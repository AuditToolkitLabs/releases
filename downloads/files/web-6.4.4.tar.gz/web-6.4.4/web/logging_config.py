#!/usr/bin/env python3
"""
Structured Logging Configuration

Production-grade logging system with:
- JSON structured output
- Log rotation
- Correlation IDs
- Multiple log levels
- Separate handlers for different log types

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import sys
import json
import re
import logging
import logging.handlers
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional
import contextvars
import uuid

# Context variable for correlation ID
correlation_id_var = contextvars.ContextVar('correlation_id', default=None)


class JSONFormatter(logging.Formatter):
    """
    JSON formatter for structured logging

    Outputs log records as JSON with:
    - timestamp
    - level
    - logger name
    - message
    - correlation_id (if set)
    - extra context fields
    """

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON"""

        # Build base log entry
        log_data: Dict[str, Any] = {
            'timestamp': datetime.utcfromtimestamp(record.created).isoformat() + 'Z',
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }

        # Add correlation ID if available
        correlation_id = correlation_id_var.get()
        if correlation_id:
            log_data['correlation_id'] = correlation_id

        # Add exception info if present
        if record.exc_info:
            log_data['exception'] = self.formatException(record.exc_info)

        # Add process and thread info
        log_data['process'] = {
            'id': record.process,
            'name': record.processName
        }
        log_data['thread'] = {
            'id': record.thread,
            'name': record.threadName
        }

        # Add any extra fields from record
        # Skip internal logging attributes
        skip_keys = {
            'name', 'msg', 'args', 'created', 'filename', 'funcName',
            'levelname', 'levelno', 'lineno', 'module', 'msecs',
            'message', 'pathname', 'process', 'processName', 'relativeCreated',
            'thread', 'threadName', 'exc_info', 'exc_text', 'stack_info'
        }

        extra = {}
        for key, value in record.__dict__.items():
            if key not in skip_keys and not key.startswith('_'):
                extra[key] = value

        if extra:
            log_data['extra'] = extra

        return json.dumps(log_data, default=str)


class ColoredConsoleFormatter(logging.Formatter):
    """
    Console formatter with colors for better readability

    Color coding by level:
    - DEBUG: Cyan
    - INFO: Green
    - WARNING: Yellow
    - ERROR: Red
    - CRITICAL: Bold Red
    """

    # ANSI color codes
    COLORS = {
        'DEBUG': '\033[36m',      # Cyan
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[33m',    # Yellow
        'ERROR': '\033[31m',      # Red
        'CRITICAL': '\033[1;31m'  # Bold Red
    }
    RESET = '\033[0m'

    def format(self, record: logging.LogRecord) -> str:
        """Format with colors for console output"""
        # Add color to level name
        levelname = record.levelname
        if levelname in self.COLORS:
            record.levelname = f"{self.COLORS[levelname]}{levelname:8}{self.RESET}"

        # Add correlation ID if present
        correlation_id = correlation_id_var.get()
        if correlation_id:
            correlation_id_short = correlation_id[:8]
            record.msg = f"[{correlation_id_short}] {record.msg}"

        # Format using parent formatter
        formatted = super().format(record)

        # Reset levelname for next use
        record.levelname = levelname

        return formatted


class SizedTimedRotatingFileHandler(logging.handlers.TimedRotatingFileHandler):
    """
    TimedRotatingFileHandler with an additional maxBytes trigger.

    Rolls over when either:
    - the configured time window is reached (e.g. midnight), or
    - the active file grows beyond maxBytes
    """

    def __init__(self, *args, maxBytes: int = 0, **kwargs):
        self.maxBytes = max(0, int(maxBytes or 0))
        super().__init__(*args, **kwargs)

    def shouldRollover(self, record: logging.LogRecord) -> int:
        if super().shouldRollover(record):
            return 1

        if self.maxBytes <= 0:
            return 0

        if self.stream is None:
            self.stream = self._open()

        message = f"{self.format(record)}{self.terminator}"
        encoding = self.encoding or 'utf-8'

        try:
            message_size = len(message.encode(encoding, errors='replace'))
        except LookupError:
            message_size = len(message.encode('utf-8', errors='replace'))

        self.stream.seek(0, os.SEEK_END)
        if self.stream.tell() + message_size >= self.maxBytes:
            return 1

        return 0


def setup_logging(
    app_name: str = 'audit-toolkit',
    log_dir: Path = None,
    log_level: str = None,
    enable_json: bool = None,
    enable_rotation: bool = True,
    max_bytes: int = 20 * 1024 * 1024,  # 20 MB
    backup_count: int = 14,
    rotation_when: str = 'midnight',
    rotation_interval: int = 1
) -> logging.Logger:
    """
    Setup comprehensive logging system

    Args:
        app_name: Application name for log files
        log_dir: Directory for log files
        log_level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        enable_json: Enable JSON logging (default: True in production)
        enable_rotation: Enable log rotation
        max_bytes: Max file size before rotation
        backup_count: Number of backup files to keep

    Returns:
        Root logger instance
    """

    # Determine defaults from environment
    if log_dir is None:
        log_dir = Path(os.getenv('LOG_DIR', 'logs'))

    if log_level is None:
        log_level = os.getenv('LOG_LEVEL', 'INFO').upper()

    if enable_json is None:
        flask_env = os.getenv('FLASK_ENV', 'development')
        enable_json = (flask_env == 'production')

    # Allow environment overrides for rotation policy
    try:
        max_bytes = int(os.getenv('LOG_MAX_BYTES', str(max_bytes)))
    except ValueError:
        max_bytes = 20 * 1024 * 1024

    try:
        backup_count = int(os.getenv('LOG_BACKUP_COUNT', str(backup_count)))
    except ValueError:
        backup_count = 14

    try:
        rotation_interval = max(1, int(os.getenv('LOG_ROTATION_INTERVAL', str(rotation_interval))))
    except ValueError:
        rotation_interval = 1

    rotation_when = os.getenv('LOG_ROTATION_WHEN', rotation_when)

    # Security settings (admin panel) override env vars if explicitly saved
    try:
        _settings_file = Path(os.getenv('AUDIT_TOOLKIT_ROOT', str(Path(__file__).parent.parent))) / 'settings' / 'security_settings.json'
        if _settings_file.exists():
            import json as _json_log
            _raw_log_settings = _json_log.loads(_settings_file.read_text(encoding='utf-8'))
            if 'log_max_bytes' in _raw_log_settings:
                max_bytes = int(_raw_log_settings['log_max_bytes'])
            if 'log_backup_count' in _raw_log_settings:
                backup_count = max(1, int(_raw_log_settings['log_backup_count']))
            if 'log_rotation_when' in _raw_log_settings:
                rotation_when = str(_raw_log_settings['log_rotation_when'])
            if 'log_rotation_interval' in _raw_log_settings:
                rotation_interval = max(1, int(_raw_log_settings['log_rotation_interval']))
    except Exception as settings_error:
        logging.getLogger(__name__).debug(
            "Failed loading security log settings overrides: %s",
            settings_error,
        )

    # Ensure log directory exists
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, log_level))

    # Clear existing handlers
    root_logger.handlers.clear()

    # Console handler (always enabled with colors)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_formatter = ColoredConsoleFormatter(
        fmt='%(asctime)s | %(levelname)s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)

    def create_file_handler(path: Path):
        if enable_rotation:
            handler = SizedTimedRotatingFileHandler(
                path,
                when=rotation_when,
                interval=rotation_interval,
                backupCount=backup_count,
                maxBytes=max_bytes,
                encoding='utf-8',
                utc=False
            )
            handler.suffix = '%Y%m%d-%H%M%S.log'
            handler.extMatch = re.compile(r'^\d{8}-\d{6}\.log$', re.ASCII)
            return handler

        return logging.FileHandler(path, encoding='utf-8')

    # File handler for all logs
    file_handler = create_file_handler(log_dir / f'{app_name}.log')

    file_handler.setLevel(logging.DEBUG)

    if enable_json:
        file_formatter = JSONFormatter()
    else:
        file_formatter = logging.Formatter(
            fmt='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s | %(pathname)s:%(lineno)d',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

    file_handler.setFormatter(file_formatter)
    root_logger.addHandler(file_handler)

    # Error log handler (errors and above only)
    error_handler = create_file_handler(log_dir / f'{app_name}-error.log')

    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(file_formatter)
    root_logger.addHandler(error_handler)

    # Access log handler (INFO level for request tracking)
    access_handler = create_file_handler(log_dir / f'{app_name}-access.log')

    access_handler.setLevel(logging.INFO)
    access_handler.addFilter(lambda record: record.name == 'werkzeug' or 'request' in record.getMessage().lower())
    access_handler.setFormatter(file_formatter)
    root_logger.addHandler(access_handler)

    # Log initial configuration
    logger = logging.getLogger(__name__)
    logger.info(
        "Logging configured",
        extra={
            'log_dir': str(log_dir),
            'log_level': log_level,
            'json_enabled': enable_json,
            'rotation_enabled': enable_rotation,
            'rotation_when': rotation_when,
            'rotation_interval': rotation_interval,
            'max_bytes': max_bytes,
            'backup_count': backup_count
        }
    )

    return root_logger


def get_correlation_id() -> Optional[str]:
    """Get current correlation ID from context"""
    return correlation_id_var.get()


def set_correlation_id(correlation_id: str):
    """Set correlation ID for current context"""
    correlation_id_var.set(correlation_id)


def generate_correlation_id() -> str:
    """Generate new correlation ID"""
    return str(uuid.uuid4())


def clear_correlation_id():
    """Clear correlation ID from context"""
    correlation_id_var.set(None)


# Flask request correlation ID middleware
def correlation_id_middleware(app):
    """
    Flask middleware to add correlation IDs to requests

    Usage:
        from logging_config import correlation_id_middleware
        correlation_id_middleware(app)
    """
    from flask import request, g

    @app.before_request
    def before_request():
        """Set correlation ID for request"""
        # Get correlation ID from header or generate new one
        correlation_id = request.headers.get('X-Correlation-ID') or generate_correlation_id()
        set_correlation_id(correlation_id)
        g.correlation_id = correlation_id

    @app.after_request
    def after_request(response):
        """Add correlation ID to response headers"""
        if hasattr(g, 'correlation_id'):
            response.headers['X-Correlation-ID'] = g.correlation_id
        return response

    @app.teardown_request
    def teardown_request(exception=None):
        """Clear correlation ID after request"""
        clear_correlation_id()


# Context manager for correlation ID
class CorrelationContext:
    """
    Context manager for correlation ID

    Usage:
        with CorrelationContext('task-123'):
            logger.info("Processing task")  # Will include correlation_id
    """

    def __init__(self, correlation_id: str = None):
        self.correlation_id = correlation_id or generate_correlation_id()
        self.previous_correlation_id = None

    def __enter__(self):
        self.previous_correlation_id = get_correlation_id()
        set_correlation_id(self.correlation_id)
        return self.correlation_id

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.previous_correlation_id:
            set_correlation_id(self.previous_correlation_id)
        else:
            clear_correlation_id()


# Helper function to get logger with extra context
def get_logger(name: str, **extra_context) -> logging.LoggerAdapter:
    """
    Get logger with extra context fields

    Args:
        name: Logger name (usually __name__)
        **extra_context: Additional context fields to add to all logs

    Returns:
        LoggerAdapter with extra context

    Example:
        logger = get_logger(__name__, component='ssh_manager')
        logger.info("Connection established", server='web-01')
    """
    base_logger = logging.getLogger(name)
    return logging.LoggerAdapter(base_logger, extra_context)
