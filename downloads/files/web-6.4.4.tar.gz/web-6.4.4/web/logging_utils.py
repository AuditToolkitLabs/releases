"""
Audit logging utilities for recording sensitive operations.

Provides centralized audit logging for:
- User actions (who did what)
- API access (rate limiting, key usage)
- Configuration changes (admin actions)
- Data exports (compliance tracking)

All audit events are written to:
1. Database (audit_log table) - for forensics
2. Syslog (journal/rsyslog) - for remote collection and immutability
"""

import logging
import json
from datetime import datetime
from typing import Optional, Dict, Any

# Get module logger
logger = logging.getLogger(__name__)


def log_audit(
    action: str,
    resource_id: Optional[str] = None,
    resource_type: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None,
    success: bool = True,
    error: Optional[str] = None,
    user_id: Optional[int] = None,
    ip_address: Optional[str] = None,
):
    """
    Log an audit event to database + syslog.

    Called after sensitive operations to create an immutable audit trail.
    Audit logs are used for forensics, compliance reporting, and intrusion detection.

    Args:
        action (str): What happened.
            Examples: 'view_discovery', 'export_discovery', 'delete_all_data',
            'manage_roles', 'regenerate_api_keys', 'create_schedule'

        resource_id (str, optional): What was affected.
            Examples: discovery_id (UUID), user_id, 'all' (for bulk operations)

        resource_type (str, optional): Type of resource.
            Examples: 'discovery_data', 'audit_result', 'user_account', 'api_key'

        details (dict, optional): Extra context as JSON.
            Examples:
            {
                'role': 'Admin',
                'team': 'Security',
                'format': 'csv',
                'row_count': 1250,
                'duration_ms': 523,
                'api_key_id': 'key_abc123'
            }

        success (bool): Did the operation succeed? (default: True)

        error (str, optional): If failed, what was the error?
            Examples: 'User not found', 'Permission denied', 'Invalid format'

        user_id (int, optional): Which user performed action (auto-detected if not provided)

        ip_address (str, optional): Source IP (auto-detected if not provided)

    Returns:
        bool: True if audit log was created successfully, False otherwise

    Example:
        ```python
        # Log successful export
        log_audit(
            action='export_discovery',
            resource_id='all',
            resource_type='discovery_data',
            details={'format': 'csv', 'host_count': 1250},
            success=True
        )

        # Log failed operation
        log_audit(
            action='decrypt_credentials',
            resource_id='cred_abc123',
            resource_type='credential',
            success=False,
            error='Invalid decryption key'
        )

        # Log API call
        log_audit(
            action='api_call_discovery_search',
            resource_type='api_request',
            details={
                'api_key_id': 'key_xyz789',
                'endpoint': '/api/discovery/search',
                'query_params': {'hostname': 'prod-*'},
                'result_count': 23
            }
        )
        ```
    """

    try:
        # Import here to avoid circular imports
        from flask import request, has_request_context
        from flask_login import current_user
        from models.audit_log import AuditLog
        from models import db

        # Auto-detect user_id and ip_address from Flask context if not provided
        if user_id is None and current_user.is_authenticated:
            user_id = current_user.id

        if ip_address is None and has_request_context():
            ip_address = request.remote_addr

        user_agent = None
        if has_request_context():
            user_agent = request.headers.get('User-Agent', '')[:500]

        # Build audit log entry
        audit_entry = AuditLog(
            timestamp=datetime.utcnow(),
            user_id=user_id,
            action=action,
            resource_id=str(resource_id) if resource_id else None,
            resource_type=resource_type or 'unknown',
            ip_address=ip_address,
            user_agent=user_agent,
            success=success,
            error_message=error,
            details=details or {}
        )

        # Store in database
        db.session.add(audit_entry)
        db.session.commit()

        # Also send to syslog (for remote collection and immutability)
        # Format matches Splunk/ELK best practices
        syslog_parts = [
            f"audit_action={action}",
        ]

        if user_id:
            syslog_parts.append(f"user_id={user_id}")
        else:
            syslog_parts.append("user_id=anonymous")

        if resource_type and resource_id:
            syslog_parts.append(f"resource={resource_type}:{resource_id}")
        elif resource_type:
            syslog_parts.append(f"resource_type={resource_type}")

        syslog_parts.append(f"success={success}")

        if ip_address:
            syslog_parts.append(f"source_ip={ip_address}")

        if error:
            syslog_parts.append(f"error={error}")

        if details:
            syslog_parts.append(f"details={json.dumps(details)}")

        syslog_message = " ".join(syslog_parts)
        logger.info(syslog_message)

        return True

    except ImportError:
        # Models not yet loaded (e.g., during migration)
        logger.warning("AuditLog model not available (may be during initialization)")
        return False

    except Exception as e:
        logger.error(f"Failed to log audit event: {e}", exc_info=True)
        # Don't raise - audit logging failure shouldn't break the operation
        return False


def get_audit_logs(
    action: Optional[str] = None,
    user_id: Optional[int] = None,
    resource_type: Optional[str] = None,
    success: Optional[bool] = None,
    limit: int = 100,
    offset: int = 0,
):
    """
    Query audit logs for forensics and compliance reporting.

    Useful for:
    - Investigating user activity: get_audit_logs(user_id=42)
    - Finding failed operations: get_audit_logs(success=False)
    - Tracking sensitive operations: get_audit_logs(action='delete_all_data')
    - Compliance audits: get_audit_logs(resource_type='user_account')

    Args:
        action (str, optional): Filter by action type
        user_id (int, optional): Filter by user ID
        resource_type (str, optional): Filter by resource type
        success (bool, optional): Filter by success/failure
        limit (int): Maximum number of results (default: 100)
        offset (int): Number of results to skip (default: 0)

    Returns:
        list[AuditLog]: Audit log entries, newest first

    Example:
        ```python
        # Get all failed operations by user 42
        logs = get_audit_logs(user_id=42, success=False, limit=50)

        # Get all data deletion operations
        logs = get_audit_logs(action='delete_all_data', limit=10)

        # Get all failed authentication attempts
        logs = get_audit_logs(action='login_failed', success=False)
        ```
    """
    try:
        from models.audit_log import AuditLog

        query = AuditLog.query

        if action:
            query = query.filter_by(action=action)
        if user_id:
            query = query.filter_by(user_id=user_id)
        if resource_type:
            query = query.filter_by(resource_type=resource_type)
        if success is not None:
            query = query.filter_by(success=success)

        # Order by newest first for forensics
        query = query.order_by(AuditLog.timestamp.desc())

        # Apply pagination
        if offset:
            query = query.offset(offset)

        return query.limit(limit).all()

    except Exception as e:
        logger.error(f"Failed to query audit logs: {e}")
        return []
