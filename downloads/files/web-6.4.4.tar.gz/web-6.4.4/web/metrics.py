"""
Prometheus Metrics for Security Audit Toolkit

This module provides comprehensive application metrics for monitoring
audit execution, system health, API performance, and resource usage.

Metrics Categories:
1. Audit Execution Metrics
2. Server Management Metrics
3. API Performance Metrics
4. Task Queue Metrics
5. Database Metrics
6. System Health Metrics

Example Usage:
    from metrics import (
        audit_counter,
        audit_duration,
        track_audit_execution
    )

    # Track audit execution
    with track_audit_execution(audit_name="baseline_security"):
        execute_audit()

    # Increment counters
    audit_counter.labels(status='success').inc()

Exposed at /metrics endpoint for Prometheus scraping.
"""

from prometheus_client import (
    Counter,
    Gauge,
    Histogram,
    Summary,
    Info,
    generate_latest,
    CollectorRegistry,
    CONTENT_TYPE_LATEST
)
from contextlib import contextmanager
from functools import wraps
import logging
import time
import psutil
import os
import tempfile
from datetime import datetime

logger = logging.getLogger(__name__)


# ============================================================================
# REGISTRY & INFO
# ============================================================================

# Custom registry (optional, can use default)
registry = CollectorRegistry()

# Application info
app_info = Info(
    'audit_toolkit_info',
    'Security Audit Toolkit application information',
    registry=registry
)
app_info.info({
    'version': '2.0',
    'python_version': f'{os.sys.version_info.major}.{os.sys.version_info.minor}',
    'environment': os.getenv('FLASK_ENV', 'development')
})


# ============================================================================
# AUDIT EXECUTION METRICS
# ============================================================================

# Total audit executions
audit_counter = Counter(
    'audit_executions_total',
    'Total number of audit executions',
    ['status', 'audit_type', 'server_hostname'],
    registry=registry
)

# Audit execution duration
audit_duration = Histogram(
    'audit_execution_duration_seconds',
    'Time spent executing audits',
    ['audit_type', 'server_hostname'],
    buckets=[1, 5, 10, 30, 60, 120, 300, 600, 1800],  # Up to 30 minutes
    registry=registry
)

# Audit execution summary (for percentiles)
audit_duration_summary = Summary(
    'audit_execution_duration_summary',
    'Summary of audit execution durations',
    ['audit_type'],
    registry=registry
)

# Active audits currently running
active_audits = Gauge(
    'audit_active_count',
    'Number of audits currently executing',
    registry=registry
)

# Audits by status
audits_by_status = Gauge(
    'audit_by_status_count',
    'Number of audits in each status',
    ['status'],  # pending, running, completed, failed, timeout
    registry=registry
)

# Failed audits details
audit_failures = Counter(
    'audit_failures_total',
    'Total number of failed audits with reasons',
    ['audit_type', 'failure_reason', 'server_hostname'],
    registry=registry
)

# Batch audit operations
batch_audit_counter = Counter(
    'batch_audit_executions_total',
    'Total number of batch audit executions',
    ['batch_size_bucket'],  # small(<10), medium(10-50), large(>50)
    registry=registry
)


# ============================================================================
# SERVER METRICS
# ============================================================================

# Total servers registered
servers_total = Gauge(
    'servers_registered_total',
    'Total number of registered servers',
    registry=registry
)

# Servers by status
servers_by_status = Gauge(
    'servers_by_status_count',
    'Number of servers in each status',
    ['status'],  # online, offline, error, unknown
    registry=registry
)

# SSH connection attempts
ssh_connections = Counter(
    'ssh_connections_total',
    'Total SSH connection attempts',
    ['status', 'server_hostname'],  # success, failed, timeout
    registry=registry
)

# SSH connection duration
ssh_connection_duration = Histogram(
    'ssh_connection_duration_seconds',
    'Time to establish SSH connection',
    ['server_hostname'],
    buckets=[0.1, 0.5, 1, 2, 5, 10, 30],
    registry=registry
)


# ============================================================================
# API PERFORMANCE METRICS
# ============================================================================

# API request count
api_requests = Counter(
    'api_requests_total',
    'Total API requests',
    ['method', 'endpoint', 'status_code'],
    registry=registry
)

# API request duration
api_request_duration = Histogram(
    'api_request_duration_seconds',
    'API request processing time',
    ['method', 'endpoint'],
    buckets=[0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 5],
    registry=registry
)

# API error rate
api_errors = Counter(
    'api_errors_total',
    'Total API errors',
    ['method', 'endpoint', 'error_type'],
    registry=registry
)

# Rate limit hits
rate_limit_hits = Counter(
    'rate_limit_hits_total',
    'Number of rate limit hits',
    ['endpoint', 'client_ip'],
    registry=registry
)

# Active API requests
active_api_requests = Gauge(
    'api_requests_active',
    'Number of API requests currently being processed',
    ['method', 'endpoint'],
    registry=registry
)


# ============================================================================
# CELERY TASK QUEUE METRICS
# ============================================================================

# Task queue depth
task_queue_depth = Gauge(
    'celery_task_queue_depth',
    'Number of tasks waiting in queue',
    ['queue_name'],  # default, audits, backups, reports
    registry=registry
)

# Task execution count
task_counter = Counter(
    'celery_task_executions_total',
    'Total task executions',
    ['task_name', 'status'],  # success, failure, retry
    registry=registry
)

# Task execution duration
task_duration = Histogram(
    'celery_task_duration_seconds',
    'Task execution time',
    ['task_name'],
    buckets=[1, 5, 10, 30, 60, 300, 600, 1800, 3600],
    registry=registry
)

# Active background tasks
active_tasks = Gauge(
    'celery_tasks_active',
    'Number of tasks currently executing',
    ['task_name'],
    registry=registry
)

# Task retries
task_retries = Counter(
    'celery_task_retries_total',
    'Number of task retries',
    ['task_name', 'retry_reason'],
    registry=registry
)


# ============================================================================
# DATABASE METRICS
# ============================================================================

# Database query count
db_queries = Counter(
    'database_queries_total',
    'Total database queries',
    ['operation', 'table'],  # select, insert, update, delete
    registry=registry
)

# Database query duration
db_query_duration = Histogram(
    'database_query_duration_seconds',
    'Database query execution time',
    ['operation', 'table'],
    buckets=[0.001, 0.01, 0.05, 0.1, 0.5, 1, 5],
    registry=registry
)

# Database connection pool
db_pool_size = Gauge(
    'database_pool_size',
    'Database connection pool size',
    ['pool_type'],  # total, active, idle
    registry=registry
)

# Database errors
db_errors = Counter(
    'database_errors_total',
    'Total database errors',
    ['error_type'],  # connection, query, timeout, constraint
    registry=registry
)

# Backup operations
backup_operations = Counter(
    'backup_operations_total',
    'Total backup operations',
    ['operation', 'status'],  # create, restore, verify, cleanup
    registry=registry
)

# Backup size
backup_size_bytes = Gauge(
    'backup_size_bytes',
    'Size of most recent backup',
    ['backup_type'],  # full, incremental, encrypted
    registry=registry
)

# Backup duration
backup_duration = Histogram(
    'backup_duration_seconds',
    'Backup operation duration',
    ['operation'],  # create, restore, verify
    buckets=[1, 5, 10, 30, 60, 300, 600],
    registry=registry
)


# ============================================================================
# SYSTEM HEALTH METRICS
# ============================================================================

# Application uptime
app_uptime = Gauge(
    'application_uptime_seconds',
    'Application uptime in seconds',
    registry=registry
)

app_start_time = time.time()


def update_uptime():
    """Update application uptime metric"""
    app_uptime.set(time.time() - app_start_time)


# System CPU usage
system_cpu_percent = Gauge(
    'system_cpu_usage_percent',
    'System CPU usage percentage',
    registry=registry
)

# System memory usage
system_memory_bytes = Gauge(
    'system_memory_usage_bytes',
    'System memory usage in bytes',
    ['type'],  # total, available, used, percent
    registry=registry
)

# System disk usage
system_disk_bytes = Gauge(
    'system_disk_usage_bytes',
    'System disk usage in bytes',
    ['path', 'type'],  # /, /var, /tmp | total, used, free
    registry=registry
)

# Application memory usage
app_memory_bytes = Gauge(
    'application_memory_usage_bytes',
    'Application memory usage in bytes',
    ['type'],  # rss, vms, shared
    registry=registry
)

# Process threads
app_threads = Gauge(
    'application_threads_count',
    'Number of application threads',
    registry=registry
)

# Health check status
health_check_status = Gauge(
    'health_check_status',
    'Health check status (1=healthy, 0=unhealthy)',
    ['component'],  # database, redis, celery, ssh, filesystem
    registry=registry
)


def update_system_metrics():
    """Update system resource metrics"""
    try:
        # CPU usage
        cpu_percent = psutil.cpu_percent(interval=0.1)
        system_cpu_percent.set(cpu_percent)

        # Memory usage
        memory = psutil.virtual_memory()
        system_memory_bytes.labels(type='total').set(memory.total)
        system_memory_bytes.labels(type='available').set(memory.available)
        system_memory_bytes.labels(type='used').set(memory.used)
        system_memory_bytes.labels(type='percent').set(memory.percent)

        # Disk usage - nosec B108: monitoring disk usage, not creating temp files
        for path in ['/', '/var', '/tmp']:  # nosec B108
            try:
                if os.path.exists(path):
                    disk = psutil.disk_usage(path)
                    system_disk_bytes.labels(path=path, type='total').set(disk.total)
                    system_disk_bytes.labels(path=path, type='used').set(disk.used)
                    system_disk_bytes.labels(path=path, type='free').set(disk.free)
            except Exception as e:
                logger.debug(f"Skipping inaccessible disk path {path}: {e}")

        # Application process metrics
        process = psutil.Process()
        memory_info = process.memory_info()
        app_memory_bytes.labels(type='rss').set(memory_info.rss)
        app_memory_bytes.labels(type='vms').set(memory_info.vms)

        # Thread count
        app_threads.set(process.num_threads())

    except Exception as e:
        print(f"Error updating system metrics: {e}")


# ============================================================================
# HELPER FUNCTIONS & DECORATORS
# ============================================================================

@contextmanager
def track_audit_execution(audit_type, server_hostname="unknown"):
    """
    Context manager to track audit execution with automatic metrics.

    Usage:
        with track_audit_execution("baseline_security", "web-server-01"):
            execute_audit()
    """
    active_audits.inc()
    start_time = time.time()

    try:
        yield
        duration = time.time() - start_time

        # Record success metrics
        audit_counter.labels(
            status='success',
            audit_type=audit_type,
            server_hostname=server_hostname
        ).inc()

        audit_duration.labels(
            audit_type=audit_type,
            server_hostname=server_hostname
        ).observe(duration)

        audit_duration_summary.labels(audit_type=audit_type).observe(duration)

    except Exception as e:
        duration = time.time() - start_time

        # Record failure metrics
        audit_counter.labels(
            status='failed',
            audit_type=audit_type,
            server_hostname=server_hostname
        ).inc()

        audit_failures.labels(
            audit_type=audit_type,
            failure_reason=type(e).__name__,
            server_hostname=server_hostname
        ).inc()

        raise

    finally:
        active_audits.dec()


@contextmanager
def track_ssh_connection(server_hostname):
    """Track SSH connection metrics"""
    start_time = time.time()

    try:
        yield
        duration = time.time() - start_time

        ssh_connections.labels(
            status='success',
            server_hostname=server_hostname
        ).inc()

        ssh_connection_duration.labels(
            server_hostname=server_hostname
        ).observe(duration)

    except Exception as e:
        status = 'timeout' if 'timeout' in str(e).lower() else 'failed'
        ssh_connections.labels(
            status=status,
            server_hostname=server_hostname
        ).inc()
        raise


@contextmanager
def track_api_request(method, endpoint):
    """Track API request metrics"""
    active_api_requests.labels(method=method, endpoint=endpoint).inc()
    start_time = time.time()
    status_code = 200

    try:
        yield

    except Exception as e:
        status_code = getattr(e, 'code', 500)
        error_type = type(e).__name__
        api_errors.labels(
            method=method,
            endpoint=endpoint,
            error_type=error_type
        ).inc()
        raise

    finally:
        duration = time.time() - start_time

        api_requests.labels(
            method=method,
            endpoint=endpoint,
            status_code=status_code
        ).inc()

        api_request_duration.labels(
            method=method,
            endpoint=endpoint
        ).observe(duration)

        active_api_requests.labels(method=method, endpoint=endpoint).dec()


def track_api_endpoint(f):
    """
    Decorator to automatically track API endpoint metrics.

    Usage:
        @app.route('/api/servers')
        @track_api_endpoint
        def list_servers():
            return jsonify(servers)
    """
    @wraps(f)
    def wrapper(*args, **kwargs):
        from flask import request
        endpoint = request.endpoint or 'unknown'
        method = request.method

        with track_api_request(method, endpoint):
            return f(*args, **kwargs)

    return wrapper


@contextmanager
def track_database_query(operation, table):
    """Track database query metrics"""
    start_time = time.time()

    try:
        yield
        duration = time.time() - start_time

        db_queries.labels(
            operation=operation,
            table=table
        ).inc()

        db_query_duration.labels(
            operation=operation,
            table=table
        ).observe(duration)

    except Exception as e:
        error_type = type(e).__name__
        db_errors.labels(error_type=error_type).inc()
        raise


@contextmanager
def track_celery_task(task_name):
    """Track Celery task execution"""
    active_tasks.labels(task_name=task_name).inc()
    start_time = time.time()

    try:
        yield
        duration = time.time() - start_time

        task_counter.labels(
            task_name=task_name,
            status='success'
        ).inc()

        task_duration.labels(task_name=task_name).observe(duration)

    except Exception:
        task_counter.labels(
            task_name=task_name,
            status='failure'
        ).inc()
        raise

    finally:
        active_tasks.labels(task_name=task_name).dec()


@contextmanager
def track_backup_operation(operation):
    """Track backup operation metrics"""
    start_time = time.time()

    try:
        yield
        duration = time.time() - start_time

        backup_operations.labels(
            operation=operation,
            status='success'
        ).inc()

        backup_duration.labels(operation=operation).observe(duration)

    except Exception:
        backup_operations.labels(
            operation=operation,
            status='failure'
        ).inc()
        raise


# ============================================================================
# FLASK INTEGRATION
# ============================================================================

def register_metrics(app):
    """
    Register metrics endpoint with Flask application.

    Usage:
        from metrics import register_metrics
        register_metrics(app)
    """
    from flask import Response, request

    @app.route('/metrics')
    def metrics_endpoint():
        """Prometheus metrics endpoint"""
        # Update dynamic metrics before scraping
        update_uptime()
        update_system_metrics()

        # Generate and return metrics
        data = generate_latest(registry)
        return Response(data, mimetype=CONTENT_TYPE_LATEST)

    @app.before_request
    def before_request():
        """Track request start time"""
        request._start_time = time.time()

    @app.after_request
    def after_request(response):
        """Track API metrics for all requests"""
        if hasattr(request, '_start_time'):
            duration = time.time() - request._start_time
            endpoint = request.endpoint or 'unknown'

            # Skip metrics endpoint to avoid recursion
            if endpoint != 'metrics_endpoint':
                api_requests.labels(
                    method=request.method,
                    endpoint=endpoint,
                    status_code=response.status_code
                ).inc()

                api_request_duration.labels(
                    method=request.method,
                    endpoint=endpoint
                ).observe(duration)

                # Track rate limit hits
                if response.status_code == 429:
                    client_ip = request.remote_addr or 'unknown'
                    rate_limit_hits.labels(
                        endpoint=endpoint,
                        client_ip=client_ip
                    ).inc()

        return response


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_metrics_summary():
    """
    Get human-readable metrics summary.

    Returns:
        dict: Summary of key metrics
    """
    return {
        'uptime_seconds': time.time() - app_start_time,
        'active_audits': active_audits._value.get(),
        'cpu_percent': system_cpu_percent._value.get(),
        'memory_percent': system_memory_bytes.labels(type='percent')._value.get(),
        'timestamp': datetime.utcnow().isoformat()
    }


def export_metrics_to_file(filepath=None):
    """
    Export metrics to file for debugging.

    Usage:
        export_metrics_to_file(os.path.join(tempfile.gettempdir(), 'app_metrics.txt'))
    """
    if filepath is None:
        filepath = os.path.join(tempfile.gettempdir(), 'metrics.txt')
    update_uptime()
    update_system_metrics()

    with open(filepath, 'wb') as f:
        f.write(generate_latest(registry))

    print(f"Metrics exported to {filepath}")


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == '__main__':
    """
    Example: Simulate metrics collection
    """
    print("Security Audit Toolkit - Metrics Module")
    print("=" * 60)

    # Simulate audit execution
    print("\nSimulating audit execution...")
    with track_audit_execution('baseline_security', 'web-server-01'):
        time.sleep(0.5)

    print("Audit metrics recorded")

    # Simulate SSH connection
    print("\nSimulating SSH connection...")
    with track_ssh_connection('web-server-01'):
        time.sleep(0.2)

    print("SSH metrics recorded")

    # Update system metrics
    print("\nCollecting system metrics...")
    update_uptime()
    update_system_metrics()

    # Print summary
    print("\n" + "=" * 60)
    print("METRICS SUMMARY")
    print("=" * 60)
    summary = get_metrics_summary()
    for key, value in summary.items():
        print(f"{key}: {value}")

    # Export to file
    print("\n" + "=" * 60)
    metrics_path = os.path.join(tempfile.gettempdir(), 'audit_toolkit_metrics.txt')
    export_metrics_to_file(metrics_path)
    print(f"\nMetrics available at {metrics_path}")
    print("\nTo scrape metrics in production:")
    print("  1. Start Flask app with metrics registered")
    print("  2. Configure Prometheus to scrape http://localhost:5000/metrics")
    print("  3. Import Grafana dashboard from grafana/dashboards/")
