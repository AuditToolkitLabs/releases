# Database Migrations with Alembic

This directory contains Alembic database migration scripts for the Security Audit Toolkit.

## Quick Start

### 1. Initialize Database (First Time)

```bash
# Run all migrations to create tables
alembic upgrade head
```

### 2. Create New Migration (After Model Changes)

```bash
# Auto-generate migration from model changes
alembic revision --autogenerate -m "description of changes"

# Example: Add a new column
alembic revision --autogenerate -m "add email column to servers"
```

### 3. Apply Migrations

```bash
# Apply all pending migrations
alembic upgrade head

# Apply specific number of migrations
alembic upgrade +2

# Apply to specific revision
alembic upgrade <revision_id>
```

### 4. Rollback Migrations

```bash
# Rollback one migration
alembic downgrade -1

# Rollback to specific revision
alembic downgrade <revision_id>

# Rollback all migrations
alembic downgrade base
```

### 5. View Migration History

```bash
# Show current database version
alembic current

# Show migration history
alembic history

# Show pending migrations
alembic heads
```

## Environment Variables

Set these before running migrations:

```bash
# For PostgreSQL
export DATABASE_URL="postgresql://user:password@localhost:5432/audit_toolkit"

# For SQLite (default)
export DATABASE_URL="sqlite:///audit_toolkit.db"
```

## Migration Files

### Current Migrations

- `001_initial_schema.py` - Creates all 4 initial tables (servers, audits, audit_executions, scheduled_audits)

### Adding Custom Migrations

If you need to create a manual migration (not auto-generated):

```bash
# Create empty migration template
alembic revision -m "description"

# Edit the generated file in versions/
# Fill in upgrade() and downgrade() functions
```

## SQLite to PostgreSQL Migration

To migrate existing data from SQLite to PostgreSQL, use the migration script:

```bash
python3 web/scripts/migrate_to_postgres.py \
  --source sqlite:///audit_toolkit.db \
  --target postgresql://user:pass@localhost/audit_toolkit
```

See [../scripts/migrate_to_postgres.py](../scripts/migrate_to_postgres.py) for details.

## Troubleshooting

### Problem: "Can't locate revision identified by..."

**Solution**: Your database is out of sync with migrations.

```bash
# Stamp database with current schema version
alembic stamp head
```

### Problem: "FAILED: Target database is not up to date"

**Solution**: Apply pending migrations first.

```bash
alembic upgrade head
```

### Problem: "Multiple head revisions are present"

**Solution**: Merge migration branches.

```bash
alembic merge heads -m "merge branches"
```

## Best Practices

1. **Always test migrations** in development before production
2. **Backup database** before running migrations in production
3. **Review auto-generated migrations** - Alembic may not catch everything
4. **Don't edit applied migrations** - Create a new migration instead
5. **Keep migrations small** - One logical change per migration

## Production Deployment

1. Backup database
2. Stop application
3. Run migrations
4. Verify schema
5. Start application

```bash
# Backup PostgreSQL
pg_dump -U user audit_toolkit > backup_$(date +%Y%m%d).sql

# Run migrations
alembic upgrade head

# Verify
alembic current

# Restore if needed
psql -U user audit_toolkit < backup_20260206.sql
```

## References

- [Alembic Documentation](https://alembic.sqlalchemy.org/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [Database Schema Design](../database_schema.md)
