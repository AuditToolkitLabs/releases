"""Initial schema - create all tables

Revision ID: 001_initial_schema
Revises:
Create Date: 2026-02-06 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '001_initial_schema'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Create all initial tables"""

    # Create servers table
    op.create_table(
        'servers',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('hostname', sa.String(length=255), nullable=False),
        sa.Column('port', sa.Integer(), nullable=False, server_default='22'),
        sa.Column('username', sa.String(length=100), nullable=False),
        sa.Column('password', sa.Text(), nullable=True),
        sa.Column('ssh_key_path', sa.String(length=500), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('tags', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('last_audit_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_servers_name', 'servers', ['name'], unique=True)
    op.create_index('idx_servers_hostname', 'servers', ['hostname'], unique=False)

    # Create audits table
    op.create_table(
        'audits',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('domain', sa.String(length=50), nullable=False),
        sa.Column('category', sa.String(length=100), nullable=False),
        sa.Column('file_path', sa.String(length=500), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_audits_name', 'audits', ['name'], unique=False)
    op.create_index('idx_audits_domain', 'audits', ['domain'], unique=False)
    op.create_index('idx_audits_file_path', 'audits', ['file_path'], unique=True)
    op.create_index('idx_audits_domain_category', 'audits', ['domain', 'category'], unique=False)

    # Create audit_executions table
    op.create_table(
        'audit_executions',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('server_id', sa.Integer(), nullable=False),
        sa.Column('audit_id', sa.Integer(), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('exit_code', sa.Integer(), nullable=True),
        sa.Column('output', sa.Text(), nullable=True),
        sa.Column('summary', sa.Text(), nullable=True),
        sa.Column('duration_seconds', sa.Float(), nullable=True),
        sa.Column('executed_by', sa.String(length=100), nullable=True),
        sa.Column('executed_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['server_id'], ['servers.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['audit_id'], ['audits.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_executions_server_id', 'audit_executions', ['server_id'], unique=False)
    op.create_index('idx_executions_audit_id', 'audit_executions', ['audit_id'], unique=False)
    op.create_index('idx_executions_status', 'audit_executions', ['status'], unique=False)
    op.create_index('idx_executions_executed_at', 'audit_executions', ['executed_at'], unique=False)
    op.create_index('idx_executions_server_audit', 'audit_executions', ['server_id', 'audit_id', 'executed_at'], unique=False)
    op.create_index('idx_executions_server_status', 'audit_executions', ['server_id', 'status', 'executed_at'], unique=False)

    # Create scheduled_audits table
    op.create_table(
        'scheduled_audits',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('server_id', sa.Integer(), nullable=False),
        sa.Column('audit_id', sa.Integer(), nullable=True),
        sa.Column('schedule_cron', sa.String(length=100), nullable=False),
        sa.Column('enabled', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('last_run_at', sa.DateTime(), nullable=True),
        sa.Column('next_run_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.ForeignKeyConstraint(['server_id'], ['servers.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['audit_id'], ['audits.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_scheduled_server_id', 'scheduled_audits', ['server_id'], unique=False)
    op.create_index('idx_scheduled_enabled_next', 'scheduled_audits', ['enabled', 'next_run_at'], unique=False)


def downgrade() -> None:
    """Drop all tables"""
    op.drop_table('scheduled_audits')
    op.drop_table('audit_executions')
    op.drop_table('audits')
    op.drop_table('servers')
