"""Add schedule and server group models

Revision ID: 002_add_schedule_models
Revises: 001_initial_schema
Create Date: 2026-02-11
"""

# Alembic identifiers
revision = '002_add_schedule_models'
down_revision = '001_initial_schema'
branch_labels = None
depends_on = None
from alembic import op
import sqlalchemy as sa

def upgrade():
    # Create maintenance_windows table
    op.create_table(
        'maintenance_windows',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text()),
        sa.Column('window_type', sa.String(length=20), nullable=False, server_default='one_time'),
        sa.Column('start_time', sa.DateTime()),
        sa.Column('end_time', sa.DateTime()),
        sa.Column('day_of_week', sa.Integer()),
        sa.Column('start_hour', sa.Integer()),
        sa.Column('start_minute', sa.Integer(), server_default='0'),
        sa.Column('duration_minutes', sa.Integer(), server_default='60'),
        sa.Column('server_id', sa.Integer(), sa.ForeignKey('servers.id', ondelete='CASCADE')),
        sa.Column('is_global', sa.Boolean(), nullable=False, server_default=sa.text('false')),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('created_by', sa.String(length=100)),
    )

    # Create server_groups table
    op.create_table(
        'server_groups',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('name', sa.String(length=100), nullable=False, unique=True, index=True),
        sa.Column('description', sa.Text()),
        sa.Column('color', sa.String(length=20), server_default='#3498db'),
        sa.Column('icon', sa.String(length=50), server_default='server'),
        sa.Column('parent_id', sa.Integer(), sa.ForeignKey('server_groups.id', ondelete='SET NULL')),
        sa.Column('is_dynamic', sa.Boolean(), nullable=False, server_default=sa.text('false')),
        sa.Column('dynamic_filter', sa.Text()),
        sa.Column('default_audit_schedule', sa.String(length=100)),
        sa.Column('maintenance_window_id', sa.Integer(), sa.ForeignKey('maintenance_windows.id', ondelete='SET NULL')),
        sa.Column('notification_emails', sa.Text()),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('created_by', sa.String(length=100)),
    )

    # Create server_group_membership table
    op.create_table(
        'server_group_membership',
        sa.Column('server_id', sa.Integer(), sa.ForeignKey('servers.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('group_id', sa.Integer(), sa.ForeignKey('server_groups.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('added_at', sa.DateTime(), server_default=sa.text('CURRENT_TIMESTAMP')),
    )

def downgrade():
    op.drop_table('server_group_membership')
    op.drop_table('server_groups')
    op.drop_table('maintenance_windows')
