"""Add dead letter queue and task failure log tables

Revision ID: 003_add_error_recovery
Revises: 002_add_schedule_models
Create Date: 2026-02-06

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers
revision = '003_add_error_recovery'
down_revision = '002_add_schedule_models'
branch_labels = None
depends_on = None


def upgrade():
    # Create dead_letter_tasks table
    op.create_table(
        'dead_letter_tasks',
        sa.Column('id', sa.Integer(), nullable=False, autoincrement=True),
        sa.Column('task_id', sa.String(length=255), nullable=False),
        sa.Column('task_name', sa.String(length=255), nullable=False),
        sa.Column('server_id', sa.Integer(), nullable=True),
        sa.Column('audit_id', sa.Integer(), nullable=True),
        sa.Column('args', sa.JSON(), nullable=True),
        sa.Column('kwargs', sa.JSON(), nullable=True),
        sa.Column('retry_count', sa.Integer(), nullable=False, default=0),
        sa.Column('max_retries', sa.Integer(), nullable=False),
        sa.Column('last_error', sa.Text(), nullable=True),
        sa.Column('last_exception_type', sa.String(length=255), nullable=True),
        sa.Column('last_traceback', sa.Text(), nullable=True),
        sa.Column('first_failure_at', sa.DateTime(), nullable=False),
        sa.Column('last_attempt_at', sa.DateTime(), nullable=False),
        sa.Column('added_to_dlq_at', sa.DateTime(), nullable=False),
        sa.Column('resolved', sa.Boolean(), nullable=False, default=False),
        sa.Column('resolved_at', sa.DateTime(), nullable=True),
        sa.Column('resolved_by', sa.String(length=255), nullable=True),
        sa.Column('resolution_notes', sa.Text(), nullable=True),
        sa.Column('retry_after', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['server_id'], ['servers.id'], ),
        sa.ForeignKeyConstraint(['audit_id'], ['audits.id'], ),
    )
    op.create_index('ix_dead_letter_tasks_task_id', 'dead_letter_tasks', ['task_id'], unique=True)
    op.create_index('ix_dead_letter_tasks_task_name', 'dead_letter_tasks', ['task_name'])
    op.create_index('ix_dead_letter_tasks_added_to_dlq_at', 'dead_letter_tasks', ['added_to_dlq_at'])
    op.create_index('ix_dead_letter_tasks_resolved', 'dead_letter_tasks', ['resolved'])

    # Create task_failure_logs table
    op.create_table(
        'task_failure_logs',
        sa.Column('id', sa.Integer(), nullable=False, autoincrement=True),
        sa.Column('task_id', sa.String(length=255), nullable=False),
        sa.Column('task_name', sa.String(length=255), nullable=False),
        sa.Column('server_id', sa.Integer(), nullable=True),
        sa.Column('audit_id', sa.Integer(), nullable=True),
        sa.Column('retry_number', sa.Integer(), nullable=False),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('exception_type', sa.String(length=255), nullable=True),
        sa.Column('traceback', sa.Text(), nullable=True),
        sa.Column('circuit_breaker_state', sa.String(length=50), nullable=True),
        sa.Column('circuit_breaker_name', sa.String(length=255), nullable=True),
        sa.Column('failed_at', sa.DateTime(), nullable=False),
        sa.Column('next_retry_at', sa.DateTime(), nullable=True),
        sa.Column('metadata', sa.JSON(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['server_id'], ['servers.id'], ),
        sa.ForeignKeyConstraint(['audit_id'], ['audits.id'], ),
    )
    op.create_index('ix_task_failure_logs_task_id', 'task_failure_logs', ['task_id'])
    op.create_index('ix_task_failure_logs_task_name', 'task_failure_logs', ['task_name'])
    op.create_index('ix_task_failure_logs_failed_at', 'task_failure_logs', ['failed_at'])


def downgrade():
    op.drop_index('ix_task_failure_logs_failed_at', table_name='task_failure_logs')
    op.drop_index('ix_task_failure_logs_task_name', table_name='task_failure_logs')
    op.drop_index('ix_task_failure_logs_task_id', table_name='task_failure_logs')
    op.drop_table('task_failure_logs')

    op.drop_index('ix_dead_letter_tasks_resolved', table_name='dead_letter_tasks')
    op.drop_index('ix_dead_letter_tasks_added_to_dlq_at', table_name='dead_letter_tasks')
    op.drop_index('ix_dead_letter_tasks_task_name', table_name='dead_letter_tasks')
    op.drop_index('ix_dead_letter_tasks_task_id', table_name='dead_letter_tasks')
    op.drop_table('dead_letter_tasks')
