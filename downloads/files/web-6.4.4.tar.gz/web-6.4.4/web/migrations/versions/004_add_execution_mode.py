"""Add execution_mode column to servers table

Revision ID: 004_add_execution_mode
Revises: 003_add_error_recovery
Create Date: 2026-02-16

This migration adds the execution_mode column to support per-server
execution mode configuration:
- 'stream': Scripts sent via SSH/WinRM stdin (agentless, no deployment)
- 'deployed': Scripts pre-installed at standard paths (requires package)
"""
from alembic import op
import sqlalchemy as sa

# revision identifiers
revision = '004_add_execution_mode'
down_revision = '003_add_error_recovery'
branch_labels = None
depends_on = None


def upgrade():
    """Add execution_mode column to servers table"""
    # Add execution_mode column with default 'stream' (agentless)
    op.add_column(
        'servers',
        sa.Column(
            'execution_mode',
            sa.String(length=20),
            nullable=False,
            server_default='stream'
        )
    )

    # Create index for execution_mode (useful for filtering servers by mode)
    op.create_index(
        'ix_servers_execution_mode',
        'servers',
        ['execution_mode']
    )


def downgrade():
    """Remove execution_mode column from servers table"""
    op.drop_index('ix_servers_execution_mode', table_name='servers')
    op.drop_column('servers', 'execution_mode')
