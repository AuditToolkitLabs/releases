"""Add Windows server support columns

Revision ID: 004_windows_support
Revises: 003_add_error_recovery
Create Date: 2026-02-07

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers
revision = '004_windows_support'
down_revision = '003_add_error_recovery'
branch_labels = None
depends_on = None


def upgrade():
    """
    Add columns to servers table for cross-platform support.
    
    New columns:
    - os_type: 'linux' or 'windows'
    - os_name: 'Ubuntu 22.04', 'Windows Server 2019', etc.
    - os_version: Version string
    - os_architecture: 'x86_64', 'x64', 'arm64', etc.
    - connection_type: 'ssh' or 'winrm'
    - connection_port: 22 (SSH) or 5985/5986 (WinRM)
    - domain: Active Directory domain (Windows only, nullable)
    """
    
    # os_type: Default to 'linux' for existing rows
    op.add_column('servers',
        sa.Column('os_type', sa.String(length=20), nullable=False, server_default='linux')
    )
    
    # os_name: Human-readable OS name (e.g., "Ubuntu 22.04 LTS")
    op.add_column('servers',
        sa.Column('os_name', sa.String(length=100), nullable=True)
    )
    
    # os_version: OS version string (e.g., "22.04", "10.0.17763")
    op.add_column('servers',
        sa.Column('os_version', sa.String(length=50), nullable=True)
    )
    
    # os_architecture: CPU architecture (e.g., "x86_64", "arm64")
    op.add_column('servers',
        sa.Column('os_architecture', sa.String(length=20), nullable=True)
    )
    
    # connection_type: Protocol used ('ssh' or 'winrm')
    op.add_column('servers',
        sa.Column('connection_type', sa.String(length=20), nullable=False, server_default='ssh')
    )
    
    # connection_port: Port number (22 for SSH, 5985/5986 for WinRM)
    op.add_column('servers',
        sa.Column('connection_port', sa.Integer(), nullable=True)
    )
    
    # domain: Active Directory domain name (Windows only)
    op.add_column('servers',
        sa.Column('domain', sa.String(length=100), nullable=True)
    )
    
    # os_build: Build number (Windows) - e.g., "17763" for Server 2019
    op.add_column('servers',
        sa.Column('os_build', sa.String(length=50), nullable=True)
    )
    
    # ssl_enabled: Whether WinRM/SSH uses SSL/TLS
    op.add_column('servers',
        sa.Column('ssl_enabled', sa.Boolean(), nullable=False, server_default='False')
    )
    
    # cert_validation: Whether to validate SSL certificates (dev vs prod)
    op.add_column('servers',
        sa.Column('cert_validation', sa.Boolean(), nullable=False, server_default='True')
    )
    
    # Create indexes for faster queries
    op.create_index('ix_servers_os_type', 'servers', ['os_type'])
    op.create_index('ix_servers_connection_type', 'servers', ['connection_type'])
    op.create_index('ix_servers_domain', 'servers', ['domain'])
    
    # Create composite index for OS queries (filter by OS type and version)
    op.create_index('ix_servers_os_type_version', 'servers', ['os_type', 'os_version'])


def downgrade():
    """
    Remove Windows support columns (rollback migration).
    """
    # Drop indexes first
    op.drop_index('ix_servers_os_type_version', table_name='servers')
    op.drop_index('ix_servers_domain', table_name='servers')
    op.drop_index('ix_servers_connection_type', table_name='servers')
    op.drop_index('ix_servers_os_type', table_name='servers')
    
    # Drop columns
    op.drop_column('servers', 'cert_validation')
    op.drop_column('servers', 'ssl_enabled')
    op.drop_column('servers', 'os_build')
    op.drop_column('servers', 'domain')
    op.drop_column('servers', 'connection_port')
    op.drop_column('servers', 'connection_type')
    op.drop_column('servers', 'os_architecture')
    op.drop_column('servers', 'os_version')
    op.drop_column('servers', 'os_name')
    op.drop_column('servers', 'os_type')
