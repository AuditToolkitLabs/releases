"""Add elevation_method and jea_endpoint columns to servers table

Revision ID: 005_add_elevation_method
Revises: 004_add_execution_mode
Create Date: 2026-02-18

This migration adds elevation configuration for least-privilege audit execution:

elevation_method - How scripts get elevated privileges on the target:
  Linux:
    - 'sudo': Standard sudo (prompts for password if required)
    - 'sudo_nopasswd': Passwordless sudo (automation-friendly)
    - 'audit_wrapper': Restricted wrapper scripts (/usr/local/bin/audit-*)
    - 'none': Connect as root directly (not recommended)

  Windows:
    - 'runas': Standard elevation (UAC prompts)
    - 'jea': Just Enough Administration endpoint (constrained PowerShell)
    - 'admin': Connect as administrator directly
    - 'none': No elevation (limited audits)

jea_endpoint - Name of the JEA endpoint for Windows servers using JEA method
  Default: 'SecurityAudit.ReadOnly'
"""
from alembic import op
import sqlalchemy as sa

# revision identifiers
revision = '005_add_elevation_method'
down_revision = '004_add_execution_mode'
branch_labels = None
depends_on = None


def upgrade():
    """Add elevation configuration columns to servers table"""

    # Add elevation_method column with default 'sudo' for Linux compatibility
    op.add_column(
        'servers',
        sa.Column(
            'elevation_method',
            sa.String(length=30),
            nullable=False,
            server_default='sudo'
        )
    )

    # Add jea_endpoint column for Windows JEA configuration
    # Only used when elevation_method='jea' and platform='windows'
    op.add_column(
        'servers',
        sa.Column(
            'jea_endpoint',
            sa.String(length=100),
            nullable=True,
            server_default=None
        )
    )

    # Create index for elevation_method (useful for filtering servers)
    op.create_index(
        'ix_servers_elevation_method',
        'servers',
        ['elevation_method']
    )


def downgrade():
    """Remove elevation configuration columns from servers table"""
    op.drop_index('ix_servers_elevation_method', table_name='servers')
    op.drop_column('servers', 'jea_endpoint')
    op.drop_column('servers', 'elevation_method')
