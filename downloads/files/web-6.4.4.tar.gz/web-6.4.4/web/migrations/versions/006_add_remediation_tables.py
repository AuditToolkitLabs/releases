"""Add remediation tables and maintenance_windows.updated_by

Revision ID: 006_add_remediation_tables
Revises: 005_add_elevation_method
Create Date: 2026-02-19

Adds:
- updated_by column to maintenance_windows table
- remediation_executions table
- remediation_settings table
"""

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '006_add_remediation_tables'
down_revision = '005_add_elevation_method'
branch_labels = None
depends_on = None


def upgrade():
    """Add remediation tables and fix maintenance_windows schema."""

    # Add missing updated_by column to maintenance_windows (if not exists)
    # Use inspector to handle idempotent column addition across databases
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    table_names = set(inspector.get_table_names())
    has_users_table = 'users' in table_names

    if not has_users_table:
        print("[Migration] users table not found; creating remediation tables without users foreign keys")

    def users_fk_column(column_name: str, nullable: bool):
        if has_users_table:
            return sa.Column(column_name, sa.Integer(), sa.ForeignKey('users.id'), nullable=nullable)
        return sa.Column(column_name, sa.Integer(), nullable=nullable)

    # Check if maintenance_windows table exists and has updated_by column
    if 'maintenance_windows' in table_names:
        columns = [col['name'] for col in inspector.get_columns('maintenance_windows')]
        if 'updated_by' not in columns:
            op.add_column('maintenance_windows',
                sa.Column('updated_by', sa.String(length=100), nullable=True)
            )

    # Create remediation_executions table (idempotent)
    if 'remediation_executions' not in table_names:
        op.create_table(
            'remediation_executions',
            sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),

            # WHO: User and Session Information
            users_fk_column('user_id', nullable=False),
            sa.Column('client_ip', sa.String(length=45), nullable=False),
            sa.Column('user_agent', sa.String(length=500), nullable=True),
            sa.Column('session_id', sa.String(length=100), nullable=True),

            # WHAT: Fix Details
            sa.Column('fix_id', sa.String(length=50), nullable=False),
            sa.Column('fix_category', sa.String(length=100), nullable=True),
            sa.Column('fix_name', sa.String(length=255), nullable=True),
            sa.Column('fix_description', sa.Text(), nullable=True),
            sa.Column('cis_control', sa.String(length=50), nullable=True),
            sa.Column('severity', sa.String(length=20), nullable=True),

            # WHERE: Target Server Information
            sa.Column('server_id', sa.Integer(), sa.ForeignKey('servers.id'), nullable=False),
            sa.Column('server_hostname', sa.String(length=255), nullable=True),
            sa.Column('os_type', sa.String(length=50), nullable=False),
            sa.Column('os_version', sa.String(length=100), nullable=True),

            # HOW: Execution Details
            sa.Column('mode', sa.String(length=20), nullable=False),
            sa.Column('command_executed', sa.Text(), nullable=False),

            # WHEN: Timestamps
            sa.Column('executed_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
            sa.Column('completed_at', sa.DateTime(), nullable=True),
            sa.Column('duration_seconds', sa.Integer(), nullable=True),

            # RESULT: Execution Outcome
            sa.Column('status', sa.String(length=20), nullable=False, server_default='pending'),
            sa.Column('exit_code', sa.Integer(), nullable=True),
            sa.Column('stdout', sa.Text(), nullable=True),
            sa.Column('stderr', sa.Text(), nullable=True),
            sa.Column('error_message', sa.Text(), nullable=True),
            sa.Column('parsed_results', sa.JSON(), nullable=True),

            # ROLLBACK: Undo Capability
            sa.Column('rollback_available', sa.Boolean(), server_default=sa.text('false')),
            sa.Column('rollback_data', sa.JSON(), nullable=True),
            sa.Column('rolled_back_at', sa.DateTime(), nullable=True),
            users_fk_column('rolled_back_by_id', nullable=True),
            sa.Column('rollback_execution_id', sa.Integer(), nullable=True),

            # BATCH EXECUTION
            sa.Column('batch_id', sa.String(length=36), nullable=True),
            sa.Column('batch_sequence', sa.Integer(), nullable=True),
        )

        # Create indexes for remediation_executions
        op.create_index('idx_remediation_user', 'remediation_executions', ['user_id'])
        op.create_index('idx_remediation_server', 'remediation_executions', ['server_id'])
        op.create_index('idx_remediation_fix', 'remediation_executions', ['fix_id'])
        op.create_index('idx_remediation_status', 'remediation_executions', ['status'])
        op.create_index('idx_remediation_executed_at', 'remediation_executions', ['executed_at'])
        op.create_index('idx_remediation_os_type', 'remediation_executions', ['os_type'])
        op.create_index('idx_remediation_batch', 'remediation_executions', ['batch_id'])

    # Create remediation_settings table (singleton, idempotent)
    if 'remediation_settings' not in table_names:
        op.create_table(
            'remediation_settings',
            sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),

            # Feature Toggles
            sa.Column('enabled', sa.Boolean(), nullable=False, server_default=sa.text('false')),
            sa.Column('require_dry_run_first', sa.Boolean(), nullable=False, server_default=sa.text('true')),
            sa.Column('require_approval', sa.Boolean(), nullable=False, server_default=sa.text('false')),

            # Access Restrictions (Time-based)
            sa.Column('allowed_hours_start', sa.Time(), nullable=True),
            sa.Column('allowed_hours_end', sa.Time(), nullable=True),
            sa.Column('allowed_days', sa.JSON(), nullable=True),
            sa.Column('timezone', sa.String(length=50), nullable=False, server_default='UTC'),
            sa.Column('ip_allowlist', sa.JSON(), nullable=True),

            # Safety Settings
            sa.Column('max_fixes_per_hour', sa.Integer(), nullable=False, server_default='20'),
            sa.Column('max_concurrent_executions', sa.Integer(), nullable=False, server_default='3'),
            sa.Column('execution_timeout_seconds', sa.Integer(), nullable=False, server_default='300'),
            sa.Column('blacklisted_fix_ids', sa.JSON(), nullable=True),
            sa.Column('high_risk_categories', sa.JSON(), nullable=True),

            # Platform-Specific Settings
            sa.Column('linux_enabled', sa.Boolean(), nullable=False, server_default=sa.text('true')),
            sa.Column('linux_fix_path', sa.String(length=500), nullable=False, server_default='/opt/audit-toolkit/fix/linux'),
            sa.Column('windows_enabled', sa.Boolean(), nullable=False, server_default=sa.text('true')),
            sa.Column('windows_fix_path', sa.String(length=500), nullable=False, server_default='C:\\audit-toolkit\\fix\\windows'),
            sa.Column('hypervisor_enabled', sa.Boolean(), nullable=False, server_default=sa.text('true')),
            sa.Column('hypervisor_fix_path', sa.String(length=500), nullable=False, server_default='/opt/audit-toolkit/fix/hypervisors'),
            sa.Column('auto_deploy_scripts', sa.Boolean(), nullable=False, server_default=sa.text('true')),

            # Notification Settings
            sa.Column('notify_on_execution', sa.Boolean(), nullable=False, server_default=sa.text('true')),
            sa.Column('notify_on_failure', sa.Boolean(), nullable=False, server_default=sa.text('true')),
            sa.Column('notification_emails', sa.JSON(), nullable=True),
            sa.Column('slack_webhook_url', sa.String(length=500), nullable=True),

            # Metadata
            sa.Column('updated_at', sa.DateTime(), server_default=sa.text('CURRENT_TIMESTAMP')),
            users_fk_column('updated_by_id', nullable=True),
        )

        # Insert default settings row (idempotent, transaction-safe)
        existing_default = conn.execute(
            sa.text("SELECT id FROM remediation_settings WHERE id = :id"),
            {"id": 1}
        ).first()

        if existing_default is None:
            conn.execute(
                sa.text("""
                    INSERT INTO remediation_settings (id, enabled)
                    VALUES (:id, :enabled)
                """),
                {"id": 1, "enabled": False}
            )


def downgrade():
    """Remove remediation tables and maintenance_windows.updated_by column."""
    op.drop_table('remediation_settings')
    op.drop_index('idx_remediation_batch', table_name='remediation_executions')
    op.drop_index('idx_remediation_os_type', table_name='remediation_executions')
    op.drop_index('idx_remediation_executed_at', table_name='remediation_executions')
    op.drop_index('idx_remediation_status', table_name='remediation_executions')
    op.drop_index('idx_remediation_fix', table_name='remediation_executions')
    op.drop_index('idx_remediation_server', table_name='remediation_executions')
    op.drop_index('idx_remediation_user', table_name='remediation_executions')
    op.drop_table('remediation_executions')
    # Only drop column if this migration added it (not if it already existed)
    try:
        op.drop_column('maintenance_windows', 'updated_by')
    except Exception as drop_error:
        _ = drop_error  # Column might not have been added by this migration
