"""
Add audit_plans table for reusable audit configurations

Revision ID: 0007
Revises: 0006
Create Date: 2026-02-19

This migration adds the audit_plans table which stores:
- Reusable audit selection configurations
- Target server assignments
- Execution options (timeout, elevation, etc.)
- Schedule configurations for automated runs
"""

from alembic import op
import sqlalchemy as sa
from datetime import datetime

# revision identifiers
revision = '007_add_audit_plans'
down_revision = '006_add_remediation_tables'
branch_labels = None
depends_on = None


def upgrade():
    """Create audit_plans table"""
    # Check if table already exists (idempotent)
    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'audit_plans' not in inspector.get_table_names():
        op.create_table(
            'audit_plans',
            sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),

            # Plan Identity
            sa.Column('name', sa.String(255), unique=True, nullable=False, index=True),
            sa.Column('description', sa.Text(), nullable=True),

            # Audit Selection (JSON array of audit paths)
            sa.Column('audit_paths', sa.Text(), nullable=False),

            # Target Servers (JSON array of server IDs - optional)
            sa.Column('server_ids', sa.Text(), nullable=True),

            # Execution Options (JSON object)
            sa.Column('execution_options', sa.Text(), nullable=True),

            # Schedule Configuration (JSON object)
            sa.Column('schedule_config', sa.Text(), nullable=True),

            # Plan Metadata
            sa.Column('tags', sa.Text(), nullable=True),
            sa.Column('is_active', sa.Boolean(), nullable=False, default=True),
            sa.Column('is_template', sa.Boolean(), nullable=False, default=False),

            # Ownership & Access
            sa.Column('created_by', sa.String(100), nullable=True),
            sa.Column('shared_with', sa.Text(), nullable=True),

            # Statistics
            sa.Column('run_count', sa.Integer(), nullable=False, default=0),
            sa.Column('last_run_at', sa.DateTime(), nullable=True),
            sa.Column('last_run_status', sa.String(20), nullable=True),

            # Timestamps
            sa.Column('created_at', sa.DateTime(), nullable=False, default=datetime.utcnow),
            sa.Column('updated_at', sa.DateTime(), nullable=False, default=datetime.utcnow),
        )

        # Create indexes
        op.create_index('idx_audit_plans_active', 'audit_plans', ['is_active'])
        op.create_index('idx_audit_plans_created_by', 'audit_plans', ['created_by'])

        print("Created audit_plans table")
    else:
        print("Table audit_plans already exists, skipping...")


def downgrade():
    """Drop audit_plans table"""
    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'audit_plans' in inspector.get_table_names():
        op.drop_index('idx_audit_plans_created_by', table_name='audit_plans')
        op.drop_index('idx_audit_plans_active', table_name='audit_plans')
        op.drop_table('audit_plans')
        print("Dropped audit_plans table")
