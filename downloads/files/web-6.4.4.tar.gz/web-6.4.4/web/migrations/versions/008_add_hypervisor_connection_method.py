"""
Add connection_method column to hypervisors table

Revision ID: 008_add_hypervisor_conn_method
Revises: 007_add_audit_plans
Create Date: 2026-02-19
"""

from alembic import op
import sqlalchemy as sa

# revision identifiers
revision = '008_add_hypervisor_conn_method'
down_revision = '007_add_audit_plans'
branch_labels = None
depends_on = None


def upgrade():
    """Add connection_method column to hypervisors table (idempotent)."""
    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'hypervisors' not in inspector.get_table_names():
        return

    columns = [col['name'] for col in inspector.get_columns('hypervisors')]
    if 'connection_method' not in columns:
        op.add_column(
            'hypervisors',
            sa.Column('connection_method', sa.String(length=20), nullable=False, server_default='api')
        )

        # Backfill existing rows to api
        op.execute("UPDATE hypervisors SET connection_method='api' WHERE connection_method IS NULL")

        # Remove server-side default after backfill (app-level default remains)
        # Note: SQLite doesn't support ALTER COLUMN DROP DEFAULT, so we skip this step
        # The server_default already takes effect during insert
        if conn.dialect.name != 'sqlite':
            op.alter_column('hypervisors', 'connection_method', server_default=None)


def downgrade():
    """Remove connection_method column from hypervisors table."""
    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'hypervisors' not in inspector.get_table_names():
        return

    columns = [col['name'] for col in inspector.get_columns('hypervisors')]
    if 'connection_method' in columns:
        op.drop_column('hypervisors', 'connection_method')
