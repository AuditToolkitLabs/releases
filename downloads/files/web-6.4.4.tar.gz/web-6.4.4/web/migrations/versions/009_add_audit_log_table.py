"""
Add audit_log table for security event logging

Implements NIST SP 800-92 audit logging:
- WHO (user_id)
- WHAT (action, resource_id, resource_type)
- WHEN (timestamp)
- WHERE (ip_address)
- WHETHER (success/failure)
- WHY (details JSON)

Revision ID: 009_add_audit_log_table
Revises: 008_add_hypervisor_conn_method
Create Date: 2026-02-19
"""

from alembic import op
import sqlalchemy as sa

# revision identifiers
revision = '009_add_audit_log_table'
down_revision = '008_add_hypervisor_conn_method'
branch_labels = None
depends_on = None


def upgrade():
    """Create audit_log table for security event logging."""
    conn = op.get_bind()
    inspector = sa.inspect(conn)

    # Check if table already exists (idempotent)
    if 'audit_log' in inspector.get_table_names():
        return

    # Create audit_log table
    op.create_table(
        'audit_log',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('timestamp', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('action', sa.String(length=100), nullable=False),
        sa.Column('resource_id', sa.String(length=100), nullable=True),
        sa.Column('resource_type', sa.String(length=50), nullable=False),
        sa.Column('ip_address', sa.String(length=50), nullable=True),
        sa.Column('user_agent', sa.String(length=500), nullable=True),
        sa.Column('success', sa.Boolean(), nullable=False, server_default='1'),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('details', sa.JSON(), nullable=False, server_default='{}'),
        sa.PrimaryKeyConstraint('id'),
    )

    # Create indexes for common forensic queries
    op.create_index(
        'idx_audit_user_timestamp',
        'audit_log',
        ['user_id', 'timestamp'],
        unique=False
    )

    op.create_index(
        'idx_audit_action_timestamp',
        'audit_log',
        ['action', 'timestamp'],
        unique=False
    )

    op.create_index(
        'idx_audit_resource',
        'audit_log',
        ['resource_type', 'resource_id'],
        unique=False
    )

    op.create_index(
        'idx_audit_failures',
        'audit_log',
        ['success', 'timestamp'],
        unique=False
    )


def downgrade():
    """Remove audit_log table."""
    conn = op.get_bind()
    inspector = sa.inspect(conn)

    # Check if table exists (idempotent)
    if 'audit_log' not in inspector.get_table_names():
        return

    # Drop indexes
    try:
        op.drop_index('idx_audit_failures', table_name='audit_log')
    except Exception:  # nosec B110
        pass

    try:
        op.drop_index('idx_audit_resource', table_name='audit_log')
    except Exception:  # nosec B110
        pass

    try:
        op.drop_index('idx_audit_action_timestamp', table_name='audit_log')
    except Exception:  # nosec B110
        pass

    try:
        op.drop_index('idx_audit_user_timestamp', table_name='audit_log')
    except Exception:  # nosec B110
        pass

    # Drop table
    op.drop_table('audit_log')
