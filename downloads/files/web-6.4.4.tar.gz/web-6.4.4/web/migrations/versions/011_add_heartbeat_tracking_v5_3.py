"""
Add Heartbeat Tracking Fields for Management Agent v5.3.0

Implements strict heartbeat validation with license re-validation on every cycle.
Adds fields to track:
- Last successful heartbeat timestamp
- Consecutive heartbeat failure count
- Heartbeat status (ok, license_expired, invalid_key, connection_error, etc)

Features:
- Fail-safe connectivity: Agent stops after 3 consecutive heartbeat failures
- Server-enforced licensing: License status checked on each heartbeat
- Operational visibility: Dashboard shows agent health status
- Foundation for Phase 3 JAR consolidation

Revision ID: 011_add_heartbeat_tracking_v5_3
Revises: 93ee7eacdc75
Create Date: 2026-02-20
"""

from alembic import op
import sqlalchemy as sa


revision = '011_add_heartbeat_tracking_v5_3'
down_revision = '93ee7eacdc75'
branch_labels = None
depends_on = None


def upgrade():
    """
    Add heartbeat tracking fields to FleetAgent table.

    New fields:
    - last_heartbeat_at: Timestamp of last successful heartbeat
    - consecutive_heartbeat_failures: Counter for failed heartbeats (0-3)
    - last_heartbeat_status: Status of last heartbeat attempt
    - heartbeat_failure_reason: Human-readable reason for failure
    """

    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'managed_agents' not in inspector.get_table_names():
        print("[Migration] managed_agents table not found, skipping heartbeat tracking migration")
        return

    existing_columns = {col['name'] for col in inspector.get_columns('managed_agents')}

    # ========================================================================
    # Add heartbeat tracking columns to managed_agents table
    # ========================================================================

    if 'last_heartbeat_at' not in existing_columns:
        op.add_column('managed_agents',
            sa.Column('last_heartbeat_at', sa.DateTime, nullable=True)
        )

    if 'consecutive_heartbeat_failures' not in existing_columns:
        op.add_column('managed_agents',
            sa.Column('consecutive_heartbeat_failures', sa.Integer,
                      nullable=False, default=0, server_default='0')
        )

    if 'last_heartbeat_status' not in existing_columns:
        op.add_column('managed_agents',
            sa.Column('last_heartbeat_status', sa.String(50),
                      nullable=True, default='unknown', server_default='unknown')
        )

    if 'heartbeat_failure_reason' not in existing_columns:
        op.add_column('managed_agents',
            sa.Column('heartbeat_failure_reason', sa.String(200),
                      nullable=True)
        )

    existing_indexes = {idx['name'] for idx in inspector.get_indexes('managed_agents')}

    # Create index for heartbeat_at (for querying agents by health)
    if 'idx_managed_agents_last_heartbeat_at' not in existing_indexes:
        op.create_index(
            'idx_managed_agents_last_heartbeat_at',
            'managed_agents',
            ['last_heartbeat_at']
        )

    # Create index for consecutive failures (for finding "dead" agents)
    if 'idx_managed_agents_consecutive_failures' not in existing_indexes:
        op.create_index(
            'idx_managed_agents_consecutive_failures',
            'managed_agents',
            ['consecutive_heartbeat_failures']
        )

    # Create index for heartbeat status (for health dashboard filtering)
    if 'idx_managed_agents_hb_status' not in existing_indexes:
        op.create_index(
            'idx_managed_agents_hb_status',
            'managed_agents',
            ['last_heartbeat_status']
        )


def downgrade():
    """
    Remove heartbeat tracking columns and indexes.
    """

    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'managed_agents' not in inspector.get_table_names():
        return

    existing_indexes = {idx['name'] for idx in inspector.get_indexes('managed_agents')}

    # Drop indexes
    if 'idx_managed_agents_hb_status' in existing_indexes:
        op.drop_index('idx_managed_agents_hb_status', table_name='managed_agents')
    if 'idx_managed_agents_consecutive_failures' in existing_indexes:
        op.drop_index('idx_managed_agents_consecutive_failures', table_name='managed_agents')
    if 'idx_managed_agents_last_heartbeat_at' in existing_indexes:
        op.drop_index('idx_managed_agents_last_heartbeat_at', table_name='managed_agents')

    existing_columns = {col['name'] for col in inspector.get_columns('managed_agents')}

    # Drop columns
    if 'heartbeat_failure_reason' in existing_columns:
        op.drop_column('managed_agents', 'heartbeat_failure_reason')
    if 'last_heartbeat_status' in existing_columns:
        op.drop_column('managed_agents', 'last_heartbeat_status')
    if 'consecutive_heartbeat_failures' in existing_columns:
        op.drop_column('managed_agents', 'consecutive_heartbeat_failures')
    if 'last_heartbeat_at' in existing_columns:
        op.drop_column('managed_agents', 'last_heartbeat_at')
