"""
Add Destination Policy Admin Settings Tables

Implements centralized management of destination whitelist/blacklist policies
enforced at audit execution and agent registration endpoints.

Tables:
- admin_destination_policy: Global policy configuration (Superadmin only)
- admin_destination_policy_log: Audit trail of policy enforcement and blocked attempts

Policy Features:
- Prevent SIEM/monitoring endpoint conflicts (default blocked keywords)
- Optional whitelist-only mode for high-security environments
- Private IP range blocking (RFC1918, loopback, link-local, multicast)
- Comprehensive audit logging for compliance reporting
- Selectable enforcement scope (asset discovery, audit execution, agents)

Revision ID: 012_add_destination_policy
Revises: 011_add_heartbeat_tracking_v5_3
Create Date: 2026-02-20
"""

from alembic import op
import sqlalchemy as sa


revision = '012_add_destination_policy'
down_revision = '011_add_heartbeat_tracking_v5_3'
branch_labels = None
depends_on = None


def upgrade():
    """
    Create admin_destination_policy and admin_destination_policy_log tables.
    """

    # ========================================================================
    # Create admin_destination_policy table
    # ========================================================================

    op.create_table(
        'admin_destination_policy',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('name', sa.String(255), nullable=False,
                  server_default='Global Destination Policy'),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('mode', sa.String(50), nullable=False,
                  server_default='ALLOW_ALL',
                  comment='ALLOW_ALL or WHITELIST_ONLY'),
        sa.Column('blocked_keywords', sa.Text, nullable=True,
                  server_default='wazuh,splunk,elastic,datadog,newrelic'),
        sa.Column('whitelist_domains', sa.Text, nullable=True),
        sa.Column('allow_private_ips', sa.Boolean, nullable=False,
                  server_default='0'),
        sa.Column('log_blocked_attempts', sa.Boolean, nullable=False,
                  server_default='1'),
        sa.Column('enforce_asset_discovery', sa.Boolean, nullable=False,
                  server_default='1'),
        sa.Column('enforce_audit_execution', sa.Boolean, nullable=False,
                  server_default='1'),
        sa.Column('enforce_fleet_agent_registration', sa.Boolean,
                  nullable=False, server_default='1'),
        sa.Column('enforce_hypervisor_registration', sa.Boolean,
                  nullable=False, server_default='1'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='1'),
        sa.Column('created_at', sa.DateTime, nullable=False,
                  server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime, nullable=False,
                  server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_by', sa.String(255), nullable=True),
    )

    # Create index for active policies
    op.create_index(
        'idx_admin_destination_policy_active',
        'admin_destination_policy',
        ['is_active']
    )

    # ========================================================================
    # Create admin_destination_policy_log table
    # ========================================================================

    op.create_table(
        'admin_destination_policy_log',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('policy_id', sa.Integer,
                  sa.ForeignKey('admin_destination_policy.id'),
                  nullable=False),
        sa.Column('action', sa.String(50), nullable=False,
                  server_default='BLOCKED',
                  comment='BLOCKED, ALLOWED, WARNED'),
        sa.Column('reason', sa.String(255), nullable=True,
                  comment='Why action was taken'),
        sa.Column('destination', sa.String(512), nullable=False,
                  comment='Target URL/hostname:port'),
        sa.Column('destination_hostname', sa.String(255), nullable=True),
        sa.Column('destination_port', sa.Integer, nullable=True),
        sa.Column('destination_type', sa.String(50), nullable=True,
                  comment='url, hostname, ip_address'),
        sa.Column('source_endpoint', sa.String(100), nullable=False,
                  comment='Which endpoint: asset_discovery, audit_execution, etc'),
        sa.Column('source_user', sa.String(255), nullable=True),
        sa.Column('source_ip', sa.String(45), nullable=True),
        sa.Column('source_context', sa.JSON, nullable=True,
                  comment='Additional context: server_id, audit_id, etc'),
        sa.Column('timestamp', sa.DateTime, nullable=False,
                  server_default=sa.text('CURRENT_TIMESTAMP'), index=True),
    )

    # Create indexes for efficient querying
    op.create_index(
        'idx_admin_dest_policy_log_policy_id',
        'admin_destination_policy_log',
        ['policy_id']
    )

    op.create_index(
        'idx_admin_dest_policy_log_destination_hostname',
        'admin_destination_policy_log',
        ['destination_hostname']
    )

    op.create_index(
        'idx_admin_dest_policy_log_source_endpoint',
        'admin_destination_policy_log',
        ['source_endpoint']
    )

    op.create_index(
        'idx_admin_dest_policy_log_source_user',
        'admin_destination_policy_log',
        ['source_user']
    )

    op.create_index(
        'idx_admin_dest_policy_log_source_ip',
        'admin_destination_policy_log',
        ['source_ip']
    )

    op.create_index(
        'idx_admin_dest_policy_log_action',
        'admin_destination_policy_log',
        ['action']
    )


def downgrade():
    """
    Drop admin_destination_policy and admin_destination_policy_log tables.
    """

    # Drop log table first (has FK to policy table)
    op.drop_table('admin_destination_policy_log')

    # Drop policy table
    op.drop_table('admin_destination_policy')
