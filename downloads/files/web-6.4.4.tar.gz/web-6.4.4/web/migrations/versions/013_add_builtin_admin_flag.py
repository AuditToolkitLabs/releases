"""
Add Break-Glass Recovery Admin Flag

Adds the is_builtin_admin column to the users table to identify the
built-in recovery admin account.

The break-glass account (like 'root' in Linux) ALWAYS uses local
authentication regardless of LDAP/SSO/Entra settings. This ensures
operators can always recover access to the system.

Key Features:
- is_builtin_admin flag marks the recovery account
- Break-glass accounts bypass SSO/LDAP authentication
- Ensures system recovery access is always available
- Default admin account created on first run is marked as break-glass

Revision ID: 013_add_builtin_admin_flag
Revises: 012_add_destination_policy
Create Date: 2026-02-23
"""

from alembic import op
import sqlalchemy as sa


revision = '013_add_builtin_admin_flag'
down_revision = '012_add_destination_policy'
branch_labels = None
depends_on = None


def upgrade():
    """
    Add is_builtin_admin column to users table.
    Mark existing admin user (id=1) as break-glass if it exists.
    """

    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'users' not in inspector.get_table_names():
        print("[Migration] users table not found, skipping built-in admin migration")
        return

    existing_columns = {col['name'] for col in inspector.get_columns('users')}

    # Add the is_builtin_admin column with default False
    # Using batch mode for SQLite compatibility
    if 'is_builtin_admin' not in existing_columns:
        with op.batch_alter_table('users', schema=None) as batch_op:
            batch_op.add_column(
                sa.Column(
                    'is_builtin_admin',
                    sa.Boolean,
                    nullable=False,
                    server_default='0',
                    comment='Break-glass recovery account flag - always uses local auth'
                )
            )

    # Mark the first SuperAdmin user as the break-glass account
    # This is typically the 'admin' user created on initial setup
    existing_columns = {col['name'] for col in inspector.get_columns('users')}
    required_columns = {'id', 'role', 'auth_provider', 'is_builtin_admin'}
    if not required_columns.issubset(existing_columns):
        print("[Migration] users table missing required columns for backfill; skipping break-glass marker update")
        return

    connection = conn

    # Find the first SuperAdmin with auth_provider='local'
    result = connection.execute(
        sa.text("""
            UPDATE users
            SET is_builtin_admin = :builtin_admin_value
            WHERE id = (
                SELECT MIN(id) FROM users
                WHERE role = 'SuperAdmin' AND auth_provider = 'local'
            )
        """),
        {"builtin_admin_value": True}
    )

    # Log the result
    print(f"[Migration] Marked {result.rowcount} user(s) as break-glass admin")


def downgrade():
    """
    Remove is_builtin_admin column from users table.
    """
    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'users' not in inspector.get_table_names():
        return

    existing_columns = {col['name'] for col in inspector.get_columns('users')}
    if 'is_builtin_admin' in existing_columns:
        with op.batch_alter_table('users', schema=None) as batch_op:
            batch_op.drop_column('is_builtin_admin')
