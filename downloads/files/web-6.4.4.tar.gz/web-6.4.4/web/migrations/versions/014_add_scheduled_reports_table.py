"""
Add scheduled_reports table for recurring PDF delivery

Creates the ScheduledReport persistence table used by Celery beat/worker
for periodic report generation.

Revision ID: 014_add_scheduled_reports_table
Revises: 013_add_builtin_admin_flag
Create Date: 2026-03-07
"""

from alembic import op
import sqlalchemy as sa


revision = '014_add_scheduled_reports_table'
down_revision = '013_add_builtin_admin_flag'
branch_labels = None
depends_on = None


def upgrade():
    """Create scheduled_reports table if it does not already exist."""
    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'scheduled_reports' in inspector.get_table_names():
        return

    op.create_table(
        'scheduled_reports',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('server_ids', sa.JSON(), nullable=True),
        sa.Column('server_tags', sa.JSON(), nullable=True),
        sa.Column('include_all_servers', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('compliance_framework', sa.String(length=50), nullable=True, server_default='none'),
        sa.Column('organization', sa.String(length=255), nullable=True),
        sa.Column('classification', sa.String(length=100), nullable=True, server_default='Confidential'),
        sa.Column('include_executive_summary', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('include_recommendations', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('cron_schedule', sa.String(length=100), nullable=False),
        sa.Column('frequency', sa.String(length=50), nullable=True, server_default='weekly'),
        sa.Column('timezone', sa.String(length=50), nullable=True, server_default='UTC'),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('email_recipients', sa.JSON(), nullable=False),
        sa.Column('webhook_urls', sa.JSON(), nullable=True),
        sa.Column('last_run', sa.DateTime(), nullable=True),
        sa.Column('next_run', sa.DateTime(), nullable=True),
        sa.Column('last_status', sa.String(length=50), nullable=True),
        sa.Column('last_error', sa.Text(), nullable=True),
        sa.Column('run_count', sa.Integer(), nullable=True, server_default=sa.text('0')),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', sa.String(length=100), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )

    op.create_index(
        'idx_scheduled_reports_active_next_run',
        'scheduled_reports',
        ['is_active', 'next_run'],
        unique=False,
    )
    op.create_index(
        'idx_scheduled_reports_created_by',
        'scheduled_reports',
        ['created_by'],
        unique=False,
    )


def downgrade():
    """Drop scheduled_reports table if present."""
    conn = op.get_bind()
    inspector = sa.inspect(conn)

    if 'scheduled_reports' not in inspector.get_table_names():
        return

    try:
        op.drop_index('idx_scheduled_reports_created_by', table_name='scheduled_reports')
    except Exception:  # nosec B110
        pass

    try:
        op.drop_index('idx_scheduled_reports_active_next_run', table_name='scheduled_reports')
    except Exception:  # nosec B110
        pass

    op.drop_table('scheduled_reports')
