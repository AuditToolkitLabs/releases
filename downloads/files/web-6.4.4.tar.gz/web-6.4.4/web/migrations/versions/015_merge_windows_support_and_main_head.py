"""
Merge windows-support and main migration heads

Unifies the two active Alembic branches:
- 004_windows_support
- 014_add_scheduled_reports_table

Revision ID: 015_merge_windows_support_main
Revises: 004_windows_support, 014_add_scheduled_reports_table
Create Date: 2026-03-07
"""

from typing import Sequence, Union


revision: str = '015_merge_windows_support_main'
down_revision: Union[str, Sequence[str], None] = (
    '004_windows_support',
    '014_add_scheduled_reports_table',
)
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Merge revision; no schema changes."""
    pass


def downgrade() -> None:
    """Unmerge revision; no schema changes."""
    pass
