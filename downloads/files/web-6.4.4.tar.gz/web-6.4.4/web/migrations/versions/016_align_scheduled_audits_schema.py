"""Align scheduled_audits and servers schema drift for PostgreSQL runtime

Revision ID: 016_align_scheduled_audits_schema
Revises: 015_merge_windows_support_main
Create Date: 2026-03-07
"""

from alembic import op
import sqlalchemy as sa


revision = '016_align_scheduled_audits_schema'
down_revision = '015_merge_windows_support_main'
branch_labels = None
depends_on = None


def _table_columns(inspector, table_name):
    return {column['name'] for column in inspector.get_columns(table_name)}


def _ensure_auxiliary_tables(connection):
    from models.audit_history import AuditHistorySummary, ServerComplianceHistory
    from models.maintenance_window import ScheduleExecutionLog

    AuditHistorySummary.__table__.create(bind=connection, checkfirst=True)
    ServerComplianceHistory.__table__.create(bind=connection, checkfirst=True)
    ScheduleExecutionLog.__table__.create(bind=connection, checkfirst=True)


def _ensure_servers_columns(connection, inspector, dialect):
    if 'servers' not in inspector.get_table_names():
        return

    if dialect == 'postgresql':
        op.execute(sa.text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS connection_method VARCHAR(20) NOT NULL DEFAULT 'ssh'"))
        op.execute(sa.text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS agent_id VARCHAR(50)"))
        op.execute(sa.text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS hypervisor_type VARCHAR(50)"))
        op.execute(sa.text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS hypervisor_endpoint VARCHAR(255)"))
        return

    columns = _table_columns(inspector, 'servers')
    if 'connection_method' not in columns:
        op.add_column(
            'servers',
            sa.Column('connection_method', sa.String(length=20), nullable=False, server_default='ssh')
        )
    if 'agent_id' not in columns:
        op.add_column('servers', sa.Column('agent_id', sa.String(length=50), nullable=True))
    if 'hypervisor_type' not in columns:
        op.add_column('servers', sa.Column('hypervisor_type', sa.String(length=50), nullable=True))
    if 'hypervisor_endpoint' not in columns:
        op.add_column('servers', sa.Column('hypervisor_endpoint', sa.String(length=255), nullable=True))


def _ensure_scheduled_audits_schema(connection, inspector, dialect):
    if 'scheduled_audits' not in inspector.get_table_names():
        op.create_table(
            'scheduled_audits',
            sa.Column('id', sa.Integer(), primary_key=True),
            sa.Column('name', sa.String(length=255), nullable=False),
            sa.Column('server_id', sa.Integer(), sa.ForeignKey('servers.id', ondelete='CASCADE'), nullable=False),
            sa.Column('audit_id', sa.Integer(), sa.ForeignKey('audits.id', ondelete='CASCADE'), nullable=False),
            sa.Column('cron_schedule', sa.String(length=100), nullable=False),
            sa.Column('is_active', sa.Boolean(), nullable=False, server_default=sa.text('true')),
            sa.Column('notification_enabled', sa.Boolean(), nullable=False, server_default=sa.text('false')),
            sa.Column('notification_emails', sa.Text(), nullable=True),
            sa.Column('notification_webhooks', sa.Text(), nullable=True),
            sa.Column('last_run', sa.DateTime(), nullable=True),
            sa.Column('next_run', sa.DateTime(), nullable=True),
            sa.Column('last_status', sa.String(length=50), nullable=True),
            sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
            sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
            sa.Column('created_by', sa.String(length=100), nullable=True),
        )
    elif dialect == 'postgresql':
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS name VARCHAR(255)"))
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS cron_schedule VARCHAR(100)"))
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS is_active BOOLEAN"))
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS notification_enabled BOOLEAN NOT NULL DEFAULT false"))
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS notification_emails TEXT"))
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS notification_webhooks TEXT"))
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS last_run TIMESTAMP"))
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS next_run TIMESTAMP"))
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS last_status VARCHAR(50)"))
        op.execute(sa.text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS created_by VARCHAR(100)"))
    else:
        columns = _table_columns(inspector, 'scheduled_audits')

        if 'name' not in columns:
            op.add_column('scheduled_audits', sa.Column('name', sa.String(length=255), nullable=True))
        if 'cron_schedule' not in columns:
            op.add_column('scheduled_audits', sa.Column('cron_schedule', sa.String(length=100), nullable=True))
        if 'is_active' not in columns:
            op.add_column('scheduled_audits', sa.Column('is_active', sa.Boolean(), nullable=True))
        if 'notification_enabled' not in columns:
            op.add_column(
                'scheduled_audits',
                sa.Column('notification_enabled', sa.Boolean(), nullable=False, server_default=sa.text('false'))
            )
        if 'notification_emails' not in columns:
            op.add_column('scheduled_audits', sa.Column('notification_emails', sa.Text(), nullable=True))
        if 'notification_webhooks' not in columns:
            op.add_column('scheduled_audits', sa.Column('notification_webhooks', sa.Text(), nullable=True))
        if 'last_run' not in columns:
            op.add_column('scheduled_audits', sa.Column('last_run', sa.DateTime(), nullable=True))
        if 'next_run' not in columns:
            op.add_column('scheduled_audits', sa.Column('next_run', sa.DateTime(), nullable=True))
        if 'last_status' not in columns:
            op.add_column('scheduled_audits', sa.Column('last_status', sa.String(length=50), nullable=True))
        if 'created_by' not in columns:
            op.add_column('scheduled_audits', sa.Column('created_by', sa.String(length=100), nullable=True))

    columns = _table_columns(sa.inspect(connection), 'scheduled_audits')

    if 'schedule_cron' in columns and 'cron_schedule' in columns:
        connection.execute(sa.text("""
            UPDATE scheduled_audits
            SET cron_schedule = schedule_cron
            WHERE cron_schedule IS NULL
        """))

    if 'enabled' in columns and 'is_active' in columns:
        connection.execute(sa.text("""
            UPDATE scheduled_audits
            SET is_active = enabled
            WHERE is_active IS NULL
        """))

    if 'last_run_at' in columns and 'last_run' in columns:
        connection.execute(sa.text("""
            UPDATE scheduled_audits
            SET last_run = last_run_at
            WHERE last_run IS NULL
        """))

    if 'next_run_at' in columns and 'next_run' in columns:
        connection.execute(sa.text("""
            UPDATE scheduled_audits
            SET next_run = next_run_at
            WHERE next_run IS NULL
        """))

    if 'name' in columns:
        connection.execute(sa.text("""
            UPDATE scheduled_audits
            SET name = 'Schedule #' || id
            WHERE name IS NULL OR TRIM(name) = ''
        """))

    if 'cron_schedule' in columns:
        connection.execute(sa.text("""
            UPDATE scheduled_audits
            SET cron_schedule = '0 0 * * *'
            WHERE cron_schedule IS NULL OR TRIM(cron_schedule) = ''
        """))

    if 'is_active' in columns:
        connection.execute(sa.text("""
            UPDATE scheduled_audits
            SET is_active = true
            WHERE is_active IS NULL
        """))

    if dialect == 'postgresql':
        if 'name' in columns:
            op.execute(sa.text("ALTER TABLE scheduled_audits ALTER COLUMN name SET NOT NULL"))
        if 'cron_schedule' in columns:
            op.execute(sa.text("ALTER TABLE scheduled_audits ALTER COLUMN cron_schedule SET NOT NULL"))
        if 'is_active' in columns:
            op.execute(sa.text("ALTER TABLE scheduled_audits ALTER COLUMN is_active SET NOT NULL"))
            op.execute(sa.text("ALTER TABLE scheduled_audits ALTER COLUMN is_active SET DEFAULT true"))

        op.execute(sa.text("CREATE INDEX IF NOT EXISTS idx_schedule_active_next_run ON scheduled_audits (is_active, next_run)"))
        op.execute(sa.text("CREATE INDEX IF NOT EXISTS idx_schedule_server_id ON scheduled_audits (server_id)"))
        op.execute(sa.text("CREATE INDEX IF NOT EXISTS idx_schedule_audit_id ON scheduled_audits (audit_id)"))
    else:
        with op.batch_alter_table('scheduled_audits', schema=None) as batch_op:
            if 'name' in columns:
                batch_op.alter_column('name', existing_type=sa.String(length=255), nullable=False)
            if 'cron_schedule' in columns:
                batch_op.alter_column('cron_schedule', existing_type=sa.String(length=100), nullable=False)
            if 'is_active' in columns:
                batch_op.alter_column(
                    'is_active',
                    existing_type=sa.Boolean(),
                    nullable=False,
                    server_default=sa.text('true')
                )

        indexes = {index['name'] for index in sa.inspect(connection).get_indexes('scheduled_audits')}
        if 'idx_schedule_active_next_run' not in indexes:
            op.create_index('idx_schedule_active_next_run', 'scheduled_audits', ['is_active', 'next_run'])
        if 'idx_schedule_server_id' not in indexes:
            op.create_index('idx_schedule_server_id', 'scheduled_audits', ['server_id'])
        if 'idx_schedule_audit_id' not in indexes:
            op.create_index('idx_schedule_audit_id', 'scheduled_audits', ['audit_id'])


def upgrade():
    connection = op.get_bind()
    inspector = sa.inspect(connection)
    dialect = connection.dialect.name

    _ensure_scheduled_audits_schema(connection, inspector, dialect)
    _ensure_servers_columns(connection, sa.inspect(connection), dialect)
    _ensure_auxiliary_tables(connection)


def downgrade():
    """No-op downgrade for schema-drift alignment migration."""
    pass
