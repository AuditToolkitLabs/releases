"""Add canonical reporting core tables.

Revision ID: 017_add_reporting_core_tables
Revises: 016_align_scheduled_audits_schema
Create Date: 2026-05-08
"""

from alembic import op
import sqlalchemy as sa


revision = '017_add_reporting_core_tables'
down_revision = '016_align_scheduled_audits_schema'
branch_labels = None
depends_on = None


def _table_exists(inspector, table_name):
    return table_name in inspector.get_table_names()


def _index_names(inspector, table_name):
    return {index['name'] for index in inspector.get_indexes(table_name)}


def _create_reporting_assets(inspector):
    if _table_exists(inspector, 'reporting_assets'):
        return

    op.create_table(
        'reporting_assets',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('asset_uid', sa.String(length=64), nullable=False),
        sa.Column('display_name', sa.String(length=255), nullable=False),
        sa.Column('asset_class', sa.String(length=50), nullable=False),
        sa.Column('platform', sa.String(length=50), nullable=False),
        sa.Column('hostname', sa.String(length=255), nullable=True),
        sa.Column('primary_ip', sa.String(length=45), nullable=True),
        sa.Column('environment', sa.String(length=50), nullable=True),
        sa.Column('owner', sa.String(length=255), nullable=True),
        sa.Column('business_unit', sa.String(length=255), nullable=True),
        sa.Column('status', sa.String(length=30), nullable=False, server_default='active'),
        sa.Column('criticality', sa.String(length=30), nullable=True),
        sa.Column('first_seen_at', sa.DateTime(), nullable=True),
        sa.Column('last_seen_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint('asset_uid', name='uq_reporting_assets_asset_uid'),
    )
    op.create_index('idx_reporting_assets_asset_uid', 'reporting_assets', ['asset_uid'], unique=False)
    op.create_index('idx_reporting_assets_display_name', 'reporting_assets', ['display_name'], unique=False)
    op.create_index('idx_reporting_assets_asset_class', 'reporting_assets', ['asset_class'], unique=False)
    op.create_index('idx_reporting_assets_platform', 'reporting_assets', ['platform'], unique=False)
    op.create_index('idx_reporting_assets_hostname', 'reporting_assets', ['hostname'], unique=False)
    op.create_index('idx_reporting_assets_primary_ip', 'reporting_assets', ['primary_ip'], unique=False)
    op.create_index('idx_reporting_assets_environment', 'reporting_assets', ['environment'], unique=False)
    op.create_index('idx_reporting_assets_owner', 'reporting_assets', ['owner'], unique=False)
    op.create_index('idx_reporting_assets_status', 'reporting_assets', ['status'], unique=False)
    op.create_index('idx_reporting_assets_last_seen_at', 'reporting_assets', ['last_seen_at'], unique=False)
    op.create_index('idx_reporting_assets_class_platform', 'reporting_assets', ['asset_class', 'platform'], unique=False)
    op.create_index('idx_reporting_assets_environment_status', 'reporting_assets', ['environment', 'status'], unique=False)


def _create_reporting_data_sources(inspector):
    if _table_exists(inspector, 'reporting_data_sources'):
        return

    op.create_table(
        'reporting_data_sources',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('source_code', sa.String(length=64), nullable=False),
        sa.Column('source_type', sa.String(length=50), nullable=False),
        sa.Column('source_name', sa.String(length=255), nullable=False),
        sa.Column('collection_method', sa.String(length=50), nullable=False),
        sa.Column('trust_level', sa.String(length=30), nullable=False, server_default='medium'),
        sa.Column('default_confidence_score', sa.Float(), nullable=False, server_default=sa.text('0.5')),
        sa.Column('active', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint('source_code', name='uq_reporting_data_sources_source_code'),
    )
    op.create_index('idx_reporting_data_sources_source_code', 'reporting_data_sources', ['source_code'], unique=False)
    op.create_index('idx_reporting_data_sources_source_type', 'reporting_data_sources', ['source_type'], unique=False)
    op.create_index('idx_reporting_data_sources_trust_level', 'reporting_data_sources', ['trust_level'], unique=False)
    op.create_index('idx_reporting_data_sources_active', 'reporting_data_sources', ['active'], unique=False)


def _create_reporting_asset_links(inspector):
    if _table_exists(inspector, 'reporting_asset_links'):
        return

    op.create_table(
        'reporting_asset_links',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('reporting_asset_id', sa.Integer(), sa.ForeignKey('reporting_assets.id', ondelete='CASCADE'), nullable=False),
        sa.Column('source_system', sa.String(length=50), nullable=False),
        sa.Column('source_table', sa.String(length=100), nullable=False),
        sa.Column('source_record_id', sa.String(length=100), nullable=False),
        sa.Column('source_key', sa.String(length=255), nullable=True),
        sa.Column('is_primary', sa.Boolean(), nullable=False, server_default=sa.text('false')),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('idx_reporting_asset_links_source_system', 'reporting_asset_links', ['source_system'], unique=False)
    op.create_index('idx_reporting_asset_links_is_primary', 'reporting_asset_links', ['is_primary'], unique=False)
    op.create_index(
        'idx_reporting_asset_links_source_record',
        'reporting_asset_links',
        ['source_system', 'source_table', 'source_record_id'],
        unique=False,
    )


def _create_reporting_observations(inspector):
    if _table_exists(inspector, 'reporting_observations'):
        return

    op.create_table(
        'reporting_observations',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('reporting_asset_id', sa.Integer(), sa.ForeignKey('reporting_assets.id', ondelete='CASCADE'), nullable=False),
        sa.Column('reporting_data_source_id', sa.Integer(), sa.ForeignKey('reporting_data_sources.id', ondelete='CASCADE'), nullable=False),
        sa.Column('observation_type', sa.String(length=50), nullable=False),
        sa.Column('collected_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('effective_at', sa.DateTime(), nullable=True),
        sa.Column('confidence_score', sa.Float(), nullable=False, server_default=sa.text('0.5')),
        sa.Column('freshness_seconds', sa.Integer(), nullable=True),
        sa.Column('raw_summary', sa.Text(), nullable=True),
        sa.Column('raw_payload_ref', sa.String(length=255), nullable=True),
        sa.Column('metadata_json', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('idx_reporting_observations_observation_type', 'reporting_observations', ['observation_type'], unique=False)
    op.create_index('idx_reporting_observations_collected_at', 'reporting_observations', ['collected_at'], unique=False)
    op.create_index(
        'idx_reporting_observations_asset_type_collected',
        'reporting_observations',
        ['reporting_asset_id', 'observation_type', 'collected_at'],
        unique=False,
    )


def _create_reporting_findings(inspector):
    if _table_exists(inspector, 'reporting_findings'):
        return

    op.create_table(
        'reporting_findings',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('finding_uid', sa.String(length=64), nullable=False),
        sa.Column('reporting_asset_id', sa.Integer(), sa.ForeignKey('reporting_assets.id', ondelete='CASCADE'), nullable=False),
        sa.Column('reporting_observation_id', sa.Integer(), sa.ForeignKey('reporting_observations.id', ondelete='CASCADE'), nullable=False),
        sa.Column('title', sa.String(length=500), nullable=False),
        sa.Column('category', sa.String(length=100), nullable=True),
        sa.Column('severity', sa.String(length=20), nullable=False),
        sa.Column('priority_score', sa.Float(), nullable=True),
        sa.Column('status', sa.String(length=30), nullable=False, server_default='open'),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('remediation', sa.Text(), nullable=True),
        sa.Column('external_reference', sa.String(length=255), nullable=True),
        sa.Column('first_observed_at', sa.DateTime(), nullable=True),
        sa.Column('last_observed_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint('finding_uid', name='uq_reporting_findings_finding_uid'),
    )
    op.create_index('idx_reporting_findings_finding_uid', 'reporting_findings', ['finding_uid'], unique=False)
    op.create_index('idx_reporting_findings_category', 'reporting_findings', ['category'], unique=False)
    op.create_index('idx_reporting_findings_severity', 'reporting_findings', ['severity'], unique=False)
    op.create_index('idx_reporting_findings_status', 'reporting_findings', ['status'], unique=False)
    op.create_index(
        'idx_reporting_findings_asset_severity_status',
        'reporting_findings',
        ['reporting_asset_id', 'severity', 'status'],
        unique=False,
    )
    op.create_index('idx_reporting_findings_status_updated', 'reporting_findings', ['status', 'updated_at'], unique=False)


def _create_reporting_control_evaluations(inspector):
    if _table_exists(inspector, 'reporting_control_evaluations'):
        return

    op.create_table(
        'reporting_control_evaluations',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('reporting_asset_id', sa.Integer(), sa.ForeignKey('reporting_assets.id', ondelete='CASCADE'), nullable=True),
        sa.Column('reporting_observation_id', sa.Integer(), sa.ForeignKey('reporting_observations.id', ondelete='CASCADE'), nullable=False),
        sa.Column('framework', sa.String(length=50), nullable=False),
        sa.Column('control_id', sa.String(length=100), nullable=False),
        sa.Column('control_family', sa.String(length=100), nullable=True),
        sa.Column('status', sa.String(length=30), nullable=False),
        sa.Column('score', sa.Float(), nullable=True),
        sa.Column('evidence_summary', sa.Text(), nullable=True),
        sa.Column('evaluated_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('idx_reporting_controls_framework', 'reporting_control_evaluations', ['framework'], unique=False)
    op.create_index('idx_reporting_controls_control_id', 'reporting_control_evaluations', ['control_id'], unique=False)
    op.create_index('idx_reporting_controls_control_family', 'reporting_control_evaluations', ['control_family'], unique=False)
    op.create_index('idx_reporting_controls_status', 'reporting_control_evaluations', ['status'], unique=False)
    op.create_index('idx_reporting_controls_evaluated_at', 'reporting_control_evaluations', ['evaluated_at'], unique=False)
    op.create_index(
        'idx_reporting_controls_framework_status',
        'reporting_control_evaluations',
        ['framework', 'status', 'evaluated_at'],
        unique=False,
    )


def upgrade():
    inspector = sa.inspect(op.get_bind())

    _create_reporting_assets(inspector)
    _create_reporting_data_sources(sa.inspect(op.get_bind()))
    _create_reporting_asset_links(sa.inspect(op.get_bind()))
    _create_reporting_observations(sa.inspect(op.get_bind()))
    _create_reporting_findings(sa.inspect(op.get_bind()))
    _create_reporting_control_evaluations(sa.inspect(op.get_bind()))


def downgrade():
    inspector = sa.inspect(op.get_bind())

    if _table_exists(inspector, 'reporting_control_evaluations'):
        indexes = _index_names(sa.inspect(op.get_bind()), 'reporting_control_evaluations')
        for name in (
            'idx_reporting_controls_framework_status',
            'idx_reporting_controls_evaluated_at',
            'idx_reporting_controls_status',
            'idx_reporting_controls_control_family',
            'idx_reporting_controls_control_id',
            'idx_reporting_controls_framework',
        ):
            if name in indexes:
                op.drop_index(name, table_name='reporting_control_evaluations')
        op.drop_table('reporting_control_evaluations')

    if _table_exists(sa.inspect(op.get_bind()), 'reporting_findings'):
        indexes = _index_names(sa.inspect(op.get_bind()), 'reporting_findings')
        for name in (
            'idx_reporting_findings_status_updated',
            'idx_reporting_findings_asset_severity_status',
            'idx_reporting_findings_status',
            'idx_reporting_findings_severity',
            'idx_reporting_findings_category',
            'idx_reporting_findings_finding_uid',
        ):
            if name in indexes:
                op.drop_index(name, table_name='reporting_findings')
        op.drop_table('reporting_findings')

    if _table_exists(sa.inspect(op.get_bind()), 'reporting_observations'):
        indexes = _index_names(sa.inspect(op.get_bind()), 'reporting_observations')
        for name in (
            'idx_reporting_observations_asset_type_collected',
            'idx_reporting_observations_collected_at',
            'idx_reporting_observations_observation_type',
        ):
            if name in indexes:
                op.drop_index(name, table_name='reporting_observations')
        op.drop_table('reporting_observations')

    if _table_exists(sa.inspect(op.get_bind()), 'reporting_asset_links'):
        indexes = _index_names(sa.inspect(op.get_bind()), 'reporting_asset_links')
        for name in (
            'idx_reporting_asset_links_source_record',
            'idx_reporting_asset_links_is_primary',
            'idx_reporting_asset_links_source_system',
        ):
            if name in indexes:
                op.drop_index(name, table_name='reporting_asset_links')
        op.drop_table('reporting_asset_links')

    if _table_exists(sa.inspect(op.get_bind()), 'reporting_data_sources'):
        indexes = _index_names(sa.inspect(op.get_bind()), 'reporting_data_sources')
        for name in (
            'idx_reporting_data_sources_active',
            'idx_reporting_data_sources_trust_level',
            'idx_reporting_data_sources_source_type',
            'idx_reporting_data_sources_source_code',
        ):
            if name in indexes:
                op.drop_index(name, table_name='reporting_data_sources')
        op.drop_table('reporting_data_sources')

    if _table_exists(sa.inspect(op.get_bind()), 'reporting_assets'):
        indexes = _index_names(sa.inspect(op.get_bind()), 'reporting_assets')
        for name in (
            'idx_reporting_assets_environment_status',
            'idx_reporting_assets_class_platform',
            'idx_reporting_assets_last_seen_at',
            'idx_reporting_assets_status',
            'idx_reporting_assets_owner',
            'idx_reporting_assets_environment',
            'idx_reporting_assets_primary_ip',
            'idx_reporting_assets_hostname',
            'idx_reporting_assets_platform',
            'idx_reporting_assets_asset_class',
            'idx_reporting_assets_display_name',
            'idx_reporting_assets_asset_uid',
        ):
            if name in indexes:
                op.drop_index(name, table_name='reporting_assets')
        op.drop_table('reporting_assets')
