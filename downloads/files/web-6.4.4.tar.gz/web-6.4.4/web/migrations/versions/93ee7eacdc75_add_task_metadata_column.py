"""add_task_metadata_column

Revision ID: 93ee7eacdc75
Revises: 010_encrypt_sensitive_fields
Create Date: 2026-02-20 09:42:44.307208

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '93ee7eacdc75'
down_revision: Union[str, None] = '010_encrypt_sensitive_fields'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add task_metadata JSON column to task_failure_logs table."""
    # Add task_metadata column (JSON type for storing task context)
    op.add_column(
        'task_failure_logs',
        sa.Column('task_metadata', sa.JSON(), nullable=True)
    )


def downgrade() -> None:
    """Remove task_metadata column from task_failure_logs table."""
    op.drop_column('task_failure_logs', 'task_metadata')
