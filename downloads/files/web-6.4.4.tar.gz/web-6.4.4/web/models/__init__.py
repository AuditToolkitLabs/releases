"""
Models package for Security Audit Toolkit

Provides data persistence and business logic for:
- Server configurations (file-based and database)
- Audit discovery and management
- Execution history
- SQLAlchemy ORM models for PostgreSQL/SQLite
"""

from .server import ServerManager
from .audit import AuditManager

# Database models (optional - require SQLAlchemy)
try:
    from .database import (
        Base,
        Server,
        Hypervisor,
        HypervisorAuditExecution,
        Audit,
        AuditExecution,
        init_db,
        drop_all_tables,
        get_table_names
    )
    DATABASE_AVAILABLE = True
except ImportError:
    Base = None
    Server = None
    Hypervisor = None
    HypervisorAuditExecution = None
    Audit = None
    AuditExecution = None
    init_db = None
    drop_all_tables = None
    get_table_names = None
    DATABASE_AVAILABLE = False

# Schedule models - MUST be imported immediately after database.py
# because Server model has a relationship to ScheduledAudit
try:
    from .schedule import ScheduledAudit
except ImportError as e:
    import sys
    print(f"[WARN] ScheduledAudit import failed: {e}", file=sys.stderr)
    ScheduledAudit = None

# Scheduled report model (optional)
try:
    from .scheduled_report import ScheduledReport
except ImportError as e:
    import sys
    print(f"[WARN] ScheduledReport import failed: {e}", file=sys.stderr)
    ScheduledReport = None

# Maintenance window models - also referenced by Server
# NOTE: Imported by database.py's _register_related_models() to avoid duplicate registration
# DO NOT import here to prevent "Multiple classes found" SQLAlchemy error
# try:
#     from .maintenance_window import MaintenanceWindow, ScheduleExecutionLog
# except ImportError as e:
#     import sys
#     print(f"[WARN] MaintenanceWindow import failed: {e}", file=sys.stderr)
#     MaintenanceWindow = None
#     ScheduleExecutionLog = None
MaintenanceWindow = None
ScheduleExecutionLog = None

# User models - MUST be imported BEFORE terminal (terminal references users table)
try:
    from .user import User, UserSession, PasswordHistory, AuthAuditLog, Role
except ImportError as e:
    import sys
    print(f"[WARN] User import failed: {e}", file=sys.stderr)
    User = None
    UserSession = None
    PasswordHistory = None
    AuthAuditLog = None
    Role = None

# Audit logging models (Phase 0 security hardening)
try:
    from .audit_log import AuditLog
except ImportError as e:
    import sys
    print(f"[WARN] AuditLog import failed: {e}", file=sys.stderr)
    AuditLog = None

# Encryption utilities (Phase 0 security hardening)
try:
    from .encrypted_field import EncryptedField
except ImportError as e:
    import sys
    print(f"[WARN] EncryptedField import failed: {e}", file=sys.stderr)
    EncryptedField = None

# Dead letter models (optional)
try:
    from .dead_letter import DeadLetterTask, TaskFailureLog
except ImportError:
    DeadLetterTask = None
    TaskFailureLog = None

# External push ingest models (optional)
try:
    from .external_push import ExternalFinding, ExternalAsset
except ImportError:
    ExternalFinding = None
    ExternalAsset = None

# Reporting models (optional)
try:
    from .reporting import (
        ReportingAsset,
        ReportingAssetLink,
        ReportingDataSource,
        ReportingObservation,
        ReportingFinding,
        ReportingControlEvaluation,
    )
except ImportError:
    ReportingAsset = None
    ReportingAssetLink = None
    ReportingDataSource = None
    ReportingObservation = None
    ReportingFinding = None
    ReportingControlEvaluation = None

# Terminal models (optional)
try:
    from .terminal import (
        TerminalConnectionProfile,
        TerminalSessionRecording,
        TerminalAccessSettings
    )
except ImportError:
    TerminalConnectionProfile = None
    TerminalSessionRecording = None
    TerminalAccessSettings = None

# Server groups (optional - must be before compliance)
try:
    from .server_group import ServerGroup
except ImportError as e:
    import logging
    logging.getLogger(__name__).debug(f"ServerGroup import failed: {e}")
    ServerGroup = None

# Differential audit models (optional)
try:
    from .differential import (
        DifferentialComparison,
        RemediationItem,
        RemediationHistory
    )
except ImportError:
    DifferentialComparison = None
    RemediationItem = None
    RemediationHistory = None

# Compliance tracking models (optional)
try:
    from .compliance import (
        ComplianceAssessment,
        ComplianceControl,
        ComplianceTrend,
        ComplianceFrameworkConfig
    )
except ImportError:
    ComplianceAssessment = None
    ComplianceControl = None
    ComplianceTrend = None
    ComplianceFrameworkConfig = None

# CVE database models (optional)
try:
    from .cve import (
        CVERecord,
        CPEMatch,
        PackageCPEMap,
        CVESettings,
        CVESyncLog,
        ServerCVESummary
    )
except ImportError:
    CVERecord = None
    CPEMatch = None
    PackageCPEMap = None
    CVESettings = None
    CVESyncLog = None
    ServerCVESummary = None

# Destination Policy models (admin settings)
try:
    from .destination_policy import (
        AdminDestinationPolicy,
        AdminDestinationPolicyLog
    )
except ImportError as e:
    import sys
    print(f"[WARN] AdminDestinationPolicy import failed: {e}", file=sys.stderr)
    AdminDestinationPolicy = None
    AdminDestinationPolicyLog = None

# Developer Script Studio models (optional)
try:
    from .developer import (
        LicenseType,
        ScriptStatus,
        ScriptPlatform,
        DeveloperLicense,
        AuditScriptDraft,
        ScriptVersion,
        ScriptTestResult,
        ScriptTemplate,
        DeveloperActivityLog
    )
except ImportError:
    LicenseType = None
    ScriptStatus = None
    ScriptPlatform = None
    DeveloperLicense = None
    AuditScriptDraft = None
    ScriptVersion = None
    ScriptTestResult = None
    ScriptTemplate = None
    DeveloperActivityLog = None

__all__ = [
    # Managers (legacy file-based storage)
    'ServerManager',
    'AuditManager',

    # SQLAlchemy ORM Models
    'Base',
    'Server',
    'Audit',
    'AuditExecution',
    'ScheduledAudit',
    'ScheduledReport',

    # User and Auth Models
    'User',
    'UserSession',
    'PasswordHistory',
    'AuthAuditLog',
    'Role',
    'AuditLog',
    'EncryptedField',

    # Other Models
    'DeadLetterTask',
    'TaskFailureLog',
    'ExternalFinding',
    'ExternalAsset',
    'ReportingAsset',
    'ReportingAssetLink',
    'ReportingDataSource',
    'ReportingObservation',
    'ReportingFinding',
    'ReportingControlEvaluation',
    'TerminalConnectionProfile',
    'TerminalSessionRecording',
    'TerminalAccessSettings',
    'DifferentialComparison',
    'RemediationItem',
    'RemediationHistory',
    'ComplianceAssessment',
    'ComplianceControl',
    'ComplianceTrend',
    'ComplianceFrameworkConfig',
    'CVERecord',
    'CPEMatch',
    'PackageCPEMap',
    'CVESettings',
    'CVESyncLog',
    'ServerCVESummary',

    # Destination Policy Models
    'AdminDestinationPolicy',
    'AdminDestinationPolicyLog',

    # Developer Script Studio Models
    'LicenseType',
    'ScriptStatus',
    'ScriptPlatform',
    'DeveloperLicense',
    'AuditScriptDraft',
    'ScriptVersion',
    'ScriptTestResult',
    'ScriptTemplate',
    'DeveloperActivityLog',

    # Database utilities
    'init_db',
    'drop_all_tables',
    'get_table_names',

    # Availability flags
    'DATABASE_AVAILABLE',
]
