"""
Agent Command Queue Model

Stores commands to be executed by agents, enabling server-initiated
audit execution for agent-connected servers.

Command Types:
- run_audit: Execute a single audit
- run_plan: Execute a list of audits
- run_discovery: Perform network discovery
- update_config: Update agent configuration

Author: Security Audit Toolkit Team
Date: February 15, 2026
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Index
from models.database import Base
from models.encrypted_field import EncryptedField


class AgentCommand(Base):
    """
    Agent command queue table - stores pending commands for agents

    Commands are queued by the server and polled by agents via heartbeat.
    """
    __tablename__ = 'agent_commands'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Agent & Server Reference
    agent_id = Column(String(50), nullable=False, index=True)
    server_id = Column(Integer, nullable=True)  # May be null for agent-level commands

    # Command Details
    command_type = Column(String(50), nullable=False)  # run_audit, run_plan, run_discovery
    command_data = Column(EncryptedField(), nullable=False)  # JSON payload with command details
    priority = Column(Integer, nullable=False, default=5)  # 1=highest, 10=lowest

    # Status Tracking
    status = Column(String(20), nullable=False, default='pending', index=True)
    # Status values: pending, acknowledged, in_progress, completed, failed, expired

    # Result Storage
    result_data = Column(EncryptedField(), nullable=True)  # JSON result from agent
    error_message = Column(EncryptedField(), nullable=True)

    # Requester Info
    requested_by = Column(String(100), nullable=True)  # Username who queued the command
    request_source = Column(String(50), nullable=True)  # ui, api, schedule

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    acknowledged_at = Column(DateTime, nullable=True)  # When agent received it
    started_at = Column(DateTime, nullable=True)  # When agent started execution
    completed_at = Column(DateTime, nullable=True)
    expires_at = Column(DateTime, nullable=True)  # Command expiration time

    # Indexes for efficient queries
    __table_args__ = (
        Index('idx_agent_commands_agent_status', 'agent_id', 'status'),
        Index('idx_agent_commands_created', 'created_at'),
    )

    def __repr__(self):
        return f"<AgentCommand(id={self.id}, agent={self.agent_id}, type={self.command_type}, status={self.status})>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'agent_id': self.agent_id,
            'server_id': self.server_id,
            'command_type': self.command_type,
            'command_data': self.command_data,
            'priority': self.priority,
            'status': self.status,
            'result_data': self.result_data,
            'error_message': self.error_message,
            'requested_by': self.requested_by,
            'request_source': self.request_source,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None
        }
