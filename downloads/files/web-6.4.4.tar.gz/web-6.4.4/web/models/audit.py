"""
Audit Model - Audit Discovery and Management

Provides functionality for:
- Discovering audit scripts from filesystem
- Caching discovered audits
- Organizing audits by domain and category
"""

import os
import logging
from pathlib import Path
from datetime import datetime

# Lazy config imports to avoid circular import with config.py
logger = logging.getLogger(__name__)


def _get_audits_dir():
    """Get AUDITS_DIR lazily to avoid circular imports."""
    from config import AUDITS_DIR
    return AUDITS_DIR


def _get_root_dir():
    """Get ROOT_DIR lazily to avoid circular imports."""
    from config import ROOT_DIR
    return ROOT_DIR


class AuditManager:
    """Manager for audit discovery and caching"""

    def __init__(self, cache_ttl=300):
        """Initialize audit manager

        Args:
            cache_ttl: Cache time-to-live in seconds (default: 5 minutes)
        """
        self.cache = {
            "data": None,
            "timestamp": None,
            "ttl": cache_ttl
        }
        self.skip_dirs = {"_lib", "orchestrators"}

    def discover_audits(self, force_refresh=False):
        """Discover all available audit scripts (CACHED for performance)

        Args:
            force_refresh: Force cache refresh even if cache is valid

        Returns:
            list: List of audit dictionaries with path, domain, category, name
        """
        now = datetime.now()

        # Check cache validity
        if not force_refresh and self.cache["data"] is not None:
            cached_time = self.cache["timestamp"]
            if cached_time and (now - cached_time).total_seconds() < self.cache["ttl"]:
                logger.debug("Returning cached audit list")
                return self.cache["data"]

        logger.info("Discovering audits (cache miss or refresh)")

        audits = []

        # Get directories lazily to avoid circular imports
        AUDITS_DIR = _get_audits_dir()
        ROOT_DIR = _get_root_dir()

        # OPTIMIZED: Use os.walk with pruning instead of rglob
        # Detect scripts by extension: .sh for Linux/Bash, .ps1 for Windows/PowerShell
        valid_extensions = ('.sh', '.ps1')

        for root, dirs, files in os.walk(AUDITS_DIR):
            # Prune excluded directories BEFORE traversing
            dirs[:] = [d for d in dirs if d not in self.skip_dirs]

            # Process script files in current directory
            for file in files:
                # Check for valid script extensions (Bash or PowerShell)
                if not file.endswith(valid_extensions):
                    continue

                script_path = Path(root) / file
                rel_path = script_path.relative_to(ROOT_DIR)
                parts = rel_path.parts[1:]  # Remove 'audits' prefix

                # Determine platform and domain from path structure
                # audits/linux/domain/category/name.sh
                # audits/windows/domain/name.ps1
                # audits/hypervisors/type/[category]/name.sh
                platform = parts[0] if parts else "other"

                if platform == "linux" and len(parts) > 1:
                    domain = parts[1] if len(parts) > 1 else "other"
                    category = parts[2] if len(parts) > 2 else "uncategorized"
                elif platform == "windows" and len(parts) > 1:
                    domain = parts[1] if len(parts) > 1 else "other"
                    category = "windows"  # Windows audits use domain as category
                elif platform == "hypervisors" and len(parts) > 1:
                    domain = parts[1] if len(parts) > 1 else "other"
                    # Category exists only if there's a folder between type and file
                    category = parts[2] if len(parts) > 3 else domain
                else:
                    domain = platform
                    category = "uncategorized"

                name = script_path.stem
                script_type = "powershell" if file.endswith('.ps1') else "bash"

                audits.append({
                    "path": str(rel_path),
                    "platform": platform,
                    "domain": domain,
                    "category": category,
                    "name": name,
                    "display_name": name.replace("-", " ").replace("_", " ").title(),
                    "script_type": script_type
                })

        # Sort once
        audits.sort(key=lambda x: (x["domain"], x["category"], x["name"]))

        # Update cache
        self.cache["data"] = audits
        self.cache["timestamp"] = now

        logger.info(f"Discovered {len(audits)} audits")
        return audits

    def group_by_domain(self, audits):
        """Group audits by domain

        Args:
            audits: List of audit dictionaries

        Returns:
            dict: Dictionary of audits grouped by domain
        """
        domains = {}
        for audit in audits:
            domain = audit["domain"]
            if domain not in domains:
                domains[domain] = []
            domains[domain].append(audit)
        return domains

    def invalidate_cache(self):
        """Invalidate audit cache"""
        self.cache["data"] = None
        self.cache["timestamp"] = None
        logger.info("Audit cache invalidated")


# Backward-compatible ORM export for legacy imports
try:
    from .database import Audit
except Exception:
    Audit = None
