"""
Audit History Analytics Models

Supplementary tables for historical trend analysis and aggregated statistics.
The core audit_executions table stores raw execution data, while these
analytics tables provide pre-computed summaries for fast querying.

Key features:
- Daily/weekly/monthly aggregated statistics
- Server-level compliance scores over time
- Audit check-level trend tracking
- Efficient time-series queries

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import logging
from datetime import datetime, timedelta
from sqlalchemy import (
    Column, Integer, String, Text, Float, Boolean,
    DateTime, ForeignKey, Index, func, and_, or_
)
from sqlalchemy.orm import relationship
from models.database import Base, AuditExecution
import json

logger = logging.getLogger(__name__)


def _get_session_local():
    """Lazy getter for SessionLocal to avoid circular imports."""
    from config import SessionLocal
    return SessionLocal


class AuditHistorySummary(Base):
    """
    Daily aggregated audit statistics per server/audit combination

    Pre-computed daily summaries for fast trend analysis without scanning
    the entire audit_executions table. Updated automatically when new
    audits complete.
    """
    __tablename__ = 'audit_history_summaries'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign Keys
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'), nullable=False, index=True)
    audit_id = Column(Integer, ForeignKey('audits.id', ondelete='CASCADE'), nullable=False, index=True)

    # Time Dimension (date only, no time component for aggregation)
    date = Column(DateTime, nullable=False, index=True)  # Truncated to date

    # Aggregated Metrics
    total_runs = Column(Integer, nullable=False, default=0)
    successful_runs = Column(Integer, nullable=False, default=0)
    failed_runs = Column(Integer, nullable=False, default=0)

    # Check Statistics (from JSON summary)
    total_checks = Column(Integer, nullable=False, default=0)
    passed_checks = Column(Integer, nullable=False, default=0)
    warned_checks = Column(Integer, nullable=False, default=0)
    failed_checks = Column(Integer, nullable=False, default=0)
    skipped_checks = Column(Integer, nullable=False, default=0)

    # Performance Metrics
    avg_duration_seconds = Column(Float, nullable=True)
    min_duration_seconds = Column(Float, nullable=True)
    max_duration_seconds = Column(Float, nullable=True)

    # Compliance Score (0-100%, based on passed vs failed checks)
    compliance_score = Column(Float, nullable=True)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    server = relationship("Server", foreign_keys=[server_id])
    audit = relationship("Audit", foreign_keys=[audit_id])

    # Composite Indexes
    __table_args__ = (
        Index('idx_history_server_audit_date', 'server_id', 'audit_id', 'date'),
        Index('idx_history_date_compliance', 'date', 'compliance_score'),
        # Unique constraint: only one summary per server/audit/date
        Index('uq_history_server_audit_date', 'server_id', 'audit_id', 'date', unique=True),
    )

    def __repr__(self):
        return f"<AuditHistorySummary(server_id={self.server_id}, audit_id={self.audit_id}, date={self.date}, compliance={self.compliance_score:.1f}%)>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'server_id': self.server_id,
            'server_name': self.server.name if self.server else None,
            'audit_id': self.audit_id,
            'audit_name': self.audit.name if self.audit else None,
            'date': self.date.strftime('%Y-%m-%d'),
            'total_runs': self.total_runs,
            'successful_runs': self.successful_runs,
            'failed_runs': self.failed_runs,
            'total_checks': self.total_checks,
            'passed_checks': self.passed_checks,
            'warned_checks': self.warned_checks,
            'failed_checks': self.failed_checks,
            'skipped_checks': self.skipped_checks,
            'avg_duration_seconds': round(self.avg_duration_seconds, 2) if self.avg_duration_seconds else None,
            'min_duration_seconds': round(self.min_duration_seconds, 2) if self.min_duration_seconds else None,
            'max_duration_seconds': round(self.max_duration_seconds, 2) if self.max_duration_seconds else None,
            'compliance_score': round(self.compliance_score, 2) if self.compliance_score else None
        }


class ServerComplianceHistory(Base):
    """
    Server-wide compliance scores computed daily

    Aggregates all audit results for a server into a single daily
    compliance score for high-level trending.
    """
    __tablename__ = 'server_compliance_history'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign Key
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'), nullable=False, index=True)

    # Time Dimension
    date = Column(DateTime, nullable=False, index=True)

    # Aggregated Metrics
    total_audits_run = Column(Integer, nullable=False, default=0)
    total_checks = Column(Integer, nullable=False, default=0)
    passed_checks = Column(Integer, nullable=False, default=0)
    warned_checks = Column(Integer, nullable=False, default=0)
    failed_checks = Column(Integer, nullable=False, default=0)

    # Overall Compliance Score (0-100%)
    overall_compliance_score = Column(Float, nullable=False)

    # Security Posture Indicators
    critical_failures = Column(Integer, nullable=False, default=0)  # Failed checks from critical audits
    high_warnings = Column(Integer, nullable=False, default=0)  # Warnings from high-priority audits

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    server = relationship("Server", foreign_keys=[server_id])

    # Indexes
    __table_args__ = (
        Index('idx_server_compliance_date', 'server_id', 'date'),
        Index('uq_server_compliance_date', 'server_id', 'date', unique=True),
    )

    def __repr__(self):
        return f"<ServerComplianceHistory(server_id={self.server_id}, date={self.date}, score={self.overall_compliance_score:.1f}%)>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'server_id': self.server_id,
            'server_name': self.server.name if self.server else None,
            'date': self.date.strftime('%Y-%m-%d'),
            'total_audits_run': self.total_audits_run,
            'total_checks': self.total_checks,
            'passed_checks': self.passed_checks,
            'warned_checks': self.warned_checks,
            'failed_checks': self.failed_checks,
            'overall_compliance_score': round(self.overall_compliance_score, 2),
            'critical_failures': self.critical_failures,
            'high_warnings': self.high_warnings
        }


# Helper Functions for History Management

def compute_compliance_score(passed, warned, failed, skipped=0):
    """
    Calculate compliance score as percentage

    Formula: (passed + warned) / (passed + warned + failed) * 100
    Skipped checks are not counted in the score.

    Args:
        passed: Number of passed checks
        warned: Number of warned checks
        failed: Number of failed checks
        skipped: Number of skipped checks (not counted)

    Returns:
        float: Compliance score (0-100)
    """
    total_counted = passed + warned + failed
    if total_counted == 0:
        return 100.0  # No checks = 100% compliant by default

    # Pass and warn are both acceptable (not failures)
    acceptable = passed + warned
    return (acceptable / total_counted) * 100.0


def aggregate_daily_summaries(db, target_date=None):
    """
    Aggregate audit executions into daily summaries

    Processes all executions from target_date and creates/updates
    AuditHistorySummary records. Should be run daily via scheduler.

    Args:
        db: SQLAlchemy session
        target_date: Date to aggregate (defaults to yesterday)

    Returns:
        int: Number of summaries created/updated
    """
    if target_date is None:
        target_date = datetime.utcnow().date() - timedelta(days=1)
    else:
        if isinstance(target_date, datetime):
            target_date = target_date.date()

    logger.info(f"Aggregating daily summaries for {target_date}")

    # Get all executions from target date
    start_of_day = datetime.combine(target_date, datetime.min.time())
    end_of_day = datetime.combine(target_date, datetime.max.time())

    # Process executions in batches for memory efficiency
    BATCH_SIZE = 1000
    offset = 0
    summaries_data = {}

    while True:
        executions = db.query(AuditExecution).filter(
            and_(
                AuditExecution.executed_at >= start_of_day,
                AuditExecution.executed_at <= end_of_day,
                AuditExecution.status != 'running'
            )
        ).limit(BATCH_SIZE).offset(offset).all()

        if not executions:
            break

        for execution in executions:
            key = (execution.server_id, execution.audit_id)

            if key not in summaries_data:
                summaries_data[key] = {
                    'server_id': execution.server_id,
                    'audit_id': execution.audit_id,
                    'date': start_of_day,
                    'total_runs': 0,
                    'successful_runs': 0,
                    'failed_runs': 0,
                    'total_checks': 0,
                    'passed_checks': 0,
                    'warned_checks': 0,
                    'failed_checks': 0,
                    'skipped_checks': 0,
                    'durations': []
                }

            summary_data = summaries_data[key]
            summary_data['total_runs'] += 1

            if execution.status == 'success':
                summary_data['successful_runs'] += 1
            elif execution.status in ('failure', 'timeout', 'error'):
                summary_data['failed_runs'] += 1

            # Parse JSON summary
            if execution.summary:
                try:
                    checks = json.loads(execution.summary)
                    summary_data['passed_checks'] += checks.get('pass', 0)
                    summary_data['warned_checks'] += checks.get('warn', 0)
                    summary_data['failed_checks'] += checks.get('fail', 0)
                    summary_data['skipped_checks'] += checks.get('skip', 0)
                    summary_data['total_checks'] += checks.get('total', 0)
                except json.JSONDecodeError:
                    logger.warning(f"Failed to parse summary for execution {execution.id}")

            if execution.duration_seconds is not None:
                summary_data['durations'].append(execution.duration_seconds)

        offset += BATCH_SIZE

    # Create or update summary records
    count = 0
    for key, data in summaries_data.items():
        # Calculate stats
        durations = data.pop('durations')
        if durations:
            data['avg_duration_seconds'] = sum(durations) / len(durations)
            data['min_duration_seconds'] = min(durations)
            data['max_duration_seconds'] = max(durations)

        # Calculate compliance score
        data['compliance_score'] = compute_compliance_score(
            data['passed_checks'],
            data['warned_checks'],
            data['failed_checks'],
            data['skipped_checks']
        )

        # Check if summary already exists
        existing = db.query(AuditHistorySummary).filter(
            and_(
                AuditHistorySummary.server_id == data['server_id'],
                AuditHistorySummary.audit_id == data['audit_id'],
                AuditHistorySummary.date == data['date']
            )
        ).first()

        if existing:
            # Update existing
            for key, value in data.items():
                setattr(existing, key, value)
            existing.updated_at = datetime.utcnow()
        else:
            # Create new
            summary = AuditHistorySummary(**data)
            db.add(summary)

        count += 1

    db.commit()
    logger.info(f"Aggregated {count} daily summaries for {target_date}")
    return count


def aggregate_server_compliance(db, target_date=None):
    """
    Aggregate server-wide compliance scores

    Rolls up all audit summaries for each server into a single
    daily compliance score.

    Args:
        db: SQLAlchemy session
        target_date: Date to aggregate (defaults to yesterday)

    Returns:
        int: Number of server compliance records created/updated
    """
    if target_date is None:
        target_date = datetime.utcnow().date() - timedelta(days=1)
    else:
        if isinstance(target_date, datetime):
            target_date = target_date.date()

    logger.info(f"Aggregating server compliance for {target_date}")

    start_of_day = datetime.combine(target_date, datetime.min.time())

    # Get all summaries for target date
    summaries = db.query(AuditHistorySummary).filter(
        AuditHistorySummary.date == start_of_day
    ).all()

    # Group by server_id
    server_data = {}

    for summary in summaries:
        if summary.server_id not in server_data:
            server_data[summary.server_id] = {
                'server_id': summary.server_id,
                'date': start_of_day,
                'total_audits_run': 0,
                'total_checks': 0,
                'passed_checks': 0,
                'warned_checks': 0,
                'failed_checks': 0,
                'critical_failures': 0,
                'high_warnings': 0
            }

        data = server_data[summary.server_id]
        data['total_audits_run'] += summary.total_runs
        data['total_checks'] += summary.total_checks
        data['passed_checks'] += summary.passed_checks
        data['warned_checks'] += summary.warned_checks
        data['failed_checks'] += summary.failed_checks

        # Count critical failures (audits with >50% failed checks)
        if summary.total_checks > 0:
            fail_rate = (summary.failed_checks / summary.total_checks) * 100
            if fail_rate > 50:
                data['critical_failures'] += summary.failed_checks
            elif fail_rate > 25:
                data['high_warnings'] += summary.warned_checks

    # Create or update server compliance records
    count = 0
    for server_id, data in server_data.items():
        # Calculate overall compliance score
        data['overall_compliance_score'] = compute_compliance_score(
            data['passed_checks'],
            data['warned_checks'],
            data['failed_checks']
        )

        # Check if record exists
        existing = db.query(ServerComplianceHistory).filter(
            and_(
                ServerComplianceHistory.server_id == server_id,
                ServerComplianceHistory.date == start_of_day
            )
        ).first()

        if existing:
            # Update existing
            for key, value in data.items():
                setattr(existing, key, value)
            existing.updated_at = datetime.utcnow()
        else:
            # Create new
            record = ServerComplianceHistory(**data)
            db.add(record)

        count += 1

    db.commit()
    logger.info(f"Aggregated {count} server compliance records for {target_date}")
    return count


__all__ = [
    'AuditHistorySummary',
    'ServerComplianceHistory',
    'compute_compliance_score',
    'aggregate_daily_summaries',
    'aggregate_server_compliance'
]
