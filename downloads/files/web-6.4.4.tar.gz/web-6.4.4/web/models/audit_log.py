"""
Audit logging model - immutable audit trail for sensitive operations.

Implements NIST SP 800-92 audit logging requirements:
- WHO (user_id)
- WHAT (action, resource_id, resource_type)
- WHEN (timestamp with microseconds)
- WHERE (ip_address)
- WHETHER (success/failure + error)
- WHY (details JSON for context)
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, JSON, Index
from .database import Base
from .encrypted_field import EncryptedField


class AuditLog(Base):
    """
    Immutable audit trail of all sensitive operations.

    Each entry records:
    - WHO: user_id (or None for API calls)
    - WHAT: action (e.g., 'export_discovery', 'delete_all_data')
    - WHEN: timestamp (UTC, indexed for range queries)
    - WHERE: ip_address, user_agent
    - WHETHER: success flag + error message if failed
    - WHY: details JSON (role, team, format, etc.)

    Never delete from this table - it's the audit trail.
    Regularly export to external syslog/SIEM for immutability.
    """

    __tablename__ = 'audit_log'

    # =====================================================================
    # Core Fields
    # =====================================================================

    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    user_id = Column(Integer, index=True, nullable=True)  # None for API/system actions

    # =====================================================================
    # What Happened (Action & Resource)
    # =====================================================================

    action = Column(String(100), index=True, nullable=False)
    """
    Action type. Examples:
    - view_discovery
    - export_discovery
    - delete_all_data
    - manage_roles
    - regenerate_api_keys
    - create_schedule
    - modify_configuration
    """

    resource_id = Column(String(100), index=True, nullable=True)
    """
    What was affected. Examples:
    - discovery_id (UUID)
    - 'all' (for bulk operations)
    - user_id (for member changes)
    - schedule_id
    """

    resource_type = Column(String(50), nullable=False)
    """
    Type of resource. Examples:
    - discovery_data
    - audit_result
    - user_account
    - api_key
    - configuration
    - team_membership
    """

    # =====================================================================
    # Where It Happened (Request Context)
    # =====================================================================

    ip_address = Column(String(50), nullable=True)
    """Source IP address (for geographic analysis, detecting anomalies)"""

    user_agent = Column(String(500), nullable=True)
    """Browser/API client info (first 500 chars)"""

    # =====================================================================
    # Whether It Succeeded
    # =====================================================================

    success = Column(Boolean, default=True, index=True)
    """Did the operation succeed? (True/False)"""

    error_message = Column(EncryptedField(), nullable=True)
    """If failed, what was the error? (e.g., 'User not found', 'Permission denied')"""

    # =====================================================================
    # Why It Happened (Context Details)
    # =====================================================================

    details = Column(JSON, default={})
    """
    Extra context as JSON. Examples:
    {
        "role": "Admin",
        "team": "Security",
        "format": "csv",
        "row_count": 1250,
        "duration_ms": 523,
        "api_key_id": "key_abc123"
    }
    """

    # =====================================================================
    # Indexes for Forensic Queries
    # =====================================================================

    __table_args__ = (
        # Query by "what did user X do on date Y?"
        Index('idx_audit_user_timestamp', 'user_id', 'timestamp'),
        # Query by "who did action X?"
        Index('idx_audit_action_timestamp', 'action', 'timestamp'),
        # Query by "what resources were affected?"
        Index('idx_audit_resource', 'resource_type', 'resource_id'),
        # Query by "which operations failed?"
        Index('idx_audit_failures', 'success', 'timestamp'),
    )

    def to_dict(self):
        """Convert to dictionary for JSON responses"""
        return {
            'id': self.id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'user_id': self.user_id,
            'action': self.action,
            'resource_id': self.resource_id,
            'resource_type': self.resource_type,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'success': self.success,
            'error_message': self.error_message,
            'details': self.details,
        }

    def __repr__(self):
        status = "✓" if self.success else "✗"
        return (
            f"<AuditLog {self.id}: {status} {self.action} "
            f"({self.resource_type}:{self.resource_id}) "
            f"user={self.user_id} @{self.timestamp}>"
        )
