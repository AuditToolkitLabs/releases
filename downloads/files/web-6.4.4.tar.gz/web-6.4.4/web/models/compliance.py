"""
SQLAlchemy Models for Compliance Dashboard & Tracking

Database schema for tracking compliance status across frameworks:
- compliance_assessments: Point-in-time compliance snapshots
- compliance_controls: Individual control status tracking
- compliance_trends: Historical compliance score data

Author: Security Audit Toolkit Team
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, Float, Boolean,
    DateTime, ForeignKey, Index
)
from sqlalchemy.orm import relationship

from .database import Base
from .encrypted_field import EncryptedField


class ComplianceAssessment(Base):
    """
    Point-in-time compliance assessment for a framework/server combination.

    Stores the overall compliance score and metadata for a specific audit run.
    """
    __tablename__ = 'compliance_assessments'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Assessment scope
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'), nullable=True, index=True)
    server_group_id = Column(Integer, ForeignKey('server_groups.id', ondelete='CASCADE', use_alter=True, name='fk_compliance_server_group'), nullable=True, index=True)

    # Linked execution (if from audit run)
    execution_id = Column(Integer, ForeignKey('audit_executions.id', ondelete='SET NULL'), nullable=True)

    # Framework identification
    framework = Column(String(50), nullable=False, index=True)  # PCI-DSS, SOC2, ISO27001, etc.
    framework_version = Column(String(20), nullable=True)  # 4.0, Type II, 2022

    # Overall scores
    compliance_score = Column(Float, nullable=False, default=0.0)  # 0-100 percentage
    total_controls = Column(Integer, nullable=False, default=0)
    satisfied_controls = Column(Integer, nullable=False, default=0)
    partial_controls = Column(Integer, nullable=False, default=0)
    failed_controls = Column(Integer, nullable=False, default=0)
    unknown_controls = Column(Integer, nullable=False, default=0)

    # Assessment metadata
    assessed_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    assessed_by = Column(String(100), nullable=True)
    notes = Column(EncryptedField(), nullable=True)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    # Relationships
    server = relationship("Server", backref="compliance_assessments")
    execution = relationship("AuditExecution", backref="compliance_assessments")
    controls = relationship("ComplianceControl", back_populates="assessment", cascade="all, delete-orphan")

    # Indexes
    __table_args__ = (
        Index('idx_assessment_server_framework', 'server_id', 'framework', 'assessed_at'),
        Index('idx_assessment_score', 'compliance_score', 'framework'),
    )

    def __repr__(self):
        return f"<ComplianceAssessment(id={self.id}, framework='{self.framework}', score={self.compliance_score})>"

    @property
    def status(self) -> str:
        """Get overall compliance status based on score"""
        if self.compliance_score >= 90:
            return "compliant"
        elif self.compliance_score >= 70:
            return "partial"
        elif self.compliance_score >= 50:
            return "at_risk"
        else:
            return "non_compliant"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'server_id': self.server_id,
            'server_name': self.server.name if self.server else None,
            'server_group_id': self.server_group_id,
            'execution_id': self.execution_id,
            'framework': self.framework,
            'framework_version': self.framework_version,
            'compliance_score': round(self.compliance_score, 1),
            'status': self.status,
            'controls': {
                'total': self.total_controls,
                'satisfied': self.satisfied_controls,
                'partial': self.partial_controls,
                'failed': self.failed_controls,
                'unknown': self.unknown_controls
            },
            'assessed_at': self.assessed_at.isoformat() if self.assessed_at else None,
            'assessed_by': self.assessed_by,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class ComplianceControl(Base):
    """
    Individual compliance control status within an assessment.

    Tracks the status of each control requirement.
    """
    __tablename__ = 'compliance_controls'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign Key to assessment
    assessment_id = Column(Integer, ForeignKey('compliance_assessments.id', ondelete='CASCADE'), nullable=False, index=True)

    # Control identification
    control_id = Column(String(50), nullable=False)  # e.g., "1.3.1", "CC6.1"
    control_name = Column(String(255), nullable=False)
    control_category = Column(String(255), nullable=True)  # e.g., "Requirement 1: Network Security"
    control_description = Column(EncryptedField(), nullable=True)

    # Status
    status = Column(String(20), nullable=False, index=True)  # satisfied, partial, failed, unknown
    evidence = Column(EncryptedField(), nullable=True)  # Description of evidence

    # Linked audit checks
    audit_checks = Column(EncryptedField(), nullable=True)  # JSON array of check names
    passing_checks = Column(Integer, nullable=False, default=0)
    failing_checks = Column(Integer, nullable=False, default=0)

    # Remediation link
    remediation_item_id = Column(Integer, ForeignKey('remediation_items.id', ondelete='SET NULL'), nullable=True)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    # Relationships
    assessment = relationship("ComplianceAssessment", back_populates="controls")

    # Indexes
    __table_args__ = (
        Index('idx_control_assessment_id', 'assessment_id', 'control_id'),
        Index('idx_control_status', 'status'),
    )

    def __repr__(self):
        return f"<ComplianceControl(id={self.id}, control_id='{self.control_id}', status='{self.status}')>"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        import json
        return {
            'id': self.id,
            'assessment_id': self.assessment_id,
            'control_id': self.control_id,
            'control_name': self.control_name,
            'control_category': self.control_category,
            'control_description': self.control_description,
            'status': self.status,
            'evidence': self.evidence,
            'audit_checks': json.loads(self.audit_checks) if self.audit_checks else [],
            'passing_checks': self.passing_checks,
            'failing_checks': self.failing_checks,
            'remediation_item_id': self.remediation_item_id,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class ComplianceTrend(Base):
    """
    Historical compliance score tracking for trend analysis.

    Stores daily/weekly compliance snapshots for charting.
    """
    __tablename__ = 'compliance_trends'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Scope
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'), nullable=True, index=True)
    server_group_id = Column(Integer, ForeignKey('server_groups.id', ondelete='CASCADE', use_alter=True, name='fk_trend_server_group'), nullable=True, index=True)
    scope = Column(String(20), nullable=False, default='server')  # server, group, organization

    # Framework
    framework = Column(String(50), nullable=False, index=True)

    # Trend data point
    recorded_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    compliance_score = Column(Float, nullable=False)

    # Control counts at this point
    total_controls = Column(Integer, nullable=False, default=0)
    satisfied_controls = Column(Integer, nullable=False, default=0)
    failed_controls = Column(Integer, nullable=False, default=0)

    # Source assessment
    assessment_id = Column(Integer, ForeignKey('compliance_assessments.id', ondelete='SET NULL'), nullable=True)

    # Relationships
    server = relationship("Server", backref="compliance_trends")
    assessment = relationship("ComplianceAssessment", backref="trend_points")

    # Indexes
    __table_args__ = (
        Index('idx_trend_scope_framework', 'scope', 'framework', 'recorded_at'),
        Index('idx_trend_server_time', 'server_id', 'framework', 'recorded_at'),
    )

    def __repr__(self):
        return f"<ComplianceTrend(id={self.id}, framework='{self.framework}', score={self.compliance_score})>"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'server_id': self.server_id,
            'server_name': self.server.name if self.server else None,
            'server_group_id': self.server_group_id,
            'scope': self.scope,
            'framework': self.framework,
            'recorded_at': self.recorded_at.isoformat() if self.recorded_at else None,
            'compliance_score': round(self.compliance_score, 1),
            'controls': {
                'total': self.total_controls,
                'satisfied': self.satisfied_controls,
                'failed': self.failed_controls
            },
            'assessment_id': self.assessment_id
        }


class ComplianceFrameworkConfig(Base):
    """
    Configuration for compliance frameworks including custom control mappings.

    Allows customization of which audit checks map to which controls.
    """
    __tablename__ = 'compliance_framework_configs'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Framework identification
    framework = Column(String(50), nullable=False, unique=True, index=True)
    display_name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    version = Column(String(20), nullable=True)

    # Configuration
    control_mappings = Column(EncryptedField(), nullable=True)  # JSON: custom mappings
    enabled = Column(Boolean, nullable=False, default=True)

    # Thresholds
    compliant_threshold = Column(Float, nullable=False, default=90.0)  # >= this = compliant
    partial_threshold = Column(Float, nullable=False, default=70.0)    # >= this = partial
    at_risk_threshold = Column(Float, nullable=False, default=50.0)   # >= this = at_risk

    # Metadata
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(String(100), nullable=True)

    def __repr__(self):
        return f"<ComplianceFrameworkConfig(framework='{self.framework}', enabled={self.enabled})>"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        import json
        return {
            'id': self.id,
            'framework': self.framework,
            'display_name': self.display_name,
            'description': self.description,
            'version': self.version,
            'control_mappings': json.loads(self.control_mappings) if self.control_mappings else None,
            'enabled': self.enabled,
            'thresholds': {
                'compliant': self.compliant_threshold,
                'partial': self.partial_threshold,
                'at_risk': self.at_risk_threshold
            },
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
