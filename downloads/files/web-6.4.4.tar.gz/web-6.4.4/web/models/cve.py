"""
CVE Database Models - Vulnerability Intelligence

Stores CVE records, CPE matches, and configuration settings.
Supports both live NVD API queries and offline local database.

Author: Security Audit Toolkit Team
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, Text, DateTime, ForeignKey, JSON
from sqlalchemy.orm import relationship

from .encrypted_field import EncryptedField

# Import base from existing models
try:
    from models.database import db, Base
except ImportError:
    from flask_sqlalchemy import SQLAlchemy
    db = SQLAlchemy()
    Base = db.Model


class CVERecord(Base):
    """
    Individual CVE vulnerability record from NVD.

    Contains CVSS scores, descriptions, and metadata.
    """
    __tablename__ = 'cve_records'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    cve_id = Column(String(20), unique=True, nullable=False, index=True)  # CVE-2024-12345

    # Description
    description = Column(Text)

    # Dates
    published_date = Column(DateTime)
    last_modified = Column(DateTime)

    # CVSS v3.1 scores
    cvss_v3_score = Column(Float)  # 0.0 - 10.0
    cvss_v3_severity = Column(String(20))  # CRITICAL, HIGH, MEDIUM, LOW, NONE
    cvss_v3_vector = Column(String(100))  # CVSS:3.1/AV:N/AC:L/...
    exploitability_score = Column(Float)
    impact_score = Column(Float)

    # CVSS v2 (legacy, still useful)
    cvss_v2_score = Column(Float)
    cvss_v2_severity = Column(String(20))

    # Additional metadata
    cwe_ids = Column(JSON)  # List of CWE IDs
    references = Column(JSON)  # List of reference URLs

    # Sync tracking
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    cpe_matches = relationship('CPEMatch', back_populates='cve', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<CVERecord {self.cve_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'cve_id': self.cve_id,
            'description': self.description,
            'published_date': self.published_date.isoformat() if self.published_date else None,
            'last_modified': self.last_modified.isoformat() if self.last_modified else None,
            'cvss_v3': {
                'score': self.cvss_v3_score,
                'severity': self.cvss_v3_severity,
                'vector': self.cvss_v3_vector,
                'exploitability_score': self.exploitability_score,
                'impact_score': self.impact_score
            } if self.cvss_v3_score else None,
            'cvss_v2': {
                'score': self.cvss_v2_score,
                'severity': self.cvss_v2_severity
            } if self.cvss_v2_score else None,
            'cwe_ids': self.cwe_ids or [],
            'references': self.references or []
        }

    @property
    def severity(self):
        """Get severity from v3 or fallback to v2"""
        return self.cvss_v3_severity or self.cvss_v2_severity or 'UNKNOWN'

    @property
    def score(self):
        """Get score from v3 or fallback to v2"""
        return self.cvss_v3_score or self.cvss_v2_score or 0.0


class CPEMatch(Base):
    """
    CPE (Common Platform Enumeration) match record.

    Links CVEs to affected software products and versions.
    """
    __tablename__ = 'cpe_matches'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    cve_id = Column(String(20), ForeignKey('cve_records.cve_id', ondelete='CASCADE'), nullable=False, index=True)

    # Full CPE 2.3 string
    cpe23 = Column(String(255), index=True)  # cpe:2.3:a:apache:http_server:2.4.49:*:*:*:*:*:*:*

    # Parsed components for faster matching
    vendor = Column(String(100), index=True)  # apache
    product = Column(String(100), index=True)  # http_server

    # Version range
    version = Column(String(50))  # Exact version if specified
    version_start = Column(String(50))
    version_start_type = Column(String(20))  # including / excluding
    version_end = Column(String(50))
    version_end_type = Column(String(20))  # including / excluding

    # Vulnerability indicator
    vulnerable = Column(Boolean, default=True)

    # Relationships
    cve = relationship('CVERecord', back_populates='cpe_matches')

    def __repr__(self):
        return f'<CPEMatch {self.vendor}:{self.product} for {self.cve_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'cve_id': self.cve_id,
            'cpe23': self.cpe23,
            'vendor': self.vendor,
            'product': self.product,
            'version': self.version,
            'version_range': {
                'start': self.version_start,
                'start_type': self.version_start_type,
                'end': self.version_end,
                'end_type': self.version_end_type
            } if self.version_start or self.version_end else None,
            'vulnerable': self.vulnerable
        }


class PackageCPEMap(Base):
    """
    Maps distro-specific package names to CPE vendor/product.

    Example: 'httpd' (RHEL) → apache:http_server
             'apache2' (Debian) → apache:http_server
    """
    __tablename__ = 'package_cpe_map'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    package_name = Column(String(100), nullable=False, index=True)  # httpd, apache2
    distro = Column(String(50), nullable=False, index=True)  # rhel, ubuntu, debian, alpine

    # CPE mapping
    cpe_vendor = Column(String(100), nullable=False)  # apache
    cpe_product = Column(String(100), nullable=False)  # http_server

    # Optional notes
    notes = Column(String(255))

    # Tracking
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<PackageCPEMap {self.package_name}@{self.distro} → {self.cpe_vendor}:{self.cpe_product}>'

    def to_dict(self):
        return {
            'id': self.id,
            'package_name': self.package_name,
            'distro': self.distro,
            'cpe_vendor': self.cpe_vendor,
            'cpe_product': self.cpe_product,
            'notes': self.notes
        }


class CVESettings(Base):
    """
    CVE integration settings - admin-controlled configuration.

    Controls whether CVE features are enabled, sync schedules,
    and operational parameters.
    """
    __tablename__ = 'cve_settings'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)

    # Feature toggle - MAIN ON/OFF SWITCH
    enabled = Column(Boolean, default=False, nullable=False)

    # NVD API configuration
    nvd_api_key = Column(EncryptedField(length=1024))  # Encrypted at rest
    nvd_rate_limit = Column(Integer, default=5)  # Requests per 30 seconds (5 without key, 50 with)

    # Sync configuration
    auto_sync_enabled = Column(Boolean, default=False)
    sync_schedule_cron = Column(String(50), default='0 3 * * *')  # Daily at 3 AM
    last_sync_at = Column(DateTime)
    last_sync_status = Column(String(20))  # success, failed, in_progress
    last_sync_message = Column(Text)
    last_sync_cve_count = Column(Integer, default=0)

    # Offline mode settings
    offline_mode = Column(Boolean, default=False)
    offline_data_path = Column(String(255))
    offline_last_import = Column(DateTime)

    # Alert thresholds
    alert_on_critical = Column(Boolean, default=True)
    alert_on_high = Column(Boolean, default=True)
    critical_threshold = Column(Float, default=9.0)  # CVSS >= 9.0
    high_threshold = Column(Float, default=7.0)  # CVSS >= 7.0

    # Data retention
    max_cve_age_days = Column(Integer, default=365 * 5)  # 5 years
    purge_old_cves = Column(Boolean, default=False)

    # Tracking
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = Column(String(100))

    def __repr__(self):
        return f'<CVESettings enabled={self.enabled}>'

    def to_dict(self):
        return {
            'id': self.id,
            'enabled': self.enabled,
            'nvd_api_key_set': bool(self.nvd_api_key),  # Don't expose actual key
            'nvd_rate_limit': self.nvd_rate_limit,
            'auto_sync': {
                'enabled': self.auto_sync_enabled,
                'schedule': self.sync_schedule_cron,
                'last_sync': self.last_sync_at.isoformat() if self.last_sync_at else None,
                'last_status': self.last_sync_status,
                'last_message': self.last_sync_message,
                'last_cve_count': self.last_sync_cve_count
            },
            'offline_mode': {
                'enabled': self.offline_mode,
                'data_path': self.offline_data_path,
                'last_import': self.offline_last_import.isoformat() if self.offline_last_import else None
            },
            'alerts': {
                'on_critical': self.alert_on_critical,
                'on_high': self.alert_on_high,
                'critical_threshold': self.critical_threshold,
                'high_threshold': self.high_threshold
            },
            'data_retention': {
                'max_age_days': self.max_cve_age_days,
                'purge_enabled': self.purge_old_cves
            },
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'updated_by': self.updated_by
        }


class CVESyncLog(Base):
    """
    Log of CVE sync operations.

    Tracks sync history for auditing and troubleshooting.
    """
    __tablename__ = 'cve_sync_logs'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)

    # Sync operation details
    sync_type = Column(String(20), nullable=False)  # full, delta, manual, import
    started_at = Column(DateTime, default=datetime.utcnow,  nullable=False)
    completed_at = Column(DateTime)

    # Results
    status = Column(String(20), nullable=False)  # in_progress, success, failed, cancelled
    message = Column(Text)

    # Statistics
    cves_added = Column(Integer, default=0)
    cves_updated = Column(Integer, default=0)
    cves_deleted = Column(Integer, default=0)
    api_calls_made = Column(Integer, default=0)

    # Error tracking
    error_count = Column(Integer, default=0)
    errors = Column(JSON)  # List of error messages

    # Who triggered it
    triggered_by = Column(String(100))  # system, admin email, scheduler

    def __repr__(self):
        return f'<CVESyncLog {self.sync_type} {self.status} at {self.started_at}>'

    def to_dict(self):
        return {
            'id': self.id,
            'sync_type': self.sync_type,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'duration_seconds': (self.completed_at - self.started_at).total_seconds() if self.completed_at and self.started_at else None,
            'status': self.status,
            'message': self.message,
            'statistics': {
                'added': self.cves_added,
                'updated': self.cves_updated,
                'deleted': self.cves_deleted,
                'api_calls': self.api_calls_made
            },
            'errors': {
                'count': self.error_count,
                'messages': self.errors or []
            },
            'triggered_by': self.triggered_by
        }


class ServerCVESummary(Base):
    """
    Cached CVE summary per server.

    Updated after each audit execution to show vulnerability counts.
    """
    __tablename__ = 'server_cve_summaries'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'), nullable=False, index=True)
    execution_id = Column(Integer, ForeignKey('audit_executions.id', ondelete='SET NULL'))

    # Counts by severity
    critical_count = Column(Integer, default=0)
    high_count = Column(Integer, default=0)
    medium_count = Column(Integer, default=0)
    low_count = Column(Integer, default=0)

    # Totals
    total_cves = Column(Integer, default=0)
    total_packages = Column(Integer, default=0)
    packages_with_cves = Column(Integer, default=0)

    # Most critical CVE
    most_critical_cve = Column(String(20))
    most_critical_score = Column(Float)

    # Timestamps
    scanned_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<ServerCVESummary server={self.server_id} critical={self.critical_count}>'

    def to_dict(self):
        return {
            'id': self.id,
            'server_id': self.server_id,
            'execution_id': self.execution_id,
            'severity_counts': {
                'critical': self.critical_count,
                'high': self.high_count,
                'medium': self.medium_count,
                'low': self.low_count
            },
            'totals': {
                'cves': self.total_cves,
                'packages': self.total_packages,
                'vulnerable_packages': self.packages_with_cves
            },
            'most_critical': {
                'cve_id': self.most_critical_cve,
                'score': self.most_critical_score
            } if self.most_critical_cve else None,
            'scanned_at': self.scanned_at.isoformat() if self.scanned_at else None
        }
