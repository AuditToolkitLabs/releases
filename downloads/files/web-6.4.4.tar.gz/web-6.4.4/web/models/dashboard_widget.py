#!/usr/bin/env python3
"""
Dashboard Widget Models

Provides customizable dashboard widget functionality:
- Widget type definitions with configurations
- User-specific dashboard layouts
- Widget data source bindings
- Threshold-based alerting

Author: Security Audit Toolkit Team
Date: February 10, 2026
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from models.database import Base
import json


# ============================================================================
# Widget Type Registry
# ============================================================================

WIDGET_TYPES = {
    'stat_card': {
        'name': 'Statistics Card',
        'description': 'Single metric with icon and trend',
        'icon': 'chart-bar',
        'default_size': {'w': 1, 'h': 1},
        'config_schema': {
            'metric': {'type': 'string', 'required': True, 'options': [
                'total_servers', 'total_audits', 'pass_rate', 'fail_count',
                'warn_count', 'active_schedules', 'pending_tasks'
            ]},
            'title': {'type': 'string', 'required': False},
            'icon': {'type': 'string', 'required': False},
            'color': {'type': 'string', 'required': False}
        }
    },
    'server_group_status': {
        'name': 'Server Group Status',
        'description': 'Health status for a server group',
        'icon': 'server',
        'default_size': {'w': 2, 'h': 1},
        'config_schema': {
            'group_id': {'type': 'integer', 'required': True},
            'show_servers': {'type': 'boolean', 'required': False, 'default': False},
            'days': {'type': 'integer', 'required': False, 'default': 7}
        }
    },
    'compliance_gauge': {
        'name': 'Compliance Gauge',
        'description': 'Circular gauge showing compliance percentage',
        'icon': 'shield-check',
        'default_size': {'w': 1, 'h': 1},
        'config_schema': {
            'framework': {'type': 'string', 'required': False, 'options': [
                'overall', 'cis', 'pci-dss', 'soc2', 'hipaa', 'nist'
            ]},
            'threshold_warning': {'type': 'integer', 'required': False, 'default': 80},
            'threshold_critical': {'type': 'integer', 'required': False, 'default': 60}
        }
    },
    'trend_chart': {
        'name': 'Trend Chart',
        'description': 'Line chart showing metrics over time',
        'icon': 'trending-up',
        'default_size': {'w': 2, 'h': 2},
        'config_schema': {
            'metrics': {'type': 'array', 'required': True, 'options': [
                'pass_count', 'warn_count', 'fail_count', 'execution_count'
            ]},
            'days': {'type': 'integer', 'required': False, 'default': 7},
            'chart_type': {'type': 'string', 'required': False, 'options': ['line', 'bar', 'area']}
        }
    },
    'recent_executions': {
        'name': 'Recent Executions',
        'description': 'Table of recent audit executions',
        'icon': 'clock',
        'default_size': {'w': 2, 'h': 2},
        'config_schema': {
            'limit': {'type': 'integer', 'required': False, 'default': 10},
            'server_id': {'type': 'integer', 'required': False},
            'group_id': {'type': 'integer', 'required': False},
            'status_filter': {'type': 'string', 'required': False, 'options': ['all', 'pass', 'warn', 'fail']}
        }
    },
    'top_risks': {
        'name': 'Top Risks',
        'description': 'List of highest severity findings',
        'icon': 'alert-triangle',
        'default_size': {'w': 1, 'h': 2},
        'config_schema': {
            'limit': {'type': 'integer', 'required': False, 'default': 5},
            'severity': {'type': 'string', 'required': False, 'options': ['all', 'critical', 'high', 'medium']}
        }
    },
    'domain_breakdown': {
        'name': 'Domain Breakdown',
        'description': 'Pie chart of audits by domain',
        'icon': 'pie-chart',
        'default_size': {'w': 1, 'h': 2},
        'config_schema': {
            'show_legend': {'type': 'boolean', 'required': False, 'default': True},
            'metric': {'type': 'string', 'required': False, 'options': ['audits', 'executions', 'failures']}
        }
    },
    'schedule_timeline': {
        'name': 'Schedule Timeline',
        'description': 'Visual timeline of upcoming scheduled audits',
        'icon': 'calendar',
        'default_size': {'w': 2, 'h': 1},
        'config_schema': {
            'hours_ahead': {'type': 'integer', 'required': False, 'default': 24},
            'show_maintenance': {'type': 'boolean', 'required': False, 'default': True}
        }
    },
    'maintenance_window': {
        'name': 'Maintenance Windows',
        'description': 'Current and upcoming maintenance windows',
        'icon': 'tool',
        'default_size': {'w': 1, 'h': 1},
        'config_schema': {
            'show_past': {'type': 'boolean', 'required': False, 'default': False},
            'days_ahead': {'type': 'integer', 'required': False, 'default': 7}
        }
    },
    'execution_queue': {
        'name': 'Execution Queue',
        'description': 'Running and pending audit tasks',
        'icon': 'activity',
        'default_size': {'w': 2, 'h': 1},
        'config_schema': {
            'show_completed': {'type': 'boolean', 'required': False, 'default': False},
            'limit': {'type': 'integer', 'required': False, 'default': 10}
        }
    },
    'server_health_map': {
        'name': 'Server Health Map',
        'description': 'Grid showing pass/fail status of each server',
        'icon': 'grid',
        'default_size': {'w': 2, 'h': 2},
        'config_schema': {
            'group_id': {'type': 'integer', 'required': False},
            'sort_by': {'type': 'string', 'required': False, 'options': ['name', 'status', 'last_audit']}
        }
    },
    'critical_findings': {
        'name': 'Critical Findings Counter',
        'description': 'Count of critical severity findings with alert',
        'icon': 'alert-octagon',
        'default_size': {'w': 1, 'h': 1},
        'config_schema': {
            'severity_levels': {'type': 'array', 'required': False, 'default': ['critical', 'high']},
            'alert_threshold': {'type': 'integer', 'required': False, 'default': 1}
        }
    },
    'storage_pressure': {
        'name': 'Storage Pressure',
        'description': 'Retention usage and storage pressure overview',
        'icon': 'hard-drive',
        'default_size': {'w': 2, 'h': 1},
        'config_schema': {
            'show_hosts': {'type': 'boolean', 'required': False, 'default': True},
            'top_hosts_limit': {'type': 'integer', 'required': False, 'default': 5}
        }
    }
}


# ============================================================================
# Dashboard Widget Model
# ============================================================================

class DashboardWidget(Base):
    """Individual widget configuration"""
    __tablename__ = 'dashboard_widgets'

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Widget identification
    widget_type = Column(String(50), nullable=False)  # Key from WIDGET_TYPES
    title = Column(String(100))  # Custom title override

    # Layout position (grid-based)
    position_x = Column(Integer, default=0)  # Grid column (0-based)
    position_y = Column(Integer, default=0)  # Grid row (0-based)
    width = Column(Integer, default=1)  # Grid units wide
    height = Column(Integer, default=1)  # Grid units tall

    # Configuration (JSON)
    config = Column(Text)  # Widget-specific settings

    # Alerting thresholds
    alert_enabled = Column(Boolean, default=False)
    alert_threshold_warning = Column(Integer)  # Yellow threshold
    alert_threshold_critical = Column(Integer)  # Red threshold

    # Refresh settings
    refresh_interval = Column(Integer, default=60)  # Seconds (0 = manual only)

    # Visibility
    is_visible = Column(Boolean, default=True)

    # Ownership
    layout_id = Column(Integer, ForeignKey('dashboard_layouts.id', ondelete='CASCADE'))
    created_by = Column(String(100))

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationship
    layout = relationship('DashboardLayout', back_populates='widgets')

    def to_dict(self):
        """Convert to dictionary for API response"""
        widget_def = WIDGET_TYPES.get(self.widget_type, {})

        return {
            'id': self.id,
            'widget_type': self.widget_type,
            'widget_name': widget_def.get('name', self.widget_type),
            'widget_icon': widget_def.get('icon', 'box'),
            'title': self.title or widget_def.get('name', self.widget_type),
            'position': {
                'x': self.position_x,
                'y': self.position_y,
                'w': self.width,
                'h': self.height
            },
            'config': json.loads(self.config) if self.config else {},
            'alert': {
                'enabled': self.alert_enabled,
                'threshold_warning': self.alert_threshold_warning,
                'threshold_critical': self.alert_threshold_critical
            },
            'refresh_interval': self.refresh_interval,
            'is_visible': self.is_visible,
            'layout_id': self.layout_id,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


# ============================================================================
# Dashboard Layout Model
# ============================================================================

class DashboardLayout(Base):
    """User-specific dashboard layout configuration"""
    __tablename__ = 'dashboard_layouts'

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Layout identification
    name = Column(String(100), nullable=False)
    description = Column(Text)

    # Ownership
    user_id = Column(String(100))  # Username or user ID
    is_default = Column(Boolean, default=False)  # Default layout for user
    is_shared = Column(Boolean, default=False)  # Visible to other users
    is_system = Column(Boolean, default=False)  # System-provided template

    # Grid settings
    grid_columns = Column(Integer, default=4)  # Number of grid columns
    grid_row_height = Column(Integer, default=150)  # Pixels per row

    # Theme
    theme = Column(String(50), default='default')  # light, dark, auto

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    widgets = relationship('DashboardWidget', back_populates='layout', cascade='all, delete-orphan')

    def to_dict(self, include_widgets=True):
        """Convert to dictionary for API response"""
        data = {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'user_id': self.user_id,
            'is_default': self.is_default,
            'is_shared': self.is_shared,
            'is_system': self.is_system,
            'grid': {
                'columns': self.grid_columns,
                'row_height': self.grid_row_height
            },
            'theme': self.theme,
            'widget_count': len(self.widgets) if self.widgets else 0,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

        if include_widgets:
            data['widgets'] = [w.to_dict() for w in (self.widgets or [])]

        return data


# ============================================================================
# Default Layout Templates
# ============================================================================

DEFAULT_LAYOUTS = {
    'overview': {
        'name': 'Overview Dashboard',
        'description': 'General system overview with key metrics',
        'widgets': [
            {'type': 'stat_card', 'config': {'metric': 'total_servers', 'title': 'Servers', 'icon': 'server', 'color': '#3498db'}, 'x': 0, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'stat_card', 'config': {'metric': 'total_audits', 'title': 'Audits', 'icon': 'file-text', 'color': '#2ecc71'}, 'x': 1, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'stat_card', 'config': {'metric': 'pass_rate', 'title': 'Pass Rate', 'icon': 'check-circle', 'color': '#27ae60'}, 'x': 2, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'stat_card', 'config': {'metric': 'fail_count', 'title': 'Failures', 'icon': 'x-circle', 'color': '#e74c3c'}, 'x': 3, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'trend_chart', 'config': {'metrics': ['pass_count', 'warn_count', 'fail_count'], 'days': 7}, 'x': 0, 'y': 1, 'w': 2, 'h': 2},
            {'type': 'recent_executions', 'config': {'limit': 10}, 'x': 2, 'y': 1, 'w': 2, 'h': 2},
            {'type': 'domain_breakdown', 'config': {'metric': 'audits'}, 'x': 0, 'y': 3, 'w': 1, 'h': 2},
            {'type': 'top_risks', 'config': {'limit': 5}, 'x': 1, 'y': 3, 'w': 1, 'h': 2},
            {'type': 'schedule_timeline', 'config': {'hours_ahead': 24}, 'x': 2, 'y': 3, 'w': 2, 'h': 1},
            {'type': 'storage_pressure', 'config': {'show_hosts': True, 'top_hosts_limit': 5}, 'x': 2, 'y': 4, 'w': 2, 'h': 1}
        ]
    },
    'operations': {
        'name': 'Operations Dashboard',
        'description': 'Focus on audit execution and scheduling',
        'widgets': [
            {'type': 'execution_queue', 'config': {'limit': 15}, 'x': 0, 'y': 0, 'w': 2, 'h': 2},
            {'type': 'schedule_timeline', 'config': {'hours_ahead': 48, 'show_maintenance': True}, 'x': 2, 'y': 0, 'w': 2, 'h': 1},
            {'type': 'maintenance_window', 'config': {'days_ahead': 7}, 'x': 2, 'y': 1, 'w': 1, 'h': 1},
            {'type': 'stat_card', 'config': {'metric': 'pending_tasks', 'title': 'Pending', 'color': '#f39c12'}, 'x': 3, 'y': 1, 'w': 1, 'h': 1},
            {'type': 'recent_executions', 'config': {'limit': 20, 'status_filter': 'all'}, 'x': 0, 'y': 2, 'w': 4, 'h': 2}
        ]
    },
    'compliance': {
        'name': 'Compliance Dashboard',
        'description': 'Compliance status and findings tracking',
        'widgets': [
            {'type': 'compliance_gauge', 'config': {'framework': 'overall'}, 'x': 0, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'compliance_gauge', 'config': {'framework': 'cis'}, 'x': 1, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'compliance_gauge', 'config': {'framework': 'pci-dss'}, 'x': 2, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'critical_findings', 'config': {'alert_threshold': 1}, 'x': 3, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'top_risks', 'config': {'limit': 10, 'severity': 'critical'}, 'x': 0, 'y': 1, 'w': 2, 'h': 2},
            {'type': 'trend_chart', 'config': {'metrics': ['fail_count'], 'days': 30}, 'x': 2, 'y': 1, 'w': 2, 'h': 2}
        ]
    },
    'server_health': {
        'name': 'Server Health Dashboard',
        'description': 'Server-centric health monitoring',
        'widgets': [
            {'type': 'server_health_map', 'config': {'sort_by': 'status'}, 'x': 0, 'y': 0, 'w': 2, 'h': 2},
            {'type': 'stat_card', 'config': {'metric': 'total_servers', 'title': 'Total Servers'}, 'x': 2, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'critical_findings', 'config': {}, 'x': 3, 'y': 0, 'w': 1, 'h': 1},
            {'type': 'recent_executions', 'config': {'limit': 15, 'status_filter': 'fail'}, 'x': 2, 'y': 1, 'w': 2, 'h': 2}
        ]
    }
}


def get_widget_types():
    """Return all available widget types for API"""
    return [
        {
            'type': key,
            'name': val['name'],
            'description': val['description'],
            'icon': val['icon'],
            'default_size': val['default_size'],
            'config_schema': val['config_schema']
        }
        for key, val in WIDGET_TYPES.items()
    ]


def get_default_layouts():
    """Return available default layout templates"""
    return [
        {
            'key': key,
            'name': val['name'],
            'description': val['description'],
            'widget_count': len(val['widgets'])
        }
        for key, val in DEFAULT_LAYOUTS.items()
    ]


def create_layout_from_template(db, template_key, user_id, name=None):
    """Create a new layout from a template"""
    template = DEFAULT_LAYOUTS.get(template_key)
    if not template:
        return None

    layout = DashboardLayout(
        name=name or template['name'],
        description=template['description'],
        user_id=user_id,
        is_default=False,
        is_shared=False,
        is_system=False
    )
    db.add(layout)
    db.flush()  # Get ID

    # Create widgets from template
    for w in template['widgets']:
        widget = DashboardWidget(
            widget_type=w['type'],
            position_x=w['x'],
            position_y=w['y'],
            width=w['w'],
            height=w['h'],
            config=json.dumps(w['config']),
            layout_id=layout.id,
            created_by=user_id
        )
        db.add(widget)

    return layout
