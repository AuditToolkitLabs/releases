"""
SQLAlchemy ORM Models for Security Audit Toolkit

Database schema with 4 core tables:
- servers: Server inventory with encrypted credentials
- audits: Audit script metadata
- audit_executions: Execution history with full output
- scheduled_audits: Cron-like scheduled jobs

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

from datetime import datetime
from importlib import import_module
from sqlalchemy import (
    Column, Integer, String, Text, Float, Boolean,
    DateTime, ForeignKey, Index
)
from sqlalchemy.orm import declarative_base, relationship

from .encrypted_field import EncryptedField

Base = declarative_base()


def _resolve_maintenance_window_model():
    """Resolve MaintenanceWindow within the active models package."""
    return import_module(f"{__package__}.maintenance_window").MaintenanceWindow


class Server(Base):
    """
    Server inventory table - stores remote Linux servers

    Supports both password and SSH key authentication.
    Passwords are encrypted using Fernet before storage.
    """
    __tablename__ = 'servers'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Server Identity
    name = Column(String(255), unique=True, nullable=False, index=True)
    hostname = Column(String(255), nullable=False, index=True)
    port = Column(Integer, nullable=False, default=22)

    # Authentication
    username = Column(String(100), nullable=False)
    password = Column(EncryptedField(), nullable=True)  # Encrypted at rest
    ssh_key_path = Column(String(500), nullable=True)

    # Connection Method: ssh, winrm, agent
    connection_method = Column(String(20), nullable=False, default='ssh')
    agent_id = Column(String(50), nullable=True)  # Links to registered agent

    # Execution Mode: how audits are run on this host
    # 'stream' = scripts sent via SSH/WinRM stdin (agentless, no deployment)
    # 'deployed' = scripts pre-installed at /opt/audit-toolkit (requires package)
    execution_mode = Column(String(20), nullable=False, default='stream')

    # Elevation Method: how scripts get elevated privileges
    # Linux: 'sudo', 'sudo_nopasswd', 'audit_wrapper', 'none'
    # Windows: 'runas', 'jea', 'admin', 'none'
    elevation_method = Column(String(30), nullable=False, default='sudo')

    # JEA Endpoint: PowerShell JEA endpoint name (Windows only, when elevation_method='jea')
    jea_endpoint = Column(String(100), nullable=True)

    # Metadata
    description = Column(Text, nullable=True)
    tags = Column(Text, nullable=True)  # JSON array: ["production", "web"]

    # Hypervisor-specific fields (nullable for non-hypervisor servers)
    hypervisor_type = Column(String(50), nullable=True)
    hypervisor_endpoint = Column(String(255), nullable=True)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_audit_at = Column(DateTime, nullable=True)

    # Relationships
    executions = relationship(
        "AuditExecution",
        back_populates="server",
        cascade="all, delete-orphan"
    )
    scheduled_audits = relationship(
        "ScheduledAudit",
        back_populates="server",
        cascade="all, delete-orphan"
    )
    maintenance_windows = relationship(
        _resolve_maintenance_window_model,
        back_populates="server",
        cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<Server(id={self.id}, name='{self.name}', hostname='{self.hostname}')>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'name': self.name,
            'hostname': self.hostname,
            'port': self.port,
            'username': self.username,
            'description': self.description,
            'tags': self.tags,
            'connection_method': self.connection_method,
            'agent_id': self.agent_id,
            'execution_mode': self.execution_mode or 'stream',
            'elevation_method': self.elevation_method or 'sudo',
            'jea_endpoint': self.jea_endpoint,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'last_audit_at': self.last_audit_at.isoformat() if self.last_audit_at else None,
            'hypervisor_type': self.hypervisor_type,
            'hypervisor_endpoint': self.hypervisor_endpoint
        }


class Hypervisor(Base):
    """
    Hypervisor inventory table - stores hypervisor/virtualization platform configurations

    Separate from Server table to allow API-based auditing (no SSH required).
    Supports: ESXi, vCenter, Proxmox, XCP-ng/Xen, KVM/libvirt, Nutanix, Xen Orchestra

    API connectivity via REST/XML-RPC/libvirt - no SSH tunnel needed.
    Credentials are encrypted using Fernet before storage.
    """
    __tablename__ = 'hypervisors'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Hypervisor Identity
    name = Column(String(255), unique=True, nullable=False, index=True)
    hostname = Column(String(255), nullable=False, index=True)
    port = Column(Integer, nullable=False, default=443)

    # Hypervisor Type
    # esxi, vcenter, proxmox, xen, kvm, nutanix, xo (Xen Orchestra)
    hypervisor_type = Column(String(50), nullable=False, index=True)

    # API Credentials (encrypted)
    username = Column(String(100), nullable=True)
    password = Column(EncryptedField(), nullable=True)  # Encrypted at rest
    api_token = Column(EncryptedField(), nullable=True)  # Encrypted at rest (Proxmox, etc.)

    # Connection Settings
    connection_method = Column(String(20), nullable=False, default='api')  # api or ssh
    verify_ssl = Column(Boolean, nullable=False, default=True)
    api_endpoint = Column(String(500), nullable=True)  # Custom API endpoint if different from default

    # Metadata
    description = Column(Text, nullable=True)
    tags = Column(Text, nullable=True)  # JSON array: ["production", "vmware", "datacenter-1"]
    datacenter = Column(String(100), nullable=True)  # Logical grouping
    cluster = Column(String(100), nullable=True)  # Cluster membership

    # Status Tracking
    status = Column(String(20), nullable=False, default='unknown')  # online, offline, error, unknown
    last_connection_check = Column(DateTime, nullable=True)
    last_connection_error = Column(EncryptedField(), nullable=True)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_audit_at = Column(DateTime, nullable=True)

    # Relationships (for audit history)
    executions = relationship(
        "HypervisorAuditExecution",
        back_populates="hypervisor",
        cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<Hypervisor(id={self.id}, name='{self.name}', type='{self.hypervisor_type}')>"

    def to_dict(self, include_sensitive=False):
        """Convert to dictionary for JSON serialization"""
        result = {
            'id': self.id,
            'name': self.name,
            'hostname': self.hostname,
            'port': self.port,
            'hypervisor_type': self.hypervisor_type,
            'username': self.username,
            'connection_method': self.connection_method,
            'verify_ssl': self.verify_ssl,
            'api_endpoint': self.api_endpoint,
            'description': self.description,
            'tags': self.tags,
            'datacenter': self.datacenter,
            'cluster': self.cluster,
            'status': self.status,
            'last_connection_check': self.last_connection_check.isoformat() if self.last_connection_check else None,
            'last_connection_error': self.last_connection_error,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'last_audit_at': self.last_audit_at.isoformat() if self.last_audit_at else None
        }
        if include_sensitive:
            result['has_password'] = bool(self.password)
            result['has_api_token'] = bool(self.api_token)
        return result


class HypervisorAuditExecution(Base):
    """
    Hypervisor audit execution history - stores results of hypervisor audits

    Separate from AuditExecution to track API-based hypervisor-specific audits.
    """
    __tablename__ = 'hypervisor_audit_executions'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign Key
    hypervisor_id = Column(Integer, ForeignKey('hypervisors.id', ondelete='CASCADE'), nullable=False, index=True)

    # Audit Details
    audit_type = Column(String(50), nullable=False)  # security, compliance, performance
    audit_script = Column(String(255), nullable=True)  # Script used (e.g., esxi-api-audit.py)

    # Execution Status
    status = Column(String(20), nullable=False, index=True)  # success, failure, timeout, running
    exit_code = Column(Integer, nullable=True)
    output = Column(EncryptedField(), nullable=True)  # Full output (encrypted at rest)
    summary = Column(EncryptedField(), nullable=True)  # JSON summary (encrypted at rest)

    # Performance Metrics
    duration_seconds = Column(Float, nullable=True)
    checks_total = Column(Integer, nullable=True)
    checks_passed = Column(Integer, nullable=True)
    checks_warned = Column(Integer, nullable=True)
    checks_failed = Column(Integer, nullable=True)
    checks_skipped = Column(Integer, nullable=True)

    # Timestamps
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)

    # Relationship
    hypervisor = relationship("Hypervisor", back_populates="executions")

    # Indexes
    __table_args__ = (
        Index('idx_hypervisor_executions_status', 'status'),
        Index('idx_hypervisor_executions_started', 'started_at'),
    )

    def __repr__(self):
        return f"<HypervisorAuditExecution(id={self.id}, hypervisor_id={self.hypervisor_id}, status='{self.status}')>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'hypervisor_id': self.hypervisor_id,
            'audit_type': self.audit_type,
            'audit_script': self.audit_script,
            'status': self.status,
            'exit_code': self.exit_code,
            'summary': self.summary,
            'duration_seconds': self.duration_seconds,
            'checks_total': self.checks_total,
            'checks_passed': self.checks_passed,
            'checks_warned': self.checks_warned,
            'checks_failed': self.checks_failed,
            'checks_skipped': self.checks_skipped,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }


class Audit(Base):
    """
    Audit metadata table - stores information about audit scripts

    Populated by audit discovery process for efficient querying.
    """
    __tablename__ = 'audits'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Audit Identity
    name = Column(String(255), nullable=False, index=True)
    domain = Column(String(50), nullable=False, index=True)
    category = Column(String(100), nullable=False)
    file_path = Column(String(500), unique=True, nullable=False, index=True)

    # Metadata
    description = Column(Text, nullable=True)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    executions = relationship(
        "AuditExecution",
        back_populates="audit",
        cascade="all, delete-orphan"
    )
    scheduled_audits = relationship(
        "ScheduledAudit",
        back_populates="audit"
    )

    # Composite Index for common queries
    __table_args__ = (
        Index('idx_audits_domain_category', 'domain', 'category'),
    )

    def __repr__(self):
        return f"<Audit(id={self.id}, name='{self.name}', domain='{self.domain}')>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'name': self.name,
            'domain': self.domain,
            'category': self.category,
            'file_path': self.file_path,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class AuditExecution(Base):
    """
    Audit execution history table - stores results of audit runs

    Includes full output for debugging and compliance reporting.
    Summary field stores JSON: {"pass": 10, "warn": 2, "fail": 1}
    """
    __tablename__ = 'audit_executions'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign Keys
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'), nullable=False, index=True)
    audit_id = Column(Integer, ForeignKey('audits.id', ondelete='CASCADE'), nullable=False, index=True)

    # Execution Status
    status = Column(String(20), nullable=False, index=True)  # success, failure, timeout, running
    exit_code = Column(Integer, nullable=True)
    output = Column(EncryptedField(), nullable=True)  # Full stdout/stderr (encrypted at rest)
    summary = Column(EncryptedField(), nullable=True)  # JSON summary (encrypted at rest)

    # Performance Metrics
    duration_seconds = Column(Float, nullable=True)

    # Audit Context
    executed_by = Column(String(100), nullable=True)  # Future: FK to users table

    # Timestamps
    executed_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    completed_at = Column(DateTime, nullable=True)

    # Relationships
    server = relationship("Server", back_populates="executions")
    audit = relationship("Audit", back_populates="executions")

    # Composite Indexes for common queries
    __table_args__ = (
        Index('idx_executions_server_audit', 'server_id', 'audit_id', 'executed_at'),
        Index('idx_executions_server_status', 'server_id', 'status', 'executed_at'),
    )

    def __repr__(self):
        return f"<AuditExecution(id={self.id}, server_id={self.server_id}, audit_id={self.audit_id}, status='{self.status}')>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'server_id': self.server_id,
            'server_name': self.server.name if self.server else None,
            'audit_id': self.audit_id,
            'audit_name': self.audit.name if self.audit else None,
            'status': self.status,
            'exit_code': self.exit_code,
            'output': self.output,
            'summary': self.summary,
            'duration_seconds': self.duration_seconds,
            'executed_by': self.executed_by,
            'executed_at': self.executed_at.isoformat() if self.executed_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }


# Import related models to register them with the mapper
# This ensures string references in relationships can be resolved
class AuditPlan(Base):
    """
    Audit Plan table - stores reusable audit configurations

    Plans include:
    - Selected audits
    - Target servers (optional - can be assigned at execution time)
    - Execution options (timeout, elevation, etc.)
    - Schedule configuration (optional)

    Connection details and API keys reference the server table and keystore,
    ensuring credentials are properly encrypted and manageable.
    """
    __tablename__ = 'audit_plans'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Plan Identity
    name = Column(String(255), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)

    # Audit Selection (JSON array of audit paths)
    audit_paths = Column(Text, nullable=False)  # JSON: ["audits/linux/baseline.sh", ...]

    # Target Servers (JSON array of server IDs - optional)
    # If empty, servers must be selected at execution time
    server_ids = Column(Text, nullable=True)  # JSON: [1, 2, 3] or null

    # Execution Options (JSON object)
    # Includes: timeout, execution_mode, elevation_method, parallel, etc.
    execution_options = Column(Text, nullable=True)  # JSON: {"timeout": 300, ...}

    # Schedule Configuration (JSON object - for scheduled plans)
    # If present, this plan can run on a schedule
    schedule_config = Column(Text, nullable=True)  # JSON: {"cron": "0 2 * * *", ...}

    # Plan Metadata
    tags = Column(Text, nullable=True)  # JSON: ["compliance", "weekly"]
    is_active = Column(Boolean, nullable=False, default=True)
    is_template = Column(Boolean, nullable=False, default=False)  # Template plans for reuse

    # Ownership & Access
    created_by = Column(String(100), nullable=True)  # Username who created
    shared_with = Column(Text, nullable=True)  # JSON: ["team1", "team2"] or "all"

    # Statistics
    run_count = Column(Integer, nullable=False, default=0)
    last_run_at = Column(DateTime, nullable=True)
    last_run_status = Column(String(20), nullable=True)  # success, failure, partial

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Indexes
    __table_args__ = (
        Index('idx_audit_plans_active', 'is_active'),
        Index('idx_audit_plans_created_by', 'created_by'),
    )

    def __repr__(self):
        return f"<AuditPlan(id={self.id}, name='{self.name}')>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        import json as json_module
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'audit_paths': json_module.loads(self.audit_paths) if self.audit_paths else [],
            'server_ids': json_module.loads(self.server_ids) if self.server_ids else [],
            'execution_options': json_module.loads(self.execution_options) if self.execution_options else {},
            'schedule_config': json_module.loads(self.schedule_config) if self.schedule_config else None,
            'tags': json_module.loads(self.tags) if self.tags else [],
            'is_active': self.is_active,
            'is_template': self.is_template,
            'created_by': self.created_by,
            'shared_with': json_module.loads(self.shared_with) if self.shared_with else None,
            'run_count': self.run_count,
            'last_run_at': self.last_run_at.isoformat() if self.last_run_at else None,
            'last_run_status': self.last_run_status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class FleetAgent(Base):
    """
    Unified Agent Registry - tracks all agent types (lightweight, managed, hypervisor)

    This table provides a single source of truth for agent health, status, and error tracking
    across all agent types: standalone agents, fleet agents, and hypervisor agents.

    Allows:
    - Unified dashboard showing all agents
    - Consistent health checks (heartbeat, connectivity, error tracking)
    - Failed import retry tracking
    - Normalized error messages across agent types
    """
    __tablename__ = 'managed_agents'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Agent Identity
    agent_id = Column(String(100), unique=True, nullable=False, index=True)
    agent_type = Column(String(50), nullable=False, index=True)  # lightweight, managed, hypervisor, standalone
    name = Column(String(255), nullable=False, index=True)
    hostname = Column(String(255), nullable=True, index=True)

    # System Information
    os_type = Column(String(50), nullable=True)  # linux, windows
    agent_version = Column(String(20), nullable=True)
    api_key_hash = Column(String(64), nullable=True)  # SHA256 hash of API key for validation

    # Status Tracking
    status = Column(String(20), nullable=False, default='unknown', index=True)  # healthy, offline, degraded, error, unknown
    is_active = Column(Boolean, nullable=False, default=True, index=True)

    # Heartbeat & Connectivity
    last_heartbeat = Column(DateTime, nullable=True)
    last_heartbeat_error = Column(EncryptedField(), nullable=True)
    registration_token = Column(EncryptedField(length=255), nullable=True)  # Token-based registration (encrypted at rest)
    registration_token_expires = Column(DateTime, nullable=True)

    # Heartbeat Tracking (v5.3.0 - Strict Heartbeat Validation)
    last_heartbeat_at = Column(DateTime, nullable=True)  # Timestamp of last successful heartbeat
    consecutive_heartbeat_failures = Column(Integer, nullable=False, default=0)  # Counter: 0-3 (stop at 3)
    last_heartbeat_status = Column(String(50), nullable=True)  # ok, license_expired, invalid_key, connection_error
    heartbeat_failure_reason = Column(String(200), nullable=True)  # Human-readable reason for failure

    # Export/Import Tracking
    last_export_at = Column(DateTime, nullable=True)
    last_export_status = Column(String(20), nullable=True)  # success, failed
    last_export_error = Column(EncryptedField(), nullable=True)
    failed_export_count = Column(Integer, nullable=False, default=0)

    # Import/Result Tracking (for core server receiving agent results)
    last_import_at = Column(DateTime, nullable=True)
    last_import_status = Column(String(20), nullable=True)  # success, failed
    last_import_error = Column(EncryptedField(), nullable=True)
    failed_import_count = Column(Integer, nullable=False, default=0)

    # Metadata
    description = Column(Text, nullable=True)
    tags = Column(Text, nullable=True)  # JSON: ["production", "web"]
    connection_config = Column(EncryptedField(), nullable=True)  # JSON: {url, port, tls_verify, etc} (encrypted at rest)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    registered_at = Column(DateTime, nullable=True)

    # Indexes for common queries
    __table_args__ = (
        Index('idx_managed_agents_status', 'status'),
        Index('idx_managed_agents_type', 'agent_type'),
        Index('idx_managed_agents_active', 'is_active'),
        Index('idx_managed_agents_heartbeat', 'last_heartbeat'),
    )

    def __repr__(self):
        return f"<FleetAgent(agent_id='{self.agent_id}', type='{self.agent_type}', status='{self.status}')>"

    def to_dict(self, include_config=False):
        """Convert to dictionary for JSON serialization"""
        result = {
            'id': self.id,
            'agent_id': self.agent_id,
            'agent_type': self.agent_type,
            'name': self.name,
            'hostname': self.hostname,
            'os_type': self.os_type,
            'agent_version': self.agent_version,
            'status': self.status,
            'is_active': self.is_active,
            'last_heartbeat': self.last_heartbeat.isoformat() if self.last_heartbeat else None,
            'last_heartbeat_error': self.last_heartbeat_error,
            'last_heartbeat_at': self.last_heartbeat_at.isoformat() if self.last_heartbeat_at else None,
            'consecutive_heartbeat_failures': self.consecutive_heartbeat_failures,
            'last_heartbeat_status': self.last_heartbeat_status,
            'heartbeat_failure_reason': self.heartbeat_failure_reason,
            'last_export_at': self.last_export_at.isoformat() if self.last_export_at else None,
            'last_export_status': self.last_export_status,
            'last_export_error': self.last_export_error,
            'failed_export_count': self.failed_export_count,
            'last_import_at': self.last_import_at.isoformat() if self.last_import_at else None,
            'last_import_status': self.last_import_status,
            'last_import_error': self.last_import_error,
            'failed_import_count': self.failed_import_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'registered_at': self.registered_at.isoformat() if self.registered_at else None,
        }
        if include_config:
            import json as json_module
            result['connection_config'] = json_module.loads(self.connection_config) if self.connection_config else {}
            result['tags'] = json_module.loads(self.tags) if self.tags else []
        return result


# Must be done AFTER base classes are defined to avoid circular imports
def _register_related_models():
    """Lazy import to register related models with mapper."""
    try:
        from . import schedule  # noqa - registers ScheduledAudit
        from . import maintenance_window  # noqa - registers MaintenanceWindow
    except ImportError:
        pass  # Models not available (minimal install)

_register_related_models()


# Additional helper functions for database initialization

def init_db(engine):
    """
    Initialize database schema - create all tables

    Args:
        engine: SQLAlchemy engine instance
    """
    Base.metadata.create_all(engine)


def drop_all_tables(engine):
    """
    Drop all tables - use with caution!

    Args:
        engine: SQLAlchemy engine instance
    """
    Base.metadata.drop_all(engine)


def get_table_names():
    """
    Get list of all table names

    Returns:
        List of table names
    """
    return [table.name for table in Base.metadata.sorted_tables]


# =============================================================================
# Flask-SQLAlchemy Compatibility Layer for Tests
# =============================================================================
# This provides a Flask-SQLAlchemy-like interface for testing while the main
# application uses raw SQLAlchemy with session management via config.py

class DatabaseShim:
    """
    Flask-SQLAlchemy compatible wrapper for raw SQLAlchemy.

    Provides methods like create_all(), drop_all(), session, engine
    that integration tests expect.
    """

    def __init__(self):
        self._engine = None
        self._session = None
        self._scoped_session = None

    @property
    def engine(self):
        if self._engine is None:
            from config import db_engine
            self._engine = db_engine
        return self._engine

    @property
    def metadata(self):
        """Return the Base metadata for table operations"""
        return Base.metadata

    @property
    def session(self):
        if self._session is None:
            from config import SessionLocal
            if SessionLocal:
                self._session = SessionLocal()
        return self._session

    @session.setter
    def session(self, value):
        self._session = value

    def create_all(self):
        """Create all tables"""
        if self.engine:
            Base.metadata.create_all(self.engine)

    def drop_all(self):
        """Drop all tables"""
        if self.engine:
            Base.metadata.drop_all(self.engine)

    def create_scoped_session(self, options=None):
        """Create a scoped session for testing"""
        from sqlalchemy.orm import scoped_session, sessionmaker
        bind = options.get('bind', self.engine) if options else self.engine
        factory = sessionmaker(bind=bind)
        return scoped_session(factory)


# Global instance for test compatibility
db = DatabaseShim()
