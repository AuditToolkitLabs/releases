#!/usr/bin/env python3
"""
Dead Letter Queue Model

Tracks tasks that fail repeatedly and need manual intervention:
- Failed task details
- Retry attempts
- Error messages
- Manual resolution tracking

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from .database import Base
from .encrypted_field import EncryptedField


class DeadLetterTask(Base):
    """
    Dead Letter Queue entry for persistently failing tasks

    Stores information about tasks that exceed retry limits
    and require manual investigation/intervention.
    """
    __tablename__ = 'dead_letter_tasks'

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Task identification
    task_id = Column(String(255), unique=True, nullable=False, index=True)
    task_name = Column(String(255), nullable=False, index=True)

    # Execution context
    server_id = Column(Integer, ForeignKey('servers.id'), nullable=True)
    audit_id = Column(Integer, ForeignKey('audits.id'), nullable=True)

    # Task arguments (serialized JSON)
    args = Column(JSON, nullable=True)
    kwargs = Column(JSON, nullable=True)

    # Failure information
    retry_count = Column(Integer, default=0, nullable=False)
    max_retries = Column(Integer, nullable=False)
    last_error = Column(EncryptedField(), nullable=True)
    last_exception_type = Column(String(255), nullable=True)
    last_traceback = Column(EncryptedField(), nullable=True)

    # Timing
    first_failure_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    last_attempt_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    added_to_dlq_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)

    # Resolution tracking
    resolved = Column(Boolean, default=False, nullable=False, index=True)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(String(255), nullable=True )
    resolution_notes = Column(EncryptedField(), nullable=True)

    # Retry strategy
    retry_after = Column(DateTime, nullable=True)  # Manual retry scheduling

    # Relationships
    server = relationship("Server", backref="dead_letter_tasks", foreign_keys=[server_id])
    audit = relationship("Audit", backref="dead_letter_tasks", foreign_keys=[audit_id])

    def __repr__(self):
        return (
            f"<DeadLetterTask(id={self.id}, task_id='{self.task_id}', "
            f"task_name='{self.task_name}', retry_count={self.retry_count}, "
            f"resolved={self.resolved})>"
        )

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'task_id': self.task_id,
            'task_name': self.task_name,
            'server_id': self.server_id,
            'audit_id': self.audit_id,
            'retry_count': self.retry_count,
            'max_retries': self.max_retries,
            'last_error': self.last_error,
            'last_exception_type': self.last_exception_type,
            'first_failure_at': self.first_failure_at.isoformat() if self.first_failure_at else None,
            'last_attempt_at': self.last_attempt_at.isoformat() if self.last_attempt_at else None,
            'added_to_dlq_at': self.added_to_dlq_at.isoformat() if self.added_to_dlq_at else None,
            'resolved': self.resolved,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'resolved_by': self.resolved_by,
            'resolution_notes': self.resolution_notes,
            'retry_after': self.retry_after.isoformat() if self.retry_after else None
        }


class TaskFailureLog(Base):
    """
    Log of all task failures (before DLQ)

    Tracks every failure attempt for analysis and debugging.
    Useful for identifying patterns and root causes.
    """
    __tablename__ = 'task_failure_logs'

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Task identification
    task_id = Column(String(255), nullable=False, index=True)
    task_name = Column(String(255), nullable=False, index=True)

    # Execution context
    server_id = Column(Integer, ForeignKey('servers.id'), nullable=True)
    audit_id = Column(Integer, ForeignKey('audits.id'), nullable=True)

    # Failure details
    retry_number = Column(Integer, nullable=False)
    error_message = Column(EncryptedField(), nullable=True)
    exception_type = Column(String(255), nullable=True)
    traceback = Column(EncryptedField(), nullable=True)

    # Circuit breaker info
    circuit_breaker_state = Column(String(50), nullable=True)
    circuit_breaker_name = Column(String(255), nullable=True)

    # Timing
    failed_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    next_retry_at = Column(DateTime, nullable=True)

    # Task Metadata (renamed from 'metadata' which is SQLAlchemy reserved)
    task_metadata = Column(JSON, nullable=True)

    # Relationships
    server = relationship("Server", backref="failure_logs", foreign_keys=[server_id])
    audit = relationship("Audit", backref="failure_logs", foreign_keys=[audit_id])

    def __repr__(self):
        return (
            f"<TaskFailureLog(id={self.id}, task_id='{self.task_id}', "
            f"retry_number={self.retry_number}, failed_at='{self.failed_at}')>"
        )

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'task_id': self.task_id,
            'task_name': self.task_name,
            'server_id': self.server_id,
            'audit_id': self.audit_id,
            'retry_number': self.retry_number,
            'error_message': self.error_message,
            'exception_type': self.exception_type,
            'circuit_breaker_state': self.circuit_breaker_state,
            'circuit_breaker_name': self.circuit_breaker_name,
            'failed_at': self.failed_at.isoformat() if self.failed_at else None,
            'next_retry_at': self.next_retry_at.isoformat() if self.next_retry_at else None,
            'task_metadata': self.task_metadata
        }
