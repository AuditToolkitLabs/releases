#!/usr/bin/env python3
"""
Destination Policy Models

Provides centralized management of destination whitelist/blacklist policies:
- AdminDestinationPolicy: Global policy configuration for allowed/blocked destinations
- AdminDestinationPolicyLog: Audit trail of policy enforcement and blocked attempts

Policies are applied at:
- Asset Discovery target registration
- Audit execution (against registered servers)
- Fleet Agent server registration (bidirectional API)
- Hypervisor Agent target connectivity

Author: Security Audit Toolkit Team
Date: February 20, 2026
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, JSON, ForeignKey
from sqlalchemy.orm import relationship
from models.database import Base


class AdminDestinationPolicy(Base):
    """
    Global destination whitelist/blacklist policy configuration (Superadmin only)

    Single-row configuration that applies to all audit execution and agent
    registration endpoints. Enforces URL validation before allowing connections.

    Policy Enforcement:
    - ALLOW_ALL (default): Permit all destinations except explicitly blocked keywords
      and private IP ranges (unless allowed)
    - WHITELIST_ONLY: Only allow destinations in the explicit whitelist
    - BLACKLIST_ONLY: Block destinations in the explicit blacklist (inverse)

    Example:
        policy = AdminDestinationPolicy.query.first()
        if not policy:
            policy = AdminDestinationPolicy(
                mode='ALLOW_ALL',
                blocked_keywords=['wazuh', 'splunk', 'elastic'],
                whitelist_domains=['*.internal.example.com', 'api.example.com'],
                allow_private_ips=False,
                log_blocked_attempts=True
            )
    """
    __tablename__ = 'admin_destination_policy'
    __table_args__ = {'extend_existing': True}

    # Policy Metadata
    id = Column(Integer, primary_key=True)
    name = Column(String(255), default='Global Destination Policy', nullable=False)
    description = Column(Text, nullable=True)

    # Policy Mode
    mode = Column(
        String(50),
        nullable=False,
        default='ALLOW_ALL',
        # ALLOW_ALL: Default-allow except blocked_keywords and private IPs
        # WHITELIST_ONLY: Deny-all except whitelist_domains
    )

    # Blocked Keywords (CIDR blocks, domain patterns, IP addresses)
    # Comma or newline-separated list
    # Applied in ALLOW_ALL mode to reject destinations containing these strings
    # Default: 'wazuh,splunk,elastic,datadog,newrelic' to prevent SIEM/monitoring conflicts
    blocked_keywords = Column(
        Text,
        default='wazuh,splunk,elastic,datadog,newrelic',
        nullable=True
    )

    # Whitelist Domains (comma-separated, supports wildcards *.example.com)
    # Applied in WHITELIST_ONLY mode to permit only listed destinations
    # Empty = allow all destinations (requires blocked_keywords to enforce anything)
    whitelist_domains = Column(Text, nullable=True)

    # Allow Private IP Ranges
    # If False (default), blocks RFC1918 (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)
    # and loopback (127.0.0.0/8), link-local (169.254.0.0/16), multicast (224.0.0.0/4)
    allow_private_ips = Column(Boolean, default=False, nullable=False)

    # Logging & Audit Trail
    log_blocked_attempts = Column(
        Boolean,
        default=True,
        nullable=False,
        comment='Log all blocked connection attempts to AdminDestinationPolicyLog'
    )

    # Enforcement Scope (applied to which endpoints)
    enforce_asset_discovery = Column(Boolean, default=True, nullable=False)
    enforce_audit_execution = Column(Boolean, default=True, nullable=False)
    enforce_fleet_agent_registration = Column(Boolean, default=True, nullable=False)
    enforce_hypervisor_registration = Column(Boolean, default=True, nullable=False)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    updated_by = Column(String(255), nullable=True, comment='User who last modified this policy')

    # Active/Inactive
    is_active = Column(Boolean, default=True, nullable=False)

    # Relationships
    policy_logs = relationship(
        'AdminDestinationPolicyLog',
        back_populates='policy',
        cascade='all, delete-orphan',
        lazy='dynamic'
    )

    def __repr__(self):
        return f'<AdminDestinationPolicy id={self.id} mode={self.mode} active={self.is_active}>'

    def to_dict(self):
        """Serialize policy to dictionary for API responses"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'mode': self.mode,
            'blocked_keywords': [k.strip() for k in (self.blocked_keywords or '').split(',') if k.strip()],
            'whitelist_domains': [d.strip() for d in (self.whitelist_domains or '').split(',') if d.strip()],
            'allow_private_ips': self.allow_private_ips,
            'log_blocked_attempts': self.log_blocked_attempts,
            'enforce': {
                'asset_discovery': self.enforce_asset_discovery,
                'audit_execution': self.enforce_audit_execution,
                'fleet_agent_registration': self.enforce_fleet_agent_registration,
                'hypervisor_registration': self.enforce_hypervisor_registration,
            },
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'updated_by': self.updated_by,
        }


class AdminDestinationPolicyLog(Base):
    """
    Audit trail for destination policy enforcement

    Records every attempt to connect to a destination that violates the
    configured policy. Used for security auditing and compliance reporting.

    Example:
        log = AdminDestinationPolicyLog(
            policy_id=1,
            action='BLOCKED',
            reason='matched_keyword',
            destination='wazuh.internal.example.com:9200',
            source_endpoint='audit_execution',
            source_user='admin@example.com',
            source_ip='10.0.1.5'
        )
    """
    __tablename__ = 'admin_destination_policy_log'
    __table_args__ = {'extend_existing': True}

    # Primary Key
    id = Column(Integer, primary_key=True)
    policy_id = Column(Integer, ForeignKey('admin_destination_policy.id'), nullable=False)

    # What Happened
    action = Column(String(50), default='BLOCKED', nullable=False)  # BLOCKED, ALLOWED, WARNED
    reason = Column(
        String(255),
        nullable=True,
        comment='Why action was taken: matched_keyword, not_in_whitelist, private_ip, invalid_format'
    )

    # Destination Details
    destination = Column(String(512), nullable=False, comment='Target URL/hostname:port')
    destination_hostname = Column(String(255), nullable=True, index=True)
    destination_port = Column(Integer, nullable=True)
    destination_type = Column(String(50), nullable=True, comment='url, hostname, ip_address')

    # Source (Who/Where)
    source_endpoint = Column(
        String(100),
        nullable=False,
        index=True,
        comment='Which endpoint attempted connection: asset_discovery, audit_execution, fleet_agent_registration, hypervisor_registration'
    )
    source_user = Column(String(255), nullable=True, index=True, comment='Username if authenticated')
    source_ip = Column(String(45), nullable=True, index=True, comment='Source IP address (IPv4 or IPv6)')
    source_context = Column(
        JSON,
        nullable=True,
        comment='Additional context: server_id, audit_id, hypervisor_id, agent_id'
    )

    # Timestamps
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    # Relationships
    policy = relationship('AdminDestinationPolicy', back_populates='policy_logs')

    def __repr__(self):
        return f'<AdminDestinationPolicyLog id={self.id} action={self.action} destination={self.destination}>'

    def to_dict(self):
        """Serialize log entry to dictionary for API responses"""
        return {
            'id': self.id,
            'policy_id': self.policy_id,
            'action': self.action,
            'reason': self.reason,
            'destination': self.destination,
            'destination_hostname': self.destination_hostname,
            'destination_port': self.destination_port,
            'destination_type': self.destination_type,
            'source_endpoint': self.source_endpoint,
            'source_user': self.source_user,
            'source_ip': self.source_ip,
            'source_context': self.source_context,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
        }
