"""
SQLAlchemy Models for Differential Audits

Database schema for tracking audit result comparisons and remediation progress:
- differential_comparisons: Stores comparison results between two audit executions
- remediation_items: Tracks remediation progress for individual failing checks

Author: Security Audit Toolkit Team
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float,
    DateTime, ForeignKey, Index
)
from sqlalchemy.orm import relationship

from .database import Base
from .encrypted_field import EncryptedField


class DifferentialComparison(Base):
    """
    Stores differential comparison results between two audit executions.

    Comparison is always between a baseline (earlier) and comparison (later) execution.
    The changes field stores JSON with categorized findings.
    """
    __tablename__ = 'differential_comparisons'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign Keys to executions being compared
    baseline_execution_id = Column(
        Integer,
        ForeignKey('audit_executions.id', ondelete='CASCADE'),
        nullable=False,
        index=True
    )
    comparison_execution_id = Column(
        Integer,
        ForeignKey('audit_executions.id', ondelete='CASCADE'),
        nullable=False,
        index=True
    )

    # Server and Audit context (denormalized for query efficiency)
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'), nullable=False, index=True)
    audit_id = Column(Integer, ForeignKey('audits.id', ondelete='CASCADE'), nullable=False, index=True)

    # Comparison timestamps
    baseline_timestamp = Column(DateTime, nullable=False)
    comparison_timestamp = Column(DateTime, nullable=False)

    # Metrics
    drift_score = Column(Float, nullable=False, default=0.0)  # 0-100
    health_trend = Column(String(20), nullable=False, default='stable')  # improving, stable, degrading

    # Change counts (for quick queries without parsing JSON)
    new_failures_count = Column(Integer, nullable=False, default=0)
    resolved_count = Column(Integer, nullable=False, default=0)
    escalated_count = Column(Integer, nullable=False, default=0)
    deescalated_count = Column(Integer, nullable=False, default=0)
    new_checks_count = Column(Integer, nullable=False, default=0)
    removed_checks_count = Column(Integer, nullable=False, default=0)

    # Full comparison data (JSON)
    changes = Column(EncryptedField(), nullable=True)  # JSON: {new_failures: [...], resolved: [...], ...}

    # Metadata
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    created_by = Column(String(100), nullable=True)

    # Relationships
    baseline_execution = relationship(
        "AuditExecution",
        foreign_keys=[baseline_execution_id],
        backref="baseline_comparisons"
    )
    comparison_execution = relationship(
        "AuditExecution",
        foreign_keys=[comparison_execution_id],
        backref="comparison_comparisons"
    )
    server = relationship("Server", backref="differential_comparisons")
    audit = relationship("Audit", backref="differential_comparisons")

    # Indexes
    __table_args__ = (
        Index('idx_diff_server_audit_time', 'server_id', 'audit_id', 'comparison_timestamp'),
        Index('idx_diff_drift_score', 'drift_score'),
        Index('idx_diff_health_trend', 'health_trend'),
    )

    def __repr__(self):
        return f"<DifferentialComparison(id={self.id}, baseline={self.baseline_execution_id}, comparison={self.comparison_execution_id}, drift={self.drift_score})>"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        import json
        return {
            'id': self.id,
            'baseline_execution_id': self.baseline_execution_id,
            'comparison_execution_id': self.comparison_execution_id,
            'server_id': self.server_id,
            'server_name': self.server.name if self.server else None,
            'audit_id': self.audit_id,
            'audit_name': self.audit.name if self.audit else None,
            'baseline_timestamp': self.baseline_timestamp.isoformat() if self.baseline_timestamp else None,
            'comparison_timestamp': self.comparison_timestamp.isoformat() if self.comparison_timestamp else None,
            'drift_score': self.drift_score,
            'health_trend': self.health_trend,
            'summary': {
                'new_failures': self.new_failures_count,
                'resolved': self.resolved_count,
                'escalated': self.escalated_count,
                'deescalated': self.deescalated_count,
                'new_checks': self.new_checks_count,
                'removed_checks': self.removed_checks_count,
                'total_changes': (
                    self.new_failures_count + self.resolved_count +
                    self.escalated_count + self.deescalated_count
                )
            },
            'changes': json.loads(self.changes) if self.changes else {},
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'created_by': self.created_by
        }


class RemediationItem(Base):
    """
    Tracks remediation progress for individual failing audit checks.

    Each item corresponds to a specific check that failed or warned,
    allowing teams to assign, track, and verify fixes.
    """
    __tablename__ = 'remediation_items'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Context
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'), nullable=False, index=True)
    audit_id = Column(Integer, ForeignKey('audits.id', ondelete='CASCADE'), nullable=False, index=True)

    # Finding identification
    check_name = Column(String(255), nullable=False, index=True)
    check_section = Column(String(255), nullable=True)

    # Current status from most recent execution
    current_status = Column(String(20), nullable=False)  # PASS, FAIL, WARN, SKIP
    first_detected_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    last_seen_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    # Linked execution when first detected
    first_execution_id = Column(
        Integer,
        ForeignKey('audit_executions.id', ondelete='SET NULL'),
        nullable=True
    )

    # Remediation tracking
    remediation_status = Column(
        String(30),
        nullable=False,
        default='open',
        index=True
    )  # open, in_progress, resolved, accepted_risk, ignored

    priority = Column(String(20), nullable=False, default='medium')  # critical, high, medium, low
    assigned_to = Column(String(100), nullable=True)

    # Remediation details
    notes = Column(EncryptedField(), nullable=True)
    remediation_steps = Column(EncryptedField(), nullable=True)
    resolution_notes = Column(EncryptedField(), nullable=True)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)

    # Metadata
    created_by = Column(String(100), nullable=True)
    resolved_by = Column(String(100), nullable=True)

    # Relationships
    server = relationship("Server", backref="remediation_items")
    audit = relationship("Audit", backref="remediation_items")
    first_execution = relationship("AuditExecution", backref="remediation_items")

    # Indexes
    __table_args__ = (
        Index('idx_remediation_server_audit', 'server_id', 'audit_id'),
        Index('idx_remediation_status_priority', 'remediation_status', 'priority'),
        Index('idx_remediation_assigned', 'assigned_to'),
        # Unique constraint: one remediation item per check per server/audit combo
        Index('idx_remediation_unique_check', 'server_id', 'audit_id', 'check_name', unique=True),
    )

    def __repr__(self):
        return f"<RemediationItem(id={self.id}, check='{self.check_name}', status='{self.remediation_status}')>"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'server_id': self.server_id,
            'server_name': self.server.name if self.server else None,
            'audit_id': self.audit_id,
            'audit_name': self.audit.name if self.audit else None,
            'check_name': self.check_name,
            'check_section': self.check_section,
            'current_status': self.current_status,
            'first_detected_at': self.first_detected_at.isoformat() if self.first_detected_at else None,
            'last_seen_at': self.last_seen_at.isoformat() if self.last_seen_at else None,
            'first_execution_id': self.first_execution_id,
            'remediation_status': self.remediation_status,
            'priority': self.priority,
            'assigned_to': self.assigned_to,
            'notes': self.notes,
            'remediation_steps': self.remediation_steps,
            'resolution_notes': self.resolution_notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'created_by': self.created_by,
            'resolved_by': self.resolved_by
        }


class RemediationHistory(Base):
    """
    Audit trail for remediation item changes.

    Tracks all status changes, assignments, and updates for compliance.
    """
    __tablename__ = 'remediation_history'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign Key
    remediation_item_id = Column(
        Integer,
        ForeignKey('remediation_items.id', ondelete='CASCADE'),
        nullable=False,
        index=True
    )

    # What changed
    field_changed = Column(String(50), nullable=False)  # status, priority, assigned_to, etc.
    old_value = Column(EncryptedField(), nullable=True)
    new_value = Column(EncryptedField(), nullable=True)

    # Who and when
    changed_by = Column(String(100), nullable=True)
    changed_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    # Optional notes
    comment = Column(EncryptedField(), nullable=True)

    # Relationships
    remediation_item = relationship("RemediationItem", backref="history")

    def __repr__(self):
        return f"<RemediationHistory(id={self.id}, item={self.remediation_item_id}, field='{self.field_changed}')>"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'remediation_item_id': self.remediation_item_id,
            'field_changed': self.field_changed,
            'old_value': self.old_value,
            'new_value': self.new_value,
            'changed_by': self.changed_by,
            'changed_at': self.changed_at.isoformat() if self.changed_at else None,
            'comment': self.comment
        }
