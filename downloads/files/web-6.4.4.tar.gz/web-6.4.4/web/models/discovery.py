"""
Discovery Model - System Discovery Results Storage

Stores discovery results including:
- OS version and system information
- Installed packages/applications
- Running services
- Available updates
- Recommended audits based on discovered software

Author: Security Audit Toolkit Team
Date: March 2026
"""

import json
from datetime import datetime


class DiscoveryResult:
    """
    Discovery result data structure for storing system discovery output

    This model is designed to work with both file-based storage (JSON)
    and can be extended for SQLAlchemy ORM storage.
    """

    def __init__(self, data=None):
        """
        Initialize a discovery result

        Args:
            data: Optional dict to populate from
        """
        if data:
            self.from_dict(data)
        else:
            self.id = None
            self.server_id = None
            self.server_name = None
            self.hostname = None
            self.os_type = 'linux'
            self.timestamp = datetime.utcnow().isoformat()
            self.success = False
            self.error = None

            # System Information (unified with linux-discovery.sh)
            self.system = {
                'hostname': None,
                'fqdn': None,
                'distro': None,
                'distro_family': None,
                'os_name': None,
                'os_version': None,
                'os_pretty_name': None,
                'kernel_version': None,
                'architecture': None,
                'cpu_name': None,
                'cpu_cores': None,
                'total_memory_gb': None,
                'available_memory_gb': None,
                'manufacturer': None,
                'model': None,
                'serial_number': None,
                'is_virtual': None,
                'hypervisor': None,
                'last_boot': None,
                'package_manager': None,
                'init_system': None
            }

            # Legacy os_info for backwards compatibility
            self.os_info = {
                'name': None,
                'version': None,
                'version_id': None,
                'pretty_name': None,
                'id': None,
                'id_like': None,
                'kernel': None,
                'architecture': None
            }

            # Network interfaces
            self.network_interfaces = []  # [{'name': 'eth0', 'ip_address': '...', 'mac_address': '...'}]

            # Storage/disk information
            self.storage = []  # [{'mount_point': '/', 'total_size_gb': 100, 'free_space_gb': 50}]

            # Discovered packages with details
            self.packages = []  # [{'name': 'nginx', 'version': '1.18.0', 'description': 'web server'}]

            # Running services
            self.services = []  # [{'name': 'nginx', 'status': 'running', 'enabled': True}]

            # Available updates
            self.updates = []  # [{'name': 'openssl', 'current': '1.1.1', 'available': '1.1.2'}]

            # Security-related findings
            self.security = {
                'firewall_active': None,
                'firewall_type': None,
                'selinux_status': None,
                'apparmor_status': None,
                'fail2ban_active': None,
                'ssh_root_login': None,
                'password_auth': None  # nosec B105
            }

            # Recommended audits based on discovered software
            self.recommendations = []  # [{'audit_id': 'web/nginx', 'name': 'Nginx Audit', 'reason': '...'}]

    def from_dict(self, data):
        """Load from dictionary - supports both script output and legacy formats"""
        self.id = data.get('id')
        self.server_id = data.get('server_id')
        self.server_name = data.get('server_name')
        self.hostname = data.get('hostname')
        self.os_type = data.get('os_type', 'linux')
        self.timestamp = data.get('timestamp') or data.get('scan_timestamp', datetime.utcnow().isoformat())
        self.success = data.get('success', False)
        self.error = data.get('error')

        # Handle script output format (data.system) vs legacy format (os_info)
        script_data = data.get('data', {})
        if script_data and 'system' in script_data:
            # Script output format - normalize to unified schema
            self.system = script_data.get('system', {})
            self.network_interfaces = script_data.get('network_interfaces', [])
            self.storage = script_data.get('storage', [])
            self.packages = script_data.get('software', [])
            self.services = script_data.get('services', [])
            self.updates = script_data.get('pending_updates', [])
            # Build os_info for backwards compatibility
            self.os_info = {
                'name': self.system.get('os_name'),
                'version': self.system.get('os_version'),
                'version_id': self.system.get('os_version'),
                'pretty_name': self.system.get('os_pretty_name'),
                'id': self.system.get('distro'),
                'id_like': self.system.get('distro_family'),
                'kernel': self.system.get('kernel_version'),
                'architecture': self.system.get('architecture')
            }
        else:
            # Legacy format
            self.system = data.get('system', {})
            self.os_info = data.get('os_info', {})
            self.network_interfaces = data.get('network_interfaces', [])
            self.storage = data.get('storage', [])
            self.packages = data.get('packages', [])
            self.services = data.get('services', [])
            self.updates = data.get('updates', [])

        self.security = data.get('security', {})
        self.recommendations = data.get('recommendations', [])

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'server_id': self.server_id,
            'server_name': self.server_name,
            'hostname': self.hostname,
            'os_type': self.os_type,
            'timestamp': self.timestamp,
            'success': self.success,
            'error': self.error,
            'system': self.system,
            'os_info': self.os_info,
            'network_interfaces': self.network_interfaces,
            'storage': self.storage,
            'packages': self.packages,
            'services': self.services,
            'updates': self.updates,
            'security': self.security,
            'recommendations': self.recommendations
        }

    def get_summary(self):
        """Get a summary of the discovery result"""
        # Try system first (new format), fall back to os_info (legacy)
        os_name = (self.system.get('os_pretty_name') or self.system.get('os_name') or
                   self.os_info.get('pretty_name') or self.os_info.get('name', 'Unknown'))
        os_version = (self.system.get('os_version') or
                      self.os_info.get('version_id') or self.os_info.get('version', ''))
        return {
            'server_name': self.server_name,
            'hostname': self.hostname,
            'os_type': self.os_type,
            'os_name': os_name,
            'os_version': os_version,
            'distro': self.system.get('distro') or self.os_info.get('id'),
            'architecture': self.system.get('architecture') or self.os_info.get('architecture'),
            'is_virtual': self.system.get('is_virtual'),
            'hypervisor': self.system.get('hypervisor'),
            'cpu_cores': self.system.get('cpu_cores'),
            'total_memory_gb': self.system.get('total_memory_gb'),
            'package_count': len(self.packages),
            'service_count': len(self.services),
            'update_count': len(self.updates),
            'network_interface_count': len(self.network_interfaces),
            'storage_volume_count': len(self.storage),
            'recommendation_count': len(self.recommendations),
            'timestamp': self.timestamp,
            'success': self.success
        }


class DiscoveryManager:
    """
    Manager for storing and retrieving discovery results

    Uses JSON file storage for simplicity.
    Can be extended to use database storage.
    """

    def __init__(self, storage_path=None):
        """
        Initialize the discovery manager

        Args:
            storage_path: Path to discovery results JSON file
        """
        import os
        self.storage_path = storage_path or os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            'servers', 'discovery_results.json'
        )
        self._ensure_storage_exists()

    def _ensure_storage_exists(self):
        """Ensure storage file exists"""
        import os
        os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
        if not os.path.exists(self.storage_path):
            with open(self.storage_path, 'w') as f:
                json.dump({'results': []}, f)

    def _load_data(self):
        """Load all results from storage"""
        try:
            with open(self.storage_path, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {'results': []}

    def _save_data(self, data):
        """Save all results to storage"""
        with open(self.storage_path, 'w') as f:
            json.dump(data, f, indent=2, default=str)

    def _get_retention_policy(self):
        """Load retention policy for discovery results from security settings."""
        try:
            from security_settings import get_security_setting
            retention_days = int(get_security_setting('result_retention', 90))
            max_records = int(get_security_setting('result_retention_max_records', 100000))
        except Exception:
            retention_days = 90
            max_records = 100000

        retention_days = max(7, retention_days)
        if max_records < 0:
            max_records = 100000
        return retention_days, max_records

    def _parse_result_timestamp(self, result):
        """Best-effort timestamp parser for result sorting and retention pruning."""
        raw = result.get('timestamp') or result.get('scan_timestamp')
        if not raw:
            return datetime.utcnow()

        if isinstance(raw, datetime):
            return raw

        raw_str = str(raw).replace('Z', '+00:00')
        try:
            return datetime.fromisoformat(raw_str)
        except ValueError:
            return datetime.utcnow()

    def _apply_retention_policy(self, data):
        """Prune discovery results by age and max record count."""
        results = list(data.get('results', []))
        if not results:
            return

        retention_days, max_records = self._get_retention_policy()
        cutoff = datetime.utcnow().timestamp() - (retention_days * 86400)

        filtered = []
        for result in results:
            ts = self._parse_result_timestamp(result).timestamp()
            if ts >= cutoff:
                filtered.append(result)

        filtered.sort(key=self._parse_result_timestamp, reverse=True)
        if max_records > 0:
            data['results'] = filtered[:max_records]
        else:
            data['results'] = filtered

    def save_result(self, result):
        """
        Save a discovery result

        Args:
            result: DiscoveryResult instance or dict

        Returns:
            int: Result ID
        """
        data = self._load_data()

        # Convert to dict if needed
        if isinstance(result, DiscoveryResult):
            result_dict = result.to_dict()
        else:
            result_dict = result

        # Assign ID
        max_id = max([r.get('id', 0) for r in data['results']] or [0])
        result_dict['id'] = max_id + 1

        data['results'].append(result_dict)
        self._apply_retention_policy(data)
        self._save_data(data)

        return result_dict['id']

    def get_result(self, result_id):
        """
        Get a specific discovery result by ID

        Args:
            result_id: Result ID

        Returns:
            DiscoveryResult or None
        """
        data = self._load_data()
        for result in data['results']:
            if result.get('id') == result_id:
                return DiscoveryResult(result)
        return None

    def get_results_by_server(self, server_id, limit=10):
        """
        Get discovery results for a specific server

        Args:
            server_id: Server ID
            limit: Maximum number of results to return

        Returns:
            List of DiscoveryResult instances
        """
        data = self._load_data()
        results = [
            DiscoveryResult(r) for r in data['results']
            if r.get('server_id') == server_id
        ]
        # Sort by timestamp descending
        results.sort(key=lambda x: x.timestamp, reverse=True)
        return results[:limit]

    def get_latest_result_by_server(self, server_id):
        """
        Get the most recent discovery result for a server

        Args:
            server_id: Server ID

        Returns:
            DiscoveryResult or None
        """
        results = self.get_results_by_server(server_id, limit=1)
        return results[0] if results else None

    def get_all_results(self, limit=100):
        """
        Get all discovery results

        Args:
            limit: Maximum number of results

        Returns:
            List of DiscoveryResult instances
        """
        data = self._load_data()
        results = [DiscoveryResult(r) for r in data['results']]
        results.sort(key=lambda x: x.timestamp, reverse=True)
        return results[:limit]

    def delete_result(self, result_id):
        """
        Delete a discovery result

        Args:
            result_id: Result ID

        Returns:
            bool: True if deleted
        """
        data = self._load_data()
        original_count = len(data['results'])
        data['results'] = [r for r in data['results'] if r.get('id') != result_id]

        if len(data['results']) < original_count:
            self._save_data(data)
            return True
        return False

    def delete_results_by_server(self, server_id):
        """
        Delete all discovery results for a server

        Args:
            server_id: Server ID

        Returns:
            int: Number of results deleted
        """
        data = self._load_data()
        original_count = len(data['results'])
        data['results'] = [r for r in data['results'] if r.get('server_id') != server_id]
        deleted_count = original_count - len(data['results'])

        if deleted_count > 0:
            self._save_data(data)
        return deleted_count


# Global instance
discovery_manager = DiscoveryManager()
