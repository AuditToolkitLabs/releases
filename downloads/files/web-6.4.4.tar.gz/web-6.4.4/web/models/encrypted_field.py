"""SQLAlchemy TypeDecorator for automatic field encryption/decryption.

Cross-platform and database-agnostic (PostgreSQL, SQLite, etc.).
Values are stored as encrypted text payloads using Fernet and a versioned
prefix marker to support migration-safe behavior.
"""

import json
import logging
import os
from pathlib import Path

from cryptography.fernet import Fernet
from sqlalchemy import String, Text
from sqlalchemy.types import TypeDecorator

logger = logging.getLogger(__name__)


class EncryptedField(TypeDecorator):
    """
    SQLAlchemy column type that automatically encrypts/decrypts values.

    Encryption is transparent to application code:
    - Values are encrypted on write and decrypted on read
    - Ciphertext is marked with a versioned prefix
    - Legacy plaintext rows remain readable for migration compatibility

    Usage in model:
    ```python
    from models.encrypted_field import EncryptedField

    class Discovery(Base):
        hostname = EncryptedField()
        ip_address = EncryptedField()
        credentials = EncryptedField()
    ```

    Environment Setup:
    ```bash
    # Generate a new encryption key
    export ENCRYPTION_KEY=$(python -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')
    ```

    Key Rotation:
    ```python
    # When rotating keys:
    # 1. Set NEW_ENCRYPTION_KEY in environment
    # 2. Query all records with old cipher
    # 3. Update record.field = record.field (triggers re-encryption with new key)
    # 4. Commit changes (new key encrypts data)
    ```
    """

    impl = Text
    cache_ok = True
    ENCRYPTED_PREFIX = "enc:v1:"

    _cipher_cache = None
    _cipher_cache_loaded = False
    _missing_key_warned = False
    _fallback_key_warned = False

    def __init__(self, length: int = None):
        super().__init__()
        self.length = length

    @classmethod
    def clear_cache(cls):
        """Clear cached cipher state (useful for tests)."""
        cls._cipher_cache = None
        cls._cipher_cache_loaded = False
        cls._missing_key_warned = False
        cls._fallback_key_warned = False

    def load_dialect_impl(self, dialect):
        if self.length:
            return dialect.type_descriptor(String(self.length))
        return dialect.type_descriptor(Text())

    @classmethod
    def _is_production_env(cls) -> bool:
        flask_env = os.environ.get('FLASK_ENV', '').strip().lower()
        runtime_env = os.environ.get('ENVIRONMENT', '').strip().lower()
        return flask_env == 'production' or runtime_env == 'production'

    @classmethod
    def _is_strict_mode(cls) -> bool:
        strict = os.environ.get('DB_ENCRYPTION_STRICT')
        if strict is None:
            return cls._is_production_env()
        return strict.strip().lower() == 'true'

    @classmethod
    def _allow_keystore_fallback(cls) -> bool:
        fallback = os.environ.get('DB_FIELD_ENCRYPTION_ALLOW_KEYSTORE_FALLBACK')
        if fallback is not None:
            return fallback.strip().lower() == 'true'

        if cls._is_production_env() or cls._is_strict_mode():
            return False

        return True

    @classmethod
    def _candidate_key_paths(cls) -> list[Path]:
        if not cls._allow_keystore_fallback():
            return []

        explicit = os.environ.get('KEYSTORE_MASTER_KEY_PATH')
        if explicit:
            return [Path(explicit)]

        repo_root = Path(__file__).resolve().parent.parent.parent
        return [repo_root / 'settings' / '.keystore_master']

    @classmethod
    def _resolve_key_bytes(cls):
        env_key = os.environ.get('DB_FIELD_ENCRYPTION_KEY') or os.environ.get('ENCRYPTION_KEY')
        if env_key:
            return env_key.encode('utf-8')

        for candidate in cls._candidate_key_paths():
            try:
                if candidate.exists():
                    if not cls._fallback_key_warned:
                        logger.warning(
                            "Using keystore master key fallback for DB field encryption; "
                            "set DB_FIELD_ENCRYPTION_KEY to isolate key material"
                        )
                        cls._fallback_key_warned = True
                    return candidate.read_bytes()
            except Exception as exc:
                logger.warning(f"Failed reading encryption key file {candidate}: {exc}")
        return None

    @classmethod
    def _get_cipher(cls):
        if cls._cipher_cache_loaded:
            return cls._cipher_cache

        key = cls._resolve_key_bytes()
        if not key:
            if not cls._missing_key_warned:
                logger.warning("Database field encryption key not configured")
                cls._missing_key_warned = True
            cls._cipher_cache = None
            cls._cipher_cache_loaded = True
            return None

        try:
            cls._cipher_cache = Fernet(key)
            cls._cipher_cache_loaded = True
            return cls._cipher_cache
        except Exception as exc:
            logger.error(f"Failed to initialize database field cipher: {exc}")
            cls._cipher_cache = None
            cls._cipher_cache_loaded = True
            return None

    @classmethod
    def _serialize_value(cls, value):
        if isinstance(value, str):
            return value
        return json.dumps(value, separators=(',', ':'))

    @classmethod
    def _deserialize_value(cls, value: str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value

    def process_bind_param(self, value, dialect):
        """Encrypt values before writing to database."""
        if value is None:
            return None

        raw_value = self._serialize_value(value)

        if raw_value.startswith(self.ENCRYPTED_PREFIX):
            return raw_value

        cipher = self._get_cipher()
        if not cipher:
            if self._is_strict_mode():
                raise ValueError("Database field encryption key is required")
            return raw_value

        try:
            encrypted_bytes = cipher.encrypt(raw_value.encode('utf-8'))
            return f"{self.ENCRYPTED_PREFIX}{encrypted_bytes.decode('utf-8')}"
        except Exception as exc:
            logger.error(f"Encryption failed: {exc}")
            raise ValueError(f"Encryption failed: {exc}")

    def process_result_value(self, value, dialect):
        """Decrypt values when reading from database."""
        if value is None:
            return None

        if not isinstance(value, str):
            return value

        if not value.startswith(self.ENCRYPTED_PREFIX):
            return self._deserialize_value(value)

        cipher = self._get_cipher()
        if not cipher:
            if self._is_strict_mode():
                raise ValueError("Database field encryption key is required")
            return value

        try:
            token = value[len(self.ENCRYPTED_PREFIX):]
            decrypted_bytes = cipher.decrypt(token.encode('utf-8'))
            decrypted_str = decrypted_bytes.decode('utf-8')
            return self._deserialize_value(decrypted_str)
        except Exception as exc:
            if self._is_strict_mode():
                raise ValueError(f"Decryption failed: {exc}")
            logger.warning(f"Decryption failed, returning raw value: {exc}")
            return value
