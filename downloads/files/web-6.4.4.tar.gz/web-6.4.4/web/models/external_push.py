"""
ORM models for the External Push Ingest API (Data-From-Anywhere R2).

ExternalFinding  - Security findings pushed from third-party scanners / CI pipelines.
ExternalAsset    - Asset / inventory records pushed from CMDBs or cloud discovery feeds.

Both tables are independent of the internal Server / AuditExecution tables so that
external data never pollutes the toolkit's own audit data lineage.
"""

from datetime import datetime

from sqlalchemy import Column, Float, Index, Integer, String, Text, DateTime

from .database import Base
from .encrypted_field import EncryptedField


class ExternalFinding(Base):
    """A security finding pushed from an external tool via the ingest API."""

    __tablename__ = "external_findings"

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Stable identifier assigned at ingest time (UUID4 hex)
    ingest_id = Column(String(36), unique=True, nullable=False, index=True)

    # Which registered producer sent this finding
    producer_id = Column(String(36), nullable=False, index=True)

    # Source tool metadata (e.g. "Nessus", "Trivy", "SonarQube")
    source_tool = Column(String(120), nullable=True)
    source_version = Column(String(80), nullable=True)

    # Finding content
    title = Column(String(500), nullable=False)
    severity = Column(String(20), nullable=False)      # critical/high/medium/low/info
    description = Column(Text, nullable=True)
    remediation = Column(Text, nullable=True)

    # Target asset (may not be registered in the servers table)
    asset_hostname = Column(String(255), nullable=True, index=True)
    asset_ip = Column(String(45), nullable=True)
    asset_tags = Column(Text, nullable=True)           # JSON blob

    # Vulnerability references
    cve_ids = Column(Text, nullable=True)              # JSON array: ["CVE-2024-1234"]
    cvss_score = Column(Float, nullable=True)
    plugin_id = Column(String(100), nullable=True)

    # External reference back to the originating tool
    external_id = Column(String(255), nullable=True)
    external_url = Column(String(500), nullable=True)

    # Lifecycle status
    status = Column(String(30), nullable=False, default="open")  # open/resolved/suppressed

    # Full raw payload stored encrypted so the original record is always recoverable
    raw_payload = Column(EncryptedField(), nullable=True)

    # Timestamps
    finding_timestamp = Column(DateTime, nullable=True)            # when the issue was found
    received_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        Index("idx_ext_findings_producer_severity", "producer_id", "severity"),
        Index("idx_ext_findings_asset_hostname", "asset_hostname"),
        Index("idx_ext_findings_status_received", "status", "received_at"),
    )

    def to_dict(self) -> dict:
        return {
            "ingest_id": self.ingest_id,
            "producer_id": self.producer_id,
            "source_tool": self.source_tool,
            "source_version": self.source_version,
            "title": self.title,
            "severity": self.severity,
            "description": self.description,
            "remediation": self.remediation,
            "asset_hostname": self.asset_hostname,
            "asset_ip": self.asset_ip,
            "asset_tags": self.asset_tags,
            "cve_ids": self.cve_ids,
            "cvss_score": self.cvss_score,
            "plugin_id": self.plugin_id,
            "external_id": self.external_id,
            "external_url": self.external_url,
            "status": self.status,
            "finding_timestamp": self.finding_timestamp.isoformat() if self.finding_timestamp else None,
            "received_at": self.received_at.isoformat() if self.received_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ExternalAsset(Base):
    """An asset / inventory record pushed from an external CMDB or cloud discovery feed."""

    __tablename__ = "external_assets"

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Stable identifier assigned at ingest time (UUID4 hex)
    asset_id = Column(String(36), unique=True, nullable=False, index=True)

    # Which registered producer sent this asset
    producer_id = Column(String(36), nullable=False, index=True)

    # Core identity
    hostname = Column(String(255), nullable=False, index=True)
    ip_addresses = Column(Text, nullable=True)          # JSON array
    mac_addresses = Column(Text, nullable=True)         # JSON array

    # OS
    os_name = Column(String(100), nullable=True)
    os_version = Column(String(100), nullable=True)

    # Classification
    asset_type = Column(String(50), nullable=True)      # server/workstation/network/iot/cloud
    environment = Column(String(50), nullable=True)     # production/staging/dev/test
    owner = Column(String(255), nullable=True)
    tags = Column(Text, nullable=True)                  # JSON blob

    # Source metadata
    source_tool = Column(String(120), nullable=True)
    external_id = Column(String(255), nullable=True)

    # Lifecycle status
    status = Column(String(30), nullable=False, default="active")  # active/decommissioned

    # Full raw payload stored encrypted
    raw_payload = Column(EncryptedField(), nullable=True)

    # Timestamps
    first_seen_at = Column(DateTime, nullable=True)
    last_seen_at = Column(DateTime, nullable=True)
    received_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        Index("idx_ext_assets_producer", "producer_id"),
        Index("idx_ext_assets_hostname", "hostname"),
        Index("idx_ext_assets_status", "status"),
    )

    def to_dict(self) -> dict:
        return {
            "asset_id": self.asset_id,
            "producer_id": self.producer_id,
            "hostname": self.hostname,
            "ip_addresses": self.ip_addresses,
            "mac_addresses": self.mac_addresses,
            "os_name": self.os_name,
            "os_version": self.os_version,
            "asset_type": self.asset_type,
            "environment": self.environment,
            "owner": self.owner,
            "tags": self.tags,
            "source_tool": self.source_tool,
            "external_id": self.external_id,
            "status": self.status,
            "first_seen_at": self.first_seen_at.isoformat() if self.first_seen_at else None,
            "last_seen_at": self.last_seen_at.isoformat() if self.last_seen_at else None,
            "received_at": self.received_at.isoformat() if self.received_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
