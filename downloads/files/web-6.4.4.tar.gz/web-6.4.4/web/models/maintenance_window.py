#!/usr/bin/env python3
"""
Maintenance Window Model - Database model for blackout periods

Defines time windows when scheduled audits should not run,
supporting both one-time and recurring maintenance windows.

Author: Security Audit Toolkit Team
Date: February 10, 2026
"""

from datetime import datetime, timedelta
from importlib import import_module
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime,
    ForeignKey, Text
)
from sqlalchemy.orm import relationship
from .database import Base
from .encrypted_field import EncryptedField
import enum


def _resolve_server_model():
    """Resolve Server within the active models package."""
    return import_module(f"{__package__}.database").Server


class WindowType(enum.Enum):
    """Types of maintenance windows"""
    ONE_TIME = "one_time"  # Single occurrence with start/end times
    RECURRING = "recurring"  # Weekly recurring (e.g., every Sunday 2-6 AM)
    DAILY = "daily"  # Daily recurring window


class MaintenanceWindow(Base):
    """
    Maintenance Window Model

    Defines blackout periods when scheduled audits should be paused.
    Can be global (all servers) or server-specific.

    Attributes:
        id: Unique identifier
        name: Human-readable name (e.g., "Weekly Patching Window")
        description: Optional description
        window_type: one_time, recurring, or daily

        # For one-time windows:
        start_time: Start of maintenance window
        end_time: End of maintenance window

        # For recurring windows:
        day_of_week: 0=Monday, 6=Sunday (for weekly recurring)
        start_hour: Hour of day to start (0-23)
        start_minute: Minute to start (0-59)
        duration_minutes: How long the window lasts

        # Scope:
        server_id: If set, applies only to this server
        is_global: If true, applies to all servers

        # Status:
        is_active: Enable/disable this window

        # Metadata:
        created_at: Creation timestamp
        updated_at: Last update timestamp
        created_by: Username who created
    """
    __tablename__ = 'maintenance_windows'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    window_type = Column(String(20), nullable=False, default='one_time')

    # One-time window fields
    start_time = Column(DateTime)  # UTC
    end_time = Column(DateTime)  # UTC

    # Recurring window fields
    day_of_week = Column(Integer)  # 0=Monday, 6=Sunday
    start_hour = Column(Integer)  # 0-23
    start_minute = Column(Integer, default=0)  # 0-59
    duration_minutes = Column(Integer, default=60)  # Duration in minutes

    # Scope
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'))
    is_global = Column(Boolean, default=False, nullable=False)

    # Status
    is_active = Column(Boolean, default=True, nullable=False)

    # Metadata / Audit Trail
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    created_by = Column(String(100))
    updated_by = Column(String(100))  # Track who last modified

    # Relationships
    server = relationship(_resolve_server_model, back_populates='maintenance_windows')

    def __init__(self, **kwargs):
        daily_start_time = kwargs.pop('daily_start_time', None)
        daily_end_time = kwargs.pop('daily_end_time', None)
        recurrence_days = kwargs.pop('recurrence_days', None)

        super().__init__(**kwargs)

        if daily_start_time is not None:
            self.daily_start_time = daily_start_time
        if recurrence_days is not None:
            self.recurrence_days = recurrence_days
        if daily_end_time is not None:
            self.daily_end_time = daily_end_time

    @staticmethod
    def _parse_hhmm(value):
        hour_str, minute_str = str(value).split(':', 1)
        hour = int(hour_str)
        minute = int(minute_str)
        if hour < 0 or hour > 23 or minute < 0 or minute > 59:
            raise ValueError("time must be in HH:MM 24-hour format")
        return hour, minute

    @property
    def daily_start_time(self):
        if self.start_hour is None:
            return None
        minute = self.start_minute or 0
        return f"{int(self.start_hour):02d}:{int(minute):02d}"

    @daily_start_time.setter
    def daily_start_time(self, value):
        hour, minute = self._parse_hhmm(value)
        self.start_hour = hour
        self.start_minute = minute

    @property
    def daily_end_time(self):
        if self.start_hour is None:
            return None
        duration = self.duration_minutes or 60
        end_minutes = ((self.start_hour * 60) + (self.start_minute or 0) + duration) % (24 * 60)
        return f"{end_minutes // 60:02d}:{end_minutes % 60:02d}"

    @daily_end_time.setter
    def daily_end_time(self, value):
        end_hour, end_minute = self._parse_hhmm(value)
        if self.start_hour is None:
            self.start_hour = 0
            self.start_minute = 0
        start_total = (self.start_hour * 60) + (self.start_minute or 0)
        end_total = (end_hour * 60) + end_minute
        if end_total <= start_total:
            end_total += 24 * 60
        self.duration_minutes = end_total - start_total

    @property
    def recurrence_days(self):
        if hasattr(self, '_recurrence_days_override'):
            return self._recurrence_days_override
        if self.day_of_week is None:
            return None
        return str(self.day_of_week)

    @recurrence_days.setter
    def recurrence_days(self, value):
        value_str = str(value)
        self._recurrence_days_override = value_str
        try:
            first_day = value_str.split(',', 1)[0].strip()
            if first_day:
                parsed_day = int(first_day)
                if 0 <= parsed_day <= 6:
                    self.day_of_week = parsed_day
        except ValueError:
            pass

    def to_dict(self):
        """Convert to dictionary representation"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'window_type': self.window_type,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'day_of_week': self.day_of_week,
            'day_of_week_name': self.get_day_name(),
            'start_hour': self.start_hour,
            'start_minute': self.start_minute,
            'duration_minutes': self.duration_minutes,
            'server_id': self.server_id,
            'server_name': self.server.name if self.server else None,
            'is_global': self.is_global,
            'is_active': self.is_active,
            'is_currently_active': self.is_in_window(),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

    def get_day_name(self):
        """Get human-readable day name"""
        if self.day_of_week is None:
            return None
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        return days[self.day_of_week] if 0 <= self.day_of_week <= 6 else None

    def is_in_window(self, check_time=None):
        """
        Check if the given time falls within this maintenance window

        Args:
            check_time: datetime to check (default: now)

        Returns:
            bool: True if currently in maintenance window
        """
        if not self.is_active:
            return False

        if check_time is None:
            check_time = datetime.utcnow()

        if self.window_type == 'one_time':
            if self.start_time and self.end_time:
                return self.start_time <= check_time <= self.end_time
            return False

        elif self.window_type == 'recurring':
            # Weekly recurring
            if self.day_of_week is None or self.start_hour is None:
                return False

            # Check if it's the right day
            if check_time.weekday() != self.day_of_week:
                return False

            # Check if we're in the time window
            window_start = check_time.replace(
                hour=self.start_hour,
                minute=self.start_minute or 0,
                second=0,
                microsecond=0
            )
            window_end = window_start + timedelta(minutes=self.duration_minutes or 60)

            return window_start <= check_time <= window_end

        elif self.window_type == 'daily':
            # Daily recurring - check time only
            if self.start_hour is None:
                return False

            window_start = check_time.replace(
                hour=self.start_hour,
                minute=self.start_minute or 0,
                second=0,
                microsecond=0
            )
            window_end = window_start + timedelta(minutes=self.duration_minutes or 60)

            return window_start <= check_time <= window_end

        return False

    def get_next_window(self, from_time=None):
        """
        Calculate when the next maintenance window starts

        Args:
            from_time: Start time for calculation (default: now)

        Returns:
            tuple: (start_time, end_time) or (None, None) if no next window
        """
        if from_time is None:
            from_time = datetime.utcnow()

        if self.window_type == 'one_time':
            if self.start_time and self.start_time > from_time:
                return (self.start_time, self.end_time)
            return (None, None)

        elif self.window_type == 'recurring':
            if self.day_of_week is None or self.start_hour is None:
                return (None, None)

            # Find next occurrence of this day
            days_ahead = self.day_of_week - from_time.weekday()
            if days_ahead < 0:  # Already past this week
                days_ahead += 7
            elif days_ahead == 0:
                # Same day - check if window already passed
                window_end_today = from_time.replace(
                    hour=self.start_hour,
                    minute=self.start_minute or 0,
                    second=0,
                    microsecond=0
                ) + timedelta(minutes=self.duration_minutes or 60)
                if from_time > window_end_today:
                    days_ahead = 7

            next_start = from_time.replace(
                hour=self.start_hour,
                minute=self.start_minute or 0,
                second=0,
                microsecond=0
            ) + timedelta(days=days_ahead)
            next_end = next_start + timedelta(minutes=self.duration_minutes or 60)

            return (next_start, next_end)

        elif self.window_type == 'daily':
            if self.start_hour is None:
                return (None, None)

            # Check if today's window is in the future
            next_start = from_time.replace(
                hour=self.start_hour,
                minute=self.start_minute or 0,
                second=0,
                microsecond=0
            )

            if next_start <= from_time:
                # Today's window passed, use tomorrow
                next_start += timedelta(days=1)

            next_end = next_start + timedelta(minutes=self.duration_minutes or 60)
            return (next_start, next_end)

        return (None, None)


class ScheduleExecutionLog(Base):
    """
    Schedule Execution Log

    Records each execution of a scheduled audit for history tracking.

    Attributes:
        id: Log entry ID
        schedule_id: Reference to ScheduledAudit
        scheduled_time: When it was supposed to run
        actual_start: When it actually started
        actual_end: When it completed
        status: 'success', 'failure', 'skipped', 'cancelled'
        skip_reason: Why it was skipped (e.g., "maintenance window")
        execution_id: Reference to audit_executions table
        error_message: Error details if failed
    """
    __tablename__ = 'schedule_execution_logs'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    schedule_id = Column(Integer, ForeignKey(
        'scheduled_audits.id', ondelete='CASCADE', use_alter=True
    ), nullable=False, index=True)

    # Timing
    scheduled_time = Column(DateTime, nullable=False)
    actual_start = Column(DateTime)
    actual_end = Column(DateTime)

    # Result
    status = Column(String(50), nullable=False)  # success, failure, skipped, cancelled
    skip_reason = Column(String(255))  # maintenance_window, server_offline, manual_cancel
    maintenance_window_id = Column(Integer, ForeignKey('maintenance_windows.id', ondelete='SET NULL'))  # Track which window blocked
    execution_id = Column(Integer, ForeignKey('audit_executions.id', ondelete='SET NULL'))
    error_message = Column(EncryptedField())

    # Task tracking
    celery_task_id = Column(String(100))

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        """Convert to dictionary representation"""
        return {
            'id': self.id,
            'schedule_id': self.schedule_id,
            'scheduled_time': self.scheduled_time.isoformat() if self.scheduled_time else None,
            'actual_start': self.actual_start.isoformat() if self.actual_start else None,
            'actual_end': self.actual_end.isoformat() if self.actual_end else None,
            'status': self.status,
            'skip_reason': self.skip_reason,
            'maintenance_window_id': self.maintenance_window_id,
            'execution_id': self.execution_id,
            'error_message': self.error_message,
            'celery_task_id': self.celery_task_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'duration_seconds': self._calculate_duration()
        }

    def _calculate_duration(self):
        """Calculate execution duration in seconds"""
        if self.actual_start and self.actual_end:
            return (self.actual_end - self.actual_start).total_seconds()
        return None


def is_in_maintenance_window(server_id=None, check_time=None):
    """
    Check if any maintenance window is currently active

    Args:
        server_id: Specific server ID to check (also checks global windows)
        check_time: Time to check (default: now)

    Returns:
        tuple: (is_in_window, window_name, window_id) or (False, None, None)
    """
    from config import SessionLocal

    if check_time is None:
        check_time = datetime.utcnow()

    db = SessionLocal()
    try:
        # Query active windows (global or for this server)
        query = db.query(MaintenanceWindow).filter(
            MaintenanceWindow.is_active.is_(True)
        )

        if server_id:
            query = query.filter(
                (MaintenanceWindow.is_global.is_(True)) |
                (MaintenanceWindow.server_id == server_id)
            )
        else:
            query = query.filter(MaintenanceWindow.is_global.is_(True))

        windows = query.all()

        for window in windows:
            if window.is_in_window(check_time):
                return (True, window.name, window.id)

        return (False, None, None)

    finally:
        db.close()


def get_active_windows(server_id=None):
    """
    Get all currently active maintenance windows

    Args:
        server_id: Filter by server ID (also includes global windows)

    Returns:
        list: List of MaintenanceWindow objects that are currently in their window
    """
    from config import SessionLocal

    db = SessionLocal()
    try:
        query = db.query(MaintenanceWindow).filter(
            MaintenanceWindow.is_active.is_(True)
        )

        if server_id:
            query = query.filter(
                (MaintenanceWindow.is_global.is_(True)) |
                (MaintenanceWindow.server_id == server_id)
            )

        windows = query.all()
        check_time = datetime.utcnow()

        return [w for w in windows if w.is_in_window(check_time)]

    finally:
        db.close()
