"""
Remediation Models

Database models for the SuperAdmin-only Remediation Panel:
- RemediationExecution: Track all fix executions with full audit trail
- RemediationSettings: Global configuration for the remediation feature

Supports Linux, Windows, and Hypervisor targets.
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, Boolean,
    DateTime, ForeignKey, Index, JSON, Time
)
from sqlalchemy.orm import declarative_base, relationship

from .encrypted_field import EncryptedField

try:
    from models.database import Base
except ImportError:
    Base = declarative_base()


class RemediationExecution(Base):
    """
    Track all remediation executions for audit purposes.

    Every fix execution (dry-run or apply) is logged with:
    - Who executed it (user, IP, session)
    - What was executed (fix ID, category, command)
    - Where it was executed (server, OS type)
    - When it was executed (start/end timestamps)
    - What happened (status, output, exit code)
    - Rollback capability (if supported by the fix)
    """
    __tablename__ = 'remediation_executions'
    __table_args__ = (
        Index('idx_remediation_user', 'user_id'),
        Index('idx_remediation_server', 'server_id'),
        Index('idx_remediation_fix', 'fix_id'),
        Index('idx_remediation_status', 'status'),
        Index('idx_remediation_executed_at', 'executed_at'),
        Index('idx_remediation_os_type', 'os_type'),
        {'extend_existing': True}
    )

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # ========================================================================
    # WHO: User and Session Information
    # ========================================================================
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    client_ip = Column(String(45), nullable=False)  # IPv4 or IPv6
    user_agent = Column(String(500), nullable=True)
    session_id = Column(String(100), nullable=True)

    # ========================================================================
    # WHAT: Fix Details
    # ========================================================================
    fix_id = Column(String(50), nullable=False, index=True)  # e.g., "SSH-001", "ESXI-001"
    fix_category = Column(String(100), nullable=True)  # e.g., "ssh", "esxi", "proxmox"
    fix_name = Column(String(255), nullable=True)  # Human-readable name
    fix_description = Column(Text, nullable=True)
    cis_control = Column(String(50), nullable=True)  # e.g., "5.2.1", "4.1.3"
    severity = Column(String(20), nullable=True)  # critical, high, medium, low

    # ========================================================================
    # WHERE: Target Server Information
    # ========================================================================
    server_id = Column(Integer, ForeignKey('servers.id'), nullable=False)
    server_hostname = Column(String(255), nullable=True)  # Cached for history display
    os_type = Column(String(50), nullable=False)  # linux, windows, esxi, kvm, proxmox, nutanix, xen
    os_version = Column(String(100), nullable=True)  # e.g., "Ubuntu 22.04", "Windows Server 2022"

    # ========================================================================
    # HOW: Execution Details
    # ========================================================================
    mode = Column(String(20), nullable=False)  # 'dry-run' or 'apply'
    command_executed = Column(EncryptedField(), nullable=False)  # Full command (encrypted at rest)

    # ========================================================================
    # WHEN: Timestamps
    # ========================================================================
    executed_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    duration_seconds = Column(Integer, nullable=True)  # Calculated on completion

    # ========================================================================
    # RESULT: Execution Outcome
    # ========================================================================
    status = Column(String(20), nullable=False, default='pending')
    # Status values: pending, running, success, failed, timeout, rolled_back, cancelled

    exit_code = Column(Integer, nullable=True)
    stdout = Column(EncryptedField(), nullable=True)
    stderr = Column(EncryptedField(), nullable=True)
    error_message = Column(EncryptedField(), nullable=True)  # User-friendly error (encrypted at rest)

    # Parsed results (JSON)
    # {"passed": 1, "warned": 0, "failed": 0, "skipped": 0, "details": [...]}
    parsed_results = Column(JSON, nullable=True)

    # ========================================================================
    # ROLLBACK: Undo Capability
    # ========================================================================
    rollback_available = Column(Boolean, default=False)
    rollback_data = Column(JSON, nullable=True)  # Backup paths, original values, etc.
    rolled_back_at = Column(DateTime, nullable=True)
    rolled_back_by_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    rollback_execution_id = Column(Integer, nullable=True)  # Link to rollback execution record

    # ========================================================================
    # BATCH EXECUTION: Group multiple fixes
    # ========================================================================
    batch_id = Column(String(36), nullable=True, index=True)  # UUID for batch executions
    batch_sequence = Column(Integer, nullable=True)  # Order within batch

    # ========================================================================
    # RELATIONSHIPS
    # ========================================================================
    user = relationship('User', foreign_keys=[user_id], backref='remediation_executions')
    rolled_back_by = relationship('User', foreign_keys=[rolled_back_by_id])
    server = relationship('Server', backref='remediation_executions')

    def __repr__(self):
        return f"<RemediationExecution(id={self.id}, fix='{self.fix_id}', server='{self.server_hostname}', status='{self.status}')>"

    def to_dict(self, include_output=False):
        """Convert to dictionary for JSON serialization."""
        data = {
            'id': self.id,
            'user_id': self.user_id,
            'fix_id': self.fix_id,
            'fix_category': self.fix_category,
            'fix_name': self.fix_name,
            'fix_description': self.fix_description,
            'cis_control': self.cis_control,
            'severity': self.severity,
            'server_id': self.server_id,
            'server_hostname': self.server_hostname,
            'os_type': self.os_type,
            'os_version': self.os_version,
            'mode': self.mode,
            'status': self.status,
            'exit_code': self.exit_code,
            'error_message': self.error_message,
            'parsed_results': self.parsed_results,
            'rollback_available': self.rollback_available,
            'executed_at': self.executed_at.isoformat() if self.executed_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'duration_seconds': self.duration_seconds,
            'batch_id': self.batch_id,
            'batch_sequence': self.batch_sequence,
            'client_ip': self.client_ip,
        }

        if include_output:
            data['stdout'] = self.stdout
            data['stderr'] = self.stderr
            data['command_executed'] = self.command_executed
            data['rollback_data'] = self.rollback_data

        return data


class RemediationSettings(Base):
    """
    Global settings for the remediation feature.

    Singleton table - only one row should exist (id=1).
    Settings are cached in memory and refreshed periodically.
    """
    __tablename__ = 'remediation_settings'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, autoincrement=True)

    # ========================================================================
    # FEATURE TOGGLES
    # ========================================================================
    enabled = Column(Boolean, default=False, nullable=False)
    require_dry_run_first = Column(Boolean, default=True, nullable=False)
    require_approval = Column(Boolean, default=False, nullable=False)  # Future: workflow

    # ========================================================================
    # ACCESS RESTRICTIONS (Time-based)
    # ========================================================================
    allowed_hours_start = Column(Time, nullable=True)  # e.g., 09:00
    allowed_hours_end = Column(Time, nullable=True)    # e.g., 17:00
    allowed_days = Column(JSON, default=[0, 1, 2, 3, 4])  # Mon=0 through Fri=4
    timezone = Column(String(50), default='UTC', nullable=False)

    # IP Restrictions (separate from terminal IP allowlist)
    ip_allowlist = Column(JSON, default=[])  # Empty = allow all SuperAdmins

    # ========================================================================
    # SAFETY SETTINGS
    # ========================================================================
    max_fixes_per_hour = Column(Integer, default=20, nullable=False)
    max_concurrent_executions = Column(Integer, default=3, nullable=False)
    execution_timeout_seconds = Column(Integer, default=300, nullable=False)  # 5 min default

    # Blacklisted fixes (too dangerous to run from UI)
    blacklisted_fix_ids = Column(JSON, default=[])

    # Require specific confirmation for certain categories
    high_risk_categories = Column(JSON, default=['kernel', 'firewall', 'selinux', 'apparmor'])

    # ========================================================================
    # PLATFORM-SPECIFIC SETTINGS
    # ========================================================================
    # Linux
    linux_enabled = Column(Boolean, default=True, nullable=False)
    linux_fix_path = Column(String(500), default='/opt/audit-toolkit/fix/linux', nullable=False)

    # Windows
    windows_enabled = Column(Boolean, default=True, nullable=False)
    windows_fix_path = Column(String(500), default='C:\\audit-toolkit\\fix\\windows', nullable=False)

    # Hypervisors
    hypervisor_enabled = Column(Boolean, default=True, nullable=False)
    hypervisor_fix_path = Column(String(500), default='/opt/audit-toolkit/fix/hypervisors', nullable=False)

    # Auto-deploy fix scripts to targets
    auto_deploy_scripts = Column(Boolean, default=True, nullable=False)

    # ========================================================================
    # NOTIFICATION SETTINGS
    # ========================================================================
    notify_on_execution = Column(Boolean, default=True, nullable=False)
    notify_on_failure = Column(Boolean, default=True, nullable=False)
    notification_emails = Column(JSON, default=[])
    slack_webhook_url = Column(String(500), nullable=True)

    # ========================================================================
    # METADATA
    # ========================================================================
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by_id = Column(Integer, ForeignKey('users.id'), nullable=True)

    # Relationships
    updated_by = relationship('User', backref='remediation_settings_updates')

    def __repr__(self):
        return f"<RemediationSettings(id={self.id}, enabled={self.enabled})>"

    def to_dict(self, include_sensitive=False):
        """Convert to dictionary for JSON serialization."""
        data = {
            'enabled': self.enabled,
            'require_dry_run_first': self.require_dry_run_first,
            'require_approval': self.require_approval,
            'allowed_hours_start': str(self.allowed_hours_start) if self.allowed_hours_start else None,
            'allowed_hours_end': str(self.allowed_hours_end) if self.allowed_hours_end else None,
            'allowed_days': self.allowed_days or [0, 1, 2, 3, 4],
            'timezone': self.timezone,
            'max_fixes_per_hour': self.max_fixes_per_hour,
            'max_concurrent_executions': self.max_concurrent_executions,
            'execution_timeout_seconds': self.execution_timeout_seconds,
            'blacklisted_fix_ids': self.blacklisted_fix_ids or [],
            'high_risk_categories': self.high_risk_categories or [],
            'linux_enabled': self.linux_enabled,
            'linux_fix_path': self.linux_fix_path,
            'windows_enabled': self.windows_enabled,
            'windows_fix_path': self.windows_fix_path,
            'hypervisor_enabled': self.hypervisor_enabled,
            'hypervisor_fix_path': self.hypervisor_fix_path,
            'auto_deploy_scripts': self.auto_deploy_scripts,
            'notify_on_execution': self.notify_on_execution,
            'notify_on_failure': self.notify_on_failure,
            'notification_emails': self.notification_emails or [],
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }

        if include_sensitive:
            data['ip_allowlist'] = self.ip_allowlist or []
            data['slack_webhook_url'] = self.slack_webhook_url

        return data

    @classmethod
    def get_settings(cls, session):
        """Get or create the singleton settings record."""
        settings = session.query(cls).filter_by(id=1).first()
        if not settings:
            settings = cls(id=1)
            session.add(settings)
            session.commit()
        return settings


# ============================================================================
# FIX CATALOG: Static metadata about available fixes
# ============================================================================

# OS Type constants
OS_TYPE_LINUX = 'linux'
OS_TYPE_WINDOWS = 'windows'
OS_TYPE_ESXI = 'esxi'
OS_TYPE_KVM = 'kvm'
OS_TYPE_PROXMOX = 'proxmox'
OS_TYPE_NUTANIX = 'nutanix'
OS_TYPE_XEN = 'xen'

SUPPORTED_OS_TYPES = [
    OS_TYPE_LINUX,
    OS_TYPE_WINDOWS,
    OS_TYPE_ESXI,
    OS_TYPE_KVM,
    OS_TYPE_PROXMOX,
    OS_TYPE_NUTANIX,
    OS_TYPE_XEN,
]

# Category to OS mapping
CATEGORY_OS_MAP = {
    # Linux categories
    'ssh': OS_TYPE_LINUX,
    'pam': OS_TYPE_LINUX,
    'kernel': OS_TYPE_LINUX,
    'network': OS_TYPE_LINUX,
    'permissions': OS_TYPE_LINUX,
    'audit': OS_TYPE_LINUX,
    'session': OS_TYPE_LINUX,
    'mac': OS_TYPE_LINUX,
    'nginx': OS_TYPE_LINUX,
    'apache': OS_TYPE_LINUX,
    'mysql': OS_TYPE_LINUX,
    'postgresql': OS_TYPE_LINUX,
    'docker': OS_TYPE_LINUX,
    'firewall': OS_TYPE_LINUX,
    'tls': OS_TYPE_LINUX,

    # Windows categories
    'account-policy': OS_TYPE_WINDOWS,
    'local-policies': OS_TYPE_WINDOWS,
    'security-options': OS_TYPE_WINDOWS,
    'audit-policy': OS_TYPE_WINDOWS,
    'user-rights': OS_TYPE_WINDOWS,
    'features': OS_TYPE_WINDOWS,
    'iis': OS_TYPE_WINDOWS,
    'sql-server': OS_TYPE_WINDOWS,
    'windows-firewall': OS_TYPE_WINDOWS,

    # Hypervisor categories
    'esxi': OS_TYPE_ESXI,
    'vcenter': OS_TYPE_ESXI,
    'kvm': OS_TYPE_KVM,
    'proxmox': OS_TYPE_PROXMOX,
    'proxmox-cluster': OS_TYPE_PROXMOX,
    'nutanix': OS_TYPE_NUTANIX,
    'xen': OS_TYPE_XEN,
    'xen-management': OS_TYPE_XEN,
}

# Severity levels
SEVERITY_CRITICAL = 'critical'
SEVERITY_HIGH = 'high'
SEVERITY_MEDIUM = 'medium'
SEVERITY_LOW = 'low'
