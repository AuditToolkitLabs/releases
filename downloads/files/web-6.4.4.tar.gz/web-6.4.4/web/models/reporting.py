"""Canonical reporting ORM models.

These models establish the first shared reporting substrate for cross-asset
enterprise reporting without changing existing source-domain tables.
"""

from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from .database import Base


class ReportingAsset(Base):
    """Canonical cross-asset identity used by reporting services."""

    __tablename__ = 'reporting_assets'

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset_uid = Column(String(64), unique=True, nullable=False, index=True)
    display_name = Column(String(255), nullable=False, index=True)
    asset_class = Column(String(50), nullable=False, index=True)
    platform = Column(String(50), nullable=False, index=True)
    hostname = Column(String(255), nullable=True, index=True)
    primary_ip = Column(String(45), nullable=True, index=True)
    environment = Column(String(50), nullable=True, index=True)
    owner = Column(String(255), nullable=True, index=True)
    business_unit = Column(String(255), nullable=True)
    status = Column(String(30), nullable=False, default='active', index=True)
    criticality = Column(String(30), nullable=True)
    first_seen_at = Column(DateTime, nullable=True)
    last_seen_at = Column(DateTime, nullable=True, index=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    asset_links = relationship(
        'ReportingAssetLink',
        back_populates='reporting_asset',
        cascade='all, delete-orphan'
    )
    observations = relationship(
        'ReportingObservation',
        back_populates='reporting_asset',
        cascade='all, delete-orphan'
    )
    findings = relationship(
        'ReportingFinding',
        back_populates='reporting_asset',
        cascade='all, delete-orphan'
    )
    control_evaluations = relationship(
        'ReportingControlEvaluation',
        back_populates='reporting_asset',
        cascade='all, delete-orphan'
    )

    __table_args__ = (
        Index('idx_reporting_assets_class_platform', 'asset_class', 'platform'),
        Index('idx_reporting_assets_environment_status', 'environment', 'status'),
    )

    def to_dict(self) -> dict:
        return {
            'asset_uid': self.asset_uid,
            'display_name': self.display_name,
            'asset_class': self.asset_class,
            'platform': self.platform,
            'hostname': self.hostname,
            'primary_ip': self.primary_ip,
            'environment': self.environment,
            'owner': self.owner,
            'business_unit': self.business_unit,
            'status': self.status,
            'criticality': self.criticality,
            'first_seen_at': self.first_seen_at.isoformat() if self.first_seen_at else None,
            'last_seen_at': self.last_seen_at.isoformat() if self.last_seen_at else None,
        }


class ReportingAssetLink(Base):
    """Maps a canonical reporting asset to one source-system record."""

    __tablename__ = 'reporting_asset_links'

    id = Column(Integer, primary_key=True, autoincrement=True)
    reporting_asset_id = Column(Integer, ForeignKey('reporting_assets.id', ondelete='CASCADE'), nullable=False)
    source_system = Column(String(50), nullable=False, index=True)
    source_table = Column(String(100), nullable=False)
    source_record_id = Column(String(100), nullable=False)
    source_key = Column(String(255), nullable=True)
    is_primary = Column(Boolean, nullable=False, default=False, index=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    reporting_asset = relationship('ReportingAsset', back_populates='asset_links')

    __table_args__ = (
        Index(
            'idx_reporting_asset_links_source_record',
            'source_system',
            'source_table',
            'source_record_id',
            unique=False,
        ),
    )


class ReportingDataSource(Base):
    """Represents a reporting producer or subsystem."""

    __tablename__ = 'reporting_data_sources'

    id = Column(Integer, primary_key=True, autoincrement=True)
    source_code = Column(String(64), unique=True, nullable=False, index=True)
    source_type = Column(String(50), nullable=False, index=True)
    source_name = Column(String(255), nullable=False)
    collection_method = Column(String(50), nullable=False)
    trust_level = Column(String(30), nullable=False, default='medium', index=True)
    default_confidence_score = Column(Float, nullable=False, default=0.5)
    active = Column(Boolean, nullable=False, default=True, index=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    observations = relationship(
        'ReportingObservation',
        back_populates='reporting_data_source',
        cascade='all, delete-orphan'
    )


class ReportingObservation(Base):
    """Time-scoped source observation for an asset."""

    __tablename__ = 'reporting_observations'

    id = Column(Integer, primary_key=True, autoincrement=True)
    reporting_asset_id = Column(Integer, ForeignKey('reporting_assets.id', ondelete='CASCADE'), nullable=False)
    reporting_data_source_id = Column(Integer, ForeignKey('reporting_data_sources.id', ondelete='CASCADE'), nullable=False)
    observation_type = Column(String(50), nullable=False, index=True)
    collected_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    effective_at = Column(DateTime, nullable=True)
    confidence_score = Column(Float, nullable=False, default=0.5)
    freshness_seconds = Column(Integer, nullable=True)
    raw_summary = Column(Text, nullable=True)
    raw_payload_ref = Column(String(255), nullable=True)
    metadata_json = Column(JSON, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    reporting_asset = relationship('ReportingAsset', back_populates='observations')
    reporting_data_source = relationship('ReportingDataSource', back_populates='observations')
    findings = relationship(
        'ReportingFinding',
        back_populates='reporting_observation',
        cascade='all, delete-orphan'
    )
    control_evaluations = relationship(
        'ReportingControlEvaluation',
        back_populates='reporting_observation',
        cascade='all, delete-orphan'
    )

    __table_args__ = (
        Index(
            'idx_reporting_observations_asset_type_collected',
            'reporting_asset_id',
            'observation_type',
            'collected_at',
        ),
    )


class ReportingFinding(Base):
    """Normalized finding record across native and imported sources."""

    __tablename__ = 'reporting_findings'

    id = Column(Integer, primary_key=True, autoincrement=True)
    finding_uid = Column(String(64), unique=True, nullable=False, index=True)
    reporting_asset_id = Column(Integer, ForeignKey('reporting_assets.id', ondelete='CASCADE'), nullable=False)
    reporting_observation_id = Column(Integer, ForeignKey('reporting_observations.id', ondelete='CASCADE'), nullable=False)
    title = Column(String(500), nullable=False)
    category = Column(String(100), nullable=True, index=True)
    severity = Column(String(20), nullable=False, index=True)
    priority_score = Column(Float, nullable=True)
    status = Column(String(30), nullable=False, default='open', index=True)
    description = Column(Text, nullable=True)
    remediation = Column(Text, nullable=True)
    external_reference = Column(String(255), nullable=True)
    first_observed_at = Column(DateTime, nullable=True)
    last_observed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    reporting_asset = relationship('ReportingAsset', back_populates='findings')
    reporting_observation = relationship('ReportingObservation', back_populates='findings')

    __table_args__ = (
        Index('idx_reporting_findings_asset_severity_status', 'reporting_asset_id', 'severity', 'status'),
        Index('idx_reporting_findings_status_updated', 'status', 'updated_at'),
    )

    def to_dict(self) -> dict:
        return {
            'finding_uid': self.finding_uid,
            'reporting_asset_id': self.reporting_asset_id,
            'reporting_observation_id': self.reporting_observation_id,
            'title': self.title,
            'category': self.category,
            'severity': self.severity,
            'priority_score': self.priority_score,
            'status': self.status,
            'external_reference': self.external_reference,
            'first_observed_at': self.first_observed_at.isoformat() if self.first_observed_at else None,
            'last_observed_at': self.last_observed_at.isoformat() if self.last_observed_at else None,
        }


class ReportingControlEvaluation(Base):
    """Normalized framework/control result attached to a reporting observation."""

    __tablename__ = 'reporting_control_evaluations'

    id = Column(Integer, primary_key=True, autoincrement=True)
    reporting_asset_id = Column(Integer, ForeignKey('reporting_assets.id', ondelete='CASCADE'), nullable=True)
    reporting_observation_id = Column(Integer, ForeignKey('reporting_observations.id', ondelete='CASCADE'), nullable=False)
    framework = Column(String(50), nullable=False, index=True)
    control_id = Column(String(100), nullable=False, index=True)
    control_family = Column(String(100), nullable=True, index=True)
    status = Column(String(30), nullable=False, index=True)
    score = Column(Float, nullable=True)
    evidence_summary = Column(Text, nullable=True)
    evaluated_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    reporting_asset = relationship('ReportingAsset', back_populates='control_evaluations')
    reporting_observation = relationship('ReportingObservation', back_populates='control_evaluations')

    __table_args__ = (
        Index(
            'idx_reporting_controls_framework_status',
            'framework',
            'status',
            'evaluated_at',
        ),
    )
