#!/usr/bin/env python3
"""
Schedule Model - Database model for scheduled audits

Provides ORM model for audit schedules with cron expressions.

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text, Index
from sqlalchemy.orm import relationship
from .database import Base
from croniter import croniter


class ScheduledAudit(Base):
    """
    Scheduled Audit Model

    Attributes:
        id: Unique schedule identifier
        name: Human-readable schedule name
        server_id: Foreign key to servers table
        audit_id: Foreign key to audits table
        cron_schedule: Cron expression (e.g., "0 2 * * *")
        is_active: Enable/disable schedule
        notification_enabled: Send notifications on completion
        notification_emails: Comma-separated email addresses
        notification_webhooks: Comma-separated webhook URLs
        last_run: Timestamp of last execution
        next_run: Calculated next run time
        last_status: Status of last execution (success/failure)
        created_at: Creation timestamp
        updated_at: Last update timestamp
        created_by: Username or identifier string (optional)
    """
    __tablename__ = 'scheduled_audits'
    __table_args__ = (
        # Index for scheduler queries: find active schedules due to run
        Index('idx_schedule_active_next_run', 'is_active', 'next_run'),
        # Index for server-based lookups
        Index('idx_schedule_server_id', 'server_id'),
        # Index for audit-based lookups
        Index('idx_schedule_audit_id', 'audit_id'),
        {'extend_existing': True}
    )

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    server_id = Column(Integer, ForeignKey('servers.id', ondelete='CASCADE'), nullable=False)
    audit_id = Column(Integer, ForeignKey('audits.id', ondelete='CASCADE'), nullable=False)
    cron_schedule = Column(String(100), nullable=False)  # e.g., "0 2 * * *"
    is_active = Column(Boolean, default=True, nullable=False, index=True)

    # Notification settings
    notification_enabled = Column(Boolean, default=False, nullable=False)
    notification_emails = Column(Text)  # Comma-separated
    notification_webhooks = Column(Text)  # Comma-separated

    # Execution tracking
    last_run = Column(DateTime)
    next_run = Column(DateTime)
    last_status = Column(String(50))  # 'success', 'failure', 'error', 'pending'

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    created_by = Column(String(100))  # Username or identifier string (no foreign key)

    # Relationships
    server = relationship('Server', back_populates='scheduled_audits')
    audit = relationship('Audit', back_populates='scheduled_audits')

    def to_dict(self, include_relations=True):
        """Convert to dictionary representation"""
        data = {
            'id': self.id,
            'name': self.name,
            'server_id': self.server_id,
            'audit_id': self.audit_id,
            'cron_schedule': self.cron_schedule,
            'cron_description': self.get_cron_description(),
            'is_active': self.is_active,
            'notification_enabled': self.notification_enabled,
            'notification_emails': self.notification_emails,
            'notification_webhooks': self.notification_webhooks,
            'last_run': self.last_run.isoformat() if self.last_run else None,
            'next_run': self.next_run.isoformat() if self.next_run else None,
            'last_status': self.last_status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

        if include_relations:
            if self.server:
                data['server'] = {
                    'id': self.server.id,
                    'name': self.server.name,
                    'hostname': self.server.hostname
                }
            if self.audit:
                data['audit'] = {
                    'id': self.audit.id,
                    'name': self.audit.name,
                    'file_path': self.audit.file_path
                }

        return data

    def get_cron_description(self):
        """Get human-readable cron schedule description"""
        try:
            # Common patterns
            patterns = {
                '* * * * *': 'Every minute',
                '*/5 * * * *': 'Every 5 minutes',
                '*/15 * * * *': 'Every 15 minutes',
                '*/30 * * * *': 'Every 30 minutes',
                '0 * * * *': 'Every hour',
                '0 */2 * * *': 'Every 2 hours',
                '0 */6 * * *': 'Every 6 hours',
                '0 0 * * *': 'Daily at midnight',
                '0 2 * * *': 'Daily at 2:00 AM',
                '0 0 * * 0': 'Weekly on Sunday',
                '0 0 * * 1': 'Weekly on Monday',
                '0 0 1 * *': 'Monthly on the 1st',
                '0 0 1 */3 *': 'Quarterly',
            }

            if self.cron_schedule in patterns:
                return patterns[self.cron_schedule]

            # Try to parse it
            cron = croniter(self.cron_schedule, datetime.utcnow())
            next_run = cron.get_next(datetime)
            return f"Next run: {next_run.strftime('%Y-%m-%d %H:%M UTC')}"
        except Exception:
            return 'Custom schedule'

    def calculate_next_run(self, base_time=None):
        """Calculate next run time from cron expression"""
        try:
            if base_time is None:
                base_time = datetime.utcnow()
            cron = croniter(self.cron_schedule, base_time)
            self.next_run = cron.get_next(datetime)
            return self.next_run
        except Exception as e:
            raise ValueError(f"Invalid cron expression: {self.cron_schedule}") from e

    def should_run_now(self):
        """Check if schedule should execute now"""
        if not self.is_active:
            return False
        if self.next_run is None:
            return False
        return datetime.utcnow() >= self.next_run

    @staticmethod
    def validate_cron(cron_expression):
        """Validate cron expression syntax"""
        try:
            croniter(cron_expression)
            return True, "Valid cron expression"
        except Exception as e:
            return False, f"Invalid cron expression: {str(e)}"
