#!/usr/bin/env python3
"""
Scheduled Report Model - Database model for scheduled PDF report delivery

Provides ORM model for scheduling recurring PDF report generation and email delivery.

Author: Security Audit Toolkit Team
Date: February 11, 2026
"""

from datetime import datetime
from enum import Enum
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, JSON
from models.database import Base
from models.encrypted_field import EncryptedField
from croniter import croniter


class ReportFrequency(str, Enum):
    """Report generation frequency options"""
    DAILY = 'daily'
    WEEKLY = 'weekly'
    BIWEEKLY = 'biweekly'
    MONTHLY = 'monthly'
    QUARTERLY = 'quarterly'


class ComplianceFramework(str, Enum):
    """Supported compliance frameworks for reports"""
    NONE = 'none'
    PCI_DSS = 'pci-dss'
    SOC2 = 'soc2'
    ISO27001 = 'iso27001'
    NIST_CSF = 'nist-csf'
    CIS_CONTROLS = 'cis-controls'


class ScheduledReport(Base):
    """
    Scheduled Report Model

    Enables recurring PDF report generation and email delivery.

    Attributes:
        id: Unique schedule identifier
        name: Human-readable report name
        description: Optional description

        # Targeting
        server_ids: JSON array of server IDs to include (null = all)
        server_tags: JSON array of server tags to filter by
        include_all_servers: Include all servers if True

        # Report configuration
        compliance_framework: Compliance framework for mapping
        organization: Organization name for branding
        classification: Document classification (Confidential, Internal, etc.)
        include_executive_summary: Include executive summary section
        include_recommendations: Include recommendations section

        # Schedule
        cron_schedule: Cron expression for scheduling
        frequency: Human-readable frequency (daily, weekly, monthly)
        timezone: Timezone for scheduling
        is_active: Enable/disable schedule

        # Delivery
        email_recipients: JSON array of email addresses
        webhook_urls: JSON array of webhook URLs

        # Execution tracking
        last_run: Timestamp of last execution
        next_run: Calculated next run time
        last_status: Status of last execution
        last_error: Error message if last run failed
        run_count: Total number of successful runs

        # Metadata
        created_at: Creation timestamp
        updated_at: Last update timestamp
        created_by: Username who created the schedule
    """
    __tablename__ = 'scheduled_reports'

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)

    # Server targeting
    server_ids = Column(JSON)  # [1, 2, 3] or null for all
    server_tags = Column(JSON)  # ["production", "web"] filters
    include_all_servers = Column(Boolean, default=True, nullable=False)

    # Report configuration
    compliance_framework = Column(String(50), default='none')
    organization = Column(String(255))
    classification = Column(String(100), default='Confidential')
    include_executive_summary = Column(Boolean, default=True, nullable=False)
    include_recommendations = Column(Boolean, default=True, nullable=False)

    # Schedule
    cron_schedule = Column(String(100), nullable=False)  # e.g., "0 8 * * 1"
    frequency = Column(String(50), default='weekly')  # For UI display
    timezone = Column(String(50), default='UTC')
    is_active = Column(Boolean, default=True, nullable=False)

    # Delivery
    email_recipients = Column(JSON, nullable=False)  # ["email1@example.com", ...]
    webhook_urls = Column(JSON)  # Optional webhooks

    # Execution tracking
    last_run = Column(DateTime)
    next_run = Column(DateTime)
    last_status = Column(String(50))  # 'success', 'failure', 'error'
    last_error = Column(EncryptedField())
    run_count = Column(Integer, default=0)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    created_by = Column(String(100))

    def to_dict(self):
        """Convert to dictionary representation"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,

            # Targeting
            'server_ids': self.server_ids,
            'server_tags': self.server_tags,
            'include_all_servers': self.include_all_servers,

            # Report config
            'compliance_framework': self.compliance_framework,
            'organization': self.organization,
            'classification': self.classification,
            'include_executive_summary': self.include_executive_summary,
            'include_recommendations': self.include_recommendations,

            # Schedule
            'cron_schedule': self.cron_schedule,
            'cron_description': self.get_cron_description(),
            'frequency': self.frequency,
            'timezone': self.timezone,
            'is_active': self.is_active,

            # Delivery
            'email_recipients': self.email_recipients or [],
            'webhook_urls': self.webhook_urls or [],

            # Execution
            'last_run': self.last_run.isoformat() if self.last_run else None,
            'next_run': self.next_run.isoformat() if self.next_run else None,
            'last_status': self.last_status,
            'last_error': self.last_error,
            'run_count': self.run_count,

            # Metadata
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by
        }

    def get_cron_description(self) -> str:
        """Get human-readable cron schedule description"""
        patterns = {
            '0 8 * * *': 'Daily at 8:00 AM',
            '0 8 * * 1': 'Weekly on Monday at 8:00 AM',
            '0 8 * * 5': 'Weekly on Friday at 8:00 AM',
            '0 8 1 * *': 'Monthly on the 1st at 8:00 AM',
            '0 8 1,15 * *': 'Bi-weekly (1st and 15th) at 8:00 AM',
            '0 8 1 1,4,7,10 *': 'Quarterly at 8:00 AM',
        }
        return patterns.get(self.cron_schedule, f"Custom: {self.cron_schedule}")

    def calculate_next_run(self, from_time: datetime = None) -> datetime:
        """Calculate the next run time from croniter"""
        base = from_time or datetime.utcnow()
        try:
            cron = croniter(self.cron_schedule, base)
            return cron.get_next(datetime)
        except Exception:
            return None

    def get_email_list(self) -> list:
        """Get email recipients as a list"""
        if isinstance(self.email_recipients, list):
            return self.email_recipients
        return []

    def get_webhook_list(self) -> list:
        """Get webhook URLs as a list"""
        if isinstance(self.webhook_urls, list):
            return self.webhook_urls
        return []

    @classmethod
    def get_cron_for_frequency(cls, frequency: str, hour: int = 8, day_of_week: int = 1) -> str:
        """
        Generate cron expression for common frequencies

        Args:
            frequency: One of daily, weekly, biweekly, monthly, quarterly
            hour: Hour of day (0-23, default 8)
            day_of_week: Day of week for weekly (0=Sun, 1=Mon, default 1)

        Returns:
            Cron expression string
        """
        cron_map = {
            'daily': f'0 {hour} * * *',
            'weekly': f'0 {hour} * * {day_of_week}',
            'biweekly': f'0 {hour} 1,15 * *',
            'monthly': f'0 {hour} 1 * *',
            'quarterly': f'0 {hour} 1 1,4,7,10 *',
        }
        return cron_map.get(frequency, f'0 {hour} * * *')
