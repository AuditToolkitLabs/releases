#!/usr/bin/env python3
"""
Server Model

Handles server configuration storage and retrieval:
- Database ORM storage (PostgreSQL/SQLite) - PRIMARY
- Legacy JSON file-based storage (fallback)
- CRUD operations (Create, Read, Update, Delete)
- Password encryption/decryption
- Server data sanitization
"""

import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any
from contextlib import contextmanager

logger = logging.getLogger(__name__)

# Import database models
try:
    from models.database import Server as ServerModel
    # Re-export for backward compatibility with tests
    Server = ServerModel
    DATABASE_AVAILABLE = True
except ImportError:
    DATABASE_AVAILABLE = False
    ServerModel = None  # Define as None to avoid NameError in type hints
    Server = None
    logger.warning("Database models not available, falling back to file storage")

def get_session_local():
    """Lazy getter for SessionLocal to avoid circular imports."""
    from config import SessionLocal
    return SessionLocal


class ServerManager:
    """
    Manages server configurations with encrypted passwords

    Storage backends:
    - Database (PostgreSQL/SQLite) - PRIMARY
    - JSON file - FALLBACK for backward compatibility

    Automatically detects available backend and uses database if available.
    """

    def __init__(self, servers_dir=None, password_manager=None, use_database=True):
        """
        Initialize Server Manager

        Args:
            servers_dir: Directory for file-based storage (optional, for fallback)
            password_manager: Password encryption manager (optional, for file storage)
            use_database: Prefer database storage if available (default: True)
        """
        self.use_database = use_database and DATABASE_AVAILABLE
        self.servers_dir = Path(servers_dir) if servers_dir else Path("servers")
        self.servers_file = self.servers_dir / "servers.json"
        self.password_manager = password_manager
        if self.password_manager is None:
            try:
                from encryption import password_manager as default_password_manager
                self.password_manager = default_password_manager
            except Exception as e:
                logger.warning(f"Password manager not available for server credential encryption: {e}")

        if self.use_database:
            logger.info("ServerManager using database storage (PostgreSQL/SQLite)")
        else:
            logger.info("ServerManager using file-based storage (JSON)")
            # Ensure directory exists for file storage
            self.servers_dir.mkdir(exist_ok=True)

    def _get_db_session(self):
        """Get database session for operations (DEPRECATED: Use get_db_context instead)"""
        if not self.use_database:
            return None
        SessionLocal = get_session_local()
        return SessionLocal()

    @contextmanager
    def get_db_context(self):
        """
        Context manager for database sessions - prevents session leaks

        Usage:
            with self.get_db_context() as db:
                servers = db.query(ServerModel).all()
        """
        if not self.use_database:
            yield None
            return

        SessionLocal = get_session_local()
        db = SessionLocal()
        try:
            yield db
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    # ========================================================================
    # Database-backed operations (PRIMARY)
    # ========================================================================

    def load_servers(self, limit: int = None, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Load servers from storage backend with optional pagination (MEDIUM-01 fix)

        Args:
            limit: Maximum number of servers to return (None = all)
            offset: Number of servers to skip (for pagination)

        Returns:
            List of server configuration dicts
        """
        if self.use_database:
            return self._load_servers_db(limit=limit, offset=offset)
        else:
            # File backend: apply pagination post-load
            all_servers = self._load_servers_file()
            if offset:
                all_servers = all_servers[offset:]
            if limit:
                all_servers = all_servers[:limit]
            return all_servers

    def _load_servers_db(self, limit: int = None, offset: int = 0) -> List[Dict[str, Any]]:
        """Load servers from database with optional pagination"""
        with self.get_db_context() as db:
            if not db:
                return []

            try:
                query = db.query(ServerModel)
                if offset:
                    query = query.offset(offset)
                if limit:
                    query = query.limit(limit)
                servers = query.all()
                result = [self._server_model_to_dict(s) for s in servers]
                logger.info(f"Loaded {len(result)} servers from database")
                return result
            except Exception as e:
                logger.error(f"Failed to load servers from database: {e}")
                return []

    def _server_model_to_dict(self, server: "ServerModel") -> Dict[str, Any]:
        """Convert SQLAlchemy model to dict for API compatibility"""
        connection_method = (server.connection_method or "ssh").lower()
        elevation_method = (getattr(server, 'elevation_method', None) or "").lower()

        model_os_type = getattr(server, 'os_type', None)
        if model_os_type:
            os_type = str(model_os_type).lower()
        elif server.hypervisor_type or connection_method == "hypervisor":
            os_type = "hypervisor"
        elif connection_method == "winrm" or elevation_method in {"runas", "jea", "admin"}:
            os_type = "windows"
        else:
            os_type = "linux"

        model_connection_protocol = getattr(server, 'connection_protocol', None)
        if model_connection_protocol:
            connection_protocol = str(model_connection_protocol).lower()
        elif connection_method in {"ssh", "winrm"}:
            connection_protocol = connection_method
        elif os_type == "windows":
            connection_protocol = "winrm"
        else:
            connection_protocol = "ssh"

        return {
            "id": server.id,
            "name": server.name,
            "host": server.hostname,
            "port": server.port,
            "user": server.username,
            "password": server.password,  # Encrypted
            "auth_type": "password" if server.password else "public_key",
            "key_path": server.ssh_key_path or "",
            "remote_path": "/opt/security-audit-toolkit",  # Default
            "os_type": os_type,
            "connection_protocol": connection_protocol,
            "connection_method": connection_method,
            "agent_id": server.agent_id,
            "execution_mode": getattr(server, 'execution_mode', 'stream') or 'stream',
            "elevation_method": getattr(server, 'elevation_method', 'sudo') or 'sudo',
            "jea_endpoint": getattr(server, 'jea_endpoint', None),
            "description": server.description or "",
            "tags": server.tags or "",
            "added_at": server.created_at.isoformat() if server.created_at else None,
            "updated_at": server.updated_at.isoformat() if server.updated_at else None,
            "last_audit_at": server.last_audit_at.isoformat() if server.last_audit_at else None
        }

    def get_server_by_id(self, server_id: int) -> Optional[Dict[str, Any]]:
        """
        Get server by ID

        Args:
            server_id: Server ID (int)

        Returns:
            Server dict or None if not found
        """
        if self.use_database:
            return self._get_server_by_id_db(server_id)
        else:
            return self._get_server_by_id_file(server_id)

    def get_server_by_host(self, host: str, resolve_dns: bool = True) -> Optional[Dict[str, Any]]:
        """
        Get server by hostname (FQDN) or IP address

        Lookup strategy:
        1. Exact match on stored hostname
        2. If resolve_dns=True and no match:
           - If query is FQDN: resolve to IP and search stored hostnames
           - If query is IP: search stored hostnames that resolve to this IP

        Args:
            host: Hostname (FQDN) or IP address to search for
            resolve_dns: Whether to perform DNS resolution for matching (default: True)

        Returns:
            Server dict or None if not found
        """
        if not host:
            return None

        host = host.strip().lower()

        if self.use_database:
            return self._get_server_by_host_db(host, resolve_dns)
        else:
            return self._get_server_by_host_file(host, resolve_dns)

    def _get_server_by_host_db(self, host: str, resolve_dns: bool) -> Optional[Dict[str, Any]]:
        """Get server by hostname/IP from database"""
        import socket
        import ipaddress

        with self.get_db_context() as db:
            if not db:
                return None

            try:
                # Strategy 1: Exact match (case-insensitive)
                server = db.query(ServerModel).filter(
                    ServerModel.hostname.ilike(host)
                ).first()
                if server:
                    logger.debug(f"Found server by exact hostname match: {host}")
                    return self._server_model_to_dict(server)

                if not resolve_dns:
                    return None

                # Determine if host is IP or FQDN
                is_ip = False
                try:
                    ipaddress.ip_address(host)
                    is_ip = True
                except ValueError:
                    pass

                if is_ip:
                    # Strategy 2: Query is IP - find servers whose hostname resolves to this IP
                    all_servers = db.query(ServerModel).all()
                    for srv in all_servers:
                        try:
                            resolved_ip = socket.gethostbyname(srv.hostname)
                            if resolved_ip == host:
                                logger.debug(f"Found server by IP resolution: {srv.hostname} -> {host}")
                                return self._server_model_to_dict(srv)
                        except socket.gaierror:
                            # Hostname doesn't resolve, skip
                            continue
                else:
                    # Strategy 3: Query is FQDN - resolve to IP and search
                    try:
                        query_ip = socket.gethostbyname(host)
                        # Search for server with matching IP in hostname field
                        server = db.query(ServerModel).filter(
                            ServerModel.hostname.ilike(query_ip)
                        ).first()
                        if server:
                            logger.debug(f"Found server by resolved IP: {host} -> {query_ip}")
                            return self._server_model_to_dict(server)

                        # Also check if any stored hostname resolves to same IP
                        all_servers = db.query(ServerModel).all()
                        for srv in all_servers:
                            try:
                                resolved_ip = socket.gethostbyname(srv.hostname)
                                if resolved_ip == query_ip:
                                    logger.debug(f"Found server by matching resolved IP: {srv.hostname} == {host}")
                                    return self._server_model_to_dict(srv)
                            except socket.gaierror:
                                continue
                    except socket.gaierror:
                        # Query hostname doesn't resolve
                        pass

                return None

            except Exception as e:
                logger.error(f"Failed to get server by host {host} from database: {e}")
                return None

    def _get_server_by_host_file(self, host: str, resolve_dns: bool) -> Optional[Dict[str, Any]]:
        """Get server by hostname/IP from file storage"""
        import socket
        import ipaddress

        servers = self._load_servers_file()

        # Strategy 1: Exact match (case-insensitive)
        for server in servers:
            if server.get('host', '').lower() == host:
                logger.debug(f"Found server by exact hostname match: {host}")
                return server

        if not resolve_dns:
            return None

        # Determine if host is IP or FQDN
        is_ip = False
        try:
            ipaddress.ip_address(host)
            is_ip = True
        except ValueError:
            pass

        if is_ip:
            # Strategy 2: Query is IP - find servers whose hostname resolves to this IP
            for server in servers:
                try:
                    resolved_ip = socket.gethostbyname(server.get('host', ''))
                    if resolved_ip == host:
                        logger.debug(f"Found server by IP resolution: {server.get('host')} -> {host}")
                        return server
                except socket.gaierror:
                    continue
        else:
            # Strategy 3: Query is FQDN - resolve to IP and search
            try:
                query_ip = socket.gethostbyname(host)
                # Search for server with matching IP in host field
                for server in servers:
                    if server.get('host', '').lower() == query_ip:
                        logger.debug(f"Found server by resolved IP: {host} -> {query_ip}")
                        return server

                # Also check if any stored hostname resolves to same IP
                for server in servers:
                    try:
                        resolved_ip = socket.gethostbyname(server.get('host', ''))
                        if resolved_ip == query_ip:
                            logger.debug(f"Found server by matching resolved IP: {server.get('host')} == {host}")
                            return server
                    except socket.gaierror:
                        continue
            except socket.gaierror:
                pass

        return None

    def find_servers_by_host(self, host: str, resolve_dns: bool = True) -> List[Dict[str, Any]]:
        """
        Find all servers matching a hostname or IP (may return multiple if DNS aliases exist)

        Args:
            host: Hostname (FQDN) or IP address to search for
            resolve_dns: Whether to perform DNS resolution for matching (default: True)

        Returns:
            List of matching server dicts (may be empty)
        """
        if not host:
            return []

        host = host.strip().lower()

        if self.use_database:
            return self._find_servers_by_host_db(host, resolve_dns)
        else:
            return self._find_servers_by_host_file(host, resolve_dns)

    def _find_servers_by_host_db(self, host: str, resolve_dns: bool) -> List[Dict[str, Any]]:
        """Find all servers matching hostname/IP from database"""
        import socket
        import ipaddress

        results = []
        seen_ids = set()

        with self.get_db_context() as db:
            if not db:
                return []

            try:
                # Strategy 1: Exact match
                servers = db.query(ServerModel).filter(
                    ServerModel.hostname.ilike(host)
                ).all()
                for srv in servers:
                    if srv.id not in seen_ids:
                        results.append(self._server_model_to_dict(srv))
                        seen_ids.add(srv.id)

                if not resolve_dns:
                    return results

                # Determine if host is IP or FQDN
                is_ip = False
                try:
                    ipaddress.ip_address(host)
                    is_ip = True
                except ValueError:
                    pass

                # Get all servers for DNS resolution matching
                all_servers = db.query(ServerModel).all()

                if is_ip:
                    # Strategy 2: Match servers whose hostname resolves to this IP
                    for srv in all_servers:
                        if srv.id in seen_ids:
                            continue
                        try:
                            resolved_ip = socket.gethostbyname(srv.hostname)
                            if resolved_ip == host:
                                results.append(self._server_model_to_dict(srv))
                                seen_ids.add(srv.id)
                        except socket.gaierror:
                            continue
                else:
                    # Strategy 3: Resolve FQDN and match by IP
                    try:
                        query_ip = socket.gethostbyname(host)
                        for srv in all_servers:
                            if srv.id in seen_ids:
                                continue
                            # Direct IP match
                            if srv.hostname.lower() == query_ip:
                                results.append(self._server_model_to_dict(srv))
                                seen_ids.add(srv.id)
                                continue
                            # Resolved IP match
                            try:
                                resolved_ip = socket.gethostbyname(srv.hostname)
                                if resolved_ip == query_ip:
                                    results.append(self._server_model_to_dict(srv))
                                    seen_ids.add(srv.id)
                            except socket.gaierror:
                                continue
                    except socket.gaierror:
                        pass

                return results

            except Exception as e:
                logger.error(f"Failed to find servers by host {host}: {e}")
                return results

    def _find_servers_by_host_file(self, host: str, resolve_dns: bool) -> List[Dict[str, Any]]:
        """Find all servers matching hostname/IP from file storage"""
        import socket
        import ipaddress

        results = []
        seen_ids = set()
        servers = self._load_servers_file()

        # Strategy 1: Exact match
        for server in servers:
            if server.get('host', '').lower() == host:
                if server.get('id') not in seen_ids:
                    results.append(server)
                    seen_ids.add(server.get('id'))

        if not resolve_dns:
            return results

        # Determine if host is IP or FQDN
        is_ip = False
        try:
            ipaddress.ip_address(host)
            is_ip = True
        except ValueError:
            pass

        if is_ip:
            # Strategy 2: Match servers whose hostname resolves to this IP
            for server in servers:
                if server.get('id') in seen_ids:
                    continue
                try:
                    resolved_ip = socket.gethostbyname(server.get('host', ''))
                    if resolved_ip == host:
                        results.append(server)
                        seen_ids.add(server.get('id'))
                except socket.gaierror:
                    continue
        else:
            # Strategy 3: Resolve FQDN and match by IP
            try:
                query_ip = socket.gethostbyname(host)
                for server in servers:
                    if server.get('id') in seen_ids:
                        continue
                    # Direct IP match
                    if server.get('host', '').lower() == query_ip:
                        results.append(server)
                        seen_ids.add(server.get('id'))
                        continue
                    # Resolved IP match
                    try:
                        resolved_ip = socket.gethostbyname(server.get('host', ''))
                        if resolved_ip == query_ip:
                            results.append(server)
                            seen_ids.add(server.get('id'))
                    except socket.gaierror:
                        continue
            except socket.gaierror:
                pass

        return results

    def _get_server_by_id_db(self, server_id: int) -> Optional[Dict[str, Any]]:
        """Get server by ID from database"""
        with self.get_db_context() as db:
            if not db:
                return None

            try:
                server = db.query(ServerModel).filter(ServerModel.id == server_id).first()
                if server:
                    return self._server_model_to_dict(server)
                return None
            except Exception as e:
                logger.error(f"Failed to get server {server_id} from database: {e}")
                return None

    def add_server(self, server_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Add new server to storage

        Args:
            server_data: Server configuration dict

        Returns:
            Created server dict with ID
        """
        if self.use_database:
            return self._add_server_db(server_data)
        else:
            return self._add_server_file(server_data)

    def _add_server_db(self, server_data: Dict[str, Any]) -> Dict[str, Any]:
        """Add server to database"""
        with self.get_db_context() as db:
            if not db:
                raise RuntimeError("Database not available")

            # Check for duplicate names
            existing = db.query(ServerModel).filter(ServerModel.name == server_data["name"]).first()
            if existing:
                raise ValueError(f"Server name '{server_data['name']}' already exists")

            # Encrypt password if provided and password_manager available
            password_value = None
            if server_data.get("auth_type") == "password" and server_data.get("password"):
                if self.password_manager:
                    password_value = self.password_manager.encrypt_password(server_data["password"])
                else:
                    logger.error("Refusing to store password without encryption manager")
                    raise RuntimeError("Password encryption manager not configured")

            # Create server model
            server_kwargs = {
                "name": server_data["name"],
                "hostname": server_data["host"],
                "port": server_data.get("port", 22),
                "username": server_data["user"],
                "password": password_value,
                "ssh_key_path": server_data.get("key_path") if server_data.get("auth_type") == "public_key" else None,
                "connection_method": server_data.get("connection_method", "ssh"),
                "agent_id": server_data.get("agent_id"),
                "execution_mode": server_data.get("execution_mode", "stream"),
                "elevation_method": server_data.get("elevation_method", "sudo"),
                "jea_endpoint": server_data.get("jea_endpoint"),
                "description": server_data.get("description", ""),
                "tags": server_data.get("tags", ""),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
            }

            if hasattr(ServerModel, "os_type"):
                server_kwargs["os_type"] = server_data.get("os_type", "linux")
            if hasattr(ServerModel, "connection_protocol"):
                server_kwargs["connection_protocol"] = server_data.get("connection_protocol", "auto")

            server = ServerModel(
                **server_kwargs
            )

            db.add(server)
            db.commit()
            db.refresh(server)

            logger.info(f"Added server to database: {server.name} (ID: {server.id})")
            return self._server_model_to_dict(server)

    def update_server(self, server_id: int, updates: Dict[str, Any]) -> bool:
        """
        Update existing server configuration

        Args:
            server_id: Server ID to update
            updates: Dict of fields to update

        Returns:
            True if successful, False otherwise
        """
        if self.use_database:
            return self._update_server_db(server_id, updates)
        else:
            return self._update_server_file(server_id, updates)

    def _update_server_db(self, server_id: int, updates: Dict[str, Any]) -> bool:
        """Update server in database"""
        with self.get_db_context() as db:
            if not db:
                return False

            server = db.query(ServerModel).filter(ServerModel.id == server_id).first()
            if not server:
                logger.warning(f"Server {server_id} not found for update")
                return False

            # Update fields
            if "name" in updates:
                server.name = updates["name"]
            if "host" in updates:
                server.hostname = updates["host"]
            if "port" in updates:
                server.port = updates["port"]
            if "user" in updates:
                server.username = updates["user"]
            if "password" in updates:
                # Encrypt password before storage
                if self.password_manager and updates["password"]:
                    server.password = self.password_manager.encrypt_password(updates["password"])
                else:
                    server.password = updates["password"]
                    if updates["password"] and not self.password_manager:
                        logger.error("Refusing to update password without encryption manager")
                        raise RuntimeError("Password encryption manager not configured")
            if "key_path" in updates:
                server.ssh_key_path = updates["key_path"]
            if "description" in updates:
                server.description = updates["description"]
            if "tags" in updates:
                server.tags = updates["tags"]
            if "execution_mode" in updates:
                # Validate execution_mode value
                valid_modes = ["stream", "deployed"]
                mode = updates["execution_mode"]
                if mode in valid_modes:
                    server.execution_mode = mode
                else:
                    logger.warning(f"Invalid execution_mode '{mode}', ignoring")
            if "elevation_method" in updates:
                # Validate elevation_method value
                valid_methods = ["sudo", "sudo_nopasswd", "audit_wrapper", "runas", "jea", "admin", "none"]
                method = updates["elevation_method"]
                if method in valid_methods:
                    server.elevation_method = method
                else:
                    logger.warning(f"Invalid elevation_method '{method}', ignoring")
            if "jea_endpoint" in updates:
                server.jea_endpoint = updates["jea_endpoint"]
            if "connection_method" in updates:
                server.connection_method = updates["connection_method"]
            if "agent_id" in updates:
                server.agent_id = updates["agent_id"]
            if "os_type" in updates and hasattr(server, "os_type"):
                server.os_type = updates["os_type"]
            if "connection_protocol" in updates and hasattr(server, "connection_protocol"):
                server.connection_protocol = updates["connection_protocol"]

            server.updated_at = datetime.utcnow()

            db.commit()
            logger.info(f"Updated server {server_id} in database")
            return True

    def remove_server(self, server_id: int) -> bool:
        """
        Remove server from storage

        Args:
            server_id: Server ID to remove

        Returns:
            True if successful, False otherwise
        """
        if self.use_database:
            return self._remove_server_db(server_id)
        else:
            return self._remove_server_file(server_id)

    def _purge_server_related_rows_db(self, db, server_id: int) -> int:
        """
        Best-effort cleanup of rows linked by server_id across optional schemas.

        Returns:
            Total number of dependent rows deleted.
        """
        from sqlalchemy import bindparam, delete, text
        from sqlalchemy.sql import table as sql_table, column

        related_tables = [
            # Current table names
            'server_group_membership',
            'server_cve_summaries',
            'audit_executions',
            'scheduled_audits',
            'maintenance_windows',
            'remediation_executions',
            'dead_letter_tasks',
            'task_failure_logs',
            'audit_history_summaries',
            'server_compliance_history',
            'compliance_assessments',
            'compliance_trends',
            'differential_comparisons',
            'remediation_items',
            'agent_commands',
            # Legacy aliases kept for backwards compatibility
            'dead_letter_queue',
            'dead_letter_archive',
            'audit_history',
            'audit_history_details',
            'compliance_history',
            'compliance_scan_results',
            'compliance_scan_history',
            'differential_changes',
            'differential_scans',
        ]

        total_deleted = 0

        # Child-of-child cleanup for schemas that do not include server_id on leaf tables.
        dependent_cleanup_sql = [
            (
                "DELETE FROM remediation_history WHERE remediation_item_id IN (SELECT id FROM remediation_items WHERE server_id = :server_id)",
                'remediation_history',
            ),
            (
                "DELETE FROM compliance_controls WHERE assessment_id IN (SELECT id FROM compliance_assessments WHERE server_id = :server_id)",
                'compliance_controls',
            ),
        ]

        for statement, table_name in dependent_cleanup_sql:
            try:
                with db.begin_nested():
                    result = db.execute(text(statement), {"server_id": server_id})
                total_deleted += int(result.rowcount or 0)
            except Exception as cleanup_error:
                logger.debug(
                    "Skipping dependent cleanup for table %s (server_id=%s): %s",
                    table_name,
                    server_id,
                    cleanup_error,
                )

        for table_name in related_tables:
            try:
                dynamic_table = sql_table(table_name, column('server_id'))
                delete_stmt = delete(dynamic_table).where(dynamic_table.c.server_id == bindparam('server_id'))
                with db.begin_nested():
                    result = db.execute(delete_stmt, {"server_id": server_id})
                total_deleted += int(result.rowcount or 0)
            except Exception as cleanup_error:
                logger.debug(
                    "Skipping cleanup for table %s (server_id=%s): %s",
                    table_name,
                    server_id,
                    cleanup_error,
                )

        return total_deleted

    def _remove_server_db(self, server_id: int) -> bool:
        """Remove server from database"""
        from sqlalchemy import text

        with self.get_db_context() as db:
            if not db:
                return False

            existing = db.execute(
                text("SELECT id FROM servers WHERE id = :server_id"),
                {"server_id": server_id},
            ).fetchone()
            if not existing:
                logger.warning(f"Server {server_id} not found for deletion")
                return False

            related_rows_deleted = self._purge_server_related_rows_db(db, server_id)

            delete_result = db.execute(
                text("DELETE FROM servers WHERE id = :server_id"),
                {"server_id": server_id},
            )
            if int(delete_result.rowcount or 0) == 0:
                logger.warning("Server %s delete returned no affected rows", server_id)
                db.rollback()
                return False

            db.commit()
            logger.info(
                "Removed server %s from database (related rows deleted=%s)",
                server_id,
                related_rows_deleted,
            )
            return True

    # ========================================================================
    # Legacy file-based operations (FALLBACK)
    # ========================================================================

    def _load_servers_file(self) -> List[Dict[str, Any]]:
        """Load servers from JSON file (legacy)"""
        if not self.servers_file.exists():
            logger.info("No servers configuration file found, returning empty list")
            return []

        try:
            with open(self.servers_file, 'r') as f:
                servers = json.load(f)

            # Ensure each server has an ID
            for i, server in enumerate(servers):
                if 'id' not in server:
                    server['id'] = i

            logger.info(f"Loaded {len(servers)} servers from file")
            return servers
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse servers.json: {e}")
            return []
        except Exception as e:
            logger.error(f"Failed to load servers from file: {e}")
            return []

    def save_servers(self, servers: List[Dict[str, Any]]) -> bool:
        """
        Save servers to configuration file (legacy)

        Args:
            servers: List of server configuration dicts

        Returns:
            True if successful, False otherwise
        """
        if self.use_database:
            logger.warning("save_servers called but database mode is active")
            return False  # Don't use file storage in database mode

        try:
            # Backup existing file if it exists
            if self.servers_file.exists():
                backup_file = self.servers_file.with_suffix('.json.bak')
                self.servers_file.rename(backup_file)

            # Write new file
            with open(self.servers_file, 'w') as f:
                json.dump(servers, f, indent=2)

            # Secure permissions
            self.servers_file.chmod(0o600)

            logger.info(f"Saved {len(servers)} servers to file")
            return True
        except Exception as e:
            logger.error(f"Failed to save servers to file: {e}")
            # Restore backup if save failed
            backup_file = self.servers_file.with_suffix('.json.bak')
            if backup_file.exists():
                backup_file.rename(self.servers_file)
            return False

    def _get_server_by_id_file(self, server_id: int) -> Optional[Dict[str, Any]]:
        """Get server by ID from file (legacy)"""
        servers = self._load_servers_file()
        for server in servers:
            if server.get('id') == server_id:
                return server
        return None

    def _add_server_file(self, server_data: Dict[str, Any]) -> Dict[str, Any]:
        """Add server to file (legacy)"""
        try:
            servers = self._load_servers_file()

            # Assign new ID
            next_id = max([s.get('id', 0) for s in servers], default=-1) + 1
            server_data['id'] = next_id

            # Encrypt password if present
            if server_data.get('auth_type') == 'password' and server_data.get('password'):
                if not self.password_manager:
                    logger.error("Refusing to store password without encryption manager")
                    raise RuntimeError("Password encryption manager not configured")
                server_data['password'] = self.password_manager.encrypt_password(server_data['password'])

            # Add timestamp
            server_data['added_at'] = datetime.now().isoformat()

            servers.append(server_data)

            if self.save_servers(servers):
                logger.info(f"Added server to file: {server_data.get('name', server_data['host'])}")
                return server_data
            else:
                raise RuntimeError("Failed to save server to file")
        except Exception as e:
            logger.error(f"Failed to add server to file: {e}")
            raise

    def _update_server_file(self, server_id: int, updates: Dict[str, Any]) -> bool:
        """Update server in file (legacy)"""
        try:
            servers = self._load_servers_file()

            server_index = None
            for i, server in enumerate(servers):
                if server.get('id') == server_id:
                    server_index = i
                    break

            if server_index is None:
                logger.warning(f"Server {server_id} not found for update")
                return False

            # Encrypt password if being updated
            if 'password' in updates and updates.get('auth_type') == 'password':
                if updates.get('password') and not self.password_manager:
                    logger.error("Refusing to update password without encryption manager")
                    raise RuntimeError("Password encryption manager not configured")
                if updates.get('password'):
                    updates['password'] = self.password_manager.encrypt_password(updates['password'])

            # Update fields
            servers[server_index].update(updates)
            servers[server_index]['updated_at'] = datetime.now().isoformat()

            if self.save_servers(servers):
                logger.info(f"Updated server {server_id} in file")
                return True
            else:
                return False
        except Exception as e:
            logger.error(f"Failed to update server in file: {e}")
            return False

    def _remove_server_file(self, server_id: int) -> bool:
        """Remove server from file (legacy)"""
        try:
            servers = self._load_servers_file()

            original_count = len(servers)
            servers = [s for s in servers if s.get('id') != server_id]

            if len(servers) == original_count:
                logger.warning(f"Server {server_id} not found for deletion")
                return False

            if self.save_servers(servers):
                logger.info(f"Removed server {server_id} from file")
                return True
            else:
                return False
        except Exception as e:
            logger.error(f"Failed to remove server from file: {e}")
            return False

    # ========================================================================
    # Common operations (both backends)
    # ========================================================================

    def sanitize_server_for_api(self, server: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """
        Sanitize server data for API response (remove sensitive data)

        Args:
            server: Server configuration dict

        Returns:
            Sanitized server dict
        """
        if not server:
            return None

        # Create copy to avoid modifying original
        sanitized = server.copy()

        # Remove sensitive fields
        if 'password' in sanitized and sanitized['password']:
            sanitized['password'] = '***hidden***'  # nosec B105
            sanitized['has_password'] = True
        else:
            sanitized['has_password'] = False

        if 'key_path' in sanitized and sanitized['key_path']:
            # Show path but mark as present
            sanitized['has_key'] = True
        else:
            sanitized['has_key'] = False

        return sanitized

    def get_all_servers_sanitized(self) -> List[Dict[str, Any]]:
        """
        Get all servers with sensitive data removed

        Returns:
            List of sanitized server dicts
        """
        servers = self.load_servers()
        return [self.sanitize_server_for_api(s) for s in servers]

    def get_server_count(self) -> int:
        """Get total number of servers"""
        if self.use_database:
            with self.get_db_context() as db:
                if not db:
                    return 0
                try:
                    return db.query(ServerModel).count()
                except Exception as e:
                    logger.error(f"Failed to count servers: {e}")
                    return 0
        else:
            return len(self._load_servers_file())


__all__ = [
    'ServerManager',
]
