#!/usr/bin/env python3
"""
Server Group Model - Organize servers into logical groups

Provides:
- ServerGroup: Named groups with optional policies
- ServerGroupMembership: Many-to-many association
- GroupPolicy: Default audit settings for groups

Author: Security Audit Toolkit Team
Date: February 10, 2026
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime,
    ForeignKey, Text, Table
)
from sqlalchemy.orm import relationship
from models.database import Base


# Association table for many-to-many Server <-> ServerGroup relationship
server_group_membership = Table(
    'server_group_membership',
    Base.metadata,
    Column('server_id', Integer, ForeignKey('servers.id', ondelete='CASCADE'), primary_key=True),
    Column('group_id', Integer, ForeignKey('server_groups.id', ondelete='CASCADE'), primary_key=True),
    Column('added_at', DateTime, default=datetime.utcnow),
    extend_existing=True
)


class ServerGroup(Base):
    """
    Server Group Model

    Organizes servers into logical groups for:
    - Bulk operations (audits, deployments)
    - Policy application
    - Permission management
    - Reporting

    Attributes:
        id: Unique group identifier
        name: Group name (unique)
        description: Optional description
        color: UI color for visual identification
        icon: UI icon name
        parent_id: Parent group for hierarchy (optional)
        is_dynamic: If true, membership based on filter rules
        dynamic_filter: JSON filter rules for dynamic groups

        # Policy settings
        default_audit_schedule: Default cron for new schedules
        maintenance_window_id: Default maintenance window
        notification_emails: Default notification recipients

        # Metadata
        created_at: Creation timestamp
        updated_at: Last update timestamp
        created_by: Username who created
    """
    __tablename__ = 'server_groups'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False, index=True)
    description = Column(Text)
    color = Column(String(20), default='#3498db')  # Hex color
    icon = Column(String(50), default='server')  # Icon name

    # Hierarchy
    parent_id = Column(Integer, ForeignKey('server_groups.id', ondelete='SET NULL'))

    # Dynamic grouping
    is_dynamic = Column(Boolean, default=False, nullable=False)
    dynamic_filter = Column(Text)  # JSON: {"tags": ["production"], "hostname_pattern": "web-*"}

    # Default policies
    default_audit_schedule = Column(String(100))  # Cron expression
    maintenance_window_id = Column(Integer, ForeignKey(
        'maintenance_windows.id', ondelete='SET NULL', use_alter=True
    ))
    notification_emails = Column(Text)  # Comma-separated

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    created_by = Column(String(100))

    # Relationships
    servers = relationship(
        'Server',
        secondary=server_group_membership,
        backref='groups',
        lazy='dynamic'
    )
    parent = relationship('ServerGroup', remote_side=[id], backref='children')

    def to_dict(self, include_servers=False, include_policy=True):
        """Convert to dictionary representation"""
        data = {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'color': self.color,
            'icon': self.icon,
            'parent_id': self.parent_id,
            'parent_name': self.parent.name if self.parent else None,
            'is_dynamic': self.is_dynamic,
            'dynamic_filter': self.dynamic_filter,
            'server_count': self.servers.count() if not self.is_dynamic else self._get_dynamic_count(),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by
        }

        if include_policy:
            data['policy'] = {
                'default_audit_schedule': self.default_audit_schedule,
                'maintenance_window_id': self.maintenance_window_id,
                'notification_emails': self.notification_emails
            }

        if include_servers:
            if self.is_dynamic:
                data['servers'] = self._get_dynamic_servers()
            else:
                data['servers'] = [
                    {'id': s.id, 'name': s.name, 'hostname': s.hostname}
                    for s in self.servers.all()
                ]

        return data

    def _get_dynamic_count(self):
        """Get count of servers matching dynamic filter"""
        # This would be implemented to query servers based on filter
        return 0

    def _get_dynamic_servers(self):
        """Get servers matching dynamic filter"""
        # This would be implemented to query servers based on filter
        return []

    def add_server(self, server):
        """Add a server to this group"""
        if not self.is_dynamic:
            if server not in self.servers:
                self.servers.append(server)

    def remove_server(self, server):
        """Remove a server from this group"""
        if not self.is_dynamic:
            if server in self.servers:
                self.servers.remove(server)


class GroupPolicy(Base):
    """
    Group Policy Model

    Defines audit policies that can be applied to server groups.

    Attributes:
        id: Policy identifier
        name: Policy name
        description: Policy description

        # Audit settings
        audit_ids: JSON list of audit IDs to run
        cron_schedule: When to run audits
        timeout_seconds: Max execution time per audit

        # Notification settings
        notify_on_failure: Send notification on audit failure
        notify_on_warning: Send notification on warnings
        notification_channels: JSON list of channels

        # Thresholds
        min_pass_rate: Minimum pass rate (0-100)
        max_critical_findings: Max critical findings allowed

        # Metadata
        is_active: Enable/disable policy
        priority: Higher priority policies override lower
    """
    __tablename__ = 'group_policies'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False, index=True)
    description = Column(Text)

    # Audit settings
    audit_ids = Column(Text)  # JSON array of audit IDs
    cron_schedule = Column(String(100))
    timeout_seconds = Column(Integer, default=600)

    # Notification settings
    notify_on_failure = Column(Boolean, default=True)
    notify_on_warning = Column(Boolean, default=False)
    notification_channels = Column(Text)  # JSON: ["email", "slack", "webhook"]

    # Thresholds
    min_pass_rate = Column(Integer, default=80)  # 0-100
    max_critical_findings = Column(Integer, default=0)

    # Metadata
    is_active = Column(Boolean, default=True, nullable=False)
    priority = Column(Integer, default=50)  # Higher = more important
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    def to_dict(self):
        """Convert to dictionary representation"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'audit_ids': self.audit_ids,
            'cron_schedule': self.cron_schedule,
            'timeout_seconds': self.timeout_seconds,
            'notify_on_failure': self.notify_on_failure,
            'notify_on_warning': self.notify_on_warning,
            'notification_channels': self.notification_channels,
            'min_pass_rate': self.min_pass_rate,
            'max_critical_findings': self.max_critical_findings,
            'is_active': self.is_active,
            'priority': self.priority,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


# Association table for GroupPolicy <-> ServerGroup relationship
group_policy_assignment = Table(
    'group_policy_assignment',
    Base.metadata,
    Column('group_id', Integer, ForeignKey('server_groups.id', ondelete='CASCADE'), primary_key=True),
    Column('policy_id', Integer, ForeignKey('group_policies.id', ondelete='CASCADE'), primary_key=True),
    Column('assigned_at', DateTime, default=datetime.utcnow),
    extend_existing=True
)


def get_servers_in_group(group_id, db_session):
    """
    Get all servers in a group (handles both static and dynamic groups)

    Args:
        group_id: ServerGroup ID
        db_session: SQLAlchemy session

    Returns:
        list: List of Server objects
    """
    from models.database import Server
    import json
    import re

    group = db_session.query(ServerGroup).filter(ServerGroup.id == group_id).first()
    if not group:
        return []

    if not group.is_dynamic:
        return group.servers.all()

    # Dynamic group - apply filter
    if not group.dynamic_filter:
        return []

    try:
        filters = json.loads(group.dynamic_filter)
    except json.JSONDecodeError:
        return []

    query = db_session.query(Server)

    # Filter by tags
    if filters.get('tags'):
        for tag in filters['tags']:
            query = query.filter(Server.tags.contains(tag))

    # Filter by hostname pattern
    if filters.get('hostname_pattern'):
        pattern = filters['hostname_pattern'].replace('*', '%')
        query = query.filter(Server.hostname.like(pattern))

    # Filter by name pattern
    if filters.get('name_pattern'):
        pattern = filters['name_pattern'].replace('*', '%')
        query = query.filter(Server.name.like(pattern))

    return query.all()


def get_groups_for_server(server_id, db_session):
    """
    Get all groups a server belongs to (both static and dynamic)

    Args:
        server_id: Server ID
        db_session: SQLAlchemy session

    Returns:
        list: List of ServerGroup objects
    """
    from models.database import Server
    import json

    server = db_session.query(Server).filter(Server.id == server_id).first()
    if not server:
        return []

    # Static group memberships
    groups = list(server.groups)

    # Check dynamic groups
    dynamic_groups = db_session.query(ServerGroup).filter(
        ServerGroup.is_dynamic.is_(True)
    ).all()

    for group in dynamic_groups:
        if not group.dynamic_filter:
            continue

        try:
            filters = json.loads(group.dynamic_filter)
        except json.JSONDecodeError:
            continue

        matches = True

        # Check tag filters
        if filters.get('tags'):
            for tag in filters['tags']:
                if tag not in (server.tags or ''):
                    matches = False
                    break

        # Check hostname pattern
        if matches and filters.get('hostname_pattern'):
            import fnmatch
            if not fnmatch.fnmatch(server.hostname, filters['hostname_pattern']):
                matches = False

        # Check name pattern
        if matches and filters.get('name_pattern'):
            import fnmatch
            if not fnmatch.fnmatch(server.name, filters['name_pattern']):
                matches = False

        if matches and group not in groups:
            groups.append(group)

    return groups
