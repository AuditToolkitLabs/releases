

from datetime import datetime
from importlib import import_module
from sqlalchemy import (
    Column, Integer, String, Text, Float, Boolean,
    DateTime, ForeignKey, Index, LargeBinary
)
from sqlalchemy.orm import declarative_base, relationship
from .encrypted_field import EncryptedField

try:
    from .database import Base
except ImportError:
    Base = declarative_base()


def _resolve_terminal_session_recording_model():
    """Resolve TerminalSessionRecording within the active models package."""
    return import_module(f"{__package__}.terminal").TerminalSessionRecording


def _resolve_terminal_connection_profile_model():
    """Resolve TerminalConnectionProfile within the active models package."""
    return import_module(f"{__package__}.terminal").TerminalConnectionProfile


class TerminalConnectionProfile(Base):
    # Stores commonly used server connections with encrypted credentials.
    __tablename__ = 'terminal_connection_profiles'
    __table_args__ = (
        Index('idx_profiles_created_by', 'created_by_id'),
        Index('idx_profiles_environment', 'environment'),
        {'extend_existing': True}
    )

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Profile Identity
    name = Column(String(255), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)

    # Connection Details
    hostname = Column(String(255), nullable=False)
    port = Column(Integer, nullable=False, default=22)
    protocol = Column(String(20), nullable=False, default='ssh')  # ssh, winrm
    username = Column(String(100), nullable=False)

    # Authentication (encrypted with Fernet)
    password_encrypted = Column(Text, nullable=True)
    ssh_key_path = Column(String(500), nullable=True)
    ssh_key_encrypted = Column(Text, nullable=True)  # For storing key content

    # Connection Options
    use_sudo = Column(Boolean, nullable=False, default=False)
    default_shell = Column(String(50), nullable=False, default='bash')
    connection_timeout = Column(Integer, nullable=False, default=30)

    # Jump Host (bastion) configuration
    jump_host = Column(String(255), nullable=True)
    jump_port = Column(Integer, nullable=True, default=22)
    jump_username = Column(String(100), nullable=True)

    # Access Control
    created_by_id = Column(Integer, nullable=False)  # User ID who created
    is_shared = Column(Boolean, nullable=False, default=False)  # Share with other SuperAdmins

    # Per-Profile Access Restrictions (only enforced if profile_restrictions_enabled in settings)
    access_hours_start = Column(String(5), nullable=True)  # HH:MM format
    access_hours_end = Column(String(5), nullable=True)    # HH:MM format
    access_days = Column(String(100), nullable=True)       # Comma-separated: "mon,tue,wed"

    # Metadata
    tags = Column(Text, nullable=True)  # JSON array: ["production", "database"]
    environment = Column(String(50), nullable=True)  # dev, staging, production

    # Usage tracking
    last_used_at = Column(DateTime, nullable=True)
    use_count = Column(Integer, nullable=False, default=0)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    recordings = relationship(
        _resolve_terminal_session_recording_model,
        back_populates="connection_profile",
        cascade="all, delete-orphan"
    )


    def __repr__(self):
        return f"<TerminalConnectionProfile(id={self.id}, name='{self.name}', host='{self.hostname}')>"

    def to_dict(self, include_sensitive=False):
        """Convert to dictionary for JSON serialization"""
        data = {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'hostname': self.hostname,
            'port': self.port,
            'protocol': self.protocol,
            'username': self.username,
            'use_sudo': self.use_sudo,
            'default_shell': self.default_shell,
            'connection_timeout': self.connection_timeout,
            'jump_host': self.jump_host,
            'jump_port': self.jump_port,
            'jump_username': self.jump_username,
            'created_by_id': self.created_by_id,
            'is_shared': self.is_shared,
            'access_hours_start': self.access_hours_start or '',
            'access_hours_end': self.access_hours_end or '',
            'access_days': self.access_days or '',
            'tags': self.tags,
            'environment': self.environment,
            'last_used_at': self.last_used_at.isoformat() if self.last_used_at else None,
            'use_count': self.use_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'has_password': bool(self.password_encrypted),
            'has_ssh_key': bool(self.ssh_key_path or self.ssh_key_encrypted),
            'has_restrictions': bool(self.access_hours_start or self.access_hours_end or self.access_days)
        }

        # Include sensitive fields only when explicitly requested
        if include_sensitive:
            data['ssh_key_path'] = self.ssh_key_path
            # Note: Never return decrypted passwords/keys

        return data


class TerminalSessionRecording(Base):

    __tablename__ = 'terminal_session_recordings'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Recording Identity
    session_id = Column(String(100), unique=True, nullable=False, index=True)

    # Session Details
    user_id = Column(Integer, nullable=False)
    username = Column(String(100), nullable=False)  # Denormalized for query efficiency

    # Connection Info
    connection_profile_id = Column(
        Integer,
        ForeignKey('terminal_connection_profiles.id', ondelete='SET NULL'),
        nullable=True
    )
    server_hostname = Column(String(255), nullable=False)
    server_port = Column(Integer, nullable=False, default=22)
    protocol = Column(String(20), nullable=False, default='ssh')

    # Session Metadata
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    ended_at = Column(DateTime, nullable=True)
    duration_seconds = Column(Float, nullable=True)

    # Client Info
    client_ip = Column(String(45), nullable=True)  # IPv6 ready
    user_agent = Column(String(500), nullable=True)

    # Recording Data
    # Stored as JSONL (JSON Lines) with timing:
    # {"t": 0.0, "type": "o", "data": "Welcome to..."}
    # {"t": 0.5, "type": "i", "data": "ls -la\r\n"}
    # {"t": 0.6, "type": "o", "data": "total 48..."}
    recording_data = Column(EncryptedField(), nullable=True)  # JSONL format
    recording_size_bytes = Column(Integer, nullable=False, default=0)

    # Compressed recording for large sessions
    recording_compressed = Column(LargeBinary, nullable=True)  # gzip compressed
    is_compressed = Column(Boolean, nullable=False, default=False)

    # Event Counts
    input_event_count = Column(Integer, nullable=False, default=0)
    output_event_count = Column(Integer, nullable=False, default=0)
    command_count = Column(Integer, nullable=False, default=0)

    # Extracted Commands (for search/audit)
    commands_json = Column(EncryptedField(), nullable=True)  # JSON array of commands typed

    # Status
    status = Column(String(20), nullable=False, default='recording')  # recording, completed, failed
    error_message = Column(EncryptedField(), nullable=True)

    # Audit markers
    contains_sensitive_output = Column(Boolean, nullable=False, default=False)
    flagged_for_review = Column(Boolean, nullable=False, default=False)
    reviewed_by_id = Column(Integer, nullable=True)
    reviewed_at = Column(DateTime, nullable=True)
    review_notes = Column(EncryptedField(), nullable=True)

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    # Relationships
    connection_profile = relationship(
        _resolve_terminal_connection_profile_model,
        back_populates="recordings"
    )

    # Indexes
    __table_args__ = (
        Index('idx_recordings_user', 'user_id', 'started_at'),
        Index('idx_recordings_server', 'server_hostname', 'started_at'),
        Index('idx_recordings_status', 'status'),
        Index('idx_recordings_flagged', 'flagged_for_review'),
        {'extend_existing': True}
    )

    def __repr__(self):
        return f"<TerminalSessionRecording(id={self.id}, session='{self.session_id}', user='{self.username}')>"

    def to_dict(self, include_recording=False):
        """Convert to dictionary for JSON serialization"""
        data = {
            'id': self.id,
            'session_id': self.session_id,
            'user_id': self.user_id,
            'username': self.username,
            'connection_profile_id': self.connection_profile_id,
            'server_hostname': self.server_hostname,
            'server_port': self.server_port,
            'protocol': self.protocol,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'ended_at': self.ended_at.isoformat() if self.ended_at else None,
            'duration_seconds': self.duration_seconds,
            'client_ip': self.client_ip,
            'recording_size_bytes': self.recording_size_bytes,
            'is_compressed': self.is_compressed,
            'input_event_count': self.input_event_count,
            'output_event_count': self.output_event_count,
            'command_count': self.command_count,
            'commands': self.commands_json,
            'status': self.status,
            'error_message': self.error_message,
            'contains_sensitive_output': self.contains_sensitive_output,
            'flagged_for_review': self.flagged_for_review,
            'reviewed_by_id': self.reviewed_by_id,
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None,
            'review_notes': self.review_notes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

        # Include recording data only when explicitly requested
        if include_recording and not self.is_compressed:
            data['recording_data'] = self.recording_data

        return data

    def to_summary(self):
        """Return minimal summary for list views"""
        return {
            'id': self.id,
            'session_id': self.session_id,
            'username': self.username,
            'server_hostname': self.server_hostname,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'duration_seconds': self.duration_seconds,
            'command_count': self.command_count,
            'status': self.status,
            'flagged_for_review': self.flagged_for_review
        }


class TerminalAccessSettings(Base):

    __tablename__ = 'terminal_access_settings'
    __table_args__ = {'extend_existing': True}

    # Primary Key (always 1 for singleton)
    id = Column(Integer, primary_key=True, default=1)

    # Time-Based Access Control
    access_hours_start = Column(String(5), nullable=True)  # HH:MM format, e.g., "09:00"
    access_hours_end = Column(String(5), nullable=True)    # HH:MM format, e.g., "17:00"
    access_days = Column(String(100), nullable=True)       # Comma-separated: "mon,tue,wed,thu,fri"
    access_timezone = Column(String(50), nullable=True, default='UTC')

    # Feature Toggles
    terminal_enabled = Column(Boolean, nullable=False, default=True)
    recording_enabled = Column(Boolean, nullable=False, default=True)
    profiles_enabled = Column(Boolean, nullable=False, default=False)  # Disabled by default
    profile_restrictions_enabled = Column(Boolean, nullable=False, default=False)  # Per-profile access hours

    # Session Limits
    max_sessions = Column(Integer, nullable=False, default=5)
    session_timeout_minutes = Column(Integer, nullable=False, default=60)
    idle_timeout_minutes = Column(Integer, nullable=False, default=15)

    # Security
    require_secondary_auth = Column(Boolean, nullable=False, default=True)
    token_validity_minutes = Column(Integer, nullable=False, default=30)
    allowed_ips = Column(Text, nullable=True)  # Comma-separated IPs/CIDRs
    command_blacklist = Column(Text, nullable=True)  # Comma-separated patterns

    # Recording Settings
    recording_max_size_mb = Column(Integer, nullable=False, default=50)
    recording_retention_days = Column(Integer, nullable=False, default=90)

    # Audit
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL', use_alter=True), nullable=True)

    def __repr__(self):
        return f"<TerminalAccessSettings timezone={self.access_timezone}>"

    def get_access_hours(self):
        """Return access hours in HH:MM-HH:MM format or empty string"""
        if self.access_hours_start and self.access_hours_end:
            return f"{self.access_hours_start}-{self.access_hours_end}"
        return ""

    def to_dict(self):
        """Return full configuration as dictionary"""
        return {
            'access_hours_start': self.access_hours_start or '',
            'access_hours_end': self.access_hours_end or '',
            'access_hours': self.get_access_hours(),
            'access_days': self.access_days or '',
            'access_timezone': self.access_timezone or 'UTC',
            'terminal_enabled': self.terminal_enabled,
            'recording_enabled': self.recording_enabled,
            'profiles_enabled': self.profiles_enabled,
            'profile_restrictions_enabled': self.profile_restrictions_enabled,
            'max_sessions': self.max_sessions,
            'session_timeout_minutes': self.session_timeout_minutes,
            'idle_timeout_minutes': self.idle_timeout_minutes,
            'require_secondary_auth': self.require_secondary_auth,
            'token_validity_minutes': self.token_validity_minutes,
            'allowed_ips': self.allowed_ips or '',
            'command_blacklist': self.command_blacklist or '',
            'recording_max_size_mb': self.recording_max_size_mb,
            'recording_retention_days': self.recording_retention_days,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

    @classmethod
    def get_settings(cls, session):
        """Get or create singleton settings row"""
        settings = session.query(cls).filter_by(id=1).first()
        if not settings:
            settings = cls(id=1)
            session.add(settings)
            session.commit()
        return settings
