"""
User and Authentication Models for Security Audit Toolkit

Database schema for authentication and RBAC:
- users: User accounts with credentials and roles
- sessions: Active user sessions
- password_history: Previous password hashes (for reuse prevention)
- auth_audit_log: Authentication event logging

Author: Security Audit Toolkit Team
Date: March 2026
"""

from datetime import datetime, timedelta
import os
import secrets
import tempfile
from sqlalchemy import (
    Column, Integer, String, Boolean,
    DateTime, ForeignKey, Index
)
from sqlalchemy.orm import relationship
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from .database import Base
from .encrypted_field import EncryptedField


# =============================================================================
# Role Definitions and Permissions
# =============================================================================

class Role:
    """Role constants and permission mappings"""

    VIEWER = 'Viewer'
    OPERATOR = 'Operator'
    ANALYST = 'Analyst'
    ADMIN = 'Admin'
    SECURITY_ADMIN = 'SecurityAdmin'  # User/password management without full SuperAdmin
    SUPERADMIN = 'SuperAdmin'

    ALL_ROLES = [VIEWER, OPERATOR, ANALYST, ADMIN, SECURITY_ADMIN, SUPERADMIN]

    # Permission definitions
    PERMISSIONS = {
        VIEWER: [
            'view_reports',
            'view_history',
            'view_audits',
            'view_dashboard',
        ],
        OPERATOR: [
            'view_reports',
            'view_history',
            'view_audits',
            'view_dashboard',
            'run_audits',
            'view_servers',
            'view_hypervisors',
            'view_logs',
        ],
        ANALYST: [
            'view_reports',
            'view_history',
            'view_audits',
            'view_dashboard',
            'run_audits',
            'view_servers',
            'view_hypervisors',
            'view_logs',
            'create_plans',
            'edit_plans',
            'delete_plans',
            'create_schedules',
            'edit_schedules',
            'delete_schedules',
            'deploy_scripts',
            'run_discovery',
            'export_reports',
        ],
        ADMIN: [
            'view_reports',
            'view_history',
            'view_audits',
            'view_dashboard',
            'run_audits',
            'view_servers',
            'view_hypervisors',
            'view_logs',
            'create_plans',
            'edit_plans',
            'delete_plans',
            'create_schedules',
            'edit_schedules',
            'delete_schedules',
            'deploy_scripts',
            'run_discovery',
            'export_reports',
            'add_servers',
            'edit_servers',
            'delete_servers',
            'manage_servers',
            'manage_agents',
            'manage_schedules',
            'manage_users',
            'view_admin',
            'edit_settings',
        ],
        SECURITY_ADMIN: [
            # All Admin permissions
            'view_reports',
            'view_history',
            'view_audits',
            'view_dashboard',
            'run_audits',
            'view_servers',
            'view_hypervisors',
            'view_logs',
            'create_plans',
            'edit_plans',
            'delete_plans',
            'create_schedules',
            'edit_schedules',
            'delete_schedules',
            'deploy_scripts',
            'run_discovery',
            'export_reports',
            'add_servers',
            'edit_servers',
            'delete_servers',
            'manage_servers',
            'manage_agents',
            'manage_schedules',
            'manage_users',
            'view_admin',
            'edit_settings',
            # SecurityAdmin specific - user/security management
            'reset_passwords',        # Reset user passwords
            'unlock_accounts',        # Unlock locked accounts
            'force_password_change',  # Force password rotation
            'view_audit_log',         # View security audit logs
            'manage_sessions',        # Terminate user sessions
            'manage_mfa',             # Manage MFA for users
        ],
        SUPERADMIN: [
            # All permissions
            'view_reports',
            'view_history',
            'view_audits',
            'view_dashboard',
            'run_audits',
            'view_servers',
            'view_hypervisors',
            'view_logs',
            'create_plans',
            'edit_plans',
            'delete_plans',
            'create_schedules',
            'edit_schedules',
            'delete_schedules',
            'deploy_scripts',
            'run_discovery',
            'export_reports',
            'add_servers',
            'edit_servers',
            'delete_servers',
            'manage_servers',
            'manage_agents',
            'manage_schedules',
            'manage_users',
            'view_admin',
            'edit_settings',
            # SuperAdmin only
            'delete_all_data',
            'manage_roles',
            'regenerate_api_keys',
            'view_audit_log',
            'manage_backups',
            'system_maintenance',
        ],
    }

    @classmethod
    def get_permissions(cls, role):
        """Get all permissions for a role"""
        return cls.PERMISSIONS.get(role, [])

    @classmethod
    def has_permission(cls, role, permission):
        """Check if a role has a specific permission"""
        return permission in cls.PERMISSIONS.get(role, [])

    @classmethod
    def get_role_level(cls, role):
        """Get numeric level for role comparison (higher = more privileges)"""
        levels = {
            cls.VIEWER: 1,
            cls.OPERATOR: 2,
            cls.ANALYST: 3,
            cls.ADMIN: 4,
            cls.SECURITY_ADMIN: 5,  # User admin but not system admin
            cls.SUPERADMIN: 6,
        }
        return levels.get(role, 0)


# =============================================================================
# User Model
# =============================================================================

class User(Base, UserMixin):
    """
    User account table

    Supports local and external authentication providers.
    Passwords are hashed using werkzeug security (pbkdf2:sha256).
    """
    __tablename__ = 'users'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Identity
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, nullable=True, index=True)  # Nullable for local users
    display_name = Column(String(100), nullable=True)

    # Authentication
    password_hash = Column(String(255), nullable=True)  # NULL for external auth
    auth_provider = Column(String(20), default='local')  # local, ldap, entra, saml, oidc
    external_id = Column(String(255), nullable=True)  # ID from external provider

    # Role and Status
    role = Column(String(20), default=Role.VIEWER, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_locked = Column(Boolean, default=False, nullable=False)

    # Security
    failed_login_attempts = Column(Integer, default=0, nullable=False)
    lockout_until = Column(DateTime, nullable=True)
    password_changed_at = Column(DateTime, nullable=True)
    must_change_password = Column(Boolean, default=False, nullable=False)

    # MFA
    mfa_enabled = Column(Boolean, default=False, nullable=False)
    mfa_secret = Column(EncryptedField(length=1024), nullable=True)  # Encrypted TOTP secret
    mfa_backup_codes = Column(EncryptedField(), nullable=True)  # Encrypted JSON list of hashed backup codes
    mfa_enrolled_at = Column(DateTime, nullable=True)  # When MFA was enabled
    mfa_last_used_at = Column(DateTime, nullable=True)  # Last successful MFA verification

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login_at = Column(DateTime, nullable=True)
    last_login_ip = Column(String(45), nullable=True)

    # Legal acceptance tracking
    disclaimer_accepted_at = Column(DateTime, nullable=True)  # When user accepted the disclaimer
    disclaimer_version = Column(String(20), nullable=True)    # Version of disclaimer accepted (e.g., "4.3.1")

    # Break-Glass Recovery Account
    # The built-in admin account is like 'root' in Linux - it ALWAYS uses local authentication
    # regardless of SSO/LDAP/Entra settings. This ensures operators can always recover access.
    is_builtin_admin = Column(Boolean, default=False, nullable=False)

    # Relationships
    sessions = relationship(
        "UserSession",
        back_populates="user",
        cascade="all, delete-orphan"
    )
    password_history = relationship(
        "PasswordHistory",
        back_populates="user",
        cascade="all, delete-orphan"
    )
    audit_logs = relationship(
        "AuthAuditLog",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    # Indexes
    __table_args__ = (
        Index('ix_users_provider_external', 'auth_provider', 'external_id'),
    )

    def __repr__(self):
        return f"<User(id={self.id}, username='{self.username}', role='{self.role}')>"

    # Password Management
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password)
        self.password_changed_at = datetime.utcnow()
        self.must_change_password = False

    def check_password(self, password):
        """Verify password against stored hash"""
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, password)

    # Role and Permission Checks
    def has_role(self, *roles):
        """Check if user has one of the specified roles (hierarchy-aware).

        This now implements role inheritance:
        - SuperAdmin passes all role checks (highest level)
        - Admin passes Admin or lower role checks
        - etc.

        Example:
            user.has_role('Admin') returns True for both Admin AND SuperAdmin users
            user.has_role('SuperAdmin') returns True only for SuperAdmin users
        """
        if not roles:
            return False
        # Get the minimum required role level from the requested roles
        min_required_level = min(Role.get_role_level(role) for role in roles)
        # Check if user's role level meets or exceeds the minimum requirement
        return Role.get_role_level(self.role) >= min_required_level

    def has_permission(self, permission):
        """Check if user has a specific permission"""
        return Role.has_permission(self.role, permission)

    def has_minimum_role(self, minimum_role):
        """Check if user has at least the specified role level"""
        return Role.get_role_level(self.role) >= Role.get_role_level(minimum_role)

    def get_permissions(self):
        """Get all permissions for this user's role"""
        return Role.get_permissions(self.role)

    # Account Status
    def is_account_locked(self):
        """Check if account is locked (either manually or due to failed attempts)"""
        if self.is_locked:
            return True
        if self.lockout_until and self.lockout_until > datetime.utcnow():
            return True
        return False

    def record_failed_login(self, max_attempts=None, lockout_minutes=None):
        """
        Record failed login attempt and possibly lock account.

        Uses security settings for max_attempts and lockout_minutes if not provided.
        """
        # Load from security settings if not explicitly provided
        if max_attempts is None or lockout_minutes is None:
            try:
                from security_settings import get_login_security
                login_settings = get_login_security()
                if max_attempts is None:
                    max_attempts = login_settings['max_attempts']
                if lockout_minutes is None:
                    lockout_minutes = login_settings['lockout_minutes']
            except ImportError:
                # Fallback defaults if security_settings not available
                max_attempts = max_attempts or 5
                lockout_minutes = lockout_minutes or 30

        self.failed_login_attempts += 1
        if self.failed_login_attempts >= max_attempts:
            self.lockout_until = datetime.utcnow() + timedelta(minutes=lockout_minutes)

    def record_successful_login(self, ip_address=None):
        """Record successful login"""
        self.failed_login_attempts = 0
        self.lockout_until = None
        self.last_login_at = datetime.utcnow()
        if ip_address:
            self.last_login_ip = ip_address

    def unlock_account(self):
        """Unlock a locked account"""
        self.is_locked = False
        self.failed_login_attempts = 0
        self.lockout_until = None

    def is_break_glass_account(self):
        """
        Check if this is the break-glass recovery account.

        The break-glass account (like 'root' in Linux) ALWAYS uses local
        authentication regardless of LDAP/SSO/Entra settings. This ensures
        operators can always recover access to the system.

        Returns:
            True if this is the built-in admin account that should bypass SSO
        """
        return (
            self.is_builtin_admin and
            self.auth_provider == 'local' and
            self.role == Role.SUPERADMIN
        )

    @property
    def last_login(self):
        """Alias for last_login_at for compatibility"""
        return self.last_login_at

    @property
    def locked_until(self):
        """Alias for lockout_until for compatibility"""
        return self.lockout_until

    def to_dict(self):
        """Convert to dictionary for JSON serialization (excludes sensitive fields)"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'display_name': self.display_name,
            'role': self.role,
            'auth_provider': self.auth_provider,
            'is_active': self.is_active,
            'is_locked': self.is_locked or self.is_account_locked(),
            'is_builtin_admin': self.is_builtin_admin,
            'mfa_enabled': self.mfa_enabled,
            'mfa_enrolled_at': self.mfa_enrolled_at.isoformat() if self.mfa_enrolled_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login_at': self.last_login_at.isoformat() if self.last_login_at else None,
            'permissions': self.get_permissions(),
        }


# =============================================================================
# Session Model
# =============================================================================

class UserSession(Base):
    """
    Active user sessions

    Tracks all active sessions for a user to allow:
    - Multiple device login
    - Session management (view/revoke sessions)
    - Security monitoring
    """
    __tablename__ = 'user_sessions'

    # Primary Key
    id = Column(String(64), primary_key=True)  # Secure random token

    # Foreign Keys
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False)

    # Session Info
    ip_address = Column(String(45), nullable=True)  # IPv4 or IPv6
    user_agent = Column(EncryptedField(), nullable=True)
    device_info = Column(String(255), nullable=True)  # Parsed device type

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    last_active_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    # Status
    is_active = Column(Boolean, default=True, nullable=False)

    # Relationships
    user = relationship("User", back_populates="sessions")

    # Indexes
    __table_args__ = (
        Index('ix_sessions_user_active', 'user_id', 'is_active'),
        Index('ix_sessions_expires', 'expires_at'),
    )

    def __repr__(self):
        return f"<UserSession(id={self.id[:8]}..., user_id={self.user_id})>"

    @classmethod
    def generate_session_id(cls):
        """Generate a cryptographically secure session ID"""
        return secrets.token_urlsafe(48)

    def is_expired(self):
        """Check if session has expired"""
        return datetime.utcnow() > self.expires_at

    def is_valid(self):
        """Check if session is both active and not expired"""
        return self.is_active and not self.is_expired()

    def refresh(self, extend_minutes=60):
        """Extend session expiry (sliding window)"""
        self.last_active_at = datetime.utcnow()
        new_expiry = datetime.utcnow() + timedelta(minutes=extend_minutes)
        if new_expiry > self.expires_at:
            self.expires_at = new_expiry

    def revoke(self):
        """Revoke/invalidate this session"""
        self.is_active = False


# =============================================================================
# Password History Model
# =============================================================================

class PasswordHistory(Base):
    """
    Password history for preventing password reuse

    Stores hashed versions of previous passwords.
    """
    __tablename__ = 'password_history'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign Keys
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False)

    # Password Hash
    password_hash = Column(String(255), nullable=False)

    # Timestamp
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    # Relationships
    user = relationship("User", back_populates="password_history")

    # Indexes
    __table_args__ = (
        Index('ix_password_history_user', 'user_id'),
    )


# =============================================================================
# Authentication Audit Log Model
# =============================================================================

class AuthAuditLog(Base):
    """
    Audit log for authentication events

    Records all authentication-related events for security monitoring.
    """
    __tablename__ = 'auth_audit_log'

    # Primary Key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign Keys (nullable for failed logins with unknown user)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'), nullable=True)

    # Event Details
    event_type = Column(String(50), nullable=False, index=True)
    # Events: login, logout, failed_login, password_change, password_reset,
    #         role_change, account_locked, account_unlocked, mfa_enabled,
    #         mfa_disabled, session_revoked, api_key_generated

    username = Column(String(50), nullable=True)  # For failed logins
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(EncryptedField(), nullable=True)

    # Additional Details (JSON)
    details = Column(EncryptedField(), nullable=True)  # JSON string with extra info

    # Outcome
    success = Column(Boolean, default=True, nullable=False)
    failure_reason = Column(String(255), nullable=True)

    # Timestamp
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)

    # Relationships
    user = relationship("User", back_populates="audit_logs")

    # Indexes
    __table_args__ = (
        Index('ix_audit_log_user_time', 'user_id', 'created_at'),
        Index('ix_audit_log_event', 'event_type', 'created_at'),
    )

    def __repr__(self):
        return f"<AuthAuditLog(id={self.id}, event='{self.event_type}', user_id={self.user_id})>"


# =============================================================================
# Helper Functions
# =============================================================================

def generate_secure_password(length=24):
    """
    Generate a cryptographically secure random password.

    Returns:
        A secure random password with mixed case, digits, and symbols
    """
    import string
    # Use a mix of characters for strong entropy
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    # Use secrets.choice for cryptographic randomness
    password = ''.join(secrets.choice(alphabet) for _ in range(length))
    return password


def _env_flag(name, default=False):
    """Parse conventional truthy/falsey environment flag values."""
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {'1', 'true', 'yes', 'on'}


def get_initial_admin_credentials_file_candidates():
    """Return ordered candidate paths for initial admin credentials file."""
    configured_path = os.getenv('INITIAL_ADMIN_CREDENTIALS_FILE', '').strip()
    programdata = os.getenv('PROGRAMDATA', '').strip()
    programdata_runtime_path = os.path.join(
        programdata,
        'SecurityAuditToolkit',
        'runtime',
        'initial-admin-credentials.txt',
    ) if programdata else ''
    temp_credentials_path = os.path.join(tempfile.gettempdir(), 'audit-toolkit-initial-admin-credentials.txt')
    return [
        configured_path,
        programdata_runtime_path,
        '/var/lib/audit-toolkit/initial-admin-credentials.txt',
        '/etc/audit-toolkit/initial-admin-credentials.txt',
        '/opt/audit-toolkit/data/initial-admin-credentials.txt',
        temp_credentials_path,
    ]


def get_initial_admin_credentials_file_path():
    """Return first readable credentials file path, otherwise None."""
    candidates = [path for path in get_initial_admin_credentials_file_candidates() if path]
    for path in candidates:
        try:
            if not os.path.exists(path):
                continue
            with open(path, 'r', encoding='utf-8'):
                pass
            return path
        except OSError:
            continue
    return None


def read_initial_admin_credentials():
    """Read initial admin credentials from persisted file, if available."""
    credentials_path = get_initial_admin_credentials_file_path()
    if not credentials_path:
        return None

    username = ''
    password = ''
    try:
        with open(credentials_path, 'r', encoding='utf-8') as cred_file:
            for raw_line in cred_file:
                line = raw_line.strip()
                if not line or line.startswith('#'):
                    continue
                if line.startswith('Username:'):
                    username = line.split(':', 1)[1].strip()
                elif line.startswith('Password:'):
                    password = line.split(':', 1)[1].strip()
    except OSError:
        return None

    if not username or not password:
        return None

    return {
        'path': credentials_path,
        'username': username,
        'password': password,
    }


def remove_initial_admin_credentials_file():
    """Remove initial admin credentials file if present."""
    for path in get_initial_admin_credentials_file_candidates():
        if not path:
            continue
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            continue


def persist_initial_admin_credentials(username, password):
    """
    Persist initial admin credentials to a root/operator-readable file.

    Returns:
        Path to credentials file if persisted, otherwise None.
    """
    timestamp_utc = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
    file_contents = (
        "# Security Audit Toolkit - Initial Admin Credentials\n"
        "# Generated once during first successful startup\n"
        f"Generated UTC: {timestamp_utc}\n"
        f"Username: {username}\n"
        f"Password: {password}\n"
        "MustChangePassword: true\n"
    )

    candidate_paths = get_initial_admin_credentials_file_candidates()

    for target_path in candidate_paths:
        if not target_path:
            continue
        try:
            target_dir = os.path.dirname(target_path)
            if target_dir:
                os.makedirs(target_dir, mode=0o700, exist_ok=True)
            with open(target_path, 'w', encoding='utf-8') as cred_file:
                cred_file.write(file_contents)
            os.chmod(target_path, 0o600)
            return target_path
        except OSError:
            continue

    return None


def create_initial_admin(db_session, username='admin', email='admin@localhost',
                         password=None):
    """
    Create initial admin user if no users exist.

    This is the "break glass" recovery account - like 'root' in Linux.
    It ALWAYS authenticates locally regardless of LDAP/SSO settings,
    ensuring operators can always recover access to the system.

    The is_builtin_admin flag marks this as the recovery account.

    SECURITY HARDENING:
    - If no password provided, generates a cryptographically random one
    - Password is logged ONCE to console/logs for operator to capture
    - Password is NEVER stored in plaintext anywhere
    - must_change_password=True forces immediate password change

    Args:
        db_session: Database session
        username: Admin username (default: 'admin')
        email: Admin email (default: 'admin@localhost')
        password: Optional explicit password. If None, generates random.

    Returns:
        Tuple of (User instance, generated_password) if created,
        (None, None) if users already exist
    """
    from sqlalchemy.exc import IntegrityError
    import logging

    logger = logging.getLogger(__name__)

    # Check if any users exist
    if db_session.query(User).count() > 0:
        return None, None

    # Resolve initial password source
    flask_env = os.getenv('FLASK_ENV', '').strip().lower()
    runtime_env = os.getenv('ENVIRONMENT', '').strip().lower()
    is_production = flask_env == 'production' or runtime_env == 'production'

    env_initial_password = os.getenv('INITIAL_ADMIN_PASSWORD', '').strip()
    env_admin_password = os.getenv('ADMIN_PASSWORD', '').strip()

    randomize_initial_password = _env_flag('AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD', False)
    installer_default_password = os.getenv('AUDIT_TOOLKIT_DEFAULT_INITIAL_ADMIN_PASSWORD', '').strip() or 'ChangeMe123!'

    if password:
        generated_password = password
        password_source = 'argument'  # nosec B105
    elif env_initial_password:
        generated_password = env_initial_password
        password_source = 'env_initial_admin_password'  # nosec B105
    elif env_admin_password:
        generated_password = env_admin_password
        password_source = 'env_admin_password'  # nosec B105
    elif randomize_initial_password:
        generated_password = generate_secure_password(24)
        password_source = 'generated_random'  # nosec B105
    else:
        generated_password = installer_default_password
        password_source = 'installer_default' if is_production else 'dev_default'  # nosec B105

    password_was_generated = password_source == 'generated_random'  # nosec B105

    admin = User(
        username=username,
        email=email,
        display_name='Administrator',
        role=Role.SUPERADMIN,
        auth_provider='local',
        is_active=True,
        must_change_password=True,  # Force password change on first login
        is_builtin_admin=True,  # Mark as break-glass recovery account
    )
    admin.set_password(generated_password)
    admin.must_change_password = True

    try:
        db_session.add(admin)
        db_session.commit()
    except IntegrityError:
        # Race condition: another worker already created the admin
        db_session.rollback()
        return None, None

    # Log the creation
    try:
        log_entry = AuthAuditLog(
            user_id=admin.id,
            event_type='account_created',
            details='{"method": "initial_setup", "role": "SuperAdmin", "password_generated": %s, "password_source": "%s"}' % (
                str(password_was_generated).lower(),
                password_source
            ),
            success=True,
        )
        db_session.add(log_entry)
        db_session.commit()
    except IntegrityError:
        db_session.rollback()

    # Persist and display initial credentials once for operator capture
    credentials_file = persist_initial_admin_credentials(username, generated_password)

    logger.critical("=" * 70)
    logger.critical("INITIAL ADMIN CREDENTIALS - SAVE THESE NOW!")
    logger.critical("=" * 70)
    logger.critical("Username: %s", username)
    logger.critical("Password: %s", generated_password)
    logger.critical("Password source: %s", password_source)
    if credentials_file:
        logger.critical("Credentials file: %s", credentials_file)
    else:
        logger.critical("Credentials file: unavailable (failed to write)")
    logger.critical("=" * 70)
    logger.critical("This password will NOT be displayed again.")
    logger.critical("You MUST change this password on first login.")
    logger.critical("Delete the credentials file after first successful login.")
    logger.critical("=" * 70)
    # Also print to stdout/stderr for console capture
    print("\n" + "=" * 70)
    print("INITIAL ADMIN CREDENTIALS - SAVE THESE NOW!")
    print("=" * 70)
    print(f"Username: {username}")
    print(f"Password: {generated_password}")
    print(f"Password source: {password_source}")
    if credentials_file:
        print(f"Credentials file: {credentials_file}")
    else:
        print("Credentials file: unavailable (failed to write)")
    print("=" * 70)
    print("This password will NOT be displayed again.")
    print("You MUST change this password on first login.")
    print("Delete the credentials file after first successful login.")
    print("=" * 70 + "\n")

    return admin, generated_password


def log_break_glass_usage(db_session, user, ip_address=None, reason=None):
    """
    Log and alert when the break-glass admin account is used.

    This should be called on every successful login of the break-glass account.
    If other SuperAdmin accounts exist, this raises a security alert.

    Args:
        db_session: Database session
        user: The user who logged in
        ip_address: Source IP of the login
        reason: Optional reason for using break-glass access
    """
    import logging
    logger = logging.getLogger(__name__)

    if not user.is_break_glass_account():
        return

    # Check if other SuperAdmins exist (indicating break-glass usage post-setup)
    other_superadmins = db_session.query(User).filter(
        User.role == Role.SUPERADMIN,
        User.id != user.id,
        User.is_active.is_(True)
    ).count()

    alert_level = 'WARNING' if other_superadmins > 0 else 'INFO'

    # Log the event
    details = {
        'event': 'break_glass_access',
        'ip_address': ip_address,
        'other_superadmins_exist': other_superadmins > 0,
        'reason': reason,
    }

    try:
        import json
        log_entry = AuthAuditLog(
            user_id=user.id,
            event_type='break_glass_access',
            ip_address=ip_address,
            details=json.dumps(details),
            success=True,
        )
        db_session.add(log_entry)
        db_session.commit()
    except Exception:
        db_session.rollback()

    # Alert if this is post-setup usage
    if other_superadmins > 0:
        logger.warning("=" * 70)
        logger.warning("SECURITY ALERT: Break-glass admin account accessed!")
        logger.warning("=" * 70)
        logger.warning(f"IP Address: {ip_address}")
        logger.warning(f"Other SuperAdmin accounts exist: {other_superadmins}")
        logger.warning("This should only be used for emergency recovery!")
        logger.warning("=" * 70)
    else:
        logger.info(f"Break-glass admin login from {ip_address} (initial setup)")


def can_disable_break_glass(db_session, break_glass_user_id):
    """
    Check if the break-glass admin can be safely disabled.

    The break-glass account can only be disabled if:
    1. At least one OTHER active SuperAdmin exists
    2. That SuperAdmin has logged in successfully at least once

    Args:
        db_session: Database session
        break_glass_user_id: ID of the break-glass account

    Returns:
        Tuple of (can_disable: bool, reason: str)
    """
    # Find other active SuperAdmins
    other_superadmins = db_session.query(User).filter(
        User.role == Role.SUPERADMIN,
        User.id != break_glass_user_id,
        User.is_active.is_(True)
    ).all()

    if not other_superadmins:
        return False, "No other SuperAdmin accounts exist. Create another SuperAdmin first."

    # Check if any other SuperAdmin has logged in
    logged_in_admins = [u for u in other_superadmins if u.last_login_at is not None]
    if not logged_in_admins:
        return False, "No other SuperAdmin has logged in yet. At least one must verify access first."

    return True, f"Safe to disable. {len(logged_in_admins)} other SuperAdmin(s) have verified access."


def disable_break_glass_account(db_session, break_glass_user_id, disabled_by_user_id):
    """
    Disable the break-glass admin account.

    Args:
        db_session: Database session
        break_glass_user_id: ID of the break-glass account to disable
        disabled_by_user_id: ID of the user performing the action

    Returns:
        Tuple of (success: bool, message: str)
    """
    import logging
    logger = logging.getLogger(__name__)

    can_disable, reason = can_disable_break_glass(db_session, break_glass_user_id)
    if not can_disable:
        return False, reason

    break_glass_user = db_session.query(User).filter_by(id=break_glass_user_id).first()
    if not break_glass_user:
        return False, "Break-glass account not found"

    if not break_glass_user.is_builtin_admin:
        return False, "This is not the break-glass account"

    # Disable the account
    break_glass_user.is_active = False

    # Log the action
    try:
        import json
        log_entry = AuthAuditLog(
            user_id=break_glass_user_id,
            event_type='break_glass_disabled',
            details=json.dumps({
                'disabled_by': disabled_by_user_id,
                'reason': 'Manual disable after establishing other SuperAdmin'
            }),
            success=True,
        )
        db_session.add(log_entry)
        db_session.commit()
    except Exception:
        db_session.rollback()
        return False, "Failed to log the action"

    logger.warning(f"Break-glass admin account (id={break_glass_user_id}) disabled by user {disabled_by_user_id}")
    return True, "Break-glass account disabled successfully"


__all__ = [
    'Role',
    'User',
    'UserSession',
    'PasswordHistory',
    'AuthAuditLog',
    'create_initial_admin',
    'generate_secure_password',
    'read_initial_admin_credentials',
    'log_break_glass_usage',
    'can_disable_break_glass',
    'disable_break_glass_account',
]
