#!/usr/bin/env python3
"""
Notification System for Scheduled Audits

Sends notifications via email and webhooks when scheduled audits complete.

Supported notification methods:
- Email (SMTP)
- Webhooks (HTTP POST)

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import smtplib
import logging
import requests
import socket
import ipaddress
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from urllib.parse import urlparse

# Import comprehensive SSRF protection module
try:
    from validators_network import validate_url as validate_ssrf_url
    ENHANCED_SSRF = True
except ImportError:
    ENHANCED_SSRF = False

logger = logging.getLogger(__name__)


def is_safe_webhook_url(url: str) -> bool:
    """
    Validate webhook URL to prevent SSRF attacks.
    Blocks requests to private/internal IP ranges and cloud metadata endpoints.

    Uses enhanced SSRF protection from validators_network.py if available.
    """
    # Use enhanced SSRF protection if available
    if ENHANCED_SSRF:
        is_valid, error_msg, _ = validate_ssrf_url(url, dns_resolve=True)
        if not is_valid:
            logger.warning(f"SSRF protection: {error_msg}")
        return is_valid

    # Fallback to basic SSRF protection
    try:
        parsed = urlparse(url)

        # Only allow http/https schemes
        if parsed.scheme not in ('http', 'https'):
            logger.warning(f"SSRF protection: Invalid scheme in webhook URL: {url}")
            return False

        hostname = parsed.hostname
        if not hostname:
            return False

        # Resolve hostname to IP
        try:
            ip_str = socket.gethostbyname(hostname)
            ip_obj = ipaddress.ip_address(ip_str)

            # Block private, loopback, link-local, and reserved IPs
            if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_reserved:
                logger.warning(f"SSRF protection: Blocked webhook to internal IP: {url} -> {ip_str}")
                return False

        except socket.gaierror:
            # Can't resolve - allow but log warning
            logger.warning(f"Could not resolve webhook hostname: {hostname}")
            return True  # Allow unresolvable hostnames for external services

        return True

    except Exception as e:
        logger.error(f"Error validating webhook URL: {e}")
        return False


class NotificationManager:
    """Manages sending notifications for scheduled audit events"""

    def __init__(self):
        # Email configuration
        self.smtp_host = os.getenv('SMTP_HOST', 'localhost')
        self.smtp_port = int(os.getenv('SMTP_PORT', 587))
        self.smtp_user = os.getenv('SMTP_USER', '')
        self.smtp_password = os.getenv('SMTP_PASSWORD', '')
        self.smtp_from = os.getenv('SMTP_FROM', 'audit-toolkit@example.com')
        self.smtp_use_tls = os.getenv('SMTP_USE_TLS', 'true').lower() == 'true'

        # Webhook configuration
        self.webhook_timeout = int(os.getenv('WEBHOOK_TIMEOUT', 10))
        self.webhook_retry = int(os.getenv('WEBHOOK_RETRY', 2))

    def send_email(self, to_emails: List[str], subject: str, body: str,
                   html_body: Optional[str] = None) -> bool:
        """
        Send email notification

        Args:
            to_emails: List of recipient email addresses
            subject: Email subject line
            body: Plain text email body
            html_body: Optional HTML email body

        Returns:
            bool: True if sent successfully
        """
        if not to_emails:
            logger.warning("No email recipients specified")
            return False

        try:
            # Create message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = self.smtp_from
            msg['To'] = ', '.join(to_emails)
            msg['Date'] = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S +0000')

            # Attach text part
            text_part = MIMEText(body, 'plain')
            msg.attach(text_part)

            # Attach HTML part if provided
            if html_body:
                html_part = MIMEText(html_body, 'html')
                msg.attach(html_part)

            # Connect and send
            if self.smtp_use_tls:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)
                server.starttls()
            else:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)

            if self.smtp_user and self.smtp_password:
                server.login(self.smtp_user, self.smtp_password)

            server.sendmail(self.smtp_from, to_emails, msg.as_string())
            server.quit()

            logger.info(f"Email sent to {len(to_emails)} recipients: {subject}")
            return True

        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            return False

    def send_email_with_attachment(
        self,
        to_emails: List[str],
        subject: str,
        body: str,
        attachment_data: bytes,
        attachment_filename: str,
        attachment_mime_type: str = 'application/pdf',
        html_body: Optional[str] = None
    ) -> bool:
        """
        Send email notification with file attachment

        Args:
            to_emails: List of recipient email addresses
            subject: Email subject line
            body: Plain text email body
            attachment_data: Binary content of the attachment
            attachment_filename: Filename for the attachment
            attachment_mime_type: MIME type of attachment (default: application/pdf)
            html_body: Optional HTML email body

        Returns:
            bool: True if sent successfully
        """
        if not to_emails:
            logger.warning("No email recipients specified")
            return False

        try:
            # Create multipart message for mixed content (text + attachment)
            msg = MIMEMultipart('mixed')
            msg['Subject'] = subject
            msg['From'] = self.smtp_from
            msg['To'] = ', '.join(to_emails)
            msg['Date'] = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S +0000')

            # Create alternative subpart for text/html
            msg_alternative = MIMEMultipart('alternative')

            # Attach text part
            text_part = MIMEText(body, 'plain')
            msg_alternative.attach(text_part)

            # Attach HTML part if provided
            if html_body:
                html_part = MIMEText(html_body, 'html')
                msg_alternative.attach(html_part)

            msg.attach(msg_alternative)

            # Create and attach the file
            maintype, subtype = attachment_mime_type.split('/', 1)
            attachment_part = MIMEBase(maintype, subtype)
            attachment_part.set_payload(attachment_data)
            encoders.encode_base64(attachment_part)
            attachment_part.add_header(
                'Content-Disposition',
                'attachment',
                filename=attachment_filename
            )
            msg.attach(attachment_part)

            # Connect and send
            if self.smtp_use_tls:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)
                server.starttls()
            else:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)

            if self.smtp_user and self.smtp_password:
                server.login(self.smtp_user, self.smtp_password)

            server.sendmail(self.smtp_from, to_emails, msg.as_string())
            server.quit()

            logger.info(f"Email with attachment sent to {len(to_emails)} recipients: {subject} [{attachment_filename}]")
            return True

        except Exception as e:
            logger.error(f"Failed to send email with attachment: {e}")
            return False

    def send_webhook(self, webhook_url: str, payload: Dict[str, Any]) -> bool:
        """
        Send webhook notification via HTTP POST

        Args:
            webhook_url: Webhook endpoint URL
            payload: JSON payload to send

        Returns:
            bool: True if sent successfully
        """
        if not webhook_url:
            logger.warning("No webhook URL specified")
            return False

        # SSRF protection: validate webhook URL
        if not is_safe_webhook_url(webhook_url):
            logger.error(f"Webhook URL blocked by SSRF protection: {webhook_url}")
            return False

        try:
            for attempt in range(self.webhook_retry + 1):
                try:
                    response = requests.post(
                        webhook_url,
                        json=payload,
                        timeout=self.webhook_timeout,
                        headers={'Content-Type': 'application/json'}
                    )

                    if response.status_code >= 200 and response.status_code < 300:
                        logger.info(f"Webhook sent successfully: {webhook_url}")
                        return True
                    else:
                        logger.warning(f"Webhook returned status {response.status_code}: {webhook_url}")
                        if attempt < self.webhook_retry:
                            continue
                        return False

                except requests.exceptions.RequestException as e:
                    logger.error(f"Webhook request failed (attempt {attempt + 1}): {e}")
                    if attempt < self.webhook_retry:
                        continue
                    return False

            return False

        except Exception as e:
            logger.error(f"Failed to send webhook: {e}")
            return False

    def notify_schedule_execution(self, schedule_name: str, server_name: str,
                                   audit_name: str, status: str,
                                   execution_summary: Dict[str, Any],
                                   email_recipients: Optional[List[str]] = None,
                                   webhook_urls: Optional[List[str]] = None) -> Dict[str, bool]:
        """
        Send notifications about scheduled audit execution

        Args:
            schedule_name: Name of the schedule
            server_name: Target server name
            audit_name: Audit that was executed
            status: Execution status (success/failure/error)
            execution_summary: Summary of execution results
            email_recipients: List of email addresses
            webhook_urls: List of webhook URLs

        Returns:
            dict: Notification delivery status
        """
        results = {'email_sent': False, 'webhooks_sent': 0}

        # Prepare notification content
        status_emoji = {
            'success': '✅',
            'failure': '❌',
            'error': '⚠️',
            'warning': '⚠️'
        }.get(status, '❓')

        subject = f"{status_emoji} Scheduled Audit: {schedule_name}"

        # Plain text body
        body = """
Scheduled Audit Execution Report
{'=' * 50}

Schedule: {schedule_name}
Server: {server_name}
Audit: {audit_name}
Status: {status.upper()}
Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}

Execution Summary:
------------------
Total Checks: {execution_summary.get('total_checks', 0)}
Passed: {execution_summary.get('passed_checks', 0)}
Failed: {execution_summary.get('failed_checks', 0)}
Warnings: {execution_summary.get('warned_checks', 0)}
Skipped: {execution_summary.get('skipped_checks', 0)}
Duration: {execution_summary.get('duration_seconds', 0):.2f}s

{'✓ All checks passed!' if status == 'success' else '✗ Some checks failed or had warnings'}

---
Security Audit Toolkit
Automated Audit Execution System
        """

        # HTML body
        html_body = """
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
        .header {{ background: #f4f4f4; padding: 20px; border-left: 4px solid {{'#28a745' if status == 'success' else '#dc3545'}}; }}
        .header h2 {{ margin: 0; color: #333; }}
        .content {{ padding: 20px; }}
        .summary {{ background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0; }}
        .summary-item {{ display: flex; justify-content: space-between; padding: 5px 0; }}
        .label {{ font-weight: bold; }}
        .value {{ text-align: right; }}
        .status {{ font-size: 24px; padding: 10px; text-align: center; }}
        .footer {{ margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; color: #777; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="header">
        <h2>{status_emoji} Scheduled Audit Execution Report</h2>
    </div>
    <div class="content">
        <div style="margin-bottom: 20px;">
            <strong>Schedule:</strong> {schedule_name}<br>
            <strong>Server:</strong> {server_name}<br>
            <strong>Audit:</strong> {audit_name}<br>
            <strong>Time:</strong> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}<br>
        </div>

        <div class="status" style="background: {{'#d4edda' if status == 'success' else '#f8d7da'}}; color: {{'#155724' if status == 'success' else '#721c24'}};">
            STATUS: {status.upper()}
        </div>

        <div class="summary">
            <h3 style="margin-top: 0;">Execution Summary</h3>
            <div class="summary-item">
                <span class="label">Total Checks:</span>
                <span class="value">{execution_summary.get('total_checks', 0)}</span>
            </div>
            <div class="summary-item" style="color: #28a745;">
                <span class="label">✓ Passed:</span>
                <span class="value">{execution_summary.get('passed_checks', 0)}</span>
            </div>
            <div class="summary-item" style="color: #dc3545;">
                <span class="label">✗ Failed:</span>
                <span class="value">{execution_summary.get('failed_checks', 0)}</span>
            </div>
            <div class="summary-item" style="color: #ffc107;">
                <span class="label">⚠ Warnings:</span>
                <span class="value">{execution_summary.get('warned_checks', 0)}</span>
            </div>
            <div class="summary-item" style="color: #6c757d;">
                <span class="label">○ Skipped:</span>
                <span class="value">{execution_summary.get('skipped_checks', 0)}</span>
            </div>
            <div class="summary-item">
                <span class="label">Duration:</span>
                <span class="value">{execution_summary.get('duration_seconds', 0):.2f}s</span>
            </div>
        </div>
    </div>
    <div class="footer">
        <p>This is an automated notification from the Security Audit Toolkit.</p>
        <p>To manage schedules or view detailed results, log in to the audit dashboard.</p>
    </div>
</body>
</html>
        """

        # Send email notifications
        if email_recipients:
            results['email_sent'] = self.send_email(
                to_emails=email_recipients,
                subject=subject,
                body=body,
                html_body=html_body
            )

        # Send webhook notifications
        webhook_payload = {
            'event': 'scheduled_audit_execution',
            'timestamp': datetime.utcnow().isoformat(),
            'schedule': {
                'name': schedule_name,
                'server': server_name,
                'audit': audit_name,
                'status': status
            },
            'summary': execution_summary
        }

        if webhook_urls:
            for webhook_url in webhook_urls:
                if self.send_webhook(webhook_url, webhook_payload):
                    results['webhooks_sent'] += 1

        return results

    def notify_scheduled_report(
        self,
        report_name: str,
        pdf_data: bytes,
        report_summary: Dict[str, Any],
        email_recipients: List[str],
        organization: Optional[str] = None,
        compliance_framework: Optional[str] = None,
        webhook_urls: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Send scheduled PDF report via email with attachment

        Args:
            report_name: Name/title of the report
            pdf_data: PDF file content as bytes
            report_summary: Summary metrics from the report
            email_recipients: List of email addresses
            organization: Organization name for branding
            compliance_framework: Compliance framework if applicable
            webhook_urls: Optional webhook URLs for notification

        Returns:
            dict: Delivery status with email_sent and webhooks_sent
        """
        results = {'email_sent': False, 'webhooks_sent': 0, 'error': None}

        timestamp = datetime.utcnow().strftime('%Y-%m-%d')
        compliance_text = f" ({compliance_framework})" if compliance_framework else ""
        org_text = f" - {organization}" if organization else ""

        subject = f"📊 Security Audit Report: {report_name}{compliance_text}{org_text}"

        # Generate filename
        safe_name = report_name.replace(' ', '_').replace('/', '-')[:50]
        filename = f"Security_Audit_Report_{safe_name}_{timestamp}.pdf"

        # Plain text body
        body = """
Security Audit Report Delivery
{'=' * 50}

Report: {report_name}
{f'Organization: {organization}' if organization else ''}
{f'Compliance Framework: {compliance_framework}' if compliance_framework else ''}
Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}

Report Summary:
--------------
Total Servers: {report_summary.get('total_servers', 0)}
Total Checks: {report_summary.get('total_checks', 0)}
Passed: {report_summary.get('total_pass', 0)}
Failed: {report_summary.get('total_fail', 0)}
Warnings: {report_summary.get('total_warn', 0)}
Compliance Score: {report_summary.get('compliance_percentage', 0)}%

The full PDF report is attached to this email.

---
Security Audit Toolkit
Automated Report Delivery System
        """

        # HTML body
        compliance_pct = report_summary.get('compliance_percentage', 0)
        score_color = '#28a745' if compliance_pct >= 90 else '#ffc107' if compliance_pct >= 70 else '#dc3545'

        html_body = """
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; }}
        .header {{ background: linear-gradient(135deg, #1e3a5f, #2d5a87); color: white; padding: 30px; text-align: center; }}
        .header h1 {{ margin: 0; font-size: 24px; }}
        .header p {{ margin: 10px 0 0 0; opacity: 0.9; }}
        .content {{ padding: 30px; background: #f8f9fa; }}
        .score-card {{ background: white; border-radius: 10px; padding: 20px; text-align: center; margin: 20px 0; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        .score {{ font-size: 48px; font-weight: bold; color: {score_color}; }}
        .score-label {{ color: #666; font-size: 14px; }}
        .metrics {{ display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 20px 0; }}
        .metric {{ background: white; padding: 15px; border-radius: 8px; text-align: center; }}
        .metric-value {{ font-size: 24px; font-weight: bold; }}
        .metric-label {{ color: #666; font-size: 12px; }}
        .pass {{ color: #28a745; }}
        .warn {{ color: #ffc107; }}
        .fail {{ color: #dc3545; }}
        .attachment-notice {{ background: #e8f4f8; border-left: 4px solid #17a2b8; padding: 15px; margin: 20px 0; }}
        .footer {{ text-align: center; padding: 20px; color: #666; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>📊 Security Audit Report</h1>
        <p>{report_name}{' - ' + organization if organization else ''}</p>
        {f'<p style="font-size: 12px; margin-top: 5px;">Compliance: {compliance_framework}</p>' if compliance_framework else ''}
    </div>
    <div class="content">
        <div class="score-card">
            <div class="score">{compliance_pct}%</div>
            <div class="score-label">Overall Compliance Score</div>
        </div>

        <div class="metrics">
            <div class="metric">
                <div class="metric-value">{report_summary.get('total_servers', 0)}</div>
                <div class="metric-label">Servers Audited</div>
            </div>
            <div class="metric">
                <div class="metric-value">{report_summary.get('total_checks', 0)}</div>
                <div class="metric-label">Total Checks</div>
            </div>
            <div class="metric">
                <div class="metric-value pass">{report_summary.get('total_pass', 0)}</div>
                <div class="metric-label">Passed</div>
            </div>
            <div class="metric">
                <div class="metric-value fail">{report_summary.get('total_fail', 0)}</div>
                <div class="metric-label">Failed</div>
            </div>
        </div>

        <div class="attachment-notice">
            <strong>📎 PDF Report Attached</strong><br>
            The complete security audit report is attached to this email as a PDF document.
        </div>
    </div>
    <div class="footer">
        <p>Generated by Security Audit Toolkit on {datetime.utcnow().strftime('%B %d, %Y at %H:%M UTC')}</p>
        <p>This is an automated report delivery.</p>
    </div>
</body>
</html>
        """

        # Send email with PDF attachment
        try:
            results['email_sent'] = self.send_email_with_attachment(
                to_emails=email_recipients,
                subject=subject,
                body=body,
                attachment_data=pdf_data,
                attachment_filename=filename,
                attachment_mime_type='application/pdf',
                html_body=html_body
            )
        except Exception as e:
            logger.error(f"Failed to send PDF report email: {e}")
            results['error'] = str(e)

        # Send webhook notifications
        webhook_payload = {
            'event': 'scheduled_report_generated',
            'timestamp': datetime.utcnow().isoformat(),
            'report': {
                'name': report_name,
                'organization': organization,
                'compliance_framework': compliance_framework,
                'generated_at': datetime.utcnow().isoformat()
            },
            'summary': report_summary,
            'delivery': {
                'email_recipients': len(email_recipients),
                'email_sent': results['email_sent']
            }
        }

        if webhook_urls:
            for webhook_url in webhook_urls:
                if self.send_webhook(webhook_url, webhook_payload):
                    results['webhooks_sent'] += 1

        return results

    def notify_maintenance_window_start(
        self,
        window_name: str,
        window_type: str,
        server_scope: str,
        start_time: datetime,
        end_time: datetime,
        reason: Optional[str] = None,
        email_recipients: Optional[List[str]] = None,
        webhook_urls: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Send notifications when a maintenance window starts.

        Args:
            window_name: Name of the maintenance window
            window_type: Type (one_time, daily, recurring)
            server_scope: Server(s) affected
            start_time: When the window started
            end_time: When the window will end
            reason: Optional reason for maintenance
            email_recipients: List of admin emails to notify
            webhook_urls: List of webhook URLs for alerts

        Returns:
            dict: Notification delivery results
        """
        results = {'email_sent': False, 'webhooks_sent': 0}

        duration = end_time - start_time
        duration_str = str(duration).split('.')[0]  # Remove microseconds

        subject = f"🔧 Maintenance Window Started: {window_name}"

        body = """
Maintenance Window Started
{'=' * 50}

Window Name: {window_name}
Type: {window_type.replace('_', ' ').title()}
Server Scope: {server_scope}
Start Time: {start_time.strftime('%Y-%m-%d %H:%M:%S UTC')}
End Time: {end_time.strftime('%Y-%m-%d %H:%M:%S UTC')}
Duration: {duration_str}
{f'Reason: {reason}' if reason else ''}

IMPORTANT: Scheduled audits are paused for affected servers during this window.

---
Security Audit Toolkit
Maintenance Window Notification
        """

        html_body = """
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
        .header {{ background: linear-gradient(135deg, #fbbf24, #d97706); padding: 20px; color: white; }}
        .header h2 {{ margin: 0; }}
        .content {{ padding: 20px; }}
        .info-box {{ background: #fef3c7; border: 1px solid #fbbf24; border-radius: 8px; padding: 15px; margin: 15px 0; }}
        .info-row {{ display: flex; padding: 8px 0; border-bottom: 1px solid #fde68a; }}
        .info-row:last-child {{ border-bottom: none; }}
        .info-label {{ font-weight: bold; min-width: 120px; color: #92400e; }}
        .info-value {{ flex: 1; }}
        .warning {{ background: #fef3c7; padding: 15px; border-left: 4px solid #d97706; margin: 15px 0; }}
        .footer {{ margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; color: #777; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="header">
        <h2>🔧 Maintenance Window Started</h2>
    </div>
    <div class="content">
        <div class="info-box">
            <div class="info-row">
                <span class="info-label">Window Name:</span>
                <span class="info-value">{window_name}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Type:</span>
                <span class="info-value">{window_type.replace('_', ' ').title()}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Server Scope:</span>
                <span class="info-value">{server_scope}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Start Time:</span>
                <span class="info-value">{start_time.strftime('%Y-%m-%d %H:%M:%S UTC')}</span>
            </div>
            <div class="info-row">
                <span class="info-label">End Time:</span>
                <span class="info-value">{end_time.strftime('%Y-%m-%d %H:%M:%S UTC')}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Duration:</span>
                <span class="info-value">{duration_str}</span>
            </div>
            {f'<div class="info-row"><span class="info-label">Reason:</span><span class="info-value">{reason}</span></div>' if reason else ''}
        </div>

        <div class="warning">
            <strong>⚠️ Important:</strong> Scheduled audits are paused for affected servers during this maintenance window.
        </div>
    </div>
    <div class="footer">
        <p>Security Audit Toolkit - Maintenance Window Notification</p>
        <p>Sent at {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
    </div>
</body>
</html>
        """

        # Send email
        if email_recipients:
            results['email_sent'] = self.send_email(
                to_emails=email_recipients,
                subject=subject,
                body=body,
                html_body=html_body
            )

        # Send webhooks
        webhook_payload = {
            'event': 'maintenance_window_started',
            'timestamp': datetime.utcnow().isoformat(),
            'window': {
                'name': window_name,
                'type': window_type,
                'server_scope': server_scope,
                'start_time': start_time.isoformat(),
                'end_time': end_time.isoformat(),
                'reason': reason
            }
        }

        if webhook_urls:
            for webhook_url in webhook_urls:
                if self.send_webhook(webhook_url, webhook_payload):
                    results['webhooks_sent'] += 1

        return results

    def notify_maintenance_window_end(
        self,
        window_name: str,
        window_type: str,
        server_scope: str,
        start_time: datetime,
        end_time: datetime,
        skipped_audits: int = 0,
        email_recipients: Optional[List[str]] = None,
        webhook_urls: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Send notifications when a maintenance window ends.

        Args:
            window_name: Name of the maintenance window
            window_type: Type (one_time, daily, recurring)
            server_scope: Server(s) affected
            start_time: When the window started
            end_time: When the window ended
            skipped_audits: Number of audits skipped during window
            email_recipients: List of admin emails to notify
            webhook_urls: List of webhook URLs for alerts

        Returns:
            dict: Notification delivery results
        """
        results = {'email_sent': False, 'webhooks_sent': 0}

        duration = end_time - start_time
        duration_str = str(duration).split('.')[0]

        subject = f"✅ Maintenance Window Ended: {window_name}"

        body = """
Maintenance Window Ended
{'=' * 50}

Window Name: {window_name}
Type: {window_type.replace('_', ' ').title()}
Server Scope: {server_scope}
Started: {start_time.strftime('%Y-%m-%d %H:%M:%S UTC')}
Ended: {end_time.strftime('%Y-%m-%d %H:%M:%S UTC')}
Duration: {duration_str}
Skipped Audits: {skipped_audits}

Scheduled audits have resumed for affected servers.

---
Security Audit Toolkit
Maintenance Window Notification
        """

        html_body = """
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
        .header {{ background: linear-gradient(135deg, #22c55e, #15803d); padding: 20px; color: white; }}
        .header h2 {{ margin: 0; }}
        .content {{ padding: 20px; }}
        .info-box {{ background: #dcfce7; border: 1px solid #22c55e; border-radius: 8px; padding: 15px; margin: 15px 0; }}
        .info-row {{ display: flex; padding: 8px 0; border-bottom: 1px solid #bbf7d0; }}
        .info-row:last-child {{ border-bottom: none; }}
        .info-label {{ font-weight: bold; min-width: 120px; color: #166534; }}
        .info-value {{ flex: 1; }}
        .success {{ background: #dcfce7; padding: 15px; border-left: 4px solid #22c55e; margin: 15px 0; }}
        .stat {{ font-size: 24px; font-weight: bold; color: #15803d; }}
        .footer {{ margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; color: #777; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="header">
        <h2>✅ Maintenance Window Ended</h2>
    </div>
    <div class="content">
        <div class="info-box">
            <div class="info-row">
                <span class="info-label">Window Name:</span>
                <span class="info-value">{window_name}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Type:</span>
                <span class="info-value">{window_type.replace('_', ' ').title()}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Server Scope:</span>
                <span class="info-value">{server_scope}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Started:</span>
                <span class="info-value">{start_time.strftime('%Y-%m-%d %H:%M:%S UTC')}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Ended:</span>
                <span class="info-value">{end_time.strftime('%Y-%m-%d %H:%M:%S UTC')}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Duration:</span>
                <span class="info-value">{duration_str}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Skipped Audits:</span>
                <span class="info-value"><span class="stat">{skipped_audits}</span></span>
            </div>
        </div>

        <div class="success">
            <strong>✅ Status:</strong> Scheduled audits have resumed for affected servers.
        </div>
    </div>
    <div class="footer">
        <p>Security Audit Toolkit - Maintenance Window Notification</p>
        <p>Sent at {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
    </div>
</body>
</html>
        """

        # Send email
        if email_recipients:
            results['email_sent'] = self.send_email(
                to_emails=email_recipients,
                subject=subject,
                body=body,
                html_body=html_body
            )

        # Send webhooks
        webhook_payload = {
            'event': 'maintenance_window_ended',
            'timestamp': datetime.utcnow().isoformat(),
            'window': {
                'name': window_name,
                'type': window_type,
                'server_scope': server_scope,
                'start_time': start_time.isoformat(),
                'end_time': end_time.isoformat()
            },
            'summary': {
                'skipped_audits': skipped_audits
            }
        }

        if webhook_urls:
            for webhook_url in webhook_urls:
                if self.send_webhook(webhook_url, webhook_payload):
                    results['webhooks_sent'] += 1

        return results


# Global notification manager instance
notification_manager = NotificationManager()
