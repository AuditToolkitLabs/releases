"""
Pagination Utilities - Cursor-Based Pagination

Provides cursor-based pagination for API endpoints to efficiently handle large result sets.
Cursor-based pagination is more efficient than offset-based for large datasets.

Features:
- Cursor-based pagination (more efficient than offset)
- Configurable page size with limits
- Next/previous page URLs
- Total count (optional, can be expensive)
- Compatible with SQLAlchemy queries and Python lists

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

from typing import List, Dict, Any, Optional, Tuple
from flask import request, url_for
import base64
import json


class PaginationParams:
    """Parse and validate pagination parameters from request"""

    def __init__(
        self,
        cursor: Optional[str] = None,
        limit: int = 50,
        max_limit: int = 200,
        include_total: bool = False
    ):
        self.cursor = cursor
        self.limit = min(limit, max_limit)  # Enforce max limit
        self.max_limit = max_limit
        self.include_total = include_total

    @classmethod
    def from_request(cls, max_limit: int = 200) -> 'PaginationParams':
        """
        Parse pagination params from Flask request

        Query parameters:
            cursor: Base64-encoded cursor string
            limit: Page size (default 50, max 200)
            include_total: Include total count (default false)

        Returns:
            PaginationParams instance
        """
        cursor = request.args.get('cursor')
        limit = int(request.args.get('limit', 50))
        include_total = request.args.get('include_total', 'false').lower() == 'true'

        return cls(
            cursor=cursor,
            limit=limit,
            max_limit=max_limit,
            include_total=include_total
        )


class Cursor:
    """Cursor encoding/decoding for pagination"""

    @staticmethod
    def encode(data: Dict[str, Any]) -> str:
        """
        Encode cursor data to base64 string

        Args:
            data: Dictionary with cursor data (e.g., {'id': 123, 'created_at': '2026-01-01'})

        Returns:
            Base64-encoded cursor string
        """
        json_str = json.dumps(data, sort_keys=True)
        return base64.urlsafe_b64encode(json_str.encode()).decode()

    @staticmethod
    def decode(cursor_str: str) -> Dict[str, Any]:
        """
        Decode base64 cursor string

        Args:
            cursor_str: Base64-encoded cursor

        Returns:
            Dictionary with cursor data

        Raises:
            ValueError: If cursor is invalid
        """
        try:
            json_str = base64.urlsafe_b64decode(cursor_str.encode()).decode()
            return json.loads(json_str)
        except Exception as e:
            raise ValueError(f"Invalid cursor: {e}")


def paginate_list(
    items: List[Any],
    params: PaginationParams,
    id_field: str = 'id',
    endpoint: str = None
) -> Dict[str, Any]:
    """
    Paginate a Python list using cursor-based pagination

    Args:
        items: List of dictionaries to paginate
        params: Pagination parameters
        id_field: Field name to use as cursor (default 'id')
        endpoint: Flask endpoint for generating next/prev URLs

    Returns:
        Dictionary with paginated results:
        {
            'data': [...],
            'pagination': {
                'limit': 50,
                'has_next': true,
                'has_prev': false,
                'next_cursor': 'encoded_cursor',
                'prev_cursor': null,
                'next_url': '/api/endpoint?cursor=...',
                'prev_url': null,
                'total': 1000  # Optional
            }
        }
    """
    # Handle cursor
    start_idx = 0
    if params.cursor:
        try:
            cursor_data = Cursor.decode(params.cursor)
            cursor_id = cursor_data.get(id_field)

            # Find starting position
            for idx, item in enumerate(items):
                if isinstance(item, dict):
                    item_id = item.get(id_field)
                else:
                    item_id = getattr(item, id_field, None)

                if item_id == cursor_id:
                    start_idx = idx + 1  # Start after cursor
                    break
        except ValueError:
            # Invalid cursor, start from beginning
            start_idx = 0

    # Get page of results
    end_idx = start_idx + params.limit
    page_items = items[start_idx:end_idx]

    # Determine if there are more pages
    has_next = end_idx < len(items)
    has_prev = start_idx > 0

    # Generate cursors
    next_cursor = None
    prev_cursor = None

    if page_items and has_next:
        last_item = page_items[-1]
        if isinstance(last_item, dict):
            last_id = last_item.get(id_field)
        else:
            last_id = getattr(last_item, id_field, None)

        if last_id is not None:
            next_cursor = Cursor.encode({id_field: last_id})

    if has_prev:
        # Previous cursor is the item before start_idx
        if start_idx > 0:
            prev_item = items[max(0, start_idx - params.limit - 1)]
            if isinstance(prev_item, dict):
                prev_id = prev_item.get(id_field)
            else:
                prev_id = getattr(prev_item, id_field, None)

            if prev_id is not None:
                prev_cursor = Cursor.encode({id_field: prev_id})

    # Build pagination response
    pagination = {
        'limit': params.limit,
        'has_next': has_next,
        'has_prev': has_prev,
        'next_cursor': next_cursor,
        'prev_cursor': prev_cursor
    }

    # Generate URLs if endpoint provided
    if endpoint:
        if next_cursor:
            pagination['next_url'] = url_for(
                endpoint,
                cursor=next_cursor,
                limit=params.limit,
                _external=False
            )
        else:
            pagination['next_url'] = None

        if prev_cursor:
            pagination['prev_url'] = url_for(
                endpoint,
                cursor=prev_cursor,
                limit=params.limit,
                _external=False
            )
        else:
            pagination['prev_url'] = None

    # Add total count if requested
    if params.include_total:
        pagination['total'] = len(items)

    return {
        'data': page_items,
        'pagination': pagination
    }


def paginate_query(
    query,
    params: PaginationParams,
    id_field: str = 'id',
    endpoint: str = None
) -> Dict[str, Any]:
    """
    Paginate a SQLAlchemy query using cursor-based pagination

    Args:
        query: SQLAlchemy query object
        params: Pagination parameters
        id_field: Field name to use as cursor (default 'id')
        endpoint: Flask endpoint for generating next/prev URLs

    Returns:
        Dictionary with paginated results (same format as paginate_list)
    """
    from sqlalchemy import desc

    # Apply cursor filter if provided
    if params.cursor:
        try:
            cursor_data = Cursor.decode(params.cursor)
            cursor_id = cursor_data.get(id_field)

            # Filter to items after cursor
            query = query.filter(getattr(query.column_descriptions[0]['entity'], id_field) > cursor_id)
        except ValueError:
            # Invalid cursor, ignore
            pass

    # Get page_size + 1 to check if there's a next page
    items = query.limit(params.limit + 1).all()

    has_next = len(items) > params.limit
    if has_next:
        items = items[:params.limit]  # Remove extra item

    has_prev = params.cursor is not None

    # Generate cursors
    next_cursor = None
    prev_cursor = None

    if items and has_next:
        last_item = items[-1]
        last_id = getattr(last_item, id_field, None)
        if last_id is not None:
            next_cursor = Cursor.encode({id_field: last_id})

    # For previous cursor, we'd need to query backwards
    # For simplicity, we'll skip prev_cursor in query-based pagination
    # (would require reverse ordering and more complex logic)

    # Build pagination response
    pagination = {
        'limit': params.limit,
        'has_next': has_next,
        'has_prev': has_prev,
        'next_cursor': next_cursor,
        'prev_cursor': None  # Not implemented for query pagination
    }

    # Generate URLs if endpoint provided
    if endpoint:
        if next_cursor:
            pagination['next_url'] = url_for(
                endpoint,
                cursor=next_cursor,
                limit=params.limit,
                _external=False
            )
        else:
            pagination['next_url'] = None

        pagination['prev_url'] = None

    # Add total count if requested (expensive query)
    if params.include_total:
        from sqlalchemy import func
        total_query = query.statement.with_only_columns([func.count()]).order_by(None)
        pagination['total'] = query.session.execute(total_query).scalar()

    return {
        'data': items,
        'pagination': pagination
    }


__all__ = [
    'PaginationParams',
    'Cursor',
    'paginate_list',
    'paginate_query',
]
