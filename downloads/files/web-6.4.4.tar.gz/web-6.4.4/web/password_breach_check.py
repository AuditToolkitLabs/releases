#!/usr/bin/env python3
"""
HaveIBeenPwned Password Check Module

Checks passwords against the HaveIBeenPwned (HIBP) database using
the k-Anonymity API to ensure passwords are checked securely without
exposing the actual password.

Security Features:
- Uses k-Anonymity (only first 5 chars of SHA-1 hash sent)
- No full password or hash ever transmitted
- Caches results to reduce API calls
- Configurable breach threshold

Reference: https://haveibeenpwned.com/API/v3#PwnedPasswords

Author: Security Audit Toolkit Team
Date: February 10, 2026
"""

import hashlib
import logging
import requests
from typing import Tuple, Optional
from functools import lru_cache

logger = logging.getLogger(__name__)

# HIBP API endpoint (free, no API key required for password checking)
HIBP_API_URL = "https://api.pwnedpasswords.com/range/"

# Request timeout in seconds
REQUEST_TIMEOUT = 5

# User agent required by HIBP API
USER_AGENT = "SecurityAuditToolkit-PasswordCheck"


def _sha1_hash(password: str) -> str:
    """
    Generate SHA-1 hash of password (uppercase).

    Args:
        password: The password to hash

    Returns:
        Uppercase SHA-1 hex digest

    Note: SHA1 is required by the HaveIBeenPwned API specification.
          This is not used for password storage (we use bcrypt for that).
    """
    # usedforsecurity=False: SHA1 required by HIBP API, not for cryptographic security
    return hashlib.sha1(password.encode('utf-8'), usedforsecurity=False).hexdigest().upper()


@lru_cache(maxsize=1000)
def _fetch_hash_range(hash_prefix: str) -> Optional[str]:
    """
    Fetch hash suffixes from HIBP API (cached).

    Uses k-Anonymity: only sends first 5 characters of hash.

    Args:
        hash_prefix: First 5 characters of SHA-1 hash

    Returns:
        API response text or None on error
    """
    try:
        response = requests.get(
            f"{HIBP_API_URL}{hash_prefix}",
            headers={"User-Agent": USER_AGENT},
            timeout=REQUEST_TIMEOUT
        )

        if response.status_code == 200:
            return response.text
        elif response.status_code == 404:
            # No breaches found for this prefix
            return ""
        else:
            logger.warning(f"HIBP API returned status {response.status_code}")
            return None

    except requests.Timeout:
        logger.warning("HIBP API request timed out")
        return None
    except requests.RequestException as e:
        logger.warning(f"HIBP API request failed: {e}")
        return None


def check_password_breach(password: str) -> Tuple[bool, int]:
    """
    Check if a password has been exposed in data breaches.

    Uses the HaveIBeenPwned k-Anonymity API to securely check
    without transmitting the full password or hash.

    Args:
        password: The password to check

    Returns:
        Tuple of (is_breached, breach_count)
        - is_breached: True if password appears in breach database
        - breach_count: Number of times password appeared in breaches

    Example:
        >>> is_breached, count = check_password_breach("password123")
        >>> if is_breached:
        ...     print(f"Password found in {count} breaches!")
    """
    if not password:
        return False, 0

    # Generate SHA-1 hash
    full_hash = _sha1_hash(password)
    hash_prefix = full_hash[:5]
    hash_suffix = full_hash[5:]

    # Fetch matching hashes from API
    response_text = _fetch_hash_range(hash_prefix)

    if response_text is None:
        # API error - fail open (don't block user)
        logger.info("HIBP check skipped due to API error")
        return False, 0

    if not response_text:
        # No breaches for this prefix
        return False, 0

    # Parse response (format: HASH_SUFFIX:COUNT)
    for line in response_text.splitlines():
        parts = line.split(':')
        if len(parts) == 2:
            suffix, count = parts
            if suffix.upper() == hash_suffix:
                breach_count = int(count)
                logger.info(f"Password found in {breach_count} breaches")
                return True, breach_count

    return False, 0


def validate_password_not_breached(
    password: str,
    max_breach_count: int = 0
) -> Tuple[bool, Optional[str]]:
    """
    Validate that a password has not been exposed in breaches.

    Args:
        password: The password to validate
        max_breach_count: Maximum acceptable breach count (default: 0 = any breach fails)

    Returns:
        Tuple of (is_valid, error_message)
        - is_valid: True if password passes breach check
        - error_message: Description of why password was rejected (if rejected)

    Example:
        >>> is_valid, error = validate_password_not_breached("password123")
        >>> if not is_valid:
        ...     flash(error, "warning")
    """
    is_breached, count = check_password_breach(password)

    if is_breached and count > max_breach_count:
        if count >= 1000000:
            severity = "extremely common"
        elif count >= 100000:
            severity = "very common"
        elif count >= 10000:
            severity = "common"
        elif count >= 1000:
            severity = "known"
        else:
            severity = "found"

        return False, (
            f"This password has been exposed in data breaches ({severity}). "
            "Please choose a different password that has not been compromised."
        )

    return True, None


def get_password_strength_with_breach_check(
    password: str,
    require_length: int = 8,
    require_uppercase: bool = True,
    require_lowercase: bool = True,
    require_digit: bool = True,
    require_special: bool = False,
    check_breach: bool = True
) -> Tuple[bool, str, dict]:
    """
    Comprehensive password strength validation with breach check.

    Args:
        password: The password to validate
        require_length: Minimum required length
        require_uppercase: Require at least one uppercase letter
        require_lowercase: Require at least one lowercase letter
        require_digit: Require at least one digit
        require_special: Require at least one special character
        check_breach: Check against HIBP database

    Returns:
        Tuple of (is_valid, message, details)
        - is_valid: True if password meets all requirements
        - message: User-friendly validation message
        - details: Dict with individual check results

    Example:
        >>> valid, msg, details = get_password_strength_with_breach_check("MyP@ssw0rd!")
        >>> if not valid:
        ...     for check, passed in details.items():
        ...         if not passed:
        ...             print(f"Failed: {check}")
    """
    details = {
        "length": len(password) >= require_length,
        "uppercase": not require_uppercase or any(c.isupper() for c in password),
        "lowercase": not require_lowercase or any(c.islower() for c in password),
        "digit": not require_digit or any(c.isdigit() for c in password),
        "special": not require_special or any(not c.isalnum() for c in password),
        "not_breached": True,
        "breach_count": 0
    }

    # Build error messages for failed checks
    errors = []

    if not details["length"]:
        errors.append(f"at least {require_length} characters")
    if not details["uppercase"]:
        errors.append("an uppercase letter")
    if not details["lowercase"]:
        errors.append("a lowercase letter")
    if not details["digit"]:
        errors.append("a digit")
    if not details["special"]:
        errors.append("a special character")

    # Check breach database
    if check_breach and not errors:  # Only check if other requirements pass
        is_breached, count = check_password_breach(password)
        details["not_breached"] = not is_breached
        details["breach_count"] = count

        if is_breached:
            errors.append("a password not found in data breaches")

    if errors:
        if len(errors) == 1:
            message = f"Password must contain {errors[0]}."
        else:
            message = f"Password must contain: {', '.join(errors[:-1])}, and {errors[-1]}."
        return False, message, details

    return True, "Password meets all requirements.", details


# Convenience function for Flask integration
def check_password_on_registration(password: str) -> Tuple[bool, Optional[str]]:
    """
    Simplified breach check for registration forms.

    Returns user-friendly message suitable for flash() or form errors.
    """
    return validate_password_not_breached(password)


def check_password_on_change(
    new_password: str,
    current_password: Optional[str] = None
) -> Tuple[bool, Optional[str]]:
    """
    Breach check for password change forms.

    Ensures new password is different from current and not breached.
    """
    if current_password and new_password == current_password:
        return False, "New password must be different from current password."

    return validate_password_not_breached(new_password)


__all__ = [
    'check_password_breach',
    'validate_password_not_breached',
    'get_password_strength_with_breach_check',
    'check_password_on_registration',
    'check_password_on_change',
]
