#!/usr/bin/env python3
"""
Cross-Platform Utility Functions

Provides platform-agnostic helpers for file operations, system detection,
and path handling to ensure the audit tool works across Windows, Linux, and macOS.

Author: Security Audit Toolkit Team
Date: February 19, 2026
"""

import os
import shutil
import platform
import subprocess  # nosec B404
from pathlib import Path
from typing import Optional, Union
import logging

logger = logging.getLogger(__name__)


def _resolve_executable(executable: str) -> str:
    """Resolve an executable to an absolute path when available."""
    resolved = shutil.which(executable)
    return resolved or executable


def _run_platform_command(command: list[str], timeout: int = 10):
    """Run trusted platform inspection commands with normalized executable path."""
    safe_command = list(command)
    safe_command[0] = _resolve_executable(safe_command[0])
    return subprocess.run(  # nosec B603
        safe_command,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def is_windows() -> bool:
    """Check if running on Windows."""
    return platform.system() == 'Windows'


def is_linux() -> bool:
    """Check if running on Linux."""
    return platform.system() == 'Linux'


def is_macos() -> bool:
    """Check if running on macOS."""
    return platform.system() == 'Darwin'


def is_unix_like() -> bool:
    """Check if running on Unix-like system (Linux or macOS)."""
    return is_linux() or is_macos()


def get_system_root_drive() -> str:
    """
    Get system root drive path in platform-specific way.

    Returns:
        str: '/' for Unix-like, 'C:\\' for Windows (or Python install drive)
    """
    if is_windows():
        import sys
        python_drive = Path(sys.executable).drive or 'C:'
        return python_drive + '\\'
    return '/'


def safe_chmod(path: Union[str, Path], mode: int) -> bool:
    """
    Safely set file permissions (Unix only).

    On Windows, this is a no-op that returns True.

    Args:
        path: File or directory path
        mode: Octal permission mode (e.g., 0o600)

    Returns:
        bool: True if successful or not applicable, False on error
    """
    if is_windows():
        return True  # Windows doesn't use Unix permissions

    try:
        os.chmod(path, mode)
        return True
    except OSError as e:
        logger.debug(f"chmod failed for {path}: {e}")
        return False


def get_machine_id() -> Optional[str]:
    """
    Get unique machine identifier in platform-specific way.

    Returns:
        str: Machine ID or None if unavailable
    """
    machine_id = None

    # Linux/Unix
    if is_unix_like():
        try:
            for path in ["/etc/machine-id", "/var/lib/dbus/machine-id"]:
                if os.path.exists(path):
                    with open(path) as f:
                        machine_id = f.read().strip()
                        break
        except Exception as e:
            logger.debug(f"Failed to read Unix machine-id: {e}")

    # Windows
    if not machine_id and is_windows():
        try:
            result = _run_platform_command(
                ["wmic", "csproduct", "get", "uuid"],
                timeout=10,
            )
            for line in result.stdout.strip().split('\n'):
                if line.strip() and line.strip() != "UUID":
                    machine_id = line.strip()
                    break
        except Exception as e:
            logger.debug(f"Failed to get Windows UUID: {e}")

    # macOS
    if not machine_id and is_macos():
        try:
            result = _run_platform_command(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                timeout=10,
            )
            for line in result.stdout.split('\n'):
                if 'IOPlatformUUID' in line:
                    machine_id = line.split('"')[1]
                    break
        except Exception as e:
            logger.debug(f"Failed to get macOS UUID: {e}")

    return machine_id


def is_container() -> bool:
    """
    Detect if running in a container (Docker, Podman, LXC, etc.).

    Returns:
        bool: True if running in container
    """
    # Environment variables
    if os.environ.get('DOCKER_CONTAINER') or os.environ.get('container'):
        return True

    # Docker/Podman specific files (Linux only)
    if is_linux():
        if os.path.exists('/.dockerenv'):
            return True

        if os.path.exists('/run/.containerenv'):  # Podman
            return True

        # Check cgroup (older method)
        try:
            if os.path.exists('/proc/1/cgroup'):
                with open('/proc/1/cgroup') as f:
                    content = f.read()
                    if any(marker in content for marker in ['docker', 'lxc', 'kubepods', 'containerd']):
                        return True
        except Exception as cgroup_error:
            logger.debug(f"Container cgroup detection failed: {cgroup_error}")

    return False


def is_kubernetes() -> bool:
    """
    Detect if running in Kubernetes.

    Returns:
        bool: True if running in K8s
    """
    return os.environ.get('KUBERNETES_SERVICE_HOST') is not None


def is_cloud_platform() -> Optional[str]:
    """
    Detect if running on cloud platform.

    Returns:
        str: 'aws', 'azure', 'gcp', or None
    """
    if os.environ.get('AWS_EXECUTION_ENV') or os.environ.get('AWS_REGION'):
        return 'aws'

    if os.environ.get('WEBSITE_SITE_NAME'):  # Azure App Service
        return 'azure'

    if os.environ.get('GAE_APPLICATION'):  # Google App Engine
        return 'gcp'

    # Check metadata servers (requires network call - not recommended)
    return None


def get_deployment_type() -> str:
    """
    Detect deployment environment.

    Returns:
        str: 'docker', 'kubernetes', 'aws', 'azure', 'gcp', or 'standalone'
    """
    if is_kubernetes():
        return 'kubernetes'

    if is_container():
        return 'docker'

    cloud = is_cloud_platform()
    if cloud:
        return cloud

    return 'standalone'


def normalize_path_separators(path: str) -> str:
    """
    Normalize path separators for current platform.

    On Windows, converts '/' to '\\'.
    On Unix, leaves '/' as-is.

    Args:
        path: Path string with mixed separators

    Returns:
        str: Path with platform-appropriate separators
    """
    if is_windows():
        return path.replace('/', '\\')
    return path.replace('\\', '/')


def get_temp_dir() -> Path:
    """
    Get platform-specific temporary directory.

    Returns:
        Path: Temporary directory path
    """
    import tempfile
    return Path(tempfile.gettempdir())


def safe_file_lock(file_obj) -> bool:
    """
    Try to acquire exclusive file lock (Unix only via fcntl).

    On Windows or if fcntl unavailable, this is a no-op.

    Args:
        file_obj: Open file object

    Returns:
        bool: True if lock acquired or not applicable
    """
    try:
        import fcntl  # type: ignore[import]
        fcntl.flock(file_obj.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)  # type: ignore[attr-defined]
        return True
    except ImportError:
        # fcntl not available (Windows)
        return True
    except OSError:
        # Lock already held
        return False


def get_os_info() -> dict:
    """
    Get detailed OS information in platform-agnostic way.

    Returns:
        dict: OS details including name, version, architecture
    """
    info = {
        'platform': platform.system(),
        'platform_release': platform.release(),
        'platform_version': platform.version(),
        'architecture': platform.machine(),
        'hostname': platform.node(),
    }

    # Linux-specific
    if is_linux():
        try:
            if os.path.exists('/etc/os-release'):
                with open('/etc/os-release') as f:
                    for line in f:
                        if line.startswith('PRETTY_NAME='):
                            info['os_name'] = line.split('=')[1].strip().strip('"')
                        elif line.startswith('ID='):
                            info['os_id'] = line.split('=')[1].strip().strip('"')
                        elif line.startswith('VERSION_ID='):
                            info['os_version'] = line.split('=')[1].strip().strip('"')
        except Exception as os_release_error:
            logger.debug(f"Failed to parse /etc/os-release: {os_release_error}")

    # Windows-specific
    elif is_windows():
        try:
            result = _run_platform_command(
                ['systeminfo'],
                timeout=30,
            )
            for line in result.stdout.split('\n'):
                if 'OS Name:' in line:
                    info['os_name'] = line.split(':', 1)[1].strip()
                elif 'OS Version:' in line:
                    info['os_version'] = line.split(':', 1)[1].strip()
        except Exception:
            info['os_name'] = f"Windows {platform.release()}"

    # macOS-specific
    elif is_macos():
        info['os_name'] = f"macOS {platform.mac_ver()[0]}"

    return info


def supports_file_permissions() -> bool:
    """
    Check if platform supports Unix-style file permissions.

    Returns:
        bool: True if chmod/chown are supported
    """
    return hasattr(os, 'chmod') and not is_windows()


def get_default_shell() -> str:
    """
    Get default shell for current platform.

    Returns:
        str: Shell executable name ('bash', 'sh', 'powershell', 'cmd')
    """
    if is_windows():
        return 'powershell'  # or 'cmd'
    elif is_macos():
        return 'zsh'  # macOS default since Catalina
    return 'bash'


# Example usage and test
if __name__ == '__main__':
    print(f"Platform: {platform.system()}")
    print(f"Is Windows: {is_windows()}")
    print(f"Is Linux: {is_linux()}")
    print(f"Is macOS: {is_macos()}")
    print(f"System root: {get_system_root_drive()}")
    print(f"Machine ID: {get_machine_id()}")
    print(f"Is container: {is_container()}")
    print(f"Deployment: {get_deployment_type()}")
    print(f"Temp dir: {get_temp_dir()}")
    print(f"Supports file perms: {supports_file_permissions()}")
    print(f"Default shell: {get_default_shell()}")
    print(f"OS Info: {get_os_info()}")
