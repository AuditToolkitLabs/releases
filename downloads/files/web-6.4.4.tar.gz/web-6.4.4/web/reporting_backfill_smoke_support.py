from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path

from werkzeug.security import generate_password_hash


logger = logging.getLogger(__name__)


def _candidate_database_paths(database_path: str | Path) -> list[Path]:
    primary_path = Path(database_path)
    candidates: list[Path] = []

    for candidate in (primary_path, primary_path.parent.parent / 'audit_tool.db'):
        resolved = candidate.resolve()
        if resolved not in candidates:
            candidates.append(resolved)

    return [candidate for candidate in candidates if candidate.exists()]


def reset_admin_in_database(database_path: str | Path, username: str, password: str) -> bool:
    logger.info('Resetting local admin account for smoke test...')
    database_paths = _candidate_database_paths(database_path)
    if not database_paths:
        logger.error('Unable to reset admin account: database not found at %s', database_path)
        return False

    timestamp = '2026-05-09 00:00:00'
    try:
        for db_path in database_paths:
            with sqlite3.connect(db_path) as connection:
                cursor = connection.cursor()
                cursor.execute('DELETE FROM password_history')
                cursor.execute('DELETE FROM auth_audit_log')
                cursor.execute('DELETE FROM users')
                cursor.execute(
                    '''
                    INSERT INTO users (
                        username,
                        email,
                        display_name,
                        password_hash,
                        auth_provider,
                        role,
                        is_active,
                        is_locked,
                        failed_login_attempts,
                        must_change_password,
                        mfa_enabled,
                        created_at,
                        updated_at,
                        is_builtin_admin
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (
                        username,
                        f'{username}@smoke.local',
                        'Smoke Test Administrator',
                        generate_password_hash(password),
                        'local',
                        'SuperAdmin',
                        1,
                        0,
                        0,
                        0,
                        0,
                        timestamp,
                        timestamp,
                        1,
                    ),
                )
                connection.commit()

        logger.info('Admin account reset complete.')
        return True
    except Exception as exc:
        logger.error('Unable to reset admin account: %s', exc)
        return False


def seed_reporting_backfill_history(database_path: str | Path) -> bool:
    logger.info('Seeding reporting backfill history for smoke test...')
    database_paths = _candidate_database_paths(database_path)
    if not database_paths:
        logger.error('Unable to seed reporting backfill history: database not found at %s', database_path)
        return False

    success_details = {
        'commit_every': 7,
        'audit_limit': 5,
        'assessment_limit': 3,
        'audit_executions': {'processed': 12, 'commits': 2},
        'compliance_assessments': {'processed': 4, 'commits': 1},
    }
    failure_details = {
        'commit_every': 9,
        'audit_limit': 2,
        'assessment_limit': 1,
        'audit_executions': {'processed': 1, 'commits': 0},
        'compliance_assessments': {'processed': 0, 'commits': 0},
    }

    try:
        for db_path in database_paths:
            with sqlite3.connect(db_path) as connection:
                cursor = connection.cursor()
                cursor.execute(
                    '''
                    DELETE FROM audit_log
                    WHERE action = ? AND resource_type = ?
                    ''',
                    ('backfill_reporting_tables', 'reporting_tables'),
                )
                cursor.executemany(
                    '''
                    INSERT INTO audit_log (
                        timestamp,
                        user_id,
                        action,
                        resource_id,
                        resource_type,
                        ip_address,
                        user_agent,
                        success,
                        error_message,
                        details
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''',
                    [
                        (
                            None,
                            None,
                            'backfill_reporting_tables',
                            'historical_reporting',
                            'reporting_tables',
                            '127.0.0.1',
                            'reporting-backfill-smoke-success',
                            1,
                            None,
                            json.dumps(success_details),
                        ),
                        (
                            None,
                            41,
                            'backfill_reporting_tables',
                            'historical_reporting',
                            'reporting_tables',
                            '127.0.0.1',
                            'reporting-backfill-smoke-failure',
                            0,
                            'seeded reporting backfill failure',
                            json.dumps(failure_details),
                        ),
                    ],
                )
                connection.commit()

        logger.info('Reporting backfill history seed complete.')
        return True
    except Exception as exc:
        logger.error('Unable to seed reporting backfill history: %s', exc)
        return False


def clear_reporting_backfill_history(database_path: str | Path) -> bool:
    logger.info('Clearing reporting backfill history for smoke test...')
    database_paths = _candidate_database_paths(database_path)
    if not database_paths:
        logger.error('Unable to clear reporting backfill history: database not found at %s', database_path)
        return False

    try:
        for db_path in database_paths:
            with sqlite3.connect(db_path) as connection:
                cursor = connection.cursor()
                cursor.execute(
                    '''
                    DELETE FROM audit_log
                    WHERE action = ? AND resource_type = ?
                    ''',
                    ('backfill_reporting_tables', 'reporting_tables'),
                )
                connection.commit()

        logger.info('Reporting backfill history cleared.')
        return True
    except Exception as exc:
        logger.error('Unable to clear reporting backfill history: %s', exc)
        return False
