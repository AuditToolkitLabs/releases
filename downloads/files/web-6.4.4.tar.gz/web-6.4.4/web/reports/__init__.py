# Security Audit Toolkit - Enhanced Reporting Module
# PDF generation, HTML reports, compliance templates, and executive summaries

# Lazy imports - only import when explicitly accessed
# This avoids loading weasyprint and its system dependencies at import time

__all__ = [
    'PDFReportGenerator',
    'HTMLExecutiveReportGenerator',
    'ComplianceTemplates',
    'ComplianceFramework',
    'ExecutiveSummaryGenerator',
    'is_pdf_available',
    'is_html_available',
    'generate_executive_html_report'
]

# Lazy accessors
_pdf_generator = None
_compliance_templates = None
_executive_summary = None


def _load_pdf_generator():
    global _pdf_generator
    if _pdf_generator is None:
        try:
            from .pdf_generator import PDFReportGenerator
            _pdf_generator = PDFReportGenerator
        except (ImportError, OSError):
            # OSError occurs when weasyprint can't load native GTK/GObject libraries
            _pdf_generator = False
    return _pdf_generator if _pdf_generator else None


def _load_compliance():
    global _compliance_templates
    if _compliance_templates is None:
        try:
            from .compliance_templates import ComplianceTemplates, ComplianceFramework
            _compliance_templates = (ComplianceTemplates, ComplianceFramework)
        except ImportError:
            _compliance_templates = (None, None)
    return _compliance_templates


def _load_executive():
    global _executive_summary
    if _executive_summary is None:
        try:
            from .executive_summary import ExecutiveSummaryGenerator
            _executive_summary = ExecutiveSummaryGenerator
        except ImportError:
            _executive_summary = False
    return _executive_summary if _executive_summary else None


_html_generator = None


def _load_html_generator():
    global _html_generator
    if _html_generator is None:
        try:
            from .html_generator import (
                HTMLExecutiveReportGenerator,
                is_html_available as _is_html,
                generate_executive_html_report as _gen_html
            )
            _html_generator = (HTMLExecutiveReportGenerator, _is_html, _gen_html)
        except ImportError:
            _html_generator = (None, lambda: False, None)
    return _html_generator


def is_pdf_available():
    """Check if PDF generation is available"""
    return _load_pdf_generator() is not None


def is_html_available():
    """Check if HTML report generation is available"""
    return _load_html_generator()[1]()


def generate_executive_html_report(*args, **kwargs):
    """Generate HTML executive report"""
    gen_func = _load_html_generator()[2]
    if gen_func:
        return gen_func(*args, **kwargs)
    raise ImportError("HTML report generation not available")


# Provide attribute access for backwards compatibility
def __getattr__(name):
    if name == 'PDFReportGenerator':
        return _load_pdf_generator()
    if name == 'HTMLExecutiveReportGenerator':
        return _load_html_generator()[0]
    if name == 'ComplianceTemplates':
        return _load_compliance()[0]
    if name == 'ComplianceFramework':
        return _load_compliance()[1]
    if name == 'ExecutiveSummaryGenerator':
        return _load_executive()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
