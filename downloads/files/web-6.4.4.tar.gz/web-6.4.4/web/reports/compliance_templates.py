"""
Compliance Report Templates for Security Audit Toolkit

Provides mapping between audit checks and major compliance frameworks:
- PCI-DSS 4.0 (Payment Card Industry Data Security Standard)
- SOC 2 Type II (Service Organization Control)
- ISO 27001:2022 (Information Security Management)
- NIST CSF (Cybersecurity Framework)
- CIS Controls v8 (Center for Internet Security)
"""

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class ComplianceFramework(Enum):
    """Supported compliance frameworks."""
    PCI_DSS = "PCI-DSS 4.0"
    SOC2 = "SOC 2 Type II"
    ISO27001 = "ISO 27001:2022"
    NIST_CSF = "NIST CSF"
    CIS_CONTROLS = "CIS Controls v8"


@dataclass
class ControlMapping:
    """Represents a compliance control and its audit mapping."""
    id: str
    name: str
    description: str
    audit_checks: list[str]  # Audit check names that satisfy this control
    status: str = "unknown"  # satisfied, partial, failed, unknown
    evidence: str = ""


class ComplianceTemplates:
    """
    Compliance framework templates and audit-to-control mapping.

    Maps security audit check results to compliance framework controls.
    """

    # PCI-DSS 4.0 Control Mappings
    PCI_DSS_CONTROLS = {
        "Requirement 1: Network Security": [
            ControlMapping(
                id="1.3.1",
                name="Restrict inbound traffic",
                description="Inbound traffic is restricted to only necessary ports and services",
                audit_checks=["firewall_active", "open_ports", "iptables_rules"]
            ),
            ControlMapping(
                id="1.3.2",
                name="Restrict outbound traffic",
                description="Outbound traffic is restricted based on business needs",
                audit_checks=["firewall_egress", "outbound_rules"]
            ),
            ControlMapping(
                id="1.4.1",
                name="Network segmentation",
                description="Network is segmented to isolate cardholder data",
                audit_checks=["network_segmentation", "vlan_config"]
            ),
        ],
        "Requirement 2: Secure Configuration": [
            ControlMapping(
                id="2.2.1",
                name="Configuration standards",
                description="System configuration standards are developed and maintained",
                audit_checks=["baseline_config", "hardening_applied"]
            ),
            ControlMapping(
                id="2.2.4",
                name="Unnecessary services disabled",
                description="Unnecessary functionality is removed or disabled",
                audit_checks=["unnecessary_services", "default_accounts"]
            ),
            ControlMapping(
                id="2.2.5",
                name="Secure protocols only",
                description="Only secure protocols are enabled (no SSL, early TLS)",
                audit_checks=["ssl_tls_config", "weak_ciphers", "protocol_version"]
            ),
        ],
        "Requirement 5: Anti-Malware": [
            ControlMapping(
                id="5.2.1",
                name="Anti-malware deployed",
                description="Anti-malware solutions are deployed on applicable systems",
                audit_checks=["antivirus_installed", "malware_protection"]
            ),
            ControlMapping(
                id="5.3.1",
                name="Anti-malware active",
                description="Anti-malware mechanisms are actively running",
                audit_checks=["antivirus_running", "definitions_current"]
            ),
        ],
        "Requirement 6: Secure Development": [
            ControlMapping(
                id="6.3.2",
                name="Secure coding standards",
                description="Software development follows secure coding guidelines",
                audit_checks=["code_review", "security_testing"]
            ),
            ControlMapping(
                id="6.4.2",
                name="Change control",
                description="Changes are tested and approved before production",
                audit_checks=["change_management", "approval_process"]
            ),
        ],
        "Requirement 7: Restrict Access": [
            ControlMapping(
                id="7.2.1",
                name="Access control system",
                description="Access control systems are established for all system components",
                audit_checks=["rbac_enabled", "access_controls"]
            ),
            ControlMapping(
                id="7.2.2",
                name="Least privilege",
                description="Access is granted based on least privilege principle",
                audit_checks=["privileged_accounts", "sudo_config", "group_membership"]
            ),
        ],
        "Requirement 8: User Identification": [
            ControlMapping(
                id="8.3.1",
                name="Strong authentication",
                description="All user access requires strong authentication",
                audit_checks=["password_policy", "mfa_enabled", "auth_config"]
            ),
            ControlMapping(
                id="8.3.4",
                name="Account lockout",
                description="Accounts are locked after too many failed login attempts",
                audit_checks=["account_lockout", "login_failures"]
            ),
            ControlMapping(
                id="8.3.6",
                name="Password complexity",
                description="Passwords meet minimum complexity requirements",
                audit_checks=["password_complexity", "min_length"]
            ),
        ],
        "Requirement 10: Logging & Monitoring": [
            ControlMapping(
                id="10.2.1",
                name="Audit logging enabled",
                description="Audit logs record all user access to cardholder data",
                audit_checks=["audit_logging", "log_config"]
            ),
            ControlMapping(
                id="10.3.1",
                name="Log protection",
                description="Audit logs are protected from modification",
                audit_checks=["log_integrity", "log_permissions"]
            ),
            ControlMapping(
                id="10.5.1",
                name="Log retention",
                description="Audit logs are retained for at least one year",
                audit_checks=["log_retention", "backup_logs"]
            ),
        ],
        "Requirement 11: Security Testing": [
            ControlMapping(
                id="11.3.1",
                name="Vulnerability scanning",
                description="Internal and external vulnerability scans performed regularly",
                audit_checks=["vuln_scanning", "patch_status"]
            ),
            ControlMapping(
                id="11.5.1",
                name="Intrusion detection",
                description="Intrusion detection/prevention systems are in place",
                audit_checks=["ids_enabled", "fail2ban", "security_monitoring"]
            ),
        ],
    }

    # SOC 2 Type II Control Mappings
    SOC2_CONTROLS = {
        "CC1: Control Environment": [
            ControlMapping(
                id="CC1.1",
                name="Ethics and integrity",
                description="Organization demonstrates commitment to ethics and integrity",
                audit_checks=["security_policy", "acceptable_use"]
            ),
            ControlMapping(
                id="CC1.4",
                name="Competence commitment",
                description="Organization attracts and retains competent individuals",
                audit_checks=["user_training", "security_awareness"]
            ),
        ],
        "CC2: Communication & Information": [
            ControlMapping(
                id="CC2.1",
                name="Information quality",
                description="Organization obtains relevant, quality information",
                audit_checks=["monitoring_config", "alerting_setup"]
            ),
        ],
        "CC3: Risk Assessment": [
            ControlMapping(
                id="CC3.2",
                name="Risk identification",
                description="Organization identifies risks to objectives",
                audit_checks=["vulnerability_assessment", "risk_scan"]
            ),
            ControlMapping(
                id="CC3.4",
                name="Change risk assessment",
                description="Organization considers fraud in assessing risks",
                audit_checks=["change_detection", "integrity_monitoring"]
            ),
        ],
        "CC5: Control Activities": [
            ControlMapping(
                id="CC5.1",
                name="Control selection",
                description="Organization selects and develops control activities",
                audit_checks=["security_controls", "baseline_config"]
            ),
            ControlMapping(
                id="CC5.2",
                name="Technology controls",
                description="Organization selects and develops technology controls",
                audit_checks=["firewall_active", "encryption_enabled", "access_controls"]
            ),
        ],
        "CC6: Logical & Physical Access": [
            ControlMapping(
                id="CC6.1",
                name="Logical access security",
                description="Logical access is restricted to authorized users",
                audit_checks=["user_management", "auth_config", "rbac_enabled"]
            ),
            ControlMapping(
                id="CC6.2",
                name="User provisioning",
                description="New users are authorized before access is granted",
                audit_checks=["user_creation", "approval_workflow"]
            ),
            ControlMapping(
                id="CC6.3",
                name="User removal",
                description="Access is removed when no longer authorized",
                audit_checks=["user_removal", "inactive_accounts"]
            ),
            ControlMapping(
                id="CC6.6",
                name="Boundary protection",
                description="System boundaries are protected",
                audit_checks=["firewall_active", "network_segmentation"]
            ),
            ControlMapping(
                id="CC6.7",
                name="Transmission security",
                description="Data in transit is protected",
                audit_checks=["ssl_tls_config", "encryption_transit"]
            ),
            ControlMapping(
                id="CC6.8",
                name="Malicious code prevention",
                description="Controls prevent malicious code",
                audit_checks=["antivirus_installed", "malware_protection"]
            ),
        ],
        "CC7: System Operations": [
            ControlMapping(
                id="CC7.1",
                name="Configuration management",
                description="Configuration changes are controlled",
                audit_checks=["change_management", "config_baseline"]
            ),
            ControlMapping(
                id="CC7.2",
                name="Vulnerability management",
                description="Vulnerabilities are identified and addressed",
                audit_checks=["patch_status", "vuln_scanning"]
            ),
            ControlMapping(
                id="CC7.3",
                name="Incident detection",
                description="Security incidents are detected and responded to",
                audit_checks=["ids_enabled", "log_monitoring", "alerting_setup"]
            ),
        ],
        "CC8: Change Management": [
            ControlMapping(
                id="CC8.1",
                name="Change authorization",
                description="Changes are authorized before implementation",
                audit_checks=["change_approval", "deployment_controls"]
            ),
        ],
        "CC9: Risk Mitigation": [
            ControlMapping(
                id="CC9.1",
                name="Risk mitigation",
                description="Organization identifies and mitigates risks",
                audit_checks=["risk_assessment", "control_effectiveness"]
            ),
            ControlMapping(
                id="CC9.2",
                name="Business continuity",
                description="Organization plans for business continuity",
                audit_checks=["backup_config", "recovery_testing"]
            ),
        ],
    }

    # ISO 27001:2022 Control Mappings
    ISO27001_CONTROLS = {
        "A.5 Organizational Controls": [
            ControlMapping(
                id="A.5.1",
                name="Policies for information security",
                description="Information security policies are defined and communicated",
                audit_checks=["security_policy", "policy_review"]
            ),
            ControlMapping(
                id="A.5.15",
                name="Access control",
                description="Rules controlling access are established",
                audit_checks=["access_controls", "rbac_enabled"]
            ),
            ControlMapping(
                id="A.5.17",
                name="Authentication information",
                description="Authentication information is protected",
                audit_checks=["password_policy", "credential_storage"]
            ),
        ],
        "A.6 People Controls": [
            ControlMapping(
                id="A.6.3",
                name="Information security awareness",
                description="Personnel receive appropriate security awareness training",
                audit_checks=["user_training", "security_awareness"]
            ),
        ],
        "A.7 Physical Controls": [
            ControlMapping(
                id="A.7.9",
                name="Security of equipment off-premises",
                description="Off-premises equipment is secured",
                audit_checks=["remote_access", "vpn_config"]
            ),
        ],
        "A.8 Technological Controls": [
            ControlMapping(
                id="A.8.1",
                name="User endpoint devices",
                description="User endpoint devices are protected",
                audit_checks=["endpoint_protection", "device_hardening"]
            ),
            ControlMapping(
                id="A.8.5",
                name="Secure authentication",
                description="Secure authentication mechanisms are implemented",
                audit_checks=["mfa_enabled", "auth_config", "password_policy"]
            ),
            ControlMapping(
                id="A.8.7",
                name="Protection against malware",
                description="Protection against malware is implemented",
                audit_checks=["antivirus_installed", "malware_protection"]
            ),
            ControlMapping(
                id="A.8.8",
                name="Technical vulnerability management",
                description="Technical vulnerabilities are managed",
                audit_checks=["patch_status", "vuln_scanning"]
            ),
            ControlMapping(
                id="A.8.9",
                name="Configuration management",
                description="Configurations are managed and controlled",
                audit_checks=["baseline_config", "hardening_applied"]
            ),
            ControlMapping(
                id="A.8.12",
                name="Data leakage prevention",
                description="Data leakage is prevented",
                audit_checks=["dlp_controls", "data_classification"]
            ),
            ControlMapping(
                id="A.8.15",
                name="Logging",
                description="Security events are logged",
                audit_checks=["audit_logging", "log_config"]
            ),
            ControlMapping(
                id="A.8.16",
                name="Monitoring activities",
                description="Networks and systems are monitored",
                audit_checks=["monitoring_config", "alerting_setup"]
            ),
            ControlMapping(
                id="A.8.20",
                name="Networks security",
                description="Networks are secured and controlled",
                audit_checks=["firewall_active", "network_segmentation"]
            ),
            ControlMapping(
                id="A.8.21",
                name="Security of network services",
                description="Network services are secured",
                audit_checks=["service_hardening", "unnecessary_services"]
            ),
            ControlMapping(
                id="A.8.24",
                name="Use of cryptography",
                description="Cryptography is used appropriately",
                audit_checks=["encryption_enabled", "ssl_tls_config", "key_management"]
            ),
        ],
    }

    # NIST CSF Control Mappings
    NIST_CSF_CONTROLS = {
        "Identify (ID)": [
            ControlMapping(
                id="ID.AM-1",
                name="Asset inventory",
                description="Physical devices and systems are inventoried",
                audit_checks=["asset_inventory", "system_discovery"]
            ),
            ControlMapping(
                id="ID.RA-1",
                name="Vulnerability identification",
                description="Vulnerabilities are identified and documented",
                audit_checks=["vuln_scanning", "vulnerability_assessment"]
            ),
        ],
        "Protect (PR)": [
            ControlMapping(
                id="PR.AC-1",
                name="Identity management",
                description="Identities and credentials are managed",
                audit_checks=["user_management", "auth_config"]
            ),
            ControlMapping(
                id="PR.AC-3",
                name="Remote access management",
                description="Remote access is managed",
                audit_checks=["remote_access", "ssh_config", "vpn_config"]
            ),
            ControlMapping(
                id="PR.AC-4",
                name="Access permissions",
                description="Access permissions are managed",
                audit_checks=["rbac_enabled", "privileged_accounts"]
            ),
            ControlMapping(
                id="PR.DS-1",
                name="Data-at-rest protection",
                description="Data-at-rest is protected",
                audit_checks=["encryption_rest", "disk_encryption"]
            ),
            ControlMapping(
                id="PR.DS-2",
                name="Data-in-transit protection",
                description="Data-in-transit is protected",
                audit_checks=["encryption_transit", "ssl_tls_config"]
            ),
            ControlMapping(
                id="PR.IP-1",
                name="Configuration baseline",
                description="Security configuration baselines are established",
                audit_checks=["baseline_config", "hardening_applied"]
            ),
            ControlMapping(
                id="PR.PT-1",
                name="Audit logging",
                description="Audit records are reviewed and managed",
                audit_checks=["audit_logging", "log_retention"]
            ),
        ],
        "Detect (DE)": [
            ControlMapping(
                id="DE.AE-1",
                name="Network monitoring",
                description="Network traffic is monitored for anomalies",
                audit_checks=["monitoring_config", "ids_enabled"]
            ),
            ControlMapping(
                id="DE.CM-1",
                name="Network monitoring",
                description="Network is monitored for security events",
                audit_checks=["log_monitoring", "security_monitoring"]
            ),
            ControlMapping(
                id="DE.CM-4",
                name="Malicious code detection",
                description="Malicious code is detected",
                audit_checks=["antivirus_installed", "malware_scanning"]
            ),
            ControlMapping(
                id="DE.CM-7",
                name="Unauthorized monitoring",
                description="Unauthorized personnel and connections are monitored",
                audit_checks=["intrusion_detection", "unauthorized_access"]
            ),
        ],
        "Respond (RS)": [
            ControlMapping(
                id="RS.AN-1",
                name="Incident investigation",
                description="Incidents are investigated",
                audit_checks=["incident_logging", "forensic_capability"]
            ),
        ],
        "Recover (RC)": [
            ControlMapping(
                id="RC.RP-1",
                name="Recovery planning",
                description="Recovery plans are executed during incidents",
                audit_checks=["backup_config", "recovery_testing"]
            ),
        ],
    }

    # CIS Controls v8 Mappings
    CIS_CONTROLS = {
        "CIS Control 1: Inventory": [
            ControlMapping(
                id="1.1",
                name="Enterprise asset inventory",
                description="Establish and maintain an enterprise asset inventory",
                audit_checks=["asset_inventory", "system_discovery"]
            ),
        ],
        "CIS Control 3: Data Protection": [
            ControlMapping(
                id="3.6",
                name="Encrypt data on end-user devices",
                description="Encrypt data on end-user devices",
                audit_checks=["disk_encryption", "encryption_rest"]
            ),
            ControlMapping(
                id="3.10",
                name="Encrypt sensitive data in transit",
                description="Encrypt sensitive data in transit",
                audit_checks=["encryption_transit", "ssl_tls_config"]
            ),
        ],
        "CIS Control 4: Secure Configuration": [
            ControlMapping(
                id="4.1",
                name="Secure configuration process",
                description="Establish and maintain a secure configuration process",
                audit_checks=["baseline_config", "hardening_applied"]
            ),
            ControlMapping(
                id="4.2",
                name="Network infrastructure configuration",
                description="Establish secure configurations for network infrastructure",
                audit_checks=["firewall_active", "network_config"]
            ),
        ],
        "CIS Control 5: Account Management": [
            ControlMapping(
                id="5.1",
                name="Account inventory",
                description="Establish and maintain an account inventory",
                audit_checks=["user_management", "account_inventory"]
            ),
            ControlMapping(
                id="5.2",
                name="Administrator accounts",
                description="Use unique passwords for all administrative accounts",
                audit_checks=["privileged_accounts", "password_policy"]
            ),
            ControlMapping(
                id="5.4",
                name="Restrict administrator privileges",
                description="Restrict administrator privileges to dedicated accounts",
                audit_checks=["sudo_config", "privilege_separation"]
            ),
        ],
        "CIS Control 6: Access Control": [
            ControlMapping(
                id="6.3",
                name="MFA for externally-exposed applications",
                description="Require MFA for externally-exposed applications",
                audit_checks=["mfa_enabled", "external_auth"]
            ),
            ControlMapping(
                id="6.5",
                name="MFA for administrative access",
                description="Require MFA for administrative access",
                audit_checks=["mfa_admin", "privileged_mfa"]
            ),
        ],
        "CIS Control 7: Vulnerability Management": [
            ControlMapping(
                id="7.1",
                name="Vulnerability management process",
                description="Establish a vulnerability management process",
                audit_checks=["vuln_scanning", "patch_management"]
            ),
            ControlMapping(
                id="7.4",
                name="Patch management",
                description="Perform automated operating system patch management",
                audit_checks=["patch_status", "auto_updates"]
            ),
        ],
        "CIS Control 8: Audit Log Management": [
            ControlMapping(
                id="8.2",
                name="Audit log collection",
                description="Collect audit logs",
                audit_checks=["audit_logging", "log_config"]
            ),
            ControlMapping(
                id="8.5",
                name="Audit log access",
                description="Protect access to audit logs",
                audit_checks=["log_permissions", "log_protection"]
            ),
            ControlMapping(
                id="8.9",
                name="Log retention",
                description="Retain audit logs at least 90 days",
                audit_checks=["log_retention", "backup_logs"]
            ),
        ],
        "CIS Control 10: Malware Defenses": [
            ControlMapping(
                id="10.1",
                name="Anti-malware software",
                description="Deploy and maintain anti-malware software",
                audit_checks=["antivirus_installed", "malware_protection"]
            ),
            ControlMapping(
                id="10.2",
                name="Anti-malware updates",
                description="Configure automatic anti-malware updates",
                audit_checks=["antivirus_updates", "definitions_current"]
            ),
        ],
        "CIS Control 13: Network Monitoring": [
            ControlMapping(
                id="13.1",
                name="Security monitoring",
                description="Centralize security event alerting",
                audit_checks=["monitoring_config", "alerting_setup"]
            ),
            ControlMapping(
                id="13.6",
                name="Network-based IDS",
                description="Deploy network-based IDS",
                audit_checks=["ids_enabled", "intrusion_detection"]
            ),
        ],
    }

    @classmethod
    def get_framework_controls(cls, framework: ComplianceFramework) -> dict:
        """Get all controls for a compliance framework."""
        if framework == ComplianceFramework.PCI_DSS:
            return cls.PCI_DSS_CONTROLS
        elif framework == ComplianceFramework.SOC2:
            return cls.SOC2_CONTROLS
        elif framework == ComplianceFramework.ISO27001:
            return cls.ISO27001_CONTROLS
        elif framework == ComplianceFramework.NIST_CSF:
            return cls.NIST_CSF_CONTROLS
        elif framework == ComplianceFramework.CIS_CONTROLS:
            return cls.CIS_CONTROLS
        else:
            raise ValueError(f"Unknown framework: {framework}")

    @classmethod
    def map_audit_to_controls(
        cls,
        framework: ComplianceFramework,
        audit_results: dict[str, str]
    ) -> dict[str, list[ControlMapping]]:
        """
        Map audit check results to compliance controls.

        Args:
            framework: Target compliance framework
            audit_results: Dict of check_name -> status (pass/warn/fail/skip)

        Returns:
            Control mappings with status set based on audit results
        """
        controls = cls.get_framework_controls(framework)
        mapped_controls = {}

        for category, control_list in controls.items():
            mapped_controls[category] = []

            for control in control_list:
                # Determine control status based on related audit checks
                check_results = []
                for check in control.audit_checks:
                    if check in audit_results:
                        check_results.append(audit_results[check])

                if not check_results:
                    control.status = "unknown"
                    control.evidence = "No matching audit checks found"
                elif all(r == "pass" for r in check_results):
                    control.status = "satisfied"
                    control.evidence = f"All {len(check_results)} related checks passed"
                elif any(r == "fail" for r in check_results):
                    control.status = "failed"
                    failed = sum(1 for r in check_results if r == "fail")
                    control.evidence = f"{failed} of {len(check_results)} related checks failed"
                else:
                    control.status = "partial"
                    passed = sum(1 for r in check_results if r == "pass")
                    control.evidence = f"{passed} of {len(check_results)} related checks passed"

                mapped_controls[category].append(control)

        return mapped_controls

    @classmethod
    def calculate_compliance_score(
        cls,
        mapped_controls: dict[str, list[ControlMapping]]
    ) -> dict[str, Any]:
        """
        Calculate compliance score from mapped controls.

        Returns:
            Dict with total, satisfied, partial, failed, unknown counts and percentage
        """
        total = 0
        satisfied = 0
        partial = 0
        failed = 0
        unknown = 0

        for controls in mapped_controls.values():
            for control in controls:
                total += 1
                if control.status == "satisfied":
                    satisfied += 1
                elif control.status == "partial":
                    partial += 1
                elif control.status == "failed":
                    failed += 1
                else:
                    unknown += 1

        # Calculate score (satisfied = 100%, partial = 50%)
        if total - unknown > 0:
            score = ((satisfied + partial * 0.5) / (total - unknown)) * 100
        else:
            score = 0.0

        return {
            "total_controls": total,
            "satisfied": satisfied,
            "partial": partial,
            "failed": failed,
            "unknown": unknown,
            "compliance_score": round(score, 1)
        }

    @classmethod
    def get_recommendations(
        cls,
        mapped_controls: dict[str, list[ControlMapping]]
    ) -> list[dict]:
        """
        Generate recommendations based on failed/partial controls.

        Returns:
            List of recommendation dictionaries
        """
        recommendations = []

        for category, controls in mapped_controls.items():
            for control in controls:
                if control.status == "failed":
                    recommendations.append({
                        "title": f"Remediate {control.id}: {control.name}",
                        "description": control.description,
                        "priority": "High",
                        "category": category,
                        "effort": "Medium"
                    })
                elif control.status == "partial":
                    recommendations.append({
                        "title": f"Improve {control.id}: {control.name}",
                        "description": f"Partially satisfied: {control.description}. {control.evidence}",
                        "priority": "Medium",
                        "category": category,
                        "effort": "Low"
                    })

        # Sort by priority
        priority_order = {"High": 0, "Medium": 1, "Low": 2}
        recommendations.sort(key=lambda x: priority_order.get(x["priority"], 99))

        return recommendations[:20]  # Limit to top 20

    @classmethod
    def get_available_frameworks(cls) -> list[dict]:
        """Get list of available compliance frameworks."""
        return [
            {
                "id": "pci-dss",
                "name": ComplianceFramework.PCI_DSS.value,
                "description": "Payment Card Industry Data Security Standard",
                "version": "4.0"
            },
            {
                "id": "soc2",
                "name": ComplianceFramework.SOC2.value,
                "description": "Service Organization Control Type II",
                "version": "2017"
            },
            {
                "id": "iso27001",
                "name": ComplianceFramework.ISO27001.value,
                "description": "Information Security Management System",
                "version": "2022"
            },
            {
                "id": "nist-csf",
                "name": ComplianceFramework.NIST_CSF.value,
                "description": "NIST Cybersecurity Framework",
                "version": "1.1"
            },
            {
                "id": "cis",
                "name": ComplianceFramework.CIS_CONTROLS.value,
                "description": "Center for Internet Security Controls",
                "version": "v8"
            }
        ]
