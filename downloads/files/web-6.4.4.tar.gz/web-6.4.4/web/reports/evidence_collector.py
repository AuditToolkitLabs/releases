"""
Compliance Evidence Collector for Security Audit Toolkit

Enterprise feature for creating auditor-ready evidence packages with:
- Automated evidence gathering from audit executions
- File attachment support (screenshots, configs, logs)
- Signed/timestamped evidence packages (SHA-256)
- Compliance framework-organized structure
- ZIP export with manifest for external auditors

Premium Feature - Justifies enterprise pricing by:
1. Reducing auditor prep time from days to minutes
2. Providing tamper-evident packages with checksums
3. Auto-organizing evidence by compliance control
4. Supporting SOC 2, PCI-DSS, ISO 27001, NIST audits

Author: Security Audit Toolkit Team
Date: February 13, 2026
"""

import hashlib
import json
import logging
import os
import tempfile
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


class EvidenceType(Enum):
    """Types of evidence that can be collected."""
    AUDIT_OUTPUT = "audit_output"           # Raw audit execution output
    CONFIGURATION = "configuration"          # Config file snapshots
    SCREENSHOT = "screenshot"                # UI screenshots
    LOG_FILE = "log_file"                   # System/application logs
    POLICY_DOC = "policy_document"          # Policy documentation
    ATTESTATION = "attestation"             # Signed attestation
    API_RESPONSE = "api_response"           # API call evidence
    REGISTRY_EXPORT = "registry_export"     # Windows registry exports
    CUSTOM = "custom"                       # Custom evidence


@dataclass
class EvidenceItem:
    """Individual piece of compliance evidence."""
    id: str
    type: EvidenceType
    title: str
    description: str
    control_ids: list[str]              # Compliance control IDs this satisfies
    framework: str                       # PCI-DSS, SOC2, ISO27001, etc.
    collected_at: datetime
    collected_by: str                    # User who collected

    # Content options (one of these)
    content: Optional[str] = None        # Text content
    file_path: Optional[str] = None      # Path to file
    file_data: Optional[bytes] = None    # Binary file data

    # Metadata
    server_id: Optional[int] = None
    server_name: Optional[str] = None
    audit_execution_id: Optional[int] = None
    checksum: Optional[str] = None       # SHA-256 of content
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        """Calculate checksum after initialization."""
        if not self.checksum:
            self.checksum = self._calculate_checksum()

    def _calculate_checksum(self) -> str:
        """Calculate SHA-256 checksum of evidence content."""
        if self.content:
            data = self.content.encode('utf-8')
        elif self.file_data:
            data = self.file_data
        elif self.file_path and os.path.exists(self.file_path):
            with open(self.file_path, 'rb') as f:
                data = f.read()
        else:
            data = b''
        return hashlib.sha256(data).hexdigest()

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            'id': self.id,
            'type': self.type.value,
            'title': self.title,
            'description': self.description,
            'control_ids': self.control_ids,
            'framework': self.framework,
            'collected_at': self.collected_at.isoformat(),
            'collected_by': self.collected_by,
            'has_content': bool(self.content),
            'has_file': bool(self.file_path or self.file_data),
            'server_id': self.server_id,
            'server_name': self.server_name,
            'audit_execution_id': self.audit_execution_id,
            'checksum': self.checksum,
            'metadata': self.metadata
        }


@dataclass
class EvidencePackage:
    """Complete evidence package for compliance audit."""
    id: str
    name: str
    framework: str
    description: str
    organization: str
    created_at: datetime
    created_by: str

    # Assessment period
    period_start: datetime
    period_end: datetime

    # Evidence items
    items: list[EvidenceItem] = field(default_factory=list)

    # Package metadata
    version: str = "1.0"
    package_checksum: Optional[str] = None
    signed_at: Optional[datetime] = None
    signed_by: Optional[str] = None

    def add_item(self, item: EvidenceItem):
        """Add evidence item to package."""
        self.items.append(item)

    def get_items_by_control(self, control_id: str) -> list[EvidenceItem]:
        """Get all evidence items for a specific control."""
        return [item for item in self.items if control_id in item.control_ids]

    def get_items_by_type(self, evidence_type: EvidenceType) -> list[EvidenceItem]:
        """Get all evidence items of a specific type."""
        return [item for item in self.items if item.type == evidence_type]

    def calculate_package_checksum(self) -> str:
        """Calculate checksum of entire package."""
        checksums = sorted([item.checksum for item in self.items if item.checksum])
        combined = '|'.join(checksums)
        self.package_checksum = hashlib.sha256(combined.encode()).hexdigest()
        return self.package_checksum

    def to_manifest(self) -> dict:
        """Generate package manifest for auditors."""
        return {
            'package_info': {
                'id': self.id,
                'name': self.name,
                'version': self.version,
                'framework': self.framework,
                'description': self.description,
                'organization': self.organization
            },
            'assessment_period': {
                'start': self.period_start.isoformat(),
                'end': self.period_end.isoformat()
            },
            'creation': {
                'created_at': self.created_at.isoformat(),
                'created_by': self.created_by,
                'signed_at': self.signed_at.isoformat() if self.signed_at else None,
                'signed_by': self.signed_by
            },
            'integrity': {
                'package_checksum': self.package_checksum,
                'algorithm': 'SHA-256',
                'item_count': len(self.items)
            },
            'evidence_summary': {
                'total_items': len(self.items),
                'by_type': {
                    t.value: len(self.get_items_by_type(t))
                    for t in EvidenceType
                    if self.get_items_by_type(t)
                },
                'controls_covered': list(set(
                    ctrl for item in self.items for ctrl in item.control_ids
                ))
            },
            'items': [item.to_dict() for item in self.items]
        }


class ComplianceEvidenceCollector:
    """
    Collects and packages compliance evidence from audit data.

    Features:
    - Auto-collects evidence from audit executions
    - Maps evidence to compliance framework controls
    - Creates signed, timestamped evidence packages
    - Exports to auditor-ready ZIP format
    """

    # Control mapping for common audit checks
    CONTROL_MAPPINGS = {
        # PCI-DSS mappings
        'firewall': ['PCI-1.3.1', 'PCI-1.3.2'],
        'antivirus': ['PCI-5.2.1', 'PCI-5.3.1'],
        'encryption': ['PCI-3.4.1', 'PCI-4.1.1'],
        'access_control': ['PCI-7.1.1', 'PCI-7.2.1'],
        'audit_log': ['PCI-10.2.1', 'PCI-10.3.1'],
        'password': ['PCI-8.2.1', 'PCI-8.3.1'],

        # SOC 2 mappings
        'logical_access': ['CC6.1', 'CC6.2', 'CC6.3'],
        'change_management': ['CC8.1'],
        'risk_assessment': ['CC3.1', 'CC3.2'],
        'monitoring': ['CC7.1', 'CC7.2'],

        # ISO 27001 mappings
        'asset_management': ['A.8.1', 'A.8.2'],
        'network_security': ['A.13.1.1', 'A.13.1.2'],
        'system_hardening': ['A.12.6.1', 'A.12.6.2'],
        'incident_response': ['A.16.1.1', 'A.16.1.2']
    }

    def __init__(self, organization: str = "Organization"):
        """Initialize evidence collector."""
        self.organization = organization
        self._db_session = None

    def _get_db_session(self):
        """Get database session lazily."""
        if self._db_session is None:
            try:
                from config import SessionLocal
                if SessionLocal is not None:
                    self._db_session = SessionLocal()
            except ImportError:
                logger.warning("Database not available for evidence collection")
        return self._db_session

    def collect_from_execution(
        self,
        execution_id: int,
        framework: str = "PCI-DSS",
        collected_by: str = "system"
    ) -> list[EvidenceItem]:
        """
        Collect evidence items from an audit execution.

        Args:
            execution_id: Audit execution ID
            framework: Target compliance framework
            collected_by: User performing collection

        Returns:
            List of evidence items extracted from the execution
        """
        db = self._get_db_session()
        if not db:
            return []

        try:
            from models.database import AuditExecution, Server, Audit

            execution = db.query(AuditExecution).filter(
                AuditExecution.id == execution_id
            ).first()

            if not execution:
                logger.error(f"Execution {execution_id} not found")
                return []

            server = db.query(Server).filter(Server.id == execution.server_id).first()
            audit = db.query(Audit).filter(Audit.id == execution.audit_id).first()

            items = []

            # Create evidence item for audit output
            item = EvidenceItem(
                id=f"exec-{execution_id}-output",
                type=EvidenceType.AUDIT_OUTPUT,
                title=f"Audit: {audit.name if audit else 'Unknown'}",
                description=f"Audit execution output from {server.name if server else 'Unknown'} on {execution.executed_at}",
                control_ids=self._map_to_controls(str(audit.name) if audit else '', framework),
                framework=framework,
                collected_at=datetime.utcnow(),
                collected_by=collected_by,
                content=str(execution.output or ''),
                server_id=int(execution.server_id),  # type: ignore[arg-type]
                server_name=str(server.name) if server else None,
                audit_execution_id=execution_id,
                metadata={
                    'audit_name': str(audit.name) if audit else None,
                    'status': execution.status,
                    'exit_code': execution.exit_code,
                    'duration_seconds': execution.duration_seconds
                }
            )
            items.append(item)

            # Parse JSON summary if available
            if execution.summary_json:
                try:
                    summary = json.loads(execution.summary_json) if isinstance(
                        execution.summary_json, str
                    ) else execution.summary_json

                    item = EvidenceItem(
                        id=f"exec-{execution_id}-summary",
                        type=EvidenceType.AUDIT_OUTPUT,
                        title=f"Audit Summary: {audit.name if audit else 'Unknown'}",
                        description="Structured audit result summary with check statuses",
                        control_ids=self._map_to_controls(str(audit.name) if audit else '', framework),
                        framework=framework,
                        collected_at=datetime.utcnow(),
                        collected_by=collected_by,
                        content=json.dumps(summary, indent=2),
                        server_id=int(execution.server_id),  # type: ignore[arg-type]
                        server_name=str(server.name) if server else None,
                        audit_execution_id=execution_id,
                        metadata={'format': 'json'}
                    )
                    items.append(item)
                except json.JSONDecodeError:
                    pass

            return items

        except Exception as e:
            logger.error(f"Error collecting evidence from execution: {e}")
            return []

    def collect_from_server(
        self,
        server_id: int,
        framework: str = "PCI-DSS",
        days: int = 90,
        collected_by: str = "system"
    ) -> list[EvidenceItem]:
        """
        Collect all evidence for a server over a time period.

        Args:
            server_id: Server ID
            framework: Target compliance framework
            days: Days of history to collect
            collected_by: User performing collection

        Returns:
            List of evidence items from all executions
        """
        db = self._get_db_session()
        if not db:
            return []

        try:
            from models.database import AuditExecution
            from datetime import timedelta

            cutoff = datetime.utcnow() - timedelta(days=days)

            executions = db.query(AuditExecution).filter(
                AuditExecution.server_id == server_id,
                AuditExecution.executed_at >= cutoff,
                AuditExecution.status == 'success'
            ).all()

            items = []
            for execution in executions:
                items.extend(self.collect_from_execution(
                    int(execution.id), framework, collected_by  # type: ignore[arg-type]
                ))

            return items

        except Exception as e:
            logger.error(f"Error collecting evidence for server: {e}")
            return []

    def _map_to_controls(self, audit_name: str, framework: str) -> list[str]:
        """Map an audit name to compliance control IDs."""
        controls = []
        audit_lower = audit_name.lower()

        for keyword, control_ids in self.CONTROL_MAPPINGS.items():
            if keyword in audit_lower:
                # Filter by framework prefix
                prefix = {
                    'PCI-DSS': 'PCI-',
                    'SOC2': 'CC',
                    'ISO27001': 'A.'
                }.get(framework, '')

                controls.extend([c for c in control_ids if c.startswith(prefix) or not prefix])

        return controls or ['UNMAPPED']

    def create_package(
        self,
        name: str,
        framework: str,
        items: list[EvidenceItem],
        period_start: datetime,
        period_end: datetime,
        created_by: str,
        description: str = ""
    ) -> EvidencePackage:
        """
        Create an evidence package from collected items.

        Args:
            name: Package name
            framework: Compliance framework
            items: Evidence items to include
            period_start: Assessment period start
            period_end: Assessment period end
            created_by: User creating the package
            description: Package description

        Returns:
            Complete evidence package
        """
        package = EvidencePackage(
            id=f"pkg-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            name=name,
            framework=framework,
            description=description or f"{framework} Compliance Evidence Package",
            organization=self.organization,
            created_at=datetime.utcnow(),
            created_by=created_by,
            period_start=period_start,
            period_end=period_end,
            items=items
        )

        package.calculate_package_checksum()

        return package

    def sign_package(
        self,
        package: EvidencePackage,
        signed_by: str
    ) -> EvidencePackage:
        """
        Sign an evidence package (timestamp and user attestation).

        Args:
            package: Package to sign
            signed_by: User signing the package

        Returns:
            Signed package
        """
        package.signed_at = datetime.utcnow()
        package.signed_by = signed_by
        package.calculate_package_checksum()  # Recalculate after signing

        return package

    def export_to_zip(
        self,
        package: EvidencePackage,
        output_path: Optional[str] = None
    ) -> str:
        """
        Export evidence package to ZIP file.

        Creates an auditor-ready ZIP with:
        - MANIFEST.json - Package metadata and checksums
        - README.txt - Instructions for auditors
        - evidence/ - Evidence files organized by control
        - checksums.txt - SHA-256 checksums for verification

        Args:
            package: Evidence package to export
            output_path: Output file path (auto-generated if None)

        Returns:
            Path to created ZIP file
        """
        if not output_path:
            # Use NamedTemporaryFile for secure temp file creation (fixes B306)
            temp_file = tempfile.NamedTemporaryFile(
                prefix=f"evidence-{package.framework}-",
                suffix='.zip',
                delete=False
            )
            output_path = temp_file.name
            temp_file.close()  # Close so ZipFile can open it

        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            # Add manifest
            manifest = package.to_manifest()
            zf.writestr(
                'MANIFEST.json',
                json.dumps(manifest, indent=2, default=str)
            )

            # Add README
            readme = self._generate_readme(package)
            zf.writestr('README.txt', readme)

            # Add evidence items
            checksums = []
            for i, item in enumerate(package.items):
                # Determine filename
                ext = {
                    EvidenceType.AUDIT_OUTPUT: '.txt',
                    EvidenceType.CONFIGURATION: '.conf',
                    EvidenceType.SCREENSHOT: '.png',
                    EvidenceType.LOG_FILE: '.log',
                    EvidenceType.POLICY_DOC: '.pdf',
                    EvidenceType.API_RESPONSE: '.json',
                    EvidenceType.REGISTRY_EXPORT: '.reg',
                    EvidenceType.CUSTOM: '.txt'
                }.get(item.type, '.txt')

                # Create path: evidence/{control_id}/{item_id}{ext}
                control_folder = item.control_ids[0] if item.control_ids else 'general'
                safe_control = control_folder.replace('.', '_').replace('/', '_')
                filename = f"evidence/{safe_control}/{item.id}{ext}"

                # Write content
                if item.content:
                    zf.writestr(filename, item.content)
                elif item.file_data:
                    zf.writestr(filename, item.file_data)
                elif item.file_path and os.path.exists(item.file_path):
                    zf.write(item.file_path, filename)

                # Track checksum
                checksums.append(f"{item.checksum}  {filename}")

                # Add item metadata
                meta_path = f"evidence/{safe_control}/{item.id}.meta.json"
                zf.writestr(meta_path, json.dumps(item.to_dict(), indent=2, default=str))

            # Add checksums file
            zf.writestr('SHA256SUMS.txt', '\n'.join(checksums))

        logger.info(f"Evidence package exported to: {output_path}")
        return output_path

    def _generate_readme(self, package: EvidencePackage) -> str:
        """Generate README file for auditors."""
        return f"""
================================================================================
COMPLIANCE EVIDENCE PACKAGE
================================================================================

Package: {package.name}
Framework: {package.framework}
Organization: {package.organization}

Assessment Period: {package.period_start.strftime('%Y-%m-%d')} to {package.period_end.strftime('%Y-%m-%d')}
Created: {package.created_at.strftime('%Y-%m-%d %H:%M:%S UTC')}
Created By: {package.created_by}
{'Signed By: ' + package.signed_by if package.signed_by else '(Unsigned)'}
{'Signed At: ' + package.signed_at.strftime('%Y-%m-%d %H:%M:%S UTC') if package.signed_at else ''}

--------------------------------------------------------------------------------
PACKAGE CONTENTS
--------------------------------------------------------------------------------

MANIFEST.json      - Complete package metadata and evidence catalog
README.txt         - This file
SHA256SUMS.txt     - SHA-256 checksums for integrity verification
evidence/          - Evidence files organized by compliance control

--------------------------------------------------------------------------------
EVIDENCE SUMMARY
--------------------------------------------------------------------------------

Total Evidence Items: {len(package.items)}
Controls Covered: {len(set(c for item in package.items for c in item.control_ids))}

Evidence by Type:
{chr(10).join(f'  - {t.value}: {len(package.get_items_by_type(t))}' for t in EvidenceType if package.get_items_by_type(t))}

--------------------------------------------------------------------------------
INTEGRITY VERIFICATION
--------------------------------------------------------------------------------

Package Checksum (SHA-256): {package.package_checksum}

To verify individual files on Linux/macOS:
  sha256sum -c SHA256SUMS.txt

To verify on Windows PowerShell:
  Get-Content SHA256SUMS.txt | ForEach-Object {{
    $parts = $_ -split '  '
    $hash = (Get-FileHash $parts[1] -Algorithm SHA256).Hash
    if ($hash -eq $parts[0]) {{ Write-Host "OK: $($parts[1])" }}
    else {{ Write-Host "FAILED: $($parts[1])" }}
  }}

--------------------------------------------------------------------------------
AUDITOR NOTES
--------------------------------------------------------------------------------

This evidence package was automatically generated by the Security Audit Toolkit.
Each evidence item includes:
- Collection timestamp
- SHA-256 checksum for integrity
- Mapping to compliance controls
- Source metadata (server, audit, user)

For questions or additional evidence requests, contact: {package.created_by}

================================================================================
Generated by Security Audit Toolkit - Enterprise Compliance Edition
================================================================================
""".strip()


# Convenience functions
def collect_evidence_for_assessment(
    server_ids: list[int],
    framework: str,
    days: int = 90,
    organization: str = "Organization",
    collected_by: str = "system"
) -> EvidencePackage:
    """
    High-level function to collect evidence for a compliance assessment.

    Args:
        server_ids: List of server IDs to collect from
        framework: Target compliance framework
        days: Days of history
        organization: Organization name
        collected_by: User performing collection

    Returns:
        Complete evidence package ready for export
    """
    from datetime import timedelta

    collector = ComplianceEvidenceCollector(organization=organization)
    all_items = []

    for server_id in server_ids:
        items = collector.collect_from_server(
            server_id=server_id,
            framework=framework,
            days=days,
            collected_by=collected_by
        )
        all_items.extend(items)

    package = collector.create_package(
        name=f"{framework} Evidence Package - {datetime.utcnow().strftime('%Y-%m')}",
        framework=framework,
        items=all_items,
        period_start=datetime.utcnow() - timedelta(days=days),
        period_end=datetime.utcnow(),
        created_by=collected_by,
        description=f"Automated {framework} compliance evidence collection"
    )

    return collector.sign_package(package, signed_by=collected_by)


def export_evidence_package(
    package: EvidencePackage,
    output_dir: Optional[str] = None
) -> str:
    """
    Export evidence package to ZIP file.

    Args:
        package: Evidence package to export
        output_dir: Output directory (uses temp dir if None)

    Returns:
        Path to created ZIP file
    """
    collector = ComplianceEvidenceCollector()

    if output_dir:
        filename = f"evidence-{package.framework}-{package.id}.zip"
        output_path = os.path.join(output_dir, filename)
    else:
        output_path = None

    return collector.export_to_zip(package, output_path)
