"""
Executive Summary Generator for Security Audit Toolkit

Generates professional executive summaries with:
- Key findings overview
- Risk assessment scoring
- Trend analysis
- Actionable recommendations
"""

import logging
from datetime import datetime
from typing import Any, Optional

logger = logging.getLogger(__name__)


class ExecutiveSummaryGenerator:
    """
    Generates executive-level summaries from audit data.

    Designed for C-level executives and board presentations with
    clear, non-technical language and actionable insights.
    """

    # Risk level thresholds
    RISK_THRESHOLDS = {
        "critical": {"min_fail_pct": 20, "max_compliance": 60},
        "high": {"min_fail_pct": 10, "max_compliance": 75},
        "medium": {"min_fail_pct": 5, "max_compliance": 85},
        "low": {"min_fail_pct": 0, "max_compliance": 100}
    }

    # Industry benchmarks (mock data - should be updated with real benchmarks)
    INDUSTRY_BENCHMARKS = {
        "financial_services": {"compliance": 92, "critical_findings": 2},
        "healthcare": {"compliance": 88, "critical_findings": 3},
        "technology": {"compliance": 85, "critical_findings": 4},
        "retail": {"compliance": 80, "critical_findings": 5},
        "manufacturing": {"compliance": 78, "critical_findings": 6},
        "government": {"compliance": 90, "critical_findings": 2},
        "default": {"compliance": 85, "critical_findings": 4}
    }

    def __init__(
        self,
        organization: Optional[str] = None,
        industry: str = "default"
    ):
        """
        Initialize executive summary generator.

        Args:
            organization: Organization name
            industry: Industry sector for benchmarking
        """
        self.organization = organization or "Organization"
        self.industry = industry
        self.benchmark = self.INDUSTRY_BENCHMARKS.get(
            industry, self.INDUSTRY_BENCHMARKS["default"]
        )

    def generate_summary(
        self,
        report_data: dict[str, Any],
        compliance_framework: Optional[str] = None,
        previous_data: Optional[dict] = None
    ) -> dict[str, Any]:
        """
        Generate comprehensive executive summary.

        Args:
            report_data: Audit report data
            compliance_framework: Target compliance framework name
            previous_data: Previous audit data for trend analysis

        Returns:
            Executive summary with all sections
        """
        summary = report_data.get("summary", {})
        servers = report_data.get("servers", [])

        # Calculate metrics
        total_checks = summary.get("total_checks", 0) or 1
        compliance_pct = summary.get("compliance_percentage", 0)
        fail_count = summary.get("total_fail", 0)
        fail_pct = (fail_count / total_checks) * 100

        # Determine risk level
        risk_level = self._calculate_risk_level(compliance_pct, fail_pct)

        # Calculate trends if previous data provided
        trends = self._calculate_trends(summary, previous_data) if previous_data else None

        # Generate key findings
        key_findings = self._extract_key_findings(servers)

        # Generate recommendations
        recommendations = self._generate_recommendations(
            risk_level, key_findings, compliance_pct
        )

        # Industry comparison
        industry_comparison = self._compare_to_industry(compliance_pct, fail_count)

        # Generate narrative
        narrative = self._generate_narrative(
            risk_level, compliance_pct, fail_count, len(servers), trends
        )

        return {
            "title": "Executive Summary: Security Audit Report",
            "organization": self.organization,
            "generated": datetime.now().isoformat(),
            "report_type": "executive_summary",

            # Overall scoring
            "overall_score": {
                "compliance_percentage": compliance_pct,
                "risk_level": risk_level,
                "risk_color": self._get_risk_color(risk_level),
                "grade": self._calculate_grade(compliance_pct)
            },

            # Key metrics
            "metrics": {
                "total_servers": summary.get("total_servers", 0),
                "total_checks": total_checks,
                "passed": summary.get("total_pass", 0),
                "warnings": summary.get("total_warn", 0),
                "failed": fail_count,
                "skipped": summary.get("total_skip", 0)
            },

            # Findings
            "key_findings": key_findings,
            "critical_servers": self._identify_critical_servers(servers),

            # Recommendations
            "recommendations": recommendations,
            "immediate_actions": self._get_immediate_actions(key_findings),

            # Comparative analysis
            "industry_comparison": industry_comparison,
            "trends": trends,

            # Narrative sections
            "narrative": narrative,

            # Compliance context
            "compliance_framework": compliance_framework,
            "compliance_status": self._get_compliance_status(compliance_pct)
        }

    def _calculate_risk_level(self, compliance_pct: float, fail_pct: float) -> str:
        """Determine overall risk level."""
        if compliance_pct < 60 or fail_pct >= 20:
            return "critical"
        elif compliance_pct < 75 or fail_pct >= 10:
            return "high"
        elif compliance_pct < 85 or fail_pct >= 5:
            return "medium"
        else:
            return "low"

    def _get_risk_color(self, risk_level: str) -> str:
        """Get color code for risk level."""
        colors = {
            "critical": "#dc2626",
            "high": "#ea580c",
            "medium": "#ca8a04",
            "low": "#16a34a"
        }
        return colors.get(risk_level, "#6b7280")

    def _calculate_grade(self, compliance_pct: float) -> str:
        """Calculate letter grade from compliance percentage."""
        if compliance_pct >= 95:
            return "A+"
        elif compliance_pct >= 90:
            return "A"
        elif compliance_pct >= 85:
            return "B+"
        elif compliance_pct >= 80:
            return "B"
        elif compliance_pct >= 75:
            return "C+"
        elif compliance_pct >= 70:
            return "C"
        elif compliance_pct >= 60:
            return "D"
        else:
            return "F"

    def _extract_key_findings(self, servers: list[dict]) -> list[dict]:
        """Extract key findings from server data."""
        findings = []

        for server in servers:
            if server.get("status") != "success":
                findings.append({
                    "type": "error",
                    "severity": "high",
                    "title": f"Server Unreachable: {server['name']}",
                    "description": f"Unable to complete audit on {server['host']}",
                    "impact": "Incomplete visibility into security posture"
                })
                continue

            metrics = server.get("metrics", {})
            fail_count = metrics.get("fail", 0)
            total = metrics.get("total", 1)
            fail_pct = (fail_count / total) * 100 if total > 0 else 0

            if fail_pct >= 20:
                findings.append({
                    "type": "failure",
                    "severity": "critical",
                    "title": f"Critical: {server['name']} has {fail_count} failed checks",
                    "description": f"{fail_pct:.0f}% of security checks failed",
                    "impact": "High risk of security breach"
                })
            elif fail_pct >= 10:
                findings.append({
                    "type": "failure",
                    "severity": "high",
                    "title": f"High Risk: {server['name']} needs attention",
                    "description": f"{fail_count} security checks failed ({fail_pct:.0f}%)",
                    "impact": "Elevated security risk"
                })

        # Sort by severity
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        findings.sort(key=lambda x: severity_order.get(x.get("severity", "low"), 99))

        return findings[:10]  # Top 10 findings

    def _identify_critical_servers(self, servers: list[dict]) -> list[dict]:
        """Identify servers requiring immediate attention."""
        critical = []

        for server in servers:
            if server.get("status") != "success":
                critical.append({
                    "name": server["name"],
                    "host": server["host"],
                    "reason": "Unreachable",
                    "priority": 1
                })
                continue

            pass_pct = server.get("pass_percentage", 0)
            if pass_pct < 70:
                critical.append({
                    "name": server["name"],
                    "host": server["host"],
                    "reason": f"Only {pass_pct}% compliance",
                    "priority": 2 if pass_pct < 50 else 3
                })

        critical.sort(key=lambda x: x["priority"])
        return critical[:5]

    def _generate_recommendations(
        self,
        risk_level: str,
        key_findings: list[dict],
        compliance_pct: float
    ) -> list[dict]:
        """Generate priority recommendations."""
        recommendations = []

        if risk_level == "critical":
            recommendations.append({
                "priority": "Immediate",
                "title": "Emergency Security Review",
                "description": "Conduct immediate review of all critical security failures",
                "timeline": "Within 24 hours",
                "effort": "High"
            })

        if risk_level in ["critical", "high"]:
            recommendations.append({
                "priority": "Urgent",
                "title": "Address Failed Security Checks",
                "description": "Remediate all failed security checks across infrastructure",
                "timeline": "Within 1 week",
                "effort": "High"
            })

        if compliance_pct < 90:
            recommendations.append({
                "priority": "High",
                "title": "Improve Security Baseline",
                "description": "Review and update security configuration baselines",
                "timeline": "Within 2 weeks",
                "effort": "Medium"
            })

        recommendations.append({
            "priority": "Medium",
            "title": "Enable Continuous Monitoring",
            "description": "Implement continuous security monitoring and alerting",
            "timeline": "Within 30 days",
            "effort": "Medium"
        })

        recommendations.append({
            "priority": "Standard",
            "title": "Schedule Regular Audits",
            "description": "Establish regular security audit schedule (weekly/monthly)",
            "timeline": "Ongoing",
            "effort": "Low"
        })

        return recommendations

    def _get_immediate_actions(self, key_findings: list[dict]) -> list[str]:
        """Get list of immediate actions based on findings."""
        actions = []

        critical_findings = [f for f in key_findings if f.get("severity") == "critical"]
        if critical_findings:
            actions.append("Investigate and remediate all critical security failures")

        unreachable = [f for f in key_findings if f.get("type") == "error"]
        if unreachable:
            actions.append(f"Restore connectivity to {len(unreachable)} unreachable server(s)")

        if not actions:
            actions.append("Continue maintaining current security practices")
            actions.append("Review warning items for potential improvements")

        return actions

    def _compare_to_industry(self, compliance_pct: float, fail_count: int) -> dict:
        """Compare results to industry benchmarks."""
        benchmark_compliance = self.benchmark["compliance"]
        benchmark_critical = self.benchmark["critical_findings"]

        compliance_diff = compliance_pct - benchmark_compliance
        findings_diff = fail_count - benchmark_critical

        if compliance_diff >= 5:
            position = "above"
            assessment = "Performing above industry average"
        elif compliance_diff >= -5:
            position = "average"
            assessment = "Performing at industry average"
        else:
            position = "below"
            assessment = "Performing below industry average"

        return {
            "industry": self.industry.replace("_", " ").title(),
            "benchmark_compliance": benchmark_compliance,
            "benchmark_critical_findings": benchmark_critical,
            "your_compliance": compliance_pct,
            "your_critical_findings": fail_count,
            "compliance_difference": round(compliance_diff, 1),
            "position": position,
            "assessment": assessment
        }

    def _calculate_trends(
        self,
        current: dict,
        previous: dict
    ) -> dict:
        """Calculate trends from previous audit."""
        current_compliance = current.get("compliance_percentage", 0)
        previous_compliance = previous.get("compliance_percentage", 0)

        current_fail = current.get("total_fail", 0)
        previous_fail = previous.get("total_fail", 0)

        compliance_change = current_compliance - previous_compliance
        fail_change = current_fail - previous_fail

        if compliance_change > 5:
            trend = "improving"
            trend_description = "Security posture is improving"
        elif compliance_change < -5:
            trend = "declining"
            trend_description = "Security posture is declining"
        else:
            trend = "stable"
            trend_description = "Security posture is stable"

        return {
            "trend": trend,
            "trend_description": trend_description,
            "compliance_change": round(compliance_change, 1),
            "failure_change": fail_change,
            "previous_compliance": previous_compliance,
            "current_compliance": current_compliance
        }

    def _get_compliance_status(self, compliance_pct: float) -> str:
        """Get human-readable compliance status."""
        if compliance_pct >= 95:
            return "Fully Compliant"
        elif compliance_pct >= 85:
            return "Substantially Compliant"
        elif compliance_pct >= 70:
            return "Partially Compliant"
        else:
            return "Non-Compliant"

    def _generate_narrative(
        self,
        risk_level: str,
        compliance_pct: float,
        fail_count: int,
        server_count: int,
        trends: Optional[dict]
    ) -> dict:
        """Generate narrative text sections."""
        # Opening paragraph
        if risk_level == "critical":
            opening = (
                "This security audit has identified critical vulnerabilities in "
                f"{self.organization}'s infrastructure. Immediate action is required "
                f"to address {fail_count} failed security checks across {server_count} servers."
            )
        elif risk_level == "high":
            opening = (
                f"The security audit of {self.organization}'s infrastructure has revealed "
                f"significant areas requiring attention. With a {compliance_pct}% compliance score, "
                "focused remediation efforts are recommended."
            )
        elif risk_level == "medium":
            opening = (
                f"{self.organization}'s infrastructure demonstrates a moderate security posture "
                f"with a {compliance_pct}% compliance score. While no critical issues were found, "
                "addressing identified warnings will strengthen overall security."
            )
        else:
            opening = (
                f"{self.organization}'s infrastructure shows a strong security posture with "
                f"a {compliance_pct}% compliance score. The organization is maintaining "
                f"security best practices across {server_count} servers."
            )

        # Trend analysis
        if trends:
            if trends["trend"] == "improving":
                trend_text = (
                    f"Compliance has improved by {trends['compliance_change']}% since the last audit, "
                    "indicating successful security initiatives."
                )
            elif trends["trend"] == "declining":
                trend_text = (
                    f"Compliance has decreased by {abs(trends['compliance_change'])}% since the last audit. "
                    "This trend requires immediate investigation."
                )
            else:
                trend_text = "Security posture has remained stable since the last audit."
        else:
            trend_text = "Trend data not available. Recommend establishing regular audit schedule."

        # Closing recommendation
        if risk_level in ["critical", "high"]:
            closing = (
                "Executive leadership should prioritize security remediation efforts. "
                "A detailed remediation plan with timelines should be developed within 48 hours."
            )
        else:
            closing = (
                "Continue regular security monitoring and address identified items "
                "according to the provided recommendations."
            )

        return {
            "opening": opening,
            "trend_analysis": trend_text,
            "closing": closing
        }

    def generate_one_page_summary(self, report_data: dict[str, Any]) -> str:
        """
        Generate a one-page text summary for quick review.

        Returns:
            Formatted text summary
        """
        summary = self.generate_summary(report_data)

        lines = [
            "=" * 70,
            "EXECUTIVE SUMMARY: SECURITY AUDIT REPORT",
            f"Organization: {self.organization}",
            f"Generated: {datetime.now().strftime('%B %d, %Y')}",
            "=" * 70,
            "",
            "OVERALL ASSESSMENT",
            "-" * 40,
            f"  Compliance Score: {summary['overall_score']['compliance_percentage']}%",
            f"  Risk Level: {summary['overall_score']['risk_level'].upper()}",
            f"  Grade: {summary['overall_score']['grade']}",
            "",
            "KEY METRICS",
            "-" * 40,
            f"  Servers Audited: {summary['metrics']['total_servers']}",
            f"  Total Checks: {summary['metrics']['total_checks']}",
            f"  Passed: {summary['metrics']['passed']} | "
            f"Warnings: {summary['metrics']['warnings']} | "
            f"Failed: {summary['metrics']['failed']}",
            "",
            "NARRATIVE",
            "-" * 40,
            summary['narrative']['opening'],
            "",
            summary['narrative']['trend_analysis'],
            "",
        ]

        if summary['key_findings']:
            lines.append("KEY FINDINGS")
            lines.append("-" * 40)
            for finding in summary['key_findings'][:5]:
                lines.append(f"  [{finding['severity'].upper()}] {finding['title']}")
            lines.append("")

        if summary['recommendations']:
            lines.append("RECOMMENDATIONS")
            lines.append("-" * 40)
            for rec in summary['recommendations'][:3]:
                lines.append(f"  [{rec['priority']}] {rec['title']}")
            lines.append("")

        lines.append("IMMEDIATE ACTIONS REQUIRED")
        lines.append("-" * 40)
        for action in summary['immediate_actions']:
            lines.append(f"  • {action}")

        lines.append("")
        lines.append("=" * 70)
        lines.append("CONFIDENTIAL - Internal Use Only")
        lines.append("=" * 70)

        return "\n".join(lines)
