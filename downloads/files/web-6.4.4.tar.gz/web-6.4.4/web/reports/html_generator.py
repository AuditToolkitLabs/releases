"""
HTML Executive Report Generator for Security Audit Toolkit

Generates professional, standalone HTML executive reports with:
- Modern, responsive design (print and screen optimized)
- Interactive charts (Chart.js)
- Risk heatmaps and compliance visualizations
- Executive summary with key findings
- Compliance framework mapping
- Server-by-server breakdown
- Actionable recommendations
- One-click PDF export support
"""

import json
import logging
from datetime import datetime
from typing import Any, Optional

from jinja2 import Template

logger = logging.getLogger(__name__)


class HTMLExecutiveReportGenerator:
    """
    Professional HTML executive report generator.

    Creates standalone HTML reports with embedded CSS and JavaScript
    that can be viewed in any browser, shared via email, or exported to PDF.
    """

    # Color scheme for consistency
    COLORS = {
        "pass": "#10b981",      # Emerald green  # nosec B105
        "warn": "#f59e0b",      # Amber
        "fail": "#ef4444",      # Red
        "skip": "#6b7280",       # Gray
        "info": "#3b82f6",       # Blue
        "primary": "#1e40af",    # Indigo
        "background": "#f8fafc",  # Slate 50
        "card": "#ffffff",       # White
        "border": "#e2e8f0",     # Slate 200
        "text": "#1e293b",       # Slate 800
        "text_muted": "#64748b"  # Slate 500
    }

    # Risk level configurations
    RISK_LEVELS = {
        "critical": {"color": "#dc2626", "bg": "#fef2f2", "threshold": 60},
        "high": {"color": "#ea580c", "bg": "#fff7ed", "threshold": 75},
        "medium": {"color": "#ca8a04", "bg": "#fefce8", "threshold": 85},
        "low": {"color": "#16a34a", "bg": "#f0fdf4", "threshold": 100}
    }

    def __init__(
        self,
        organization: Optional[str] = None,
        logo_url: Optional[str] = None,
        contact_email: Optional[str] = None,
        classification: str = "Confidential",
        include_charts: bool = True
    ):
        """
        Initialize HTML executive report generator.

        Args:
            organization: Organization name for branding
            logo_url: URL or data URI for logo image
            contact_email: Contact email for report footer
            classification: Document classification (Confidential, Internal, etc.)
            include_charts: Whether to include Chart.js visualizations
        """
        self.organization = organization or "Security Audit"
        self.logo_url = logo_url
        self.contact_email = contact_email
        self.classification = classification
        self.include_charts = include_charts

    def generate_report(
        self,
        report_data: dict[str, Any],
        compliance_framework: Optional[str] = None,
        executive_summary: Optional[dict] = None,
        compliance_mapping: Optional[dict] = None,
        trend_data: Optional[dict] = None,
        theme: str = "professional"
    ) -> str:
        """
        Generate comprehensive HTML executive report.

        Args:
            report_data: Audit report data with servers and summary
            compliance_framework: Target compliance framework (PCI-DSS, SOC2, etc.)
            executive_summary: Pre-generated executive summary data
            compliance_mapping: Pre-generated compliance control mapping
            trend_data: Historical trend data for improvement charts
            theme: Report theme (professional, dark, minimal)

        Returns:
            Complete HTML document as string
        """
        # Extract summary metrics
        summary = report_data.get("summary", {})
        servers = report_data.get("servers", [])

        # Calculate risk metrics
        total_checks = summary.get("total_checks", 0) or 1
        compliance_pct = summary.get("compliance_percentage", 0)
        fail_count = summary.get("total_fail", 0)
        warn_count = summary.get("total_warn", 0)
        pass_count = summary.get("total_pass", 0)

        risk_level = self._determine_risk_level(compliance_pct)
        risk_config = self.RISK_LEVELS[risk_level]

        # Calculate grade
        grade = self._calculate_grade(compliance_pct)

        # Prepare chart data
        chart_data = self._prepare_chart_data(summary, servers)

        # Identify critical servers
        critical_servers = [
            s for s in servers
            if s.get("status") == "success" and s.get("pass_percentage", 100) < 70
        ]

        # Generate key findings
        key_findings = self._extract_key_findings(servers, summary)

        # Generate recommendations
        recommendations = self._generate_recommendations(
            risk_level, compliance_pct, fail_count, warn_count, servers
        )

        # Build the report
        context = {
            "title": report_data.get("title", "Security Audit Report"),
            "organization": self.organization,
            "generated_date": datetime.now().strftime("%B %d, %Y at %I:%M %p"),
            "generated_iso": datetime.now().isoformat(),
            "classification": self.classification,
            "logo_url": self.logo_url,
            "contact_email": self.contact_email,

            # Summary metrics
            "total_servers": summary.get("total_servers", len(servers)),
            "total_checks": total_checks,
            "pass_count": pass_count,
            "warn_count": warn_count,
            "fail_count": fail_count,
            "skip_count": summary.get("total_skip", 0),
            "compliance_percentage": compliance_pct,

            # Risk assessment
            "risk_level": risk_level,
            "risk_color": risk_config["color"],
            "risk_bg": risk_config["bg"],
            "grade": grade,

            # Servers
            "servers": servers,
            "critical_servers": critical_servers,

            # Findings and recommendations
            "key_findings": key_findings,
            "recommendations": recommendations,

            # Charts
            "include_charts": self.include_charts,
            "chart_data": json.dumps(chart_data),

            # Compliance
            "compliance_framework": compliance_framework,
            "executive_summary": executive_summary,
            "compliance_mapping": compliance_mapping,

            # Trend data
            "trend_data": trend_data,
            "has_trend_data": trend_data is not None and trend_data.get("comparison") is not None,

            # Colors
            "colors": self.COLORS,

            # Theme
            "theme": theme
        }

        template = Template(self.HTML_TEMPLATE)
        return template.render(**context)

    def _determine_risk_level(self, compliance_pct: float) -> str:
        """Determine risk level based on compliance percentage."""
        if compliance_pct < 60:
            return "critical"
        elif compliance_pct < 75:
            return "high"
        elif compliance_pct < 85:
            return "medium"
        return "low"

    def _calculate_grade(self, compliance_pct: float) -> str:
        """Calculate letter grade from compliance percentage."""
        if compliance_pct >= 95:
            return "A+"
        elif compliance_pct >= 90:
            return "A"
        elif compliance_pct >= 85:
            return "B+"
        elif compliance_pct >= 80:
            return "B"
        elif compliance_pct >= 75:
            return "C+"
        elif compliance_pct >= 70:
            return "C"
        elif compliance_pct >= 60:
            return "D"
        return "F"

    def _prepare_chart_data(
        self, summary: dict, servers: list
    ) -> dict[str, Any]:
        """Prepare data structures for Chart.js visualizations."""
        return {
            "summary": {
                "labels": ["Pass", "Warn", "Fail", "Skip"],
                "data": [
                    summary.get("total_pass", 0),
                    summary.get("total_warn", 0),
                    summary.get("total_fail", 0),
                    summary.get("total_skip", 0)
                ],
                "colors": [
                    self.COLORS["pass"],
                    self.COLORS["warn"],
                    self.COLORS["fail"],
                    self.COLORS["skip"]
                ]
            },
            "servers": {
                "labels": [s.get("name", "Unknown") for s in servers if s.get("status") == "success"],
                "compliance": [s.get("pass_percentage", 0) for s in servers if s.get("status") == "success"]
            }
        }

    def _extract_key_findings(
        self, servers: list, summary: dict
    ) -> list[dict[str, Any]]:
        """Extract key findings from audit results."""
        findings = []

        # Overall compliance finding
        compliance_pct = summary.get("compliance_percentage", 0)
        if compliance_pct < 70:
            findings.append({
                "severity": "critical",
                "title": "Low Overall Compliance",
                "description": f"Overall compliance is at {compliance_pct}%, which is below the minimum acceptable threshold of 70%.",
                "impact": "High risk of security incidents and potential compliance violations."
            })
        elif compliance_pct < 85:
            findings.append({
                "severity": "warning",
                "title": "Moderate Compliance Gap",
                "description": f"Overall compliance is at {compliance_pct}%, indicating room for improvement.",
                "impact": "Some security controls may not be fully effective."
            })

        # Failed checks finding
        fail_count = summary.get("total_fail", 0)
        if fail_count > 0:
            findings.append({
                "severity": "critical" if fail_count > 10 else "warning",
                "title": f"{fail_count} Security Check{'s' if fail_count != 1 else ''} Failed",
                "description": f"There are {fail_count} failed security checks that require immediate attention.",
                "impact": "Failed checks represent active security vulnerabilities."
            })

        # Per-server findings
        for server in servers:
            if server.get("status") == "success":
                server_compliance = server.get("pass_percentage", 100)
                if server_compliance < 60:
                    findings.append({
                        "severity": "critical",
                        "title": f"Critical: {server.get('name')} at {server_compliance}%",
                        "description": f"Server {server.get('name')} ({server.get('host')}) has critically low compliance.",
                        "impact": "This server poses significant security risk to the infrastructure."
                    })

        return findings[:10]  # Limit to top 10 findings

    def _generate_recommendations(
        self,
        risk_level: str,
        compliance_pct: float,
        fail_count: int,
        warn_count: int,
        servers: list
    ) -> list[dict[str, Any]]:
        """Generate actionable recommendations based on audit results."""
        recommendations = []

        # Critical risk recommendations
        if risk_level == "critical":
            recommendations.append({
                "priority": "immediate",
                "title": "Emergency Security Review",
                "description": "Conduct an emergency security review to address critical vulnerabilities.",
                "effort": "1-2 days",
                "impact": "High"
            })

        # Failed checks recommendations
        if fail_count > 0:
            recommendations.append({
                "priority": "high",
                "title": "Remediate Failed Security Checks",
                "description": f"Address all {fail_count} failed security checks with built-in one-click remediation.",
                "effort": f"{max(1, fail_count // 5)} hours",
                "impact": "High"
            })

        # Warning recommendations
        if warn_count > 5:
            recommendations.append({
                "priority": "medium",
                "title": "Review Security Warnings",
                "description": f"Review and address {warn_count} security warnings to improve security posture.",
                "effort": f"{max(1, warn_count // 10)} hours",
                "impact": "Medium"
            })

        # Per-server recommendations
        low_compliance_servers = [
            s for s in servers
            if s.get("status") == "success" and s.get("pass_percentage", 100) < 75
        ]

        if low_compliance_servers:
            recommendations.append({
                "priority": "high",
                "title": "Prioritize Low-Compliance Servers",
                "description": f"Focus remediation efforts on {len(low_compliance_servers)} servers with compliance below 75%.",
                "effort": "2-4 hours",
                "impact": "High"
            })

        # General recommendations
        if compliance_pct >= 85:
            recommendations.append({
                "priority": "low",
                "title": "Maintain Security Posture",
                "description": "Schedule regular audits to maintain the current security posture.",
                "effort": "Ongoing",
                "impact": "Medium"
            })

        recommendations.append({
            "priority": "medium",
            "title": "Enable Automated Remediation",
            "description": "Use the toolkit's one-click remediation with automatic rollback for safe fixes.",
            "effort": "Minutes per fix",
            "impact": "High"
        })

        return recommendations

    # ==========================================================================
    # HTML TEMPLATE
    # ==========================================================================
    HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Security Audit Toolkit">
    <meta name="classification" content="{{ classification }}">
    <title>{{ title }} - {{ organization }}</title>

    <!-- Chart.js CDN -->
    {% if include_charts %}
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    {% endif %}

    <style>
        /* ===== CSS Reset & Base Styles ===== */
        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        :root {
            --color-pass: {{ colors.pass }};
            --color-warn: {{ colors.warn }};
            --color-fail: {{ colors.fail }};
            --color-skip: {{ colors.skip }};
            --color-info: {{ colors.info }};
            --color-primary: {{ colors.primary }};
            --color-bg: {{ colors.background }};
            --color-card: {{ colors.card }};
            --color-border: {{ colors.border }};
            --color-text: {{ colors.text }};
            --color-muted: {{ colors.text_muted }};
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            font-size: 14px;
            line-height: 1.6;
            color: var(--color-text);
            background: var(--color-bg);
        }

        /* ===== Layout ===== */
        .report-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .card {
            background: var(--color-card);
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06);
            padding: 24px;
            margin-bottom: 24px;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--color-border);
        }

        .card-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--color-text);
        }

        /* ===== Header ===== */
        .report-header {
            text-align: center;
            padding: 40px 20px;
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            color: white;
            border-radius: 12px;
            margin-bottom: 24px;
        }

        .report-header h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .report-header .subtitle {
            font-size: 16px;
            opacity: 0.9;
        }

        .report-header .meta {
            margin-top: 20px;
            font-size: 13px;
            opacity: 0.8;
        }

        .classification-badge {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: 12px;
        }

        /* ===== Executive Summary ===== */
        .executive-summary {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 24px;
        }

        .score-card {
            text-align: center;
            padding: 32px;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border-radius: 12px;
            border: 1px solid #bae6fd;
        }

        .score-value {
            font-size: 72px;
            font-weight: 800;
            color: var(--color-primary);
            line-height: 1;
        }

        .score-label {
            font-size: 14px;
            color: var(--color-muted);
            margin-top: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .grade-badge {
            display: inline-block;
            font-size: 24px;
            font-weight: 700;
            padding: 8px 20px;
            border-radius: 8px;
            margin-top: 16px;
        }

        .risk-indicator {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px 20px;
            border-radius: 8px;
            margin-top: 16px;
            background: {{ risk_bg }};
            border-left: 4px solid {{ risk_color }};
        }

        .risk-indicator .label {
            font-size: 12px;
            color: var(--color-muted);
            text-transform: uppercase;
        }

        .risk-indicator .value {
            font-size: 16px;
            font-weight: 600;
            color: {{ risk_color }};
            text-transform: uppercase;
        }

        /* ===== Metrics Grid ===== */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 16px;
        }

        .metric-card {
            text-align: center;
            padding: 20px 16px;
            border-radius: 10px;
            background: var(--color-bg);
            border: 1px solid var(--color-border);
        }

        .metric-card.pass { border-left: 4px solid var(--color-pass); }
        .metric-card.warn { border-left: 4px solid var(--color-warn); }
        .metric-card.fail { border-left: 4px solid var(--color-fail); }
        .metric-card.skip { border-left: 4px solid var(--color-skip); }
        .metric-card.total { border-left: 4px solid var(--color-primary); }

        .metric-value {
            font-size: 32px;
            font-weight: 700;
            line-height: 1;
        }

        .metric-value.pass { color: var(--color-pass); }
        .metric-value.warn { color: var(--color-warn); }
        .metric-value.fail { color: var(--color-fail); }
        .metric-value.skip { color: var(--color-muted); }

        .metric-label {
            font-size: 12px;
            color: var(--color-muted);
            margin-top: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* ===== Charts ===== */
        .charts-row {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 24px;
        }

        .chart-container {
            position: relative;
            height: 280px;
        }

        /* ===== Tables ===== */
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            text-align: left;
            padding: 12px 16px;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--color-muted);
            background: var(--color-bg);
            border-bottom: 2px solid var(--color-border);
        }

        .data-table td {
            padding: 14px 16px;
            border-bottom: 1px solid var(--color-border);
        }

        .data-table tr:hover {
            background: var(--color-bg);
        }

        /* ===== Status Badges ===== */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-badge.success { background: #d1fae5; color: #065f46; }
        .status-badge.warning { background: #fef3c7; color: #92400e; }
        .status-badge.error { background: #fee2e2; color: #991b1b; }
        .status-badge.info { background: #dbeafe; color: #1e40af; }

        /* ===== Findings ===== */
        .finding-item {
            display: flex;
            gap: 16px;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 12px;
            background: var(--color-bg);
            border-left: 4px solid var(--color-border);
        }

        .finding-item.critical { border-left-color: var(--color-fail); background: #fef2f2; }
        .finding-item.warning { border-left-color: var(--color-warn); background: #fffbeb; }
        .finding-item.info { border-left-color: var(--color-info); background: #eff6ff; }

        .finding-icon {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            font-weight: 700;
            font-size: 14px;
        }

        .finding-item.critical .finding-icon { background: var(--color-fail); color: white; }
        .finding-item.warning .finding-icon { background: var(--color-warn); color: white; }
        .finding-item.info .finding-icon { background: var(--color-info); color: white; }

        .finding-content h4 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .finding-content p {
            font-size: 13px;
            color: var(--color-muted);
            margin-bottom: 4px;
        }

        .finding-impact {
            font-size: 12px;
            font-style: italic;
            color: var(--color-muted);
        }

        /* ===== Recommendations ===== */
        .recommendation-item {
            display: grid;
            grid-template-columns: auto 1fr auto auto;
            gap: 16px;
            align-items: start;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 12px;
            background: var(--color-bg);
        }

        .priority-badge {
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .priority-badge.immediate { background: #fef2f2; color: #dc2626; }
        .priority-badge.high { background: #fff7ed; color: #ea580c; }
        .priority-badge.medium { background: #fefce8; color: #ca8a04; }
        .priority-badge.low { background: #f0fdf4; color: #16a34a; }

        .recommendation-content h4 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .recommendation-content p {
            font-size: 13px;
            color: var(--color-muted);
        }

        .recommendation-meta {
            text-align: right;
            font-size: 12px;
            color: var(--color-muted);
        }

        .recommendation-meta strong {
            display: block;
            color: var(--color-text);
        }

        /* ===== Server Cards ===== */
        .server-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }

        .server-card {
            background: var(--color-card);
            border-radius: 10px;
            border: 1px solid var(--color-border);
            overflow: hidden;
        }

        .server-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            background: var(--color-bg);
            border-bottom: 1px solid var(--color-border);
        }

        .server-name {
            font-weight: 600;
            font-size: 15px;
        }

        .server-host {
            font-size: 12px;
            color: var(--color-muted);
        }

        .server-card-body {
            padding: 16px 20px;
        }

        .server-metrics {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            text-align: center;
        }

        .server-metric {
            padding: 8px;
        }

        .server-metric-value {
            font-size: 20px;
            font-weight: 700;
        }

        .server-metric-label {
            font-size: 10px;
            text-transform: uppercase;
            color: var(--color-muted);
        }

        .compliance-bar {
            margin-top: 16px;
            background: var(--color-bg);
            border-radius: 8px;
            height: 8px;
            overflow: hidden;
        }

        .compliance-bar-fill {
            height: 100%;
            border-radius: 8px;
            transition: width 0.5s ease;
        }

        /* ===== Footer ===== */
        .report-footer {
            text-align: center;
            padding: 24px;
            color: var(--color-muted);
            font-size: 12px;
            border-top: 1px solid var(--color-border);
            margin-top: 40px;
        }

        /* ===== Print Styles ===== */
        @media print {
            body {
                background: white;
                font-size: 11pt;
            }

            .report-container {
                max-width: none;
                padding: 0;
            }

            .card {
                box-shadow: none;
                border: 1px solid #ddd;
                page-break-inside: avoid;
            }

            .report-header {
                background: #1e40af !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .no-print {
                display: none !important;
            }

            .charts-row {
                grid-template-columns: 1fr 1fr;
            }

            .server-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @page {
            size: A4;
            margin: 1.5cm;
        }
    </style>
</head>
<body>
    <div class="report-container">
        <!-- Header -->
        <header class="report-header">
            {% if logo_url %}
            <img src="{{ logo_url }}" alt="{{ organization }}" style="height: 50px; margin-bottom: 16px;">
            {% endif %}
            <h1>{{ title }}</h1>
            <p class="subtitle">{{ organization }}</p>
            <p class="meta">Generated {{ generated_date }}</p>
            <span class="classification-badge">{{ classification }}</span>
        </header>

        <!-- Executive Summary -->
        <section class="card">
            <div class="card-header">
                <h2 class="card-title">Executive Summary</h2>
                <span class="status-badge {% if compliance_percentage >= 85 %}success{% elif compliance_percentage >= 70 %}warning{% else %}error{% endif %}">
                    {% if compliance_percentage >= 85 %}Low Risk{% elif compliance_percentage >= 70 %}Medium Risk{% else %}High Risk{% endif %}
                </span>
            </div>

            <div class="executive-summary">
                <div class="score-card">
                    <div class="score-value">{{ compliance_percentage | round(1) }}%</div>
                    <div class="score-label">Overall Compliance</div>
                    <div class="grade-badge" style="background: {{ risk_bg }}; color: {{ risk_color }};">
                        Grade: {{ grade }}
                    </div>
                    <div class="risk-indicator">
                        <div>
                            <div class="label">Risk Level</div>
                            <div class="value">{{ risk_level | upper }}</div>
                        </div>
                    </div>
                </div>

                <div class="metrics-grid">
                    <div class="metric-card total">
                        <div class="metric-value">{{ total_servers }}</div>
                        <div class="metric-label">Servers</div>
                    </div>
                    <div class="metric-card pass">
                        <div class="metric-value pass">{{ pass_count }}</div>
                        <div class="metric-label">Passed</div>
                    </div>
                    <div class="metric-card warn">
                        <div class="metric-value warn">{{ warn_count }}</div>
                        <div class="metric-label">Warnings</div>
                    </div>
                    <div class="metric-card fail">
                        <div class="metric-value fail">{{ fail_count }}</div>
                        <div class="metric-label">Failed</div>
                    </div>
                    <div class="metric-card skip">
                        <div class="metric-value skip">{{ skip_count }}</div>
                        <div class="metric-label">Skipped</div>
                    </div>
                </div>
            </div>
        </section>

        {% if include_charts %}
        <!-- Charts Section -->
        <section class="card">
            <div class="card-header">
                <h2 class="card-title">Visual Analysis</h2>
            </div>
            <div class="charts-row">
                <div>
                    <h3 style="font-size: 14px; margin-bottom: 16px; color: var(--color-muted);">Check Results Distribution</h3>
                    <div class="chart-container">
                        <canvas id="summaryChart"></canvas>
                    </div>
                </div>
                <div>
                    <h3 style="font-size: 14px; margin-bottom: 16px; color: var(--color-muted);">Server Compliance Comparison</h3>
                    <div class="chart-container">
                        <canvas id="serverChart"></canvas>
                    </div>
                </div>
            </div>
        </section>
        {% endif %}

        <!-- Trend Analysis Section -->
        {% if has_trend_data %}
        <section class="card">
            <div class="card-header">
                <h2 class="card-title">📈 Trend Analysis - Improvement Over Time</h2>
                <span class="status-badge {% if trend_data.comparison.improvement.compliance_trend == 'improving' %}success{% elif trend_data.comparison.improvement.compliance_trend == 'declining' %}error{% else %}info{% endif %}">
                    {{ trend_data.comparison.improvement.compliance_trend | upper }}
                </span>
            </div>

            <div class="trend-summary" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
                <div class="metric-card" style="{% if trend_data.comparison.improvement.compliance_delta >= 0 %}border-left-color: var(--color-pass);{% else %}border-left-color: var(--color-fail);{% endif %}">
                    <div class="metric-value" style="{% if trend_data.comparison.improvement.compliance_delta >= 0 %}color: var(--color-pass);{% else %}color: var(--color-fail);{% endif %}">
                        {% if trend_data.comparison.improvement.compliance_delta >= 0 %}+{% endif %}{{ trend_data.comparison.improvement.compliance_delta }}%
                    </div>
                    <div class="metric-label">Compliance Change</div>
                </div>
                <div class="metric-card pass">
                    <div class="metric-value pass">{{ trend_data.comparison.improvement.checks_fixed }}</div>
                    <div class="metric-label">Issues Fixed</div>
                </div>
                <div class="metric-card fail">
                    <div class="metric-value fail">{{ trend_data.comparison.improvement.new_failures }}</div>
                    <div class="metric-label">New Issues</div>
                </div>
                <div class="metric-card" style="border-left-color: var(--color-info);">
                    <div class="metric-value">{{ trend_data.comparison.improvement.days_between_runs }}</div>
                    <div class="metric-label">Days Between Runs</div>
                </div>
            </div>

            <div class="trend-comparison" style="display: grid; grid-template-columns: 1fr auto 1fr; gap: 24px; align-items: center; padding: 20px; background: var(--color-bg); border-radius: 8px;">
                <div style="text-align: center;">
                    <div style="font-size: 12px; color: var(--color-muted); text-transform: uppercase; margin-bottom: 8px;">Previous Run</div>
                    <div style="font-size: 36px; font-weight: 700; color: var(--color-muted);">{{ trend_data.comparison.previous_run.compliance_score }}%</div>
                    <div style="font-size: 12px; color: var(--color-muted);">{{ trend_data.comparison.previous_run.date }}</div>
                </div>
                <div style="font-size: 32px; color: {% if trend_data.comparison.improvement.compliance_delta >= 0 %}var(--color-pass){% else %}var(--color-fail){% endif %};">
                    {% if trend_data.comparison.improvement.compliance_delta >= 0 %}→{% else %}←{% endif %}
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 12px; color: var(--color-muted); text-transform: uppercase; margin-bottom: 8px;">Current Run</div>
                    <div style="font-size: 36px; font-weight: 700; color: var(--color-primary);">{{ trend_data.comparison.current_run.compliance_score }}%</div>
                    <div style="font-size: 12px; color: var(--color-muted);">{{ trend_data.comparison.current_run.date }}</div>
                </div>
            </div>

            <div style="margin-top: 20px; padding: 16px; background: {% if trend_data.comparison.improvement.compliance_delta >= 0 %}#f0fdf4{% else %}#fef2f2{% endif %}; border-radius: 8px; border-left: 4px solid {% if trend_data.comparison.improvement.compliance_delta >= 0 %}var(--color-pass){% else %}var(--color-fail){% endif %};">
                <p style="font-size: 16px; font-weight: 500; color: var(--color-text);">
                    {{ trend_data.comparison.summary_text }}
                </p>
            </div>
        </section>
        {% endif %}

        <!-- Key Findings -->
        {% if key_findings %}
        <section class="card">
            <div class="card-header">
                <h2 class="card-title">Key Findings</h2>
                <span class="status-badge info">{{ key_findings | length }} Finding{{ 's' if key_findings | length != 1 else '' }}</span>
            </div>

            {% for finding in key_findings %}
            <div class="finding-item {{ finding.severity }}">
                <div class="finding-icon">{{ '!' if finding.severity == 'critical' else '⚠' if finding.severity == 'warning' else 'i' }}</div>
                <div class="finding-content">
                    <h4>{{ finding.title }}</h4>
                    <p>{{ finding.description }}</p>
                    <p class="finding-impact"><strong>Impact:</strong> {{ finding.impact }}</p>
                </div>
            </div>
            {% endfor %}
        </section>
        {% endif %}

        <!-- Recommendations -->
        {% if recommendations %}
        <section class="card">
            <div class="card-header">
                <h2 class="card-title">Recommendations</h2>
            </div>

            {% for rec in recommendations %}
            <div class="recommendation-item">
                <span class="priority-badge {{ rec.priority }}">{{ rec.priority }}</span>
                <div class="recommendation-content">
                    <h4>{{ rec.title }}</h4>
                    <p>{{ rec.description }}</p>
                </div>
                <div class="recommendation-meta">
                    <strong>{{ rec.effort }}</strong>
                    Effort
                </div>
                <div class="recommendation-meta">
                    <strong>{{ rec.impact }}</strong>
                    Impact
                </div>
            </div>
            {% endfor %}
        </section>
        {% endif %}

        <!-- Server Details -->
        {% if servers %}
        <section class="card">
            <div class="card-header">
                <h2 class="card-title">Server Details</h2>
                <span class="status-badge info">{{ servers | length }} Server{{ 's' if servers | length != 1 else '' }}</span>
            </div>

            <div class="server-grid">
                {% for server in servers %}
                <div class="server-card">
                    <div class="server-card-header">
                        <div>
                            <div class="server-name">{{ server.name }}</div>
                            <div class="server-host">{{ server.host }}</div>
                        </div>
                        <span class="status-badge {% if server.status == 'success' %}{% if server.pass_percentage >= 85 %}success{% elif server.pass_percentage >= 70 %}warning{% else %}error{% endif %}{% else %}error{% endif %}">
                            {% if server.status == 'success' %}{{ server.pass_percentage | round(1) }}%{% else %}ERROR{% endif %}
                        </span>
                    </div>

                    {% if server.status == 'success' %}
                    <div class="server-card-body">
                        <div class="server-metrics">
                            <div class="server-metric">
                                <div class="server-metric-value" style="color: var(--color-pass);">{{ server.metrics.pass }}</div>
                                <div class="server-metric-label">Pass</div>
                            </div>
                            <div class="server-metric">
                                <div class="server-metric-value" style="color: var(--color-warn);">{{ server.metrics.warn }}</div>
                                <div class="server-metric-label">Warn</div>
                            </div>
                            <div class="server-metric">
                                <div class="server-metric-value" style="color: var(--color-fail);">{{ server.metrics.fail }}</div>
                                <div class="server-metric-label">Fail</div>
                            </div>
                            <div class="server-metric">
                                <div class="server-metric-value" style="color: var(--color-muted);">{{ server.metrics.total }}</div>
                                <div class="server-metric-label">Total</div>
                            </div>
                        </div>
                        <div class="compliance-bar">
                            <div class="compliance-bar-fill" style="width: {{ server.pass_percentage }}%; background: {% if server.pass_percentage >= 85 %}var(--color-pass){% elif server.pass_percentage >= 70 %}var(--color-warn){% else %}var(--color-fail){% endif %};"></div>
                        </div>
                    </div>
                    {% else %}
                    <div class="server-card-body">
                        <p style="color: var(--color-fail);">{{ server.error | default('Connection failed') }}</p>
                    </div>
                    {% endif %}
                </div>
                {% endfor %}
            </div>
        </section>
        {% endif %}

        <!-- Critical Servers Alert -->
        {% if critical_servers %}
        <section class="card" style="border: 2px solid var(--color-fail);">
            <div class="card-header" style="background: #fef2f2;">
                <h2 class="card-title" style="color: var(--color-fail);">⚠ Critical Servers Requiring Immediate Attention</h2>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>Server</th>
                        <th>Host</th>
                        <th>Compliance</th>
                        <th>Failed Checks</th>
                        <th>Priority</th>
                    </tr>
                </thead>
                <tbody>
                    {% for server in critical_servers %}
                    <tr>
                        <td><strong>{{ server.name }}</strong></td>
                        <td>{{ server.host }}</td>
                        <td><span class="status-badge error">{{ server.pass_percentage | round(1) }}%</span></td>
                        <td>{{ server.metrics.fail }}</td>
                        <td><span class="priority-badge immediate">Immediate</span></td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </section>
        {% endif %}

        <!-- Compliance Framework Section -->
        {% if compliance_framework and compliance_mapping %}
        <section class="card">
            <div class="card-header">
                <h2 class="card-title">{{ compliance_framework }} Compliance Mapping</h2>
            </div>
            <p style="color: var(--color-muted); margin-bottom: 20px;">
                Audit results mapped to {{ compliance_framework }} control requirements.
            </p>
            <!-- Compliance mapping would be rendered here -->
        </section>
        {% endif %}

        <!-- Footer -->
        <footer class="report-footer">
            <p><strong>{{ title }}</strong></p>
            <p>Generated by Security Audit Toolkit on {{ generated_date }}</p>
            {% if contact_email %}
            <p>Contact: <a href="mailto:{{ contact_email }}">{{ contact_email }}</a></p>
            {% endif %}
            <p style="margin-top: 12px;"><em>This report is classified as {{ classification }}. Handle accordingly.</em></p>
        </footer>
    </div>

    {% if include_charts %}
    <!-- Chart.js Initialization -->
    <script>
        const chartData = {{ chart_data | safe }};

        // Summary Doughnut Chart
        new Chart(document.getElementById('summaryChart'), {
            type: 'doughnut',
            data: {
                labels: chartData.summary.labels,
                datasets: [{
                    data: chartData.summary.data,
                    backgroundColor: chartData.summary.colors,
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            font: { size: 12 }
                        }
                    }
                },
                cutout: '60%'
            }
        });

        // Server Compliance Bar Chart
        if (chartData.servers.labels.length > 0) {
            new Chart(document.getElementById('serverChart'), {
                type: 'bar',
                data: {
                    labels: chartData.servers.labels,
                    datasets: [{
                        label: 'Compliance %',
                        data: chartData.servers.compliance,
                        backgroundColor: chartData.servers.compliance.map(v =>
                            v >= 85 ? '{{ colors.pass }}' : v >= 70 ? '{{ colors.warn }}' : '{{ colors.fail }}'
                        ),
                        borderRadius: 6,
                        borderSkipped: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            grid: { color: '#f0f0f0' },
                            ticks: { callback: v => v + '%' }
                        },
                        x: {
                            grid: { display: false }
                        }
                    }
                }
            });
        }
    </script>
    {% endif %}
</body>
</html>'''


def is_html_available() -> bool:
    """Check if HTML generation is available (always true)."""
    return True


def generate_executive_html_report(
    report_data: dict[str, Any],
    organization: Optional[str] = None,
    compliance_framework: Optional[str] = None,
    trend_data: Optional[dict] = None,
    **kwargs
) -> str:
    """
    Convenience function to generate HTML executive report.

    Args:
        report_data: Audit report data
        organization: Organization name
        compliance_framework: Target compliance framework
        trend_data: Historical trend data for improvement charts
        **kwargs: Additional options passed to HTMLExecutiveReportGenerator

    Returns:
        Complete HTML document as string
    """
    generator = HTMLExecutiveReportGenerator(organization=organization, **kwargs)
    return generator.generate_report(
        report_data,
        compliance_framework=compliance_framework,
        trend_data=trend_data
    )


def fetch_trend_data_for_server(server_id: int, days: int = 90) -> Optional[dict]:
    """
    Fetch trend comparison data for a server from the analytics API.

    This helper can be used to automatically include trend data in reports.

    Args:
        server_id: Server ID to fetch trends for
        days: Number of days to look back for comparison

    Returns:
        Trend data dict or None if unavailable
    """
    try:
        # Import here to avoid circular dependencies
        from config import SessionLocal
        from models.database import Server
        from models.audit_history import ServerComplianceHistory
        from datetime import datetime, timedelta
        from sqlalchemy import and_, desc

        if SessionLocal is None:
            return None

        db = SessionLocal()

        # Verify server exists
        server = db.query(Server).filter(Server.id == server_id).first()
        if not server:
            db.close()
            return None

        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)

        # Get compliance history
        records = db.query(ServerComplianceHistory).filter(
            and_(
                ServerComplianceHistory.server_id == server_id,
                ServerComplianceHistory.date >= start_date,
                ServerComplianceHistory.date <= end_date
            )
        ).order_by(desc(ServerComplianceHistory.date)).all()

        db.close()

        if len(records) < 2:
            return None

        current = records[0]
        previous = None
        for r in records[1:]:
            if (current.date - r.date).days >= 1:
                previous = r
                break

        if not previous:
            return None

        # Cast SQLAlchemy columns to primitive types for type safety
        current_score = float(current.overall_compliance_score)  # type: ignore[arg-type]
        previous_score = float(previous.overall_compliance_score)  # type: ignore[arg-type]
        compliance_delta = current_score - previous_score

        checks_fixed = max(0, int(previous.failed_checks) - int(current.failed_checks))  # type: ignore[arg-type]
        new_failures = max(0, int(current.failed_checks) - int(previous.failed_checks))  # type: ignore[arg-type]
        days_between = (current.date - previous.date).days

        trend = "improving" if compliance_delta > 5 else ("declining" if compliance_delta < -5 else "stable")

        if compliance_delta > 0:
            summary = f"📈 Compliance improved from {previous_score:.1f}% to {current_score:.1f}% (+{compliance_delta:.1f}%)"
        elif compliance_delta < 0:
            summary = f"📉 Compliance decreased from {previous_score:.1f}% to {current_score:.1f}% ({compliance_delta:.1f}%)"
        else:
            summary = f"➡️ Compliance stable at {current_score:.1f}%"

        return {
            "server": server.to_dict(),
            "comparison": {
                "current_run": {
                    "date": current.date.strftime('%Y-%m-%d'),
                    "compliance_score": round(current_score, 1),
                    "passed_checks": int(current.passed_checks),  # type: ignore[arg-type]
                    "failed_checks": int(current.failed_checks)  # type: ignore[arg-type]
                },
                "previous_run": {
                    "date": previous.date.strftime('%Y-%m-%d'),
                    "compliance_score": round(previous_score, 1),
                    "passed_checks": int(previous.passed_checks),  # type: ignore[arg-type]
                    "failed_checks": int(previous.failed_checks)  # type: ignore[arg-type]
                },
                "improvement": {
                    "compliance_delta": round(compliance_delta, 1),
                    "compliance_trend": trend,
                    "checks_fixed": checks_fixed,
                    "new_failures": new_failures,
                    "days_between_runs": days_between
                },
                "summary_text": summary
            }
        }

    except Exception as e:
        logger.warning(f"Could not fetch trend data for server {server_id}: {e}")
        return None
