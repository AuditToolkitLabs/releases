"""
PDF Report Generator for Security Audit Toolkit

Generates professional PDF reports from audit data using WeasyPrint.
Supports custom branding, executive summaries, and compliance templates.
"""

import io
import logging
from datetime import datetime
from typing import Any, Optional

from jinja2 import Template

logger = logging.getLogger(__name__)

# Check for WeasyPrint availability
try:
    from weasyprint import HTML, CSS
    WEASYPRINT_AVAILABLE = True
except ImportError:
    WEASYPRINT_AVAILABLE = False
    logger.warning("WeasyPrint not installed. PDF generation disabled.")


class PDFReportGenerator:
    """
    Professional PDF report generator for security audits.

    Features:
    - Executive summaries with charts
    - Compliance mapping (PCI-DSS, SOC 2, ISO 27001)
    - Custom branding support
    - Multi-server aggregation
    """

    # Default styling for PDF reports
    DEFAULT_CSS = """
        @page {
            size: A4;
            margin: 2cm;
            @top-right {
                content: "Page " counter(page) " of " counter(pages);
                font-size: 10pt;
                color: #666;
            }
            @bottom-center {
                content: "Security Audit Report - Confidential";
                font-size: 9pt;
                color: #999;
            }
        }

        body {
            font-family: 'Helvetica', 'Arial', sans-serif;
            font-size: 11pt;
            line-height: 1.6;
            color: #333;
        }

        .cover-page {
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            page-break-after: always;
        }

        .cover-title {
            font-size: 32pt;
            font-weight: bold;
            color: #1e40af;
            margin-bottom: 20px;
        }

        .cover-subtitle {
            font-size: 16pt;
            color: #6b7280;
            margin-bottom: 40px;
        }

        .cover-meta {
            font-size: 12pt;
            color: #9ca3af;
        }

        h1 {
            font-size: 22pt;
            color: #1e40af;
            border-bottom: 3px solid #1e40af;
            padding-bottom: 8px;
            margin-top: 30px;
            page-break-after: avoid;
        }

        h2 {
            font-size: 16pt;
            color: #1e40af;
            margin-top: 25px;
            page-break-after: avoid;
        }

        h3 {
            font-size: 13pt;
            color: #374151;
            margin-top: 20px;
        }

        .executive-summary {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border: 1px solid #0284c7;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            page-break-inside: avoid;
        }

        .summary-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin: 20px 0;
        }

        .summary-card {
            flex: 1;
            min-width: 150px;
            background: #ffffff;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .summary-card.pass { border-left: 4px solid #10b981; }
        .summary-card.warn { border-left: 4px solid #f59e0b; }
        .summary-card.fail { border-left: 4px solid #ef4444; }
        .summary-card.info { border-left: 4px solid #3b82f6; }

        .card-label {
            font-size: 10pt;
            color: #6b7280;
            text-transform: uppercase;
            margin-bottom: 5px;
        }

        .card-value {
            font-size: 24pt;
            font-weight: bold;
            color: #1f2937;
        }

        .compliance-score {
            font-size: 48pt;
            font-weight: bold;
            text-align: center;
            margin: 20px 0;
        }

        .score-high { color: #10b981; }
        .score-medium { color: #f59e0b; }
        .score-low { color: #ef4444; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            page-break-inside: auto;
        }

        thead {
            display: table-header-group;
        }

        tr {
            page-break-inside: avoid;
            page-break-after: auto;
        }

        th {
            background: #1e40af;
            color: white;
            padding: 12px 10px;
            text-align: left;
            font-weight: 600;
            font-size: 10pt;
        }

        td {
            padding: 10px;
            border-bottom: 1px solid #e5e7eb;
            font-size: 10pt;
        }

        tr:nth-child(even) {
            background: #f9fafb;
        }

        .status-pass { color: #059669; font-weight: bold; }
        .status-warn { color: #d97706; font-weight: bold; }
        .status-fail { color: #dc2626; font-weight: bold; }
        .status-skip { color: #6b7280; }

        .server-section {
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            page-break-inside: avoid;
        }

        .server-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .server-name {
            font-size: 14pt;
            font-weight: bold;
            color: #1f2937;
        }

        .server-host {
            font-size: 10pt;
            color: #6b7280;
        }

        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 9pt;
            font-weight: 600;
        }

        .badge-success { background: #d1fae5; color: #065f46; }
        .badge-error { background: #fee2e2; color: #991b1b; }
        .badge-warning { background: #fef3c7; color: #92400e; }

        .compliance-section {
            page-break-before: always;
        }

        .control-item {
            border-left: 3px solid #e5e7eb;
            padding-left: 15px;
            margin: 15px 0;
        }

        .control-item.satisfied { border-left-color: #10b981; }
        .control-item.partial { border-left-color: #f59e0b; }
        .control-item.failed { border-left-color: #ef4444; }

        .control-id {
            font-weight: bold;
            color: #374151;
        }

        .control-name {
            color: #6b7280;
            font-size: 10pt;
        }

        .finding-list {
            margin: 15px 0;
            padding-left: 20px;
        }

        .finding-list li {
            margin: 8px 0;
        }

        .recommendation-box {
            background: #fefce8;
            border: 1px solid #facc15;
            border-radius: 6px;
            padding: 15px;
            margin: 15px 0;
        }

        .critical-finding {
            background: #fef2f2;
            border: 1px solid #ef4444;
            border-radius: 6px;
            padding: 15px;
            margin: 15px 0;
        }

        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
            text-align: center;
            color: #9ca3af;
            font-size: 9pt;
        }

        .page-break {
            page-break-before: always;
        }

        .toc {
            page-break-after: always;
        }

        .toc-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px dotted #d1d5db;
        }

        .chart-placeholder {
            background: #f3f4f6;
            border: 2px dashed #d1d5db;
            padding: 40px;
            text-align: center;
            border-radius: 8px;
            margin: 20px 0;
        }
    """

    # HTML template for comprehensive PDF report
    REPORT_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{{ title }}</title>
</head>
<body>
    <!-- Cover Page -->
    <div class="cover-page">
        <div class="cover-title">{{ title }}</div>
        <div class="cover-subtitle">{{ subtitle | default('Security Compliance Assessment') }}</div>
        <div class="cover-meta">
            <p><strong>Generated:</strong> {{ generated_date }}</p>
            <p><strong>Prepared by:</strong> {{ prepared_by | default('Security Audit Toolkit') }}</p>
            {% if organization %}
            <p><strong>Organization:</strong> {{ organization }}</p>
            {% endif %}
            <p><strong>Classification:</strong> {{ classification | default('Confidential') }}</p>
        </div>
    </div>

    <!-- Table of Contents -->
    <div class="toc">
        <h1>Table of Contents</h1>
        <div class="toc-item"><span>1. Executive Summary</span><span>2</span></div>
        <div class="toc-item"><span>2. Compliance Overview</span><span>3</span></div>
        <div class="toc-item"><span>3. Server Details</span><span>4</span></div>
        {% if compliance_framework %}
        <div class="toc-item"><span>4. {{ compliance_framework }} Compliance</span><span>5</span></div>
        {% endif %}
        <div class="toc-item"><span>5. Findings & Recommendations</span><span>6</span></div>
    </div>

    <!-- Executive Summary -->
    <h1>1. Executive Summary</h1>
    <div class="executive-summary">
        <p>{{ executive_summary | default('This report presents the findings of a comprehensive security audit conducted across the organization\'s infrastructure.') }}</p>
    </div>

    <div class="summary-grid">
        <div class="summary-card info">
            <div class="card-label">Total Servers</div>
            <div class="card-value">{{ summary.total_servers }}</div>
        </div>
        <div class="summary-card info">
            <div class="card-label">Total Checks</div>
            <div class="card-value">{{ summary.total_checks }}</div>
        </div>
        <div class="summary-card pass">
            <div class="card-label">Passed</div>
            <div class="card-value">{{ summary.total_pass }}</div>
        </div>
        <div class="summary-card warn">
            <div class="card-label">Warnings</div>
            <div class="card-value">{{ summary.total_warn }}</div>
        </div>
        <div class="summary-card fail">
            <div class="card-label">Failed</div>
            <div class="card-value">{{ summary.total_fail }}</div>
        </div>
    </div>

    <div class="compliance-score {{ score_class }}">
        {{ summary.compliance_percentage }}%
    </div>
    <p style="text-align: center; color: #6b7280;">Overall Compliance Score</p>

    {% if critical_findings %}
    <div class="critical-finding">
        <h3 style="color: #dc2626; margin-top: 0;">⚠️ Critical Findings</h3>
        <ul class="finding-list">
            {% for finding in critical_findings %}
            <li>{{ finding }}</li>
            {% endfor %}
        </ul>
    </div>
    {% endif %}

    <!-- Compliance Overview -->
    <h1 class="page-break">2. Compliance Overview</h1>
    <table>
        <thead>
            <tr>
                <th>Metric</th>
                <th>Count</th>
                <th>Percentage</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Passed Checks</td>
                <td>{{ summary.total_pass }}</td>
                <td>{{ pass_percentage }}%</td>
                <td class="status-pass">COMPLIANT</td>
            </tr>
            <tr>
                <td>Warnings</td>
                <td>{{ summary.total_warn }}</td>
                <td>{{ warn_percentage }}%</td>
                <td class="status-warn">REVIEW REQUIRED</td>
            </tr>
            <tr>
                <td>Failed Checks</td>
                <td>{{ summary.total_fail }}</td>
                <td>{{ fail_percentage }}%</td>
                <td class="status-fail">NON-COMPLIANT</td>
            </tr>
            <tr>
                <td>Skipped</td>
                <td>{{ summary.total_skip }}</td>
                <td>{{ skip_percentage }}%</td>
                <td class="status-skip">N/A</td>
            </tr>
        </tbody>
    </table>

    <!-- Server Details -->
    <h1 class="page-break">3. Server Details</h1>
    {% for server in servers %}
    <div class="server-section">
        <div class="server-header">
            <div>
                <div class="server-name">{{ server.name }}</div>
                <div class="server-host">{{ server.host }}</div>
            </div>
            <span class="badge {% if server.status == 'success' %}badge-success{% else %}badge-error{% endif %}">
                {{ server.status | upper }}
            </span>
        </div>

        {% if server.status == 'success' %}
        <table>
            <thead>
                <tr>
                    <th>Check Type</th>
                    <th>Count</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Passed</td>
                    <td class="status-pass">{{ server.metrics.pass }}</td>
                    <td>{{ server.pass_percentage }}%</td>
                </tr>
                <tr>
                    <td>Warnings</td>
                    <td class="status-warn">{{ server.metrics.warn }}</td>
                    <td>{{ (server.metrics.warn / server.metrics.total * 100) | round(1) if server.metrics.total > 0 else 0 }}%</td>
                </tr>
                <tr>
                    <td>Failed</td>
                    <td class="status-fail">{{ server.metrics.fail }}</td>
                    <td>{{ (server.metrics.fail / server.metrics.total * 100) | round(1) if server.metrics.total > 0 else 0 }}%</td>
                </tr>
                <tr>
                    <td>Skipped</td>
                    <td class="status-skip">{{ server.metrics.skip }}</td>
                    <td>{{ (server.metrics.skip / server.metrics.total * 100) | round(1) if server.metrics.total > 0 else 0 }}%</td>
                </tr>
            </tbody>
        </table>
        {% else %}
        <div class="badge badge-error" style="display: block; text-align: center; padding: 20px;">
            Error: {{ server.error | default('Unable to fetch audit data') }}
        </div>
        {% endif %}
    </div>
    {% endfor %}

    {% if compliance_mapping %}
    <!-- Compliance Framework Section -->
    <div class="compliance-section">
        <h1>4. {{ compliance_framework }} Compliance Mapping</h1>
        <p>The following section maps audit findings to {{ compliance_framework }} controls.</p>

        {% for category, controls in compliance_mapping.items() %}
        <h2>{{ category }}</h2>
        {% for control in controls %}
        <div class="control-item {{ control.status }}">
            <span class="control-id">{{ control.id }}</span>
            <span class="control-name"> - {{ control.name }}</span>
            <p>{{ control.description }}</p>
            <p><strong>Status:</strong>
                {% if control.status == 'satisfied' %}
                <span class="status-pass">SATISFIED</span>
                {% elif control.status == 'partial' %}
                <span class="status-warn">PARTIALLY SATISFIED</span>
                {% else %}
                <span class="status-fail">NOT SATISFIED</span>
                {% endif %}
            </p>
            {% if control.evidence %}
            <p><strong>Evidence:</strong> {{ control.evidence }}</p>
            {% endif %}
        </div>
        {% endfor %}
        {% endfor %}
    </div>
    {% endif %}

    <!-- Findings & Recommendations -->
    <h1 class="page-break">5. Findings & Recommendations</h1>

    {% if recommendations %}
    <h2>Key Recommendations</h2>
    {% for rec in recommendations %}
    <div class="recommendation-box">
        <h3 style="margin-top: 0;">{{ rec.title }}</h3>
        <p>{{ rec.description }}</p>
        <p><strong>Priority:</strong> {{ rec.priority }}</p>
        {% if rec.effort %}
        <p><strong>Estimated Effort:</strong> {{ rec.effort }}</p>
        {% endif %}
    </div>
    {% endfor %}
    {% else %}
    <p>No specific recommendations at this time. Continue following security best practices.</p>
    {% endif %}

    <!-- Footer -->
    <div class="footer">
        <p>This report was generated on {{ generated_date }} by Security Audit Toolkit v4.1</p>
        <p class="classification">{{ classification | default('Confidential') }} - Do not distribute without authorization</p>
    </div>
</body>
</html>
    """

    def __init__(self, custom_css: Optional[str] = None):
        """
        Initialize PDF report generator.

        Args:
            custom_css: Optional custom CSS to override default styling
        """
        if not WEASYPRINT_AVAILABLE:
            raise ImportError(
                "WeasyPrint is not installed. Please install with: "
                "pip install weasyprint"
            )

        self.css = custom_css or self.DEFAULT_CSS
        self.template = Template(self.REPORT_TEMPLATE)

    def generate_pdf(
        self,
        report_data: dict[str, Any],
        compliance_framework: Optional[str] = None,
        compliance_mapping: Optional[dict] = None,
        recommendations: Optional[list] = None,
        organization: Optional[str] = None,
        classification: str = "Confidential",
        executive_summary: Optional[str] = None
    ) -> bytes:
        """
        Generate PDF report from audit data.

        Args:
            report_data: Report data from /api/reports/generate
            compliance_framework: Optional compliance framework name
            compliance_mapping: Optional compliance control mapping
            recommendations: Optional list of recommendations
            organization: Optional organization name
            classification: Document classification level
            executive_summary: Optional custom executive summary text

        Returns:
            PDF content as bytes
        """
        try:
            summary = report_data.get("summary", {})
            total = summary.get("total_checks", 0) or 1  # Avoid division by zero

            # Calculate percentages
            pass_pct = round(summary.get("total_pass", 0) / total * 100, 1)
            warn_pct = round(summary.get("total_warn", 0) / total * 100, 1)
            fail_pct = round(summary.get("total_fail", 0) / total * 100, 1)
            skip_pct = round(summary.get("total_skip", 0) / total * 100, 1)

            # Determine score class for styling
            compliance = summary.get("compliance_percentage", 0)
            if compliance >= 90:
                score_class = "score-high"
            elif compliance >= 70:
                score_class = "score-medium"
            else:
                score_class = "score-low"

            # Identify critical findings (failed checks)
            critical_findings = []
            for server in report_data.get("servers", []):
                if server.get("status") == "success":
                    if server.get("metrics", {}).get("fail", 0) > 0:
                        critical_findings.append(
                            f"{server['name']}: {server['metrics']['fail']} failed security checks"
                        )

            # Generate default executive summary if not provided
            if not executive_summary:
                executive_summary = self._generate_executive_summary(report_data)

            # Render HTML
            html_content = self.template.render(
                title=report_data.get("title", "Security Audit Report"),
                subtitle=report_data.get("subtitle", "Comprehensive Security Assessment"),
                generated_date=datetime.now().strftime("%B %d, %Y at %H:%M"),
                organization=organization,
                classification=classification,
                prepared_by="Security Audit Toolkit",
                summary=summary,
                servers=report_data.get("servers", []),
                score_class=score_class,
                pass_percentage=pass_pct,
                warn_percentage=warn_pct,
                fail_percentage=fail_pct,
                skip_percentage=skip_pct,
                critical_findings=critical_findings[:5],  # Limit to top 5
                compliance_framework=compliance_framework,
                compliance_mapping=compliance_mapping,
                recommendations=recommendations,
                executive_summary=executive_summary
            )

            # Generate PDF
            html = HTML(string=html_content)
            css = CSS(string=self.css)

            pdf_buffer = io.BytesIO()
            html.write_pdf(pdf_buffer, stylesheets=[css])

            return pdf_buffer.getvalue()

        except Exception as e:
            logger.error(f"Error generating PDF: {e}")
            raise

    def _generate_executive_summary(self, report_data: dict) -> str:
        """Generate automatic executive summary from audit data."""
        summary = report_data.get("summary", {})
        servers = report_data.get("servers", [])

        total_servers = summary.get("total_servers", 0)
        compliance = summary.get("compliance_percentage", 0)
        total_fail = summary.get("total_fail", 0)
        total_warn = summary.get("total_warn", 0)

        # Determine overall assessment
        if compliance >= 95:
            assessment = "excellent"
            recommendation = "Continue maintaining current security practices."
        elif compliance >= 85:
            assessment = "good"
            recommendation = "Address warning items to further improve security posture."
        elif compliance >= 70:
            assessment = "moderate"
            recommendation = "Prioritize remediation of failed checks to improve compliance."
        else:
            assessment = "concerning"
            recommendation = "Immediate action required to address critical security gaps."

        return (
            f"A comprehensive security audit was conducted across {total_servers} server(s) "
            f"in the organization's infrastructure. The overall compliance score is "
            f"{compliance}%, which is considered {assessment}. "
            f"The audit identified {total_fail} failed check(s) and {total_warn} warning(s) "
            f"that require attention. {recommendation}"
        )

    def generate_simple_pdf(self, html_content: str) -> bytes:
        """
        Generate PDF from raw HTML content.

        Args:
            html_content: HTML string to convert

        Returns:
            PDF content as bytes
        """
        try:
            html = HTML(string=html_content)
            css = CSS(string=self.css)

            pdf_buffer = io.BytesIO()
            html.write_pdf(pdf_buffer, stylesheets=[css])

            return pdf_buffer.getvalue()

        except Exception as e:
            logger.error(f"Error generating simple PDF: {e}")
            raise


def is_pdf_available() -> bool:
    """Check if PDF generation is available."""
    return WEASYPRINT_AVAILABLE
