#!/usr/bin/env bash
#
# reset-docker-db.sh - Reset Docker containers with fresh database
#
# This script fixes the PostgreSQL password authentication issue by:
# 1. Stopping all containers
# 2. Removing the postgres volume (fresh database)
# 3. Rebuilding and starting containers
#
# Usage: ./reset-docker-db.sh
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."

echo ""
echo "======================================="
echo " Docker Database Reset"
echo "======================================="
echo ""
echo "This will:"
echo "  1. Stop all containers"
echo "  2. Remove PostgreSQL volume (DATA WILL BE LOST)"
echo "  3. Rebuild and start containers"
echo ""

# Check if .env exists
if [[ ! -f .env ]]; then
    echo "[ERROR] .env file not found!"
    echo "  Copy .env.example to .env and set passwords first:"
    echo "    cp .env.example .env"
    exit 1
fi

# Verify required env vars
if ! grep -q "POSTGRES_PASSWORD=." .env 2>/dev/null; then
    echo "[ERROR] POSTGRES_PASSWORD not set in .env"
    exit 1
fi

if ! grep -q "REDIS_PASSWORD=." .env 2>/dev/null; then
    echo "[ERROR] REDIS_PASSWORD not set in .env"
    exit 1
fi

if ! grep -q "FLASK_SECRET_KEY=." .env 2>/dev/null; then
    echo "[ERROR] FLASK_SECRET_KEY not set in .env"
    exit 1
fi

echo "[INFO] Environment variables verified"
echo ""

# Confirm
read -p "Continue with database reset? This will DELETE all data. [y/N] " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 0
fi

echo ""
echo "[STEP 1/4] Stopping containers..."
docker-compose down --remove-orphans 2>/dev/null || true

echo ""
echo "[STEP 2/4] Removing PostgreSQL volume..."
docker volume rm audit-tool-_postgres-data 2>/dev/null || \
    docker volume rm audit-tool_postgres-data 2>/dev/null || \
    echo "  No existing volume to remove"

echo ""
echo "[STEP 3/4] Rebuilding containers..."
docker-compose build --no-cache web celery-worker 2>/dev/null || docker-compose build web

echo ""
echo "[STEP 4/4] Starting containers..."
docker-compose up -d

echo ""
echo "======================================="
echo " Waiting for services to start..."
echo "======================================="
sleep 5

# Check status
echo ""
docker-compose ps

echo ""
echo "======================================="
echo " Checking logs for errors..."
echo "======================================="
echo ""
echo "--- PostgreSQL ---"
docker-compose logs --tail=10 postgres 2>/dev/null | grep -E "ready|listening|error|failed" || echo "  Container starting..."

echo ""
echo "--- Web App ---"
docker-compose logs --tail=10 web 2>/dev/null | grep -E "Running|error|Traceback" || echo "  Container starting..."

echo ""
echo "======================================="
echo " Reset Complete"
echo "======================================="
echo ""
echo "Web interface: http://localhost:5000"
echo ""
echo "If issues persist, check full logs:"
echo "  docker-compose logs -f"
echo ""
