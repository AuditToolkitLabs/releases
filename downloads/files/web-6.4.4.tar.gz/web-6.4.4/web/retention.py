"""
Data Retention and Archival Policies

Automatically clean up old audit data based on configurable retention policies:
- audit_executions: Retain raw execution logs for N days
- audit_history_summaries: Retain aggregated summaries for M days
- server_compliance_history: Retain compliance data for L days

Features:
- Configurable retention periods via environment variables
- Dry-run mode for testing
- Automatic cleanup scheduler
- Archive exports before deletion (optional)

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import json
from datetime import datetime, timedelta
from config import logger
from config import SessionLocal, LOGS_DIR
from models.database import AuditExecution
from models.audit_history import AuditHistorySummary, ServerComplianceHistory


# ============================================================================
# Configuration
# ============================================================================

class RetentionPolicy:
    """Retention policy configuration"""

    def __init__(self):
        # Days to retain data (configurable via environment variables)
        self.RAW_EXECUTIONS_DAYS = int(os.environ.get('RETENTION_RAW_EXECUTIONS_DAYS', 90))
        self.HISTORY_SUMMARIES_DAYS = int(os.environ.get('RETENTION_HISTORY_SUMMARIES_DAYS', 365))
        self.COMPLIANCE_HISTORY_DAYS = int(os.environ.get('RETENTION_COMPLIANCE_HISTORY_DAYS', 365))

        # Archive before delete
        self.ARCHIVE_BEFORE_DELETE = os.environ.get('ARCHIVE_BEFORE_DELETE', 'true').lower() == 'true'
        self.ARCHIVE_DIR = LOGS_DIR / 'archives'

        # Ensure archive directory exists
        if self.ARCHIVE_BEFORE_DELETE:
            self.ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)

    def __repr__(self):
        return (f"RetentionPolicy(raw={self.RAW_EXECUTIONS_DAYS}d, "
                f"summaries={self.HISTORY_SUMMARIES_DAYS}d, "
                f"compliance={self.COMPLIANCE_HISTORY_DAYS}d)")


# Global policy instance
policy = RetentionPolicy()


# ============================================================================
# Cleanup Functions
# ============================================================================

def cleanup_raw_executions(db, dry_run=False):
    """
    Clean up old audit execution records

    Args:
        db: SQLAlchemy session
        dry_run: If True, only count records without deleting

    Returns:
        int: Number of records deleted/counted
    """
    cutoff_date = datetime.utcnow() - timedelta(days=policy.RAW_EXECUTIONS_DAYS)

    logger.info(f"Cleaning raw executions older than {cutoff_date.strftime('%Y-%m-%d')}")

    # Query old executions
    query = db.query(AuditExecution).filter(
        AuditExecution.executed_at < cutoff_date
    )

    count = query.count()

    if count == 0:
        logger.info("No old raw executions to clean")
        return 0

    if dry_run:
        logger.info(f"DRY RUN: Would delete {count} raw execution records")
        return count

    # Archive before delete if enabled (MEDIUM-04 fix: with error handling)
    if policy.ARCHIVE_BEFORE_DELETE:
        executions = query.all()
        try:
            archive_executions(executions)
        except Exception as e:
            logger.error(f"Archive failed, aborting cleanup of raw executions: {e}")
            raise RuntimeError(f"Archive failed: {e}") from e

    # Delete old records
    deleted = query.delete(synchronize_session=False)
    db.commit()

    logger.info(f"Deleted {deleted} raw execution records older than {policy.RAW_EXECUTIONS_DAYS} days")
    return deleted


def cleanup_history_summaries(db, dry_run=False):
    """
    Clean up old audit history summaries

    Args:
        db: SQLAlchemy session
        dry_run: If True, only count records without deleting

    Returns:
        int: Number of records deleted/counted
    """
    cutoff_date = datetime.utcnow() - timedelta(days=policy.HISTORY_SUMMARIES_DAYS)

    logger.info(f"Cleaning history summaries older than {cutoff_date.strftime('%Y-%m-%d')}")

    # Query old summaries
    query = db.query(AuditHistorySummary).filter(
        AuditHistorySummary.date < cutoff_date
    )

    count = query.count()

    if count == 0:
        logger.info("No old history summaries to clean")
        return 0

    if dry_run:
        logger.info(f"DRY RUN: Would delete {count} history summary records")
        return count

    # Archive before delete if enabled (MEDIUM-04 fix: with error handling)
    if policy.ARCHIVE_BEFORE_DELETE:
        summaries = query.all()
        try:
            archive_summaries(summaries)
        except Exception as e:
            logger.error(f"Archive failed, aborting cleanup of history summaries: {e}")
            raise RuntimeError(f"Archive failed: {e}") from e

    # Delete old records
    deleted = query.delete(synchronize_session=False)
    db.commit()

    logger.info(f"Deleted {deleted} history summary records older than {policy.HISTORY_SUMMARIES_DAYS} days")
    return deleted


def cleanup_compliance_history(db, dry_run=False):
    """
    Clean up old server compliance history

    Args:
        db: SQLAlchemy session
        dry_run: If True, only count records without deleting

    Returns:
        int: Number of records deleted/counted
    """
    cutoff_date = datetime.utcnow() - timedelta(days=policy.COMPLIANCE_HISTORY_DAYS)

    logger.info(f"Cleaning compliance history older than {cutoff_date.strftime('%Y-%m-%d')}")

    # Query old compliance records
    query = db.query(ServerComplianceHistory).filter(
        ServerComplianceHistory.date < cutoff_date
    )

    count = query.count()

    if count == 0:
        logger.info("No old compliance history to clean")
        return 0

    if dry_run:
        logger.info(f"DRY RUN: Would delete {count} compliance history records")
        return count

    # Archive before delete if enabled (MEDIUM-04 fix: with error handling)
    if policy.ARCHIVE_BEFORE_DELETE:
        compliance_records = query.all()
        try:
            archive_compliance(compliance_records)
        except Exception as e:
            logger.error(f"Archive failed, aborting cleanup of compliance history: {e}")
            raise RuntimeError(f"Archive failed: {e}") from e

    # Delete old records
    deleted = query.delete(synchronize_session=False)
    db.commit()

    logger.info(f"Deleted {deleted} compliance history records older than {policy.COMPLIANCE_HISTORY_DAYS} days")
    return deleted


def cleanup_all(db, dry_run=False):
    """
    Run all cleanup tasks

    Args:
        db: SQLAlchemy session
        dry_run: If True, only count records without deleting

    Returns:
        dict: Summary of deletions
    """
    logger.info("=== Starting data retention cleanup ===")
    logger.info(f"Policy: {policy}")

    result = {
        'raw_executions': cleanup_raw_executions(db, dry_run),
        'history_summaries': cleanup_history_summaries(db, dry_run),
        'compliance_history': cleanup_compliance_history(db, dry_run),
        'dry_run': dry_run
    }

    total = sum(result.values()) - (1 if dry_run else 0)  # Subtract dry_run flag from total

    logger.info(f"=== Cleanup complete: {total} total records ===")
    return result


# ============================================================================
# Archive Functions
# ============================================================================

def archive_executions(executions):
    """
    Archive audit executions to JSON files before deletion

    Args:
        executions: List of AuditExecution objects
    """
    if not executions:
        return

    timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    archive_file = policy.ARCHIVE_DIR / f'executions_{timestamp}.json'

    data = [
        {
            'id': e.id,
            'server_id': e.server_id,
            'audit_id': e.audit_id,
            'status': e.status,
            'exit_code': e.exit_code,
            'summary': e.summary,
            'duration_seconds': e.duration_seconds,
            'executed_at': e.executed_at.isoformat() if e.executed_at else None,
            'completed_at': e.completed_at.isoformat() if e.completed_at else None
        }
        for e in executions
    ]

    with open(archive_file, 'w') as f:
        json.dump(data, f, indent=2)

    logger.info(f"Archived {len(executions)} executions to {archive_file}")


def archive_summaries(summaries):
    """
    Archive history summaries to JSON files before deletion

    Args:
        summaries: List of AuditHistorySummary objects
    """
    if not summaries:
        return

    timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    archive_file = policy.ARCHIVE_DIR / f'summaries_{timestamp}.json'

    data = [s.to_dict() for s in summaries]

    with open(archive_file, 'w') as f:
        json.dump(data, f, indent=2)

    logger.info(f"Archived {len(summaries)} summaries to {archive_file}")


def archive_compliance(compliance_records):
    """
    Archive compliance history to JSON files before deletion

    Args:
        compliance_records: List of ServerComplianceHistory objects
    """
    if not compliance_records:
        return

    timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    archive_file = policy.ARCHIVE_DIR / f'compliance_{timestamp}.json'

    data = [c.to_dict() for c in compliance_records]

    with open(archive_file, 'w') as f:
        json.dump(data, f, indent=2)

    logger.info(f"Archived {len(compliance_records)} compliance records to {archive_file}")


# ============================================================================
# CLI Entry Point
# ============================================================================

def main():
    """Command-line entry point for manual cleanup"""
    import argparse

    parser = argparse.ArgumentParser(description='Run data retention cleanup')
    parser.add_argument('--dry-run', action='store_true', help='Count records without deleting')
    parser.add_argument('--raw-days', type=int, help='Override raw executions retention days')
    parser.add_argument('--summary-days', type=int, help='Override history summaries retention days')
    parser.add_argument('--compliance-days', type=int, help='Override compliance history retention days')

    args = parser.parse_args()

    # Override policy if specified
    if args.raw_days:
        policy.RAW_EXECUTIONS_DAYS = args.raw_days
    if args.summary_days:
        policy.HISTORY_SUMMARIES_DAYS = args.summary_days
    if args.compliance_days:
        policy.COMPLIANCE_HISTORY_DAYS = args.compliance_days

    # Run cleanup
    db = SessionLocal()
    try:
        result = cleanup_all(db, dry_run=args.dry_run)

        logger.info("="*50)
        logger.info("=== Cleanup Summary ===")
        logger.info("="*50)
        logger.info(f"Raw executions: {result['raw_executions']}")
        logger.info(f"History summaries: {result['history_summaries']}")
        logger.info(f"Compliance history: {result['compliance_history']}")
        logger.info(f"Mode: {'DRY RUN' if result['dry_run'] else 'LIVE'}")
        logger.info("="*50)

        if result['dry_run']:
            logger.warning("Run without --dry-run to actually delete records")

    finally:
        db.close()


if __name__ == '__main__':
    main()


__all__ = [
    'RetentionPolicy',
    'policy',
    'cleanup_all',
    'cleanup_raw_executions',
    'cleanup_history_summaries',
    'cleanup_compliance_history'
]
