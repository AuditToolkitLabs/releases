import os
import sys

# Add the web directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app

if __name__ == "__main__":
    debug = os.environ.get("FLASK_DEBUG", "false").lower() in ("true", "1", "yes")
    port = int(os.environ.get("FLASK_PORT", 5000))

    # SECURITY: Default to localhost-only binding.
    # Set FLASK_BIND_HOST=0.0.0.0 explicitly for development scenarios that require
    # remote access to the Flask dev server.
    # nosec B104 - Configurable via FLASK_BIND_HOST env var, documented security warning below
    host = os.environ.get("FLASK_BIND_HOST", "127.0.0.1")  # nosec B104

    if host in ("127.0.0.1", "localhost", "::1"):
        print(f"[SECURITY] Binding to localhost only (port {port})")
        print("[SECURITY] External access should go through HTTPS reverse proxy")
    else:
        print(f"[WARNING] Binding to all interfaces ({host}:{port})")
        print("[WARNING] For production, prefer FLASK_BIND_HOST=127.0.0.1 behind HTTPS")

    app.run(host=host, port=port, debug=debug)
