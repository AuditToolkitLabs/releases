#!/usr/bin/env python3
"""
API Request Schema Validation Module

Provides Marshmallow-based schema validation for all API endpoints.
Ensures all incoming data is properly validated before processing.

Security Benefits:
- Prevents injection attacks via strict type enforcement
- Validates field lengths to prevent buffer overflow
- Rejects unexpected fields (unknown='RAISE')
- Provides clear validation error messages

Author: Security Audit Toolkit Team
Date: February 10, 2026
"""

from functools import wraps
from flask import request, jsonify
from marshmallow import Schema, fields, validate, ValidationError, RAISE
import logging
import re

logger = logging.getLogger(__name__)


# =============================================================================
# Base Schema with Security Defaults
# =============================================================================

class SecureSchema(Schema):
    """
    Base schema with security-focused defaults.

    - Rejects unknown fields (prevents mass assignment)
    - Strips whitespace from strings
    - Logs validation failures
    """
    class Meta:
        unknown = RAISE  # Reject unexpected fields

    def handle_error(self, error, data, **kwargs):
        """Log validation errors for security monitoring"""
        logger.warning(f"Schema validation failed: {error.messages}")
        raise error


# =============================================================================
# Validation Decorators
# =============================================================================

def validate_json(schema_cls):
    """
    Decorator to validate request JSON against a Marshmallow schema.

    Usage:
        @app.route('/api/users', methods=['POST'])
        @validate_json(CreateUserSchema)
        def create_user():
            # request.validated_data contains the validated data
            data = request.validated_data
            ...
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            json_data = request.get_json()

            if json_data is None:
                return jsonify({
                    'success': False,
                    'error': 'Request body must be valid JSON'
                }), 400

            schema = schema_cls()
            try:
                validated_data = schema.load(json_data)
                request.validated_data = validated_data
            except ValidationError as e:
                logger.warning(f"Validation error on {request.path}: {e.messages}")
                return jsonify({
                    'success': False,
                    'error': 'Validation failed',
                    'details': e.messages
                }), 400

            return f(*args, **kwargs)
        return decorated_function
    return decorator


def validate_query_params(schema_cls):
    """
    Decorator to validate query parameters.

    Usage:
        @app.route('/api/servers', methods=['GET'])
        @validate_query_params(ListServersQuerySchema)
        def list_servers():
            params = request.validated_params
            ...
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            schema = schema_cls()
            try:
                validated_params = schema.load(request.args.to_dict())
                request.validated_params = validated_params
            except ValidationError as e:
                return jsonify({
                    'success': False,
                    'error': 'Invalid query parameters',
                    'details': e.messages
                }), 400

            return f(*args, **kwargs)
        return decorated_function
    return decorator


# =============================================================================
# Custom Validators
# =============================================================================

class SafeString(fields.String):
    """String field that rejects dangerous characters"""

    def _deserialize(self, value, attr, data, **kwargs):
        value = super()._deserialize(value, attr, data, **kwargs)
        if value:
            # Strip control characters except newline/tab
            value = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', value)
        return value


class Hostname(fields.String):
    """Validated hostname field"""

    HOSTNAME_REGEX = re.compile(r'^[a-zA-Z0-9]([a-zA-Z0-9.-]{0,253}[a-zA-Z0-9])?$')

    def _deserialize(self, value, attr, data, **kwargs):
        value = super()._deserialize(value, attr, data, **kwargs)
        if value and not self.HOSTNAME_REGEX.match(value):
            raise ValidationError(f"Invalid hostname: {value}")
        return value


class IPAddress(fields.String):
    """Validated IP address field (v4 or v6)"""

    def _deserialize(self, value, attr, data, **kwargs):
        value = super()._deserialize(value, attr, data, **kwargs)
        if value:
            import ipaddress
            try:
                ipaddress.ip_address(value)
            except ValueError:
                raise ValidationError(f"Invalid IP address: {value}")
        return value


class Port(fields.Integer):
    """Validated port number field (1-65535)"""

    def __init__(self, **kwargs):
        super().__init__(
            validate=validate.Range(min=1, max=65535),
            **kwargs
        )


class SafePath(fields.String):
    """Path field that rejects traversal attempts"""

    DANGEROUS_PATTERNS = [
        '..', '~/', '//', '\\\\',
        '\x00', '%00', '%2e%2e'
    ]

    def _deserialize(self, value, attr, data, **kwargs):
        value = super()._deserialize(value, attr, data, **kwargs)
        if value:
            value_lower = value.lower()
            for pattern in self.DANGEROUS_PATTERNS:
                if pattern in value_lower:
                    raise ValidationError(f"Path contains forbidden pattern: {pattern}")
        return value


# =============================================================================
# Server Schemas
# =============================================================================

class ServerCreateSchema(SecureSchema):
    """Schema for creating a new server"""
    name = SafeString(required=True, validate=validate.Length(min=1, max=100))
    host = Hostname(required=True)
    port = Port(load_default=22)
    username = SafeString(required=True, validate=validate.Length(min=1, max=50))
    password = fields.String(load_default=None)  # Allow special chars for passwords
    ssh_key_path = SafePath(load_default=None, validate=validate.Length(max=500))
    platform = fields.String(
        load_default='linux',
        validate=validate.OneOf(['linux', 'windows', 'macos'])
    )
    os_version = SafeString(load_default=None, validate=validate.Length(max=100))
    description = SafeString(load_default=None, validate=validate.Length(max=500))
    tags = fields.List(SafeString(validate=validate.Length(max=50)), load_default=[])
    # Elevation method for privilege escalation during audits
    # Linux: sudo, sudo_nopasswd, audit_wrapper, none
    # Windows: runas, jea, admin, none
    elevation_method = fields.String(
        load_default='sudo',
        validate=validate.OneOf(['sudo', 'sudo_nopasswd', 'audit_wrapper', 'runas', 'jea', 'admin', 'none'])
    )
    # JEA endpoint name (Windows only, when elevation_method='jea')
    jea_endpoint = SafeString(load_default=None, validate=validate.Length(max=100))


class ServerUpdateSchema(SecureSchema):
    """Schema for updating a server"""
    name = SafeString(validate=validate.Length(min=1, max=100))
    host = Hostname()
    port = Port()
    username = SafeString(validate=validate.Length(min=1, max=50))
    password = fields.String()
    ssh_key_path = SafePath(validate=validate.Length(max=500))
    platform = fields.String(validate=validate.OneOf(['linux', 'windows', 'macos']))
    os_version = SafeString(validate=validate.Length(max=100))
    description = SafeString(validate=validate.Length(max=500))
    tags = fields.List(SafeString(validate=validate.Length(max=50)))
    # Elevation method for privilege escalation during audits
    elevation_method = fields.String(
        validate=validate.OneOf(['sudo', 'sudo_nopasswd', 'audit_wrapper', 'runas', 'jea', 'admin', 'none'])
    )
    # JEA endpoint name (Windows only)
    jea_endpoint = SafeString(validate=validate.Length(max=100))


class ServerListQuerySchema(SecureSchema):
    """Schema for server list query parameters"""
    class Meta:
        unknown = 'EXCLUDE'  # Ignore unknown query params

    page = fields.Integer(load_default=1, validate=validate.Range(min=1))
    per_page = fields.Integer(load_default=20, validate=validate.Range(min=1, max=100))
    platform = fields.String(validate=validate.OneOf(['linux', 'windows', 'macos', 'all']))
    search = SafeString(validate=validate.Length(max=100))
    tag = SafeString(validate=validate.Length(max=50))


# =============================================================================
# User/Auth Schemas
# =============================================================================

class UserCreateSchema(SecureSchema):
    """Schema for creating a new user"""
    username = SafeString(
        required=True,
        validate=[
            validate.Length(min=3, max=50),
            validate.Regexp(r'^[a-zA-Z0-9_-]+$', error="Username can only contain letters, numbers, - and _")
        ]
    )
    email = fields.Email(required=True)
    password = fields.String(
        required=True,
        validate=validate.Length(min=8, max=128)
    )
    display_name = SafeString(validate=validate.Length(max=100))
    role = fields.String(
        load_default='Viewer',
        validate=validate.OneOf(['Viewer', 'Operator', 'Analyst', 'Admin', 'SuperAdmin'])
    )


class UserUpdateSchema(SecureSchema):
    """Schema for updating a user"""
    email = fields.Email()
    display_name = SafeString(validate=validate.Length(max=100))
    role = fields.String(validate=validate.OneOf(['Viewer', 'Operator', 'Analyst', 'Admin', 'SuperAdmin']))
    is_active = fields.Boolean()


class LoginSchema(SecureSchema):
    """Schema for login requests"""
    username = SafeString(required=True, validate=validate.Length(min=1, max=50))
    password = fields.String(required=True, validate=validate.Length(min=1, max=128))
    mfa_code = SafeString(validate=validate.Length(min=6, max=6))


class PasswordChangeSchema(SecureSchema):
    """Schema for password change requests"""
    current_password = fields.String(required=True, validate=validate.Length(min=1, max=128))
    new_password = fields.String(
        required=True,
        validate=validate.Length(min=8, max=128)
    )


# =============================================================================
# Audit Execution Schemas
# =============================================================================

class AuditExecuteSchema(SecureSchema):
    """Schema for executing an audit"""
    server_ids = fields.List(
        fields.Integer(validate=validate.Range(min=1)),
        required=True,
        validate=validate.Length(min=1, max=100)
    )
    audit_path = SafePath(required=True, validate=validate.Length(min=1, max=500))
    timeout = fields.Integer(
        load_default=600,
        validate=validate.Range(min=30, max=3600)
    )
    options = fields.Dict(load_default={})


class BatchExecuteSchema(SecureSchema):
    """Schema for batch audit execution"""
    server_ids = fields.List(
        fields.Integer(validate=validate.Range(min=1)),
        required=True,
        validate=validate.Length(min=1, max=500)
    )
    audit_name = SafeString(required=True, validate=validate.Length(min=1, max=200))
    max_concurrent = fields.Integer(
        load_default=50,
        validate=validate.Range(min=1, max=200)
    )
    timeout_seconds = fields.Integer(
        load_default=600,
        validate=validate.Range(min=30, max=7200)
    )


class MatrixExecuteSchema(SecureSchema):
    """Schema for matrix audit execution"""
    server_ids = fields.List(
        fields.Integer(validate=validate.Range(min=1)),
        required=True,
        validate=validate.Length(min=1, max=500)
    )
    audit_paths = fields.List(
        SafePath(validate=validate.Length(min=1, max=500)),
        required=True,
        validate=validate.Length(min=1, max=50)
    )
    plan_name = SafeString(load_default=None, validate=validate.Length(max=200))
    max_concurrent = fields.Integer(
        load_default=50,
        validate=validate.Range(min=1, max=200)
    )


# =============================================================================
# Schedule Schemas
# =============================================================================

class ScheduleCreateSchema(SecureSchema):
    """Schema for creating a schedule"""
    name = SafeString(required=True, validate=validate.Length(min=1, max=100))
    description = SafeString(validate=validate.Length(max=500))
    cron_expression = SafeString(
        required=True,
        validate=validate.Regexp(
            r'^[\d\*,/-]+ [\d\*,/-]+ [\d\*,/-]+ [\d\*,/-]+ [\d\*,/-]+$',
            error="Invalid cron expression format"
        )
    )
    server_ids = fields.List(
        fields.Integer(validate=validate.Range(min=1)),
        required=True,
        validate=validate.Length(min=1)
    )
    audit_path = SafePath(required=True, validate=validate.Length(min=1, max=500))
    enabled = fields.Boolean(load_default=True)
    notification_emails = fields.List(fields.Email(), load_default=[])


# =============================================================================
# Discovery Schemas
# =============================================================================

class DiscoverySchema(SecureSchema):
    """Schema for network discovery"""
    network = fields.String(
        required=True,
        validate=validate.Regexp(
            r'^(\d{1,3}\.){3}\d{1,3}/\d{1,2}$',
            error="Invalid CIDR notation (e.g., 192.168.1.0/24)"
        )
    )
    ports = fields.List(
        Port(),
        load_default=[22, 3389, 5985]
    )
    ssh_username = SafeString(validate=validate.Length(max=50))
    timeout_seconds = fields.Integer(
        load_default=10,
        validate=validate.Range(min=1, max=60)
    )


# =============================================================================
# Export all schemas
# =============================================================================

__all__ = [
    # Base
    'SecureSchema',
    'validate_json',
    'validate_query_params',

    # Custom fields
    'SafeString',
    'Hostname',
    'IPAddress',
    'Port',
    'SafePath',

    # Server
    'ServerCreateSchema',
    'ServerUpdateSchema',
    'ServerListQuerySchema',

    # User/Auth
    'UserCreateSchema',
    'UserUpdateSchema',
    'LoginSchema',
    'PasswordChangeSchema',

    # Audit
    'AuditExecuteSchema',
    'BatchExecuteSchema',
    'MatrixExecuteSchema',

    # Schedule
    'ScheduleCreateSchema',

    # Discovery
    'DiscoverySchema',
]
