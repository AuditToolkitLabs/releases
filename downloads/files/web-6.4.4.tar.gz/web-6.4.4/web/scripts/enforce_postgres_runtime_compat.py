#!/usr/bin/env python3
import os
import subprocess  # nosec B404 - controlled internal subprocess usage for Alembic commands
import sys
from pathlib import Path

from sqlalchemy import create_engine, inspect, text

WEB_DIR = Path(__file__).resolve().parents[1]
REPO_ROOT = WEB_DIR.parent

if str(WEB_DIR) not in sys.path:
    sys.path.insert(0, str(WEB_DIR))

from models.audit_history import AuditHistorySummary, ServerComplianceHistory
from models.database import Audit, AuditExecution, Base, Server
from models.maintenance_window import MaintenanceWindow, ScheduleExecutionLog
from models.remediation import RemediationExecution, RemediationSettings
from models.schedule import ScheduledAudit
from models.scheduled_report import ScheduledReport
from models.user import User


CORE_ALEMBIC_TABLES = {
    "servers",
    "audits",
    "audit_executions",
    "scheduled_audits",
}


def read_database_url() -> str:
    env_url = os.getenv("DATABASE_URL", "").strip()
    if env_url:
        return env_url

    env_files = [
        REPO_ROOT / ".env",
        WEB_DIR / ".env",
    ]

    for env_file in env_files:
        if not env_file.exists():
            continue

        with env_file.open("r", encoding="utf-8") as handle:
            for raw_line in handle:
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue

                key, value = line.split("=", 1)
                if key.strip() != "DATABASE_URL":
                    continue

                return value.strip().strip('"').strip("'")

    return ""


def normalize_database_url(database_url: str) -> str:
    url = database_url.strip()
    if url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://") :]
    return url


def is_postgresql_url(database_url: str) -> bool:
    return database_url.startswith("postgresql://") or database_url.startswith("postgresql+")


def ensure_alembic_version_table(engine) -> None:
    with engine.begin() as connection:
        connection.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS alembic_version (
                    version_num VARCHAR(255) NOT NULL PRIMARY KEY
                )
                """
            )
        )
        connection.execute(
            text("ALTER TABLE alembic_version ALTER COLUMN version_num TYPE VARCHAR(255)")
        )


def get_alembic_versions(engine) -> list[str]:
    inspector = inspect(engine)
    if "alembic_version" not in inspector.get_table_names():
        return []

    with engine.connect() as connection:
        return [
            version
            for version in connection.execute(
                text("SELECT version_num FROM alembic_version ORDER BY version_num")
            ).scalars()
            if version
        ]


def has_untracked_core_schema(engine) -> bool:
    inspector = inspect(engine)
    table_names = set(inspector.get_table_names())
    return any(table_name in table_names for table_name in CORE_ALEMBIC_TABLES)


def normalize_legacy_revisions(engine) -> None:
    with engine.begin() as connection:
        connection.execute(
            text(
                """
                UPDATE alembic_version
                SET version_num = '008_add_hypervisor_conn_method'
                WHERE version_num = '008_add_hypervisor_connection_method'
                """
            )
        )
        connection.execute(
            text(
                """
                UPDATE alembic_version
                SET version_num = '015_merge_windows_support_main'
                WHERE version_num = '015_merge_windows_support_and_main_head'
                """
            )
        )


def ensure_users_table(engine) -> None:
    inspector = inspect(engine)
    if "users" in inspector.get_table_names():
        return

    Base.metadata.create_all(engine, tables=[User.__table__])


def run_alembic_command(database_url: str, *args: str) -> None:
    config_candidates = [
        REPO_ROOT / "alembic.ini",
        WEB_DIR / "alembic.ini",
    ]
    config_path = next((candidate for candidate in config_candidates if candidate.exists()), None)

    if config_path is None:
        print("[WARN] Alembic config not found; skipping alembic upgrade")
        return

    env = os.environ.copy()
    env["DATABASE_URL"] = database_url
    subprocess.run(
        [sys.executable, "-m", "alembic", "-c", str(config_path), *args],
        cwd=str(REPO_ROOT),
        env=env,
        check=True,
    )  # nosec B603 - command and args are fixed/internal, shell is not used


def run_alembic_upgrade(database_url: str) -> None:
    run_alembic_command(database_url, "upgrade", "head")


def stamp_alembic_head(database_url: str) -> None:
    run_alembic_command(database_url, "stamp", "head")


def reconcile_untracked_schema(engine) -> None:
    print("[INFO] Existing PostgreSQL schema detected without Alembic revision; reconciling current metadata")
    Base.metadata.create_all(engine)
    ensure_users_table(engine)
    enforce_runtime_schema(engine)


def enforce_runtime_schema(engine) -> None:
    # Ensure FK dependency tables exist before creating runtime-maintained tables.
    # Some legacy/partial DB states can miss these, which would make CREATE TABLE
    # for scheduled/history tables fail due to unresolved foreign keys.
    Base.metadata.create_all(
        engine,
        tables=[
            Server.__table__,
            Audit.__table__,
            AuditExecution.__table__,
            RemediationExecution.__table__,
            RemediationSettings.__table__,
            MaintenanceWindow.__table__,
            ScheduledAudit.__table__,
            ScheduledReport.__table__,
            ScheduleExecutionLog.__table__,
            AuditHistorySummary.__table__,
            ServerComplianceHistory.__table__,
        ],
    )

    with engine.begin() as connection:
        connection.execute(text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS connection_method VARCHAR(20) NOT NULL DEFAULT 'ssh'"))
        connection.execute(text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS agent_id VARCHAR(50)"))
        connection.execute(text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS hypervisor_type VARCHAR(50)"))
        connection.execute(text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS hypervisor_endpoint VARCHAR(255)"))

        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS name VARCHAR(255)"))
        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS cron_schedule VARCHAR(100)"))
        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS is_active BOOLEAN"))
        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS notification_enabled BOOLEAN NOT NULL DEFAULT false"))
        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS notification_emails TEXT"))
        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS notification_webhooks TEXT"))
        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS last_run TIMESTAMP"))
        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS next_run TIMESTAMP"))
        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS last_status VARCHAR(50)"))
        connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS created_by VARCHAR(100)"))

        columns = {column["name"] for column in inspect(connection).get_columns("scheduled_audits")}

        if "schedule_cron" in columns and "cron_schedule" in columns:
            connection.execute(text("UPDATE scheduled_audits SET cron_schedule = schedule_cron WHERE cron_schedule IS NULL"))

        if "enabled" in columns and "is_active" in columns:
            connection.execute(text("UPDATE scheduled_audits SET is_active = enabled WHERE is_active IS NULL"))

        if "last_run_at" in columns and "last_run" in columns:
            connection.execute(text("UPDATE scheduled_audits SET last_run = last_run_at WHERE last_run IS NULL"))

        if "next_run_at" in columns and "next_run" in columns:
            connection.execute(text("UPDATE scheduled_audits SET next_run = next_run_at WHERE next_run IS NULL"))

        connection.execute(text("UPDATE scheduled_audits SET name = 'Schedule #' || id WHERE name IS NULL OR TRIM(name) = ''"))
        connection.execute(text("UPDATE scheduled_audits SET cron_schedule = '0 0 * * *' WHERE cron_schedule IS NULL OR TRIM(cron_schedule) = ''"))
        connection.execute(text("UPDATE scheduled_audits SET is_active = true WHERE is_active IS NULL"))

        connection.execute(text("ALTER TABLE scheduled_audits ALTER COLUMN name SET NOT NULL"))
        connection.execute(text("ALTER TABLE scheduled_audits ALTER COLUMN cron_schedule SET NOT NULL"))
        connection.execute(text("ALTER TABLE scheduled_audits ALTER COLUMN is_active SET NOT NULL"))
        connection.execute(text("ALTER TABLE scheduled_audits ALTER COLUMN is_active SET DEFAULT true"))

        connection.execute(text("CREATE INDEX IF NOT EXISTS idx_schedule_active_next_run ON scheduled_audits (is_active, next_run)"))
        connection.execute(text("CREATE INDEX IF NOT EXISTS idx_schedule_server_id ON scheduled_audits (server_id)"))
        connection.execute(text("CREATE INDEX IF NOT EXISTS idx_schedule_audit_id ON scheduled_audits (audit_id)"))

        connection.execute(
            text(
                """
                INSERT INTO remediation_settings (
                    id,
                    enabled,
                    require_dry_run_first,
                    require_approval,
                    timezone,
                    max_fixes_per_hour,
                    max_concurrent_executions,
                    execution_timeout_seconds,
                    linux_enabled,
                    linux_fix_path,
                    windows_enabled,
                    windows_fix_path,
                    hypervisor_enabled,
                    hypervisor_fix_path,
                    auto_deploy_scripts,
                    notify_on_execution,
                    notify_on_failure
                )
                VALUES (
                    1,
                    false,
                    true,
                    false,
                    'UTC',
                    20,
                    3,
                    300,
                    true,
                    '/opt/audit-toolkit/fix/linux',
                    true,
                    'C:\\audit-toolkit\\fix\\windows',
                    true,
                    '/opt/audit-toolkit/fix/hypervisors',
                    true,
                    true,
                    true
                )
                ON CONFLICT (id) DO NOTHING
                """
            )
        )

        connection.execute(
            text(
                """
                UPDATE alembic_version
                SET version_num = '016_align_scheduled_audits_schema'
                WHERE version_num = '015_merge_windows_support_main'
                """
            )
        )


def verify_runtime_schema(engine) -> None:
    inspector = inspect(engine)
    tables = set(inspector.get_table_names())

    required_tables = {
        "users",
        "scheduled_reports",
        "audit_history_summaries",
        "alembic_version",
    }

    missing_tables = sorted(required_tables - tables)
    if missing_tables:
        raise RuntimeError(f"Missing required PostgreSQL tables: {', '.join(missing_tables)}")

    scheduled_audits_columns = {column["name"] for column in inspector.get_columns("scheduled_audits")}
    required_scheduled_audits_columns = {"name", "cron_schedule", "is_active", "next_run"}
    missing_schedule_columns = sorted(required_scheduled_audits_columns - scheduled_audits_columns)
    if missing_schedule_columns:
        raise RuntimeError(
            "Missing required scheduled_audits columns: " + ", ".join(missing_schedule_columns)
        )

    servers_columns = {column["name"] for column in inspector.get_columns("servers")}
    required_server_columns = {"connection_method", "execution_mode", "elevation_method"}
    missing_server_columns = sorted(required_server_columns - servers_columns)
    if missing_server_columns:
        raise RuntimeError(
            "Missing required servers columns: " + ", ".join(missing_server_columns)
        )


def main() -> int:
    database_url = normalize_database_url(read_database_url())

    if not database_url:
        print("[INFO] DATABASE_URL not set; skipping PostgreSQL runtime compatibility checks")
        return 0

    if not is_postgresql_url(database_url):
        print("[INFO] DATABASE_URL is not PostgreSQL; skipping PostgreSQL runtime compatibility checks")
        return 0

    print("[INFO] Applying PostgreSQL runtime compatibility checks")
    engine = create_engine(database_url)

    ensure_alembic_version_table(engine)
    normalize_legacy_revisions(engine)
    alembic_versions = get_alembic_versions(engine)

    if not alembic_versions and has_untracked_core_schema(engine):
        reconcile_untracked_schema(engine)
        stamp_alembic_head(database_url)
    else:
        ensure_users_table(engine)
        run_alembic_upgrade(database_url)

    enforce_runtime_schema(engine)
    verify_runtime_schema(engine)

    print("[OK] PostgreSQL runtime compatibility checks passed")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"[ERROR] PostgreSQL runtime compatibility failed: {exc}")
        raise
