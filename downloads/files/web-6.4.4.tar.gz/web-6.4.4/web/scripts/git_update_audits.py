#!/usr/bin/env python3
"""
Git-Based Audit Script Updater

Updates audit scripts (Bash and PowerShell) from the Git repository.
Supports both 'git pull' for full update and sparse checkout for audits-only.

Author: Security Audit Toolkit
Date: March 2026
"""

import os
import shutil
import subprocess  # nosec B404
import sys
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
ROOT_DIR = Path(__file__).parent.parent.parent  # Repository root


def _sanitize_error(error_msg: str) -> str:
    """
    Sanitize error messages to prevent information disclosure.
    Removes file paths and sensitive details from git error output.

    OWASP API8:2023 - Security Misconfiguration
    """
    if not error_msg:
        return "Unknown error"

    # Remove absolute paths
    import re
    sanitized = re.sub(r'[A-Za-z]:\\[^\s]+', '[path]', error_msg)
    sanitized = re.sub(r'/[^\s]*/', '/.../', sanitized)

    # Truncate long error messages
    if len(sanitized) > 200:
        sanitized = sanitized[:200] + '...'

    return sanitized
AUDITS_DIR = ROOT_DIR / 'audits'
GIT_REMOTE = 'origin'
GIT_BRANCH = 'main'


def _resolve_executable(executable: str) -> str:
    """Resolve executable path when available."""
    resolved = shutil.which(executable)
    return resolved or executable


def _run_command(command: List[str], *, timeout: int, cwd: Optional[Path] = None,
                 text: bool = True, capture_output: bool = True):
    """Run trusted git commands with normalized executable path."""
    safe_command = list(command)
    safe_command[0] = _resolve_executable(safe_command[0])
    return subprocess.run(  # nosec B603
        safe_command,
        cwd=cwd,
        capture_output=capture_output,
        text=text,
        timeout=timeout,
    )


def check_git_available() -> bool:
    """Check if git is available in PATH"""
    try:
        result = _run_command(
            ['git', '--version'],
            timeout=10
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def get_git_status() -> Dict:
    """Get current git repository status"""
    try:
        # Get current branch
        branch_result = _run_command(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            cwd=ROOT_DIR,
            timeout=10
        )
        current_branch = branch_result.stdout.strip() if branch_result.returncode == 0 else 'unknown'

        # Get current commit hash
        commit_result = _run_command(
            ['git', 'rev-parse', '--short', 'HEAD'],
            cwd=ROOT_DIR,
            timeout=10
        )
        current_commit = commit_result.stdout.strip() if commit_result.returncode == 0 else 'unknown'

        # Get remote URL
        remote_result = _run_command(
            ['git', 'config', '--get', f'remote.{GIT_REMOTE}.url'],
            cwd=ROOT_DIR,
            timeout=10
        )
        remote_url = remote_result.stdout.strip() if remote_result.returncode == 0 else 'unknown'

        # Check for local changes
        status_result = _run_command(
            ['git', 'status', '--porcelain', '--', 'audits/'],
            cwd=ROOT_DIR,
            timeout=10
        )
        has_local_changes = bool(status_result.stdout.strip())
        local_changes = status_result.stdout.strip().split('\n') if has_local_changes else []

        return {
            'branch': current_branch,
            'commit': current_commit,
            'remote_url': remote_url,
            'has_local_changes': has_local_changes,
            'local_changes': [c for c in local_changes if c]
        }
    except Exception as e:
        logger.error(f"Error getting git status: {e}")
        return {'error': _sanitize_error(str(e))}


def fetch_updates() -> Tuple[bool, str]:
    """Fetch updates from remote without merging"""
    try:
        result = _run_command(
            ['git', 'fetch', GIT_REMOTE, GIT_BRANCH],
            cwd=ROOT_DIR,
            timeout=60
        )
        if result.returncode == 0:
            return True, "Fetched latest changes from remote"
        else:
            logger.warning(f"Git fetch failed: {result.stderr}")
            return False, "Fetch failed - check network connectivity"
    except subprocess.TimeoutExpired:
        return False, "Fetch timed out"
    except Exception as e:
        logger.error(f"Fetch error: {e}")
        return False, "Fetch error occurred"


def check_for_audit_updates() -> Dict:
    """Check if there are updates available for audit scripts"""
    try:
        # Fetch first
        fetch_success, fetch_msg = fetch_updates()
        if not fetch_success:
            return {'has_updates': False, 'error': fetch_msg}

        # Check for differences in audits folder
        result = _run_command(
            ['git', 'diff', '--name-only', f'HEAD..{GIT_REMOTE}/{GIT_BRANCH}', '--', 'audits/'],
            cwd=ROOT_DIR,
            timeout=30
        )

        if result.returncode == 0:
            changed_files = [f for f in result.stdout.strip().split('\n') if f]

            # Categorize changes
            bash_scripts = [f for f in changed_files if f.endswith('.sh')]
            ps_scripts = [f for f in changed_files if f.endswith('.ps1')]
            other_files = [f for f in changed_files if not f.endswith('.sh') and not f.endswith('.ps1')]

            return {
                'has_updates': len(changed_files) > 0,
                'total_changes': len(changed_files),
                'bash_scripts': bash_scripts,
                'powershell_scripts': ps_scripts,
                'other_files': other_files,
                'changed_files': changed_files
            }
        else:
            logger.warning(f"Git diff failed: {result.stderr}")
            return {'has_updates': False, 'error': 'Failed to check for updates'}

    except Exception as e:
        logger.error(f"Error checking for updates: {e}")
        return {'has_updates': False, 'error': 'Error checking for updates'}


def pull_audit_updates(force: bool = False) -> Dict:
    """
    Pull updates for audit scripts from Git

    Args:
        force: If True, stash local changes before pulling

    Returns:
        Dict with success status and details
    """
    result = {
        'success': False,
        'message': '',
        'updated_files': [],
        'backup_created': False,
        'timestamp': datetime.now().isoformat()
    }

    try:
        # Check git status first
        status = get_git_status()
        if 'error' in status:
            result['message'] = f"Git status error: {status['error']}"
            return result

        # Handle local changes
        if status['has_local_changes'] and not force:
            result['message'] = "Local changes detected in audits folder. Use force=True to stash and pull."
            result['local_changes'] = status['local_changes']
            return result

        # Stash local changes if force mode
        if status['has_local_changes'] and force:
            stash_result = _run_command(
                ['git', 'stash', 'push', '-m', f'Auto-stash before audit update {datetime.now().isoformat()}', '--', 'audits/'],
                cwd=ROOT_DIR,
                timeout=30
            )
            if stash_result.returncode == 0:
                result['backup_created'] = True
                logger.info("Stashed local changes")

        # Get list of files that will be updated
        check_result = check_for_audit_updates()
        if check_result.get('has_updates'):
            result['updated_files'] = check_result.get('changed_files', [])

        # Pull updates (checkout specific files from remote)
        if check_result.get('has_updates'):
            # Use checkout to get specific files from remote
            checkout_result = _run_command(
                ['git', 'checkout', f'{GIT_REMOTE}/{GIT_BRANCH}', '--', 'audits/'],
                cwd=ROOT_DIR,
                timeout=60
            )

            if checkout_result.returncode == 0:
                result['success'] = True
                result['message'] = f"Successfully updated {len(result['updated_files'])} audit files"

                # Count by type
                bash_count = len([f for f in result['updated_files'] if f.endswith('.sh')])
                ps_count = len([f for f in result['updated_files'] if f.endswith('.ps1')])
                result['bash_scripts_updated'] = bash_count
                result['powershell_scripts_updated'] = ps_count

                logger.info(f"Updated {bash_count} Bash scripts and {ps_count} PowerShell scripts")
            else:
                result['message'] = f"Checkout failed: {checkout_result.stderr}"
        else:
            result['success'] = True
            result['message'] = "Audits are already up to date"

    except subprocess.TimeoutExpired:
        result['message'] = "Git operation timed out"
    except Exception as e:
        result['message'] = f"Error: {str(e)}"
        logger.error(f"Pull error: {e}")

    return result


def full_repo_update() -> Dict:
    """
    Perform a full git pull to update the entire repository

    Returns:
        Dict with success status and details
    """
    result = {
        'success': False,
        'message': '',
        'timestamp': datetime.now().isoformat()
    }

    try:
        # Check for uncommitted changes
        status_result = _run_command(
            ['git', 'status', '--porcelain'],
            cwd=ROOT_DIR,
            timeout=10
        )

        if status_result.stdout.strip():
            result['message'] = "Cannot pull: uncommitted changes exist. Commit or stash changes first."
            result['uncommitted_files'] = status_result.stdout.strip().split('\n')
            return result

        # Perform git pull
        pull_result = _run_command(
            ['git', 'pull', GIT_REMOTE, GIT_BRANCH],
            cwd=ROOT_DIR,
            timeout=120
        )

        if pull_result.returncode == 0:
            result['success'] = True
            result['message'] = "Repository updated successfully"
            result['output'] = pull_result.stdout

            # Parse output to find updated files
            if 'Already up to date' in pull_result.stdout:
                result['message'] = "Repository is already up to date"
            else:
                # Count changed files
                lines = pull_result.stdout.split('\n')
                file_changes = [l for l in lines if '|' in l or 'create mode' in l or 'delete mode' in l]
                result['files_changed'] = len(file_changes)
        else:
            result['message'] = f"Pull failed: {pull_result.stderr}"

    except subprocess.TimeoutExpired:
        result['message'] = "Git pull timed out"
    except Exception as e:
        result['message'] = f"Error: {str(e)}"

    return result


def get_audit_file_stats() -> Dict:
    """Get statistics about current audit files"""
    stats = {
        'linux': {'bash': 0, 'total': 0, 'folders': []},
        'windows': {'powershell': 0, 'total': 0, 'folders': []}
    }

    try:
        linux_dir = AUDITS_DIR / 'linux'
        windows_dir = AUDITS_DIR / 'windows'

        if linux_dir.exists():
            for sh_file in linux_dir.rglob('*.sh'):
                stats['linux']['bash'] += 1
                stats['linux']['total'] += 1
            stats['linux']['folders'] = [d.name for d in linux_dir.iterdir() if d.is_dir()]

        if windows_dir.exists():
            for ps_file in windows_dir.rglob('*.ps1'):
                stats['windows']['powershell'] += 1
                stats['windows']['total'] += 1
            stats['windows']['folders'] = [d.name for d in windows_dir.iterdir() if d.is_dir()]

    except Exception as e:
        stats['error'] = str(e)

    return stats


def main():
    """CLI interface for audit updates"""
    import argparse

    parser = argparse.ArgumentParser(description='Update audit scripts from Git')
    parser.add_argument('--check', action='store_true', help='Check for available updates')
    parser.add_argument('--pull', action='store_true', help='Pull audit updates')
    parser.add_argument('--full', action='store_true', help='Full repository update')
    parser.add_argument('--force', action='store_true', help='Force update (stash local changes)')
    parser.add_argument('--stats', action='store_true', help='Show audit file statistics')
    parser.add_argument('--status', action='store_true', help='Show git status')
    parser.add_argument('--json', action='store_true', help='Output as JSON')

    args = parser.parse_args()

    if not check_git_available():
        print("Error: Git is not available in PATH")
        sys.exit(1)

    output = {}

    if args.status:
        output = get_git_status()
    elif args.stats:
        output = get_audit_file_stats()
    elif args.check:
        output = check_for_audit_updates()
    elif args.pull:
        output = pull_audit_updates(force=args.force)
    elif args.full:
        output = full_repo_update()
    else:
        # Default: show status and check for updates
        output = {
            'status': get_git_status(),
            'stats': get_audit_file_stats(),
            'updates': check_for_audit_updates()
        }

    if args.json:
        print(json.dumps(output, indent=2))
    else:
        # Pretty print
        if 'success' in output:
            status = '✓' if output['success'] else '✗'
            print(f"{status} {output.get('message', 'Complete')}")
            if output.get('updated_files'):
                print(f"\nUpdated files ({len(output['updated_files'])}):")
                for f in output['updated_files'][:20]:
                    print(f"  - {f}")
                if len(output['updated_files']) > 20:
                    print(f"  ... and {len(output['updated_files']) - 20} more")
        elif 'has_updates' in output:
            if output['has_updates']:
                print(f"Updates available: {output['total_changes']} files")
                print(f"  Bash scripts: {len(output.get('bash_scripts', []))}")
                print(f"  PowerShell scripts: {len(output.get('powershell_scripts', []))}")
            else:
                print("No updates available")
        else:
            print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
