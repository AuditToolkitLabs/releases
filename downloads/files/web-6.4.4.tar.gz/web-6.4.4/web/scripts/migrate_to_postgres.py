#!/usr/bin/env python3
"""
SQLite to PostgreSQL Migration Script

Migrates data from SQLite database to PostgreSQL while preserving all data.
Handles schema creation, data transfer, and validation.

Usage:
    python3 web/scripts/migrate_to_postgres.py \\
        --source sqlite:///audit_toolkit.db \\
        --target postgresql://user:pass@localhost/audit_toolkit

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import argparse
import sys
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.resolve()))

from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import sessionmaker
from datetime import datetime

# Import models
from models.database import Base, Server, Audit, AuditExecution, ScheduledAudit


def validate_database_url(url: str, db_type: str) -> bool:
    """Validate database URL format"""
    if db_type == "source" and not url.startswith("sqlite:"):
        print(f"❌ Error: Source database must be SQLite (got: {url})")
        return False
    if db_type == "target" and not url.startswith("postgresql"):
        print(f"❌ Error: Target database must be PostgreSQL (got: {url})")
        return False
    return True


def test_connection(engine, db_name: str) -> bool:
    """Test database connection"""
    try:
        with engine.connect() as conn:
            conn.execute("SELECT 1")
        print(f"✓ Connected to {db_name}")
        return True
    except Exception as e:
        print(f"❌ Failed to connect to {db_name}: {e}")
        return False


def get_table_count(session, model) -> int:
    """Get row count for a table"""
    try:
        return session.query(model).count()
    except Exception:
        return 0


def migrate_data(source_url: str, target_url: str, skip_validation: bool = False):
    """Migrate data from SQLite to PostgreSQL"""

    print("\n" + "="*70)
    print("  SQLite → PostgreSQL Migration")
    print("="*70 + "\n")

    # Validate URLs
    if not validate_database_url(source_url, "source"):
        sys.exit(1)
    if not validate_database_url(target_url, "target"):
        sys.exit(1)

    # Create engines
    print("📡 Connecting to databases...")
    source_engine = create_engine(source_url)
    target_engine = create_engine(target_url)

    # Test connections
    if not test_connection(source_engine, "source SQLite"):
        sys.exit(1)
    if not test_connection(target_engine, "target PostgreSQL"):
        sys.exit(1)

    # Check if source database has tables
    inspector = inspect(source_engine)
    source_tables = inspector.get_table_names()

    if not source_tables:
        print("\n⚠️  Warning: Source database has no tables. Nothing to migrate.")
        sys.exit(0)

    print(f"\n✓ Source database has {len(source_tables)} tables: {', '.join(source_tables)}")

    # Create target schema
    print("\n📋 Creating target schema...")
    Base.metadata.create_all(target_engine)
    print("✓ Target schema created")

    # Create sessions
    SourceSession = sessionmaker(bind=source_engine)
    TargetSession = sessionmaker(bind=target_engine)

    source_session = SourceSession()
    target_session = TargetSession()

    # Migration statistics
    stats = {
        'servers': {'source': 0, 'migrated': 0, 'errors': 0},
        'audits': {'source': 0, 'migrated': 0, 'errors': 0},
        'audit_executions': {'source': 0, 'migrated': 0, 'errors': 0},
        'scheduled_audits': {'source': 0, 'migrated': 0, 'errors': 0}
    }

    try:
        # Migrate servers
        print("\n📊 Migrating data...")
        print("-" * 70)

        # 1. Servers
        if 'servers' in source_tables:
            servers = source_session.query(Server).all()
            stats['servers']['source'] = len(servers)
            print(f"\n[1/4] Servers: {len(servers)} records")

            for server in servers:
                try:
                    # Create new instance (don't copy ID - let PostgreSQL auto-generate)
                    new_server = Server(
                        name=server.name,
                        hostname=server.hostname,
                        port=server.port,
                        username=server.username,
                        password=server.password,
                        ssh_key_path=server.ssh_key_path,
                        description=server.description,
                        tags=server.tags,
                        created_at=server.created_at,
                        updated_at=server.updated_at,
                        last_audit_at=server.last_audit_at
                    )
                    target_session.add(new_server)
                    stats['servers']['migrated'] += 1
                except Exception as e:
                    print(f"  ⚠️  Error migrating server '{server.name}': {e}")
                    stats['servers']['errors'] += 1

            target_session.commit()
            print(f"  ✓ Migrated {stats['servers']['migrated']}/{stats['servers']['source']} servers")

        # 2. Audits
        if 'audits' in source_tables:
            audits = source_session.query(Audit).all()
            stats['audits']['source'] = len(audits)
            print(f"\n[2/4] Audits: {len(audits)} records")

            for audit in audits:
                try:
                    new_audit = Audit(
                        name=audit.name,
                        domain=audit.domain,
                        category=audit.category,
                        file_path=audit.file_path,
                        description=audit.description,
                        created_at=audit.created_at,
                        updated_at=audit.updated_at
                    )
                    target_session.add(new_audit)
                    stats['audits']['migrated'] += 1
                except Exception as e:
                    print(f"  ⚠️  Error migrating audit '{audit.name}': {e}")
                    stats['audits']['errors'] += 1

            target_session.commit()
            print(f"  ✓ Migrated {stats['audits']['migrated']}/{stats['audits']['source']} audits")

        # 3. Audit Executions
        if 'audit_executions' in source_tables:
            executions = source_session.query(AuditExecution).all()
            stats['audit_executions']['source'] = len(executions)
            print(f"\n[3/4] Audit Executions: {len(executions)} records")

            # Build server/audit ID mappings
            server_map = {}
            for old_server, new_server in zip(
                source_session.query(Server).all(),
                target_session.query(Server).all()
            ):
                server_map[old_server.id] = new_server.id

            audit_map = {}
            for old_audit, new_audit in zip(
                source_session.query(Audit).all(),
                target_session.query(Audit).all()
            ):
                audit_map[old_audit.id] = new_audit.id

            for execution in executions:
                try:
                    new_execution = AuditExecution(
                        server_id=server_map.get(execution.server_id, execution.server_id),
                        audit_id=audit_map.get(execution.audit_id, execution.audit_id),
                        status=execution.status,
                        exit_code=execution.exit_code,
                        output=execution.output,
                        summary=execution.summary,
                        duration_seconds=execution.duration_seconds,
                        executed_by=execution.executed_by,
                        executed_at=execution.executed_at,
                        completed_at=execution.completed_at
                    )
                    target_session.add(new_execution)
                    stats['audit_executions']['migrated'] += 1
                except Exception as e:
                    print(f"  ⚠️  Error migrating execution ID {execution.id}: {e}")
                    stats['audit_executions']['errors'] += 1

            target_session.commit()
            print(f"  ✓ Migrated {stats['audit_executions']['migrated']}/{stats['audit_executions']['source']} executions")

        # 4. Scheduled Audits
        if 'scheduled_audits' in source_tables:
            schedules = source_session.query(ScheduledAudit).all()
            stats['scheduled_audits']['source'] = len(schedules)
            print(f"\n[4/4] Scheduled Audits: {len(schedules)} records")

            for schedule in schedules:
                try:
                    new_schedule = ScheduledAudit(
                        server_id=server_map.get(schedule.server_id, schedule.server_id),
                        audit_id=audit_map.get(schedule.audit_id, schedule.audit_id) if schedule.audit_id else None,
                        schedule_cron=schedule.schedule_cron,
                        enabled=schedule.enabled,
                        last_run_at=schedule.last_run_at,
                        next_run_at=schedule.next_run_at,
                        created_at=schedule.created_at,
                        updated_at=schedule.updated_at
                    )
                    target_session.add(new_schedule)
                    stats['scheduled_audits']['migrated'] += 1
                except Exception as e:
                    print(f"  ⚠️  Error migrating schedule ID {schedule.id}: {e}")
                    stats['scheduled_audits']['errors'] += 1

            target_session.commit()
            print(f"  ✓ Migrated {stats['scheduled_audits']['migrated']}/{stats['scheduled_audits']['source']} schedules")

        # Validation
        if not skip_validation:
            print("\n🔍 Validating migration...")
            print("-" * 70)

            validation_pass = True
            for table_name, table_stats in stats.items():
                target_count = get_table_count(target_session, globals()[table_name.title().replace('_', '')])
                expected = table_stats['migrated']

                if target_count == expected:
                    print(f"  ✓ {table_name}: {target_count} records")
                else:
                    print(f"  ❌ {table_name}: Expected {expected}, found {target_count}")
                    validation_pass = False

            if not validation_pass:
                print("\n⚠️  Validation failed! Review errors above.")
                sys.exit(1)

        # Summary
        print("\n" + "="*70)
        print("  Migration Summary")
        print("="*70)
        total_migrated = sum(s['migrated'] for s in stats.values())
        total_errors = sum(s['errors'] for s in stats.values())

        for table, table_stats in stats.items():
            if table_stats['source'] > 0:
                print(f"  {table:20s}: {table_stats['migrated']:4d} / {table_stats['source']:4d} migrated", end="")
                if table_stats['errors'] > 0:
                    print(f" ({table_stats['errors']} errors)")
                else:
                    print()

        print(f"\n  {'Total':20s}: {total_migrated:4d} records migrated")
        if total_errors > 0:
            print(f"  {'Errors':20s}: {total_errors:4d} errors")
        print("="*70)

        if total_errors == 0:
            print("\n✅ Migration completed successfully!")
        else:
            print(f"\n⚠️  Migration completed with {total_errors} errors. Review logs above.")

    except Exception as e:
        print(f"\n❌ Migration failed: {e}")
        target_session.rollback()
        sys.exit(1)
    finally:
        source_session.close()
        target_session.close()


def main():
    parser = argparse.ArgumentParser(
        description="Migrate Security Audit Toolkit data from SQLite to PostgreSQL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Migrate local SQLite to local PostgreSQL
  python3 web/scripts/migrate_to_postgres.py \\
    --source sqlite:///audit_toolkit.db \\
    --target postgresql://user:pass@localhost/audit_toolkit

  # Migrate to remote PostgreSQL
  python3 web/scripts/migrate_to_postgres.py \\
    --source sqlite:///audit_toolkit.db \\
    --target postgresql://user:pass@db.example.com:5432/audit_toolkit

  # Skip validation (faster for large datasets)
  python3 web/scripts/migrate_to_postgres.py \\
    --source sqlite:///audit_toolkit.db \\
    --target postgresql://user:pass@localhost/audit_toolkit \\
    --skip-validation
        """
    )

    parser.add_argument(
        '--source',
        required=True,
        help='Source SQLite database URL (e.g., sqlite:///audit_toolkit.db)'
    )

    parser.add_argument(
        '--target',
        required=True,
        help='Target PostgreSQL database URL (e.g., postgresql://user:pass@host/db)'
    )

    parser.add_argument(
        '--skip-validation',
        action='store_true',
        help='Skip post-migration validation (faster for large datasets)'
    )

    args = parser.parse_args()

    # Confirm before proceeding
    print("\n⚠️  WARNING: This will copy data from SQLite to PostgreSQL.")
    print(f"  Source: {args.source}")
    print(f"  Target: {args.target}")
    print("\nThis will NOT delete the source database.")
    print("The target database will be created/overwritten.")

    response = input("\nContinue? [y/N]: ")
    if response.lower() != 'y':
        print("Migration cancelled.")
        sys.exit(0)

    migrate_data(args.source, args.target, args.skip_validation)


if __name__ == '__main__':
    main()
