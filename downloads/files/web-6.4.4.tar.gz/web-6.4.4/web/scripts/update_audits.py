import os
import shutil
import requests
import zipfile
from pathlib import Path

# Configuration
AUDITS_DIR = Path(__file__).parent.parent / 'audits'
BACKUP_DIR = Path(__file__).parent.parent / 'audits_backup'
UPDATE_URL = 'https://your-repo-url.com/latest_audits.zip'  # Replace with actual URL
DEFAULT_TIMEOUT = 30  # seconds


def backup_audits():
    if AUDITS_DIR.exists():
        if BACKUP_DIR.exists():
            shutil.rmtree(BACKUP_DIR)
        shutil.copytree(AUDITS_DIR, BACKUP_DIR)
        print(f"Backed up audits to {BACKUP_DIR}")


def download_update():
    print(f"Downloading update from {UPDATE_URL}")
    response = requests.get(UPDATE_URL, timeout=DEFAULT_TIMEOUT)
    zip_path = Path(__file__).parent / 'latest_audits.zip'
    with open(zip_path, 'wb') as f:
        f.write(response.content)
    return zip_path


def apply_update(zip_path):
    print(f"Extracting {zip_path} to {AUDITS_DIR}")
    if AUDITS_DIR.exists():
        shutil.rmtree(AUDITS_DIR)
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(AUDITS_DIR)
    print("Update applied.")


def main():
    backup_audits()
    zip_path = download_update()
    apply_update(zip_path)
    print("Audit scripts updated successfully.")

if __name__ == '__main__':
    main()
