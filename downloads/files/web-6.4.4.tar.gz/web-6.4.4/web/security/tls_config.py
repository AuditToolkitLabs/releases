#!/usr/bin/env python3
"""
TLS Configuration Module

Provides SSL context builders for different communication tiers.
Implements Phase 1: Configuration knobs without enforcement changes.

Phase 1: Config only (this module)
Phase 2+: Actual TLS enforcement (future release)

Usage:
    from web.security.tls_config import get_tls_context_for_tier

    # Create context for toolkit↔agent communication
    context = get_tls_context_for_tier('toolkit', verify_cert=True)

    # Create context for external APIs
    context = get_tls_context_for_tier('external', verify_cert=True)
"""

import ssl
import logging
from typing import Optional
from security_settings import get_security_setting

logger = logging.getLogger(__name__)


def get_tls_version_enum(version_str: str) -> ssl.TLSVersion:
    """
    Convert string TLS version to ssl.TLSVersion enum.

    Args:
        version_str: String like 'TLSv1_2' or 'TLSv1_3'

    Returns:
        ssl.TLSVersion enum value
    """
    version_map = {
        'TLSv1_1': ssl.TLSVersion.TLSv1_1,
        'TLSv1_2': ssl.TLSVersion.TLSv1_2,
        'TLSv1_3': ssl.TLSVersion.TLSv1_3,
    }
    return version_map.get(version_str, ssl.TLSVersion.TLSv1_2)


def get_tls_context_for_tier(
    tier: str = 'external',
    verify_cert: bool = True,
    check_hostname: bool = True
) -> ssl.SSLContext:
    """
    Create an SSL context configured for the specified communication tier.

    Phase 1: Returns contexts with correct TLS settings from security_settings.
    Phase 2+: Will actively enforce minimum TLS versions.

    Args:
        tier: 'toolkit' (agent API) or 'external' (hypervisor, S3, SMTP, etc.)
        verify_cert: Whether to verify server certificate
        check_hostname: Whether to check hostname matches certificate

    Returns:
        ssl.SSLContext configured for the tier
    """
    if not verify_cert:
        # Unverified context (not recommended, but sometimes needed)
        # Build explicitly instead of using ssl._create_unverified_context().
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        return context

    # Standard verified context
    context = ssl.create_default_context()

    # Load TLS settings from security_settings
    if tier == 'toolkit':
        # Toolkit↔Agent: TLS 1.3-only (internal communication under our control)
        min_version_str = get_security_setting('tls_minimum_version_toolkit', 'TLSv1_3')
    else:
        # External APIs: TLS 1.2+ (we don't control external systems)
        min_version_str = get_security_setting('tls_minimum_version_external', 'TLSv1_2')

    max_version_str = get_security_setting('tls_maximum_version', 'TLSv1_3')
    cipher_suites_str = get_security_setting(
        'tls_cipher_suites',
        'ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!DSS:!RC4:!DES'
    )
    strict_mode = get_security_setting('tls_strict_mode', False)

    # Set TLS version constraints
    try:
        min_version = get_tls_version_enum(min_version_str)
        max_version = get_tls_version_enum(max_version_str)

        context.minimum_version = min_version
        context.maximum_version = max_version

        logger.debug(
            f"TLS context [{tier}]: min={min_version_str}, max={max_version_str}, "
            f"verify={verify_cert}, hostname_check={check_hostname}"
        )
    except Exception as e:
        logger.warning(f"Error setting TLS versions: {e}, using defaults")

    # Set cipher suites if supported
    try:
        if cipher_suites_str:
            context.set_ciphers(cipher_suites_str)
            logger.debug(f"TLS ciphers set for [{tier}]: {cipher_suites_str}")
    except ssl.SSLError as e:
        logger.warning(f"Could not set cipher suites: {e}")

    # Configure certificate verification
    context.check_hostname = check_hostname
    context.verify_mode = ssl.CERT_REQUIRED if verify_cert else ssl.CERT_NONE

    logger.debug(f"Created TLS context for tier '{tier}' (strict_mode={strict_mode})")

    return context


def log_tls_connection(
    tier: str,
    target: str,
    tls_version: Optional[str] = None,
    cipher: Optional[str] = None,
    protocol: str = 'unknown'
) -> None:
    """
    Log TLS connection details for audit trail and troubleshooting.

    Args:
        tier: Communication tier ('toolkit', 'external', 'audit')
        target: Target server/service (e.g., 'hypervisor.example.com:443')
        tls_version: TLS version string (e.g., 'TLSv1.3')
        cipher: Cipher suite used
        protocol: Protocol used (https, rest, ssh, etc.)
    """
    if get_security_setting('tls_log_version', True):
        logger.info(
            f"TLS connection: tier={tier}, target={target}, "
            f"protocol={protocol}, version={tls_version}, cipher={cipher}"
        )
