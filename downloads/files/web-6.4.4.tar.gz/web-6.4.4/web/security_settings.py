#!/usr/bin/env python3
"""
Security Settings Loader

Provides cached access to security settings from settings/security_settings.json.
Settings are cached for 30 seconds to balance responsiveness with disk I/O.

Usage:
    from security_settings import get_security_setting, get_all_security_settings

    # Get single setting with default
    min_length = get_security_setting('password_min_length', 12)

    # Get all settings
    settings = get_all_security_settings()
"""

import json
import time
import logging
from pathlib import Path
from threading import Lock

logger = logging.getLogger(__name__)

# Determine ROOT_DIR relative to this file
ROOT_DIR = Path(__file__).parent.parent

# Cache configuration
_settings_cache = None
_cache_timestamp = 0
_cache_lock = Lock()
CACHE_TTL = 30  # seconds


def get_default_security_settings():
    """Return default security settings (must match admin_routes.py)"""
    return {
        # Authentication & Access
        'session_timeout': 30,
        'max_login_attempts': 5,
        'lockout_duration': 15,
        'enforce_2fa': False,

        # Password Policy
        'password_min_length': 12,  # nosec B105
        'password_uppercase': True,  # nosec B105
        'password_numbers': True,  # nosec B105
        'password_special': True,  # nosec B105
        'password_expiry': 90,  # nosec B105
        'password_history': 5,  # nosec B105

        # Audit Execution
        'audit_timeout': 300,
        'result_retention': 90,
        'result_retention_max_records': 100000,
        'hypervisor_result_retention_days': 90,
        'hypervisor_result_retention_max_records': 100000,
        'report_artifact_retention_days': 90,
        'report_artifact_max_files': 10000,
        'history_summary_retention_days': 365,
        'compliance_history_retention_days': 365,
        'evidence_retention_enabled': True,   # Enforce evidence export retention policy
        'evidence_retention_days': 30,         # Days to keep evidence export ZIPs (min 1)
        'cleanup_old_executions_enabled': True,
        'cleanup_old_executions_interval_minutes': 1440,
        'cleanup_analytics_history_enabled': True,
        'cleanup_analytics_history_interval_minutes': 1440,
        'postgres_maintenance_enabled': True,
        'postgres_maintenance_vacuum_analyze_enabled': True,
        'postgres_maintenance_interval_minutes': 360,
        'postgres_database_size_warn_mb': 10240,
        'postgres_database_size_critical_mb': 20480,
        'postgres_table_size_warn_mb': 2048,

        # User Management Defaults
        'default_role': 'Viewer',
        'auto_approve_users': False,
        'self_registration': False,
        'max_users': 0,

        # Maintenance
        'maintenance_mode': False,
        'maintenance_message': '',

        # Network & Security
        'ip_whitelist': '',
        'ip_blacklist': '',
        'enforce_https': False,

        # Log Retention
        'log_max_bytes': 20971520,        # 20 MB per log file before rotation
        'log_backup_count': 14,           # Rotated log files to keep
        'log_rotation_when': 'midnight',  # Rotation schedule: midnight | h | d | w0
        'log_rotation_interval': 1,       # Interval units (used with log_rotation_when)
        'execution_log_retention_days': 14,   # Days to keep per-execution log files
        'execution_log_max_files': 14,    # Max per-execution log files retained

        # Advanced (Restart Required)
        'rate_limit': 100,
        'max_concurrent_audits': 5,
        'worker_pool_size': 4,
        'analytics_max_result_set_size': 10000,  # Absolute max records allowed per analytics query window
        'log_level': 'INFO',
        'cors_origins': '',

        # Backup Configuration
        'backup_retention_days': 30,
        'backup_keep_count': 10,
        'backup_compress': True,
        'backup_encrypt': False,  # Encrypt toolkit-managed internal backups
        'backup_include_shared_data': True,  # Include mounted shared service data (asset-discovery/agents) in companion archive
        'backup_shared_data_paths': '/opt/audit-toolkit/data/agents,/opt/audit-toolkit/shared/asset-discovery-data,/opt/audit-toolkit/shared/asset-discovery-logs',
        'backup_auto_enabled': False,
        'backup_schedule': 'daily',
        'backup_max_size': 500,

        # Agent Security Configuration
        'agent_require_approval': False,  # Require admin approval for new agents
        'agent_auto_approve_known_hosts': True,  # Auto-approve if hostname matches existing
        'agent_tls_verify': True,  # Verify TLS certificates
        'agent_tls_pinning_enabled': False,  # Enable certificate pinning
        'agent_tls_pinned_cert_hash': '',  # SHA256 hash of pinned certificate
        'agent_api_key_rotation_days': 0,  # Days before API key rotation warning (0 = disabled)
        'agent_api_key_grace_period_hours': 24,  # Hours old key remains valid after rotation
        'agent_encrypt_keys_at_rest': True,  # Require encrypted key storage on agents
        'fleet_agent_enforce_signed_config': True,  # Require signed config envelopes for fleet agent config pulls (default-on)
        'fleet_agent_config_max_age_seconds': 900,  # Freshness window for config envelopes
        'fleet_agent_config_signing_key': '',  # Shared signing key for HMAC envelope compatibility path
        'fleet_agent_require_request_signatures': False,  # Require signed managed runtime requests (Phase 3)
        'fleet_agent_request_signature_max_age_seconds': 300,  # Freshness window for request signatures
        'fleet_agent_request_signing_key': '',  # HMAC signing key for managed runtime request verification
        'fleet_agent_request_signature_ecdsa_dual_verify_enabled': False,  # Dev-stage dual verify (accept HMAC or ECDSA)
        'fleet_agent_request_signature_ecdsa_public_key': '',  # PEM public key for ECDSA verification

        # Fleet Agent Result Encryption (Phase 2)
        'fleet_agent_result_encryption_enabled': False,  # Encrypt results at rest using Fernet AES-128
        'fleet_agent_result_encryption_algorithm': 'fernet-aes128',  # Algorithm (fernet-aes128)
        'fleet_agent_result_encryption_key_derivation': 'agent_id',  # Key derivation: agent_id, shared, custom
        'fleet_agent_results_encryption_key_custom': '',  # Custom key (base64) if using custom derivation

        # Global SSH Host Key Policy
        'ssh_host_key_policy': 'warn',  # strict, warn, auto

        # Hypervisor Agent Key Validity (lifetime before expiry)
        'hypervisor_key_validity_days': 90,  # Default validity period in days (30, 90, 180, 365, 0=never)
        'hypervisor_key_validity_options': [30, 90, 180, 365, 0],  # Available validity options (0=never expires)
        'hypervisor_key_expiry_warning_days': 14,  # Warn this many days before expiry

        # Agent Throttle Configuration (Global Defaults)
        'agent_cpu_nice_level': 19,  # Linux: -20 to 19 (19 = lowest priority)
        'agent_process_priority': 'Idle',  # Windows: Idle, BelowNormal, Normal, AboveNormal, High
        'agent_io_class': 'idle',  # Linux ionice: realtime, best-effort, idle
        'agent_min_free_memory_pct': 10,  # Don't run audits if below this %
        'agent_upload_rate_limit': 0,  # bytes/sec (0 = unlimited)
        'agent_download_rate_limit': 0,  # bytes/sec (0 = unlimited)
        'agent_max_concurrent_audits': 1,  # Max parallel audits on agent
        'agent_audit_timeout': 3600,  # Max seconds per audit
        'agent_command_batch_size': 5,  # Max commands per poll
        'agent_batch_delay': 5,  # Seconds between commands
        'agent_max_load_average': 0,  # 0 = disabled (Linux)
        'agent_max_cpu_pct': 0,  # 0 = disabled (Windows)
        'agent_heartbeat_interval': 30,  # Min seconds between heartbeats
        'agent_poll_interval': 60,  # Seconds between command polls
        'agent_local_result_max_files': 1000,  # Max local result files retained on each fleet agent (0 = unlimited)
        'agent_local_min_free_disk_mb': 512,  # Min free disk MB required for local agent writes
        'agent_local_min_free_disk_pct': 3,  # Min free disk % required for local agent writes

        # Agent Result Storage Limits (Core host)
        'standalone_agent_result_max_files_per_host': 5000,  # Max standalone agent result files per host (0 = unlimited)
        'fleet_agent_result_max_files_per_host': 5000,  # Max fleet-agent fallback result files per host (0 = unlimited)

        # Agent Result Ingestion Capacity Limits
        'agent_result_ingest_max_body_kb': 2048,  # Max request body size in KB for agent result ingestion
        'agent_result_ingest_max_results_per_request': 100,  # Max results[] items per managed ingest request
        'agent_result_ingest_max_checks_per_result': 500,  # Max checks[] items per single result payload
        'agent_result_ingest_max_output_chars': 200000,  # Max output field length per result
        'agent_result_ingest_disk_guard_enabled': True,  # Block ingest when free disk watermark is breached
        'agent_result_ingest_min_free_disk_mb': 1024,  # Minimum required free disk space in MB
        'agent_result_ingest_min_free_disk_pct': 5,  # Minimum required free disk percentage
        'agent_discovery_ingest_max_body_kb': 2048,  # Max request body size in KB for hypervisor discovery ingest
        'agent_discovery_ingest_max_items_per_collection': 5000,  # Max items allowed per discovery collection (vms/containers/storage/networks)
        'agent_discovery_ingest_max_total_items': 20000,  # Max combined items across all discovery collections

        # SSH Key Authentication (Preferred over password)
        'ssh_default_key_name': 'audit-toolkit',  # Default key name to use/generate
        'ssh_prefer_key_auth': True,  # Prefer SSH key auth over password when available
        'ssh_key_deploy_backup': True,  # Backup existing authorized_keys before deploying

        # TLS/SSL Configuration (Phase 1: Config knobs only)
        'tls_minimum_version_toolkit': 'TLSv1_3',  # Toolkit↔Agent: TLS 1.3-only (enforced)
        'tls_minimum_version_external': 'TLSv1_2',  # External APIs (hypervisors, S3, SMTP): TLS 1.2+
        'tls_maximum_version': 'TLSv1_3',  # Always use latest (currently 1.3)
        'tls_cipher_suites': 'ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!DSS:!RC4:!DES',  # Hardened ciphers
        'tls_certificate_verification': True,  # Verify server certificates
        'tls_strict_mode': False,  # Enforce TLS minimum on internal Toolkit↔Agent channels
        'tls_log_version': True,  # Log TLS version used for each connection

        # Server certificate lifecycle metadata (managed via SuperAdmin Certificate Management)
        'server_tls_certificate_source': 'self_signed',
        'server_tls_certificate_last_updated': '',
        'server_tls_certificate_subject': '',
        'server_tls_certificate_issuer': '',
        'server_tls_certificate_not_before': '',
        'server_tls_certificate_not_after': '',
        'server_tls_certificate_fingerprint_sha256': '',
        'server_tls_certificate_chain_installed': False,
        'server_tls_runtime_apply_status': '',
        'server_tls_runtime_apply_message': '',
        'server_tls_runtime_last_attempt_at': '',
    }


def _load_settings_from_file():
    """Load settings from JSON file, return defaults on error"""
    settings_file = ROOT_DIR / 'settings' / 'security_settings.json'

    try:
        if settings_file.exists():
            with open(settings_file, 'r') as f:
                file_settings = json.load(f)
            # Merge with defaults to ensure all keys exist
            defaults = get_default_security_settings()
            defaults.update(file_settings)
            return defaults
    except Exception as e:
        logger.warning(f"Error loading security settings: {e}")

    return get_default_security_settings()


def save_security_settings(settings):
    """
    Save security settings to JSON file.

    Args:
        settings: dict of settings to save

    Returns:
        bool: True if saved successfully
    """
    settings_file = ROOT_DIR / 'settings' / 'security_settings.json'

    try:
        # Ensure settings directory exists
        settings_file.parent.mkdir(parents=True, exist_ok=True)

        # Write settings to file
        with open(settings_file, 'w') as f:
            json.dump(settings, f, indent=2, default=str)

        # Invalidate cache so next read picks up changes
        invalidate_cache()

        logger.info("Security settings saved successfully")
        return True

    except Exception as e:
        logger.error(f"Error saving security settings: {e}")
        return False


def get_all_security_settings():
    """
    Get all security settings with caching.

    Returns:
        dict: All security settings
    """
    global _settings_cache, _cache_timestamp

    current_time = time.time()

    # Check if cache is valid
    with _cache_lock:
        if _settings_cache is not None and (current_time - _cache_timestamp) < CACHE_TTL:
            return _settings_cache.copy()

        # Reload from file
        _settings_cache = _load_settings_from_file()
        _cache_timestamp = current_time
        return _settings_cache.copy()


def get_security_setting(key, default=None):
    """
    Get a single security setting with caching.

    Args:
        key: Setting name (e.g., 'password_min_length')
        default: Default value if key not found

    Returns:
        Setting value or default
    """
    settings = get_all_security_settings()
    return settings.get(key, default)


def invalidate_cache():
    """Force cache refresh on next access"""
    global _settings_cache, _cache_timestamp
    with _cache_lock:
        _settings_cache = None
        _cache_timestamp = 0


# Convenience functions for common setting groups
def get_password_policy():
    """Get password policy settings as a dict"""
    settings = get_all_security_settings()
    return {
        'min_length': settings.get('password_min_length', 12),
        'require_uppercase': settings.get('password_uppercase', True),
        'require_numbers': settings.get('password_numbers', True),
        'require_special': settings.get('password_special', True),
        'expiry_days': settings.get('password_expiry', 90),
        'history_count': settings.get('password_history', 5),
    }


def get_login_security():
    """Get login security settings as a dict"""
    settings = get_all_security_settings()
    return {
        'max_attempts': settings.get('max_login_attempts', 5),
        'lockout_minutes': settings.get('lockout_duration', 15),
        'session_timeout_minutes': settings.get('session_timeout', 30),
        'enforce_2fa': settings.get('enforce_2fa', False),
    }


def get_authentication_settings():
    """Get authentication settings (alias for get_login_security)"""
    return get_login_security()


def get_audit_execution_settings():
    """Get audit execution settings as a dict"""
    settings = get_all_security_settings()
    return {
        'audit_timeout': settings.get('audit_timeout', 300),
        'retention_days': settings.get('result_retention', 90),
        'max_records': settings.get('result_retention_max_records', 100000),
        'hypervisor_retention_days': settings.get('hypervisor_result_retention_days', settings.get('result_retention', 90)),
        'hypervisor_max_records': settings.get('hypervisor_result_retention_max_records', settings.get('result_retention_max_records', 100000)),
    }


def get_user_management_settings():
    """Get user management settings as a dict"""
    settings = get_all_security_settings()
    return {
        'default_role': settings.get('default_role', 'Viewer'),
        'auto_approve': settings.get('auto_approve_users', False),
        'self_registration': settings.get('self_registration', False),
        'max_users': settings.get('max_users', 0),
    }


def get_network_settings():
    """Get network security settings as a dict"""
    settings = get_all_security_settings()
    ip_whitelist_raw = settings.get('ip_whitelist', '')
    ip_blacklist_raw = settings.get('ip_blacklist', '')
    # Parse IP whitelist - can be comma or newline separated
    whitelist = []
    if ip_whitelist_raw:
        for ip in ip_whitelist_raw.replace('\n', ',').split(','):
            ip = ip.strip()
            if ip:
                whitelist.append(ip)

    # Parse IP blacklist - can be comma or newline separated
    blacklist = []
    if ip_blacklist_raw:
        for ip in ip_blacklist_raw.replace('\n', ',').split(','):
            ip = ip.strip()
            if ip:
                blacklist.append(ip)

    return {
        'ip_whitelist': whitelist,
        'ip_blacklist': blacklist,
        'enforce_https': settings.get('enforce_https', False),
    }


def is_ip_allowed(client_ip: str) -> bool:
    """
    Check if client IP is allowed based on IP whitelist.

    Returns True if:
    - Whitelist is empty (all IPs allowed)
    - Client IP matches an entry in the whitelist
    - Client IP matches a CIDR range in the whitelist
    """
    import ipaddress

    network_settings = get_network_settings()
    whitelist = network_settings['ip_whitelist']

    # Empty whitelist = allow all
    if not whitelist:
        return True

    try:
        client = ipaddress.ip_address(client_ip)
    except ValueError:
        # Invalid IP format - deny
        return False

    for entry in whitelist:
        try:
            if '/' in entry:
                # CIDR notation
                network = ipaddress.ip_network(entry, strict=False)
                if client in network:
                    return True
            else:
                # Single IP
                if ipaddress.ip_address(entry) == client:
                    return True
        except ValueError:
            # Skip invalid entries
            continue

    return False


def is_ip_blocked(client_ip: str) -> bool:
    """
    Check if client IP is blocked based on IP blacklist.

    Returns True if:
    - Client IP matches an entry in the blacklist
    - Client IP matches a CIDR range in the blacklist
    """
    import ipaddress

    network_settings = get_network_settings()
    blacklist = network_settings['ip_blacklist']

    # Empty blacklist = block none
    if not blacklist:
        return False

    try:
        client = ipaddress.ip_address(client_ip)
    except ValueError:
        # Invalid IP format - treat as blocked
        return True

    for entry in blacklist:
        try:
            if '/' in entry:
                # CIDR notation
                network = ipaddress.ip_network(entry, strict=False)
                if client in network:
                    return True
            else:
                # Single IP
                if ipaddress.ip_address(entry) == client:
                    return True
        except ValueError:
            # Skip invalid entries
            continue

    return False


def get_log_retention_settings():
    """Get log retention settings as a dict"""
    settings = get_all_security_settings()
    return {
        'log_max_bytes': int(settings.get('log_max_bytes', 20971520)),
        'log_backup_count': int(settings.get('log_backup_count', 14)),
        'log_rotation_when': str(settings.get('log_rotation_when', 'midnight')),
        'log_rotation_interval': int(settings.get('log_rotation_interval', 1)),
        'execution_log_retention_days': int(settings.get('execution_log_retention_days', 14)),
        'execution_log_max_files': int(settings.get('execution_log_max_files', 14)),
    }


def is_maintenance_mode():
    """Check if maintenance mode is enabled"""
    return get_security_setting('maintenance_mode', False)


def get_maintenance_message():
    """Get maintenance message"""
    return get_security_setting('maintenance_message', 'System is under maintenance')


__all__ = [
    'get_security_setting',
    'get_all_security_settings',
    'get_default_security_settings',
    'invalidate_cache',
    'get_password_policy',
    'get_login_security',
    'get_audit_execution_settings',
    'get_user_management_settings',
    'get_network_settings',
    'is_ip_allowed',
    'is_ip_blocked',
    'is_maintenance_mode',
    'get_maintenance_message',
    'get_log_retention_settings',
]
