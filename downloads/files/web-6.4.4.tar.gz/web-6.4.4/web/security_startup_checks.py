#!/usr/bin/env python3
"""Startup security checks for application bootstrapping."""

import os
from typing import Dict, List, Tuple

from sqlalchemy import MetaData, Table, bindparam, inspect, or_, select

# Table/column format expectations for credential-at-rest values.
# - DB EncryptedField values are expected to be prefixed with `enc:v1:`.
# - Legacy Fernet-encrypted text values are expected to start with `gAAAA`.
_SENSITIVE_STORAGE_RULES: List[Tuple[str, str, Tuple[str, ...]]] = [
    ('servers', 'password', ('enc:v1:',)),
    ('hypervisors', 'password', ('enc:v1:',)),
    ('hypervisors', 'api_token', ('enc:v1:',)),
    ('managed_agents', 'registration_token', ('enc:v1:',)),
    ('users', 'mfa_secret', ('enc:v1:',)),
    ('cve_settings', 'nvd_api_key', ('enc:v1:',)),
    ('terminal_connection_profiles', 'password_encrypted', ('gAAAA', 'enc:v1:')),
    ('terminal_connection_profiles', 'ssh_key_encrypted', ('gAAAA', 'enc:v1:')),
    ('scan_credentials', 'encrypted_password', ('gAAAA', 'enc:v1:')),
    ('scan_credentials', 'encrypted_private_key', ('gAAAA', 'enc:v1:')),
]


def db_encryption_strict_enabled() -> bool:
    strict = os.environ.get('DB_ENCRYPTION_STRICT', 'false')
    return strict.strip().lower() in ('1', 'true', 'yes', 'on')


def _existing_table_columns(engine) -> Dict[str, set]:
    inspector = inspect(engine)
    table_columns: Dict[str, set] = {}

    for table_name in inspector.get_table_names():
        table_columns[table_name] = {column['name'] for column in inspector.get_columns(table_name)}

    return table_columns


def enforce_server_password_storage_format(engine, logger=None):
    """Fail startup if strict mode finds credentials not stored in approved encrypted formats."""
    if not db_encryption_strict_enabled() or engine is None:
        return

    table_columns = _existing_table_columns(engine)
    violations = []

    with engine.connect() as conn:
        for table_name, column_name, allowed_prefixes in _SENSITIVE_STORAGE_RULES:
            if table_name not in table_columns or column_name not in table_columns[table_name]:
                continue

            params = {}
            allowed_conditions = []
            for idx, prefix in enumerate(allowed_prefixes):
                key = f'prefix_{idx}'
                params[key] = f'{prefix}%'
                allowed_conditions.append(bindparam(key))

            metadata = MetaData()
            table = Table(table_name, metadata, autoload_with=conn)
            column = table.c[column_name]
            like_predicates = [column.like(expr) for expr in allowed_conditions]
            invalid_rows_query = (
                select(column)
                .select_from(table)
                .where(column.is_not(None))
                .where(~or_(*like_predicates))
            )
            invalid_count = len(conn.execute(invalid_rows_query, params).fetchall())

            if invalid_count > 0:
                violations.append(
                    f'{table_name}.{column_name}={invalid_count} invalid rows '
                    f'(expected prefixes: {", ".join(allowed_prefixes)})'
                )

    if violations:
        raise RuntimeError(
            'DB encryption startup check failed: ' + '; '.join(violations)
        )

    if logger:
        logger.info('[OK] DB encryption startup check passed for all configured sensitive fields')
