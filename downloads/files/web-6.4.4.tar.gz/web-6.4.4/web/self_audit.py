#!/usr/bin/env python3
"""
Self-Audit Module for Security Audit Toolkit

Provides comprehensive self-diagnostic capabilities including:
- Version checking against GitHub releases
- Dependency security scanning (pip-audit)
- Configuration validation
- Database migration status
- Deployment health assessment
- System resource monitoring

Author: Security Audit Toolkit Team
Date: February 14, 2026
"""

import os
import sys
import json
import shutil
import subprocess  # nosec B404
import platform
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum

logger = logging.getLogger(__name__)

# Version constants
TOOLKIT_VERSION = "6.2.1"
GITHUB_REPO = "AuditToolkitLabs/Audit-Tool-"
GITHUB_API_URL = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"

# Root directory
ROOT_DIR = Path(__file__).parent.parent
AUDITS_DIR = ROOT_DIR / 'audits'
WEB_DIR = ROOT_DIR / 'web'


def _resolve_executable(executable: str) -> str:
    """Resolve executable to absolute path when available."""
    resolved = shutil.which(executable)
    return resolved or executable


def _run_command(command: List[str], *, timeout: int, cwd: Optional[str] = None,
                 text: bool = True, capture_output: bool = True, check: bool = False):
    """Run trusted toolkit subprocess commands with normalized executable path."""
    safe_command = list(command)
    safe_command[0] = _resolve_executable(safe_command[0])
    return subprocess.run(  # nosec B603
        safe_command,
        capture_output=capture_output,
        text=text,
        timeout=timeout,
        cwd=cwd,
        check=check,
    )


class SeverityLevel(Enum):
    """Severity levels for self-audit findings"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class Finding:
    """Represents a self-audit finding"""
    category: str
    title: str
    severity: str
    message: str
    recommendation: Optional[str] = None
    metadata: Optional[Dict] = None


class SelfAudit:
    """Comprehensive self-audit engine for the Security Audit Toolkit"""

    def __init__(self):
        self.findings: List[Finding] = []
        self.timestamp = datetime.utcnow().isoformat()
        self.version = TOOLKIT_VERSION

    def _add_finding(self, category: str, title: str, severity: SeverityLevel,
                     message: str, recommendation: Optional[str] = None,
                     metadata: Optional[Dict] = None):
        """Add a finding to the audit results"""
        self.findings.append(Finding(
            category=category,
            title=title,
            severity=severity.value,
            message=message,
            recommendation=recommendation,
            metadata=metadata
        ))

    # =========================================================================
    # Version Checking
    # =========================================================================

    def check_version(self) -> Dict[str, Any]:
        """
        Check current version against latest GitHub release.

        Returns:
            Dict with version comparison results
        """
        result = {
            'current_version': TOOLKIT_VERSION,
            'latest_version': None,
            'update_available': False,
            'release_url': None,
            'release_date': None,
            'checked_at': datetime.utcnow().isoformat()
        }

        try:
            import requests

            headers = {
                'Accept': 'application/vnd.github.v3+json',
                'User-Agent': f'SecurityAuditToolkit/{TOOLKIT_VERSION}'
            }

            # Check for GitHub token in environment
            github_token = os.environ.get('GITHUB_TOKEN')
            if github_token:
                headers['Authorization'] = f'token {github_token}'

            response = requests.get(GITHUB_API_URL, headers=headers, timeout=10)

            if response.status_code == 200:
                release_data = response.json()
                latest_version = release_data.get('tag_name', '').lstrip('v')

                result['latest_version'] = latest_version
                result['release_url'] = release_data.get('html_url')
                result['release_date'] = release_data.get('published_at')
                result['release_notes'] = release_data.get('body', '')[:500]  # First 500 chars

                # Compare versions
                if latest_version and latest_version != TOOLKIT_VERSION:
                    result['update_available'] = self._is_newer_version(
                        latest_version, TOOLKIT_VERSION
                    )

                if result['update_available']:
                    self._add_finding(
                        category='version',
                        title='Update Available',
                        severity=SeverityLevel.INFO,
                        message=f'New version {latest_version} is available (current: {TOOLKIT_VERSION})',
                        recommendation=f'Review release notes and update from {result["release_url"]}'
                    )
                else:
                    self._add_finding(
                        category='version',
                        title='Version Current',
                        severity=SeverityLevel.INFO,
                        message=f'Running latest version {TOOLKIT_VERSION}'
                    )

            elif response.status_code == 404:
                result['error'] = 'No releases found'
            elif response.status_code == 403:
                result['error'] = 'GitHub API rate limited. Set GITHUB_TOKEN environment variable.'
            else:
                result['error'] = f'GitHub API returned status {response.status_code}'

        except ImportError:
            result['error'] = 'requests library not available'
        except requests.exceptions.Timeout:
            result['error'] = 'GitHub API request timed out'
        except requests.exceptions.RequestException as e:
            result['error'] = f'Network error: {str(e)}'
        except Exception as e:
            result['error'] = f'Error checking version: {str(e)}'
            logger.error(f"Version check failed: {e}")

        return result

    def _is_newer_version(self, version1: str, version2: str) -> bool:
        """Compare semantic versions. Returns True if version1 > version2"""
        try:
            def parse_version(v):
                # Handle versions like "4.3.2", "4.3.2-beta", etc.
                parts = v.split('-')[0].split('.')
                return [int(p) for p in parts]

            v1_parts = parse_version(version1)
            v2_parts = parse_version(version2)

            # Pad shorter version with zeros
            max_len = max(len(v1_parts), len(v2_parts))
            v1_parts.extend([0] * (max_len - len(v1_parts)))
            v2_parts.extend([0] * (max_len - len(v2_parts)))

            return v1_parts > v2_parts
        except Exception:
            return False

    # =========================================================================
    # Dependency Security Scan
    # =========================================================================

    def scan_dependencies(self, timeout_seconds: int = 120) -> Dict[str, Any]:
        """
        Scan Python dependencies for known vulnerabilities using pip-audit.

        Returns:
            Dict with vulnerability scan results
        """
        result = {
            'scanned_at': datetime.utcnow().isoformat(),
            'total_packages': 0,
            'vulnerable_packages': 0,
            'vulnerabilities': [],
            'scan_method': None
        }

        try:
            # Try pip-audit first (most comprehensive)
            audit_result = _run_command(
                [sys.executable, '-m', 'pip_audit', '--format', 'json', '--progress-spinner', 'off'],
                timeout=timeout_seconds,
                cwd=str(WEB_DIR),
            )

            result['scan_method'] = 'pip-audit'

            if audit_result.returncode == 0 or audit_result.stdout:
                try:
                    audit_data = json.loads(audit_result.stdout)

                    # pip-audit returns list of packages
                    if isinstance(audit_data, list):
                        for pkg in audit_data:
                            result['total_packages'] += 1
                            vulns = pkg.get('vulns', [])
                            if vulns:
                                result['vulnerable_packages'] += 1
                                for vuln in vulns:
                                    vuln_info = {
                                        'package': pkg.get('name'),
                                        'installed_version': pkg.get('version'),
                                        'vulnerability_id': vuln.get('id'),
                                        'fix_versions': vuln.get('fix_versions', []),
                                        'description': vuln.get('description', '')[:200]
                                    }
                                    result['vulnerabilities'].append(vuln_info)

                                    # Add finding for each CVE
                                    self._add_finding(
                                        category='dependencies',
                                        title=f'Vulnerable Package: {pkg.get("name")}',
                                        severity=SeverityLevel.ERROR,
                                        message=f'{vuln.get("id")}: {pkg.get("name")} {pkg.get("version")}',
                                        recommendation=f'Upgrade to version {", ".join(vuln.get("fix_versions", ["latest"]))}',
                                        metadata=vuln_info
                                    )
                except json.JSONDecodeError:
                    result['error'] = 'Failed to parse pip-audit output'

            if result['vulnerable_packages'] == 0 and result['total_packages'] > 0:
                self._add_finding(
                    category='dependencies',
                    title='Dependencies Secure',
                    severity=SeverityLevel.INFO,
                    message=f'All {result["total_packages"]} packages passed security scan'
                )

        except subprocess.TimeoutExpired:
            result['error'] = 'Dependency scan timed out'
        except FileNotFoundError:
            result['scan_method'] = 'pip-audit-not-installed'
            result['error'] = 'pip-audit not installed. Install with: pip install pip-audit'
            self._add_finding(
                category='dependencies',
                title='Dependency Scanner Not Available',
                severity=SeverityLevel.WARNING,
                message='pip-audit is not installed',
                recommendation='Install pip-audit: pip install pip-audit'
            )
        except Exception as e:
            result['error'] = f'Scan failed: {str(e)}'
            logger.error(f"Dependency scan failed: {e}")

        return result

    # =========================================================================
    # Configuration Validation
    # =========================================================================

    def validate_configuration(self) -> Dict[str, Any]:
        """
        Validate application configuration and environment.

        Returns:
            Dict with configuration validation results
        """
        result = {
            'valid': True,
            'checks': [],
            'warnings': [],
            'errors': []
        }

        # Check SECRET_KEY (also accept FLASK_SECRET_KEY for Docker deployments)
        secret_key = os.environ.get('SECRET_KEY', '') or os.environ.get('FLASK_SECRET_KEY', '')
        if not secret_key:
            result['warnings'].append('SECRET_KEY not set - using default (insecure for production)')
            self._add_finding(
                category='configuration',
                title='Missing SECRET_KEY',
                severity=SeverityLevel.WARNING,
                message='SECRET_KEY environment variable not set',
                recommendation='Set SECRET_KEY or FLASK_SECRET_KEY in production'
            )
        elif len(secret_key) < 32:
            result['warnings'].append('SECRET_KEY is too short (should be at least 32 characters)')
            self._add_finding(
                category='configuration',
                title='Weak SECRET_KEY',
                severity=SeverityLevel.WARNING,
                message='SECRET_KEY is less than 32 characters',
                recommendation='Use a longer SECRET_KEY for better security'
            )
        else:
            result['checks'].append('SECRET_KEY: OK')

        # Check DATABASE_URL
        db_url = os.environ.get('DATABASE_URL', '')
        if not db_url:
            result['checks'].append('DATABASE_URL: Using SQLite default')
        elif 'sqlite' in db_url.lower():
            result['warnings'].append('Using SQLite database (not recommended for production)')
        elif 'postgresql' in db_url.lower():
            result['checks'].append('DATABASE_URL: PostgreSQL configured')
        else:
            result['checks'].append(f'DATABASE_URL: {db_url.split("@")[0]}***')

        # Check REDIS_URL
        redis_url = os.environ.get('REDIS_URL', '')
        redis_enabled = os.environ.get('REDIS_ENABLED', 'false').lower() == 'true'
        if redis_enabled and not redis_url:
            result['warnings'].append('REDIS_ENABLED=true but REDIS_URL not set')
            self._add_finding(
                category='configuration',
                title='Redis Configuration Issue',
                severity=SeverityLevel.WARNING,
                message='Redis enabled but URL not configured',
                recommendation='Set REDIS_URL environment variable'
            )
        elif redis_enabled:
            result['checks'].append('REDIS_URL: Configured')
        else:
            result['checks'].append('REDIS: Disabled (in-memory rate limiting)')

        # Check HTTPS enforcement (skip warning in development mode)
        force_https = os.environ.get('FORCE_HTTPS', 'false').lower() == 'true'
        flask_env = os.environ.get('FLASK_ENV', '').lower()
        is_dev_mode = flask_env in ('development', 'dev') or os.environ.get('AUDIT_TOOLKIT_DEV_MODE', '').lower() == 'true'
        session_secure = os.environ.get('SESSION_COOKIE_SECURE', 'false').lower() == 'true'

        if force_https:
            result['checks'].append('FORCE_HTTPS: Enabled')
        elif is_dev_mode:
            # Don't warn about HTTPS in development mode
            if session_secure:
                result['checks'].append('HTTPS: Development mode (session cookies secured)')
            else:
                result['checks'].append('HTTPS: Development mode (OK for local testing)')
        else:
            result['warnings'].append('FORCE_HTTPS not enabled (recommended for production)')
            self._add_finding(
                category='configuration',
                title='HTTPS Not Enforced',
                severity=SeverityLevel.WARNING,
                message='HTTPS enforcement is disabled',
                recommendation='Set FORCE_HTTPS=true in production'
            )

        # Check audit scripts directory
        if AUDITS_DIR.exists():
            linux_count = len(list((AUDITS_DIR / 'linux').rglob('*.sh'))) if (AUDITS_DIR / 'linux').exists() else 0
            windows_count = len(list((AUDITS_DIR / 'windows').rglob('*.ps1'))) if (AUDITS_DIR / 'windows').exists() else 0
            result['checks'].append(f'Audit scripts: {linux_count} Linux, {windows_count} Windows')
        else:
            result['errors'].append('Audits directory not found')
            result['valid'] = False

        # Check required directories
        required_dirs = ['logs', 'backups', 'schedules']
        for dir_name in required_dirs:
            dir_path = ROOT_DIR / dir_name
            if dir_path.exists():
                result['checks'].append(f'{dir_name}/: Exists')
            else:
                result['warnings'].append(f'{dir_name}/ directory missing')

        if result['errors']:
            result['valid'] = False

        return result

    # =========================================================================
    # Database Migration Status
    # =========================================================================

    def check_database_migrations(self) -> Dict[str, Any]:
        """
        Check Alembic database migration status.

        Returns:
            Dict with migration status
        """
        result = {
            'migrations_current': None,
            'current_revision': None,
            'head_revision': None,
            'pending_migrations': []
        }

        try:
            # Try to get current revision
            current_result = _run_command(
                ['alembic', 'current'],
                timeout=30,
                cwd=str(ROOT_DIR),
            )

            if current_result.returncode == 0:
                # Parse current revision from output
                for line in current_result.stdout.split('\n'):
                    if '(head)' in line or len(line.strip()) == 12:  # Alembic revision is 12 chars
                        result['current_revision'] = line.strip().split()[0]
                        break

            # Check for pending migrations
            history_result = _run_command(
                ['alembic', 'history', '--verbose'],
                timeout=30,
                cwd=str(ROOT_DIR),
            )

            if history_result.returncode == 0:
                # Get head revision
                head_result = _run_command(
                    ['alembic', 'heads'],
                    timeout=10,
                    cwd=str(ROOT_DIR),
                )
                if head_result.returncode == 0:
                    result['head_revision'] = head_result.stdout.strip().split()[0] if head_result.stdout.strip() else None

                # Check if current matches head
                result['migrations_current'] = (
                    result['current_revision'] == result['head_revision']
                    if result['current_revision'] and result['head_revision']
                    else None
                )

                if result['migrations_current'] is False:
                    self._add_finding(
                        category='database',
                        title='Pending Migrations',
                        severity=SeverityLevel.WARNING,
                        message=f'Database is at revision {result["current_revision"]}, head is {result["head_revision"]}',
                        recommendation='Run: alembic upgrade head'
                    )
                elif result['migrations_current']:
                    self._add_finding(
                        category='database',
                        title='Migrations Current',
                        severity=SeverityLevel.INFO,
                        message=f'Database is at latest revision: {result["current_revision"]}'
                    )

        except FileNotFoundError:
            result['error'] = 'Alembic not installed or not in PATH'
        except subprocess.TimeoutExpired:
            result['error'] = 'Migration check timed out'
        except Exception as e:
            result['error'] = f'Migration check failed: {str(e)}'
            logger.error(f"Migration check failed: {e}")

        return result

    # =========================================================================
    # Git Repository Status
    # =========================================================================

    def check_git_status(self) -> Dict[str, Any]:
        """
        Check Git repository status and update availability.

        Returns:
            Dict with Git status information
        """
        result = {
            'is_git_repo': False,
            'branch': None,
            'commit': None,
            'has_local_changes': False,
            'behind_remote': 0,
            'ahead_remote': 0,
            'remote_url': None
        }

        try:
            # Check if git is available
            version_result = _run_command(
                ['git', '--version'],
                timeout=10
            )
            if version_result.returncode != 0:
                result['error'] = 'Git not available'
                return result

            # Check if this is a git repo
            git_dir = ROOT_DIR / '.git'
            if not git_dir.exists():
                result['is_git_repo'] = False
                return result

            result['is_git_repo'] = True

            # Get current branch
            branch_result = _run_command(
                ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
                timeout=10,
                cwd=str(ROOT_DIR),
            )
            if branch_result.returncode == 0:
                result['branch'] = branch_result.stdout.strip()

            # Get current commit
            commit_result = _run_command(
                ['git', 'rev-parse', '--short', 'HEAD'],
                timeout=10,
                cwd=str(ROOT_DIR),
            )
            if commit_result.returncode == 0:
                result['commit'] = commit_result.stdout.strip()

            # Check for local changes
            status_result = _run_command(
                ['git', 'status', '--porcelain'],
                timeout=10,
                cwd=str(ROOT_DIR),
            )
            if status_result.returncode == 0:
                result['has_local_changes'] = bool(status_result.stdout.strip())
                if result['has_local_changes']:
                    result['changed_files'] = len(status_result.stdout.strip().split('\n'))

            # Get remote URL
            remote_result = _run_command(
                ['git', 'config', '--get', 'remote.origin.url'],
                timeout=10,
                cwd=str(ROOT_DIR),
            )
            if remote_result.returncode == 0:
                result['remote_url'] = remote_result.stdout.strip()

            # Fetch and check ahead/behind (optional, may fail without network)
            try:
                _run_command(
                    ['git', 'fetch', 'origin'],
                    timeout=30,
                    cwd=str(ROOT_DIR),
                )

                rev_list_result = _run_command(
                    ['git', 'rev-list', '--left-right', '--count', f'HEAD...origin/{result["branch"]}'],
                    timeout=10,
                    cwd=str(ROOT_DIR),
                )
                if rev_list_result.returncode == 0:
                    parts = rev_list_result.stdout.strip().split()
                    if len(parts) == 2:
                        result['ahead_remote'] = int(parts[0])
                        result['behind_remote'] = int(parts[1])

                        if result['behind_remote'] > 0:
                            self._add_finding(
                                category='git',
                                title='Updates Available',
                                severity=SeverityLevel.INFO,
                                message=f'Repository is {result["behind_remote"]} commits behind remote',
                                recommendation='Run: git pull origin main'
                            )
            except Exception as e:
                logger.debug(f"Network unavailable for remote check: {e}")

        except FileNotFoundError:
            result['error'] = 'Git not installed'
        except subprocess.TimeoutExpired:
            result['error'] = 'Git operation timed out'
        except Exception as e:
            result['error'] = f'Git check failed: {str(e)}'
            logger.error(f"Git check failed: {e}")

        return result

    # =========================================================================
    # System Information
    # =========================================================================

    def get_system_info(self) -> Dict[str, Any]:
        """
        Get system and deployment information.

        Returns:
            Dict with system details
        """
        import psutil

        # Get disk usage for root/system drive in a cross-platform way
        try:
            if platform.system() == 'Windows':
                # Windows: Use drive where Python is installed
                import sys
                python_drive = Path(sys.executable).drive or 'C:'
                disk_path = python_drive + '\\'
            else:
                # Unix-like: Use root filesystem
                disk_path = '/'
            disk_total_gb = round(psutil.disk_usage(disk_path).total / (1024**3), 2)
        except Exception:
            disk_total_gb = 0  # Fallback if disk check fails

        result = {
            'platform': platform.system(),
            'platform_release': platform.release(),
            'platform_version': platform.version(),
            'architecture': platform.machine(),
            'python_version': platform.python_version(),
            'python_implementation': platform.python_implementation(),
            'hostname': platform.node(),
            'processors': psutil.cpu_count(),
            'memory_total_gb': round(psutil.virtual_memory().total / (1024**3), 2),
            'disk_total_gb': disk_total_gb
        }

        # Deployment type detection using platform_utils
        from platform_utils import get_deployment_type
        result['deployment_type'] = get_deployment_type().capitalize()

        return result

    # =========================================================================
    # Audit Script Statistics
    # =========================================================================

    def get_audit_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about audit scripts.

        Returns:
            Dict with audit script statistics
        """
        result = {
            'linux': {'bash': 0, 'categories': []},
            'windows': {'powershell': 0, 'categories': []},
            'hypervisors': {'total': 0},
            'total_scripts': 0
        }

        try:
            # Count Linux scripts
            linux_dir = AUDITS_DIR / 'linux'
            if linux_dir.exists():
                result['linux']['bash'] = len(list(linux_dir.rglob('*.sh')))
                result['linux']['categories'] = [d.name for d in linux_dir.iterdir() if d.is_dir()]

            # Count Windows scripts
            windows_dir = AUDITS_DIR / 'windows'
            if windows_dir.exists():
                result['windows']['powershell'] = len(list(windows_dir.rglob('*.ps1')))
                result['windows']['categories'] = [d.name for d in windows_dir.iterdir() if d.is_dir()]

            # Count Hypervisor scripts
            hypervisors_dir = AUDITS_DIR / 'hypervisors'
            if hypervisors_dir.exists():
                result['hypervisors']['total'] = (
                    len(list(hypervisors_dir.rglob('*.sh'))) +
                    len(list(hypervisors_dir.rglob('*.ps1')))
                )

            result['total_scripts'] = (
                result['linux']['bash'] +
                result['windows']['powershell'] +
                result['hypervisors']['total']
            )

        except Exception as e:
            result['error'] = str(e)
            logger.error(f"Error counting audit scripts: {e}")

        return result

    # =========================================================================
    # Full Self-Audit Report
    # =========================================================================

    def run_full_audit(self, include_dependency_scan: bool = True, dependency_scan_timeout_seconds: int = 120) -> Dict[str, Any]:
        """
        Run a comprehensive self-audit and generate a full report.

        Args:
            include_dependency_scan: Whether to run pip-audit (can be slow)

        Returns:
            Dict with complete self-audit results
        """
        self.findings = []  # Reset findings

        report = {
            'timestamp': datetime.utcnow().isoformat(),
            'toolkit_version': TOOLKIT_VERSION,
            'audit_duration_ms': 0,
            'overall_status': 'healthy',
            'summary': {
                'total_findings': 0,
                'critical': 0,
                'errors': 0,
                'warnings': 0,
                'info': 0
            },
            'sections': {}
        }

        start_time = datetime.utcnow()

        # Run all checks
        report['sections']['system'] = self.get_system_info()
        report['sections']['version'] = self.check_version()
        report['sections']['configuration'] = self.validate_configuration()
        report['sections']['git'] = self.check_git_status()
        report['sections']['database'] = self.check_database_migrations()
        report['sections']['audit_scripts'] = self.get_audit_statistics()

        if include_dependency_scan:
            report['sections']['dependencies'] = self.scan_dependencies(
                timeout_seconds=dependency_scan_timeout_seconds
            )

        # Calculate duration
        report['audit_duration_ms'] = int((datetime.utcnow() - start_time).total_seconds() * 1000)

        # Aggregate findings
        report['findings'] = [asdict(f) for f in self.findings]
        report['summary']['total_findings'] = len(self.findings)

        for finding in self.findings:
            if finding.severity == 'critical':
                report['summary']['critical'] += 1
            elif finding.severity == 'error':
                report['summary']['errors'] += 1
            elif finding.severity == 'warning':
                report['summary']['warnings'] += 1
            else:
                report['summary']['info'] += 1

        # Determine overall status
        if report['summary']['critical'] > 0:
            report['overall_status'] = 'critical'
        elif report['summary']['errors'] > 0:
            report['overall_status'] = 'unhealthy'
        elif report['summary']['warnings'] > 0:
            report['overall_status'] = 'degraded'
        else:
            report['overall_status'] = 'healthy'

        return report

    def get_quick_status(self) -> Dict[str, Any]:
        """
        Get a quick status check (faster, no dependency scan).

        Returns:
            Dict with quick status
        """
        return {
            'timestamp': datetime.utcnow().isoformat(),
            'version': TOOLKIT_VERSION,
            'git_commit': self._get_git_commit(),
            'update_available': self._quick_version_check(),
            'audit_script_count': self._quick_script_count(),
            'status': 'operational'
        }

    def _get_git_commit(self) -> Optional[str]:
        """Get current git commit hash"""
        try:
            result = _run_command(
                ['git', 'rev-parse', '--short', 'HEAD'],
                timeout=5,
                cwd=str(ROOT_DIR),
            )
            return result.stdout.strip() if result.returncode == 0 else None
        except Exception:
            return None

    def _quick_version_check(self) -> Optional[bool]:
        """Quick check if update might be available (uses cached data if available)"""
        # In production, this could check a local cache file
        return None

    def _quick_script_count(self) -> int:
        """Quick count of audit scripts"""
        try:
            count = 0
            if (AUDITS_DIR / 'linux').exists():
                count += len(list((AUDITS_DIR / 'linux').rglob('*.sh')))
            if (AUDITS_DIR / 'windows').exists():
                count += len(list((AUDITS_DIR / 'windows').rglob('*.ps1')))
            return count
        except Exception:
            return 0


# Convenience functions for API routes
def run_self_audit(include_deps: bool = True, dependency_scan_timeout_seconds: int = 120) -> Dict[str, Any]:
    """Run a full self-audit"""
    auditor = SelfAudit()
    return auditor.run_full_audit(
        include_dependency_scan=include_deps,
        dependency_scan_timeout_seconds=dependency_scan_timeout_seconds,
    )


def get_quick_status() -> Dict[str, Any]:
    """Get quick status check"""
    auditor = SelfAudit()
    return auditor.get_quick_status()


def check_for_updates() -> Dict[str, Any]:
    """Check for toolkit updates"""
    auditor = SelfAudit()
    return auditor.check_version()


def scan_dependencies(timeout_seconds: int = 120) -> Dict[str, Any]:
    """Scan dependencies for vulnerabilities"""
    auditor = SelfAudit()
    return auditor.scan_dependencies(timeout_seconds=timeout_seconds)


# CLI interface
if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Security Audit Toolkit Self-Audit')
    parser.add_argument('--full', action='store_true', help='Run full audit')
    parser.add_argument('--quick', action='store_true', help='Quick status check')
    parser.add_argument('--version', action='store_true', help='Check for updates')
    parser.add_argument('--deps', action='store_true', help='Scan dependencies')
    parser.add_argument('--json', action='store_true', help='Output as JSON')

    args = parser.parse_args()

    if args.version:
        result = check_for_updates()
    elif args.deps:
        result = scan_dependencies()
    elif args.quick:
        result = get_quick_status()
    else:
        result = run_self_audit(include_deps=not args.quick)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        # Pretty print
        print("\n" + "=" * 60)
        print("Security Audit Toolkit - Self-Audit Report")
        print("=" * 60)
        print(f"Version: {result.get('toolkit_version', result.get('version', 'N/A'))}")
        print(f"Timestamp: {result.get('timestamp', 'N/A')}")

        if 'overall_status' in result:
            status_emoji = {
                'healthy': '✅',
                'degraded': '⚠️',
                'unhealthy': '❌',
                'critical': '🚨'
            }.get(result['overall_status'], '❓')
            print(f"Status: {status_emoji} {result['overall_status'].upper()}")

            summary = result.get('summary', {})
            print("\nFindings:")
            print(f"  Critical: {summary.get('critical', 0)}")
            print(f"  Errors:   {summary.get('errors', 0)}")
            print(f"  Warnings: {summary.get('warnings', 0)}")
            print(f"  Info:     {summary.get('info', 0)}")

            # Print findings
            if result.get('findings'):
                print("\nDetails:")
                for f in result['findings']:
                    icon = {'critical': '🚨', 'error': '❌', 'warning': '⚠️', 'info': 'ℹ️'}.get(f['severity'], '•')
                    print(f"  {icon} [{f['category']}] {f['title']}: {f['message']}")
                    if f.get('recommendation'):
                        print(f"     → {f['recommendation']}")

        print("\n" + "=" * 60 + "\n")
