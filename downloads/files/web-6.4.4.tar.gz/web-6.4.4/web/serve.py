#!/usr/bin/env python3
"""Production web launcher for the Security Audit Toolkit.

This compatibility entry point is used by the MSI/Linux installers and starts
Waitress with reverse-proxy trust limited to the configured local proxy.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

WEB_DIR = Path(__file__).resolve().parent
if str(WEB_DIR) not in sys.path:
    sys.path.insert(0, str(WEB_DIR))

from app import app  # noqa: E402

try:
    from waitress import serve as waitress_serve  # noqa: E402
except ImportError:  # pragma: no cover - development fallback
    waitress_serve = None


def _env_flag(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name, str(default)).strip()
    try:
        return int(raw)
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    debug = _env_flag("FLASK_DEBUG", False)
    host = os.getenv("FLASK_BIND_HOST", "127.0.0.1").strip() or "127.0.0.1"
    port = _env_int("FLASK_PORT", 5000)
    threads = max(_env_int("WAITRESS_THREADS", 8), 1)
    trusted_proxy = os.getenv("WAITRESS_TRUSTED_PROXY", "127.0.0.1").strip() or "127.0.0.1"
    trusted_proxy_count = max(_env_int("WAITRESS_TRUSTED_PROXY_COUNT", 1), 1)
    clear_untrusted_proxy_headers = _env_flag("WAITRESS_CLEAR_UNTRUSTED_PROXY_HEADERS", True)

    if host in ("127.0.0.1", "localhost", "::1"):
        print(f"[SECURITY] Binding to localhost only ({host}:{port})")
        print(f"[SECURITY] Trusting reverse proxy headers from: {trusted_proxy} (count={trusted_proxy_count})")
    else:
        print(f"[WARNING] Binding to non-loopback interface ({host}:{port})")

    if waitress_serve is None:
        print("[WARN] waitress is not installed; falling back to Flask development server")
        app.run(host=host, port=port, debug=debug)
    else:
        waitress_serve(
            app,
            host=host,
            port=port,
            threads=threads,
            ident="SecurityAuditToolkit",
            trusted_proxy=trusted_proxy,
            trusted_proxy_count=trusted_proxy_count,
            trusted_proxy_headers={
                "x-forwarded-for",
                "x-forwarded-host",
                "x-forwarded-proto",
                "x-forwarded-port",
            },
            clear_untrusted_proxy_headers=clear_untrusted_proxy_headers,
        )
