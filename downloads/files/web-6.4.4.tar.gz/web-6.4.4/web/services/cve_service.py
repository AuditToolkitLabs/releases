"""
CVE Service - NVD API Client and Sync Logic

Handles:
- NVD API rate-limited queries
- CVE database synchronization
- Package-to-CVE correlation
- Offline data import

Author: Security Audit Toolkit Team
"""

import re
import time
import json
import hashlib
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from threading import Lock

# Import logging
try:
    from config import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


@dataclass
class CVEResult:
    """CVE lookup result"""
    cve_id: str
    description: str
    cvss_score: float
    severity: str
    published_date: datetime
    affected_versions: List[str]
    references: List[str]


class RateLimiter:
    """
    Token bucket rate limiter for NVD API.

    Without API key: 5 requests per 30 seconds
    With API key: 50 requests per 30 seconds
    """

    def __init__(self, requests_per_window: int = 5, window_seconds: int = 30):
        self.requests_per_window = requests_per_window
        self.window_seconds = window_seconds
        self.tokens = requests_per_window
        self.last_refill = time.time()
        self.lock = Lock()

    def acquire(self) -> float:
        """
        Acquire a token, waiting if necessary.
        Returns wait time in seconds.
        """
        with self.lock:
            now = time.time()

            # Refill tokens based on elapsed time
            elapsed = now - self.last_refill
            refill = int(elapsed / self.window_seconds) * self.requests_per_window

            if refill > 0:
                self.tokens = min(self.requests_per_window, self.tokens + refill)
                self.last_refill = now

            if self.tokens > 0:
                self.tokens -= 1
                return 0.0

            # Calculate wait time
            wait_time = self.window_seconds - (now - self.last_refill)
            return max(0.0, wait_time)

    def wait_and_acquire(self) -> None:
        """Wait for a token and acquire it"""
        wait_time = self.acquire()
        if wait_time > 0:
            logger.debug(f"Rate limiting: waiting {wait_time:.2f}s")
            time.sleep(wait_time)
            self.acquire()


class NVDClient:
    """
    NIST NVD API Client with rate limiting.

    Endpoints:
    - /cves/2.0 - CVE data
    - /cpes/2.0 - CPE data
    """

    BASE_URL = "https://services.nvd.nist.gov/rest/json"

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.session = requests.Session()

        # Set rate limit based on API key presence
        if api_key:
            self.rate_limiter = RateLimiter(requests_per_window=50, window_seconds=30)
        else:
            self.rate_limiter = RateLimiter(requests_per_window=5, window_seconds=30)

        # Set headers
        self.session.headers.update({
            'User-Agent': 'SecurityAuditToolkit/1.0',
            'Accept': 'application/json'
        })
        if api_key:
            self.session.headers['apiKey'] = api_key

    def _request(self, endpoint: str, params: Dict = None) -> Dict:
        """Make rate-limited request to NVD API"""
        self.rate_limiter.wait_and_acquire()

        url = f"{self.BASE_URL}{endpoint}"

        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.Timeout:
            logger.error(f"NVD API timeout: {url}")
            raise
        except requests.exceptions.HTTPError as e:
            logger.error(f"NVD API error: {e}")
            raise
        except json.JSONDecodeError:
            logger.error("NVD API invalid JSON response")
            raise

    def get_cve(self, cve_id: str) -> Optional[Dict]:
        """Get single CVE by ID"""
        try:
            result = self._request('/cves/2.0', {'cveId': cve_id})
            vulnerabilities = result.get('vulnerabilities', [])
            return vulnerabilities[0] if vulnerabilities else None
        except Exception as e:
            logger.error(f"Failed to fetch CVE {cve_id}: {e}")
            return None

    def search_cves(
        self,
        keyword: str = None,
        cpe_name: str = None,
        cvss_v3_severity: str = None,
        pub_start_date: datetime = None,
        pub_end_date: datetime = None,
        mod_start_date: datetime = None,
        mod_end_date: datetime = None,
        results_per_page: int = 2000,
        start_index: int = 0
    ) -> Tuple[List[Dict], int]:
        """
        Search CVEs with various filters.

        Returns (list of CVE dicts, total results count)
        """
        params = {
            'resultsPerPage': results_per_page,
            'startIndex': start_index
        }

        if keyword:
            params['keywordSearch'] = keyword
        if cpe_name:
            params['cpeName'] = cpe_name
        if cvss_v3_severity:
            params['cvssV3Severity'] = cvss_v3_severity.upper()

        # Date filtering
        if pub_start_date:
            params['pubStartDate'] = pub_start_date.strftime('%Y-%m-%dT%H:%M:%S.000')
        if pub_end_date:
            params['pubEndDate'] = pub_end_date.strftime('%Y-%m-%dT%H:%M:%S.000')
        if mod_start_date:
            params['lastModStartDate'] = mod_start_date.strftime('%Y-%m-%dT%H:%M:%S.000')
        if mod_end_date:
            params['lastModEndDate'] = mod_end_date.strftime('%Y-%m-%dT%H:%M:%S.000')

        try:
            result = self._request('/cves/2.0', params)
            vulnerabilities = result.get('vulnerabilities', [])
            total = result.get('totalResults', 0)
            return vulnerabilities, total
        except Exception as e:
            logger.error(f"CVE search failed: {e}")
            return [], 0

    def get_cves_modified_since(
        self,
        since: datetime,
        results_per_page: int = 2000
    ) -> List[Dict]:
        """
        Get all CVEs modified since a given date.
        Handles pagination automatically.
        """
        all_cves = []
        start_index = 0

        while True:
            cves, total = self.search_cves(
                mod_start_date=since,
                results_per_page=results_per_page,
                start_index=start_index
            )

            all_cves.extend(cves)
            start_index += len(cves)

            if start_index >= total or len(cves) == 0:
                break

            logger.info(f"Fetched {start_index}/{total} CVEs")

        return all_cves

    def get_cves_by_cpe(self, cpe_name: str) -> List[Dict]:
        """Get all CVEs affecting a specific CPE"""
        cves, _ = self.search_cves(cpe_name=cpe_name)
        return cves


class CVEService:
    """
    CVE Service - Main interface for CVE operations.

    Checks if feature is enabled before every operation.
    """

    def __init__(self, db_session=None):
        self.db = db_session
        self._client = None
        self._settings_cache = None
        self._settings_cache_time = None

    def _get_settings(self):
        """Get CVE settings with caching"""
        from models.cve import CVESettings

        # Cache for 60 seconds
        if self._settings_cache and self._settings_cache_time:
            if (datetime.utcnow() - self._settings_cache_time).total_seconds() < 60:
                return self._settings_cache

        settings = self.db.query(CVESettings).first()
        if not settings:
            # Create default settings (disabled)
            settings = CVESettings(enabled=False)
            self.db.add(settings)
            self.db.commit()

        self._settings_cache = settings
        self._settings_cache_time = datetime.utcnow()
        return settings

    def is_enabled(self) -> bool:
        """Check if CVE integration is enabled"""
        settings = self._get_settings()
        return settings.enabled if settings else False

    def get_client(self) -> Optional[NVDClient]:
        """Get NVD client if enabled"""
        if not self.is_enabled():
            logger.warning("CVE integration is disabled")
            return None

        if self._client is None:
            settings = self._get_settings()
            self._client = NVDClient(api_key=settings.nvd_api_key)

        return self._client

    def lookup_cve(self, cve_id: str) -> Optional[Dict]:
        """
        Look up a single CVE.
        Checks local database first, then NVD API.
        """
        if not self.is_enabled():
            return {'error': 'CVE integration is disabled', 'enabled': False}

        from models.cve import CVERecord

        # Check local database first
        record = self.db.query(CVERecord).filter(
            CVERecord.cve_id == cve_id
        ).first()

        if record:
            return record.to_dict()

        # Fetch from NVD API
        client = self.get_client()
        if not client:
            return {'error': 'Unable to connect to NVD API'}

        result = client.get_cve(cve_id)
        if result:
            # Store in local database
            cve_data = result.get('cve', {})
            record = self._parse_and_store_cve(cve_data)
            return record.to_dict() if record else None

        return None

    def search_by_product(
        self,
        vendor: str,
        product: str,
        version: str = None
    ) -> List[Dict]:
        """Search CVEs by vendor/product"""
        if not self.is_enabled():
            return []

        from models.cve import CVERecord, CPEMatch

        query = self.db.query(CVERecord).join(CPEMatch).filter(
            CPEMatch.vendor == vendor.lower(),
            CPEMatch.product == product.lower()
        )

        records = query.order_by(CVERecord.cvss_v3_score.desc()).all()

        # Filter by version if specified
        if version:
            filtered_records = []
            for record in records:
                for cpe_match in record.cpe_matches:
                    if cpe_match.vendor != vendor.lower() or cpe_match.product != product.lower():
                        continue
                    if self._version_in_range(version, cpe_match):
                        filtered_records.append(record)
                        break
            records = filtered_records

        return [r.to_dict() for r in records]

    def _version_in_range(self, version: str, cpe_match) -> bool:
        """Check if a version falls within a CPE match's version range."""
        # If exact version match is specified
        if cpe_match.version and cpe_match.version != '*':
            return self._compare_versions(version, cpe_match.version) == 0

        # If no version constraints, all versions are affected
        if not cpe_match.version_start and not cpe_match.version_end:
            return True

        # Check start boundary
        if cpe_match.version_start:
            cmp = self._compare_versions(version, cpe_match.version_start)
            if cpe_match.version_start_type == 'excluding':
                if cmp <= 0:  # version <= start (exclusive)
                    return False
            else:  # including
                if cmp < 0:  # version < start
                    return False

        # Check end boundary
        if cpe_match.version_end:
            cmp = self._compare_versions(version, cpe_match.version_end)
            if cpe_match.version_end_type == 'excluding':
                if cmp >= 0:  # version >= end (exclusive)
                    return False
            else:  # including
                if cmp > 0:  # version > end
                    return False

        return True

    def _compare_versions(self, v1: str, v2: str) -> int:
        """
        Compare two version strings.
        Returns: -1 if v1 < v2, 0 if v1 == v2, 1 if v1 > v2
        """
        def normalize(v):
            """Split version into comparable parts."""
            parts = []
            for part in v.replace('-', '.').replace('_', '.').split('.'):
                # Try to parse as integer, otherwise keep as string
                try:
                    parts.append((0, int(part)))  # Numeric parts sort first
                except ValueError:
                    parts.append((1, part.lower()))  # Alpha parts sort after
            return parts

        n1 = normalize(v1)
        n2 = normalize(v2)

        # Pad shorter version with zeros
        max_len = max(len(n1), len(n2))
        n1.extend([(0, 0)] * (max_len - len(n1)))
        n2.extend([(0, 0)] * (max_len - len(n2)))

        for p1, p2 in zip(n1, n2):
            if p1 < p2:
                return -1
            if p1 > p2:
                return 1
        return 0

    def get_cves_for_package(
        self,
        package_name: str,
        package_version: str,
        distro: str = None
    ) -> List[Dict]:
        """
        Get CVEs affecting a specific package.
        Uses package-to-CPE mapping.
        """
        if not self.is_enabled():
            return []

        from models.cve import PackageCPEMap, CVERecord, CPEMatch

        # Look up CPE mapping for this package
        mapping_query = self.db.query(PackageCPEMap).filter(
            PackageCPEMap.package_name == package_name.lower()
        )
        if distro:
            mapping_query = mapping_query.filter(PackageCPEMap.distro == distro.lower())

        mapping = mapping_query.first()

        if not mapping:
            # Try without distro filter
            mapping = self.db.query(PackageCPEMap).filter(
                PackageCPEMap.package_name == package_name.lower()
            ).first()

        if not mapping:
            logger.debug(f"No CPE mapping found for package: {package_name}")
            return []

        # Find CVEs for this CPE
        return self.search_by_product(
            mapping.cpe_vendor,
            mapping.cpe_product,
            package_version
        )

    def correlate_execution(self, execution_id: int) -> Dict:
        """
        Correlate audit execution with CVE data.

        Parses package list from execution output and looks up CVEs.
        Returns summary with affected packages.
        """
        if not self.is_enabled():
            return {'error': 'CVE integration is disabled', 'enabled': False}

        from models.database import AuditExecution, Server
        from models.cve import ServerCVESummary

        execution = self.db.query(AuditExecution).get(execution_id)
        if not execution:
            return {'error': 'Execution not found'}

        # Parse packages from output
        packages = self._parse_packages_from_output(execution.output or '')

        if not packages:
            return {
                'execution_id': execution_id,
                'message': 'No package data found in execution output',
                'packages': []
            }

        # Lookup CVEs for each package
        results = []
        severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
        all_cves = set()
        packages_with_cves = 0

        for pkg in packages:
            cves = self.get_cves_for_package(
                pkg['name'],
                pkg.get('version'),
                pkg.get('distro')
            )

            if cves:
                packages_with_cves += 1
                for cve in cves:
                    all_cves.add(cve['cve_id'])
                    severity = (cve.get('cvss_v3', {}) or {}).get('severity', 'UNKNOWN').lower()
                    if severity in severity_counts:
                        severity_counts[severity] += 1

                results.append({
                    'package': pkg['name'],
                    'version': pkg.get('version'),
                    'cve_count': len(cves),
                    'cves': cves[:5]  # Top 5 only
                })

        # Update server CVE summary
        if execution.server_id:
            summary = self.db.query(ServerCVESummary).filter(
                ServerCVESummary.server_id == execution.server_id
            ).first()

            if not summary:
                summary = ServerCVESummary(server_id=execution.server_id)
                self.db.add(summary)

            summary.execution_id = execution_id
            summary.total_packages = len(packages)
            summary.packages_with_cves = packages_with_cves
            summary.total_cves = len(all_cves)
            summary.critical_count = severity_counts['critical']
            summary.high_count = severity_counts['high']
            summary.medium_count = severity_counts['medium']
            summary.low_count = severity_counts['low']
            summary.scanned_at = datetime.utcnow()

            # Find most critical
            if results:
                most_critical = max(
                    [c for r in results for c in r['cves']],
                    key=lambda x: (x.get('cvss_v3', {}) or {}).get('score', 0),
                    default=None
                )
                if most_critical:
                    summary.most_critical_cve = most_critical['cve_id']
                    summary.most_critical_score = (most_critical.get('cvss_v3', {}) or {}).get('score', 0)

            self.db.commit()

        return {
            'execution_id': execution_id,
            'server_id': execution.server_id,
            'summary': {
                'total_packages': len(packages),
                'packages_with_cves': packages_with_cves,
                'total_cves': len(all_cves),
                'severity_counts': severity_counts
            },
            'vulnerable_packages': results
        }

    def _parse_packages_from_output(self, output: str) -> List[Dict]:
        """
        Parse package list from audit output.

        Looks for [PACKAGES] ... [/PACKAGES] section or
        [SOFTWARE] markers.
        """
        packages = []

        # Pattern 1: [PACKAGES] section
        pkg_section = re.search(r'\[PACKAGES\](.*?)\[/PACKAGES\]', output, re.DOTALL)
        if pkg_section:
            for line in pkg_section.group(1).strip().split('\n'):
                line = line.strip()
                if not line:
                    continue

                # Format: name|version|release|arch or name|version|arch
                parts = line.split('|')
                if len(parts) >= 2:
                    packages.append({
                        'name': parts[0].strip(),
                        'version': parts[1].strip(),
                        'release': parts[2].strip() if len(parts) > 2 else None,
                        'arch': parts[-1].strip() if len(parts) > 3 else None
                    })

        # Pattern 2: [SOFTWARE] markers
        software_pattern = re.findall(r'\[SOFTWARE\]\s*(\S+)\|(\S+)', output)
        for name, version in software_pattern:
            packages.append({'name': name, 'version': version})

        return packages

    def _parse_and_store_cve(self, cve_data: Dict):
        """Parse NVD CVE response and store in database"""
        from models.cve import CVERecord, CPEMatch

        cve_id = cve_data.get('id')
        if not cve_id:
            return None

        # Get or create record
        record = self.db.query(CVERecord).filter(CVERecord.cve_id == cve_id).first()
        if not record:
            record = CVERecord(cve_id=cve_id)
            self.db.add(record)

        # Update fields
        descriptions = cve_data.get('descriptions', [])
        en_desc = next((d['value'] for d in descriptions if d.get('lang') == 'en'), None)
        record.description = en_desc

        # Dates
        if cve_data.get('published'):
            record.published_date = datetime.fromisoformat(
                cve_data['published'].replace('Z', '+00:00')
            )
        if cve_data.get('lastModified'):
            record.last_modified = datetime.fromisoformat(
                cve_data['lastModified'].replace('Z', '+00:00')
            )

        # CVSS v3.1
        metrics = cve_data.get('metrics', {})
        cvss_v3 = metrics.get('cvssMetricV31', [{}])[0] if metrics.get('cvssMetricV31') else {}
        if cvss_v3:
            cvss_data = cvss_v3.get('cvssData', {})
            record.cvss_v3_score = cvss_data.get('baseScore')
            record.cvss_v3_severity = cvss_data.get('baseSeverity')
            record.cvss_v3_vector = cvss_data.get('vectorString')
            record.exploitability_score = cvss_v3.get('exploitabilityScore')
            record.impact_score = cvss_v3.get('impactScore')

        # CVSS v2
        cvss_v2 = metrics.get('cvssMetricV2', [{}])[0] if metrics.get('cvssMetricV2') else {}
        if cvss_v2:
            cvss_data = cvss_v2.get('cvssData', {})
            record.cvss_v2_score = cvss_data.get('baseScore')
            record.cvss_v2_severity = cvss_v2.get('baseSeverity')

        # CWE
        weaknesses = cve_data.get('weaknesses', [])
        cwes = []
        for weakness in weaknesses:
            for desc in weakness.get('description', []):
                if desc.get('value', '').startswith('CWE-'):
                    cwes.append(desc['value'])
        record.cwe_ids = cwes

        # References
        refs = cve_data.get('references', [])
        record.references = [r.get('url') for r in refs if r.get('url')]

        # CPE matches
        configurations = cve_data.get('configurations', [])
        for config in configurations:
            for node in config.get('nodes', []):
                for match in node.get('cpeMatch', []):
                    cpe23 = match.get('criteria')
                    if cpe23 and match.get('vulnerable'):
                        # Parse CPE
                        parts = cpe23.split(':')
                        if len(parts) >= 5:
                            cpe_match = CPEMatch(
                                cve_id=cve_id,
                                cpe23=cpe23,
                                vendor=parts[3] if len(parts) > 3 else None,
                                product=parts[4] if len(parts) > 4 else None,
                                version=parts[5] if len(parts) > 5 and parts[5] != '*' else None,
                                version_start=match.get('versionStartIncluding') or match.get('versionStartExcluding'),
                                version_start_type='including' if match.get('versionStartIncluding') else 'excluding' if match.get('versionStartExcluding') else None,
                                version_end=match.get('versionEndIncluding') or match.get('versionEndExcluding'),
                                version_end_type='including' if match.get('versionEndIncluding') else 'excluding' if match.get('versionEndExcluding') else None,
                                vulnerable=True
                            )
                            self.db.add(cpe_match)

        self.db.commit()
        return record


class CVESyncService:
    """
    CVE Sync Service - Manages database synchronization.

    All sync operations check if enabled before running.
    """

    def __init__(self, db_session):
        self.db = db_session
        self.cve_service = CVEService(db_session)

    def _get_settings(self):
        from models.cve import CVESettings
        return self.db.query(CVESettings).first()

    def _update_sync_status(
        self,
        status: str,
        message: str = None,
        cve_count: int = 0
    ):
        """Update settings with sync status"""
        settings = self._get_settings()
        if settings:
            settings.last_sync_at = datetime.utcnow()
            settings.last_sync_status = status
            settings.last_sync_message = message
            settings.last_sync_cve_count = cve_count
            self.db.commit()

    def _create_sync_log(
        self,
        sync_type: str,
        triggered_by: str
    ):
        """Create sync log entry"""
        from models.cve import CVESyncLog

        log = CVESyncLog(
            sync_type=sync_type,
            status='in_progress',
            triggered_by=triggered_by
        )
        self.db.add(log)
        self.db.commit()
        return log

    def run_sync(
        self,
        sync_type: str = 'delta',
        triggered_by: str = 'system',
        days_back: int = 7
    ) -> Dict:
        """
        Run CVE sync operation.

        sync_type: 'full' | 'delta' | 'manual'
        """
        from models.cve import CVESyncLog

        # Check if enabled
        if not self.cve_service.is_enabled():
            return {
                'success': False,
                'error': 'CVE integration is disabled',
                'enabled': False
            }

        settings = self._get_settings()
        if settings.last_sync_status == 'in_progress':
            return {
                'success': False,
                'error': 'Sync already in progress'
            }

        # Create log entry
        log = self._create_sync_log(sync_type, triggered_by)

        try:
            self._update_sync_status('in_progress', f'Starting {sync_type} sync')

            client = self.cve_service.get_client()
            if not client:
                raise Exception("Cannot initialize NVD client")

            # Determine date range
            if sync_type == 'full':
                since = datetime.utcnow() - timedelta(days=365 * 5)  # 5 years
            else:
                since = settings.last_sync_at or (datetime.utcnow() - timedelta(days=days_back))

            # Fetch CVEs
            logger.info(f"Fetching CVEs modified since {since}")
            cves = client.get_cves_modified_since(since)

            # Store CVEs
            added = 0
            updated = 0
            errors = []

            for cve_wrapper in cves:
                try:
                    cve_data = cve_wrapper.get('cve', {})
                    cve_id = cve_data.get('id')

                    from models.cve import CVERecord
                    existing = self.db.query(CVERecord).filter(
                        CVERecord.cve_id == cve_id
                    ).first()

                    self.cve_service._parse_and_store_cve(cve_data)

                    if existing:
                        updated += 1
                    else:
                        added += 1

                except Exception as e:
                    errors.append(str(e))
                    if len(errors) <= 10:  # Limit stored errors
                        pass

            # Update log
            log.completed_at = datetime.utcnow()
            log.status = 'success' if not errors else 'partial'
            log.message = f"Synced {added + updated} CVEs"
            log.cves_added = added
            log.cves_updated = updated
            log.error_count = len(errors)
            log.errors = errors[:10]

            self._update_sync_status(
                'success',
                f"Added {added}, updated {updated} CVEs",
                added + updated
            )

            self.db.commit()

            return {
                'success': True,
                'added': added,
                'updated': updated,
                'errors': len(errors),
                'sync_log_id': log.id
            }

        except Exception as e:
            logger.error(f"CVE sync failed: {e}")

            log.completed_at = datetime.utcnow()
            log.status = 'failed'
            log.message = str(e)

            self._update_sync_status('failed', str(e))
            self.db.commit()

            return {
                'success': False,
                'error': str(e)
            }

    def import_offline_data(self, file_path: str, triggered_by: str = 'admin') -> Dict:
        """
        Import CVE data from offline file.

        Supports JSON export files from NVD or custom JSON format.
        """
        if not self.cve_service.is_enabled():
            return {'error': 'CVE integration is disabled'}

        log = self._create_sync_log('import', triggered_by)

        try:
            import os
            import json

            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Import file not found: {file_path}")

            # Determine file type and parse
            added = 0
            updated = 0
            errors = []

            file_ext = os.path.splitext(file_path)[1].lower()

            if file_ext == '.json':
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                # Handle different JSON formats
                cves = []
                if isinstance(data, list):
                    # Direct list of CVEs
                    cves = data
                elif isinstance(data, dict):
                    # NVD format: {"vulnerabilities": [{"cve": {...}}, ...]}
                    if 'vulnerabilities' in data:
                        cves = [v.get('cve', v) for v in data['vulnerabilities']]
                    # Simple format: {"cves": [...]}
                    elif 'cves' in data:
                        cves = data['cves']
                    # Single CVE
                    elif 'id' in data or 'cve_id' in data:
                        cves = [data]

                from models.cve import CVERecord

                for cve_data in cves:
                    try:
                        # Handle nested CVE format
                        if 'cve' in cve_data and isinstance(cve_data['cve'], dict):
                            cve_data = cve_data['cve']

                        cve_id = cve_data.get('id') or cve_data.get('cve_id')
                        if not cve_id:
                            continue

                        existing = self.db.query(CVERecord).filter(
                            CVERecord.cve_id == cve_id
                        ).first()

                        self.cve_service._parse_and_store_cve(cve_data)

                        if existing:
                            updated += 1
                        else:
                            added += 1

                    except Exception as e:
                        errors.append(f"Error processing CVE: {str(e)}")
                        if len(errors) > 100:  # Limit errors stored
                            break

            else:
                raise ValueError(f"Unsupported file type: {file_ext}. Supported: .json")

            # Update log
            log.completed_at = datetime.utcnow()
            log.status = 'success' if not errors else 'partial'
            log.message = f"Imported {added + updated} CVEs from {os.path.basename(file_path)}"
            log.cves_added = added
            log.cves_updated = updated
            log.error_count = len(errors)
            log.errors = errors[:10]

            self._update_sync_status(
                'success' if not errors else 'partial',
                f"Import: Added {added}, updated {updated} CVEs",
                added + updated
            )

            self.db.commit()

            return {
                'success': True,
                'file': file_path,
                'added': added,
                'updated': updated,
                'errors': len(errors)
            }

        except Exception as e:
            logger.error(f"CVE import failed: {e}")
            log.completed_at = datetime.utcnow()
            log.status = 'failed'
            log.message = str(e)
            self.db.commit()

            return {'success': False, 'error': str(e)}

    def cancel_sync(self) -> Dict:
        """Cancel in-progress sync"""
        settings = self._get_settings()
        if settings and settings.last_sync_status == 'in_progress':
            self._update_sync_status('cancelled', 'Sync cancelled by admin')
            return {'success': True, 'message': 'Sync cancelled'}
        return {'success': False, 'message': 'No sync in progress'}
