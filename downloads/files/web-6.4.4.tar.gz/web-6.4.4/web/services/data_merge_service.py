"""
Data Merge Service - Unifies data from main toolkit and asset-discovery databases

This service enables:
1. Viewing combined inventory from both databases
2. Matching servers by hostname/IP across databases
3. Enriching main toolkit servers with asset-discovery data
4. Optional sync of asset-discovery data to main database

The databases remain separate to allow asset-discovery to function standalone.

Author: Security Audit Toolkit Team
Date: March 2026
"""

import os
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
from contextlib import contextmanager

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session

logger = logging.getLogger(__name__)


class DataMergeService:
    """
    Service to merge/query data across the main toolkit and asset-discovery databases.

    Supports:
    - SQLite (default) and PostgreSQL for both databases
    - Read-only merged views
    - Optional write-back sync to main database
    """

    def __init__(
        self,
        main_db_url: Optional[str] = None,
        asset_db_url: Optional[str] = None
    ):
        """
        Initialize the merge service with database connections.

        Args:
            main_db_url: SQLAlchemy URL for main toolkit database
            asset_db_url: SQLAlchemy URL for asset-discovery database
        """
        # Default paths
        web_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        repo_root = os.path.dirname(web_dir)

        # Main toolkit database
        if main_db_url:
            self.main_db_url = main_db_url
        else:
            main_db_path = os.path.join(web_dir, 'data', 'audit_toolkit.db')
            self.main_db_url = f"sqlite:///{main_db_path}"

        # Asset discovery database
        if asset_db_url:
            self.asset_db_url = asset_db_url
        else:
            asset_db_path = os.path.join(repo_root, 'tools', 'asset-discovery', 'data', 'asset_discovery.db')
            self.asset_db_url = f"sqlite:///{asset_db_path}"

        # Create engines (lazy connection)
        self._main_engine = None
        self._asset_engine = None
        self._main_session_factory = None
        self._asset_session_factory = None

        logger.info("DataMergeService initialized")
        logger.debug(f"Main DB: {self.main_db_url}")
        logger.debug(f"Asset DB: {self.asset_db_url}")

    @property
    def main_engine(self):
        """Lazy-load main database engine."""
        if self._main_engine is None:
            self._main_engine = create_engine(
                self.main_db_url,
                echo=False,
                pool_pre_ping=True
            )
            self._main_session_factory = sessionmaker(bind=self._main_engine)
        return self._main_engine

    @property
    def asset_engine(self):
        """Lazy-load asset database engine."""
        if self._asset_engine is None:
            self._asset_engine = create_engine(
                self.asset_db_url,
                echo=False,
                pool_pre_ping=True
            )
            self._asset_session_factory = sessionmaker(bind=self._asset_engine)
        return self._asset_engine

    @contextmanager
    def main_session(self) -> Session:
        """Context manager for main database session."""
        _ = self.main_engine  # Ensure engine is initialized
        session = self._main_session_factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    @contextmanager
    def asset_session(self) -> Session:
        """Context manager for asset database session."""
        _ = self.asset_engine  # Ensure engine is initialized
        session = self._asset_session_factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def check_databases_available(self) -> Dict[str, bool]:
        """Check if both databases are accessible."""
        result = {
            'main_db': False,
            'asset_db': False,
            'main_db_path': self.main_db_url,
            'asset_db_path': self.asset_db_url
        }

        try:
            with self.main_session() as session:
                session.execute("SELECT 1")
            result['main_db'] = True
        except Exception as e:
            logger.warning(f"Main database not accessible: {e}")

        try:
            with self.asset_session() as session:
                session.execute("SELECT 1")
            result['asset_db'] = True
        except Exception as e:
            logger.warning(f"Asset database not accessible: {e}")

        return result

    def get_main_servers(self) -> List[Dict[str, Any]]:
        """Get all servers from main toolkit database."""
        try:
            with self.main_session() as session:
                result = session.execute(text("""
                    SELECT id, name, hostname, port, username, description, tags,
                           hypervisor_type, hypervisor_endpoint,
                           created_at, updated_at, last_audit_at
                    FROM servers
                    ORDER BY name
                """))
                servers = []
                for row in result:
                    servers.append({
                        'id': row[0],
                        'name': row[1],
                        'hostname': row[2],
                        'port': row[3],
                        'username': row[4],
                        'description': row[5],
                        'tags': row[6],
                        'hypervisor_type': row[7],
                        'hypervisor_endpoint': row[8],
                        'created_at': row[9],
                        'updated_at': row[10],
                        'last_audit_at': row[11],
                        'source': 'main'
                    })
                return servers
        except Exception as e:
            logger.error(f"Error fetching main servers: {e}")
            return []

    def get_discovered_assets(self) -> List[Dict[str, Any]]:
        """Get all assets from asset-discovery database."""
        try:
            with self.asset_session() as session:
                result = session.execute(text("""
                    SELECT id, uuid, hostname, fqdn, domain, asset_type,
                           os_type, os_name, os_version, kernel_version,
                           architecture, manufacturer, model, serial_number,
                           cpu_model, cpu_cores, total_memory_gb,
                           primary_ip, mac_address, is_virtual, hypervisor,
                           status, environment, location, owner, business_unit,
                           criticality, tags, first_seen, last_seen
                    FROM assets
                    ORDER BY hostname
                """))
                assets = []
                for row in result:
                    assets.append({
                        'id': row[0],
                        'uuid': row[1],
                        'hostname': row[2],
                        'fqdn': row[3],
                        'domain': row[4],
                        'asset_type': row[5],
                        'os_type': row[6],
                        'os_name': row[7],
                        'os_version': row[8],
                        'kernel_version': row[9],
                        'architecture': row[10],
                        'manufacturer': row[11],
                        'model': row[12],
                        'serial_number': row[13],
                        'cpu_model': row[14],
                        'cpu_cores': row[15],
                        'total_memory_gb': float(row[16]) if row[16] else None,
                        'primary_ip': row[17],
                        'mac_address': row[18],
                        'is_virtual': row[19],
                        'hypervisor': row[20],
                        'status': row[21],
                        'environment': row[22],
                        'location': row[23],
                        'owner': row[24],
                        'business_unit': row[25],
                        'criticality': row[26],
                        'tags': row[27],
                        'first_seen': row[28],
                        'last_seen': row[29],
                        'source': 'asset_discovery'
                    })
                return assets
        except Exception as e:
            logger.error(f"Error fetching discovered assets: {e}")
            return []

    def get_asset_software(self, asset_id: int) -> List[Dict[str, Any]]:
        """Get installed software for an asset."""
        try:
            with self.asset_session() as session:
                result = session.execute(text("""
                    SELECT id, name, version, vendor, install_date
                    FROM installed_software
                    WHERE asset_id = :asset_id
                    ORDER BY name
                """), {'asset_id': asset_id})
                return [
                    {
                        'id': row[0],
                        'name': row[1],
                        'version': row[2],
                        'vendor': row[3],
                        'install_date': row[4]
                    }
                    for row in result
                ]
        except Exception as e:
            logger.error(f"Error fetching software for asset {asset_id}: {e}")
            return []

    def get_asset_vulnerabilities(self, asset_id: int) -> List[Dict[str, Any]]:
        """Get vulnerabilities for an asset."""
        try:
            with self.asset_session() as session:
                result = session.execute(text("""
                    SELECT sv.id, sv.cve_id, sv.software_name, sv.software_version,
                           sv.severity, sv.status, c.cvss_score, c.description
                    FROM software_vulnerabilities sv
                    LEFT JOIN cve_records c ON sv.cve_id = c.cve_id
                    WHERE sv.asset_id = :asset_id
                    ORDER BY c.cvss_score DESC NULLS LAST
                """), {'asset_id': asset_id})
                return [
                    {
                        'id': row[0],
                        'cve_id': row[1],
                        'software_name': row[2],
                        'software_version': row[3],
                        'severity': row[4],
                        'status': row[5],
                        'cvss_score': float(row[6]) if row[6] else None,
                        'description': row[7]
                    }
                    for row in result
                ]
        except Exception as e:
            logger.error(f"Error fetching vulnerabilities for asset {asset_id}: {e}")
            return []

    def get_merged_inventory(self) -> Dict[str, Any]:
        """
        Get a merged inventory view combining both databases.

        Matches records by hostname (case-insensitive) and IP address.
        Returns:
        - unified: Records found in both databases (merged)
        - main_only: Records only in main toolkit
        - discovery_only: Records only in asset discovery
        """
        main_servers = self.get_main_servers()
        discovered_assets = self.get_discovered_assets()

        # Build lookup indices
        main_by_hostname = {s['hostname'].lower(): s for s in main_servers if s.get('hostname')}
        asset_by_hostname = {a['hostname'].lower(): a for a in discovered_assets if a.get('hostname')}
        asset_by_ip = {a['primary_ip']: a for a in discovered_assets if a.get('primary_ip')}

        unified = []
        main_only = []
        discovery_only = []
        matched_asset_hostnames = set()

        # Match main servers to discovered assets
        for server in main_servers:
            hostname_lower = server['hostname'].lower() if server.get('hostname') else None

            # Try to find matching asset by hostname
            asset = None
            if hostname_lower and hostname_lower in asset_by_hostname:
                asset = asset_by_hostname[hostname_lower]
                matched_asset_hostnames.add(hostname_lower)
            # Try IP match if hostname didn't work
            elif server.get('hostname') in asset_by_ip:
                asset = asset_by_ip[server['hostname']]
                if asset.get('hostname'):
                    matched_asset_hostnames.add(asset['hostname'].lower())

            if asset:
                # Merge data - main server info + enriched asset discovery data
                merged = {
                    # Identity from main (authoritative for auditing)
                    'main_id': server['id'],
                    'name': server['name'],
                    'hostname': server['hostname'],
                    'port': server['port'],
                    'username': server['username'],

                    # Asset discovery enrichment
                    'asset_id': asset['id'],
                    'asset_uuid': asset['uuid'],
                    'fqdn': asset.get('fqdn'),
                    'os_type': asset.get('os_type'),
                    'os_name': asset.get('os_name'),
                    'os_version': asset.get('os_version'),
                    'kernel_version': asset.get('kernel_version'),
                    'architecture': asset.get('architecture'),

                    # Hardware (from asset discovery)
                    'manufacturer': asset.get('manufacturer'),
                    'model': asset.get('model'),
                    'serial_number': asset.get('serial_number'),
                    'cpu_model': asset.get('cpu_model'),
                    'cpu_cores': asset.get('cpu_cores'),
                    'total_memory_gb': asset.get('total_memory_gb'),

                    # Network
                    'primary_ip': asset.get('primary_ip'),
                    'mac_address': asset.get('mac_address'),

                    # Classification
                    'asset_type': asset.get('asset_type'),
                    'is_virtual': asset.get('is_virtual'),
                    'hypervisor': asset.get('hypervisor') or server.get('hypervisor_type'),
                    'environment': asset.get('environment'),
                    'criticality': asset.get('criticality'),
                    'status': asset.get('status'),

                    # Organization
                    'location': asset.get('location'),
                    'owner': asset.get('owner'),
                    'business_unit': asset.get('business_unit'),

                    # Metadata (merge tags from both)
                    'tags': list(set((server.get('tags') or '').split(',') + (asset.get('tags') or []))),
                    'description': server.get('description'),

                    # Timestamps
                    'last_audit_at': server.get('last_audit_at'),
                    'first_seen': asset.get('first_seen'),
                    'last_seen': asset.get('last_seen'),

                    'match_type': 'unified',
                    'sources': ['main', 'asset_discovery']
                }
                unified.append(merged)
            else:
                # Main server only - no matching asset discovery data
                main_only.append({
                    **server,
                    'match_type': 'main_only',
                    'sources': ['main']
                })

        # Find assets not in main database
        for asset in discovered_assets:
            hostname_lower = asset['hostname'].lower() if asset.get('hostname') else None
            if hostname_lower and hostname_lower not in matched_asset_hostnames:
                discovery_only.append({
                    **asset,
                    'match_type': 'discovery_only',
                    'sources': ['asset_discovery']
                })

        return {
            'unified': unified,
            'main_only': main_only,
            'discovery_only': discovery_only,
            'stats': {
                'total_main_servers': len(main_servers),
                'total_discovered_assets': len(discovered_assets),
                'unified_count': len(unified),
                'main_only_count': len(main_only),
                'discovery_only_count': len(discovery_only),
                'total_unique_hosts': len(unified) + len(main_only) + len(discovery_only)
            }
        }

    def sync_asset_to_main(self, asset_id: int, create_if_missing: bool = True) -> Dict[str, Any]:
        """
        Sync a discovered asset to the main toolkit database.

        Args:
            asset_id: ID of asset in asset-discovery database
            create_if_missing: Create new server record if not found in main

        Returns:
            Dict with sync status and server ID
        """
        # Get asset from discovery database
        try:
            with self.asset_session() as session:
                result = session.execute(text("""
                    SELECT hostname, fqdn, primary_ip, os_type, environment, tags
                    FROM assets WHERE id = :id
                """), {'id': asset_id})
                row = result.fetchone()
                if not row:
                    return {'success': False, 'error': 'Asset not found'}

                asset = {
                    'hostname': row[0],
                    'fqdn': row[1],
                    'primary_ip': row[2],
                    'os_type': row[3],
                    'environment': row[4],
                    'tags': row[5]
                }
        except Exception as e:
            return {'success': False, 'error': f'Failed to fetch asset: {e}'}

        # Check if server exists in main database
        try:
            with self.main_session() as session:
                result = session.execute(text("""
                    SELECT id FROM servers
                    WHERE LOWER(hostname) = LOWER(:hostname)
                """), {'hostname': asset['hostname']})
                existing = result.fetchone()

                if existing:
                    # Update existing server
                    server_id = existing[0]
                    session.execute(text("""
                        UPDATE servers
                        SET updated_at = :updated_at
                        WHERE id = :id
                    """), {'id': server_id, 'updated_at': datetime.utcnow()})
                    return {
                        'success': True,
                        'action': 'updated',
                        'server_id': server_id
                    }
                elif create_if_missing:
                    # Create new server
                    result = session.execute(text("""
                        INSERT INTO servers (name, hostname, port, username, description, tags, created_at, updated_at)
                        VALUES (:name, :hostname, 22, 'root', :description, :tags, :created_at, :updated_at)
                        RETURNING id
                    """), {
                        'name': asset['hostname'],
                        'hostname': asset['hostname'],
                        'description': f"Imported from Asset Discovery ({asset.get('os_type', 'unknown')} - {asset.get('environment', 'unknown')})",
                        'tags': ','.join(asset['tags']) if asset['tags'] else '',
                        'created_at': datetime.utcnow(),
                        'updated_at': datetime.utcnow()
                    })
                    server_id = result.fetchone()[0]
                    return {
                        'success': True,
                        'action': 'created',
                        'server_id': server_id
                    }
                else:
                    return {
                        'success': False,
                        'error': 'Server not found and create_if_missing=False'
                    }
        except Exception as e:
            return {'success': False, 'error': f'Failed to sync to main db: {e}'}

    def get_enriched_server(self, server_id: int) -> Optional[Dict[str, Any]]:
        """
        Get a server from main DB enriched with asset-discovery data.

        Args:
            server_id: ID of server in main database

        Returns:
            Dict with server + enrichment data, or None if not found
        """
        # Get server from main DB
        try:
            with self.main_session() as session:
                result = session.execute(text("""
                    SELECT id, name, hostname, port, username, description, tags,
                           hypervisor_type, created_at, updated_at, last_audit_at
                    FROM servers WHERE id = :id
                """), {'id': server_id})
                row = result.fetchone()
                if not row:
                    return None

                server = {
                    'id': row[0],
                    'name': row[1],
                    'hostname': row[2],
                    'port': row[3],
                    'username': row[4],
                    'description': row[5],
                    'tags': row[6],
                    'hypervisor_type': row[7],
                    'created_at': row[8],
                    'updated_at': row[9],
                    'last_audit_at': row[10]
                }
        except Exception as e:
            logger.error(f"Error fetching server {server_id}: {e}")
            return None

        # Try to find matching asset
        try:
            with self.asset_session() as session:
                result = session.execute(text("""
                    SELECT id, uuid, fqdn, os_type, os_name, os_version,
                           kernel_version, architecture, manufacturer, model,
                           cpu_model, cpu_cores, total_memory_gb,
                           primary_ip, is_virtual, hypervisor, status,
                           environment, criticality, first_seen, last_seen
                    FROM assets
                    WHERE LOWER(hostname) = LOWER(:hostname)
                    LIMIT 1
                """), {'hostname': server['hostname']})
                asset_row = result.fetchone()

                if asset_row:
                    server['enrichment'] = {
                        'asset_id': asset_row[0],
                        'asset_uuid': asset_row[1],
                        'fqdn': asset_row[2],
                        'os_type': asset_row[3],
                        'os_name': asset_row[4],
                        'os_version': asset_row[5],
                        'kernel_version': asset_row[6],
                        'architecture': asset_row[7],
                        'manufacturer': asset_row[8],
                        'model': asset_row[9],
                        'cpu_model': asset_row[10],
                        'cpu_cores': asset_row[11],
                        'total_memory_gb': float(asset_row[12]) if asset_row[12] else None,
                        'primary_ip': asset_row[13],
                        'is_virtual': asset_row[14],
                        'hypervisor': asset_row[15],
                        'status': asset_row[16],
                        'environment': asset_row[17],
                        'criticality': asset_row[18],
                        'first_seen': asset_row[19],
                        'last_seen': asset_row[20],
                        'has_enrichment': True
                    }

                    # Get software count
                    sw_result = session.execute(text("""
                        SELECT COUNT(*) FROM installed_software WHERE asset_id = :id
                    """), {'id': asset_row[0]})
                    server['enrichment']['software_count'] = sw_result.fetchone()[0]

                    # Get vulnerability count
                    vuln_result = session.execute(text("""
                        SELECT COUNT(*) FROM software_vulnerabilities WHERE asset_id = :id
                    """), {'id': asset_row[0]})
                    server['enrichment']['vulnerability_count'] = vuln_result.fetchone()[0]
                else:
                    server['enrichment'] = {'has_enrichment': False}
        except Exception as e:
            logger.warning(f"Could not enrich server {server_id}: {e}")
            server['enrichment'] = {'has_enrichment': False, 'error': str(e)}

        return server


# Singleton instance
_merge_service: Optional[DataMergeService] = None


def get_merge_service() -> DataMergeService:
    """Get or create the singleton merge service instance."""
    global _merge_service
    if _merge_service is None:
        _merge_service = DataMergeService()
    return _merge_service
