# Services package initializer
from .license_service import LicenseService, get_license_service
from .beta_licensing import BetaLicenseService, get_beta_license_service, BetaTier
from .beta_enforcement import (
    init_beta_enforcement,
    require_beta_license,
    check_scan_limit,
    record_scan_usage,
    check_machine_limit,
    get_beta_status,
    is_beta_valid,
)
from .feature_licensing import (
    Feature,
    FeatureLicenseService,
    get_feature_service,
    require_feature,
    require_feature_key,
    check_feature,
    FEATURE_CONFIG,
    FEATURE_CATEGORIES,
)
from .reporting_normalization import ReportingNormalizationService
from .reporting_backfill_service import ReportingBackfillService
from .reporting_persistence_service import ReportingPersistenceService
from .reporting_provenance_service import ReportingProvenanceService, REPORTING_SOURCE_SPECS
from .reporting_query_service import ReportingQueryService

__all__ = [
    # License Service
    'LicenseService',
    'get_license_service',
    # Beta Licensing
    'BetaLicenseService',
    'get_beta_license_service',
    'BetaTier',
    'init_beta_enforcement',
    'require_beta_license',
    'check_scan_limit',
    'record_scan_usage',
    'check_machine_limit',
    'get_beta_status',
    'is_beta_valid',
    # Feature Licensing
    'Feature',
    'FeatureLicenseService',
    'get_feature_service',
    'require_feature',
    'require_feature_key',
    'check_feature',
    'FEATURE_CONFIG',
    'FEATURE_CATEGORIES',
    # Reporting services
    'ReportingNormalizationService',
    'ReportingBackfillService',
    'ReportingPersistenceService',
    'ReportingProvenanceService',
    'ReportingQueryService',
    'REPORTING_SOURCE_SPECS',
]
