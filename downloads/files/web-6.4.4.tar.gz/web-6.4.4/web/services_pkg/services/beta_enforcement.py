"""
Beta License Enforcement Middleware

Provides Flask middleware and decorators to enforce beta licensing:
1. Build expiration check on app startup
2. Scan limit enforcement before audit execution
3. Machine count limits for server registration
4. Optional telemetry collection

Usage:
    # In app.py
    from services_pkg.services.beta_enforcement import init_beta_enforcement
    init_beta_enforcement(app)

    # On specific routes
    from services_pkg.services.beta_enforcement import require_beta_license, check_scan_limit
    @require_beta_license
    @check_scan_limit
    def run_audit():
        ...
"""

import os
from functools import wraps
from flask import jsonify, request, g, current_app
import logging

logger = logging.getLogger(__name__)

# Environment variable to bypass beta checks (for internal/CI use)
BYPASS_BETA_CHECKS = os.environ.get('BYPASS_BETA_CHECKS', 'false').lower() == 'true'


def init_beta_enforcement(app):
    """
    Initialize beta enforcement on Flask app.

    This adds:
    1. Build expiration check on startup
    2. Before-request hook for license validation
    3. Context processor for templates
    """
    from services_pkg.services.beta_licensing import (
        get_beta_license_service,
        BETA_PROGRAM,
        BUILD_DATE,
        BUILD_VERSION,
    )

    # Check build expiration on startup (unless bypassed)
    if not BYPASS_BETA_CHECKS:
        service = get_beta_license_service()
        build_status = service.check_build_expiration()

        if build_status.get('expired'):
            logger.critical(f"BUILD EXPIRED: {build_status['message']}")
            # In strict mode, you could raise an exception here
            # raise RuntimeError(build_status['message'])

        if build_status.get('days_remaining', 999) < 14:
            logger.warning(
                f"BUILD EXPIRING SOON: {build_status['days_remaining']} days remaining. "
                f"Please update to a newer version."
            )

    # Add beta context to templates
    @app.context_processor
    def inject_beta_context():
        """Inject beta program info into all templates."""
        try:
            service = get_beta_license_service()
            status = service.get_status()
            return {
                'beta_program': {
                    'enabled': BETA_PROGRAM.get('enabled', False),
                    'build_version': BUILD_VERSION,
                    'build_date': BUILD_DATE,
                    'days_remaining': status.get('build', {}).get('days_remaining', -1),
                    'license_valid': status.get('valid', False),
                    'license_tier': status.get('license', {}).get('tier', 'none'),
                },
            }
        except Exception:
            return {'beta_program': {'enabled': False}}

    logger.info(f"Beta enforcement initialized (build: {BUILD_VERSION}, bypass: {BYPASS_BETA_CHECKS})")


def require_beta_license(f):
    """
    Decorator requiring valid beta license for endpoint.

    Returns 403 if:
    - Build has expired
    - No beta license is active
    - Beta license has expired
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        if BYPASS_BETA_CHECKS:
            return f(*args, **kwargs)

        from services_pkg.services.beta_licensing import get_beta_license_service

        service = get_beta_license_service()

        # Check build expiration
        build_status = service.check_build_expiration()
        if build_status.get('expired'):
            return jsonify({
                "success": False,
                "error": "build_expired",
                "message": build_status['message'],
                "action": "Please update to a newer version of the software.",
            }), 403

        # Check license validity
        status = service.get_status()
        if not status.get('valid'):
            return jsonify({
                "success": False,
                "error": status.get('error', 'invalid_license'),
                "message": status.get('message', 'Valid beta license required'),
                "action": "Register at /api/beta/register or activate a beta key at /api/beta/activate",
            }), 403

        # Store license info in request context
        g.beta_license = status.get('license', {})
        g.beta_usage = status.get('usage', {})

        return f(*args, **kwargs)

    return decorated


def check_scan_limit(f):
    """
    Decorator to check and enforce scan limits.

    Must be used after require_beta_license.

    Returns 429 if daily or monthly scan limit exceeded.
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        if BYPASS_BETA_CHECKS:
            return f(*args, **kwargs)

        from services_pkg.services.beta_licensing import get_beta_license_service

        service = get_beta_license_service()
        check = service.check_scan_allowed()

        if not check.get('allowed'):
            return jsonify({
                "success": False,
                "error": "scan_limit_exceeded",
                "message": check['message'],
                "remaining_today": check.get('remaining_today', 0),
                "remaining_month": check.get('remaining_month', 0),
                "action": "Wait until limits reset or upgrade your beta tier.",
            }), 429

        return f(*args, **kwargs)

    return decorated


def record_scan_usage(machine_id: str = None):
    """
    Record a completed scan for usage tracking.

    Call this after a successful audit execution.

    Args:
        machine_id: Optional unique identifier for the scanned machine
    """
    if BYPASS_BETA_CHECKS:
        return

    try:
        from services_pkg.services.beta_licensing import get_beta_license_service
        service = get_beta_license_service()
        service.record_scan(machine_id)
    except Exception as e:
        logger.warning(f"Failed to record scan usage: {e}")


def check_machine_limit(machine_id: str) -> dict:
    """
    Check if adding a machine is allowed under current limits.

    Args:
        machine_id: Unique identifier for the machine

    Returns:
        Dict with 'allowed' (bool), 'message' (str), machine counts
    """
    if BYPASS_BETA_CHECKS:
        return {'allowed': True, 'message': 'Beta checks bypassed'}

    from services_pkg.services.beta_licensing import get_beta_license_service
    service = get_beta_license_service()
    return service.check_machine_allowed(machine_id)


def get_beta_status() -> dict:
    """Get current beta license status."""
    from services_pkg.services.beta_licensing import get_beta_license_service
    service = get_beta_license_service()
    return service.get_status()


def is_beta_valid() -> bool:
    """Quick check if beta license is valid."""
    if BYPASS_BETA_CHECKS:
        return True

    status = get_beta_status()
    return status.get('valid', False)
