"""
Beta/Early Access Licensing Module

Provides additional controls for beta and early release phases:
1. Beta tier with time-limited access
2. Build date expiration (software expires after N days from build)
3. Scan/audit count limits per time period
4. Beta registration requirement
5. Optional telemetry for usage feedback
6. License validation callbacks
7. Remote kill-switch capability

Usage Scenarios:
- Private Beta: Invite-only keys, 90-day expiry, 100 machines
- Public Beta: Free registration, 30-day trial, 25 machines
- Early Access: Discounted paid tier, extended features

Author: Security Audit Toolkit Team
Date: March 2026
"""

import os
import json
import hashlib
import hmac
import secrets
import platform
import shutil
import subprocess  # nosec B404
import urllib.request
import urllib.error
import ssl
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict, field
from enum import Enum
import logging

logger = logging.getLogger(__name__)


def _resolve_executable(executable: str) -> str:
    """Resolve executable path when available."""
    resolved = shutil.which(executable)
    return resolved or executable


def _run_platform_command(command: List[str], timeout: int = 5):
    """Run trusted platform inspection commands with normalized executable path."""
    safe_command = list(command)
    safe_command[0] = _resolve_executable(safe_command[0])
    return subprocess.run(  # nosec B603
        safe_command,
        capture_output=True,
        text=True,
        timeout=timeout,
    )

# ============================================================================
# Beta Constants
# ============================================================================

# Software build date (updated during release process)
BUILD_DATE = "2026-02-18"
BUILD_VERSION = "5.1.5"

# Beta program configuration
BETA_PROGRAM = {
    'enabled': True,
    'program_name': 'Security Audit Toolkit Beta',
    'program_version': '1.0',

    # Beta period settings
    'beta_start_date': '2026-02-01',
    'beta_end_date': '2026-06-30',  # Hard cutoff for beta program

    # Build expiration (days after BUILD_DATE the software stops working)
    'build_expires_days': 120,

    # License server for validation
    'license_server': os.environ.get('LICENSE_SERVER_URL', ''),
    'require_online_validation': False,  # If True, requires periodic phone-home

    # Telemetry settings
    'telemetry_enabled': False,  # Opt-in telemetry
    'telemetry_endpoint': os.environ.get('TELEMETRY_ENDPOINT', ''),
}


class BetaTier(Enum):
    """Beta-specific license tiers."""
    PRIVATE_BETA = "private_beta"       # Invite-only
    PUBLIC_BETA = "public_beta"         # Free registration
    EARLY_ACCESS = "early_access"       # Paid early supporter
    INTERNAL = "internal"               # Internal testing
    EXPIRED = "expired"                 # Expired beta


@dataclass
class BetaLicense:
    """Beta license information."""
    tier: BetaTier
    key: Optional[str] = None
    email: Optional[str] = None
    organization: Optional[str] = None
    issued: Optional[datetime] = None
    expires: Optional[datetime] = None
    hardware_id: Optional[str] = None
    features: List[str] = field(default_factory=list)
    usage_limits: Dict[str, int] = field(default_factory=dict)
    registration_id: Optional[str] = None

    @property
    def is_valid(self) -> bool:
        """Check if beta license is still valid."""
        if self.tier == BetaTier.EXPIRED:
            return False
        if self.expires and datetime.utcnow() > self.expires:
            return False
        return True

    @property
    def days_remaining(self) -> int:
        """Days remaining until license expires."""
        if not self.expires:
            return -1  # No expiration
        delta = self.expires - datetime.utcnow()
        return max(0, delta.days)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tier": self.tier.value,
            "key": self.key,
            "email": self.email,
            "organization": self.organization,
            "issued": self.issued.isoformat() if self.issued else None,
            "expires": self.expires.isoformat() if self.expires else None,
            "hardware_id": self.hardware_id,
            "features": self.features,
            "usage_limits": self.usage_limits,
            "registration_id": self.registration_id,
            "is_valid": self.is_valid,
            "days_remaining": self.days_remaining,
        }


# Beta tier configurations
BETA_TIER_CONFIGS = {
    BetaTier.PRIVATE_BETA: {
        'machine_limit': 100,
        'scan_limit_daily': 500,
        'scan_limit_monthly': 5000,
        'duration_days': 90,
        'features': [
            'all_audits', 'scheduling', 'api_access',
            'priority_support', 'beta_features'
        ],
        'watermark': True,
        'telemetry_required': True,
    },
    BetaTier.PUBLIC_BETA: {
        'machine_limit': 25,
        'scan_limit_daily': 100,
        'scan_limit_monthly': 1000,
        'duration_days': 30,
        'features': ['core_audits', 'basic_scheduling'],
        'watermark': True,
        'telemetry_required': False,
    },
    BetaTier.EARLY_ACCESS: {
        'machine_limit': 250,
        'scan_limit_daily': 1000,
        'scan_limit_monthly': 10000,
        'duration_days': 365,
        'features': [
            'all_audits', 'scheduling', 'api_access',
            'siem_integration', 'priority_support'
        ],
        'watermark': False,
        'telemetry_required': False,
    },
    BetaTier.INTERNAL: {
        'machine_limit': float('inf'),
        'scan_limit_daily': float('inf'),
        'scan_limit_monthly': float('inf'),
        'duration_days': None,  # No expiration
        'features': ['all_features', 'debug_mode'],
        'watermark': False,
        'telemetry_required': False,
    },
}


class BetaLicenseService:
    """
    Manages beta licensing, usage tracking, and early access controls.
    """

    # Beta key prefix mapping
    KEY_PREFIXES = {
        "BETA": BetaTier.PUBLIC_BETA,
        "PBTA": BetaTier.PRIVATE_BETA,
        "EARL": BetaTier.EARLY_ACCESS,
        "INTL": BetaTier.INTERNAL,
    }

    # Secret for beta key generation
    BETA_SECRET = os.environ.get("BETA_LICENSE_SECRET", "beta-secret-change-in-prod-2026")

    def __init__(self, data_dir: Optional[str] = None):
        """Initialize beta license service."""
        if data_dir is None:
            data_dir = os.environ.get("LICENSE_DATA_DIR") or os.path.expanduser("~/.audit-tool")

        self.data_dir = Path(data_dir)
        self.beta_license_file = self.data_dir / "beta_license.json"
        self.usage_file = self.data_dir / "beta_usage.json"
        self.revoked_keys_file = self.data_dir / "revoked_keys.json"

        self._ensure_data_dir()
        self._beta_license: Optional[BetaLicense] = None
        self._usage_data: Dict[str, Any] = {}
        self._revoked_keys: List[str] = []

        self._load_license()
        self._load_usage()
        self._load_revoked_keys()

    def _ensure_data_dir(self):
        """Create data directory if needed."""
        self.data_dir.mkdir(parents=True, exist_ok=True)
        if platform.system() != "Windows":
            os.chmod(self.data_dir, 0o700)

    # =========================================================================
    # Build Expiration Check
    # =========================================================================

    @staticmethod
    def check_build_expiration() -> Dict[str, Any]:
        """
        Check if the software build has expired.

        Returns dict with:
        - expired: bool
        - build_date: str
        - expires_date: str
        - days_remaining: int
        - message: str
        """
        try:
            build_date = datetime.strptime(BUILD_DATE, "%Y-%m-%d")
            expires_days = BETA_PROGRAM.get('build_expires_days', 120)
            expires_date = build_date + timedelta(days=expires_days)
            now = datetime.now()

            days_remaining = (expires_date - now).days
            is_expired = now > expires_date

            return {
                'expired': is_expired,
                'build_date': BUILD_DATE,
                'build_version': BUILD_VERSION,
                'expires_date': expires_date.strftime("%Y-%m-%d"),
                'days_remaining': max(0, days_remaining),
                'message': (
                    f"This beta build expires on {expires_date.strftime('%Y-%m-%d')}. "
                    f"{days_remaining} days remaining."
                ) if not is_expired else "This beta build has expired. Please update to a newer version.",
            }
        except Exception as e:
            logger.error(f"Build expiration check failed: {e}")
            # Fail open - don't block if check fails
            return {
                'expired': False,
                'build_date': BUILD_DATE,
                'build_version': BUILD_VERSION,
                'expires_date': 'unknown',
                'days_remaining': -1,
                'message': 'Unable to verify build expiration',
            }

    @staticmethod
    def check_beta_program_active() -> Dict[str, Any]:
        """
        Check if the beta program is currently active.

        Returns dict with program status.
        """
        if not BETA_PROGRAM.get('enabled'):
            return {
                'active': False,
                'message': 'Beta program is not enabled',
            }

        try:
            now = datetime.now()
            start = datetime.strptime(BETA_PROGRAM['beta_start_date'], "%Y-%m-%d")
            end = datetime.strptime(BETA_PROGRAM['beta_end_date'], "%Y-%m-%d")

            if now < start:
                return {
                    'active': False,
                    'message': f"Beta program starts on {BETA_PROGRAM['beta_start_date']}",
                    'starts_in_days': (start - now).days,
                }

            if now > end:
                return {
                    'active': False,
                    'message': f"Beta program ended on {BETA_PROGRAM['beta_end_date']}",
                    'ended': True,
                }

            return {
                'active': True,
                'message': 'Beta program is active',
                'days_remaining': (end - now).days,
                'end_date': BETA_PROGRAM['beta_end_date'],
            }
        except Exception as e:
            logger.error(f"Beta program check failed: {e}")
            return {'active': True, 'message': 'Beta program status unknown'}

    # =========================================================================
    # License Management
    # =========================================================================

    def _load_license(self):
        """Load beta license from file."""
        if not self.beta_license_file.exists():
            self._beta_license = None
            return

        try:
            with open(self.beta_license_file, 'r') as f:
                data = json.load(f)

            tier = BetaTier(data.get("tier", "public_beta"))
            expires = None
            issued = None

            if data.get("expires"):
                expires = datetime.fromisoformat(data["expires"].replace("Z", "+00:00"))
            if data.get("issued"):
                issued = datetime.fromisoformat(data["issued"].replace("Z", "+00:00"))

            self._beta_license = BetaLicense(
                tier=tier,
                key=data.get("key"),
                email=data.get("email"),
                organization=data.get("organization"),
                issued=issued,
                expires=expires,
                hardware_id=data.get("hardware_id"),
                features=data.get("features", []),
                usage_limits=data.get("usage_limits", {}),
                registration_id=data.get("registration_id"),
            )

            # Check if license is expired
            if not self._beta_license.is_valid:
                logger.warning("Beta license has expired")
                self._beta_license.tier = BetaTier.EXPIRED

        except Exception as e:
            logger.error(f"Failed to load beta license: {e}")
            self._beta_license = None

    def _save_license(self):
        """Save beta license to file."""
        if not self._beta_license:
            if self.beta_license_file.exists():
                self.beta_license_file.unlink()
            return

        data = self._beta_license.to_dict()
        with open(self.beta_license_file, 'w') as f:
            json.dump(data, f, indent=2)

        if platform.system() != "Windows":
            os.chmod(self.beta_license_file, 0o600)

    def _load_usage(self):
        """Load usage tracking data."""
        if not self.usage_file.exists():
            self._usage_data = {
                'scans_today': 0,
                'scans_this_month': 0,
                'machines_registered': [],
                'last_scan_date': None,
                'last_month': None,
            }
            return

        try:
            with open(self.usage_file, 'r') as f:
                self._usage_data = json.load(f)

            # Reset daily/monthly counters if needed
            today = datetime.now().strftime("%Y-%m-%d")
            this_month = datetime.now().strftime("%Y-%m")

            if self._usage_data.get('last_scan_date') != today:
                self._usage_data['scans_today'] = 0
                self._usage_data['last_scan_date'] = today

            if self._usage_data.get('last_month') != this_month:
                self._usage_data['scans_this_month'] = 0
                self._usage_data['last_month'] = this_month

        except Exception as e:
            logger.error(f"Failed to load usage data: {e}")
            self._usage_data = {}

    def _save_usage(self):
        """Save usage tracking data."""
        with open(self.usage_file, 'w') as f:
            json.dump(self._usage_data, f, indent=2)

    def _load_revoked_keys(self):
        """Load list of revoked license keys."""
        self._revoked_keys = []

        # Local revocation list
        if self.revoked_keys_file.exists():
            try:
                with open(self.revoked_keys_file, 'r') as f:
                    self._revoked_keys = json.load(f)
            except Exception as revoked_read_error:
                logger.debug(f"Unable to load revoked keys file {self.revoked_keys_file}: {revoked_read_error}")

    def is_key_revoked(self, key: str) -> bool:
        """Check if a license key has been revoked."""
        key_hash = hashlib.sha256(key.encode()).hexdigest()
        return key_hash in self._revoked_keys or key in self._revoked_keys

    # =========================================================================
    # Beta Registration & Activation
    # =========================================================================

    def register_beta(self, email: str, organization: str = "",
                      tier: BetaTier = BetaTier.PUBLIC_BETA) -> Dict[str, Any]:
        """
        Register for beta access.

        Args:
            email: User's email address
            organization: Optional organization name
            tier: Beta tier (default: public beta)

        Returns:
            Dict with registration result and beta key
        """
        # Check beta program status
        program_status = self.check_beta_program_active()
        if not program_status.get('active'):
            return {
                'success': False,
                'message': program_status.get('message', 'Beta program not active'),
            }

        # Generate beta key
        beta_key = self.generate_beta_key(tier, email)

        # Get hardware fingerprint
        hardware_id = self._get_hardware_fingerprint()

        # Get tier config
        tier_config = BETA_TIER_CONFIGS.get(tier, BETA_TIER_CONFIGS[BetaTier.PUBLIC_BETA])
        duration = tier_config.get('duration_days')

        now = datetime.utcnow()
        expires = now + timedelta(days=duration) if duration else None

        # Create license
        self._beta_license = BetaLicense(
            tier=tier,
            key=beta_key,
            email=email,
            organization=organization,
            issued=now,
            expires=expires,
            hardware_id=hardware_id,
            features=tier_config.get('features', []),
            usage_limits={
                'machine_limit': tier_config.get('machine_limit', 25),
                'scan_limit_daily': tier_config.get('scan_limit_daily', 100),
                'scan_limit_monthly': tier_config.get('scan_limit_monthly', 1000),
            },
            registration_id=secrets.token_hex(8),
        )

        self._save_license()

        logger.info(f"Beta registration: {email} ({tier.value})")

        return {
            'success': True,
            'message': f'Beta access granted ({tier.value})',
            'beta_key': beta_key,
            'expires': expires.isoformat() if expires else None,
            'days_remaining': self._beta_license.days_remaining,
            'features': tier_config.get('features', []),
            'usage_limits': self._beta_license.usage_limits,
        }

    def activate_beta_key(self, beta_key: str) -> Dict[str, Any]:
        """
        Activate a beta license key.

        Args:
            beta_key: Beta license key (format: XXXX-XXXX-XXXX-XXXX-XXXX)

        Returns:
            Dict with activation result
        """
        # Check if key is revoked
        if self.is_key_revoked(beta_key):
            return {
                'success': False,
                'message': 'This beta key has been revoked',
            }

        # Validate key format
        import re
        if not re.match(r'^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$', beta_key):
            return {
                'success': False,
                'message': 'Invalid beta key format. Expected: XXXX-XXXX-XXXX-XXXX-XXXX',
            }

        # Validate key signature
        validation = self._validate_beta_key(beta_key)
        if not validation['valid']:
            return {
                'success': False,
                'message': 'Invalid beta key',
            }

        tier = validation['tier']
        tier_config = BETA_TIER_CONFIGS.get(tier, BETA_TIER_CONFIGS[BetaTier.PUBLIC_BETA])
        duration = tier_config.get('duration_days')

        now = datetime.utcnow()
        expires = now + timedelta(days=duration) if duration else None

        self._beta_license = BetaLicense(
            tier=tier,
            key=beta_key,
            issued=now,
            expires=expires,
            hardware_id=self._get_hardware_fingerprint(),
            features=tier_config.get('features', []),
            usage_limits={
                'machine_limit': tier_config.get('machine_limit', 25),
                'scan_limit_daily': tier_config.get('scan_limit_daily', 100),
                'scan_limit_monthly': tier_config.get('scan_limit_monthly', 1000),
            },
        )

        self._save_license()

        return {
            'success': True,
            'message': f'Beta key activated ({tier.value})',
            'tier': tier.value,
            'expires': expires.isoformat() if expires else None,
            'days_remaining': self._beta_license.days_remaining,
        }

    # =========================================================================
    # Key Generation & Validation
    # =========================================================================

    @classmethod
    def generate_beta_key(cls, tier: BetaTier, identifier: str = "") -> str:
        """
        Generate a beta license key.

        Key format: TTTT-XXXX-XXXX-XXXX-SSSS
        - TTTT: Tier prefix
        - XXXX-XXXX-XXXX: Random identifier (12 chars)
        - SSSS: Signature (first 4 chars of HMAC)
        """
        prefix_map = {
            BetaTier.PUBLIC_BETA: "BETA",
            BetaTier.PRIVATE_BETA: "PBTA",
            BetaTier.EARLY_ACCESS: "EARL",
            BetaTier.INTERNAL: "INTL",
        }

        prefix = prefix_map.get(tier, "BETA")

        # Include identifier hash in randomness for uniqueness
        random_seed = f"{secrets.token_hex(6)}{hashlib.sha256(identifier.encode()).hexdigest()[:6]}"
        random_id = random_seed[:12].upper()

        # Format: XXXX-XXXX-XXXX
        parts = [random_id[i:i+4] for i in range(0, 12, 4)]

        # Generate signature
        key_data = f"{prefix}-{'-'.join(parts)}"
        signature = hmac.new(
            cls.BETA_SECRET.encode(),
            key_data.encode(),
            hashlib.sha256
        ).hexdigest()[:4].upper()

        return f"{prefix}-{'-'.join(parts)}-{signature}"

    def _validate_beta_key(self, key: str) -> Dict[str, Any]:
        """Validate beta key signature."""
        parts = key.split("-")
        if len(parts) != 5:
            return {'valid': False}

        prefix = parts[0]
        if prefix not in self.KEY_PREFIXES:
            return {'valid': False}

        # Verify signature
        key_data = f"{parts[0]}-{parts[1]}-{parts[2]}-{parts[3]}"
        expected_sig = hmac.new(
            self.BETA_SECRET.encode(),
            key_data.encode(),
            hashlib.sha256
        ).hexdigest()[:4].upper()

        if parts[4] != expected_sig:
            return {'valid': False}

        return {
            'valid': True,
            'tier': self.KEY_PREFIXES[prefix],
        }

    def _get_hardware_fingerprint(self) -> str:
        """Generate hardware fingerprint."""
        components = [
            platform.node(),
            platform.system(),
            platform.machine(),
        ]

        # Try to get machine-id (platform-specific)
        try:
            if platform.system() == "Windows":
                # Windows: Use WMIC
                result = _run_platform_command(
                    ["wmic", "csproduct", "get", "uuid"],
                    timeout=5,
                )
                for line in result.stdout.strip().split('\n'):
                    if line.strip() and line.strip() != "UUID":
                        components.append(line.strip())
                        break
            elif platform.system() == "Darwin":
                # macOS: Use ioreg
                result = _run_platform_command(
                    ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                    timeout=5,
                )
                for line in result.stdout.split('\n'):
                    if 'IOPlatformUUID' in line:
                        components.append(line.split('"')[1])
                        break
            else:
                # Linux/Unix: Use machine-id files
                for path in ['/etc/machine-id', '/var/lib/dbus/machine-id']:
                    if os.path.exists(path):
                        with open(path, 'r') as f:
                            components.append(f.read().strip())
                        break
        except Exception as hardware_id_error:
            logger.debug(f"Hardware fingerprint machine-id probe failed: {hardware_id_error}")

        return hashlib.sha256(":".join(components).encode()).hexdigest()[:32]

    # =========================================================================
    # Usage Tracking
    # =========================================================================

    def check_scan_allowed(self) -> Dict[str, Any]:
        """
        Check if a scan is allowed under current license limits.

        Returns dict with:
        - allowed: bool
        - message: str
        - remaining_today: int
        - remaining_month: int
        """
        if not self._beta_license or not self._beta_license.is_valid:
            return {
                'allowed': False,
                'message': 'No valid beta license. Please register or activate a beta key.',
            }

        limits = self._beta_license.usage_limits
        daily_limit = limits.get('scan_limit_daily', float('inf'))
        monthly_limit = limits.get('scan_limit_monthly', float('inf'))

        scans_today = self._usage_data.get('scans_today', 0)
        scans_month = self._usage_data.get('scans_this_month', 0)

        if daily_limit != float('inf') and scans_today >= daily_limit:
            return {
                'allowed': False,
                'message': f'Daily scan limit reached ({daily_limit} scans/day)',
                'remaining_today': 0,
                'remaining_month': max(0, monthly_limit - scans_month) if monthly_limit != float('inf') else -1,
            }

        if monthly_limit != float('inf') and scans_month >= monthly_limit:
            return {
                'allowed': False,
                'message': f'Monthly scan limit reached ({monthly_limit} scans/month)',
                'remaining_today': max(0, daily_limit - scans_today) if daily_limit != float('inf') else -1,
                'remaining_month': 0,
            }

        return {
            'allowed': True,
            'message': 'Scan allowed',
            'remaining_today': max(0, daily_limit - scans_today) if daily_limit != float('inf') else -1,
            'remaining_month': max(0, monthly_limit - scans_month) if monthly_limit != float('inf') else -1,
        }

    def record_scan(self, machine_id: str = None):
        """Record a scan for usage tracking."""
        self._usage_data['scans_today'] = self._usage_data.get('scans_today', 0) + 1
        self._usage_data['scans_this_month'] = self._usage_data.get('scans_this_month', 0) + 1
        self._usage_data['total_scans'] = self._usage_data.get('total_scans', 0) + 1

        if machine_id:
            machines = self._usage_data.get('machines_registered', [])
            if machine_id not in machines:
                machines.append(machine_id)
                self._usage_data['machines_registered'] = machines

        self._save_usage()

    def check_machine_allowed(self, machine_id: str) -> Dict[str, Any]:
        """Check if adding a machine is allowed under license limits."""
        if not self._beta_license or not self._beta_license.is_valid:
            return {
                'allowed': False,
                'message': 'No valid beta license',
            }

        machines = self._usage_data.get('machines_registered', [])
        limit = self._beta_license.usage_limits.get('machine_limit', 25)

        # Already registered
        if machine_id in machines:
            return {
                'allowed': True,
                'message': 'Machine already registered',
                'machines_used': len(machines),
                'machines_limit': limit if limit != float('inf') else 'unlimited',
            }

        # Check limit
        if limit != float('inf') and len(machines) >= limit:
            return {
                'allowed': False,
                'message': f'Machine limit reached ({limit} machines)',
                'machines_used': len(machines),
                'machines_limit': limit,
            }

        return {
            'allowed': True,
            'message': 'Machine can be registered',
            'machines_used': len(machines),
            'machines_limit': limit if limit != float('inf') else 'unlimited',
        }

    # =========================================================================
    # Status & Info
    # =========================================================================

    def get_status(self) -> Dict[str, Any]:
        """Get complete beta license status."""
        build_status = self.check_build_expiration()
        program_status = self.check_beta_program_active()

        if build_status.get('expired'):
            return {
                'valid': False,
                'error': 'build_expired',
                'message': build_status['message'],
                'build': build_status,
                'program': program_status,
            }

        if not self._beta_license:
            return {
                'valid': False,
                'error': 'no_license',
                'message': 'No beta license found. Please register or activate a beta key.',
                'build': build_status,
                'program': program_status,
            }

        return {
            'valid': self._beta_license.is_valid,
            'license': self._beta_license.to_dict(),
            'usage': {
                'scans_today': self._usage_data.get('scans_today', 0),
                'scans_this_month': self._usage_data.get('scans_this_month', 0),
                'total_scans': self._usage_data.get('total_scans', 0),
                'machines_registered': len(self._usage_data.get('machines_registered', [])),
            },
            'limits': self._beta_license.usage_limits,
            'build': build_status,
            'program': program_status,
        }

    def deactivate(self) -> Dict[str, Any]:
        """Deactivate current beta license."""
        if self.beta_license_file.exists():
            self.beta_license_file.unlink()

        self._beta_license = None

        return {
            'success': True,
            'message': 'Beta license deactivated',
        }


# Global instance
_beta_service: Optional[BetaLicenseService] = None


def get_beta_license_service(data_dir: Optional[str] = None) -> BetaLicenseService:
    """Get or create global beta license service."""
    global _beta_service
    if _beta_service is None:
        _beta_service = BetaLicenseService(data_dir)
    return _beta_service
