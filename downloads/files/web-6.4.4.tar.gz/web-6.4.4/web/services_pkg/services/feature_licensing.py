"""
Feature-Based Licensing Module

Gates specific features based on license tier, user type, and activation keys.
Premium features (interactive sessions, fix scripts, etc.) require appropriate
license tiers or feature-specific activation keys.

Feature Categories:
1. Remote Session Features - SSH/WinRM interactive terminals
2. Remediation Features - Fix script execution, rollback
3. Integration Features - SIEM, ticketing, cloud providers
4. Advanced Audit Features - Custom audits, parallel execution
5. Analytics Features - Trending, predictive, ML-based
6. Compliance Features - CIS benchmarks, HIPAA, PCI-DSS

Activation Methods:
- License tier (Professional/Business/Enterprise)
- Feature activation key (per-feature unlock)
- Time-limited trial activation
- Beta program features

Author: Security Audit Toolkit Team
Date: March 2026
"""

import os
import json
import hashlib
import hmac
import secrets
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum
from functools import wraps
import logging

from flask import jsonify, session

logger = logging.getLogger(__name__)

ENTERPRISE_FEATURE_PACK_ADDON = "enterprise_feature_pack"
ENTERPRISE_FEATURE_PACK_MARKER = f"addon:{ENTERPRISE_FEATURE_PACK_ADDON}"
ADDON_MIN_BASE_TIER = "professional"

# ============================================================================
# Feature Definitions
# ============================================================================

class Feature(Enum):
    """Enumeration of all gated features."""

    # Remote Session Features
    SSH_INTERACTIVE = "ssh_interactive"             # Interactive SSH terminal
    WINRM_INTERACTIVE = "winrm_interactive"         # Interactive WinRM/PowerShell
    SESSION_RECORDING = "session_recording"         # Record terminal sessions
    SESSION_PLAYBACK = "session_playback"           # Playback recorded sessions
    MULTI_SESSION = "multi_session"                 # Multiple concurrent sessions

    # Remediation Features
    FIX_SCRIPTS_LINUX = "fix_scripts_linux"         # Linux fix execution
    FIX_SCRIPTS_WINDOWS = "fix_scripts_windows"     # Windows fix execution
    FIX_SCRIPTS_HYPERVISOR = "fix_scripts_hypervisor"  # ESXi/KVM/etc fixes
    FIX_ROLLBACK = "fix_rollback"                   # Rollback capability
    FIX_BATCH = "fix_batch"                         # Batch fix execution
    FIX_SCHEDULING = "fix_scheduling"               # Schedule fixes

    # Integration Features
    SIEM_INTEGRATION = "siem_integration"           # SIEM export/integration
    TICKETING_INTEGRATION = "ticketing_integration" # Jira, ServiceNow, etc.
    CLOUD_AWS = "cloud_aws"                         # AWS integration
    CLOUD_AZURE = "cloud_azure"                     # Azure integration
    CLOUD_GCP = "cloud_gcp"                         # GCP integration
    LDAP_AUTH = "ldap_auth"                         # LDAP/AD authentication
    OKTA_AUTH = "okta_auth"                         # Okta SSO
    ENTRA_AUTH = "entra_auth"                       # Microsoft Entra (Azure AD)

    # Advanced Audit Features
    CUSTOM_AUDITS = "custom_audits"                 # Create/edit custom audits
    PARALLEL_AUDIT = "parallel_audit"               # Parallel audit execution
    DIFFERENTIAL_AUDIT = "differential_audit"       # Differential/delta audits
    COMPLIANCE_MAPPING = "compliance_mapping"       # Map audits to compliance

    # Analytics Features
    TREND_ANALYTICS = "trend_analytics"             # Trend analysis
    PREDICTIVE_ANALYTICS = "predictive_analytics"  # ML-based predictions
    RISK_SCORING = "risk_scoring"                   # Risk score calculations
    CUSTOM_DASHBOARDS = "custom_dashboards"         # Custom dashboard widgets

    # Asset Discovery Features
    DIRECT_API_SCANS = "direct_api_scans"           # Direct Agent API scan workflows
    ADVANCED_CVE_REPORTING = "advanced_cve_reporting"  # CVE drill-down and report generation

    # Compliance Features
    CIS_BENCHMARKS = "cis_benchmarks"               # CIS benchmark audits
    HIPAA_COMPLIANCE = "hipaa_compliance"           # HIPAA compliance reports
    PCI_DSS = "pci_dss"                             # PCI-DSS compliance
    SOC2_COMPLIANCE = "soc2_compliance"             # SOC 2 compliance
    ISO27001 = "iso27001"                           # ISO 27001 compliance

    # Enterprise Features
    MULTI_TENANT = "multi_tenant"                   # Multi-tenancy support
    RBAC_ADVANCED = "rbac_advanced"                 # Advanced RBAC
    AUDIT_TRAIL = "audit_trail"                     # Full audit trail
    API_UNLIMITED = "api_unlimited"                 # Unlimited API calls
    AGENT_UNLIMITED = "agent_unlimited"             # Unlimited agents

    # ==========================================================================
    # Hypervisor Features - MAJOR DIFFERENTIATOR (Not available in Free tier)
    # ==========================================================================
    # This is a key competitive advantage - must be licensed

    # Core Hypervisor Access (Professional+)
    HYPERVISOR_VIEW = "hypervisor_view"             # View hypervisor tab & list
    HYPERVISOR_ADD = "hypervisor_add"               # Add/configure hypervisors
    HYPERVISOR_AUDIT_BASIC = "hypervisor_audit_basic"  # Basic audits (limited platforms)

    # Advanced Hypervisor Features (Enterprise only)
    HYPERVISOR_AUDIT_ADVANCED = "hypervisor_audit_advanced"  # All platforms, advanced checks
    HYPERVISOR_DISCOVERY = "hypervisor_discovery"   # VM/container/storage discovery
    HYPERVISOR_REMEDIATION = "hypervisor_remediation"  # Fix script execution
    HYPERVISOR_BULK_OPERATIONS = "hypervisor_bulk_operations"  # Bulk audit/actions
    HYPERVISOR_SCHEDULING = "hypervisor_scheduling"  # Scheduled hypervisor audits

    # Hypervisor Agent Features (Enterprise only - prevents tool bypass)
    HYPERVISOR_AGENT_DOWNLOAD = "hypervisor_agent_download"   # Download hypervisor agent
    HYPERVISOR_AGENT_REGISTER = "hypervisor_agent_register"   # Register hypervisor agents
    HYPERVISOR_AGENT_MANAGE = "hypervisor_agent_manage"       # Manage hypervisor agents

    # ==========================================================================
    # Enterprise Reporting & Compliance Features (Milestone 1A)
    # ==========================================================================
    EVIDENCE_PACKAGER = "evidence_packager"          # Auditor-ready tamper-evident evidence bundles
    SARIF_EXPORT = "sarif_export"                    # SARIF 2.1.0 export for pipeline integration
    ADVANCED_REPORTING = "advanced_reporting"        # Completeness metadata + versioned report schema

    # ==========================================================================
    # Multi-Tool External Ingest (R1 Foundation)
    # ==========================================================================
    EXTERNAL_SOURCE_INGEST = "external_source_ingest"  # Register external producers and ingest findings

    # ==========================================================================
    # External Push Ingest (R2 — Data From Anywhere)
    # ==========================================================================
    EXTERNAL_DATA_PUSH = "external_data_push"    # Business+: push findings from any external tool
    EXTERNAL_ASSET_PUSH = "external_asset_push"  # Business + add-on: push asset/inventory records from CMDBs


class LicenseTier(Enum):
    """License tiers (mirrors main license service, revised Feb 2026)."""
    FREE = "free"
    TRIAL = "trial"               # 30-day trial with PROFESSIONAL features
    STARTER = "starter"           # New tier for SMBs (~$249/yr)
    PROFESSIONAL = "professional"  # ~$599/yr
    BUSINESS = "business"          # ~£2,499/yr
    ENTERPRISE = "enterprise"      # By separate agreement only


class UserRole(Enum):
    """User roles for role-based feature access.

    Must match Role class in models/user.py:
    - Viewer (1): Read-only access to reports and dashboard
    - Operator (2): Can run audits and view servers
    - Analyst (3): Plans, schedules, discovery, exports
    - Admin (4): User/server management, settings
    - SecurityAdmin (5): Password resets, account unlocks, user security
    - SuperAdmin (6): Full system control, remediation
    """
    VIEWER = "Viewer"
    OPERATOR = "Operator"
    ANALYST = "Analyst"     # Level 3 - plans, schedules, deploy scripts
    ADMIN = "Admin"
    SECURITY_ADMIN = "SecurityAdmin"  # Level 5 - user/password management
    SUPERADMIN = "SuperAdmin"


# ============================================================================
# Feature Configuration
# ============================================================================

# Feature -> Required tier mapping
# Format: {Feature: {'min_tier': LicenseTier, 'min_role': UserRole, 'requires_key': bool}}
FEATURE_CONFIG: Dict[Feature, Dict[str, Any]] = {
    # Remote Sessions - SuperAdmin-gated admin tool access
    Feature.SSH_INTERACTIVE: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Interactive SSH terminal sessions (add-on restricted)',
        'category': 'remote_sessions',
        'risk_level': 'high',
    },
    Feature.WINRM_INTERACTIVE: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Interactive WinRM/PowerShell sessions (add-on restricted)',
        'category': 'remote_sessions',
        'risk_level': 'high',
    },
    Feature.SESSION_RECORDING: {
        'min_tier': LicenseTier.PROFESSIONAL,  # Moved from Business - compliance need
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'Record terminal sessions for compliance',
        'category': 'remote_sessions',
        'risk_level': 'low',
    },
    Feature.SESSION_PLAYBACK: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'Playback recorded sessions',
        'category': 'remote_sessions',
        'risk_level': 'low',
    },
    Feature.MULTI_SESSION: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'description': 'Multiple concurrent terminal sessions',
        'category': 'remote_sessions',
        'risk_level': 'medium',
    },

    # Remediation/Fix Features - Require SuperAdmin
    Feature.FIX_SCRIPTS_LINUX: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Execute Linux security fixes (add-on restricted)',
        'category': 'remediation',
        'risk_level': 'critical',
    },
    Feature.FIX_SCRIPTS_WINDOWS: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Execute Windows security fixes (add-on restricted)',
        'category': 'remediation',
        'risk_level': 'critical',
    },
    Feature.FIX_SCRIPTS_HYPERVISOR: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Execute hypervisor security fixes (add-on restricted)',
        'category': 'remediation',
        'risk_level': 'critical',
    },
    Feature.FIX_ROLLBACK: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Rollback applied fixes (add-on restricted)',
        'category': 'remediation',
        'risk_level': 'high',
    },
    Feature.FIX_BATCH: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Apply fixes to multiple servers at once',
        'category': 'remediation',
        'risk_level': 'critical',
    },
    Feature.FIX_SCHEDULING: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'description': 'Schedule fix execution',
        'category': 'remediation',
        'risk_level': 'high',
    },

    # Integration Features
    Feature.SIEM_INTEGRATION: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'trial_eligible': True,
        'trial_days': 30,
        'description': 'SIEM export and integration',
        'category': 'integrations',
        'risk_level': 'low',
    },
    Feature.TICKETING_INTEGRATION: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'Jira, ServiceNow integration',
        'category': 'integrations',
        'risk_level': 'low',
    },
    Feature.CLOUD_AWS: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'AWS cloud resource auditing',
        'category': 'integrations',
        'risk_level': 'medium',
    },
    Feature.CLOUD_AZURE: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'Azure cloud resource auditing',
        'category': 'integrations',
        'risk_level': 'medium',
    },
    Feature.CLOUD_GCP: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'GCP cloud resource auditing',
        'category': 'integrations',
        'risk_level': 'medium',
    },
    Feature.LDAP_AUTH: {
        'min_tier': LicenseTier.STARTER,  # Moved from Professional - needed for enterprise eval
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'LDAP/Active Directory authentication',
        'category': 'integrations',
        'risk_level': 'medium',
    },
    Feature.OKTA_AUTH: {
        'min_tier': LicenseTier.PROFESSIONAL,  # Moved from Business - modern auth standard
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'Okta SSO integration',
        'category': 'integrations',
        'risk_level': 'medium',
    },
    Feature.ENTRA_AUTH: {
        'min_tier': LicenseTier.PROFESSIONAL,  # Moved from Business - modern auth standard
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'Microsoft Entra ID (Azure AD) SSO',
        'category': 'integrations',
        'risk_level': 'medium',
    },

    # Advanced Audit Features
    Feature.CUSTOM_AUDITS: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'Create and edit custom audit scripts',
        'category': 'audits',
        'risk_level': 'medium',
    },
    Feature.PARALLEL_AUDIT: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.OPERATOR,
        'requires_key': False,
        'description': 'Execute audits in parallel',
        'category': 'audits',
        'risk_level': 'low',
    },
    Feature.DIFFERENTIAL_AUDIT: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.OPERATOR,
        'requires_key': False,
        'description': 'Compare audit results over time',
        'category': 'audits',
        'risk_level': 'low',
    },
    Feature.COMPLIANCE_MAPPING: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ANALYST,  # Analysts map findings to frameworks
        'requires_key': False,
        'description': 'Map audit results to compliance frameworks',
        'category': 'audits',
        'risk_level': 'low',
    },

    # Analytics Features
    Feature.TREND_ANALYTICS: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ANALYST,  # Analysts perform trend analysis
        'requires_key': False,
        'description': 'Security trend analysis',
        'category': 'analytics',
        'risk_level': 'low',
    },
    Feature.PREDICTIVE_ANALYTICS: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'ML-based predictive analytics',
        'category': 'analytics',
        'risk_level': 'low',
    },
    Feature.RISK_SCORING: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.OPERATOR,
        'requires_key': False,
        'description': 'Risk score calculations',
        'category': 'analytics',
        'risk_level': 'low',
    },
    Feature.CUSTOM_DASHBOARDS: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ANALYST,  # Analysts create dashboards for reporting
        'requires_key': False,
        'description': 'Create custom dashboard widgets',
        'category': 'analytics',
        'risk_level': 'low',
    },

    # Asset Discovery Features
    Feature.DIRECT_API_SCANS: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ANALYST,
        'requires_key': False,
        'description': 'Direct Agent API scan workflows and direct API report views',
        'category': 'asset_discovery',
        'risk_level': 'medium',
    },
    Feature.ADVANCED_CVE_REPORTING: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ANALYST,
        'requires_key': False,
        'description': 'Advanced CVE drill-down and software update reporting',
        'category': 'asset_discovery',
        'risk_level': 'low',
    },

    # Compliance Features
    Feature.CIS_BENCHMARKS: {
        'min_tier': LicenseTier.STARTER,  # Moved from Professional - entry compliance
        'min_role': UserRole.OPERATOR,
        'requires_key': False,
        'description': 'CIS benchmark compliance audits',
        'category': 'compliance',
        'risk_level': 'low',
    },
    Feature.HIPAA_COMPLIANCE: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'HIPAA compliance reports',
        'category': 'compliance',
        'risk_level': 'low',
    },
    Feature.PCI_DSS: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'PCI-DSS compliance reports',
        'category': 'compliance',
        'risk_level': 'low',
    },
    Feature.SOC2_COMPLIANCE: {
        'min_tier': LicenseTier.BUSINESS,  # Moved from Enterprise - compliance market
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'SOC 2 compliance reports',
        'category': 'compliance',
        'risk_level': 'low',
    },
    Feature.ISO27001: {
        'min_tier': LicenseTier.BUSINESS,  # Moved from Enterprise - compliance market
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'ISO 27001 compliance reports',
        'category': 'compliance',
        'risk_level': 'low',
    },

    # Enterprise Features
    Feature.MULTI_TENANT: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Multi-tenant environment support',
        'category': 'enterprise',
        'risk_level': 'medium',
    },
    Feature.RBAC_ADVANCED: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'Advanced RBAC with custom roles',
        'category': 'enterprise',
        'risk_level': 'medium',
    },
    Feature.AUDIT_TRAIL: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'description': 'Full audit trail logging',
        'category': 'enterprise',
        'risk_level': 'low',
    },
    Feature.API_UNLIMITED: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Unlimited API calls',
        'category': 'enterprise',
        'risk_level': 'low',
    },
    Feature.AGENT_UNLIMITED: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Unlimited agent deployments',
        'category': 'enterprise',
        'risk_level': 'medium',
    },

    # ==========================================================================
    # HYPERVISOR FEATURES - Major Competitive Differentiator
    # ==========================================================================
    # Tiered access:
    # - FREE: No access (beta testing only with BETA_HYPERVISOR_ENABLED flag)
    # - PROFESSIONAL: Basic audits, ESXi/Hyper-V only, max 3 hypervisors
    # - ENTERPRISE: All platforms, unlimited, agents, discovery, remediation
    # ==========================================================================

    # Professional Tier - Basic Hypervisor Access
    Feature.HYPERVISOR_VIEW: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.OPERATOR,
        'requires_key': False,
        'trial_eligible': True,
        'trial_days': 14,
        'description': 'View hypervisor management tab and list',
        'category': 'hypervisor',
        'risk_level': 'low',
        'limits': {
            'professional': {'max_hypervisors': 5, 'platforms': ['esxi', 'hyperv', 'proxmox']},
            'business': {'max_hypervisors': 20, 'platforms': ['esxi', 'hyperv', 'proxmox', 'kvm']},
            'enterprise': {'max_hypervisors': None, 'platforms': 'all'},  # Unlimited
        },
    },
    Feature.HYPERVISOR_ADD: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'trial_eligible': True,
        'trial_days': 14,
        'description': 'Add and configure hypervisors',
        'category': 'hypervisor',
        'risk_level': 'medium',
        'limits': {
            'professional': {'max_hypervisors': 5},
            'business': {'max_hypervisors': 20},
            'enterprise': {'max_hypervisors': None},
        },
    },
    Feature.HYPERVISOR_AUDIT_BASIC: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.OPERATOR,
        'requires_key': False,
        'trial_eligible': True,
        'trial_days': 14,
        'description': 'Run basic security audits on hypervisors',
        'category': 'hypervisor',
        'risk_level': 'low',
        'audit_types': ['security_baseline', 'configuration'],
        'limits': {
            'professional': {'audits_per_day': 10, 'platforms': ['esxi', 'hyperv', 'proxmox']},
            'business': {'audits_per_day': 50, 'platforms': ['esxi', 'hyperv', 'proxmox', 'kvm']},
            'enterprise': {'audits_per_day': None, 'platforms': 'all'},
        },
    },

    # Enterprise Tier - Advanced Hypervisor Features
    Feature.HYPERVISOR_AUDIT_ADVANCED: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.OPERATOR,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Advanced audits: CIS benchmarks, compliance, all platforms',
        'category': 'hypervisor',
        'risk_level': 'low',
        'audit_types': ['cis_benchmark', 'compliance', 'vulnerability', 'hardening'],
    },
    Feature.HYPERVISOR_DISCOVERY: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.OPERATOR,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Discover VMs, containers, storage, and networks',
        'category': 'hypervisor',
        'risk_level': 'low',
    },
    Feature.HYPERVISOR_REMEDIATION: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': True,  # Requires explicit activation (high risk)
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Execute fix scripts on hypervisors',
        'category': 'hypervisor',
        'risk_level': 'critical',
    },
    Feature.HYPERVISOR_BULK_OPERATIONS: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Bulk audit and management across multiple hypervisors',
        'category': 'hypervisor',
        'risk_level': 'medium',
    },
    Feature.HYPERVISOR_SCHEDULING: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Schedule recurring hypervisor audits',
        'category': 'hypervisor',
        'risk_level': 'low',
    },

    # Hypervisor Agent Features - Business tier (moved from Enterprise)
    # These features allow direct hypervisor management
    Feature.HYPERVISOR_AGENT_DOWNLOAD: {
        'min_tier': LicenseTier.BUSINESS,  # Moved from Enterprise - major differentiator
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'trial_eligible': True,  # Allow trial to showcase value
        'trial_days': 14,
        'description': 'Download hypervisor agent packages',
        'category': 'hypervisor',
        'risk_level': 'high',
        'rate_limit': {'per_day': 5, 'per_month': 20},
        'audit_required': True,
    },
    Feature.HYPERVISOR_AGENT_REGISTER: {
        'min_tier': LicenseTier.BUSINESS,  # Moved from Enterprise
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'trial_eligible': True,
        'trial_days': 14,
        'description': 'Register hypervisor agents with the server',
        'category': 'hypervisor',
        'risk_level': 'high',
        'rate_limit': {'per_day': 10, 'per_month': 50},
        'audit_required': True,
    },
    Feature.HYPERVISOR_AGENT_MANAGE: {
        'min_tier': LicenseTier.BUSINESS,  # Moved from Enterprise
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'trial_eligible': False,
        'description': 'Manage and configure hypervisor agents',
        'category': 'hypervisor',
        'risk_level': 'medium',
        'audit_required': True,
    },

    # Enterprise Reporting & Compliance (Milestone 1A) -------------------------
    Feature.EVIDENCE_PACKAGER: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ANALYST,
        'requires_key': False,
        'trial_eligible': True,
        'trial_days': 14,
        'description': 'Auditor-ready tamper-evident evidence bundles with integrity verification and retention policy',
        'category': 'compliance',
        'risk_level': 'low',
    },
    Feature.SARIF_EXPORT: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ANALYST,
        'requires_key': False,
        'trial_eligible': True,
        'trial_days': 14,
        'description': 'Export audit findings as SARIF 2.1.0 for GitHub Code Scanning and DevSecOps pipelines',
        'category': 'reporting',
        'risk_level': 'low',
    },
    Feature.ADVANCED_REPORTING: {
        'min_tier': LicenseTier.PROFESSIONAL,
        'min_role': UserRole.ANALYST,
        'requires_key': False,
        'trial_eligible': True,
        'trial_days': 14,
        'description': 'Completeness/confidence metadata and versioned report schema for external consumers',
        'category': 'reporting',
        'risk_level': 'low',
    },

    # Multi-Tool External Ingest (R1 Foundation) --------------------------------
    Feature.EXTERNAL_SOURCE_INGEST: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.SUPERADMIN,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': 'Register external data producers and ingest findings from third-party tools (CMDB, scanners, CI pipelines). Requires Business tier plus Advanced Operations Pack add-on.',
        'category': 'enterprise',
        'risk_level': 'medium',
    },

    # External Push Ingest (R2 - Data From Anywhere) ----------------------------
    Feature.EXTERNAL_DATA_PUSH: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'trial_eligible': True,
        'trial_days': 14,
        'description': (
            'Push security findings from external scanners, CI pipelines, and third-party tools '
            'directly into the database via authenticated API. No agent required. '
            'Included with Business tier and above.'
        ),
        'category': 'enterprise',
        'risk_level': 'medium',
    },
    Feature.EXTERNAL_ASSET_PUSH: {
        'min_tier': LicenseTier.BUSINESS,
        'min_role': UserRole.ADMIN,
        'requires_key': False,
        'trial_eligible': False,
        'requires_enterprise_feature_pack_addon': True,
        'description': (
            'Push asset and inventory records from CMDBs or cloud discovery feeds directly '
            'into the toolkit database. Requires Business tier plus Advanced Operations Pack add-on.'
        ),
        'category': 'enterprise',
        'risk_level': 'medium',
    },
}

# Tier hierarchy for comparison (revised Feb 2026)
# TRIAL gets same level as PROFESSIONAL (full feature access during trial)
TIER_HIERARCHY = {
    LicenseTier.FREE: 0,
    LicenseTier.STARTER: 1,        # New tier
    LicenseTier.TRIAL: 2,          # Trial = PROFESSIONAL level access
    LicenseTier.PROFESSIONAL: 2,
    LicenseTier.BUSINESS: 3,
    LicenseTier.ENTERPRISE: 4,
}

# Role hierarchy for comparison
# Must match Role.get_role_level() in models/user.py (1-6 scale)
ROLE_HIERARCHY = {
    UserRole.VIEWER: 1,
    UserRole.OPERATOR: 2,
    UserRole.ANALYST: 3,
    UserRole.ADMIN: 4,
    UserRole.SECURITY_ADMIN: 5,  # User/security admin but not system admin
    UserRole.SUPERADMIN: 6,
}


# ============================================================================
# Feature Activation Keys
# ============================================================================

@dataclass
class FeatureActivation:
    """Tracks activation of a specific feature."""
    feature: Feature
    activated_at: datetime
    expires_at: Optional[datetime]
    activation_key: Optional[str]
    activation_type: str  # 'license', 'key', 'trial', 'beta', 'grant'
    granted_by: Optional[str] = None
    notes: Optional[str] = None

    @property
    def is_active(self) -> bool:
        if self.expires_at is None:
            return True
        return datetime.utcnow() < self.expires_at

    @property
    def days_remaining(self) -> int:
        if self.expires_at is None:
            return -1
        delta = self.expires_at - datetime.utcnow()
        return max(0, delta.days)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'feature': self.feature.value,
            'activated_at': self.activated_at.isoformat(),
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'activation_key': self.activation_key[:8] + '...' if self.activation_key else None,
            'activation_type': self.activation_type,
            'granted_by': self.granted_by,
            'is_active': self.is_active,
            'days_remaining': self.days_remaining,
        }


class FeatureLicenseService:
    """
    Manages feature-based licensing and activation.
    """

    # Feature key prefix for HMAC validation
    FEATURE_KEY_PREFIX = "FEAT"
    KEY_SECRET = os.environ.get('FEATURE_KEY_SECRET', 'default-feature-key-secret-change-me')

    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or Path("data")
        self.data_dir.mkdir(exist_ok=True)

        self.feature_data_file = self.data_dir / "feature_activations.json"
        self.trial_data_file = self.data_dir / "feature_trials.json"

        # Thread-safe lock
        self._lock = threading.Lock()

        # Caches
        self._activations: Dict[str, List[FeatureActivation]] = {}  # user_id -> activations
        self._trials: Dict[str, Dict[str, datetime]] = {}  # user_id -> {feature: started}
        self._license_tier: Optional[LicenseTier] = None

        # Load data
        self._load_data()

    def _load_data(self):
        """Load activation and trial data from files."""
        try:
            if self.feature_data_file.exists():
                with open(self.feature_data_file, 'r') as f:
                    data = json.load(f)
                    for user_id, activations in data.items():
                        self._activations[user_id] = []
                        for act in activations:
                            try:
                                self._activations[user_id].append(FeatureActivation(
                                    feature=Feature(act['feature']),
                                    activated_at=datetime.fromisoformat(act['activated_at']),
                                    expires_at=datetime.fromisoformat(act['expires_at']) if act.get('expires_at') else None,
                                    activation_key=act.get('activation_key'),
                                    activation_type=act['activation_type'],
                                    granted_by=act.get('granted_by'),
                                    notes=act.get('notes'),
                                ))
                            except (KeyError, ValueError) as e:
                                logger.warning(f"Invalid activation entry: {e}")
        except Exception as e:
            logger.error(f"Failed to load feature activations: {e}")

        try:
            if self.trial_data_file.exists():
                with open(self.trial_data_file, 'r') as f:
                    data = json.load(f)
                    for user_id, trials in data.items():
                        self._trials[user_id] = {
                            k: datetime.fromisoformat(v) for k, v in trials.items()
                        }
        except Exception as e:
            logger.error(f"Failed to load trial data: {e}")

    def _save_data(self):
        """Persist activation and trial data to files."""
        try:
            with self._lock:
                # Save activations
                data = {}
                for user_id, activations in self._activations.items():
                    data[user_id] = []
                    for act in activations:
                        data[user_id].append({
                            'feature': act.feature.value,
                            'activated_at': act.activated_at.isoformat(),
                            'expires_at': act.expires_at.isoformat() if act.expires_at else None,
                            'activation_key': act.activation_key,
                            'activation_type': act.activation_type,
                            'granted_by': act.granted_by,
                            'notes': act.notes,
                        })

                with open(self.feature_data_file, 'w') as f:
                    json.dump(data, f, indent=2)

                # Save trials
                trial_data = {}
                for user_id, trials in self._trials.items():
                    trial_data[user_id] = {k: v.isoformat() for k, v in trials.items()}

                with open(self.trial_data_file, 'w') as f:
                    json.dump(trial_data, f, indent=2)

        except Exception as e:
            logger.error(f"Failed to save feature data: {e}")

    def get_current_license_tier(self) -> LicenseTier:
        """Get the currently active license tier."""
        # Try to get from main license service
        try:
            from web.services_pkg.services.license_service import LicenseService
            license_service = LicenseService()
            license_info = license_service.license_info  # property, not method
            return LicenseTier(license_info.tier.value)
        except Exception as tier_lookup_error:
            logger.warning(f"Unable to read tier from LicenseService, defaulting to FREE: {tier_lookup_error}")

        # Optional override is disabled by default to prevent unauthorized tier escalation.
        allow_env_override = os.environ.get('ALLOW_LICENSE_TIER_ENV_OVERRIDE', '').lower() in {
            '1', 'true', 'yes', 'on'
        }
        if allow_env_override:
            tier_str = os.environ.get('LICENSE_TIER', 'free').lower()
            try:
                return LicenseTier(tier_str)
            except ValueError:
                return LicenseTier.FREE

        return LicenseTier.FREE

    def get_current_user_role(self) -> Optional[UserRole]:
        """Get the current user's role from Flask context."""
        try:
            from flask_login import current_user
            if current_user.is_authenticated:
                role_str = getattr(current_user, 'role', 'Viewer')
                return UserRole(role_str)
        except Exception as user_role_error:
            logger.debug(f"Unable to resolve current user role from flask_login: {user_role_error}")

        # Try from session
        try:
            role_str = session.get('user_role', 'Viewer')
            return UserRole(role_str)
        except Exception:
            return None

    def tier_satisfies(self, required: LicenseTier, current: LicenseTier) -> bool:
        """Check if current tier meets or exceeds required tier."""
        return TIER_HIERARCHY.get(current, 0) >= TIER_HIERARCHY.get(required, 0)

    def _get_enterprise_addon_min_base_tier(self) -> LicenseTier:
        """Resolve minimum base tier required for enterprise feature-pack add-on."""
        configured = (os.environ.get('ENTERPRISE_ADDON_MIN_BASE_TIER', ADDON_MIN_BASE_TIER) or ADDON_MIN_BASE_TIER).strip().lower()
        try:
            resolved = LicenseTier(configured)
        except ValueError:
            return LicenseTier.PROFESSIONAL
        if TIER_HIERARCHY.get(resolved, 0) < TIER_HIERARCHY.get(LicenseTier.PROFESSIONAL, 0):
            return LicenseTier.PROFESSIONAL
        return resolved

    def _has_enterprise_feature_pack_addon(self) -> bool:
        """Check whether the active license includes the enterprise add-on marker."""
        try:
            from web.services_pkg.services.license_service import LicenseService

            license_info = LicenseService().license_info
            active_features = set(license_info.features or [])
            return ENTERPRISE_FEATURE_PACK_MARKER in active_features
        except Exception as addon_lookup_error:
            logger.debug(f"Unable to resolve enterprise add-on marker: {addon_lookup_error}")
            return False

    def role_satisfies(self, required: UserRole, current: UserRole) -> bool:
        """Check if current role meets or exceeds required role."""
        return ROLE_HIERARCHY.get(current, 0) >= ROLE_HIERARCHY.get(required, 0)

    # ========================================================================
    # Feature Key Generation/Validation
    # ========================================================================

    def generate_feature_key(self, feature: Feature, duration_days: Optional[int] = None,
                             org_id: Optional[str] = None) -> str:
        """
        Generate a feature activation key.

        Key format: FEAT-XXXX-XXXX-XXXX-<CHECKSUM>
        Where:
        - FEAT = prefix
        - XXXX blocks contain encoded feature + expiry + org
        - CHECKSUM = HMAC signature
        """
        now = datetime.utcnow()
        expires = (now + timedelta(days=duration_days)).isoformat() if duration_days else "PERP"

        payload = f"{feature.value}|{expires}|{org_id or 'ANY'}"
        payload_encoded = payload.encode('utf-8').hex()

        # Generate HMAC signature
        signature = hmac.new(
            self.KEY_SECRET.encode(),
            payload_encoded.encode(),
            hashlib.sha256
        ).hexdigest()[:8].upper()

        # Split payload into blocks
        blocks = []
        for i in range(0, min(len(payload_encoded), 16), 4):
            blocks.append(payload_encoded[i:i+4].upper())

        while len(blocks) < 4:
            blocks.append(secrets.token_hex(2).upper())

        key = f"{self.FEATURE_KEY_PREFIX}-{'-'.join(blocks)}-{signature}"
        return key

    def validate_feature_key(self, key: str, feature: Feature) -> Dict[str, Any]:
        """
        Validate a feature activation key.

        Returns:
            {
                'valid': bool,
                'feature': str,
                'expires': datetime or None,
                'org_id': str or None,
                'error': str (if invalid)
            }
        """
        result = {'valid': False, 'feature': None, 'expires': None, 'org_id': None}

        try:
            if not key.startswith(f"{self.FEATURE_KEY_PREFIX}-"):
                result['error'] = 'Invalid key prefix'
                return result

            parts = key.split('-')
            if len(parts) < 6:
                result['error'] = 'Invalid key format'
                return result

            # Extract payload and checksum
            payload_hex = ''.join(parts[1:5])
            provided_checksum = parts[5]

            # Verify checksum
            expected_checksum = hmac.new(
                self.KEY_SECRET.encode(),
                payload_hex.lower().encode(),
                hashlib.sha256
            ).hexdigest()[:8].upper()

            if provided_checksum.upper() != expected_checksum:
                result['error'] = 'Invalid key checksum'
                return result

            # Decode payload
            try:
                payload = bytes.fromhex(payload_hex.lower()).decode('utf-8')
                parts = payload.split('|')
                key_feature = parts[0]
                expires_str = parts[1] if len(parts) > 1 else 'PERP'
                org_id = parts[2] if len(parts) > 2 else None
            except Exception:
                # Key might use random padding - accept if checksum valid
                result['valid'] = True
                result['feature'] = feature.value
                return result

            # Validate feature matches
            if key_feature != feature.value:
                result['error'] = f'Key is for feature {key_feature}, not {feature.value}'
                return result

            # Check expiration
            expires = None
            if expires_str != 'PERP':
                try:
                    expires = datetime.fromisoformat(expires_str)
                    if expires < datetime.utcnow():
                        result['error'] = 'Key has expired'
                        return result
                except ValueError:
                    pass

            result['valid'] = True
            result['feature'] = key_feature
            result['expires'] = expires
            result['org_id'] = org_id if org_id != 'ANY' else None
            return result

        except Exception as e:
            result['error'] = f'Key validation error: {str(e)}'
            return result

    # ========================================================================
    # Feature Access Checks
    # ========================================================================

    def is_feature_available(self, feature: Feature, user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Check if a feature is available for the current license/user.

        Returns comprehensive status including:
        - available: bool
        - reason: why available/unavailable
        - activation_type: how it's activated
        - trial_eligible: if trial is available
        - upgrade_tier: what tier would unlock it
        """
        result = {
            'available': False,
            'feature': feature.value,
            'reason': None,
            'activation_type': None,
            'trial_eligible': False,
            'upgrade_tier': None,
            'expires': None,
        }

        # Check if feature bypass is enabled (testing-only safeguard)
        bypass_feature_checks = os.environ.get('BYPASS_FEATURE_CHECKS', '').lower() == 'true'
        is_non_production = os.environ.get('FLASK_ENV', '').lower() in {'development', 'testing'}

        if bypass_feature_checks and is_non_production:
            result['available'] = True
            result['reason'] = 'Feature checks bypassed'
            result['activation_type'] = 'bypass'
            return result
        elif bypass_feature_checks:
            logger.warning('Ignoring BYPASS_FEATURE_CHECKS outside development/testing runtime')

        config = FEATURE_CONFIG.get(feature)
        if not config:
            result['reason'] = 'Unknown feature'
            return result

        current_tier = self.get_current_license_tier()
        current_role = self.get_current_user_role()

        # Check role requirement
        min_role = config.get('min_role', UserRole.VIEWER)
        if current_role and not self.role_satisfies(min_role, current_role):
            result['reason'] = f'Requires {min_role.value} role or higher'
            result['required_role'] = min_role.value
            return result

        # Check if user has explicit activation
        if user_id:
            activations = self._activations.get(user_id, [])
            for act in activations:
                if act.feature == feature and act.is_active:
                    result['available'] = True
                    result['activation_type'] = act.activation_type
                    result['reason'] = f'Activated via {act.activation_type}'
                    result['expires'] = act.expires_at
                    return result

        # Check license tier
        min_tier = config.get('min_tier', LicenseTier.FREE)
        requires_enterprise_feature_pack_addon = bool(config.get('requires_enterprise_feature_pack_addon', False))
        addon_min_base_tier = self._get_enterprise_addon_min_base_tier()
        addon_base_tier = min_tier if TIER_HIERARCHY.get(min_tier, 0) >= TIER_HIERARCHY.get(addon_min_base_tier, 0) else addon_min_base_tier
        has_enterprise_addon = self._has_enterprise_feature_pack_addon()

        if self.tier_satisfies(min_tier, current_tier):
            if requires_enterprise_feature_pack_addon and not has_enterprise_addon:
                result['reason'] = (
                    f"Requires {addon_base_tier.value} tier plus advanced_operations_pack add-on"
                )
                result['upgrade_tier'] = f"{addon_base_tier.value}+advanced_operations_pack"
                result['trial_eligible'] = config.get('trial_eligible', False)
                return result

            if requires_enterprise_feature_pack_addon and has_enterprise_addon and not config.get('requires_key', False):
                result['available'] = True
                result['activation_type'] = 'addon'
                result['reason'] = 'Unlocked by Advanced Operations Pack add-on'
                result['upgrade_tier'] = None
                result['trial_eligible'] = False
                return result

            # Feature key required even with correct tier?
            if config.get('requires_key', False):
                result['reason'] = f'Feature requires activation key (tier {current_tier.value} sufficient)'
                result['trial_eligible'] = config.get('trial_eligible', False)
                result['upgrade_tier'] = None
            else:
                result['available'] = True
                result['activation_type'] = 'license'
                result['reason'] = f'Included in {current_tier.value} tier'
        else:
            addon_unlock = (
                min_tier == LicenseTier.ENTERPRISE
                and self.tier_satisfies(addon_min_base_tier, current_tier)
                and has_enterprise_addon
            )

            if addon_unlock:
                if config.get('requires_key', False):
                    result['reason'] = (
                        'Advanced Operations Pack add-on is active, but this feature still requires '
                        'an activation key'
                    )
                    result['trial_eligible'] = False
                    result['upgrade_tier'] = None
                else:
                    result['available'] = True
                    result['activation_type'] = 'addon'
                    result['reason'] = 'Unlocked by Advanced Operations Pack add-on'
                    result['upgrade_tier'] = None
                    result['trial_eligible'] = False
            else:
                if requires_enterprise_feature_pack_addon:
                    result['reason'] = (
                        f"Requires {addon_base_tier.value} tier plus advanced_operations_pack add-on"
                    )
                    result['upgrade_tier'] = f"{addon_base_tier.value}+advanced_operations_pack"
                elif min_tier == LicenseTier.ENTERPRISE:
                    result['reason'] = (
                        f"Requires enterprise tier or {addon_min_base_tier.value}+ "
                        'with advanced_operations_pack add-on'
                    )
                    result['upgrade_tier'] = f"{addon_min_base_tier.value}+advanced_operations_pack"
                else:
                    result['reason'] = f'Requires {min_tier.value} tier or higher'
                    result['upgrade_tier'] = min_tier.value
                result['trial_eligible'] = config.get('trial_eligible', False)

        return result

    def check_feature_access(self, feature: Feature, user_id: Optional[str] = None,
                             user_role: Optional[str] = None) -> bool:
        """Simple boolean check for feature access."""
        status = self.is_feature_available(feature, user_id)
        return status['available']

    # ========================================================================
    # Feature Activation
    # ========================================================================

    def activate_feature(self, feature: Feature, user_id: str, activation_key: str) -> Dict[str, Any]:
        """
        Activate a feature using an activation key.

        Returns:
            {'success': bool, 'message': str, 'activation': dict}
        """
        result = {'success': False, 'message': '', 'activation': None}

        # Validate the key
        validation = self.validate_feature_key(activation_key, feature)
        if not validation['valid']:
            result['message'] = validation.get('error', 'Invalid activation key')
            return result

        # Check role requirement
        config = FEATURE_CONFIG.get(feature)
        if config:
            current_role = self.get_current_user_role()
            min_role = config.get('min_role', UserRole.VIEWER)
            if current_role and not self.role_satisfies(min_role, current_role):
                result['message'] = f'Feature requires {min_role.value} role or higher'
                return result

        # Create activation record
        activation = FeatureActivation(
            feature=feature,
            activated_at=datetime.utcnow(),
            expires_at=validation.get('expires'),
            activation_key=activation_key,
            activation_type='key',
        )

        with self._lock:
            if user_id not in self._activations:
                self._activations[user_id] = []

            # Remove any existing activation for this feature
            self._activations[user_id] = [
                a for a in self._activations[user_id] if a.feature != feature
            ]
            self._activations[user_id].append(activation)

        self._save_data()

        result['success'] = True
        result['message'] = f'Feature {feature.value} activated successfully'
        result['activation'] = activation.to_dict()

        logger.info(f"Feature {feature.value} activated for user {user_id}")
        return result

    def start_trial(self, feature: Feature, user_id: str) -> Dict[str, Any]:
        """
        Start a free trial for a feature.

        Returns:
            {'success': bool, 'message': str, 'expires': datetime}
        """
        result = {'success': False, 'message': '', 'expires': None}

        config = FEATURE_CONFIG.get(feature)
        if not config:
            result['message'] = 'Unknown feature'
            return result

        if not config.get('trial_eligible', False):
            result['message'] = 'Feature is not eligible for trial'
            return result

        # Check if user already had a trial
        user_trials = self._trials.get(user_id, {})
        if feature.value in user_trials:
            result['message'] = 'Trial already used for this feature'
            result['previous_trial'] = user_trials[feature.value].isoformat()
            return result

        # Check role requirement
        current_role = self.get_current_user_role()
        min_role = config.get('min_role', UserRole.VIEWER)
        if current_role and not self.role_satisfies(min_role, current_role):
            result['message'] = f'Feature requires {min_role.value} role or higher'
            return result

        # Start trial
        trial_days = config.get('trial_days', 7)
        now = datetime.utcnow()
        expires = now + timedelta(days=trial_days)

        # Record trial usage
        with self._lock:
            if user_id not in self._trials:
                self._trials[user_id] = {}
            self._trials[user_id][feature.value] = now

        # Create activation
        activation = FeatureActivation(
            feature=feature,
            activated_at=now,
            expires_at=expires,
            activation_key=None,
            activation_type='trial',
        )

        with self._lock:
            if user_id not in self._activations:
                self._activations[user_id] = []
            self._activations[user_id].append(activation)

        self._save_data()

        result['success'] = True
        result['message'] = f'{trial_days}-day trial started for {feature.value}'
        result['expires'] = expires.isoformat()
        result['trial_days'] = trial_days

        logger.info(f"Trial started for {feature.value} by user {user_id}, expires {expires}")
        return result

    def grant_feature(self, feature: Feature, user_id: str, granted_by: str,
                      duration_days: Optional[int] = None, notes: Optional[str] = None) -> Dict[str, Any]:
        """
        Grant a feature to a user (admin function).

        Returns:
            {'success': bool, 'message': str, 'activation': dict}
        """
        now = datetime.utcnow()
        expires = now + timedelta(days=duration_days) if duration_days else None

        activation = FeatureActivation(
            feature=feature,
            activated_at=now,
            expires_at=expires,
            activation_key=None,
            activation_type='grant',
            granted_by=granted_by,
            notes=notes,
        )

        with self._lock:
            if user_id not in self._activations:
                self._activations[user_id] = []
            self._activations[user_id].append(activation)

        self._save_data()

        logger.info(f"Feature {feature.value} granted to {user_id} by {granted_by}")

        return {
            'success': True,
            'message': f'Feature {feature.value} granted to user',
            'activation': activation.to_dict(),
        }

    def revoke_feature(self, feature: Feature, user_id: str, revoked_by: str) -> Dict[str, Any]:
        """Revoke a user's access to a feature."""
        with self._lock:
            if user_id in self._activations:
                original_count = len(self._activations[user_id])
                self._activations[user_id] = [
                    a for a in self._activations[user_id] if a.feature != feature
                ]
                revoked = original_count - len(self._activations[user_id])
            else:
                revoked = 0

        self._save_data()

        if revoked > 0:
            logger.info(f"Feature {feature.value} revoked from {user_id} by {revoked_by}")
            return {'success': True, 'message': f'Feature {feature.value} revoked'}
        else:
            return {'success': False, 'message': 'No active activation found'}

    # ========================================================================
    # Status and Listing
    # ========================================================================

    def get_user_features(self, user_id: str) -> List[Dict[str, Any]]:
        """Get all activated features for a user."""
        activations = self._activations.get(user_id, [])
        return [a.to_dict() for a in activations if a.is_active]

    def get_available_features(self, user_id: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
        """Get status of all features for current license/user."""
        result = {}
        for feature in Feature:
            status = self.is_feature_available(feature, user_id)
            status['config'] = {
                'description': FEATURE_CONFIG.get(feature, {}).get('description', ''),
                'category': FEATURE_CONFIG.get(feature, {}).get('category', ''),
                'risk_level': FEATURE_CONFIG.get(feature, {}).get('risk_level', ''),
            }
            result[feature.value] = status
        return result

    def get_features_by_category(self, category: str, user_id: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
        """Get features in a specific category."""
        result = {}
        for feature in Feature:
            config = FEATURE_CONFIG.get(feature, {})
            if config.get('category') == category:
                status = self.is_feature_available(feature, user_id)
                status['config'] = config
                result[feature.value] = status
        return result


# ============================================================================
# Flask Decorators
# ============================================================================

# Singleton instance
_feature_service: Optional[FeatureLicenseService] = None


def get_feature_service() -> FeatureLicenseService:
    """Get or create the feature license service instance."""
    global _feature_service
    if _feature_service is None:
        _feature_service = FeatureLicenseService()
    return _feature_service


def require_feature(feature: Feature, allow_trial: bool = True):
    """
    Decorator to require a specific feature to be activated.

    Usage:
        @require_feature(Feature.SSH_INTERACTIVE)
        def connect_ssh():
            ...
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            service = get_feature_service()

            # Get user ID from Flask context
            user_id = None
            try:
                from flask_login import current_user
                if current_user.is_authenticated:
                    user_id = str(current_user.id)
            except Exception:
                user_id = session.get('user_id')

            # Check feature availability
            status = service.is_feature_available(feature, user_id)

            if status['available']:
                return f(*args, **kwargs)

            # Feature not available
            response = {
                'error': 'Feature not available',
                'feature': feature.value,
                'reason': status['reason'],
                'code': 'FEATURE_UNAVAILABLE',
            }

            if status.get('trial_eligible') and allow_trial:
                response['trial_available'] = True
                response['trial_url'] = f'/api/features/{feature.value}/trial'

            if status.get('upgrade_tier'):
                response['upgrade_tier'] = status['upgrade_tier']
                response['upgrade_url'] = '/pricing'

            if status.get('required_role'):
                response['code'] = 'ROLE_REQUIRED'
                response['required_role'] = status['required_role']

            return jsonify(response), 403

        return decorated_function
    return decorator


def require_feature_key(feature: Feature):
    """
    Decorator requiring explicit feature key activation (not just tier).

    Use for high-risk features like fix script execution.
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            service = get_feature_service()

            user_id = None
            try:
                from flask_login import current_user
                if current_user.is_authenticated:
                    user_id = str(current_user.id)
            except Exception:
                user_id = session.get('user_id')

            if not user_id:
                return jsonify({
                    'error': 'Authentication required',
                    'code': 'AUTH_REQUIRED'
                }), 401

            # Get user's activations
            activations = service._activations.get(user_id, [])
            for act in activations:
                if act.feature == feature and act.is_active:
                    if act.activation_type in ('key', 'grant'):
                        return f(*args, **kwargs)

            # No explicit activation found
            return jsonify({
                'error': 'Feature activation key required',
                'feature': feature.value,
                'code': 'FEATURE_KEY_REQUIRED',
                'message': f'This feature requires explicit activation. '
                           f'Enter your {feature.value} activation key.',
                'activation_url': f'/api/features/{feature.value}/activate',
            }), 403

        return decorated_function
    return decorator


def check_feature(feature: Feature) -> bool:
    """
    Simple function to check if a feature is available.

    Usage:
        if check_feature(Feature.SSH_INTERACTIVE):
            # show SSH option
    """
    service = get_feature_service()
    user_id = None
    try:
        from flask_login import current_user
        if current_user.is_authenticated:
            user_id = str(current_user.id)
    except Exception as user_lookup_error:
        logger.debug(f"Unable to resolve current user for feature check: {user_lookup_error}")
    return service.check_feature_access(feature, user_id)


# ============================================================================
# Feature Categories Helper
# ============================================================================

FEATURE_CATEGORIES = {
    'remote_sessions': {
        'name': 'Remote Sessions',
        'description': 'Interactive SSH and WinRM terminal sessions',
        'icon': 'terminal',
        'features': [
            Feature.SSH_INTERACTIVE,
            Feature.WINRM_INTERACTIVE,
            Feature.SESSION_RECORDING,
            Feature.SESSION_PLAYBACK,
            Feature.MULTI_SESSION,
        ],
    },
    'remediation': {
        'name': 'Remediation',
        'description': 'Execute security fix scripts on remote servers',
        'icon': 'wrench',
        'features': [
            Feature.FIX_SCRIPTS_LINUX,
            Feature.FIX_SCRIPTS_WINDOWS,
            Feature.FIX_SCRIPTS_HYPERVISOR,
            Feature.FIX_ROLLBACK,
            Feature.FIX_BATCH,
            Feature.FIX_SCHEDULING,
        ],
    },
    'integrations': {
        'name': 'Integrations',
        'description': 'Third-party integrations and authentication',
        'icon': 'plug',
        'features': [
            Feature.SIEM_INTEGRATION,
            Feature.TICKETING_INTEGRATION,
            Feature.CLOUD_AWS,
            Feature.CLOUD_AZURE,
            Feature.CLOUD_GCP,
            Feature.LDAP_AUTH,
            Feature.OKTA_AUTH,
            Feature.ENTRA_AUTH,
        ],
    },
    'audits': {
        'name': 'Advanced Audits',
        'description': 'Advanced audit capabilities',
        'icon': 'search',
        'features': [
            Feature.CUSTOM_AUDITS,
            Feature.PARALLEL_AUDIT,
            Feature.DIFFERENTIAL_AUDIT,
            Feature.COMPLIANCE_MAPPING,
        ],
    },
    'analytics': {
        'name': 'Analytics',
        'description': 'Security analytics and insights',
        'icon': 'chart-line',
        'features': [
            Feature.TREND_ANALYTICS,
            Feature.PREDICTIVE_ANALYTICS,
            Feature.RISK_SCORING,
            Feature.CUSTOM_DASHBOARDS,
        ],
    },
    'asset_discovery': {
        'name': 'Asset Discovery',
        'description': 'Direct API scans and advanced CVE reporting workflows',
        'icon': 'radar',
        'features': [
            Feature.DIRECT_API_SCANS,
            Feature.ADVANCED_CVE_REPORTING,
        ],
    },
    'compliance': {
        'name': 'Compliance',
        'description': 'Compliance framework reports',
        'icon': 'shield-check',
        'features': [
            Feature.CIS_BENCHMARKS,
            Feature.HIPAA_COMPLIANCE,
            Feature.PCI_DSS,
            Feature.SOC2_COMPLIANCE,
            Feature.ISO27001,
        ],
    },
    'enterprise': {
        'name': 'Enterprise',
        'description': 'Enterprise-grade features',
        'icon': 'building',
        'features': [
            Feature.MULTI_TENANT,
            Feature.RBAC_ADVANCED,
            Feature.AUDIT_TRAIL,
            Feature.API_UNLIMITED,
            Feature.AGENT_UNLIMITED,
        ],
    },
}
