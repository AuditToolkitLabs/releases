"""
Keygen License Integration Module

Provides integration with Keygen.sh for license validation and key generation.

Keygen is a web-based license management service that handles:
- License key generation and distribution
- License validation and expiration
- Machine registration and tracking
- Offline validation support via public key

Free tier (beta): Up to 100 licenses
Production: $49/month

See: https://keygen.sh/docs/

Usage:
    keygen = KeygenIntegration(api_key, account_id, product_id)
    result = keygen.validate_key(key, machine_id)
"""

import os
import logging
from typing import Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
import requests
from functools import lru_cache

logger = logging.getLogger(__name__)


class KeygenIntegration:
    """
    Keygen API client for license validation and management.
    
    Attributes:
        api_key: Keygen API key for admin operations
        account_id: Keygen account ID (from dashboard)
        product_id: Keygen product ID for your application
        api_url: Base Keygen API endpoint (default: https://api.keygen.sh/v1)
    """
    
    def __init__(
        self,
        api_key: str,
        account_id: str,
        product_id: str,
        api_url: str = "https://api.keygen.sh/v1"
    ):
        """Initialize Keygen API client."""
        self.api_key = api_key
        self.account_id = account_id
        self.product_id = product_id
        self.api_url = api_url
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/vnd.api+json",
            "Content-Type": "application/vnd.api+json"
        })
        self.timeout = 10
    
    def validate_key(self, key: str, machine_id: str) -> Tuple[bool, Dict[str, Any]]:
        """
        Validate a license key for a specific machine.
        
        Args:
            key: License key to validate
            machine_id: Unique machine identifier (hostname, hardware ID, etc.)
        
        Returns:
            Tuple of (is_valid, license_data)
            is_valid: True if key is valid and active
            license_data: Dictionary with key info, tier, machine limit, expiry, etc.
        
        Example:
            is_valid, data = keygen.validate_key("key-abc123", "server-mac-address")
            if is_valid:
                print(f"License valid until: {data['expires_at']}")
                print(f"Machines: {data['machines_count']}/{data['machines_limit']}")
        """
        try:
            # Endpoint to validate a license key
            url = f"{self.api_url}/accounts/{self.account_id}/licenses/actions/validate-key"
            
            payload = {
                "meta": {
                    "key": key,
                    "scope": {
                        "fingerprint": machine_id  # Register this machine
                    }
                }
            }
            
            response = self.session.post(url, json=payload, timeout=self.timeout)
            
            if response.status_code == 200:
                data = response.json()
                license_data = self._parse_license_response(data)
                return True, license_data
            elif response.status_code == 401:
                logger.warning(f"License validation failed (401): {key}")
                return False, {"error": "Invalid or expired license key"}
            else:
                logger.error(f"Keygen API error ({response.status_code}): {response.text}")
                return False, {"error": f"API error: {response.status_code}"}
        
        except requests.exceptions.Timeout:
            logger.error("Keygen API timeout - validation service unavailable")
            return False, {"error": "License validation service unavailable (timeout)"}
        except Exception as e:
            logger.error(f"Keygen validation error: {e}")
            return False, {"error": f"Validation error: {str(e)}"}
    
    def activate_key(self, key: str, machine_id: str, machine_name: str = "") -> Tuple[bool, Dict[str, Any]]:
        """
        Activate a license key on a specific machine.
        
        Activating registers the machine as using this license, allowing Keygen
        to track active vs. inactive installations.
        
        Args:
            key: License key to activate
            machine_id: Unique machine identifier
            machine_name: Human-readable machine name (optional)
        
        Returns:
            Tuple of (success, response_data)
        """
        try:
            is_valid, license_data = self.validate_key(key, machine_id)
            
            if not is_valid:
                return False, license_data
            
            # If validation succeeded, key is registered in Keygen
            logger.info(f"License key activated for machine: {machine_name or machine_id}")
            return True, license_data
        
        except Exception as e:
            logger.error(f"Keygen activation error: {e}")
            return False, {"error": f"Activation error: {str(e)}"}
    
    def deactivate_key(self, key: str, machine_id: str) -> bool:
        """
        Deactivate a license key (remove machine registration).
        
        Args:
            key: License key to deactivate
            machine_id: Machine to unregister
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get the license group ID first
            licenses = self._get_licenses_by_key(key)
            if not licenses:
                return False
            
            license_id = licenses[0].get('id')
            
            # Remove machine from license
            url = f"{self.api_url}/accounts/{self.account_id}/licenses/{license_id}/machines"
            response = self.session.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                machines = response.json().get('data', [])
                for machine in machines:
                    if machine.get('fingerprint') == machine_id:
                        machine_id_keygen = machine.get('id')
                        delete_url = f"{url}/{machine_id_keygen}"
                        del_response = self.session.delete(delete_url, timeout=self.timeout)
                        return del_response.status_code in [200, 204]
            
            return False
        
        except Exception as e:
            logger.error(f"Keygen deactivation error: {e}")
            return False
    
    def create_license(
        self,
        tier: str,
        email: str,
        expires_in_days: int = 365,
        machines_limit: int = 25,
        metadata: Dict[str, Any] = None
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        Create a new license (admin operation).
        
        Args:
            tier: License tier (free, beta, starter, professional, business, enterprise)
            email: Customer email address
            expires_in_days: License validity period in days
            machines_limit: Max machines allowed with this key
            metadata: Custom metadata (customer name, order ID, etc.)
        
        Returns:
            Tuple of (success, license_data)
            license_data includes 'key', 'id', 'expires_at', etc.
        
        Example:
            success, data = keygen.create_license(
                tier='professional',
                email='customer@example.com',
                machines_limit=150,
                metadata={'order_id': 'ORD-12345'}
            )
            if success:
                license_key = data['key']
                # Email license_key to customer
        """
        try:
            tier = (tier or "").strip().lower()
            expires_at = (datetime.utcnow() + timedelta(days=expires_in_days)).isoformat() + "Z"
            
            # Map tiers to Keygen policy IDs (you'll need to set these up in dashboard)
            policy_map = {
                "free": os.environ.get("KEYGEN_POLICY_FREE"),
                "beta": os.environ.get("KEYGEN_POLICY_BETA"),
                "starter": os.environ.get("KEYGEN_POLICY_STARTER"),
                "professional": os.environ.get("KEYGEN_POLICY_PROFESSIONAL"),
                "business": os.environ.get("KEYGEN_POLICY_BUSINESS"),
                "enterprise": os.environ.get("KEYGEN_POLICY_ENTERPRISE"),
            }
            
            if tier not in policy_map:
                return False, {"error": f"Unknown tier: {tier}"}

            policy_id = policy_map.get(tier)
            if not policy_id:
                return False, {"error": f"No Keygen policy configured for tier: {tier}"}

            effective_metadata = {
                "email": email,
                "tier": tier,
                "machines_limit": machines_limit,
            }

            if metadata:
                effective_metadata.update(metadata)

            if tier == "beta":
                effective_metadata.setdefault("release_channel", "beta")
                effective_metadata.setdefault("beta_program", "customer_evaluation")
            
            url = f"{self.api_url}/accounts/{self.account_id}/licenses"
            
            payload = {
                "data": {
                    "type": "licenses",
                    "attributes": {
                        "expiry": expires_at,
                        "maxMachines": machines_limit,
                        "metadata": effective_metadata,
                    },
                    "relationships": {
                        "policy": {
                            "data": {
                                "type": "policies",
                                "id": policy_id
                            }
                        }
                    }
                }
            }
            
            response = self.session.post(url, json=payload, timeout=self.timeout)

            if response.status_code == 422:
                try:
                    response_data = response.json()
                    errors = response_data.get("errors", [])
                    error_code = errors[0].get("code") if errors else None
                except Exception:
                    error_code = None

                if error_code == "MAX_MACHINES_INVALID":
                    logger.warning(
                        "Policy for tier '%s' does not allow maxMachines override; retrying without override",
                        tier,
                    )
                    payload["data"]["attributes"].pop("maxMachines", None)
                    response = self.session.post(url, json=payload, timeout=self.timeout)
            
            if response.status_code == 201:
                data = response.json()
                license_data = self._parse_license_response(data)
                logger.info(f"License created for {email}: {license_data.get('key')}")
                return True, license_data
            else:
                logger.error(f"License creation failed ({response.status_code}): {response.text}")
                return False, {"error": response.text}
        
        except Exception as e:
            logger.error(f"Keygen license creation error: {e}")
            return False, {"error": str(e)}
    
    def get_license_info(self, key: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a license key without registering a machine.
        
        Args:
            key: License key
        
        Returns:
            License data or None if not found
        """
        try:
            licenses = self._get_licenses_by_key(key)
            if licenses:
                return self._parse_license_response({"data": licenses[0]})
            return None
        except Exception as e:
            logger.error(f"Error getting license info: {e}")
            return None
    
    def list_licenses(self) -> Dict[str, Any]:
        """
        List all licenses (admin operation).
        
        Returns:
            Dictionary with license count and list
        """
        try:
            url = f"{self.api_url}/accounts/{self.account_id}/licenses"
            response = self.session.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                data = response.json()
                licenses = data.get('data', [])
                return {
                    "count": len(licenses),
                    "licenses": [self._parse_license_response({"data": l}) for l in licenses]
                }
            return {"count": 0, "licenses": []}
        
        except Exception as e:
            logger.error(f"Error listing licenses: {e}")
            return {"count": 0, "licenses": [], "error": str(e)}
    
    def _get_licenses_by_key(self, key: str) -> list:
        """Get license(s) matching a key."""
        try:
            url = f"{self.api_url}/accounts/{self.account_id}/licenses"
            params = {"filter[key]": key}
            response = self.session.get(url, params=params, timeout=self.timeout)
            
            if response.status_code == 200:
                return response.json().get('data', [])
            return []
        
        except Exception as e:
            logger.error(f"Error getting licenses: {e}")
            return []
    
    def _parse_license_response(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """Parse Keygen API response into common format."""
        license_data = response.get('data', {})
        
        if isinstance(license_data, list) and license_data:
            license_data = license_data[0]
        
        attributes = license_data.get('attributes', {})
        metadata = attributes.get('metadata', {}) or {}
        machines_limit = (
            attributes.get('maxMachines')
            or metadata.get('machines_limit')
            or metadata.get('machinesLimit')
            or 25
        )
        tier = metadata.get('tier') or metadata.get('licenseTier') or 'free'
        
        return {
            'key': attributes.get('key'),
            'id': license_data.get('id'),
            'status': attributes.get('status'),
            'expires_at': attributes.get('expiry') or attributes.get('expiresAt'),
            'machines_count': attributes.get('machinesCount', 0),
            'machines_limit': machines_limit,
            'tier': tier,
            'valid': attributes.get('valid', False),
            'metadata': metadata
        }


def get_keygen_client() -> Optional[KeygenIntegration]:
    """
    Factory function to get configured Keygen client.
    
    Returns:
        KeygenIntegration instance or None if not configured
    
    Requires environment variables:
        KEYGEN_API_KEY: Keygen API key
        KEYGEN_ACCOUNT_ID: Keygen account ID
        KEYGEN_PRODUCT_ID: Keygen product ID
    """
    api_key = os.environ.get("KEYGEN_API_KEY")
    account_id = os.environ.get("KEYGEN_ACCOUNT_ID")
    product_id = os.environ.get("KEYGEN_PRODUCT_ID")
    
    if not all([api_key, account_id, product_id]):
        logger.debug("Keygen not fully configured - some environment variables missing")
        return None
    
    return KeygenIntegration(api_key, account_id, product_id)


# Cache for public key validation (avoids repeated API calls)
@lru_cache(maxsize=1)
def get_keygen_public_key(account_id: str) -> Optional[str]:
    """
    Get Keygen public key for offline validation.
    
    This allows customers to validate keys without calling Keygen API
    (useful for air-gapped environments).
    
    Returns:
        PEM-formatted public key or None
    """
    try:
        api_url = "https://api.keygen.sh/v1"
        url = f"{api_url}/accounts/{account_id}?include=public-key"
        
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            included = data.get('included', [])
            for item in included:
                if item.get('type') == 'public-keys':
                    return item.get('attributes', {}).get('content')
        return None
    
    except Exception as e:
        logger.error(f"Error getting Keygen public key: {e}")
        return None
