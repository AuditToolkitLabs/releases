"""
License Service for Audit Tool Web Dashboard

Enforces BSL license limits:
- Community (Free): Up to 25 unique machines - self-service
- Trial: Full PROFESSIONAL access for 30 days - auto-activates on first use
    - Starter: Up to 50 machines (£549/year) - best effort email
    - Professional: Up to 150 machines (£1,099/year) - 48hr email support
    - Business: Up to 500 machines (£2,499/year)
- Enterprise: Unlimited machines (by separate agreement only, not publicly listed)

Enterprise purchasing model:
- Enterprise is not listed as a public website checkout option
- Enterprise is available by separate agreement only
- Contact licensing@audittoolkitlabs.com for Enterprise enquiries

Use TIER_AVAILABILITY to control which tiers are actively sold.

BETA/TRIAL STRATEGY (Feb 2026):
- New installs can start a 14-day TRIAL with PROFESSIONAL features
- After trial expires, gracefully downgrades to FREE (25 servers)
- Existing data preserved, just feature-gated
- Can upgrade to paid tier at any time to unlock
"""

import os
import json
import hashlib
import hmac
import secrets
import platform
import shutil
import subprocess  # nosec B404
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)


ENTERPRISE_FEATURE_PACK_ADDON = "enterprise_feature_pack"
ENTERPRISE_FEATURE_PACK_MARKER = f"addon:{ENTERPRISE_FEATURE_PACK_ADDON}"
ADDON_MIN_BASE_TIER = "professional"


def _resolve_executable(executable: str) -> str:
    """Resolve an executable to an absolute path when available."""
    resolved = shutil.which(executable)
    return resolved or executable


def _run_platform_command(command: List[str], timeout: int = 10):
    """Run platform inspection command with normalized executable path."""
    safe_command = list(command)
    safe_command[0] = _resolve_executable(safe_command[0])
    return subprocess.run(  # nosec B603
        safe_command,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


class LicenseTier(Enum):
    FREE = "free"
    COMMUNITY = "community"       # Alias for free (standalone-facing name)
    TRIAL = "trial"               # 14-day full access trial (anti-abuse protected)
    STARTER = "starter"           # Entry paid tier
    BUSINESS = "business"         # Mid paid tier
    PROFESSIONAL = "professional" # Top public tier
    ENTERPRISE = "enterprise"     # Legacy / by-agreement only


DELEGATED_AGENT_LIMITS = {
    # Live delegated agents remain aligned with the Core tier capacity.
    LicenseTier.FREE.value: 0,
    LicenseTier.COMMUNITY.value: 0,
    LicenseTier.TRIAL.value: 150,
    LicenseTier.STARTER.value: 50,
    LicenseTier.PROFESSIONAL.value: 150,
    LicenseTier.BUSINESS.value: 500,
    LicenseTier.ENTERPRISE.value: 10000,
}

STANDALONE_KEY_LIMITS = {
    # Pre-signed standalone keys are an exception path for offline or air-gapped use.
    # Keep this pool materially smaller than the live delegated pool so customers are
    # nudged toward managed/direct connectivity instead of treating ATKS as the default.
    LicenseTier.FREE.value: 0,
    LicenseTier.COMMUNITY.value: 0,
    LicenseTier.TRIAL.value: 3,
    LicenseTier.STARTER.value: 10,
    LicenseTier.PROFESSIONAL.value: 50,
    LicenseTier.BUSINESS.value: 100,
    LicenseTier.ENTERPRISE.value: 250,
}


def get_delegated_agent_limit_for_tier(tier: str) -> int:
    """Return live delegated agent capacity for a tier."""
    normalized_tier = str(tier or LicenseTier.FREE.value).lower()
    return DELEGATED_AGENT_LIMITS.get(normalized_tier, DELEGATED_AGENT_LIMITS[LicenseTier.FREE.value])


def get_standalone_key_limit_for_tier(tier: str) -> int:
    """Return the smaller exception-only ATKS issuance capacity for a tier."""
    normalized_tier = str(tier or LicenseTier.FREE.value).lower()
    return STANDALONE_KEY_LIMITS.get(normalized_tier, STANDALONE_KEY_LIMITS[LicenseTier.FREE.value])


# Trial configuration with anti-abuse measures
TRIAL_CONFIG = {
    'duration_days': 14,          # Shorter trial - enough to evaluate, limits abuse
    'features_equivalent': LicenseTier.PROFESSIONAL,  # Trial gets PROFESSIONAL features
    'machine_limit': 150,         # Same as PROFESSIONAL
    'extend_max_days': 7,         # One-time extension (reduced from 14)
    'auto_activate': False,       # Require email registration first
    # Anti-abuse measures
    'require_registration': True,  # Must provide email to start trial
    'machine_id_bound': True,      # Trial bound to hardware - reinstall won't reset
    'export_disabled': True,       # Can't export PDF/reports during trial
    'watermark_reports': True,     # Trial reports marked "EVALUATION ONLY"
    'audit_view_only': True,       # Can run audits but results watermarked
}


# Tier availability for purchase - controls what's actively sold
# Status options: 'active', 'waitlist', 'coming_soon', 'partner_only'
TIER_AVAILABILITY = {
    LicenseTier.FREE: {
        'status': 'active',
        'purchasable': True,
        'message': None,
    },
    LicenseTier.TRIAL: {
        'status': 'active',
        'purchasable': False,  # Not purchasable, requires registration
        'price_yearly': 0,
        'message': '14-day evaluation trial - registration required',
        'is_trial': True,
        'restrictions': ['export_disabled', 'reports_watermarked'],
    },
    LicenseTier.STARTER: {
        'status': 'active',
        'purchasable': True,
        'price_yearly': 549,
        'message': None,
    },
    LicenseTier.PROFESSIONAL: {
        'status': 'active',
        'purchasable': True,
        'price_yearly': 1099,
        'message': None,
    },
    LicenseTier.BUSINESS: {
        'status': 'active',
        'purchasable': True,
        'price_yearly': 2499,
        'message': None,
    },
    LicenseTier.ENTERPRISE: {
        'status': 'active',
        'purchasable': False,
        'price_yearly': 5999,
        'message': 'Enterprise is available by separate agreement only. Contact licensing@audittoolkitlabs.com.',
        'website_listed': False,
        'contact_pricing': True,
        'contact_url': '/contact/enterprise',
    },
}


def is_tier_available(tier: LicenseTier) -> bool:
    """Check if a tier is currently available for purchase."""
    availability = TIER_AVAILABILITY.get(tier, {})
    return availability.get('purchasable', False)


def get_tier_availability(tier: LicenseTier) -> dict:
    """Get full availability info for a tier."""
    return TIER_AVAILABILITY.get(tier, {'status': 'unknown', 'purchasable': False})


@dataclass
class LicenseInfo:
    tier: LicenseTier
    key: Optional[str] = None
    issued: Optional[datetime] = None
    expires: Optional[datetime] = None
    features: List[str] = None
    trial_started: Optional[datetime] = None  # When trial was activated
    trial_extended: bool = False              # If trial was extended
    # Anti-abuse fields
    machine_id: Optional[str] = None          # Hardware fingerprint for trial
    registration_email: Optional[str] = None  # Email used for registration

    def __post_init__(self):
        if self.features is None:
            self.features = []

    @property
    def is_valid(self) -> bool:
        if self.tier == LicenseTier.FREE:
            return True
        if self.tier == LicenseTier.TRIAL:
            # Trial is valid if not expired
            if self.expires is None:
                return False
            return datetime.utcnow() < self.expires
        if self.expires is None:
            return False
        return datetime.utcnow() < self.expires

    @property
    def is_trial(self) -> bool:
        """Check if this is an active trial."""
        return self.tier == LicenseTier.TRIAL and self.is_valid

    @property
    def trial_days_remaining(self) -> int:
        """Days remaining in trial (0 if not trial or expired)."""
        if self.tier != LicenseTier.TRIAL or self.expires is None:
            return 0
        remaining = (self.expires - datetime.utcnow()).days
        return max(0, remaining)

    @property
    def trial_expired(self) -> bool:
        """Check if trial has expired (was trial but no longer valid)."""
        if self.tier != LicenseTier.TRIAL:
            return False
        return not self.is_valid

    @property
    def can_export(self) -> bool:
        """Check if export is allowed (disabled during trial)."""
        if self.tier == LicenseTier.TRIAL and TRIAL_CONFIG.get('export_disabled', True):
            return False
        return True

    @property
    def reports_watermarked(self) -> bool:
        """Check if reports should be watermarked (trial only)."""
        if self.tier == LicenseTier.TRIAL and TRIAL_CONFIG.get('watermark_reports', True):
            return True
        return False

    @property
    def machine_limit(self) -> int:
        """Machine limits per tier (revised Feb 2026 - solo operator pricing)."""
        if self.tier == LicenseTier.ENTERPRISE:
            return float('inf')  # Unlimited - £5,999/yr
        elif self.tier == LicenseTier.BUSINESS:
            return 500   # £2,499/yr - priority email support
        elif self.tier == LicenseTier.PROFESSIONAL:
            return 150   # £1,099/yr - 48hr email support
        elif self.tier == LicenseTier.TRIAL:
            return TRIAL_CONFIG['machine_limit']  # Same as PROFESSIONAL during trial
        elif self.tier == LicenseTier.STARTER:
            return 50    # £549/yr - best effort email
        return 25  # Free tier - docs/community only

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "tier": self.tier.value,
            "key": self.key,
            "issued": self.issued.isoformat() if self.issued else None,
            "expires": self.expires.isoformat() if self.expires else None,
            "features": self.features,
            "is_valid": self.is_valid,
            "machine_limit": self.machine_limit if self.machine_limit != float('inf') else "unlimited",
            # Anti-abuse restrictions
            "can_export": self.can_export,
            "reports_watermarked": self.reports_watermarked,
        }

        # Add trial-specific info
        if self.tier == LicenseTier.TRIAL:
            result["is_trial"] = True
            result["trial_days_remaining"] = self.trial_days_remaining
            result["trial_started"] = self.trial_started.isoformat() if self.trial_started else None
            result["trial_extended"] = self.trial_extended
            result["trial_expired"] = self.trial_expired
            result["registration_email"] = self.registration_email
            # Trial restrictions
            result["restrictions"] = {
                "export_disabled": TRIAL_CONFIG.get('export_disabled', True),
                "reports_watermarked": TRIAL_CONFIG.get('watermark_reports', True),
            }
        else:
            result["is_trial"] = False

        return result


@dataclass
class RegisteredMachine:
    machine_id: str
    hostname: str
    first_seen: datetime
    last_seen: datetime
    ip_address: Optional[str] = None
    os_info: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "machine_id": self.machine_id,
            "hostname": self.hostname,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
            "ip_address": self.ip_address,
            "os_info": self.os_info
        }


class LicenseService:
    """
    Manages license validation and machine registration for the Audit Tool.

    Tiers (revised Feb 2026 - solo operator pricing):
    - Free: 1-25 servers ($0, docs/community support)
    - Starter: 26-50 servers (£549/yr, best effort email)
    - Professional: 51-150 servers (£1,099/yr, 48hr email)
    - Business: 151-500 servers (£2,499/yr, priority email 24hr)
    - Enterprise: Unlimited servers (by separate agreement only)
    """

    # License limits (revised Feb 2026 - realistic for solo support)
    FREE_TIER_LIMIT = 25
    STARTER_LIMIT = 50
    PROFESSIONAL_LIMIT = 150
    BUSINESS_LIMIT = 500

    # License key prefix mapping
    KEY_PREFIXES = {
        "STRT": LicenseTier.STARTER,
        "PROF": LicenseTier.PROFESSIONAL,
        "BUSN": LicenseTier.BUSINESS,
        "ENTR": LicenseTier.ENTERPRISE,
    }

    # Secret key for license generation (in production, use env var)
    LICENSE_SECRET = os.environ.get("LICENSE_SECRET", "change-this-in-production-2026")

    def __init__(self, data_dir: Optional[str] = None):
        """
        Initialize the license service.

        Args:
            data_dir: Directory to store license and machine data.
                     Defaults to LICENSE_DATA_DIR env var or ~/.audit-tool/
        """
        if data_dir is None:
            data_dir = os.environ.get("LICENSE_DATA_DIR") or os.path.expanduser("~/.audit-tool")

        self.data_dir = Path(data_dir)
        self.license_file = self.data_dir / "license.json"
        self.machines_file = self.data_dir / "machines.json"

        self._ensure_data_dir()
        self._license_info: Optional[LicenseInfo] = None
        self._machines: Dict[str, RegisteredMachine] = {}

        self._load_license()
        self._load_machines()

    def _ensure_data_dir(self):
        """Create data directory if it doesn't exist."""
        self.data_dir.mkdir(parents=True, exist_ok=True)
        # Set restrictive permissions on Unix systems
        if platform.system() != "Windows":
            os.chmod(self.data_dir, 0o700)

    def _load_license(self):
        """Load license from file, with auto-trial activation for fresh installs."""
        if not self.license_file.exists():
            # Fresh install - auto-activate trial if enabled
            if TRIAL_CONFIG.get('auto_activate', True):
                logger.info("Fresh install detected - activating trial period")
                self._activate_trial()
            else:
                self._license_info = LicenseInfo(tier=LicenseTier.FREE)
            return

        try:
            with open(self.license_file, 'r') as f:
                data = json.load(f)

            tier = LicenseTier(data.get("tier", "free"))
            expires = self._parse_datetime_utc_naive(data.get("expires"))
            issued = self._parse_datetime_utc_naive(data.get("issued"))
            trial_started = self._parse_datetime_utc_naive(data.get("trial_started"))

            self._license_info = LicenseInfo(
                tier=tier,
                key=data.get("key"),
                issued=issued,
                expires=expires,
                features=data.get("features", []),
                trial_started=trial_started,
                trial_extended=data.get("trial_extended", False),
                machine_id=data.get("machine_id"),
                registration_email=data.get("registration_email")
            )

            # Enforce host-bound non-transferability for all non-free licenses.
            # A license can only be used on the installation host where it was activated.
            if self._license_info.tier != LicenseTier.FREE:
                current_fingerprint = self._get_machine_fingerprint()
                if not self._license_info.machine_id:
                    self._license_info.machine_id = current_fingerprint
                    self._save_license()
                    logger.info("License bound to installation fingerprint")
                elif current_fingerprint != self._license_info.machine_id:
                    logger.warning(
                        "Installation fingerprint mismatch - license is non-transferable across hosts"
                    )
                    self._license_info = LicenseInfo(tier=LicenseTier.FREE)
                    self._save_license()
                    return

            # Handle trial expiry - graceful downgrade to FREE
            if self._license_info.tier == LicenseTier.TRIAL and not self._license_info.is_valid:
                logger.warning("Trial has expired, downgrading to FREE tier")
                self._downgrade_from_trial()
            # Handle other expired licenses
            elif not self._license_info.is_valid and self._license_info.tier != LicenseTier.FREE:
                logger.warning(f"License has expired ({self._license_info.tier.value}), reverting to free tier")
                self._license_info = LicenseInfo(tier=LicenseTier.FREE)
                self._save_license()

        except Exception as e:
            logger.error(f"Failed to load license: {e}")
            self._license_info = LicenseInfo(tier=LicenseTier.FREE)

    @staticmethod
    def _parse_datetime_utc_naive(value: Optional[str]) -> Optional[datetime]:
        """Parse ISO datetime and normalize to naive UTC for safe comparisons."""
        if not value or not isinstance(value, str):
            return None

        candidate = value.strip()
        if candidate.endswith("Z"):
            candidate = f"{candidate[:-1]}+00:00"

        parsed = datetime.fromisoformat(candidate)
        if parsed.tzinfo is not None:
            return parsed.astimezone(timezone.utc).replace(tzinfo=None)

        return parsed

    def _activate_trial(self, email: str = None, machine_id: str = None):
        """
        Activate a new trial period with anti-abuse protections.

        Args:
            email: Registration email (required if require_registration is True)
            machine_id: Hardware fingerprint to bind trial to

        Returns:
            Dict with success status and trial info
        """
        # Check if registration is required
        if TRIAL_CONFIG.get('require_registration', True) and not email:
            return {
                'success': False,
                'error': 'Email registration required to start trial',
                'require_registration': True
            }

        # Get or generate machine ID for binding
        if machine_id is None:
            machine_id = self._get_machine_fingerprint()

        # Check if this machine already used a trial (anti-abuse)
        if TRIAL_CONFIG.get('machine_id_bound', True):
            existing_trial = self._check_existing_trial(machine_id)
            if existing_trial:
                return {
                    'success': False,
                    'error': 'Trial already used on this machine',
                    'previous_trial': existing_trial,
                    'upgrade_options': self._get_upgrade_options()
                }

        now = datetime.utcnow()
        trial_days = TRIAL_CONFIG.get('duration_days', 14)
        expires = now + timedelta(days=trial_days)

        self._license_info = LicenseInfo(
            tier=LicenseTier.TRIAL,
            key=f"TRIAL-{secrets.token_hex(8).upper()}",
            issued=now,
            expires=expires,
            features=['all'],  # Trial gets all features (with restrictions)
            trial_started=now,
            trial_extended=False,
            machine_id=machine_id,
            registration_email=email
        )
        self._save_license()

        logger.info(f"Trial activated for {email}: {trial_days} days until {expires.isoformat()}")

        return {
            'success': True,
            'trial_days': trial_days,
            'expires': expires.isoformat(),
            'restrictions': {
                'export_disabled': TRIAL_CONFIG.get('export_disabled', True),
                'reports_watermarked': TRIAL_CONFIG.get('watermark_reports', True),
            }
        }

    def _get_machine_fingerprint(self) -> str:
        """
        Generate a hardware fingerprint for trial binding.

        Uses multiple system identifiers to create a stable fingerprint
        that survives reinstallation.
        """
        identifiers = []

        # Linux/Unix machine-id
        if platform.system() != "Windows":
            for path in ["/etc/machine-id", "/var/lib/dbus/machine-id"]:
                if os.path.exists(path):
                    try:
                        with open(path) as f:
                            identifiers.append(f.read().strip())
                            break
                    except Exception as machine_id_error:
                        logger.debug(f"Failed to read machine ID from {path}: {machine_id_error}")

        # Windows machine GUID
        if platform.system() == "Windows":
            try:
                result = _run_platform_command(
                    ["wmic", "csproduct", "get", "uuid"],
                    timeout=10,
                )
                for line in result.stdout.strip().split('\n'):
                    if line.strip() and line.strip() != "UUID":
                        identifiers.append(line.strip())
                        break
            except Exception as windows_uuid_error:
                logger.debug(f"Failed to collect Windows UUID for fingerprint: {windows_uuid_error}")

        # macOS hardware UUID
        if platform.system() == "Darwin":
            try:
                result = _run_platform_command(
                    ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                    timeout=10,
                )
                for line in result.stdout.split('\n'):
                    if 'IOPlatformUUID' in line:
                        identifiers.append(line.split('"')[-2])
                        break
            except Exception as mac_uuid_error:
                logger.debug(f"Failed to collect macOS UUID for fingerprint: {mac_uuid_error}")

        # Fallback: hostname + platform
        if not identifiers:
            identifiers.append(f"{platform.node()}:{platform.system()}")

        # Hash all identifiers into a single fingerprint
        combined = ":".join(identifiers)
        return hashlib.sha256(combined.encode()).hexdigest()[:32]

    def _check_existing_trial(self, machine_id: str) -> Optional[Dict]:
        """
        Check if this machine has already used a trial.

        Looks in the trial history file to prevent reinstall abuse.
        """
        history_file = self.data_dir / "trial_history.json"
        if not history_file.exists():
            return None

        try:
            with open(history_file, 'r') as f:
                history = json.load(f)
            return history.get(machine_id)
        except Exception:
            return None

    def _record_trial_usage(self, machine_id: str, email: str, started: datetime):
        """Record trial usage in history file for anti-abuse tracking."""
        history_file = self.data_dir / "trial_history.json"
        history = {}

        if history_file.exists():
            try:
                with open(history_file, 'r') as f:
                    history = json.load(f)
            except Exception as history_read_error:
                logger.debug(f"Unable to read trial history file {history_file}: {history_read_error}")

        history[machine_id] = {
            'email': email,
            'started': started.isoformat(),
            'recorded': datetime.utcnow().isoformat()
        }

        with open(history_file, 'w') as f:
            json.dump(history, f, indent=2)

    def _downgrade_from_trial(self):
        """Gracefully downgrade from expired trial to FREE tier."""
        logger.info("Downgrading from expired trial to FREE tier")

        # Preserve some info for analytics/recovery
        old_trial_started = self._license_info.trial_started
        old_machine_id = self._license_info.machine_id
        old_email = self._license_info.registration_email

        # Record trial usage for anti-abuse tracking
        if old_machine_id:
            self._record_trial_usage(old_machine_id, old_email, old_trial_started)

        self._license_info = LicenseInfo(
            tier=LicenseTier.FREE,
            key=None,
            issued=old_trial_started,  # Preserve original install date
            expires=None,
            features=[],
            trial_started=old_trial_started,  # Remember they had a trial
            trial_extended=self._license_info.trial_extended,
            machine_id=old_machine_id,  # Keep machine ID for tracking
            registration_email=old_email
        )
        self._save_license()

        logger.info("Downgrade complete - data preserved, features limited to FREE tier")

    def _save_license(self):
        """Save license to file."""
        data = {
            "tier": self._license_info.tier.value,
            "key": self._license_info.key,
            "issued": self._license_info.issued.isoformat() if self._license_info.issued else None,
            "expires": self._license_info.expires.isoformat() if self._license_info.expires else None,
            "features": self._license_info.features,
            "trial_started": self._license_info.trial_started.isoformat() if self._license_info.trial_started else None,
            "trial_extended": self._license_info.trial_extended,
            # Anti-abuse fields
            "machine_id": self._license_info.machine_id,
            "registration_email": self._license_info.registration_email
        }

        with open(self.license_file, 'w') as f:
            json.dump(data, f, indent=2)

        if platform.system() != "Windows":
            os.chmod(self.license_file, 0o600)

    def _load_machines(self):
        """Load registered machines from file."""
        if not self.machines_file.exists():
            self._machines = {}
            return

        try:
            with open(self.machines_file, 'r') as f:
                data = json.load(f)

            self._machines = {}
            for machine_id, machine_data in data.items():
                self._machines[machine_id] = RegisteredMachine(
                    machine_id=machine_id,
                    hostname=machine_data.get("hostname", "unknown"),
                    first_seen=datetime.fromisoformat(machine_data["first_seen"]),
                    last_seen=datetime.fromisoformat(machine_data["last_seen"]),
                    ip_address=machine_data.get("ip_address"),
                    os_info=machine_data.get("os_info")
                )
        except Exception as e:
            logger.error(f"Failed to load machines: {e}")
            self._machines = {}

    def _save_machines(self):
        """Save registered machines to file."""
        data = {
            machine_id: machine.to_dict()
            for machine_id, machine in self._machines.items()
        }

        with open(self.machines_file, 'w') as f:
            json.dump(data, f, indent=2, default=str)

        if platform.system() != "Windows":
            os.chmod(self.machines_file, 0o600)

    @property
    def license_info(self) -> LicenseInfo:
        """Get current license information."""
        return self._license_info

    @property
    def machine_count(self) -> int:
        """Get number of registered machines."""
        return len(self._machines)

    @property
    def machine_limit(self) -> int:
        """Get machine limit for current license."""
        return self._license_info.machine_limit

    @property
    def remaining_slots(self) -> int:
        """Get remaining machine slots."""
        limit = self.machine_limit
        if limit == float('inf'):
            return float('inf')
        return max(0, limit - self.machine_count)

    def get_status(self) -> Dict[str, Any]:
        """Get complete license status including trial info."""
        status = {
            "license": self._license_info.to_dict(),
            "machines": {
                "count": self.machine_count,
                "limit": self.machine_limit if self.machine_limit != float('inf') else "unlimited",
                "remaining": self.remaining_slots if self.remaining_slots != float('inf') else "unlimited"
            }
        }

        # Add trial-specific status for better UX feedback
        if self._license_info.tier == LicenseTier.TRIAL:
            status["trial"] = {
                "active": self._license_info.is_valid,
                "days_remaining": self._license_info.trial_days_remaining,
                "started": self._license_info.trial_started.isoformat() if self._license_info.trial_started else None,
                "expires": self._license_info.expires.isoformat() if self._license_info.expires else None,
                "extended": self._license_info.trial_extended,
                "can_extend": not self._license_info.trial_extended,  # Can only extend once
                "upgrade_options": self._get_upgrade_options()
            }
        elif self._license_info.trial_started:
            # They had a trial but it expired - show upgrade prompt
            status["former_trial"] = {
                "was_trial": True,
                "trial_started": self._license_info.trial_started.isoformat(),
                "upgrade_options": self._get_upgrade_options()
            }

        return status

    def _get_upgrade_options(self) -> List[Dict]:
        """Get available upgrade options for trial users."""
        options = []
        for tier, info in TIER_AVAILABILITY.items():
            if info.get('purchasable', False) and tier != LicenseTier.FREE:
                options.append({
                    'tier': tier.value,
                    'price_yearly': info.get('price_yearly', 0),
                    'status': info.get('status', 'unknown')
                })
        return options

    def extend_trial(self, days: int = None) -> Dict[str, Any]:
        """
        Extend an active trial period (one-time extension allowed).

        Args:
            days: Number of days to extend (max defined by TRIAL_CONFIG)

        Returns:
            Dict with success status and new expiry date
        """
        if self._license_info.tier != LicenseTier.TRIAL:
            return {
                "success": False,
                "error": "No active trial to extend",
                "current_tier": self._license_info.tier.value
            }

        if self._license_info.trial_extended:
            return {
                "success": False,
                "error": "Trial has already been extended once",
                "current_expires": self._license_info.expires.isoformat() if self._license_info.expires else None
            }

        max_extend = TRIAL_CONFIG.get('extend_max_days', 14)
        extend_days = min(days or max_extend, max_extend)

        if not self._license_info.is_valid:
            # Trial expired - can't extend after expiry
            return {
                "success": False,
                "error": "Cannot extend expired trial. Please upgrade to continue.",
                "upgrade_options": self._get_upgrade_options()
            }

        # Extend the trial
        new_expires = self._license_info.expires + timedelta(days=extend_days)
        self._license_info.expires = new_expires
        self._license_info.trial_extended = True
        self._save_license()

        logger.info(f"Trial extended by {extend_days} days to {new_expires.isoformat()}")

        return {
            "success": True,
            "extended_by_days": extend_days,
            "new_expires": new_expires.isoformat(),
            "days_remaining": self._license_info.trial_days_remaining
        }

    def get_trial_status(self) -> Dict[str, Any]:
        """Get detailed trial status for UI display."""
        if self._license_info.tier == LicenseTier.TRIAL:
            return {
                "is_trial": True,
                "active": self._license_info.is_valid,
                "days_remaining": self._license_info.trial_days_remaining,
                "started": self._license_info.trial_started.isoformat() if self._license_info.trial_started else None,
                "expires": self._license_info.expires.isoformat() if self._license_info.expires else None,
                "extended": self._license_info.trial_extended,
                "can_extend": not self._license_info.trial_extended and self._license_info.is_valid,
                "features_unlocked": True,
                "feature_level": TRIAL_CONFIG.get('features_equivalent', LicenseTier.PROFESSIONAL).value,
                "upgrade_prompt": self._license_info.trial_days_remaining <= 7,  # Show prompt in last week
                "restrictions": {
                    "can_export": self._license_info.can_export,
                    "reports_watermarked": self._license_info.reports_watermarked,
                    "machine_bound": TRIAL_CONFIG.get('machine_id_bound', True),
                    "registration_email": self._license_info.registration_email
                }
            }
        elif self._license_info.trial_started:
            # Former trial user
            return {
                "is_trial": False,
                "was_trial": True,
                "trial_started": self._license_info.trial_started.isoformat(),
                "current_tier": self._license_info.tier.value,
                "features_unlocked": False,
                "upgrade_prompt": True
            }
        else:
            # Never had a trial (unlikely with auto-activate)
            return {
                "is_trial": False,
                "was_trial": False,
                "current_tier": self._license_info.tier.value,
                "features_unlocked": self._license_info.tier not in [LicenseTier.FREE]
            }

    def is_machine_registered(self, machine_id: str) -> bool:
        """Check if a machine is registered."""
        return machine_id in self._machines

    def get_machine_id(self, hostname: str, mac_address: Optional[str] = None) -> str:
        """
        Generate a unique machine ID.

        Args:
            hostname: Machine hostname
            mac_address: Optional MAC address for uniqueness

        Returns:
            Unique machine identifier
        """
        # Try to get system machine ID in a cross-platform way
        machine_id = None

        # Linux/Unix
        if platform.system() != "Windows":
            try:
                for path in ["/etc/machine-id", "/var/lib/dbus/machine-id"]:
                    if os.path.exists(path):
                        with open(path) as f:
                            machine_id = f.read().strip()
                            break
            except Exception as e:
                logger.debug(f"Failed to read Linux machine-id: {e}")

        # Windows
        if not machine_id and platform.system() == "Windows":
            try:
                result = _run_platform_command(
                    ["wmic", "csproduct", "get", "uuid"],
                    timeout=10,
                )
                for line in result.stdout.strip().split('\n'):
                    if line.strip() and line.strip() != "UUID":
                        machine_id = line.strip()
                        break
            except Exception as e:
                logger.debug(f"Failed to get Windows UUID via wmic: {e}")

        # macOS fallback
        if not machine_id and platform.system() == "Darwin":
            try:
                result = _run_platform_command(
                    ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                    timeout=10,
                )
                for line in result.stdout.split('\n'):
                    if 'IOPlatformUUID' in line:
                        machine_id = line.split('"')[1]
                        break
            except Exception as e:
                logger.debug(f"Failed to get macOS UUID: {e}")

        # Fallback: hash hostname + MAC
        if not machine_id:
            identifier = f"{hostname}:{mac_address or 'unknown'}"
            machine_id = hashlib.sha256(identifier.encode()).hexdigest()

        return machine_id

    def check_license(self, machine_id: str, hostname: str,
                      ip_address: Optional[str] = None,
                      os_info: Optional[str] = None) -> Dict[str, Any]:
        """
        Check if a machine can be scanned under the current license.

        Args:
            machine_id: Unique machine identifier
            hostname: Machine hostname
            ip_address: Optional IP address
            os_info: Optional OS information

        Returns:
            Dict with 'allowed' (bool) and 'message' (str)
        """
        # Already registered - always allow
        if self.is_machine_registered(machine_id):
            self._update_machine(machine_id, hostname, ip_address, os_info)
            return {
                "allowed": True,
                "message": "Machine already registered"
            }

        # Check limit
        if self.machine_limit != float('inf') and self.machine_count >= self.machine_limit:
            tier = self._license_info.tier.value
            limit = self.machine_limit

            return {
                "allowed": False,
                "message": f"License limit reached. Your {tier} license allows {limit} machines. "
                          f"You have already registered {self.machine_count} machines.",
                "upgrade_options": {
                    "starter": {
                        "price": "£549/year",
                        "limit": 50
                    },
                    "professional": {
                        "price": "£1,099/year",
                        "limit": 150
                    },
                    "business": {
                        "price": "£2,499/year",
                        "limit": 500
                    }
                }
            }

        # Register new machine
        self._register_machine(machine_id, hostname, ip_address, os_info)

        remaining = self.remaining_slots
        message = "Machine registered successfully"

        if remaining != float('inf') and remaining <= 5:
            message += f". Warning: Only {remaining} machine slots remaining."

        return {
            "allowed": True,
            "message": message,
            "remaining_slots": remaining if remaining != float('inf') else "unlimited"
        }

    def _register_machine(self, machine_id: str, hostname: str,
                          ip_address: Optional[str] = None,
                          os_info: Optional[str] = None):
        """Register a new machine."""
        now = datetime.utcnow()
        self._machines[machine_id] = RegisteredMachine(
            machine_id=machine_id,
            hostname=hostname,
            first_seen=now,
            last_seen=now,
            ip_address=ip_address,
            os_info=os_info
        )
        self._save_machines()
        logger.info(f"Registered new machine: {hostname} ({machine_id[:8]}...)")

    def _update_machine(self, machine_id: str, hostname: str,
                        ip_address: Optional[str] = None,
                        os_info: Optional[str] = None):
        """Update an existing machine's last_seen timestamp."""
        if machine_id in self._machines:
            machine = self._machines[machine_id]
            machine.last_seen = datetime.utcnow()
            if hostname:
                machine.hostname = hostname
            if ip_address:
                machine.ip_address = ip_address
            if os_info:
                machine.os_info = os_info
            self._save_machines()

    def list_machines(self) -> List[Dict[str, Any]]:
        """List all registered machines."""
        return [machine.to_dict() for machine in self._machines.values()]

    def remove_machine(self, machine_id: str) -> bool:
        """Remove a machine from the registry."""
        if machine_id in self._machines:
            del self._machines[machine_id]
            self._save_machines()
            return True
        return False

    def reset_machines(self):
        """Reset the machine registry (removes all machines)."""
        self._machines = {}
        self._save_machines()
        logger.info("Machine registry reset")

    def activate_license(self, license_key: str) -> Dict[str, Any]:
        """
        Activate a license key.

        Args:
            license_key: License key in format XXXX-XXXX-XXXX-XXXX

        Returns:
            Dict with activation result
        """
        import re

        # Validate format
        if not re.match(r'^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$', license_key):
            return {
                "success": False,
                "message": "Invalid license key format. Expected: XXXX-XXXX-XXXX-XXXX"
            }

        enable_demo_keys = os.getenv("ENABLE_DEMO_KEYS", "false").strip().lower() in {
            "1",
            "true",
            "yes",
            "on",
        }
        installation_fingerprint = self._get_machine_fingerprint()

        if enable_demo_keys:
            demo_keys = {
                "STRT-TEST-2026-DEMO": (LicenseTier.STARTER, 365),
                "PROF-TEST-2026-DEMO": (LicenseTier.PROFESSIONAL, 365),
                "BUSN-TEST-2026-DEMO": (LicenseTier.BUSINESS, 365),
                "ENTR-TEST-2026-DEMO": (LicenseTier.ENTERPRISE, 365),
            }

            if license_key in demo_keys:
                tier, days = demo_keys[license_key]
                now = datetime.utcnow()

                self._license_info = LicenseInfo(
                    tier=tier,
                    key=license_key,
                    issued=now,
                    expires=now + timedelta(days=days),
                    features=self._get_tier_features(tier),
                    machine_id=installation_fingerprint,
                )
                self._save_license()

                return {
                    "success": True,
                    "message": f"License activated: {tier.value}",
                    "license": self._license_info.to_dict()
                }

        # Try to validate key locally (offline validation)
        validation = self._validate_key_offline(license_key)
        if validation["valid"]:
            tier = validation["tier"]
            now = datetime.utcnow()

            self._license_info = LicenseInfo(
                tier=tier,
                key=license_key,
                issued=now,
                expires=now + timedelta(days=validation.get("days", 365)),
                features=self._get_tier_features(tier),
                machine_id=installation_fingerprint,
            )
            self._save_license()

            return {
                "success": True,
                "message": f"License activated: {tier.value}",
                "license": self._license_info.to_dict()
            }

        return {
            "success": False,
            "message": "Invalid license key. Please check your key and try again."
        }

    def activate_keygen_license(
        self,
        license_key: str,
        tier: str,
        expires_at: Optional[str],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Persist a Keygen-validated license into local installation state.

        This binds the activated license to the current host fingerprint so
        license files cannot be transferred across installations.
        """
        tier_normalized = (tier or "").strip().lower()
        metadata = metadata if isinstance(metadata, dict) else {}
        addons = self._extract_addons_from_metadata(metadata)

        remap_enterprise_to_addon = (
            os.environ.get("REMAP_ENTERPRISE_TO_ADDON", "true").strip().lower()
            in {"1", "true", "yes", "on"}
        )

        if tier_normalized == "enterprise" and remap_enterprise_to_addon:
            # Reuse existing enterprise fulfillment while keeping support tier at business/professional.
            # Optional metadata can choose base tier, but add-ons must sit on top of
            # Professional-or-higher base licensing.
            base_tier = str(metadata.get("base_tier") or metadata.get("support_tier") or ADDON_MIN_BASE_TIER).strip().lower()
            if base_tier not in {"professional", "business"}:
                base_tier = ADDON_MIN_BASE_TIER
            tier_normalized = base_tier
            addons.add(ENTERPRISE_FEATURE_PACK_ADDON)

        # --- Add-on key handling -------------------------------------------------
        # When tier is "addon" (or unrecognised but addons are present) the user
        # has entered a standalone add-on license key purchased separately.
        # We merge the add-on markers into the EXISTING base license rather than
        # replacing it.  The base tier and expiry remain unchanged.
        is_addon_only_key = tier_normalized == "addon" or (
            tier_normalized not in {
                "free", "trial", "starter", "professional", "business", "enterprise", "beta"
            }
            and bool(addons)
        )
        if is_addon_only_key:
            if not self._license_info:
                return {
                    "success": False,
                    "message": (
                        "An add-on key requires an active base license. "
                        "Please activate your base tier key first, then apply the add-on key."
                    ),
                }
            if self._license_info.tier not in {
                LicenseTier.PROFESSIONAL,
                LicenseTier.BUSINESS,
                LicenseTier.ENTERPRISE,
            }:
                return {
                    "success": False,
                    "message": (
                        "An add-on key requires an active Professional or higher base license. "
                        "Please activate a Professional or Business tier key first, then apply the add-on key."
                    ),
                }
            features = list(self._license_info.features or [])
            added: list[str] = []
            if ENTERPRISE_FEATURE_PACK_ADDON in addons and ENTERPRISE_FEATURE_PACK_MARKER not in features:
                features.append(ENTERPRISE_FEATURE_PACK_MARKER)
                added.append("Enterprise Integrations Pack")
            if not added:
                return {
                    "success": True,
                    "message": "Add-on already active — no changes made.",
                    "license": self._license_info.to_dict(),
                }
            self._license_info = LicenseInfo(
                tier=self._license_info.tier,
                key=self._license_info.key,
                issued=self._license_info.issued,
                expires=self._license_info.expires,
                features=features,
                machine_id=self._license_info.machine_id,
                registration_email=self._license_info.registration_email,
            )
            self._save_license()
            return {
                "success": True,
                "message": f"Add-on activated: {', '.join(added)}",
                "license": self._license_info.to_dict(),
                "machine_id": self._license_info.machine_id,
                "addon": True,
                "addons_applied": added,
            }
        # -------------------------------------------------------------------------

        tier_map = {
            "free": LicenseTier.FREE,
            "trial": LicenseTier.TRIAL,
            "starter": LicenseTier.STARTER,
            "professional": LicenseTier.PROFESSIONAL,
            "business": LicenseTier.BUSINESS,
            "enterprise": LicenseTier.ENTERPRISE,
            "beta": LicenseTier.PROFESSIONAL,
        }

        if tier_normalized not in tier_map:
            return {
                "success": False,
                "message": f"Unsupported Keygen tier: {tier}",
            }

        target_tier = tier_map[tier_normalized]
        now = datetime.utcnow()
        parsed_expiry = self._parse_datetime_utc_naive(expires_at)

        if target_tier != LicenseTier.FREE:
            if not parsed_expiry:
                return {
                    "success": False,
                    "message": "Keygen license expiry is required for non-free tiers",
                }
            if parsed_expiry <= now:
                return {
                    "success": False,
                    "message": "Cannot activate an expired Keygen license",
                }

        installation_fingerprint = self._get_machine_fingerprint()
        registration_email = None
        base_features = self._get_tier_features(target_tier)
        registration_email = metadata.get("email")
        if ENTERPRISE_FEATURE_PACK_ADDON in addons and ENTERPRISE_FEATURE_PACK_MARKER not in base_features:
            base_features.append(ENTERPRISE_FEATURE_PACK_MARKER)

        self._license_info = LicenseInfo(
            tier=target_tier,
            key=license_key,
            issued=now,
            expires=parsed_expiry if target_tier != LicenseTier.FREE else None,
            features=base_features,
            machine_id=installation_fingerprint,
            registration_email=registration_email,
        )
        self._save_license()

        return {
            "success": True,
            "message": f"License activated: {target_tier.value}",
            "license": self._license_info.to_dict(),
            "machine_id": installation_fingerprint,
        }

    @staticmethod
    def _extract_addons_from_metadata(metadata: Dict[str, Any]) -> set[str]:
        """Extract normalized add-on codes from Keygen license metadata."""
        if not isinstance(metadata, dict):
            return set()

        addons: set[str] = set()

        raw_addons = metadata.get("addons") or metadata.get("add_ons") or metadata.get("addon_codes")
        if isinstance(raw_addons, list):
            addons.update(str(item).strip().lower() for item in raw_addons if item)
        elif isinstance(raw_addons, str):
            addons.update(
                part.strip().lower()
                for part in raw_addons.split(",")
                if part and part.strip()
            )

        if metadata.get("enterprise_addon") is True:
            addons.add(ENTERPRISE_FEATURE_PACK_ADDON)

        return addons

    def _get_tier_features(self, tier: LicenseTier) -> List[str]:
        """Get features for a license tier."""
        features = ["unlimited_audits", "basic_reports"]

        if tier in [LicenseTier.PROFESSIONAL, LicenseTier.BUSINESS, LicenseTier.ENTERPRISE]:
            features.extend(["scheduling", "pdf_reports", "sso_support", "email_support"])

        if tier in [LicenseTier.BUSINESS, LicenseTier.ENTERPRISE]:
            features.extend(["siem_integration", "parallel_execution", "priority_support"])

        if tier == LicenseTier.ENTERPRISE:
            features.extend(["dedicated_support", "custom_development", "sla_guarantee"])

        return features

    def _validate_key_offline(self, key: str) -> Dict[str, Any]:
        """
        Validate license key offline using HMAC signature.

        Key format: TTTT-XXXX-XXXX-SSSS
        - TTTT: Tier prefix (STRT, PROF, BUSN, ENTR)
        - XXXX-XXXX: Random identifier
        - SSSS: Signature (first 4 chars of HMAC)
        """
        parts = key.split("-")
        if len(parts) != 4:
            return {"valid": False}

        prefix = parts[0]
        if prefix not in self.KEY_PREFIXES:
            return {"valid": False}

        # Verify signature
        key_data = f"{parts[0]}-{parts[1]}-{parts[2]}"
        expected_sig = hmac.new(
            self.LICENSE_SECRET.encode(),
            key_data.encode(),
            hashlib.sha256
        ).hexdigest()[:4].upper()

        if parts[3] != expected_sig:
            return {"valid": False}

        return {
            "valid": True,
            "tier": self.KEY_PREFIXES[prefix],
            "days": 365
        }

    @classmethod
    def generate_license_key(cls, tier: LicenseTier) -> str:
        """
        Generate a new license key for a tier.

        Args:
            tier: The license tier

        Returns:
            License key in format TTTT-XXXX-XXXX-SSSS
        """
        # Tier prefix
        prefix_map = {
            LicenseTier.STARTER: "STRT",
            LicenseTier.PROFESSIONAL: "PROF",
            LicenseTier.BUSINESS: "BUSN",
            LicenseTier.ENTERPRISE: "ENTR",
        }

        if tier not in prefix_map:
            raise ValueError(f"Cannot generate key for tier: {tier}")

        prefix = prefix_map[tier]

        # Random identifier (8 chars, split into 2 groups)
        random_id = secrets.token_hex(4).upper()
        part1 = random_id[:4]
        part2 = random_id[4:]

        # Generate signature
        key_data = f"{prefix}-{part1}-{part2}"
        signature = hmac.new(
            cls.LICENSE_SECRET.encode(),
            key_data.encode(),
            hashlib.sha256
        ).hexdigest()[:4].upper()

        return f"{prefix}-{part1}-{part2}-{signature}"

    def deactivate_license(self) -> Dict[str, Any]:
        """Deactivate the current license."""
        self._license_info = LicenseInfo(tier=LicenseTier.FREE)

        if self.license_file.exists():
            self.license_file.unlink()

        return {
            "success": True,
            "message": "License deactivated. Reverted to free tier.",
            "license": self._license_info.to_dict()
        }


# Global instance for convenience
_license_service: Optional[LicenseService] = None


def get_license_service(data_dir: Optional[str] = None) -> LicenseService:
    """Get or create the global license service instance."""
    global _license_service
    if _license_service is None:
        _license_service = LicenseService(data_dir)
    return _license_service
