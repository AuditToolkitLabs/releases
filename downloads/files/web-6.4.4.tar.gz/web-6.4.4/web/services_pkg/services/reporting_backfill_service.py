"""Historical backfill helpers for canonical reporting tables."""

from __future__ import annotations

from typing import Any, Callable

from sqlalchemy.orm import joinedload

from models.compliance import ComplianceAssessment
from models.database import AuditExecution

from .reporting_persistence_service import ReportingPersistenceService


class ReportingBackfillService:
    """Populate canonical reporting tables from historical source-domain rows."""

    def __init__(self, persistence_service: ReportingPersistenceService | None = None):
        self.persistence_service = persistence_service or ReportingPersistenceService()

    def backfill_audit_executions(
        self,
        db_session: Any,
        *,
        limit: int | None = None,
        commit_every: int = 100,
    ) -> dict[str, int]:
        self._validate_batch_size(commit_every)
        query = db_session.query(AuditExecution).options(
            joinedload(AuditExecution.server),
            joinedload(AuditExecution.audit),
        ).order_by(AuditExecution.id.asc())
        if limit is not None:
            query = query.limit(limit)
        return self._process_records(
            db_session,
            query,
            self.persistence_service.persist_audit_execution,
            commit_every,
        )

    def backfill_compliance_assessments(
        self,
        db_session: Any,
        *,
        limit: int | None = None,
        commit_every: int = 100,
    ) -> dict[str, int]:
        self._validate_batch_size(commit_every)
        query = db_session.query(ComplianceAssessment).options(
            joinedload(ComplianceAssessment.server),
        ).order_by(ComplianceAssessment.id.asc())
        if limit is not None:
            query = query.limit(limit)
        return self._process_records(
            db_session,
            query,
            self.persistence_service.persist_compliance_assessment,
            commit_every,
        )

    def backfill_all(
        self,
        db_session: Any,
        *,
        audit_limit: int | None = None,
        assessment_limit: int | None = None,
        commit_every: int = 100,
    ) -> dict[str, dict[str, int]]:
        return {
            'audit_executions': self.backfill_audit_executions(
                db_session,
                limit=audit_limit,
                commit_every=commit_every,
            ),
            'compliance_assessments': self.backfill_compliance_assessments(
                db_session,
                limit=assessment_limit,
                commit_every=commit_every,
            ),
        }

    @staticmethod
    def _validate_batch_size(commit_every: int) -> None:
        if commit_every < 1:
            raise ValueError('commit_every must be greater than or equal to 1')

    @staticmethod
    def _process_records(
        db_session: Any,
        records: Any,
        persist_record: Callable[[Any, Any], dict[str, Any]],
        commit_every: int,
    ) -> dict[str, int]:
        processed = 0
        commits = 0
        for record in records:
            persist_record(db_session, record)
            processed += 1
            if processed % commit_every == 0:
                db_session.commit()
                commits += 1

        if processed and processed % commit_every != 0:
            db_session.commit()
            commits += 1

        return {
            'processed': processed,
            'commits': commits,
        }
