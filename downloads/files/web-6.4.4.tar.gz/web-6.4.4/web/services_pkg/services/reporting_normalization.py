"""Canonical reporting normalization helpers.

This service maps existing source-domain records into canonical reporting payloads
without yet persisting them. The output shape is intentionally close to the
reporting ORM so later DB-backed ingestion can reuse the same contracts.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from .reporting_provenance_service import ReportingProvenanceService


class ReportingNormalizationService:
    """Normalize existing toolkit records into canonical reporting payloads."""

    def __init__(self, provenance_service: ReportingProvenanceService | None = None):
        self.provenance_service = provenance_service or ReportingProvenanceService()

    @staticmethod
    def _normalize_os_type(value: Any) -> str:
        normalized = str(value or '').strip().lower()
        if normalized in {'windows', 'win', 'winrm'}:
            return 'windows'
        if normalized in {'hypervisor', 'esxi', 'vcenter', 'proxmox', 'xen', 'kvm', 'nutanix', 'xo'}:
            return 'hypervisor'
        return 'linux'

    def _source_code_for_server(self, server: Any) -> str:
        os_type = self._normalize_os_type(getattr(server, 'os_type', None))
        if os_type == 'windows':
            return 'main_audit_windows'
        if os_type == 'hypervisor' or getattr(server, 'hypervisor_type', None):
            return 'main_audit_hypervisor'
        return 'main_audit_linux'

    def _source_code_for_producer(self, producer_id: Any = None, source_tool: Any = None) -> str:
        producer_text = str(producer_id or '').strip().lower()
        tool_text = str(source_tool or '').strip().lower()
        if 'asset_discovery' in producer_text or 'asset discovery' in tool_text:
            return 'asset_discovery'
        return 'external_ingest'

    @staticmethod
    def _stable_uid(prefix: str, *parts: Any) -> str:
        payload = '|'.join(str(part or '') for part in parts)
        digest = hashlib.sha256(payload.encode('utf-8')).hexdigest()[:24]
        return f'{prefix}_{digest}'

    @staticmethod
    def _parse_summary(summary: Any) -> dict[str, Any]:
        if isinstance(summary, dict):
            return summary
        if not summary:
            return {}
        if isinstance(summary, str):
            try:
                parsed = json.loads(summary)
            except json.JSONDecodeError:
                return {}
            return parsed if isinstance(parsed, dict) else {}
        return {}

    def normalize_audit_execution(self, execution: Any) -> dict[str, Any]:
        server = getattr(execution, 'server', None)
        audit = getattr(execution, 'audit', None)
        server_name = getattr(server, 'name', None) or f'server-{getattr(execution, "server_id", "unknown")}'
        hostname = getattr(server, 'hostname', None) or server_name
        primary_ip = getattr(server, 'ip_address', None)
        platform = self._normalize_os_type(getattr(server, 'os_type', None))
        executed_at = getattr(execution, 'executed_at', None)
        completed_at = getattr(execution, 'completed_at', None)
        asset_uid = self._stable_uid('asset', 'server', getattr(execution, 'server_id', None), hostname)
        observation_uid = self._stable_uid('obs', 'audit_execution', getattr(execution, 'id', None))
        summary = self._parse_summary(getattr(execution, 'summary', None))
        finding_title = f"Audit execution {getattr(execution, 'status', 'unknown')}"
        audit_name = getattr(audit, 'name', None)
        source_code = self._source_code_for_server(server)
        if audit_name:
            finding_title = f'{audit_name} execution {getattr(execution, "status", "unknown")}'

        return {
            'asset': {
                'asset_uid': asset_uid,
                'display_name': server_name,
                'asset_class': 'server',
                'platform': platform,
                'hostname': hostname,
                'primary_ip': primary_ip,
                'status': 'active',
                'last_seen_at': completed_at or executed_at,
            },
            'asset_link': {
                'source_system': 'main_tool',
                'source_table': 'audit_executions',
                'source_record_id': str(getattr(execution, 'id', '')),
                'source_key': str(getattr(execution, 'server_id', '')),
                'is_primary': True,
            },
            'observation': {
                'observation_uid': observation_uid,
                'observation_type': 'audit_execution',
                'collected_at': executed_at,
                'effective_at': completed_at or executed_at,
                'raw_summary': getattr(execution, 'summary', None),
                'metadata_json': {
                    'audit_id': getattr(execution, 'audit_id', None),
                    'audit_name': audit_name,
                    'status': getattr(execution, 'status', None),
                    'exit_code': getattr(execution, 'exit_code', None),
                    'duration_seconds': getattr(execution, 'duration_seconds', None),
                    'summary': summary,
                },
                'provenance': self.provenance_service.build_metadata(
                    source_code,
                    collected_at=executed_at.isoformat() if executed_at else None,
                ),
            },
            'finding': {
                'finding_uid': self._stable_uid('finding', 'audit_execution', getattr(execution, 'id', None)),
                'title': finding_title,
                'category': 'audit_execution',
                'severity': self._severity_from_execution_status(getattr(execution, 'status', 'unknown')),
                'status': 'open' if getattr(execution, 'status', None) != 'success' else 'resolved',
                'description': getattr(execution, 'output', None),
                'remediation': None,
                'external_reference': str(getattr(execution, 'id', '')),
                'first_observed_at': executed_at,
                'last_observed_at': completed_at or executed_at,
            },
        }

    def normalize_compliance_assessment(self, assessment: Any) -> dict[str, Any]:
        assessed_at = getattr(assessment, 'assessed_at', None)
        server = getattr(assessment, 'server', None)
        server_name = getattr(server, 'name', None) or f'server-{getattr(assessment, "server_id", "unknown")}'
        platform = self._normalize_os_type(getattr(server, 'os_type', None))
        asset_uid = self._stable_uid('asset', 'server', getattr(assessment, 'server_id', None), server_name)

        return {
            'asset': {
                'asset_uid': asset_uid,
                'display_name': server_name,
                'asset_class': 'server',
                'platform': platform,
                'status': 'active',
            },
            'observation': {
                'observation_uid': self._stable_uid('obs', 'compliance_assessment', getattr(assessment, 'id', None)),
                'observation_type': 'compliance_assessment',
                'collected_at': assessed_at,
                'effective_at': assessed_at,
                'raw_summary': getattr(assessment, 'notes', None),
                'metadata_json': {
                    'framework': getattr(assessment, 'framework', None),
                    'framework_version': getattr(assessment, 'framework_version', None),
                    'execution_id': getattr(assessment, 'execution_id', None),
                },
                'provenance': self.provenance_service.build_metadata(
                    'main_compliance',
                    collected_at=assessed_at.isoformat() if assessed_at else None,
                ),
            },
            'control_evaluation': {
                'framework': getattr(assessment, 'framework', None),
                'control_id': 'overall',
                'control_family': 'overall',
                'status': getattr(assessment, 'status', None),
                'score': getattr(assessment, 'compliance_score', None),
                'evidence_summary': getattr(assessment, 'notes', None),
                'evaluated_at': assessed_at,
            },
        }

    def normalize_history_record(self, history_record: Any) -> dict[str, Any]:
        snapshot_at = getattr(history_record, 'date', None)
        return {
            'scope_type': 'asset',
            'scope_key': str(getattr(history_record, 'server_id', '')),
            'asset_class': 'server',
            'risk_score': max(0.0, 100.0 - float(getattr(history_record, 'overall_compliance_score', 0.0))),
            'compliance_score': getattr(history_record, 'overall_compliance_score', None),
            'coverage_score': None,
            'critical_findings': getattr(history_record, 'critical_failures', 0),
            'high_findings': getattr(history_record, 'high_warnings', 0),
            'snapshot_at': snapshot_at,
            'provenance': self.provenance_service.build_metadata(
                'main_history',
                collected_at=snapshot_at.isoformat() if snapshot_at else None,
            ),
        }

    def normalize_external_asset(self, asset: Any) -> dict[str, Any]:
        hostname = getattr(asset, 'hostname', None) or f'external-asset-{getattr(asset, "asset_id", "unknown")}'
        source_code = self._source_code_for_producer(
            producer_id=getattr(asset, 'producer_id', None),
            source_tool=getattr(asset, 'source_tool', None),
        )
        return {
            'asset': {
                'asset_uid': self._stable_uid('asset', 'external_asset', getattr(asset, 'asset_id', None)),
                'display_name': hostname,
                'asset_class': getattr(asset, 'asset_type', None) or 'external_asset',
                'platform': self._platform_from_external_asset(asset),
                'hostname': hostname,
                'primary_ip': self._first_json_list_item(getattr(asset, 'ip_addresses', None)),
                'environment': getattr(asset, 'environment', None),
                'owner': getattr(asset, 'owner', None),
                'status': getattr(asset, 'status', None) or 'active',
                'first_seen_at': getattr(asset, 'first_seen_at', None),
                'last_seen_at': getattr(asset, 'last_seen_at', None),
            },
            'asset_link': {
                'source_system': 'external_ingest',
                'source_table': 'external_assets',
                'source_record_id': str(getattr(asset, 'asset_id', '')),
                'source_key': getattr(asset, 'external_id', None),
                'is_primary': True,
            },
            'provenance': self.provenance_service.build_metadata(
                source_code,
                collected_at=getattr(asset, 'received_at', None).isoformat() if getattr(asset, 'received_at', None) else None,
                producer_id=getattr(asset, 'producer_id', None),
                source_tool=getattr(asset, 'source_tool', None),
            ),
        }

    def normalize_external_finding(self, finding: Any) -> dict[str, Any]:
        observed_at = getattr(finding, 'finding_timestamp', None) or getattr(finding, 'received_at', None)
        asset_uid = self._stable_uid(
            'asset',
            'external_finding_asset',
            getattr(finding, 'asset_hostname', None),
            getattr(finding, 'asset_ip', None),
        )
        source_code = self._source_code_for_producer(
            producer_id=getattr(finding, 'producer_id', None),
            source_tool=getattr(finding, 'source_tool', None),
        )
        return {
            'asset': {
                'asset_uid': asset_uid,
                'display_name': getattr(finding, 'asset_hostname', None) or getattr(finding, 'asset_ip', None) or 'External asset',
                'asset_class': 'external_asset',
                'platform': 'unknown',
                'hostname': getattr(finding, 'asset_hostname', None),
                'primary_ip': getattr(finding, 'asset_ip', None),
                'status': 'active',
            },
            'observation': {
                'observation_uid': self._stable_uid('obs', 'external_finding', getattr(finding, 'ingest_id', None)),
                'observation_type': 'external_finding',
                'collected_at': getattr(finding, 'received_at', None),
                'effective_at': observed_at,
                'raw_summary': getattr(finding, 'description', None),
                'metadata_json': {
                    'producer_id': getattr(finding, 'producer_id', None),
                    'source_tool': getattr(finding, 'source_tool', None),
                    'external_id': getattr(finding, 'external_id', None),
                    'external_url': getattr(finding, 'external_url', None),
                    'cvss_score': getattr(finding, 'cvss_score', None),
                },
                'provenance': self.provenance_service.build_metadata(
                    source_code,
                    collected_at=getattr(finding, 'received_at', None).isoformat() if getattr(finding, 'received_at', None) else None,
                    producer_id=getattr(finding, 'producer_id', None),
                    source_tool=getattr(finding, 'source_tool', None),
                ),
            },
            'finding': {
                'finding_uid': self._stable_uid('finding', 'external_finding', getattr(finding, 'ingest_id', None)),
                'title': getattr(finding, 'title', None) or 'External finding',
                'category': 'external_finding',
                'severity': (getattr(finding, 'severity', None) or 'unknown').lower(),
                'priority_score': getattr(finding, 'cvss_score', None),
                'status': getattr(finding, 'status', None) or 'open',
                'description': getattr(finding, 'description', None),
                'remediation': getattr(finding, 'remediation', None),
                'external_reference': getattr(finding, 'external_id', None) or getattr(finding, 'ingest_id', None),
                'first_observed_at': observed_at,
                'last_observed_at': getattr(finding, 'updated_at', None) or observed_at,
            },
        }

    @staticmethod
    def _severity_from_execution_status(status: str) -> str:
        normalized = (status or '').lower()
        if normalized == 'success':
            return 'info'
        if normalized in {'failure', 'timeout'}:
            return 'high'
        if normalized == 'running':
            return 'low'
        return 'medium'

    @staticmethod
    def _platform_from_external_asset(asset: Any) -> str:
        os_name = (getattr(asset, 'os_name', None) or '').lower()
        if 'windows' in os_name:
            return 'windows'
        if any(token in os_name for token in ('linux', 'ubuntu', 'debian', 'rhel', 'centos', 'fedora', 'suse')):
            return 'linux'
        return 'unknown'

    @staticmethod
    def _first_json_list_item(raw_value: Any) -> str | None:
        if not raw_value:
            return None
        if isinstance(raw_value, list):
            return str(raw_value[0]) if raw_value else None
        if isinstance(raw_value, str):
            try:
                parsed = json.loads(raw_value)
            except json.JSONDecodeError:
                return raw_value
            if isinstance(parsed, list) and parsed:
                return str(parsed[0])
        return None
