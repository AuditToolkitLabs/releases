"""Persistence helpers for canonical reporting records."""

from __future__ import annotations

from typing import Any

from models.reporting import (
    ReportingAsset,
    ReportingAssetLink,
    ReportingControlEvaluation,
    ReportingDataSource,
    ReportingFinding,
    ReportingObservation,
)

from .reporting_normalization import ReportingNormalizationService


class ReportingPersistenceService:
    """Upsert canonical reporting rows from normalized source records."""

    def __init__(self, normalization_service: ReportingNormalizationService | None = None):
        self.normalization_service = normalization_service or ReportingNormalizationService()

    def persist_audit_execution(self, db_session: Any, execution: Any) -> dict[str, Any]:
        payload = self.normalization_service.normalize_audit_execution(execution)
        persisted = self._persist_common(db_session, payload)
        finding_payload = payload['finding']
        finding = self._get_or_create_finding(
            db_session,
            persisted['asset'],
            persisted['observation'],
            finding_payload,
        )
        db_session.flush()
        return {
            'asset_id': persisted['asset'].id,
            'observation_id': persisted['observation'].id,
            'finding_id': finding.id,
            'source_code': persisted['data_source'].source_code,
        }

    def persist_compliance_assessment(self, db_session: Any, assessment: Any) -> dict[str, Any]:
        payload = self.normalization_service.normalize_compliance_assessment(assessment)
        persisted = self._persist_common(db_session, payload)
        control = self._get_or_create_control_evaluation(
            db_session,
            persisted['asset'],
            persisted['observation'],
            payload['control_evaluation'],
        )
        db_session.flush()
        return {
            'asset_id': persisted['asset'].id,
            'observation_id': persisted['observation'].id,
            'control_evaluation_id': control.id,
            'source_code': persisted['data_source'].source_code,
        }

    def _persist_common(self, db_session: Any, payload: dict[str, Any]) -> dict[str, Any]:
        asset = self._get_or_create_asset(db_session, payload['asset'])
        self._get_or_create_asset_link(db_session, asset, payload.get('asset_link'))

        observation_payload = payload['observation']
        provenance = observation_payload.get('provenance', {})
        data_source = self._get_or_create_data_source(db_session, provenance)
        observation = self._get_or_create_observation(db_session, asset, data_source, observation_payload)

        db_session.flush()
        return {
            'asset': asset,
            'data_source': data_source,
            'observation': observation,
        }

    @staticmethod
    def _get_or_create_asset(db_session: Any, payload: dict[str, Any]) -> ReportingAsset:
        asset = db_session.query(ReportingAsset).filter_by(asset_uid=payload['asset_uid']).first()
        if asset is None:
            asset = ReportingAsset(asset_uid=payload['asset_uid'])
            db_session.add(asset)

        for field in (
            'display_name', 'asset_class', 'platform', 'hostname', 'primary_ip',
            'environment', 'owner', 'business_unit', 'status', 'criticality',
            'first_seen_at', 'last_seen_at',
        ):
            if field in payload:
                setattr(asset, field, payload.get(field))
        return asset

    @staticmethod
    def _get_or_create_asset_link(db_session: Any, asset: ReportingAsset, payload: dict[str, Any] | None) -> ReportingAssetLink | None:
        if not payload:
            return None

        link = db_session.query(ReportingAssetLink).filter_by(
            reporting_asset_id=asset.id,
            source_system=payload['source_system'],
            source_table=payload['source_table'],
            source_record_id=payload['source_record_id'],
        ).first()
        if link is None:
            link = ReportingAssetLink(
                reporting_asset=asset,
                source_system=payload['source_system'],
                source_table=payload['source_table'],
                source_record_id=payload['source_record_id'],
            )
            db_session.add(link)

        link.source_key = payload.get('source_key')
        link.is_primary = bool(payload.get('is_primary', False))
        return link

    @staticmethod
    def _get_or_create_data_source(db_session: Any, payload: dict[str, Any]) -> ReportingDataSource:
        source_code = payload['source_code']
        data_source = db_session.query(ReportingDataSource).filter_by(source_code=source_code).first()
        if data_source is None:
            data_source = ReportingDataSource(source_code=source_code)
            db_session.add(data_source)

        data_source.source_type = payload.get('source_type')
        data_source.source_name = payload.get('source_name')
        data_source.collection_method = payload.get('collection_method')
        data_source.trust_level = payload.get('trust_level')
        data_source.default_confidence_score = payload.get('confidence_score')
        data_source.active = True
        return data_source

    @staticmethod
    def _get_or_create_observation(
        db_session: Any,
        asset: ReportingAsset,
        data_source: ReportingDataSource,
        payload: dict[str, Any],
    ) -> ReportingObservation:
        observation = db_session.query(ReportingObservation).filter_by(
            reporting_asset_id=asset.id,
            reporting_data_source_id=data_source.id,
            observation_type=payload['observation_type'],
            collected_at=payload.get('collected_at'),
        ).first()
        if observation is None:
            observation = ReportingObservation(
                reporting_asset=asset,
                reporting_data_source=data_source,
                observation_type=payload['observation_type'],
                collected_at=payload.get('collected_at'),
            )
            db_session.add(observation)

        observation.effective_at = payload.get('effective_at')
        observation.confidence_score = payload.get('provenance', {}).get('confidence_score', 0.5)
        observation.raw_summary = payload.get('raw_summary')
        observation.metadata_json = payload.get('metadata_json')
        return observation

    @staticmethod
    def _get_or_create_finding(
        db_session: Any,
        asset: ReportingAsset,
        observation: ReportingObservation,
        payload: dict[str, Any],
    ) -> ReportingFinding:
        finding = db_session.query(ReportingFinding).filter_by(finding_uid=payload['finding_uid']).first()
        if finding is None:
            finding = ReportingFinding(
                finding_uid=payload['finding_uid'],
                reporting_asset=asset,
                reporting_observation=observation,
            )
            db_session.add(finding)

        finding.title = payload.get('title')
        finding.category = payload.get('category')
        finding.severity = payload.get('severity')
        finding.priority_score = payload.get('priority_score')
        finding.status = payload.get('status')
        finding.description = payload.get('description')
        finding.remediation = payload.get('remediation')
        finding.external_reference = payload.get('external_reference')
        finding.first_observed_at = payload.get('first_observed_at')
        finding.last_observed_at = payload.get('last_observed_at')
        return finding

    @staticmethod
    def _get_or_create_control_evaluation(
        db_session: Any,
        asset: ReportingAsset,
        observation: ReportingObservation,
        payload: dict[str, Any],
    ) -> ReportingControlEvaluation:
        control = db_session.query(ReportingControlEvaluation).filter_by(
            reporting_observation_id=observation.id,
            framework=payload['framework'],
            control_id=payload['control_id'],
        ).first()
        if control is None:
            control = ReportingControlEvaluation(
                reporting_asset=asset,
                reporting_observation=observation,
                framework=payload['framework'],
                control_id=payload['control_id'],
            )
            db_session.add(control)

        control.control_family = payload.get('control_family')
        control.status = payload.get('status')
        control.score = payload.get('score')
        control.evidence_summary = payload.get('evidence_summary')
        control.evaluated_at = payload.get('evaluated_at')
        return control
