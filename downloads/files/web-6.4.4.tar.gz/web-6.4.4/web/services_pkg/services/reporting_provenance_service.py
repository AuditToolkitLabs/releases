"""Helpers for canonical reporting provenance metadata."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ReportingSourceSpec:
    """Static provenance metadata for a canonical reporting producer."""

    source_code: str
    source_type: str
    source_name: str
    collection_method: str
    trust_level: str
    default_confidence_score: float


REPORTING_SOURCE_SPECS: dict[str, ReportingSourceSpec] = {
    'main_audit_linux': ReportingSourceSpec(
        source_code='main_audit_linux',
        source_type='native_audit',
        source_name='Main Audit Toolkit (Linux)',
        collection_method='ssh',
        trust_level='authoritative',
        default_confidence_score=1.0,
    ),
    'main_audit_windows': ReportingSourceSpec(
        source_code='main_audit_windows',
        source_type='native_audit',
        source_name='Main Audit Toolkit (Windows)',
        collection_method='winrm',
        trust_level='authoritative',
        default_confidence_score=1.0,
    ),
    'main_audit_hypervisor': ReportingSourceSpec(
        source_code='main_audit_hypervisor',
        source_type='native_audit',
        source_name='Main Audit Toolkit (Hypervisor)',
        collection_method='api',
        trust_level='authoritative',
        default_confidence_score=1.0,
    ),
    'main_compliance': ReportingSourceSpec(
        source_code='main_compliance',
        source_type='compliance',
        source_name='Main Audit Toolkit Compliance',
        collection_method='derived',
        trust_level='authoritative',
        default_confidence_score=0.95,
    ),
    'main_history': ReportingSourceSpec(
        source_code='main_history',
        source_type='analytics',
        source_name='Main Audit Toolkit History Analytics',
        collection_method='derived',
        trust_level='high',
        default_confidence_score=0.9,
    ),
    'external_ingest': ReportingSourceSpec(
        source_code='external_ingest',
        source_type='scanner',
        source_name='External Ingest API',
        collection_method='api',
        trust_level='asserted',
        default_confidence_score=0.75,
    ),
    'asset_discovery': ReportingSourceSpec(
        source_code='asset_discovery',
        source_type='scanner',
        source_name='Asset Discovery Service',
        collection_method='api',
        trust_level='asserted',
        default_confidence_score=0.8,
    ),
}


class ReportingProvenanceService:
    """Produces provenance metadata attached to canonical reporting records."""

    def get_source_spec(self, source_code: str) -> ReportingSourceSpec:
        try:
            return REPORTING_SOURCE_SPECS[source_code]
        except KeyError as exc:
            raise ValueError(f'Unknown reporting source code: {source_code}') from exc

    def build_metadata(self, source_code: str, **overrides: Any) -> dict[str, Any]:
        spec = self.get_source_spec(source_code)
        metadata = {
            'source_code': spec.source_code,
            'source_type': spec.source_type,
            'source_name': spec.source_name,
            'collection_method': spec.collection_method,
            'trust_level': spec.trust_level,
            'confidence_score': spec.default_confidence_score,
        }
        metadata.update({key: value for key, value in overrides.items() if value is not None})
        return metadata
