"""Query and assembly helpers for compatibility reporting paths."""

from __future__ import annotations

import json
from datetime import datetime
from types import SimpleNamespace
from typing import Any

from .reporting_normalization import ReportingNormalizationService


class ReportingQueryService:
    """Build compatibility report payloads on top of canonical normalization."""

    def __init__(self, normalization_service: ReportingNormalizationService | None = None):
        self.normalization_service = normalization_service or ReportingNormalizationService()

    def build_compatibility_report(
        self,
        report_type: str,
        target_servers: list[dict[str, Any]],
        server_reports: list[dict[str, Any]],
        generated_at: datetime | None = None,
    ) -> dict[str, Any]:
        generated_at = generated_at or datetime.now()
        report_data = {
            'title': 'Security Audit Report',
            'generated': generated_at.isoformat(),
            'schema_version': '1.0',
            'report_type': report_type,
            'servers': list(server_reports),
            'summary': {
                'total_servers': len(target_servers),
                'total_checks': 0,
                'total_pass': 0,
                'total_warn': 0,
                'total_fail': 0,
                'total_skip': 0,
                'compliance_percentage': 0,
            },
        }

        canonical_assets: list[dict[str, Any]] = []
        canonical_findings: list[dict[str, Any]] = []
        canonical_sources: set[str] = set()

        for server_report in report_data['servers']:
            if server_report.get('status') != 'success':
                continue

            metrics = server_report['metrics']
            report_data['summary']['total_checks'] += metrics.get('total', 0)
            report_data['summary']['total_pass'] += metrics.get('pass', 0)
            report_data['summary']['total_warn'] += metrics.get('warn', 0)
            report_data['summary']['total_fail'] += metrics.get('fail', 0)
            report_data['summary']['total_skip'] += metrics.get('skip', 0)

            canonical_payload = self._normalize_server_report(server_report)
            canonical_assets.append(canonical_payload['asset'])
            canonical_findings.append(canonical_payload['finding'])
            canonical_sources.add(canonical_payload['observation']['provenance']['source_code'])

        if report_data['summary']['total_checks'] > 0:
            report_data['summary']['compliance_percentage'] = round(
                report_data['summary']['total_pass'] / report_data['summary']['total_checks'] * 100,
                2,
            )

        total_servers = report_data['summary']['total_servers']
        total_checks = report_data['summary']['total_checks']
        total_skip = report_data['summary']['total_skip']
        successful_servers = sum(1 for item in report_data['servers'] if item.get('status') == 'success')
        failed_servers = total_servers - successful_servers
        collection_success_rate = round((successful_servers / total_servers * 100) if total_servers > 0 else 0, 2)
        coverage_score = round(((total_checks - total_skip) / total_checks * 100) if total_checks > 0 else 0, 2)

        report_data['completeness'] = {
            'collection': {
                'successful_servers': successful_servers,
                'failed_servers': failed_servers,
                'collection_success_rate': collection_success_rate,
            },
            'checks': {
                'total_checks': total_checks,
                'non_skip_checks': total_checks - total_skip,
                'skip_checks': total_skip,
                'coverage_score': coverage_score,
            },
            'confidence_score': round((collection_success_rate + coverage_score) / 2, 2),
        }

        report_data['reporting_context'] = {
            'assembly_mode': 'compatibility',
            'canonical_assets': len(canonical_assets),
            'canonical_findings': len(canonical_findings),
            'source_codes': sorted(canonical_sources),
        }

        return report_data

    def build_audit_execution_report(
        self,
        execution: Any,
        *,
        server: Any = None,
        audit: Any = None,
    ) -> dict[str, Any]:
        metrics = self._metrics_from_output(getattr(execution, 'output', None))
        started_at = getattr(execution, 'executed_at', None)
        completed_at = getattr(execution, 'completed_at', None)
        duration = None
        if started_at and completed_at:
            duration = (completed_at - started_at).total_seconds()

        execution_view = SimpleNamespace(
            id=getattr(execution, 'id', None),
            server_id=getattr(execution, 'server_id', None),
            audit_id=getattr(execution, 'audit_id', None),
            status=getattr(execution, 'status', None),
            exit_code=getattr(execution, 'exit_code', None),
            output=getattr(execution, 'output', None),
            summary=getattr(execution, 'summary', None),
            duration_seconds=getattr(execution, 'duration_seconds', None),
            executed_at=started_at,
            completed_at=completed_at,
            server=SimpleNamespace(
                **{
                    **getattr(server or getattr(execution, 'server', None), '__dict__', {}),
                    'os_type': getattr(server or getattr(execution, 'server', None), 'os_type', None),
                    'hypervisor_type': getattr(server or getattr(execution, 'server', None), 'hypervisor_type', None),
                }
            ),
            audit=audit or getattr(execution, 'audit', None),
        )
        canonical_payload = self.normalization_service.normalize_audit_execution(execution_view)

        return {
            'id': getattr(execution, 'id', None),
            'audit_name': getattr(audit or getattr(execution, 'audit', None), 'name', None) or 'Unknown',
            'audit_path': getattr(audit or getattr(execution, 'audit', None), 'file_path', None),
            'server_id': getattr(execution, 'server_id', None),
            'server_hostname': getattr(server or getattr(execution, 'server', None), 'hostname', None),
            'status': getattr(execution, 'status', None),
            'started_at': started_at.isoformat() if started_at else None,
            'completed_at': completed_at.isoformat() if completed_at else None,
            'duration_seconds': duration,
            'results': metrics,
            'exit_code': getattr(execution, 'exit_code', None),
            'output': getattr(execution, 'output', None),
            'reporting_context': {
                'assembly_mode': 'audit_execution',
                'canonical_asset_uid': canonical_payload['asset']['asset_uid'],
                'canonical_finding_uid': canonical_payload['finding']['finding_uid'],
                'source_codes': [canonical_payload['observation']['provenance']['source_code']],
            },
        }

    def build_audit_execution_canonical_payload(
        self,
        execution: Any,
        *,
        server: Any = None,
        audit: Any = None,
    ) -> dict[str, Any]:
        execution_view = SimpleNamespace(
            id=getattr(execution, 'id', None),
            server_id=getattr(execution, 'server_id', None),
            audit_id=getattr(execution, 'audit_id', None),
            status=getattr(execution, 'status', None),
            exit_code=getattr(execution, 'exit_code', None),
            output=getattr(execution, 'output', None),
            summary=getattr(execution, 'summary', None),
            duration_seconds=getattr(execution, 'duration_seconds', None),
            executed_at=getattr(execution, 'executed_at', None),
            completed_at=getattr(execution, 'completed_at', None),
            server=SimpleNamespace(
                **{
                    **getattr(server or getattr(execution, 'server', None), '__dict__', {}),
                    'os_type': getattr(server or getattr(execution, 'server', None), 'os_type', None),
                    'hypervisor_type': getattr(server or getattr(execution, 'server', None), 'hypervisor_type', None),
                }
            ),
            audit=audit or getattr(execution, 'audit', None),
        )
        canonical_payload = self.normalization_service.normalize_audit_execution(execution_view)
        canonical_payload['source_record'] = {
            'execution_id': getattr(execution, 'id', None),
            'server_id': getattr(execution, 'server_id', None),
            'audit_id': getattr(execution, 'audit_id', None),
            'audit_name': getattr(audit or getattr(execution, 'audit', None), 'name', None),
            'server_hostname': getattr(server or getattr(execution, 'server', None), 'hostname', None),
        }
        return canonical_payload

    def build_compliance_assessment_report(
        self,
        assessment: Any,
        *,
        server: Any = None,
        controls: list[Any] | None = None,
    ) -> dict[str, Any]:
        assessment_view = SimpleNamespace(
            id=getattr(assessment, 'id', None),
            server_id=getattr(assessment, 'server_id', None),
            framework=getattr(assessment, 'framework', None),
            framework_version=getattr(assessment, 'framework_version', None),
            execution_id=getattr(assessment, 'execution_id', None),
            compliance_score=getattr(assessment, 'compliance_score', None),
            notes=getattr(assessment, 'notes', None),
            assessed_at=getattr(assessment, 'assessed_at', None),
            status=getattr(assessment, 'status', None),
            server=server or getattr(assessment, 'server', None),
        )
        canonical_payload = self.normalization_service.normalize_compliance_assessment(assessment_view)
        control_rows = controls if controls is not None else list(getattr(assessment, 'controls', []) or [])
        base_payload = assessment.to_dict() if hasattr(assessment, 'to_dict') else {
            'id': getattr(assessment, 'id', None),
            'server_id': getattr(assessment, 'server_id', None),
            'framework': getattr(assessment, 'framework', None),
            'framework_version': getattr(assessment, 'framework_version', None),
            'compliance_score': getattr(assessment, 'compliance_score', None),
            'status': getattr(assessment, 'status', None),
            'assessed_at': getattr(assessment, 'assessed_at', None).isoformat() if getattr(assessment, 'assessed_at', None) else None,
        }
        base_payload['controls'] = [c.to_dict() if hasattr(c, 'to_dict') else c for c in control_rows]
        base_payload['reporting_context'] = {
            'assembly_mode': 'compliance_assessment',
            'canonical_asset_uid': canonical_payload['asset']['asset_uid'],
            'control_evaluation': {
                'framework': canonical_payload['control_evaluation']['framework'],
                'control_id': canonical_payload['control_evaluation']['control_id'],
                'status': canonical_payload['control_evaluation']['status'],
                'score': canonical_payload['control_evaluation']['score'],
            },
            'source_codes': [canonical_payload['observation']['provenance']['source_code']],
        }
        return base_payload

    def build_compliance_assessment_canonical_payload(
        self,
        assessment: Any,
        *,
        server: Any = None,
        controls: list[Any] | None = None,
    ) -> dict[str, Any]:
        assessment_view = SimpleNamespace(
            id=getattr(assessment, 'id', None),
            server_id=getattr(assessment, 'server_id', None),
            framework=getattr(assessment, 'framework', None),
            framework_version=getattr(assessment, 'framework_version', None),
            execution_id=getattr(assessment, 'execution_id', None),
            compliance_score=getattr(assessment, 'compliance_score', None),
            notes=getattr(assessment, 'notes', None),
            assessed_at=getattr(assessment, 'assessed_at', None),
            status=getattr(assessment, 'status', None),
            server=server or getattr(assessment, 'server', None),
        )
        canonical_payload = self.normalization_service.normalize_compliance_assessment(assessment_view)
        control_rows = controls if controls is not None else list(getattr(assessment, 'controls', []) or [])
        canonical_payload['controls'] = [
            control.to_dict() if hasattr(control, 'to_dict') else control
            for control in control_rows
        ]
        canonical_payload['source_record'] = {
            'assessment_id': getattr(assessment, 'id', None),
            'server_id': getattr(assessment, 'server_id', None),
            'framework': getattr(assessment, 'framework', None),
            'framework_version': getattr(assessment, 'framework_version', None),
            'execution_id': getattr(assessment, 'execution_id', None),
            'server_hostname': getattr(server or getattr(assessment, 'server', None), 'hostname', None),
        }
        return canonical_payload

    def _normalize_server_report(self, server_report: dict[str, Any]) -> dict[str, Any]:
        metrics = server_report.get('metrics', {})
        server_os_type = server_report.get('os_type') or server_report.get('os') or 'linux'
        summary = json.dumps(
            {
                'pass': metrics.get('pass', 0),
                'warn': metrics.get('warn', 0),
                'fail': metrics.get('fail', 0),
                'skip': metrics.get('skip', 0),
                'total': metrics.get('total', 0),
            }
        )
        synthetic_execution = SimpleNamespace(
            id=f"remote-log:{server_report.get('host', 'unknown')}:{server_report.get('name', 'unknown')}",
            server_id=server_report.get('host', server_report.get('name', 'unknown')),
            audit_id=None,
            status='success' if metrics.get('fail', 0) == 0 else 'failure',
            exit_code=0 if metrics.get('fail', 0) == 0 else 1,
            output=server_report.get('log_preview') or summary,
            summary=summary,
            duration_seconds=None,
            executed_at=None,
            completed_at=None,
            server=SimpleNamespace(
                name=server_report.get('name'),
                hostname=server_report.get('name'),
                ip_address=server_report.get('host'),
                os_type=server_os_type,
                hypervisor_type=server_report.get('hypervisor_type'),
            ),
            audit=None,
        )
        return self.normalization_service.normalize_audit_execution(synthetic_execution)

    @staticmethod
    def _metrics_from_output(output_text: str | None) -> dict[str, int]:
        metrics = {'pass': 0, 'warn': 0, 'fail': 0, 'skip': 0, 'total': 0}
        if not output_text:
            return metrics

        for line in output_text.split('\n'):
            if '[PASS]' in line:
                metrics['pass'] += 1
                metrics['total'] += 1
            elif '[WARN]' in line:
                metrics['warn'] += 1
                metrics['total'] += 1
            elif '[FAIL]' in line:
                metrics['fail'] += 1
                metrics['total'] += 1
            elif '[SKIP]' in line:
                metrics['skip'] += 1
                metrics['total'] += 1

        return metrics
