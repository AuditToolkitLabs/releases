[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [switch]$AutoInstallPython,
    [switch]$InstallOpenSSHClient,
    [switch]$InstallOpenSSHServer,
    [switch]$ConfigureStartup,
    [switch]$OpenFirewall,
    [switch]$StartServer,
    [switch]$Quiet,
    [ValidateSet('install','patch','minor','major')]
    [string]$InstallMode = 'install',
    [string]$StateRoot = '',
    [Alias('InitialAdminPassword')]
    [string]$InitialAdminSecret,
    # Windows MSI/server installs require PostgreSQL.
    # Pass an explicit postgresql:// URL to override host/user/password values.
    [string]$DatabaseUrl = ''
)

$null = $Quiet

$ErrorActionPreference = "Stop"

$script:ToolkitStateRoot = if ($StateRoot -and $StateRoot.Trim()) {
    $StateRoot.Trim()
}
elseif ($env:SECURITY_AUDIT_STATE -and $env:SECURITY_AUDIT_STATE.Trim()) {
    $env:SECURITY_AUDIT_STATE.Trim()
}
else {
    Join-Path $env:ProgramData 'SecurityAuditToolkit'
}

$script:SetupLogPath = Join-Path $script:ToolkitStateRoot 'logs\setup-web-bootstrap.log'
try {
    New-Item -ItemType Directory -Path (Split-Path -Parent $script:SetupLogPath) -Force | Out-Null
    Add-Content -Path $script:SetupLogPath -Value "`n==== setup-web.ps1 start $(Get-Date -Format o) ====" -Encoding UTF8
} catch {
    Write-Verbose 'Suppressed non-fatal error.'
}

function Initialize-ToolkitStateRoot {
    foreach ($relativePath in @('logs', 'runtime', 'runtime\tmp', 'Backups', 'Results')) {
        New-Item -ItemType Directory -Path (Join-Path $script:ToolkitStateRoot $relativePath) -Force | Out-Null
    }
}

function New-WindowsUpgradeSnapshot {
    param(
        [Parameter(Mandatory)][string]$ResolvedInstallMode,
        [Parameter(Mandatory)][string]$InstallRoot,
        [Parameter(Mandatory)][string]$ResolvedStateRoot
    )

    if ($ResolvedInstallMode -eq 'install') {
        return
    }

    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $snapshotRoot = Join-Path $ResolvedStateRoot (Join-Path 'Backups' ("windows-upgrade-$timestamp"))
    New-Item -ItemType Directory -Path $snapshotRoot -Force | Out-Null

    @(
        "install_mode=$ResolvedInstallMode"
        "created_at=$((Get-Date).ToUniversalTime().ToString('o'))"
        "install_root=$InstallRoot"
        "state_root=$ResolvedStateRoot"
    ) | Out-File -FilePath (Join-Path $snapshotRoot 'metadata.txt') -Encoding UTF8 -Force

    $toolkitRegKey = 'HKLM:\Software\SecurityAuditToolkit'
    if (Test-Path $toolkitRegKey) {
        reg.exe export 'HKLM\Software\SecurityAuditToolkit' (Join-Path $snapshotRoot 'security-audit-toolkit.reg') /y *> $null
    }

    foreach ($candidate in @(
        (Join-Path $ResolvedStateRoot 'runtime\initial-admin-credentials.txt'),
        (Join-Path $ResolvedStateRoot 'runtime\FIRST-LOGIN.txt')
    )) {
        if (Test-Path $candidate) {
            Copy-Item -Path $candidate -Destination $snapshotRoot -Force -ErrorAction SilentlyContinue
        }
    }

    Write-Info "Created Windows upgrade snapshot: $snapshotRoot"
}

function Write-SetupLog {
    param(
        [Parameter(Mandatory)][string]$Level,
        [Parameter(Mandatory)][string]$Message
    )

    try {
        Add-Content -Path $script:SetupLogPath -Value ("[{0}] {1} {2}" -f $Level, (Get-Date -Format o), $Message) -Encoding UTF8
    } catch {
        Write-Verbose 'Suppressed non-fatal error.'
    }
}

function Write-Info {
    param([string]$Message)
    Write-SetupLog -Level 'INFO' -Message $Message
    if (-not $Quiet) { Write-Host "[INFO] $Message" -ForegroundColor Cyan }
}

function Write-Ok {
    param([string]$Message)
    Write-SetupLog -Level 'OK' -Message $Message
    if (-not $Quiet) { Write-Host "[OK]   $Message" -ForegroundColor Green }
}

function Write-Warn {
    param([string]$Message)
    Write-SetupLog -Level 'WARN' -Message $Message
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

trap {
    $errText = $_ | Out-String
    Write-SetupLog -Level 'ERROR' -Message $errText.Trim()
    throw
}

function ConvertTo-PsSingleQuotedString {
    param([string]$Value)
    if ($null -eq $Value) {
        return ""
    }

    return ($Value -replace "'", "''")
}

function ConvertTo-SqlLiteral {
    param([string]$Value)

    if ($null -eq $Value) {
        return ""
    }

    return ($Value -replace "'", "''")
}

function Test-TcpPortListening {
    param([int]$Port)

    try {
        return @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop).Count -gt 0
    }
    catch {
        return $false
    }
}

function Stop-ProcessesListeningOnPorts {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param([int[]]$Ports)

    foreach ($port in $Ports) {
        $listeners = @()
        try {
            $listeners = @(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction Stop)
        }
        catch {
            $listeners = @()
        }

        $owningProcessIds = $listeners | Select-Object -ExpandProperty OwningProcess -Unique
        foreach ($processId in $owningProcessIds) {
            if (-not $processId -or $processId -eq 0 -or $processId -eq $PID) {
                continue
            }

            try {
                $process = Get-Process -Id $processId -ErrorAction Stop
                if ($PSCmdlet.ShouldProcess("PID $processId", "Stop process listening on TCP/$port")) {
                    Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue
                    Write-Info "Stopped process '$($process.ProcessName)' (PID $processId) listening on TCP/$port."
                }
            }
            catch {
                Write-Verbose 'Suppressed non-fatal error.'
            }
        }
    }
}

function Get-HttpStatusCode {
    param(
        [string]$Uri,
        [switch]$AllowInvalidCertificate
    )

    $previousCallback = [System.Net.ServicePointManager]::ServerCertificateValidationCallback
    $previousProtocols = [System.Net.ServicePointManager]::SecurityProtocol

    try {
        if ($Uri -like 'https://*') {
            [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
        }

        if ($AllowInvalidCertificate) {
            [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
        }

        $response = Invoke-WebRequest -Uri $Uri -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
        return [int]$response.StatusCode
    }
    catch [System.Net.WebException] {
        if ($_.Exception.Response) {
            return [int]$_.Exception.Response.StatusCode
        }
        return 0
    }
    catch {
        return 0
    }
    finally {
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = $previousCallback
        [System.Net.ServicePointManager]::SecurityProtocol = $previousProtocols
    }
}

function Wait-HttpReady {
    param(
        [string]$Uri,
        [int]$TimeoutSeconds = 120,
        [switch]$AllowInvalidCertificate
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        $status = Get-HttpStatusCode -Uri $Uri -AllowInvalidCertificate:$AllowInvalidCertificate
        if ($status -ge 200 -and $status -lt 400) {
            return $true
        }
        Start-Sleep -Seconds 2
    }

    return $false
}

function Show-InitialAdminOnboarding {
    param(
        [string]$ResolvedSecret,
        [string]$SecretSource,
        [string]$OnboardingPath,
        [string]$GuidePath
    )

    Write-Output ""
    Write-Host "Initial admin onboarding:" -ForegroundColor Cyan
    Write-Host "  Username         : admin" -ForegroundColor White
    if ($ResolvedSecret) {
        Write-Host "  Initial password : $ResolvedSecret" -ForegroundColor White
        Write-Host "  Password source  : $SecretSource" -ForegroundColor White
    }
    else {
        Write-Host "  Initial password : Generated on first startup (production mode)" -ForegroundColor White
        Write-Host "  Password source  : generated_random" -ForegroundColor White
    }
    Write-Host "  Credentials file : $OnboardingPath" -ForegroundColor White
    Write-Host "  First-login guide: $GuidePath" -ForegroundColor White
    Write-Host "  Policy           : Password change is required at first login" -ForegroundColor White
    Write-Host "  Browser support  : Use Edge/Chrome/Firefox (IE on Windows Server 2019 is not supported)" -ForegroundColor White
}

function Test-IsAdministrator {
    $currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-IsSystemContext {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        return ($identity.User -and $identity.User.Value -eq 'S-1-5-18')
    }
    catch {
        return $false
    }
}

function Invoke-SystemOneShotScript {
    param(
        [Parameter(Mandatory)][string]$TaskName,
        [Parameter(Mandatory)][string]$ScriptBody,
        [int]$TimeoutSeconds = 600
    )

    $tempRoot = Join-Path $script:ToolkitStateRoot 'runtime\tmp'
    New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

    $scriptPath = Join-Path $tempRoot ($TaskName + '.ps1')
    $resultPath = Join-Path $tempRoot ($TaskName + '.result.txt')
    Set-Content -Path $scriptPath -Value $ScriptBody -Encoding UTF8
    Remove-Item -Path $resultPath -Force -ErrorAction SilentlyContinue

    try {
        schtasks /Delete /TN $TaskName /F *> $null
        schtasks /Create /TN $TaskName /SC ONCE /ST 00:00 /RU SYSTEM /RL HIGHEST /TR "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File \"$scriptPath\"" /F | Out-Null
        schtasks /Run /TN $TaskName | Out-Null

        $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
        do {
            Start-Sleep -Seconds 3
            $done = Test-Path $resultPath
        } while (-not $done -and (Get-Date) -lt $deadline)

        if (-not (Test-Path $resultPath)) {
            throw "Timed out waiting for SYSTEM task '$TaskName' completion."
        }

        $result = (Get-Content -Path $resultPath -Raw -ErrorAction SilentlyContinue).Trim()
        if ($result -ne 'OK') {
            throw "SYSTEM task '$TaskName' reported failure: $result"
        }
    }
    finally {
        schtasks /Delete /TN $TaskName /F *> $null
        Remove-Item -Path $scriptPath -Force -ErrorAction SilentlyContinue
        Remove-Item -Path $resultPath -Force -ErrorAction SilentlyContinue
    }
}

function Wait-ForAnyExistingPath {
    param(
        [string[]]$Paths,
        [int]$TimeoutSeconds = 45,
        [int]$DelaySeconds = 3
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        foreach ($candidate in $Paths) {
            if ($candidate -and (Test-Path $candidate)) {
                return $candidate
            }
        }
        Start-Sleep -Seconds $DelaySeconds
    } while ((Get-Date) -lt $deadline)

    return $null
}

function Install-OpenSSHClient {
    param([Parameter(Mandatory)][bool]$IsAdministrator)

    if (-not $IsAdministrator) {
        Write-Warn "Skipping OpenSSH Client provisioning (requires elevation)."
        return $false
    }

    $clientCapability = 'OpenSSH.Client~~~~0.0.1.0'
    $sshKeygenPaths = @(
        'C:\Windows\System32\OpenSSH\ssh-keygen.exe',
        (Join-Path ${env:ProgramFiles} 'OpenSSH\ssh-keygen.exe')
    ) | Where-Object { $_ }

    $existingPath = Wait-ForAnyExistingPath -Paths $sshKeygenPaths -TimeoutSeconds 5 -DelaySeconds 1
    if ($existingPath) {
        Write-Info "OpenSSH Client already available at $existingPath"
        return $true
    }

    Write-Info 'Installing OpenSSH Client capability...'

    try {
        Add-WindowsCapability -Online -Name $clientCapability -ErrorAction Stop | Out-Null
    }
    catch {
        Write-Warn "OpenSSH Client install in current token failed: $($_.Exception.Message). Retrying via SYSTEM one-shot task."
        $script = @"
`$ErrorActionPreference = 'Stop'
Add-WindowsCapability -Online -Name '$clientCapability' | Out-Null
'OK' | Out-File -FilePath '$((Join-Path $env:ProgramData 'SecurityAuditToolkit\runtime\tmp\AuditToolkitOpenSSHClient.result.txt'))' -Encoding ASCII -Force
"@
        Invoke-SystemOneShotScript -TaskName 'AuditToolkitOpenSSHClient' -ScriptBody $script
    }

    $resolvedSshKeygenPath = Wait-ForAnyExistingPath -Paths $sshKeygenPaths -TimeoutSeconds 60 -DelaySeconds 3
    if ($resolvedSshKeygenPath) {
        $openSshDir = Split-Path -Path $resolvedSshKeygenPath -Parent
        if ($openSshDir -and -not (($env:PATH -split ';') -contains $openSshDir)) {
            $env:PATH = "$openSshDir;$env:PATH"
        }
        Write-Ok "OpenSSH Client is available at $resolvedSshKeygenPath"
        return $true
    }

    $capabilityState = (Get-WindowsCapability -Online -Name $clientCapability -ErrorAction SilentlyContinue).State
    if ($capabilityState -eq 'Installed') {
        Write-Warn 'OpenSSH Client capability is installed but ssh-keygen.exe is not yet visible. Continuing; SSH key features may require a short delay or sign-in refresh.'
        return $false
    }

    throw 'OpenSSH Client installation did not reach the Installed state.'
}

function Install-OpenSSHServer {
    param([Parameter(Mandatory)][bool]$IsAdministrator)

    if (-not $IsAdministrator) {
        Write-Warn "Skipping OpenSSH Server provisioning (requires elevation)."
        return $false
    }

    $serverCapability = 'OpenSSH.Server~~~~0.0.1.0'
    $sshdService = Get-Service -Name 'sshd' -ErrorAction SilentlyContinue

    if (-not $sshdService) {
        Write-Info 'Installing OpenSSH Server capability...'
        try {
            Add-WindowsCapability -Online -Name $serverCapability -ErrorAction Stop | Out-Null
        }
        catch {
            Write-Warn "OpenSSH Server install in current token failed: $($_.Exception.Message). Retrying via SYSTEM one-shot task."
            $script = @"
`$ErrorActionPreference = 'Stop'
Add-WindowsCapability -Online -Name '$serverCapability' | Out-Null
'OK' | Out-File -FilePath '$((Join-Path $env:ProgramData 'SecurityAuditToolkit\runtime\tmp\AuditToolkitOpenSSHServer.result.txt'))' -Encoding ASCII -Force
"@
            Invoke-SystemOneShotScript -TaskName 'AuditToolkitOpenSSHServer' -ScriptBody $script
        }
        $sshdService = Get-Service -Name 'sshd' -ErrorAction SilentlyContinue
    }

    if (-not $sshdService) {
        throw 'OpenSSH Server installation completed but sshd service is unavailable.'
    }

    Set-Service -Name 'sshd' -StartupType Automatic -ErrorAction SilentlyContinue
    if ($sshdService.Status -ne 'Running') {
        Start-Service -Name 'sshd' -ErrorAction SilentlyContinue
    }

    $ruleName = 'OpenSSH-Server-In-TCP'
    if (-not (Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -Name $ruleName -DisplayName 'OpenSSH Server (sshd)' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22 | Out-Null
    }
    else {
        Enable-NetFirewallRule -Name $ruleName | Out-Null
    }

    Write-Ok 'OpenSSH Server is installed and enabled (TCP/22).'
    return $true
}

function Get-PythonExecutable {
    $candidates = @(
        "C:\Program Files\Python312\python.exe",
        "C:\Python312\python.exe",
        "C:\Program Files\Python311\python.exe",
        "C:\Python311\python.exe"
    )

    foreach ($candidate in $candidates) {
        if (Test-Path $candidate) {
            return $candidate
        }
    }

    foreach ($cmd in @("python", "python3")) {
        try {
            $resolved = (Get-Command $cmd -ErrorAction Stop).Source
            if ($resolved -notlike "*WindowsApps*") {
                $version = & $resolved --version 2>&1
                if ($LASTEXITCODE -eq 0 -and $version -match "Python 3") {
                    return $resolved
                }
            }
        } catch {
            continue
        }
    }

    try {
        $resolved = & py -3 -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $resolved -and (Test-Path $resolved.Trim())) {
            return $resolved.Trim()
        }
    } catch {
        # no-op
        Write-Verbose 'Suppressed non-fatal error.'
    }

    return $null
}

function Install-Python {
    param([string]$InstallerPath)

    $pythonUrl = "https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe"
    Write-Info "Downloading Python 3.12 installer..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $pythonUrl -OutFile $InstallerPath -UseBasicParsing

    Write-Info "Installing Python silently..."
    Start-Process -FilePath $InstallerPath -ArgumentList "/quiet", "InstallAllUsers=1", "PrependPath=1", "Include_test=0" -Wait
}

function Install-VcRedistPrerequisite {
    $vcKey = 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64'
    $vcInstalled = (Get-ItemProperty $vcKey -ErrorAction SilentlyContinue).Installed -eq 1
    if ($vcInstalled) {
        Write-Info "VC++ 2019/2022 x64 Redistributable already present."
        return
    }

    Write-Info "VC++ 2019/2022 x64 Redistributable not detected; installing prerequisite..."
    $vcRedistUrl = 'https://aka.ms/vs/17/release/vc_redist.x64.exe'
    $vcRedistPath = Join-Path $env:TEMP 'vc_redist.x64.exe'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $vcRedistUrl -OutFile $vcRedistPath -UseBasicParsing

    $lastExitCode = $null
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        $vcProc = Start-Process -FilePath $vcRedistPath -ArgumentList @('/install', '/quiet', '/norestart') -Wait -PassThru -NoNewWindow
        $lastExitCode = $vcProc.ExitCode

        if ($lastExitCode -eq 0 -or $lastExitCode -eq 3010) {
            Write-Info "VC++ Redistributable prerequisite installed (exit $lastExitCode)."
            return
        }

        if ($lastExitCode -eq 1618 -and $attempt -lt 3) {
            Write-Warn "VC++ Redistributable installer reported another installation in progress (1618). Waiting 30 seconds before retry $($attempt + 1)/3."
            Start-Sleep -Seconds 30
            continue
        }

        if ($lastExitCode -eq 1618) {
            Write-Warn 'VC++ Redistributable install is still blocked by another Windows installation session (1618). Continuing so setup can be re-run after the MSI transaction completes.'
            return
        }

        throw "VC++ Redistributable prerequisite install failed with exit code $lastExitCode."
    }
}

function Get-PostgresConnectionInfo {
    param([string]$DatabaseUrl)

    $info = @{
        IsPostgres = $false
        IsLocalHost = $false
        Host = 'localhost'
        Port = 5432
        Database = 'audittoolkit'
        User = 'audittoolkit'
        Password = 'Atk!7Xq3vL9mP2_kZ5nR8'
    }

    if (-not $DatabaseUrl -or $DatabaseUrl -notmatch '^postgres(?:ql)?://') {
        return $info
    }

    $info.IsPostgres = $true

    try {
        $uri = [System.Uri]$DatabaseUrl

        if ($uri.Host) {
            $info.Host = $uri.Host
        }

        if ($uri.Port -gt 0) {
            $info.Port = $uri.Port
        }

        $dbName = $uri.AbsolutePath.Trim('/')
        if ($dbName) {
            $info.Database = [System.Uri]::UnescapeDataString($dbName)
        }

        if ($uri.UserInfo) {
            $parts = $uri.UserInfo.Split(':', 2)
            if ($parts[0]) {
                $info.User = [System.Uri]::UnescapeDataString($parts[0])
            }
            if ($parts.Count -gt 1 -and $parts[1]) {
                $info.Password = [System.Uri]::UnescapeDataString($parts[1])
            }
        }
    }
    catch {
        Write-Warn "Could not parse PostgreSQL URL. Using default local provisioning values."
    }

    $localHostNames = @(
        'localhost',
        '127.0.0.1',
        '::1',
        $env:COMPUTERNAME,
        "$($env:COMPUTERNAME).local"
    ) | Where-Object { $_ } | ForEach-Object { $_.ToLowerInvariant() }

    $info.IsLocalHost = $localHostNames -contains $info.Host.ToLowerInvariant()
    return $info
}

function Resolve-PostgresPsqlPath {
    $command = Get-Command psql.exe -ErrorAction SilentlyContinue
    if ($command -and $command.Source) {
        return $command.Source
    }

    foreach ($pattern in @(
        'C:\Program Files\PostgreSQL\*\bin\psql.exe',
        'C:\Program Files\PostgresPro\*\bin\psql.exe',
        'C:\ProgramData\SecurityAuditToolkit\PostgreSQL\*\bin\psql.exe',
        'C:\AuditToolkitLabs\PostgreSQL\*\bin\psql.exe'
    )) {
        $candidate = Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue |
            Sort-Object FullName -Descending |
            Select-Object -First 1

        if ($candidate) {
            return $candidate.FullName
        }
    }

    $serviceBackedBinary = Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^postgresql|^pgsql' -or $_.DisplayName -match 'PostgreSQL' } |
        Select-Object -First 1

    if ($serviceBackedBinary -and $serviceBackedBinary.PathName) {
        $pathText = $serviceBackedBinary.PathName.Trim()
        $exePath = $null

        if ($pathText -match '^["'']([^"'']+?(?:pg_ctl|postgres)\.exe)["'']') {
            $exePath = $Matches[1]
        }
        elseif ($pathText -match '^([^\s]+?(?:pg_ctl|postgres)\.exe)') {
            $exePath = $Matches[1]
        }

        if ($exePath) {
            $candidate = Join-Path (Split-Path $exePath -Parent) 'psql.exe'
            if (Test-Path $candidate) {
                return $candidate
            }
        }
    }

    return $null
}

function Resolve-PostgresDataDirectory {
    param([string]$ServiceName)

    if (-not $ServiceName) {
        return $null
    }

    try {
        $service = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'" -ErrorAction Stop
    }
    catch {
        return $null
    }

    if (-not $service -or -not $service.PathName) {
        return $null
    }

    if ($service.PathName -match '-D\s+"([^"]+)"') {
        return $Matches[1]
    }

    if ($service.PathName -match '-D\s+([^\s]+)') {
        return ($Matches[1].Trim('"'))
    }

    return $null
}

function Enable-PostgresTemporaryLoopbackTrust {
    param([Parameter(Mandatory)][string]$DataDirectory)

    $hbaPath = Join-Path $DataDirectory 'pg_hba.conf'
    if (-not (Test-Path $hbaPath)) {
        throw "pg_hba.conf not found at $hbaPath"
    }

    $backupPath = "$hbaPath.atk-backup"
    Copy-Item -Path $hbaPath -Destination $backupPath -Force

    $content = Get-Content -Path $hbaPath -ErrorAction Stop
    $updated = @()
    $changed = $false
    $hasIpv4 = $false
    $hasIpv6 = $false

    foreach ($line in $content) {
        $newLine = $line

        if ($line -notmatch '^\s*#') {
            if ($line -match '^\s*host\s+all\s+all\s+127\.0\.0\.1/32\s+\S+') {
                $newLine = ($line -replace '(^\s*host\s+all\s+all\s+127\.0\.0\.1/32\s+)\S+', '$1trust')
                $hasIpv4 = $true
            }
            elseif ($line -match '^\s*host\s+all\s+all\s+::1/128\s+\S+') {
                $newLine = ($line -replace '(^\s*host\s+all\s+all\s+::1/128\s+)\S+', '$1trust')
                $hasIpv6 = $true
            }
            elseif ($line -match '^\s*host\s+all\s+postgres\s+127\.0\.0\.1/32\s+\S+') {
                $newLine = ($line -replace '(^\s*host\s+all\s+postgres\s+127\.0\.0\.1/32\s+)\S+', '$1trust')
                $hasIpv4 = $true
            }
            elseif ($line -match '^\s*host\s+all\s+postgres\s+::1/128\s+\S+') {
                $newLine = ($line -replace '(^\s*host\s+all\s+postgres\s+::1/128\s+)\S+', '$1trust')
                $hasIpv6 = $true
            }
        }

        if ($newLine -ne $line) {
            $changed = $true
        }

        $updated += $newLine
    }

    if (-not $hasIpv4) {
        $updated += 'host    all             all             127.0.0.1/32            trust'
        $changed = $true
    }

    if (-not $hasIpv6) {
        $updated += 'host    all             all             ::1/128                 trust'
        $changed = $true
    }

    if ($changed) {
        Set-Content -Path $hbaPath -Value $updated -Encoding ASCII
    }

    return @{
        HbaPath = $hbaPath
        BackupPath = $backupPath
        Changed = $changed
    }
}

function Restore-PostgresHbaFromBackup {
    param([hashtable]$State)

    if (-not $State) {
        return
    }

    $hbaPath = $State.HbaPath
    $backupPath = $State.BackupPath

    if ($hbaPath -and $backupPath -and (Test-Path $backupPath)) {
        Copy-Item -Path $backupPath -Destination $hbaPath -Force
        Remove-Item -Path $backupPath -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-PsqlCommand {
    param(
        [Parameter(Mandatory)][string]$PsqlPath,
        [Parameter(Mandatory)][string[]]$Arguments
    )

    $previousErrorPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $rawOutput = & $PsqlPath @Arguments 2>&1
        $exitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $previousErrorPreference
    }

    $outputText = ''
    if ($null -ne $rawOutput) {
        if ($rawOutput -is [System.Array]) {
            $outputText = ($rawOutput | ForEach-Object { $_.ToString() }) -join "`n"
        }
        else {
            $outputText = $rawOutput.ToString()
        }
    }

    return @{
        ExitCode = $exitCode
        Output = $outputText.Trim()
    }
}

function Get-PreferredPostgreSqlReleaseProfile {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction SilentlyContinue
    $caption = if ($os -and $os.Caption) { $os.Caption } else { 'Unknown Windows' }
    $buildNumber = 0

    if ($os -and $os.BuildNumber -match '^\d+$') {
        $buildNumber = [int]$os.BuildNumber
    }

    if ($buildNumber -ge 20348) {
        $selected = @{
            Version = '18.3-2'
            Major = '18'
            WingetId = 'PostgreSQL.PostgreSQL.18'
            ExeUrl = 'https://get.enterprisedb.com/postgresql/postgresql-18.3-2-windows-x64.exe'
            ExeFileName = 'postgresql-18.3-2-windows-x64.exe'
            ZipUrl = 'https://get.enterprisedb.com/postgresql/postgresql-18.3-2-windows-x64-binaries.zip'
            ZipFileName = 'postgresql-18.3-2-windows-x64-binaries.zip'
        }
    }
    else {
        $selected = @{
            Version = '17.9-2'
            Major = '17'
            WingetId = 'PostgreSQL.PostgreSQL.17'
            ExeUrl = 'https://get.enterprisedb.com/postgresql/postgresql-17.9-2-windows-x64.exe'
            ExeFileName = 'postgresql-17.9-2-windows-x64.exe'
            ZipUrl = 'https://get.enterprisedb.com/postgresql/postgresql-17.9-2-windows-x64-binaries.zip'
            ZipFileName = 'postgresql-17.9-2-windows-x64-binaries.zip'
        }
    }

    return @{
        Caption = $caption
        BuildNumber = $buildNumber
        Selected = $selected
    }
}

function Initialize-PostgreSqlProvisioning {
    param(
        [Parameter(Mandatory)][hashtable]$ConnectionInfo,
        [Parameter(Mandatory)][bool]$IsAdministrator
    )

    if (-not $ConnectionInfo.IsPostgres) {
        Write-Info "Database mode is not PostgreSQL. Skipping PostgreSQL provisioning."
        return
    }

    if (-not $ConnectionInfo.IsLocalHost) {
        Write-Info "DATABASE_URL points to remote PostgreSQL host '$($ConnectionInfo.Host)'. Skipping local PostgreSQL provisioning."
        return
    }

    if ($env:AUDIT_TOOLKIT_SKIP_PG_PROVISION -eq '1') {
        Write-Warn "Skipping local PostgreSQL provisioning due to AUDIT_TOOLKIT_SKIP_PG_PROVISION=1"
        return
    }

    if (-not $IsAdministrator) {
        throw "Local PostgreSQL provisioning requires Administrator rights. Re-run setup elevated."
    }

    if ($ConnectionInfo.User -notmatch '^[A-Za-z_][A-Za-z0-9_]*$') {
        throw "Unsupported PostgreSQL username '$($ConnectionInfo.User)' for automatic provisioning."
    }

    if ($ConnectionInfo.Database -notmatch '^[A-Za-z_][A-Za-z0-9_]*$') {
        throw "Unsupported PostgreSQL database name '$($ConnectionInfo.Database)' for automatic provisioning."
    }

    $pgService = Get-Service | Where-Object { $_.Name -match '^postgresql|^pgsql' -or $_.DisplayName -match 'PostgreSQL' } | Select-Object -First 1
    if ($pgService) {
        $existingDataDir = Resolve-PostgresDataDirectory -ServiceName $pgService.Name
        $clusterLooksValid = $false
        if ($existingDataDir -and (Test-Path (Join-Path $existingDataDir 'PG_VERSION'))) {
            $clusterLooksValid = $true
        }

        if (-not $clusterLooksValid) {
            Write-Warn "Detected PostgreSQL service '$($pgService.Name)' with missing/invalid cluster directory. Re-provisioning PostgreSQL."
            try {
                if ($pgService.Status -ne 'Stopped') {
                    Stop-Service -Name $pgService.Name -Force -ErrorAction SilentlyContinue
                    Start-Sleep -Seconds 2
                }
            }
            catch {
                Write-Verbose 'Suppressed non-fatal error.'
            }

            & sc.exe delete $pgService.Name | Out-Null
            Start-Sleep -Seconds 2
            $pgService = $null
        }
    }

    if (-not $pgService) {
        Write-Info "Installing PostgreSQL prerequisite..."

        # Install runtime prerequisites before any PostgreSQL installer path.
        Install-VcRedistPrerequisite

        $pgReleaseProfile = Get-PreferredPostgreSqlReleaseProfile
        $selectedPgSpec = $pgReleaseProfile.Selected
        Write-Info "Selected PostgreSQL $($selectedPgSpec.Version) for Windows build $($pgReleaseProfile.BuildNumber) ($($pgReleaseProfile.Caption))."

        $superPassword = if ($ConnectionInfo.Password) { $ConnectionInfo.Password } else { 'Atk!7Xq3vL9mP2_kZ5nR8' }
        $pgInstalled = $false
        $useLegacyInstallers = ($env:AUDIT_TOOLKIT_PG_ENABLE_LEGACY_INSTALLERS -eq '1')

        if ($useLegacyInstallers) {
            Write-Warn "AUDIT_TOOLKIT_PG_ENABLE_LEGACY_INSTALLERS=1: enabling winget/EDB attempts before ZIP bootstrap."
        } else {
            Write-Info "Using PostgreSQL ZIP binaries bootstrap as default install path. Set AUDIT_TOOLKIT_PG_ENABLE_LEGACY_INSTALLERS=1 to enable legacy winget/EDB attempts."
        }

        # Method 1 (legacy, opt-in): winget
        if ($useLegacyInstallers) {
            $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
            if ($winget) {
                Write-Info "Attempting PostgreSQL install via winget (legacy path)..."
                $overrideArgs = "--mode unattended --unattendedmodeui none --superpassword `"$superPassword`" --servicepassword `"$superPassword`" --servicename `"postgresql-x64-$($selectedPgSpec.Major)`" --serverport $($ConnectionInfo.Port) --prefix `"C:\Program Files\PostgreSQL\$($selectedPgSpec.Major)`" --datadir `"C:\ProgramData\SecurityAuditToolkit\PostgreSQL\$($selectedPgSpec.Major)\data`" --install_runtimes 0"
                $installArgs = @(
                    'install',
                    '--id', $selectedPgSpec.WingetId,
                    '-e',
                    '--silent',
                    '--accept-package-agreements',
                    '--accept-source-agreements',
                    '--disable-interactivity',
                    '--override', $overrideArgs
                )

                $installProcess = Start-Process -FilePath $winget.Source -ArgumentList $installArgs -Wait -PassThru
                if ($installProcess.ExitCode -eq 0) {
                    $pgInstalled = $true
                    Write-Ok "PostgreSQL installed via winget."
                } else {
                    Write-Warn "winget install failed (exit $($installProcess.ExitCode)). Falling back to direct EDB installer."
                }
            } else {
                Write-Warn "winget not found. Falling back to direct EDB installer (legacy path)."
            }
        } else {
            Write-Info "Skipping winget path by default."
        }

        # Method 2: Direct EnterpriseDB installer - used on hosts where winget is absent
        # (e.g. Windows Server 2019/2022). Note: EDB's InstallBuilder framework silently
        # exits 1 when launched directly as NT AUTHORITY\SYSTEM (the WiX deferred-CA
        # context). The helper below detects that case and relaunches via a one-shot
        # scheduled task under a temporary local admin, giving the installer a real
        # interactive-style user token.
        if (-not $pgInstalled) {
            # SYSTEM-context workaround for EDB installer.
            function Invoke-EdbInstallerAsNonSystem {
                param([string]$InstallerPath, [string[]]$InstallerArgs)

                if (-not [Security.Principal.WindowsIdentity]::GetCurrent().IsSystem) {
                    $proc = Start-Process -FilePath $InstallerPath -ArgumentList $InstallerArgs `
                                -Wait -PassThru -WorkingDirectory 'C:\'
                    return $proc.ExitCode
                }

                Write-Info "Running as NT AUTHORITY\SYSTEM - relaunching EDB installer via scheduled-task workaround (real user token required)."

                # Build a single command-line string; double-quote tokens that contain whitespace.
                $argLine = ($InstallerArgs | ForEach-Object {
                    if ($_ -match '\s' -and $_ -notmatch '^"') { "`"$_`"" } else { $_ }
                }) -join ' '

                $helperUser = 'AtkPGHelper'
                $helperPwd  = 'P@ss' + [System.Guid]::NewGuid().ToString('N').Substring(0, 10)
                $taskName   = 'AtkPostgresInstall'
                $exitFile   = 'C:\Windows\Temp\atk_pg_exit.txt'
                $wrapScript = 'C:\Windows\Temp\atk_pg_install.ps1'

                $escapedPath = $InstallerPath -replace "'", "''"
                $escapedArgs = $argLine        -replace "'", "''"

                $psContent = @"
`$p = Start-Process -FilePath '$escapedPath' -ArgumentList '$escapedArgs' -Wait -PassThru -WorkingDirectory 'C:\'
`$p.ExitCode | Set-Content -LiteralPath '$exitFile' -Encoding ASCII
"@
                Remove-Item $exitFile   -Force -ErrorAction SilentlyContinue
                Remove-Item $wrapScript -Force -ErrorAction SilentlyContinue
                [IO.File]::WriteAllText($wrapScript, $psContent, [Text.Encoding]::UTF8)

                $null = & cmd /c "net user `"$helperUser`" `"$helperPwd`" /add /y" 2>&1
                $null = & cmd /c "net localgroup Administrators `"$helperUser`" /add" 2>&1
                try {
                    $startTime = (Get-Date).AddMinutes(1).ToString('HH:mm')
                    $taskRunCmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -NonInteractive -File `"$wrapScript`""
                    $createOutput = & schtasks.exe /Create /TN $taskName /SC ONCE /ST $startTime /TR $taskRunCmd /RU ".\$helperUser" /RP $helperPwd /RL HIGHEST /F 2>&1
                    if ($LASTEXITCODE -ne 0) {
                        Write-Warn ("schtasks /Create failed: " + (($createOutput | Out-String).Trim()))
                        return 1
                    }

                    $runOutput = & schtasks.exe /Run /TN $taskName 2>&1
                    if ($LASTEXITCODE -ne 0) {
                        Write-Warn ("schtasks /Run failed: " + (($runOutput | Out-String).Trim()))
                        return 1
                    }

                    $deadline = (Get-Date).AddMinutes(20)
                    do {
                        Start-Sleep -Seconds 10
                        $queryOutput = & schtasks.exe /Query /TN $taskName /FO LIST /V 2>&1
                        $queryText = ($queryOutput | Out-String)
                        $taskRunning = $queryText -match 'Status:\s+Running'
                    } while ($taskRunning -and (Get-Date) -lt $deadline)

                    if (-not (Test-Path $exitFile)) {
                        if ($queryText) {
                            Write-Warn ("EDB scheduled-task wrapper did not produce an exit-code file. Task query:`n" + $queryText.Trim())
                        }
                        else {
                            Write-Warn "EDB scheduled-task wrapper did not produce an exit-code file - treating as failure."
                        }
                        return 1
                    }
                    $rawExit = (Get-Content $exitFile -Raw -ErrorAction SilentlyContinue).Trim()
                    if ($rawExit -match '^-?\d+$') { return [int]$rawExit }
                    Write-Warn "EDB scheduled-task exit-code file content: '$rawExit' - treating as failure."
                    return 1
                } finally {
                    & schtasks.exe /Delete /TN $taskName /F 2>&1 | Out-Null
                    $null = & cmd /c "net user `"$helperUser`" /delete" 2>&1
                    Remove-Item $wrapScript -Force -ErrorAction SilentlyContinue
                    Remove-Item $exitFile   -Force -ErrorAction SilentlyContinue
                }
            }

            $installerSpecs = @()
            if ($useLegacyInstallers) {
                $installerSpecs = @(
                    @{
                        Version = $selectedPgSpec.Version
                        Major = $selectedPgSpec.Major
                        Url = $selectedPgSpec.ExeUrl
                        FileName = $selectedPgSpec.ExeFileName
                    }
                )
            } else {
                Write-Info "Skipping EDB installer path by default."
            }

            $installAttemptMessages = @()

            foreach ($spec in $installerSpecs) {
                if ($pgInstalled) {
                    break
                }

                $prefixPath = "C:\Program Files\PostgreSQL\$($spec.Major)"
                $dataPath = "C:\ProgramData\SecurityAuditToolkit\PostgreSQL\$($spec.Major)\data"
                $serviceName = "postgresql-x64-$($spec.Major)"

                New-Item -ItemType Directory -Path (Split-Path $dataPath -Parent) -Force | Out-Null

                $pgInstallerCandidates = @(
                    (Join-Path 'C:\Windows\Temp' $spec.FileName),
                    (Join-Path $env:TEMP $spec.FileName)
                )

                $pgInstallerPath = $pgInstallerCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
                if (-not $pgInstallerPath) {
                    Write-Info "Downloading PostgreSQL $($spec.Version) installer from EnterpriseDB..."
                    $pgInstallerPath = Join-Path $env:TEMP $spec.FileName
                    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                    Invoke-WebRequest -Uri $spec.Url -OutFile $pgInstallerPath -UseBasicParsing
                }
                else {
                    Write-Info "Using cached PostgreSQL installer: $pgInstallerPath"
                }

                $errorTracePath = Join-Path $env:TEMP "postgresql-edb-errortrace-$($spec.Major).xml"
                $debugTracePath = Join-Path $env:TEMP "postgresql-edb-debugtrace-$($spec.Major).log"
                Remove-Item -Path $errorTracePath -Force -ErrorAction SilentlyContinue
                Remove-Item -Path $debugTracePath -Force -ErrorAction SilentlyContinue

                $installArgSets = @(
                    @(
                        '--mode',             'unattended',
                        '--unattendedmodeui', 'none',
                        '--enable-components','server,commandlinetools',
                        '--disable-components','pgAdmin,stackbuilder',
                        '--create_shortcuts', '0',
                        '--install_runtimes', '0',
                        '--superpassword',    $superPassword,
                        '--servicepassword',  $superPassword,
                        '--servicename',      $serviceName,
                        '--serverport',       "$($ConnectionInfo.Port)",
                        '--prefix',           $prefixPath,
                        '--datadir',          $dataPath,
                        '--errortrace',       $errorTracePath,
                        '--debugtrace',       $debugTracePath,
                        '--debuglevel',       '4'
                    ),
                    @(
                        '--mode',             'unattended',
                        '--unattendedmodeui', 'none',
                        '--install_runtimes', '0',
                        '--superpassword',    $superPassword,
                        '--servicepassword',  $superPassword,
                        '--servicename',      $serviceName,
                        '--serverport',       "$($ConnectionInfo.Port)",
                        '--prefix',           $prefixPath,
                        '--datadir',          $dataPath,
                        '--errortrace',       $errorTracePath,
                        '--debugtrace',       $debugTracePath,
                        '--debuglevel',       '4'
                    ),
                    @(
                        '--mode',             'unattended',
                        '--unattendedmodeui', 'none',
                        '--superpassword',    $superPassword,
                        '--serviceaccount',   '"NT AUTHORITY\NetworkService"',
                        '--install_runtimes', '0',
                        '--enable_acledit',   '1',
                        '--servicename',      $serviceName,
                        '--serverport',       "$($ConnectionInfo.Port)",
                        '--prefix',           $prefixPath,
                        '--datadir',          $dataPath,
                        '--errortrace',       $errorTracePath,
                        '--debugtrace',       $debugTracePath,
                        '--debuglevel',       '4'
                    )
                )

                $attemptIndex = 0
                foreach ($argSet in $installArgSets) {
                    $attemptIndex++
                    Write-Info "Running PostgreSQL EDB installer (version $($spec.Version), attempt $attemptIndex)..."
                    $edbExitCode = Invoke-EdbInstallerAsNonSystem -InstallerPath $pgInstallerPath -InstallerArgs $argSet

                    # ExitCode 3010 = success + reboot recommended - acceptable for service-based install
                    if ($edbExitCode -eq 0 -or $edbExitCode -eq 3010) {
                        $pgInstalled = $true
                        Write-Ok "PostgreSQL installed via EDB installer (version $($spec.Version), attempt $attemptIndex)."
                        break
                    }

                    $attemptMessage = "PostgreSQL EDB installer version $($spec.Version) attempt $attemptIndex failed with exit code $edbExitCode."
                    $installAttemptMessages += $attemptMessage
                    Write-Warn $attemptMessage

                    # Some EDB builds on older Windows hosts return non-zero even when
                    # server bits are laid down and service registration succeeds.
                    $serviceProbe = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
                    $psqlProbe = Test-Path (Join-Path $prefixPath 'bin\psql.exe')
                    if ($serviceProbe) {
                        $pgInstalled = $true
                        Write-Warn "PostgreSQL installer returned $edbExitCode but post-install probe succeeded (service: $([bool]$serviceProbe), psql: $psqlProbe). Continuing."
                        break
                    }

                    if ($psqlProbe) {
                        Write-Warn "PostgreSQL installer returned $edbExitCode and only psql.exe was detected (service missing). Treating as partial install and continuing fallback attempts."
                        continue
                    }

                    if (Test-Path $errorTracePath) {
                        $traceTail = (Get-Content -Path $errorTracePath -Tail 40 -ErrorAction SilentlyContinue) -join "`n"
                        if ($traceTail) {
                            Write-Warn "PostgreSQL installer error trace:`n$traceTail"
                        }
                    }

                    if (Test-Path $debugTracePath) {
                        $debugTail = (Get-Content -Path $debugTracePath -Tail 60 -ErrorAction SilentlyContinue) -join "`n"
                        if ($debugTail) {
                            Write-Warn "PostgreSQL installer debug trace:`n$debugTail"
                        }
                    }

                    $latestIbLog = Get-ChildItem -Path $env:TEMP -Filter 'installbuilder_installer*.log' -ErrorAction SilentlyContinue |
                        Sort-Object LastWriteTime -Descending |
                        Select-Object -First 1
                    if ($latestIbLog) {
                        $ibTail = (Get-Content -Path $latestIbLog.FullName -Tail 30 -ErrorAction SilentlyContinue) -join "`n"
                        if ($ibTail) {
                            Write-Warn "InstallBuilder log ($($latestIbLog.Name)):`n$ibTail"
                        }
                    }
                }
            }

            if (-not $pgInstalled) {
                Write-Info "Attempting PostgreSQL binaries ZIP bootstrap."

                $binarySpecs = @(
                    @{
                        Version = $selectedPgSpec.Version
                        Major = $selectedPgSpec.Major
                        Url = $selectedPgSpec.ZipUrl
                        FileName = $selectedPgSpec.ZipFileName
                    }
                )

                foreach ($spec in $binarySpecs) {
                    if ($pgInstalled) {
                        break
                    }

                    $prefixPath = "C:\Program Files\PostgreSQL\$($spec.Major)"
                    $dataPath = "C:\ProgramData\SecurityAuditToolkit\PostgreSQL\$($spec.Major)\data"
                    $serviceName = "postgresql-x64-$($spec.Major)"
                    $zipPath = Join-Path $env:TEMP $spec.FileName
                    $extractRoot = Join-Path $env:TEMP "atk-pg-binaries-$($spec.Major)"
                    $pwFile = Join-Path $env:TEMP "atk-pg-initdb-pw-$($spec.Major).txt"
                    $bundledZipPath = Join-Path $installRoot (Join-Path 'PostgreSQL-Binaries' $spec.FileName)

                    try {
                        # Validate any cached ZIP before trusting it - a prior interrupted download
                        # leaves a corrupt file that Expand-Archive will fail on with
                        # "End of Central Directory record could not be found".
                        $needsDownload = $true
                        if ((Test-Path $bundledZipPath) -and ((Get-Item $bundledZipPath).Length -gt 50MB)) {
                            Write-Info "Using bundled PostgreSQL binaries ZIP from install directory: $bundledZipPath"
                            $zipPath = $bundledZipPath
                            $needsDownload = $false
                        } elseif (Test-Path $zipPath) {
                            $cachedZipItem = Get-Item $zipPath
                            $zipOk = $false
                            if ($cachedZipItem.Length -gt 50MB) {
                                try {
                                    Add-Type -AssemblyName System.IO.Compression.FileSystem
                                    $zf = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
                                    $zipOk = ($zf.Entries.Count -gt 0)
                                    $zf.Dispose()
                                } catch {
                                    $zipOk = $false
                                }
                            }
                            if ($zipOk) {
                                Write-Info "Using cached PostgreSQL binaries ZIP: $zipPath"
                                $needsDownload = $false
                            } else {
                                Write-Warn "Cached PostgreSQL binaries ZIP is corrupt or truncated ($([math]::Round($cachedZipItem.Length/1MB,1)) MB); deleting and re-downloading."
                                Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
                            }
                        }

                        if ($needsDownload) {
                            Write-Info "Downloading PostgreSQL binaries ZIP ($($spec.Version))..."
                            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                            Invoke-WebRequest -Uri $spec.Url -OutFile $zipPath -UseBasicParsing
                        }

                        Remove-Item $extractRoot -Recurse -Force -ErrorAction SilentlyContinue
                        New-Item -ItemType Directory -Path $extractRoot -Force | Out-Null
                        Write-Info "Expanding PostgreSQL binaries ZIP into $extractRoot"
                        Expand-Archive -Path $zipPath -DestinationPath $extractRoot -Force
                        Write-Info "PostgreSQL binaries ZIP expansion complete."

                        Write-Info "Locating PostgreSQL executables in extracted ZIP payload..."
                        $initdbExe = Get-ChildItem -Path $extractRoot -Recurse -Filter 'initdb.exe' -ErrorAction SilentlyContinue |
                            Select-Object -First 1 -ExpandProperty FullName
                        $pgCtlExe = Get-ChildItem -Path $extractRoot -Recurse -Filter 'pg_ctl.exe' -ErrorAction SilentlyContinue |
                            Select-Object -First 1 -ExpandProperty FullName
                        $psqlExe = Get-ChildItem -Path $extractRoot -Recurse -Filter 'psql.exe' -ErrorAction SilentlyContinue |
                            Select-Object -First 1 -ExpandProperty FullName
                        Write-Info "PostgreSQL executable discovery complete."

                        if (-not $initdbExe -or -not $pgCtlExe -or -not $psqlExe) {
                            throw "PostgreSQL binaries ZIP did not contain expected executables (initdb/pg_ctl/psql)."
                        }

                        $extractedRoot = Split-Path (Split-Path $initdbExe -Parent) -Parent

                        Write-Info "Preparing PostgreSQL destination directory at $prefixPath"
                        if (Test-Path $prefixPath) {
                            Remove-Item $prefixPath -Recurse -Force -ErrorAction SilentlyContinue
                        }
                        New-Item -ItemType Directory -Path $prefixPath -Force | Out-Null

                        Write-Info "Copying PostgreSQL binaries into $prefixPath"
                        $null = & robocopy.exe $extractedRoot $prefixPath /MIR /R:1 /W:1 /NFL /NDL /NJH /NJS /NP
                        Write-Info "PostgreSQL binaries copy complete."

                        if (-not (Test-Path (Join-Path $prefixPath 'bin\initdb.exe'))) {
                            throw "PostgreSQL binaries copy failed (initdb.exe missing from destination)."
                        }

                        Write-Info "Preparing PostgreSQL data directory at $dataPath"
                        if (Test-Path $dataPath) {
                            Remove-Item $dataPath -Recurse -Force -ErrorAction SilentlyContinue
                        }
                        New-Item -ItemType Directory -Path $dataPath -Force | Out-Null

                        Set-Content -Path $pwFile -Value $superPassword -Encoding ASCII -NoNewline

                        Install-VcRedistPrerequisite

                        Write-Info "Running initdb for PostgreSQL ZIP fallback."
                        $initdbArgSets = @(
                            @(
                                '-D', $dataPath,
                                '-U', 'postgres',
                                '--pwfile', $pwFile,
                                '-A', 'scram-sha-256',
                                '--encoding', 'UTF8'
                            ),
                            @(
                                '-D', $dataPath,
                                '-U', 'postgres',
                                '--pwfile', $pwFile,
                                '-A', 'scram-sha-256',
                                '--encoding', 'UTF8',
                                '--locale', 'C'
                            )
                        )

                        $initdbSucceeded = $false
                        $initdbAttempt = 0
                        foreach ($initdbArgs in $initdbArgSets) {
                            $initdbAttempt++
                            if (Test-Path $dataPath) {
                                Remove-Item $dataPath -Recurse -Force -ErrorAction SilentlyContinue
                            }
                            New-Item -ItemType Directory -Path $dataPath -Force | Out-Null

                            $initdbExe = Join-Path $prefixPath 'bin\initdb.exe'
                            $initdbOutput = (& $initdbExe @initdbArgs 2>&1 | ForEach-Object { $_.ToString() }) -join "`n"
                            $initdbExitCode = $LASTEXITCODE

                            if ($initdbExitCode -eq 0) {
                                $initdbSucceeded = $true
                                Write-Info "initdb completed successfully (attempt $initdbAttempt)."
                                break
                            }

                            Write-Warn "initdb attempt $initdbAttempt failed with exit code $initdbExitCode."
                            if ($initdbOutput) {
                                $initdbTail = ($initdbOutput -split "`n" | Select-Object -Last 30) -join "`n"
                                Write-Warn "initdb stderr:`n$initdbTail"
                            }
                        }

                        if (-not $initdbSucceeded) {
                            throw "initdb failed across fallback attempts."
                        }

                        & icacls $dataPath /grant 'NT AUTHORITY\NetworkService:(OI)(CI)F' /T /C | Out-Null

                        Get-Service -Name $serviceName -ErrorAction SilentlyContinue | ForEach-Object {
                            if ($_.Status -ne 'Stopped') {
                                Stop-Service -Name $_.Name -Force -ErrorAction SilentlyContinue
                            }
                            & sc.exe delete $_.Name | Out-Null
                            Start-Sleep -Seconds 1
                        }

                        Write-Info "Registering PostgreSQL service $serviceName"
                        $pgCtlExe = Join-Path $prefixPath 'bin\pg_ctl.exe'
                        $registerSucceeded = $false

                        $registerArgSets = @(
                            @('register', '-N', $serviceName, '-D', $dataPath, '-w'),
                            @('register', '-N', $serviceName, '-U', 'NT AUTHORITY\NetworkService', '-D', $dataPath, '-w')
                        )

                        foreach ($registerArgs in $registerArgSets) {
                            $registerOutput = (& $pgCtlExe @registerArgs 2>&1 | ForEach-Object { $_.ToString() }) -join "`n"
                            $registerExitCode = $LASTEXITCODE

                            if ($registerExitCode -eq 0) {
                                $registerSucceeded = $true
                                Write-Info "PostgreSQL service registration completed."
                                break
                            }

                            Write-Warn "pg_ctl register failed with exit code $registerExitCode."
                            if ($registerOutput) {
                                $registerTail = ($registerOutput -split "`n" | Select-Object -Last 30) -join "`n"
                                Write-Warn "pg_ctl register output:`n$registerTail"
                            }
                        }

                        if (-not $registerSucceeded) {
                            throw "pg_ctl register failed across all account strategies."
                        }

                        Write-Info "Starting PostgreSQL service $serviceName"
                        Start-Service -Name $serviceName -ErrorAction SilentlyContinue
                        Start-Sleep -Seconds 4

                        $serviceProbe = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
                        $psqlProbe = Test-Path (Join-Path $prefixPath 'bin\psql.exe')

                        if ($serviceProbe -and $psqlProbe) {
                            Set-Service -Name $serviceName -StartupType Automatic -ErrorAction SilentlyContinue
                            $pgInstalled = $true
                            Write-Ok "PostgreSQL provisioned via binaries ZIP fallback (version $($spec.Version))."
                            break
                        }

                        throw "PostgreSQL binaries fallback did not produce expected service/runtime footprint."
                    }
                    catch {
                        $binaryMessage = "PostgreSQL binaries fallback version $($spec.Version) failed: $($_.Exception.Message)"
                        $installAttemptMessages += $binaryMessage
                        Write-Warn $binaryMessage
                    }
                    finally {
                        Remove-Item $pwFile -Force -ErrorAction SilentlyContinue
                        Remove-Item $extractRoot -Recurse -Force -ErrorAction SilentlyContinue
                    }
                }
            }

            if (-not $pgInstalled) {
                if ($installAttemptMessages.Count -gt 0) {
                    Write-Warn ($installAttemptMessages -join "`n")
                }
                throw "PostgreSQL provisioning failed after ZIP binaries bootstrap (and optional legacy installer attempts if enabled). Manual installation required from https://www.postgresql.org/download/windows/"
            }
        }

        Start-Sleep -Seconds 5
        $pgService = Get-Service | Where-Object { $_.Name -match '^postgresql|^pgsql' -or $_.DisplayName -match 'PostgreSQL' } | Select-Object -First 1
    }

    if (-not $pgService) {
        # Some EDB runs lay down binaries but skip/lose service registration.
        # Attempt to recover by finding postgres-backed services first.
        $pgService = Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
            Where-Object { $_.PathName -match 'postgres' -or $_.DisplayName -match 'PostgreSQL' } |
            Select-Object -First 1 |
            ForEach-Object { Get-Service -Name $_.Name -ErrorAction SilentlyContinue }
    }

    if (-not $pgService) {
        # Last-resort recovery: register service from discovered psql/pg_ctl footprint.
        $psqlRecoveryPath = Resolve-PostgresPsqlPath
        if ($psqlRecoveryPath) {
            $recoveryPrefix = Split-Path (Split-Path $psqlRecoveryPath -Parent) -Parent
            $recoveryPgCtl = Join-Path $recoveryPrefix 'bin\pg_ctl.exe'
            $recoveryVersion = Split-Path $recoveryPrefix -Leaf
            $recoveryServiceName = if ($recoveryVersion -match '^\d+$') { "postgresql-x64-$recoveryVersion" } else { 'postgresql-x64-17' }

            $candidateDataDirs = @(
                (Join-Path $recoveryPrefix 'data')
            ) + (Get-ChildItem -Path 'C:\ProgramData\SecurityAuditToolkit\PostgreSQL' -Directory -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending |
                ForEach-Object { Join-Path $_.FullName 'data' }) + (Get-ChildItem -Path 'C:\Program Files\PostgreSQL' -Directory -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending |
                ForEach-Object { Join-Path $_.FullName 'data' })

            $recoveryDataDir = $candidateDataDirs |
                Where-Object { $_ -and (Test-Path (Join-Path $_ 'PG_VERSION')) } |
                Select-Object -First 1

            if ((Test-Path $recoveryPgCtl) -and $recoveryDataDir) {
                Write-Warn "PostgreSQL binaries were detected but no service was found. Attempting service registration recovery."
                try {
                    $registerProcess = Start-Process -FilePath $recoveryPgCtl -ArgumentList @(
                        'register',
                        '-N', $recoveryServiceName,
                        '-U', 'NT AUTHORITY\NetworkService',
                        '-D', $recoveryDataDir,
                        '-w'
                    ) -Wait -PassThru -NoNewWindow

                    if ($registerProcess.ExitCode -eq 0) {
                        Start-Service -Name $recoveryServiceName -ErrorAction SilentlyContinue
                        Start-Sleep -Seconds 3
                        $pgService = Get-Service -Name $recoveryServiceName -ErrorAction SilentlyContinue
                        if ($pgService) {
                            Write-Ok "Recovered PostgreSQL service registration as '$recoveryServiceName'."
                        }
                    }
                    else {
                        Write-Warn "PostgreSQL service registration recovery failed with exit code $($registerProcess.ExitCode)."
                    }
                }
                catch {
                    Write-Warn "PostgreSQL service registration recovery failed: $($_.Exception.Message)"
                }
            }
        }
    }

    if (-not $pgService) {
        throw "PostgreSQL service was not detected after installation."
    }

    if ($pgService.Status -ne 'Running') {
        Write-Warn "PostgreSQL service '$($pgService.Name)' is '$($pgService.Status)'. Attempting to start."
        Start-Service -Name $pgService.Name -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 4

        $pgService = Get-Service -Name $pgService.Name -ErrorAction SilentlyContinue
        if ($pgService -and $pgService.Status -ne 'Running') {
            $pgDataDirectory = Resolve-PostgresDataDirectory -ServiceName $pgService.Name
            $pgCtlPath = $null
            $psqlCandidate = Resolve-PostgresPsqlPath
            if ($psqlCandidate) {
                $pgCtlPath = Join-Path (Split-Path $psqlCandidate -Parent) 'pg_ctl.exe'
            }

            if ($pgCtlPath -and (Test-Path $pgCtlPath) -and $pgDataDirectory) {
                $pgCtlOutput = (& $pgCtlPath 'start' '-N' $pgService.Name '-D' $pgDataDirectory '-w' 2>&1 | ForEach-Object { $_.ToString() }) -join "`n"
                if ($LASTEXITCODE -ne 0 -and $pgCtlOutput) {
                    $pgCtlTail = ($pgCtlOutput -split "`n" | Select-Object -Last 30) -join "`n"
                    Write-Warn "pg_ctl start output:`n$pgCtlTail"
                }
                Start-Sleep -Seconds 3
            }

            $pgService = Get-Service -Name $pgService.Name -ErrorAction SilentlyContinue
        }

        if (-not $pgService -or $pgService.Status -ne 'Running') {
            $statusText = if ($pgService) { $pgService.Status } else { 'NotFound' }
            $serviceNameForError = if ($pgService) { $pgService.Name } else { 'unknown' }
            throw "PostgreSQL service '$serviceNameForError' could not be started (service status: $statusText)."
        }
    }

    Set-Service -Name $pgService.Name -StartupType Automatic -ErrorAction SilentlyContinue

    $psqlPath = Resolve-PostgresPsqlPath
    if (-not $psqlPath) {
        throw "psql.exe was not found after PostgreSQL installation."
    }

    $superPassword = if ($ConnectionInfo.Password) { $ConnectionInfo.Password } else { 'Atk!7Xq3vL9mP2_kZ5nR8' }
    $userName = $ConnectionInfo.User
    $databaseName = $ConnectionInfo.Database
    $dbPassword = if ($ConnectionInfo.Password) { $ConnectionInfo.Password } else { 'Atk!7Xq3vL9mP2_kZ5nR8' }
    $port = $ConnectionInfo.Port

    $userSql = ConvertTo-SqlLiteral $userName
    $dbSql = ConvertTo-SqlLiteral $databaseName
    $passwordSql = ConvertTo-SqlLiteral $dbPassword

    $temporaryTrustState = $null
    $usedTemporaryTrust = $false

    $env:PGPASSWORD = $superPassword
    try {
        $roleExistsResult = Invoke-PsqlCommand -PsqlPath $psqlPath -Arguments @(
            '-h', 'localhost',
            '-p', "$port",
            '-U', 'postgres',
            '-d', 'postgres',
            '-tAc', "SELECT 1 FROM pg_roles WHERE rolname='$userSql';"
        )

        $roleExists = $roleExistsResult.Output
        if ($roleExistsResult.ExitCode -ne 0) {
            Write-Warn "Unable to authenticate to PostgreSQL as postgres with configured password. Attempting temporary local trust bootstrap."

            Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue

            $pgDataDirectory = Resolve-PostgresDataDirectory -ServiceName $pgService.Name
            if (-not $pgDataDirectory) {
                throw "Unable to determine PostgreSQL data directory for service '$($pgService.Name)'."
            }

            $temporaryTrustState = Enable-PostgresTemporaryLoopbackTrust -DataDirectory $pgDataDirectory

            Restart-Service -Name $pgService.Name -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 4

            $roleExistsResult = Invoke-PsqlCommand -PsqlPath $psqlPath -Arguments @(
                '-h', 'localhost',
                '-p', "$port",
                '-U', 'postgres',
                '-d', 'postgres',
                '-tAc', "SELECT 1 FROM pg_roles WHERE rolname='$userSql';"
            )

            $roleExists = $roleExistsResult.Output
            if ($roleExistsResult.ExitCode -ne 0) {
                throw "Unable to connect to local PostgreSQL as postgres, even after temporary trust bootstrap."
            }

            $usedTemporaryTrust = $true
            Write-Info "Connected to PostgreSQL using temporary local trust bootstrap."
        }

        if (-not ($roleExists -match '1')) {
            $createRoleResult = Invoke-PsqlCommand -PsqlPath $psqlPath -Arguments @(
                '-h', 'localhost',
                '-p', "$port",
                '-U', 'postgres',
                '-d', 'postgres',
                '-v', 'ON_ERROR_STOP=1',
                '-c', "CREATE ROLE $userName WITH LOGIN PASSWORD '$passwordSql';"
            )
            if ($createRoleResult.ExitCode -ne 0) {
                throw "Failed to create PostgreSQL role '$userName'."
            }
        }

        $alterRoleResult = Invoke-PsqlCommand -PsqlPath $psqlPath -Arguments @(
            '-h', 'localhost',
            '-p', "$port",
            '-U', 'postgres',
            '-d', 'postgres',
            '-v', 'ON_ERROR_STOP=1',
            '-c', "ALTER ROLE $userName WITH LOGIN PASSWORD '$passwordSql';"
        )
        if ($alterRoleResult.ExitCode -ne 0) {
            throw "Failed to set password for PostgreSQL role '$userName'."
        }

        $dbExistsResult = Invoke-PsqlCommand -PsqlPath $psqlPath -Arguments @(
            '-h', 'localhost',
            '-p', "$port",
            '-U', 'postgres',
            '-d', 'postgres',
            '-tAc', "SELECT 1 FROM pg_database WHERE datname='$dbSql';"
        )

        $dbExists = $dbExistsResult.Output
        if ($dbExistsResult.ExitCode -ne 0) {
            throw "Failed to verify PostgreSQL database '$databaseName'."
        }

        if (-not ($dbExists -match '1')) {
            $createDbResult = Invoke-PsqlCommand -PsqlPath $psqlPath -Arguments @(
                '-h', 'localhost',
                '-p', "$port",
                '-U', 'postgres',
                '-d', 'postgres',
                '-v', 'ON_ERROR_STOP=1',
                '-c', "CREATE DATABASE $databaseName OWNER $userName;"
            )
            if ($createDbResult.ExitCode -ne 0) {
                throw "Failed to create PostgreSQL database '$databaseName'."
            }
        }

        $grantResult = Invoke-PsqlCommand -PsqlPath $psqlPath -Arguments @(
            '-h', 'localhost',
            '-p', "$port",
            '-U', 'postgres',
            '-d', 'postgres',
            '-v', 'ON_ERROR_STOP=1',
            '-c', "GRANT ALL PRIVILEGES ON DATABASE $databaseName TO $userName;"
        )
        if ($grantResult.ExitCode -ne 0) {
            throw "Failed to grant PostgreSQL privileges for '$databaseName'."
        }
    }
    finally {
        Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue

        if ($usedTemporaryTrust -and $temporaryTrustState) {
            Write-Info "Restoring PostgreSQL pg_hba.conf secure settings after bootstrap."
            Restore-PostgresHbaFromBackup -State $temporaryTrustState
            Restart-Service -Name $pgService.Name -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 4
        }
    }

    $env:PGPASSWORD = $dbPassword
    try {
        $passwordCheckResult = Invoke-PsqlCommand -PsqlPath $psqlPath -Arguments @(
            '-h', 'localhost',
            '-p', "$port",
            '-U', $userName,
            '-d', $databaseName,
            '-tAc', 'SELECT 1'
        )
        if ($passwordCheckResult.ExitCode -ne 0) {
            throw "PostgreSQL password-auth test failed for $userName@$($ConnectionInfo.Host):$port/$databaseName."
        }
    }
    finally {
        Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
    }

    Write-Ok "PostgreSQL prerequisite is installed and provisioned (service: $($pgService.Name), database: $databaseName)."
}

function Resolve-NginxBinaryPath {
    $command = Get-Command nginx.exe -ErrorAction SilentlyContinue
    if ($command -and $command.Source) {
        return $command.Source
    }

    foreach ($candidate in @(
        'C:\nginx\nginx.exe',
        'C:\Program Files\nginx\nginx.exe',
        'C:\tools\nginx\nginx.exe'
    )) {
        if (Test-Path $candidate) {
            return (Resolve-Path $candidate).Path
        }
    }

    return $null
}

function Resolve-RedisBinaryPath {
    $command = Get-Command redis-server.exe -ErrorAction SilentlyContinue
    if ($command -and $command.Source) {
        return $command.Source
    }

    foreach ($candidate in @(
        'C:\Program Files\Redis\redis-server.exe',
        'C:\Redis\redis-server.exe',
        'C:\tools\redis\redis-server.exe'
    )) {
        if (Test-Path $candidate) {
            return (Resolve-Path $candidate).Path
        }
    }

    return $null
}

function Install-RedisPrerequisite {
    param([Parameter(Mandatory)][bool]$IsAdministrator)

    $existing = Resolve-RedisBinaryPath
    if ($existing) {
        Write-Info "Redis already installed at: $existing"
        return $existing
    }

    if (-not $IsAdministrator) {
        throw "Redis provisioning requires Administrator rights. Re-run setup elevated."
    }

    Write-Info "Installing Redis prerequisite..."

    # Use Redis for Windows (tporadowski port) v5.0.14.1 via ZIP to avoid nested MSI conflicts.
    $redisZipUrl = 'https://github.com/tporadowski/redis/releases/download/v5.0.14.1/Redis-x64-5.0.14.1.zip'
    $redisZipPath = Join-Path $env:TEMP 'Redis-x64-5.0.14.1.zip'
    $redisExtractPath = Join-Path $env:TEMP 'redis-x64-5.0.14.1-extract'
    $redisInstallPath = 'C:\Program Files\Redis'

    Write-Info "Downloading Redis ZIP package..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $redisZipUrl -OutFile $redisZipPath -UseBasicParsing

    Write-Info "Extracting Redis ZIP package..."
    Remove-Item $redisExtractPath -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Path $redisExtractPath -Force | Out-Null
    Expand-Archive -Path $redisZipPath -DestinationPath $redisExtractPath -Force

    Write-Info "Installing Redis files to $redisInstallPath"
    Remove-Item $redisInstallPath -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Path $redisInstallPath -Force | Out-Null
    Copy-Item -Path (Join-Path $redisExtractPath '*') -Destination $redisInstallPath -Recurse -Force

    $redisServerExe = Join-Path $redisInstallPath 'redis-server.exe'
    $redisServiceConf = Join-Path $redisInstallPath 'redis.windows-service.conf'
    if (-not (Test-Path $redisServerExe) -or -not (Test-Path $redisServiceConf)) {
        throw "Redis ZIP install payload is incomplete (redis-server.exe or redis.windows-service.conf missing)."
    }

    Write-Info "Registering Redis Windows service..."
    & $redisServerExe --service-install $redisServiceConf --service-name Redis --loglevel warning
    if ($LASTEXITCODE -ne 0) {
        # tporadowski Redis Windows builds sometimes return exit code 1 even on success.
        # Validate by checking whether the service was actually registered.
        $svcCheck = Get-Service -Name 'Redis' -ErrorAction SilentlyContinue
        if (-not $svcCheck) {
            throw "Redis service registration failed with exit code $LASTEXITCODE."
        }
        Write-Info "Redis --service-install returned exit code $LASTEXITCODE but service is registered - continuing."
    }

    Start-Sleep -Seconds 2

    $existing = Resolve-RedisBinaryPath
    if (-not $existing) {
        throw "Redis was not found after ZIP installation. Installation may have failed."
    }

    Write-Ok "Redis installed successfully: $existing"
    return $existing
}

function Set-RedisRuntime {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param(
        [Parameter(Mandatory)][string]$RedisExePath,
        [Parameter(Mandatory)][bool]$IsAdministrator
    )

    $null = $RedisExePath

    if (-not $IsAdministrator) {
        throw "Redis runtime configuration requires Administrator rights."
    }

    $redisService = Get-Service | Where-Object { $_.Name -eq 'Redis' } | Select-Object -First 1

    if (-not $redisService) {
        throw "Redis service not found after installation. Manual setup required."
    }

    if (-not $PSCmdlet.ShouldProcess('Redis service', 'Configure startup type and ensure service is running')) {
        return
    }

    # Ensure Redis service starts automatically
    Set-Service -Name 'Redis' -StartupType Automatic -ErrorAction SilentlyContinue
    Write-Info "Redis service configured for automatic startup."

    # Start Redis if not already running
    if ($redisService.Status -ne 'Running') {
        Start-Service -Name 'Redis' -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        Write-Ok "Redis service started."
    } else {
        Write-Info "Redis service already running."
    }

    Write-Ok "Redis runtime configured."
}

function Install-NginxPrerequisite {
    param([Parameter(Mandatory)][bool]$IsAdministrator)

    $existing = Resolve-NginxBinaryPath
    if ($existing) {
        return $existing
    }

    if (-not $IsAdministrator) {
        throw "nginx provisioning requires Administrator rights. Re-run setup elevated."
    }

    Write-Info "Installing nginx prerequisite..."

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        $installArgs = @(
            'install',
            '--id', 'NGINX.NGINX',
            '-e',
            '--silent',
            '--accept-package-agreements',
            '--accept-source-agreements',
            '--disable-interactivity'
        )

        $process = Start-Process -FilePath $winget.Source -ArgumentList $installArgs -Wait -PassThru
        if ($process.ExitCode -eq 0) {
            $existing = Resolve-NginxBinaryPath
            if ($existing) {
                return $existing
            }
        }
    }

    $zipPath = Join-Path $env:TEMP 'nginx-win.zip'
    $downloadUrl = 'https://nginx.org/download/nginx-1.26.3.zip'
    Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath -UseBasicParsing

    Remove-Item -Path 'C:\nginx' -Recurse -Force -ErrorAction SilentlyContinue
    Expand-Archive -Path $zipPath -DestinationPath 'C:\' -Force

    $expanded = Get-ChildItem -Path 'C:\' -Directory -Filter 'nginx-*' -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending |
        Select-Object -First 1

    if (-not $expanded) {
        throw "Unable to locate extracted nginx directory."
    }

    Rename-Item -Path $expanded.FullName -NewName 'nginx' -Force
    $existing = Resolve-NginxBinaryPath
    if (-not $existing) {
        throw "Unable to install nginx prerequisite."
    }

    return $existing
}

function New-NginxCertificate {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param(
        [Parameter(Mandatory)][string]$PythonExe,
        [Parameter(Mandatory)][string]$CertificatePath,
        [Parameter(Mandatory)][string]$KeyPath
    )

    if (-not $PSCmdlet.ShouldProcess($CertificatePath, 'Generate nginx TLS certificate and key')) {
        return
    }

    & $PythonExe -m pip install cryptography --quiet | Out-Null

    $scriptPath = Join-Path $PSScriptRoot 'scripts\generate_nginx_cert.py'
    if (-not (Test-Path $scriptPath)) {
        throw "Certificate generator script not found: $scriptPath"
    }

    & $PythonExe $scriptPath $CertificatePath $KeyPath $env:COMPUTERNAME
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to generate nginx TLS certificate."
    }
}

function Set-NginxRuntime {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param(
        [Parameter(Mandatory)][string]$NginxExe,
        [Parameter(Mandatory)][string]$PythonExe,
        [Parameter(Mandatory)][bool]$IsAdministrator
    )

    if (-not $IsAdministrator) {
        throw "nginx runtime configuration requires Administrator rights."
    }

    if (-not $PSCmdlet.ShouldProcess($NginxExe, 'Configure nginx runtime, TLS assets, and service wiring')) {
        return
    }

    $nginxRoot = Split-Path -Parent $NginxExe
    $nginxConfDir = Join-Path $nginxRoot 'conf'
    $sslDir = Join-Path $nginxConfDir 'ssl'
    $logsDir = Join-Path $nginxRoot 'logs'
    $tempDir = Join-Path $nginxRoot 'temp'
    New-Item -ItemType Directory -Path $sslDir, $logsDir, $tempDir -Force | Out-Null

    $certPath = Join-Path $sslDir 'audit-toolkit.crt'
    $keyPath = Join-Path $sslDir 'audit-toolkit.key'
    New-NginxCertificate -PythonExe $PythonExe -CertificatePath $certPath -KeyPath $keyPath

    $certPathNginx = $certPath -replace '\\', '/'
    $keyPathNginx = $keyPath -replace '\\', '/'
    $nginxConfPath = Join-Path $nginxConfDir 'nginx.conf'

    $nginxConfTemplate = @'
worker_processes  1;
events { worker_connections  1024; }

http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;

    server {
        listen       127.0.0.1:8080;
        server_name  _;
        return 301 https://$host$request_uri;
    }

    server {
        listen       443 ssl;
        server_name  _;

        ssl_certificate      __CERT_PATH__;
        ssl_certificate_key  __KEY_PATH__;
        ssl_protocols        TLSv1.2 TLSv1.3;

        location / {
            proxy_pass         http://127.0.0.1:5000;
            proxy_http_version 1.1;
            proxy_set_header   Host $host;
            proxy_set_header   X-Real-IP $remote_addr;
            proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header   X-Forwarded-Proto $scheme;
            proxy_set_header   X-Forwarded-Host $host;
            proxy_set_header   X-Forwarded-Port $server_port;
        }

        location /api/asset-discovery/ {
            proxy_pass         http://127.0.0.1:18080/;
            proxy_http_version 1.1;
            proxy_set_header   Host $host;
            proxy_set_header   X-Real-IP $remote_addr;
            proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header   X-Forwarded-Proto $scheme;
            proxy_set_header   X-Forwarded-Host $host;
            proxy_set_header   X-Forwarded-Port $server_port;
        }
    }
}
'@
    $nginxConf = $nginxConfTemplate.Replace('__CERT_PATH__', $certPathNginx).Replace('__KEY_PATH__', $keyPathNginx)

    $nginxConf | Out-File -FilePath $nginxConfPath -Encoding ASCII -Force

    Start-Process -FilePath $NginxExe -ArgumentList @('-s', 'stop', '-p', $nginxRoot, '-c', 'conf/nginx.conf') -Wait -NoNewWindow -ErrorAction SilentlyContinue | Out-Null
    Start-Sleep -Seconds 1

    $nginxTestOutput = ''
    $nginxTestExitCode = 0
    $previousNginxErrorPreference = $ErrorActionPreference
    $nativeErrorPreferenceWasSet = $false
    $previousNativeErrorPreference = $null
    try {
        if ($PSVersionTable.PSVersion.Major -ge 7) {
            $previousNativeErrorPreference = $PSNativeCommandUseErrorActionPreference
            $PSNativeCommandUseErrorActionPreference = $false
            $nativeErrorPreferenceWasSet = $true
        }
        $ErrorActionPreference = 'Continue'
        $nginxTestOutput = (& $NginxExe -t -p $nginxRoot -c 'conf/nginx.conf' 2>&1 | ForEach-Object { $_.ToString() }) -join "`n"
        $nginxTestExitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $previousNginxErrorPreference
        if ($nativeErrorPreferenceWasSet) {
            $PSNativeCommandUseErrorActionPreference = $previousNativeErrorPreference
        }
    }

    if ($nginxTestExitCode -ne 0) {
        $nginxTail = ($nginxTestOutput -split "`n" | Select-Object -Last 40) -join "`n"
        Write-Warn "nginx configuration test failed with exit code $nginxTestExitCode. Continuing without managed nginx startup."
        if ($nginxTail) {
            Write-Warn "nginx -t output:`n$nginxTail"
        }
        return
    }

    Unregister-ScheduledTask -TaskName 'AuditToolkitNginx' -Confirm:$false -ErrorAction SilentlyContinue
    $nginxAction = New-ScheduledTaskAction -Execute $NginxExe -Argument "-p `"$nginxRoot`" -c conf/nginx.conf"
    $nginxTrigger = New-ScheduledTaskTrigger -AtStartup
    $nginxSettings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
        -ExecutionTimeLimit ([TimeSpan]::Zero) `
        -RestartCount 10 `
        -RestartInterval (New-TimeSpan -Minutes 1)
    Register-ScheduledTask -TaskName 'AuditToolkitNginx' -Action $nginxAction -Trigger $nginxTrigger -Settings $nginxSettings -RunLevel Highest -User 'SYSTEM' -Force | Out-Null

    Start-Process -FilePath $NginxExe -ArgumentList @('-p', $nginxRoot, '-c', 'conf/nginx.conf') -WindowStyle Hidden | Out-Null
    Start-ScheduledTask -TaskName 'AuditToolkitNginx' -ErrorAction SilentlyContinue

    Write-Ok "nginx reverse proxy configured for HTTPS on port 443."
}

Write-Output ""
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host " Security Audit Toolkit - Web GUI Setup" -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Output ""

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$installRoot = Split-Path -Parent $scriptDir
$requirementsPath = Join-Path $scriptDir "requirements.txt"
$assetDiscoveryDir = Join-Path $installRoot "tools\asset-discovery"
$assetDiscoveryRequirementsPath = Join-Path $assetDiscoveryDir "requirements.txt"
$assetDiscoveryEntryPoint = Join-Path $assetDiscoveryDir "src\app.py"
$assetDiscoveryPort = "18080"
$assetDiscoveryInternalUrl = "http://127.0.0.1:$assetDiscoveryPort"
$assetDiscoveryExternalUrl = "https://127.0.0.1/api/asset-discovery/"
$assetDiscoveryRuntimeAvailable = (Test-Path $assetDiscoveryEntryPoint)

if (-not (Test-Path $requirementsPath)) {
    throw "requirements.txt not found at: $requirementsPath"
}

$isAdmin = Test-IsAdministrator

$dataRoot = Join-Path $env:ProgramData "SecurityAuditToolkit\data"
$runtimeRoot = Join-Path $env:ProgramData "SecurityAuditToolkit\runtime"

if (-not $isAdmin) {
    $dataRoot = Join-Path $env:LOCALAPPDATA "SecurityAuditToolkit\data"
    $runtimeRoot = Join-Path $env:LOCALAPPDATA "SecurityAuditToolkit\runtime"
    Write-Warn "Not running elevated. Using user-local runtime paths under LOCALAPPDATA."
}

New-Item -ItemType Directory -Path $dataRoot -Force | Out-Null
New-Item -ItemType Directory -Path $runtimeRoot -Force | Out-Null

$requiredToolkitDirs = @(
    Join-Path $installRoot "logs"
    Join-Path $installRoot "backups"
    Join-Path $installRoot "schedules"
)
New-Item -ItemType Directory -Path $requiredToolkitDirs -Force | Out-Null

Write-Info "Data root: $dataRoot"

# -----------------------------------------------------------------------
# Resolve DATABASE_URL for server deployment
# Order of precedence:
#   1. -DatabaseUrl parameter
#   2. DATABASE_URL env var already set in session
#   3. Caller-supplied values via POSTGRES_* env vars
#   4. Default PostgreSQL URL (server policy)
#
# PostgreSQL is REQUIRED for Windows server/appliance deployments.
# SQLite is development/container-only and must never be used in production.
# -----------------------------------------------------------------------

# Production enforcement: force PostgreSQL mode for Windows installs.
$env:AUDIT_TOOLKIT_DB_MODE = 'postgres'
$resolvedDatabaseUrl = ''
$dbUrlSource = ''

if ($DatabaseUrl -and $DatabaseUrl.Trim()) {
    $resolvedDatabaseUrl = $DatabaseUrl.Trim()
    if ($resolvedDatabaseUrl -match '^sqlite') {
        throw "SQLite is not supported for Windows MSI/server installs. Use PostgreSQL."
    }
    if ($resolvedDatabaseUrl -notmatch '^postgres(?:ql)?://') {
        throw "Invalid -DatabaseUrl. Expected a PostgreSQL URL (postgresql://...)."
    }
    $dbUrlSource = 'parameter'
} elseif ($env:DATABASE_URL -and $env:DATABASE_URL.Trim()) {
    $resolvedDatabaseUrl = $env:DATABASE_URL.Trim()
    if ($resolvedDatabaseUrl -match '^sqlite') {
        throw "SQLite is not supported for Windows MSI/server installs. Use PostgreSQL."
    }
    $dbUrlSource = 'env_database_url'
} else {
    # Build PostgreSQL default from POSTGRES_* overrides or hard default
    $pgUser     = if ($env:POSTGRES_USER)     { $env:POSTGRES_USER }     else { 'audittoolkit' }
    $pgPassword = if ($env:POSTGRES_PASSWORD) { $env:POSTGRES_PASSWORD } else { 'Atk!7Xq3vL9mP2_kZ5nR8' }
    $pgHost     = if ($env:POSTGRES_HOST)     { $env:POSTGRES_HOST }     else { 'localhost' }
    $pgPort     = if ($env:POSTGRES_PORT)     { $env:POSTGRES_PORT }     else { '5432' }
    $pgDb       = if ($env:POSTGRES_DB)       { $env:POSTGRES_DB }       else { 'audittoolkit' }
    $resolvedDatabaseUrl = "postgresql://${pgUser}:${pgPassword}@${pgHost}:${pgPort}/${pgDb}"
    $dbUrlSource = 'default_postgres'
}

if ($resolvedDatabaseUrl -notmatch '^postgres(?:ql)?://') {
    throw "Resolved DATABASE_URL is not PostgreSQL. Windows MSI/server installs require PostgreSQL."
}

$pgConnection = Get-PostgresConnectionInfo -DatabaseUrl $resolvedDatabaseUrl

if ($resolvedDatabaseUrl -notmatch '^postgres(?:ql)?://[^/]+@') {
    $encodedUser = [System.Uri]::EscapeDataString($pgConnection.User)
    $encodedPassword = [System.Uri]::EscapeDataString($pgConnection.Password)
    $resolvedDatabaseUrl = "postgresql://${encodedUser}:${encodedPassword}@$($pgConnection.Host):$($pgConnection.Port)/$($pgConnection.Database)"
    if ($dbUrlSource -eq 'parameter') {
        $dbUrlSource = 'parameter_normalized_postgres_credentials'
    }
    elseif ($dbUrlSource -eq 'env_database_url') {
        $dbUrlSource = 'env_database_url_normalized_postgres_credentials'
    }
}

Write-Info "Database URL source : $dbUrlSource"
$dbDisplayUrl = $resolvedDatabaseUrl -replace '://[^:@/]+:[^@/]+@', '://<user>:<pass>@'
Write-Info "Database URL        : $dbDisplayUrl"

$dbMode = 'postgres'

Write-Info "Database mode       : PostgreSQL"
Initialize-PostgreSqlProvisioning -ConnectionInfo $pgConnection -IsAdministrator:$isAdmin
Initialize-ToolkitStateRoot
New-WindowsUpgradeSnapshot -ResolvedInstallMode $InstallMode -InstallRoot $scriptDir -ResolvedStateRoot $script:ToolkitStateRoot

$initialAdminCredentialsPath = Join-Path $runtimeRoot "initial-admin-credentials.txt"
$initialLoginGuidePath = Join-Path $runtimeRoot "FIRST-LOGIN.txt"

$flaskEnv = if ($env:FLASK_ENV) { $env:FLASK_ENV.Trim().ToLowerInvariant() } else { "" }
$runtimeEnv = if ($env:ENVIRONMENT) { $env:ENVIRONMENT.Trim().ToLowerInvariant() } else { "" }
$isProduction = $flaskEnv -eq "production" -or $runtimeEnv -eq "production"
$defaultInstallerPassword = if ($env:AUDIT_TOOLKIT_DEFAULT_INITIAL_ADMIN_PASSWORD -and $env:AUDIT_TOOLKIT_DEFAULT_INITIAL_ADMIN_PASSWORD.Trim()) {
    $env:AUDIT_TOOLKIT_DEFAULT_INITIAL_ADMIN_PASSWORD.Trim()
} else {
    "ChangeMe123!"
}
$randomizeInitialAdminPassword = $false
if ($env:AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD) {
    $randomizeInitialAdminPassword = @('1', 'true', 'yes', 'on') -contains $env:AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD.Trim().ToLowerInvariant()
}

$resolvedInitialAdminSecret = $null
$initialSecretSource = "generated_random"

if ($InitialAdminSecret -and $InitialAdminSecret.Trim()) {
    $resolvedInitialAdminSecret = $InitialAdminSecret.Trim()
    $initialSecretSource = "setup_parameter"
}
elseif ($env:INITIAL_ADMIN_PASSWORD -and $env:INITIAL_ADMIN_PASSWORD.Trim()) {
    $resolvedInitialAdminSecret = $env:INITIAL_ADMIN_PASSWORD.Trim()
    $initialSecretSource = "env_initial_admin_password"
}
elseif ($env:ADMIN_PASSWORD -and $env:ADMIN_PASSWORD.Trim()) {
    $resolvedInitialAdminSecret = $env:ADMIN_PASSWORD.Trim()
    $initialSecretSource = "env_admin_password"
}
elseif (-not $randomizeInitialAdminPassword) {
    $resolvedInitialAdminSecret = $defaultInstallerPassword
    $initialSecretSource = if ($isProduction) { "installer_default" } else { "dev_default" }
}

if (-not $assetDiscoveryRuntimeAvailable) {
    Write-Warn "Asset Discovery runtime not found at $assetDiscoveryEntryPoint. Asset Discovery setup will be skipped."
}

$pythonExe = Get-PythonExecutable
if (-not $pythonExe) {
    if (-not $AutoInstallPython) {
        throw "Python 3 not found. Re-run with -AutoInstallPython or install Python 3.9+ manually."
    }

    if (-not $isAdmin) {
        throw "Python auto-install requires administrator rights. Re-run elevated with -AutoInstallPython."
    }

    $installerPath = Join-Path $env:TEMP "python-3.12.9-amd64.exe"
    Install-Python -InstallerPath $installerPath
    $pythonExe = Get-PythonExecutable
}

if (-not $pythonExe) {
    throw "Python installation could not be verified."
}

Write-Ok "Using Python: $pythonExe"

$venvPath = Join-Path $runtimeRoot "venv"
$venvPython = Join-Path $venvPath "Scripts\python.exe"

if ($isAdmin) {
    foreach ($taskName in @('AuditToolkitWeb', 'AuditToolkitAssetDiscovery')) {
        Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    }

    Stop-ProcessesListeningOnPorts -Ports @(5000, 18080, 8080)

    $toolkitPythonProcesses = Get-CimInstance Win32_Process -Filter "Name='python.exe'" -ErrorAction SilentlyContinue |
        Where-Object {
            $_.CommandLine -and (
                $_.CommandLine -match 'SecurityAuditToolkit\\web\\run\.py' -or
                $_.CommandLine -match 'SecurityAuditToolkit\\tools\\asset-discovery'
            )
        }

    foreach ($processInfo in $toolkitPythonProcesses) {
        Stop-Process -Id $processInfo.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

$venvNeedsCreate = -not (Test-Path $venvPython)
if ($venvNeedsCreate) {
    Write-Info "Creating virtual environment at $venvPath"
}
else {
    Write-Info "Using existing virtual environment at $venvPath"
}

if ($venvNeedsCreate) {
    $venvCreateFailed = $false
    $venvCreateError = ''
    try {
        & $pythonExe -m venv $venvPath
        if ($LASTEXITCODE -ne 0) {
            $venvCreateFailed = $true
            $venvCreateError = "python -m venv exited with code $LASTEXITCODE"
        }
    }
    catch {
        $venvCreateFailed = $true
        $venvCreateError = $_.Exception.Message
    }

    if ($venvCreateFailed -and (Test-Path $venvPython)) {
        Write-Warn "Virtual environment recreation failed (`"$venvCreateError`"), but existing venv is present. Continuing with existing venv."
    }
    elseif ($venvCreateFailed) {
        throw "Failed to create virtual environment: $venvCreateError"
    }
}

if (-not (Test-Path $venvPython)) {
    throw "Virtual environment python not found: $venvPython"
}

Write-Info "Installing web dependencies..."
& $venvPython -m pip install --upgrade pip setuptools wheel --quiet
& $venvPython -m pip install -r $requirementsPath --upgrade --quiet
Write-Ok "Web dependencies installed"

$nginxExePath = $null
if ($isAdmin) {
    if ($InstallOpenSSHClient) {
        Install-OpenSSHClient -IsAdministrator:$isAdmin | Out-Null
    }

    if ($InstallOpenSSHServer) {
        Install-OpenSSHServer -IsAdministrator:$isAdmin | Out-Null
    }

    $redisExePath = Install-RedisPrerequisite -IsAdministrator:$isAdmin
    Set-RedisRuntime -RedisExePath $redisExePath -IsAdministrator:$isAdmin

    $nginxExePath = Install-NginxPrerequisite -IsAdministrator:$isAdmin
    Set-NginxRuntime -NginxExe $nginxExePath -PythonExe $venvPython -IsAdministrator:$isAdmin
}
else {
    Write-Warn "Skipping nginx provisioning (requires elevation)."
}

$assetLauncherPath = Join-Path $runtimeRoot "start-asset-discovery.ps1"
$assetDiscoveryConfigured = $false

if ($assetDiscoveryRuntimeAvailable) {
    if (-not (Test-Path $assetDiscoveryRequirementsPath)) {
        throw "Asset discovery requirements.txt not found at: $assetDiscoveryRequirementsPath"
    }

    Write-Info "Installing Asset Discovery dependencies..."
    & $venvPython -m pip install -r $assetDiscoveryRequirementsPath --upgrade --quiet
    Write-Ok "Asset Discovery dependencies installed"

    $assetDirEscaped = ConvertTo-PsSingleQuotedString $assetDiscoveryDir
    $venvPythonEscaped = ConvertTo-PsSingleQuotedString $venvPython
    $dbModeEscaped = ConvertTo-PsSingleQuotedString $dbMode
    $assetLauncherContent = @"
`$env:API_HOST = '127.0.0.1'
`$env:API_PORT = '$assetDiscoveryPort'
`$env:AUDIT_TOOLKIT_URL = 'http://127.0.0.1:5000'
`$env:DATABASE_URL = '$(ConvertTo-PsSingleQuotedString $resolvedDatabaseUrl)'
`$env:AUDIT_TOOLKIT_DB_MODE = '$dbModeEscaped'
Set-Location '$assetDirEscaped'
& '$venvPythonEscaped' -m src.app
"@
    $assetLauncherContent | Out-File -FilePath $assetLauncherPath -Encoding UTF8 -Force
    Write-Ok "Generated asset discovery launcher: $assetLauncherPath"
    $assetDiscoveryConfigured = $true
}

$celeryWorkerLauncherPath = Join-Path $runtimeRoot "start-celery-worker.ps1"
$venvPythonEscaped = ConvertTo-PsSingleQuotedString $venvPython
$scriptDirEscaped = ConvertTo-PsSingleQuotedString $scriptDir
$celeryWorkerLauncherContent = @"
`$env:DATABASE_URL = '$(ConvertTo-PsSingleQuotedString $resolvedDatabaseUrl)'
`$env:REDIS_URL = 'redis://127.0.0.1:6379/1'
`$env:REDIS_ENABLED = 'true'
`$env:AUDIT_TOOLKIT_DB_MODE = '$(ConvertTo-PsSingleQuotedString $dbMode)'
Set-Location '$scriptDirEscaped'
& '$venvPythonEscaped' -m celery -A celery_app worker --loglevel=info --concurrency=4 --max-tasks-per-child=100 --time-limit=3900 --soft-time-limit=3600 -Q audits,scheduled,celery
"@
$celeryWorkerLauncherContent | Out-File -FilePath $celeryWorkerLauncherPath -Encoding UTF8 -Force
Write-Ok "Generated Celery worker launcher: $celeryWorkerLauncherPath"

$celeryBeatLauncherPath = Join-Path $runtimeRoot "start-celery-beat.ps1"
$celeryBeatLauncherContent = @"
`$env:DATABASE_URL = '$(ConvertTo-PsSingleQuotedString $resolvedDatabaseUrl)'
`$env:REDIS_URL = 'redis://127.0.0.1:6379/1'
`$env:REDIS_ENABLED = 'true'
`$env:AUDIT_TOOLKIT_DB_MODE = '$(ConvertTo-PsSingleQuotedString $dbMode)'
`$beatScheduleDb = Join-Path (Get-Location) 'celerybeat-schedule.db'
if (Test-Path `$beatScheduleDb) { Remove-Item `$beatScheduleDb -Force -ErrorAction SilentlyContinue }
Set-Location '$scriptDirEscaped'
& '$venvPythonEscaped' -m celery -A celery_app beat --loglevel=info --pidfile= --schedule=celerybeat-schedule.db
"@
$celeryBeatLauncherContent | Out-File -FilePath $celeryBeatLauncherPath -Encoding UTF8 -Force
Write-Ok "Generated Celery beat launcher: $celeryBeatLauncherPath"

$runtimeCompatScript = Join-Path $scriptDir "scripts\enforce_postgres_runtime_compat.py"
if ($dbMode -eq 'postgres' -and (Test-Path $runtimeCompatScript)) {
    Write-Info "Applying PostgreSQL runtime compatibility checks..."
    $previousDatabaseUrl = $env:DATABASE_URL
    $runtimeCompatExitCode = 0
    $runtimeCompatOutput = @()
    $nativeErrorPreferenceWasSet = $false
    $previousNativeErrorPreference = $null
    try {
        $env:DATABASE_URL = $resolvedDatabaseUrl
        if ($PSVersionTable.PSVersion.Major -ge 7) {
            $previousNativeErrorPreference = $PSNativeCommandUseErrorActionPreference
            $PSNativeCommandUseErrorActionPreference = $false
            $nativeErrorPreferenceWasSet = $true
        }

        $previousRuntimeErrorPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            $runtimeCompatOutput = & $venvPython $runtimeCompatScript 2>&1
            $runtimeCompatExitCode = $LASTEXITCODE
        }
        finally {
            $ErrorActionPreference = $previousRuntimeErrorPreference
        }

        if ($runtimeCompatExitCode -ne 0) {
            $compatOutputText = ''
            if ($runtimeCompatOutput) {
                if ($runtimeCompatOutput -is [System.Array]) {
                    $compatOutputText = ($runtimeCompatOutput | ForEach-Object { $_.ToString() }) -join "`n"
                }
                else {
                    $compatOutputText = $runtimeCompatOutput.ToString()
                }
            }

            if ($compatOutputText) {
                $compatTail = ($compatOutputText -split "`n" | Select-Object -Last 40) -join "`n"
                Write-Warn "PostgreSQL runtime compatibility output:`n$compatTail"
            }

            if ($env:AUDIT_TOOLKIT_STRICT_RUNTIME_COMPAT -eq '1') {
                throw "PostgreSQL runtime compatibility checks failed."
            }

            Write-Warn "PostgreSQL runtime compatibility checks failed; continuing install in non-strict mode."
        }
        else {
            Write-Ok "PostgreSQL runtime compatibility checks passed"
        }
    }
    finally {
        if ($nativeErrorPreferenceWasSet) {
            $PSNativeCommandUseErrorActionPreference = $previousNativeErrorPreference
        }

        if ($null -ne $previousDatabaseUrl) {
            $env:DATABASE_URL = $previousDatabaseUrl
        }
        else {
            Remove-Item Env:DATABASE_URL -ErrorAction SilentlyContinue
        }
    }
}

$launcherPath = Join-Path $runtimeRoot "start-web.ps1"
$dataRootEscaped = ConvertTo-PsSingleQuotedString $dataRoot
$scriptDirEscaped = ConvertTo-PsSingleQuotedString $scriptDir
$venvPythonEscaped = ConvertTo-PsSingleQuotedString $venvPython
$assetDiscoveryInternalUrlEscaped = ConvertTo-PsSingleQuotedString $assetDiscoveryInternalUrl
$assetDiscoveryExternalUrlEscaped = ConvertTo-PsSingleQuotedString $assetDiscoveryExternalUrl
$initialAdminCredentialsPathEscaped = ConvertTo-PsSingleQuotedString $initialAdminCredentialsPath
$dbModeEscaped = ConvertTo-PsSingleQuotedString $dbMode
$initialPasswordLauncherLine = ""
$flaskSecretKeyPath = Join-Path $runtimeRoot "flask-secret-key.txt"
$resolvedFlaskSecretKey = ''

if (Test-Path $flaskSecretKeyPath) {
    try {
        $resolvedFlaskSecretKey = (Get-Content -Path $flaskSecretKeyPath -Raw -ErrorAction Stop).Trim()
    }
    catch {
        $resolvedFlaskSecretKey = ''
    }
}

if (-not $resolvedFlaskSecretKey -or $resolvedFlaskSecretKey.Length -lt 32) {
    $secretBytes = New-Object byte[] 32
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $rng.GetBytes($secretBytes)
    }
    finally {
        if ($rng) {
            $rng.Dispose()
        }
    }
    $resolvedFlaskSecretKey = ([System.BitConverter]::ToString($secretBytes) -replace '-', '').ToLowerInvariant()
    $resolvedFlaskSecretKey | Out-File -FilePath $flaskSecretKeyPath -Encoding ASCII -Force
}

$resolvedFlaskSecretKeyEscaped = ConvertTo-PsSingleQuotedString $resolvedFlaskSecretKey

if ($resolvedInitialAdminSecret) {
    $resolvedInitialAdminSecretEscaped = ConvertTo-PsSingleQuotedString $resolvedInitialAdminSecret
    $initialPasswordLauncherLine = "`$env:INITIAL_ADMIN_PASSWORD = '$resolvedInitialAdminSecretEscaped'"
}

$launcherContent = @"
`$env:AUDIT_TOOLKIT_DATA_DIR = '$dataRootEscaped'
`$env:FLASK_BIND_HOST = '127.0.0.1'
`$env:FLASK_PORT = '5000'
`$env:ASSET_DISCOVERY_PORT = '$assetDiscoveryPort'
`$env:ASSET_DISCOVERY_URL = '$assetDiscoveryInternalUrlEscaped'
`$env:ASSET_DISCOVERY_EXTERNAL_URL = '$assetDiscoveryExternalUrlEscaped'
`$env:INITIAL_ADMIN_CREDENTIALS_FILE = '$initialAdminCredentialsPathEscaped'
`$env:DATABASE_URL = '$(ConvertTo-PsSingleQuotedString $resolvedDatabaseUrl)'
`$env:AUDIT_TOOLKIT_DB_MODE = '$dbModeEscaped'
`$env:FLASK_SECRET_KEY = '$resolvedFlaskSecretKeyEscaped'
`$env:SECRET_KEY = '$resolvedFlaskSecretKeyEscaped'
`$env:FORCE_HTTPS = 'true'
`$env:SESSION_COOKIE_SECURE = 'true'
`$env:REDIS_ENABLED = 'true'
`$env:REDIS_URL = 'redis://127.0.0.1:6379/1'
`$env:PROXY_FIX_X_FOR = '1'
`$env:PROXY_FIX_X_PROTO = '1'
`$env:PROXY_FIX_X_HOST = '1'
`$env:PROXY_FIX_X_PORT = '1'
`$env:WAITRESS_TRUSTED_PROXY = '127.0.0.1'
`$env:WAITRESS_TRUSTED_PROXY_COUNT = '1'
$initialPasswordLauncherLine
Set-Location '$scriptDirEscaped'
& '$venvPythonEscaped' 'serve.py'
"@
$launcherContent | Out-File -FilePath $launcherPath -Encoding UTF8 -Force
Write-Ok "Generated launcher: $launcherPath"

$guideLines = @(
    "Security Audit Toolkit - Initial Login",
    "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
    "",
    "Username: admin"
)

if ($resolvedInitialAdminSecret) {
    $guideLines += "Initial Password: $resolvedInitialAdminSecret"
    $guideLines += "Password Source: $initialSecretSource"
}
else {
    $guideLines += "Initial Password: Generated on first startup (production mode)"
    $guideLines += "Password Source: generated_random"
}

$guideLines += @(
    "Credentials File: $initialAdminCredentialsPath",
    "First Login Policy: Password change is mandatory",
    "Browser Support: Use Edge, Chrome, or Firefox. Internet Explorer on Windows Server 2019 is not supported.",
    "Access URL: Use HTTPS endpoint (for example: https://<server-ip>/)",
    "",
    "Delete the credentials file after first successful login."
)

$guideLines -join [Environment]::NewLine | Out-File -FilePath $initialLoginGuidePath -Encoding UTF8 -Force
Write-Ok "Generated first-login guide: $initialLoginGuidePath"

if ($OpenFirewall) {
    if (-not $isAdmin) {
        Write-Warn "Skipping firewall rule creation (requires elevation)."
    } else {
        Get-NetFirewallRule -DisplayName "AuditToolkit Web 5000" -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
        Get-NetFirewallRule -DisplayName "AuditToolkit Asset Discovery 18080" -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue

        if (-not (Get-NetFirewallRule -DisplayName "AuditToolkit Web HTTPS 443" -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule -DisplayName "AuditToolkit Web HTTPS 443" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 443 -Profile Any | Out-Null
            Write-Ok "Firewall rule created for TCP/443 (HTTPS)"
        } else {
            Get-NetFirewallRule -DisplayName "AuditToolkit Web HTTPS 443" | Set-NetFirewallRule -Enabled True -Action Allow -Direction Inbound -Profile Any | Out-Null
            Write-Ok "Firewall rule ensured for TCP/443 (HTTPS)"
        }

        Write-Info "Direct HTTP ports (5000/8080) are kept localhost-only by default"
    }
}

if ($ConfigureStartup) {
    if (-not $isAdmin) {
        Write-Warn "Skipping startup task creation (requires elevation)."
    } else {
        Unregister-ScheduledTask -TaskName "AuditToolkitWeb" -Confirm:$false -ErrorAction SilentlyContinue
        $taskAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$launcherPath`""
        $taskTrigger = New-ScheduledTaskTrigger -AtStartup
        # RestartCount/RestartInterval mirror systemd Restart=on-failure / RestartSec=30.
        # ExecutionTimeLimit=PT0S means no timeout (equivalent to TimeoutStopSec=infinity).
        $taskSettings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
            -ExecutionTimeLimit ([TimeSpan]::Zero) `
            -RestartCount 10 `
            -RestartInterval (New-TimeSpan -Minutes 1)
        Register-ScheduledTask -TaskName "AuditToolkitWeb" -Action $taskAction -Trigger $taskTrigger -Settings $taskSettings -RunLevel Highest -User "SYSTEM" -Force | Out-Null
        Write-Ok "Scheduled task configured: AuditToolkitWeb"

        if ($assetDiscoveryConfigured) {
            Unregister-ScheduledTask -TaskName "AuditToolkitAssetDiscovery" -Confirm:$false -ErrorAction SilentlyContinue
            $assetTaskAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$assetLauncherPath`""
            Register-ScheduledTask -TaskName "AuditToolkitAssetDiscovery" -Action $assetTaskAction -Trigger $taskTrigger -Settings $taskSettings -RunLevel Highest -User "SYSTEM" -Force | Out-Null
            Write-Ok "Scheduled task configured: AuditToolkitAssetDiscovery"
        }

        # Register Celery worker task
        Unregister-ScheduledTask -TaskName "AuditToolkitCeleryWorker" -Confirm:$false -ErrorAction SilentlyContinue
        $celeryTaskAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$celeryWorkerLauncherPath`""
        Register-ScheduledTask -TaskName "AuditToolkitCeleryWorker" -Action $celeryTaskAction -Trigger $taskTrigger -Settings $taskSettings -RunLevel Highest -User "SYSTEM" -Force | Out-Null
        Write-Ok "Scheduled task configured: AuditToolkitCeleryWorker"

        # Register Celery beat task
        Unregister-ScheduledTask -TaskName "AuditToolkitCeleryBeat" -Confirm:$false -ErrorAction SilentlyContinue
        $beatTaskAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$celeryBeatLauncherPath`""
        Register-ScheduledTask -TaskName "AuditToolkitCeleryBeat" -Action $beatTaskAction -Trigger $taskTrigger -Settings $taskSettings -RunLevel Highest -User "SYSTEM" -Force | Out-Null
        Write-Ok "Scheduled task configured: AuditToolkitCeleryBeat"

        if (-not $StartServer) {
            if ($assetDiscoveryConfigured) {
                Start-ScheduledTask -TaskName "AuditToolkitAssetDiscovery" -ErrorAction SilentlyContinue
                Write-Ok "Scheduled task started: AuditToolkitAssetDiscovery"
            }

            Start-ScheduledTask -TaskName "AuditToolkitCeleryWorker" -ErrorAction SilentlyContinue
            Write-Ok "Scheduled task started: AuditToolkitCeleryWorker"

            Start-ScheduledTask -TaskName "AuditToolkitCeleryBeat" -ErrorAction SilentlyContinue
            Write-Ok "Scheduled task started: AuditToolkitCeleryBeat"

            Start-ScheduledTask -TaskName "AuditToolkitWeb" -ErrorAction SilentlyContinue
            Write-Ok "Scheduled task started: AuditToolkitWeb"
        }
    }
}

if ($ConfigureStartup -and -not $StartServer) {
    $webReady = Wait-HttpReady -Uri 'http://127.0.0.1:5000/ready' -TimeoutSeconds 180
    if (-not $webReady) {
        $webReady = Wait-HttpReady -Uri 'http://localhost:5000/ready' -TimeoutSeconds 30
    }

    if (-not $webReady) {
        if (Test-TcpPortListening -Port 5000) {
            Write-Warn "Web readiness probe failed, but port 5000 is listening; continuing."
        }
        else {
            throw "Web service did not become ready on http://127.0.0.1:5000/ready."
        }
    }

    if ($assetDiscoveryConfigured -and -not (Wait-HttpReady -Uri 'http://127.0.0.1:18080/health' -TimeoutSeconds 120)) {
        if (Test-TcpPortListening -Port 18080) {
            Write-Warn "Asset Discovery service did not pass /health probe, but port 18080 is listening; continuing."
        }
        else {
            throw "Asset Discovery service did not become ready on http://127.0.0.1:18080/health. Install cannot continue."
        }
    }

    if ($isAdmin -and $nginxExePath -and -not (Wait-HttpReady -Uri 'https://127.0.0.1/ready' -TimeoutSeconds 120 -AllowInvalidCertificate)) {
        if (Test-TcpPortListening -Port 443) {
            Write-Warn "Local HTTPS readiness probe failed, but port 443 is listening; continuing."
        }
        else {
            Write-Warn "HTTPS reverse proxy did not become ready on https://127.0.0.1/ready. Continuing with direct backend availability."
        }
    }
}

if ($StartServer) {
    if ($assetDiscoveryConfigured) {
        if (-not (Test-TcpPortListening -Port 18080)) {
            Write-Info "Starting Asset Discovery service..."
            Start-Process -FilePath "powershell.exe" -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $assetLauncherPath -WindowStyle Hidden | Out-Null
            Start-Sleep -Seconds 3
            if (Test-TcpPortListening -Port 18080) {
                Write-Ok "Asset Discovery service is listening on TCP/18080"
            }
            else {
                Write-Warn "Asset Discovery did not open TCP/18080 yet. Check $assetLauncherPath for manual start."
            }
        }
        else {
            Write-Ok "Asset Discovery service already listening on TCP/18080"
        }
    }

    Write-Info "Starting Celery worker and beat..."
    Start-Process -FilePath "powershell.exe" -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $celeryWorkerLauncherPath -WindowStyle Hidden | Out-Null
    Start-Process -FilePath "powershell.exe" -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $celeryBeatLauncherPath -WindowStyle Hidden | Out-Null
    Start-Sleep -Seconds 2
    Write-Ok "Celery worker and beat processes started"

    Write-Info "Starting web server..."
    if ($isAdmin -and (Get-ScheduledTask -TaskName "AuditToolkitNginx" -ErrorAction SilentlyContinue)) {
        Start-ScheduledTask -TaskName "AuditToolkitNginx" -ErrorAction SilentlyContinue
    }

    $env:AUDIT_TOOLKIT_DATA_DIR = $dataRoot
    $env:FLASK_BIND_HOST = "127.0.0.1"
    $env:FLASK_PORT = "5000"
    $env:ASSET_DISCOVERY_PORT = $assetDiscoveryPort
    $env:ASSET_DISCOVERY_URL = $assetDiscoveryInternalUrl
    $env:ASSET_DISCOVERY_EXTERNAL_URL = $assetDiscoveryExternalUrl
    $env:INITIAL_ADMIN_CREDENTIALS_FILE = $initialAdminCredentialsPath
    $env:DATABASE_URL = $resolvedDatabaseUrl
    $env:AUDIT_TOOLKIT_DB_MODE = $dbMode
    $env:FLASK_SECRET_KEY = $resolvedFlaskSecretKey
    $env:SECRET_KEY = $resolvedFlaskSecretKey
    $env:FORCE_HTTPS = 'true'
    $env:SESSION_COOKIE_SECURE = 'true'
    $env:REDIS_ENABLED = 'true'
    $env:REDIS_URL = 'redis://127.0.0.1:6379/1'
    $env:PROXY_FIX_X_FOR = '1'
    $env:PROXY_FIX_X_PROTO = '1'
    $env:PROXY_FIX_X_HOST = '1'
    $env:PROXY_FIX_X_PORT = '1'
    $env:WAITRESS_TRUSTED_PROXY = '127.0.0.1'
    $env:WAITRESS_TRUSTED_PROXY_COUNT = '1'
    if ($resolvedInitialAdminSecret) {
        $env:INITIAL_ADMIN_PASSWORD = $resolvedInitialAdminSecret
    }

    Show-InitialAdminOnboarding -ResolvedSecret $resolvedInitialAdminSecret -SecretSource $initialSecretSource -OnboardingPath $initialAdminCredentialsPath -GuidePath $initialLoginGuidePath

    Set-Location $scriptDir
    & $venvPython "serve.py"
    exit $LASTEXITCODE
}

$global:LASTEXITCODE = 0

Write-Output ""
Write-Host "==============================================================" -ForegroundColor Green
Write-Host " Web GUI Setup Complete" -ForegroundColor Green
Write-Host "==============================================================" -ForegroundColor Green
Write-Output ""
Write-Host "Runtime config:" -ForegroundColor Cyan
Write-Host "  Install mode    : $InstallMode" -ForegroundColor White
Write-Host "  State root      : $script:ToolkitStateRoot" -ForegroundColor White
Write-Host "  Data directory : $dataRoot" -ForegroundColor White
Write-Host "  Venv python    : $venvPython" -ForegroundColor White
Write-Host "  Redis          : Enabled (localhost:6379)" -ForegroundColor White
$discoveryStatus = if ($assetDiscoveryConfigured) { "Enabled (port 18080)" } else { "Unavailable in current install" }
Write-Host "  Discovery      : $discoveryStatus" -ForegroundColor White
Write-Output ""
Write-Host "Background job queue (Celery):" -ForegroundColor Cyan
Write-Host "  Worker launcher  : $celeryWorkerLauncherPath" -ForegroundColor White
Write-Host "  Beat launcher    : $celeryBeatLauncherPath" -ForegroundColor White
Write-Output ""
Write-Host "To run now:" -ForegroundColor Cyan
Write-Host "  powershell -NoProfile -ExecutionPolicy Bypass -File `"$launcherPath`"" -ForegroundColor White
Write-Output ""
Write-Host "Local Web UI URL:" -ForegroundColor Cyan
Write-Host "  https://localhost" -ForegroundColor White
Write-Host "  (backend health: http://localhost:5000/health)" -ForegroundColor DarkGray
if ($assetDiscoveryConfigured) {
    Write-Host "Asset Discovery URL:" -ForegroundColor Cyan
    Write-Host "  internal-only: http://localhost:18080" -ForegroundColor White
}
Write-Host "Remote access policy:" -ForegroundColor Cyan
Write-Host "  Use HTTPS on port 443 via reverse proxy / TLS terminator" -ForegroundColor White
Write-Output ""

Show-InitialAdminOnboarding -ResolvedSecret $resolvedInitialAdminSecret -SecretSource $initialSecretSource -OnboardingPath $initialAdminCredentialsPath -GuidePath $initialLoginGuidePath
