"""
Server-Sent Events (SSE) Module for Real-Time Updates

Provides SSE endpoints and Redis pub/sub for streaming audit progress:
- SSE endpoint for client connections
- Redis pub/sub for event distribution
- Progress event formatting and streaming

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import json
import time
from typing import Generator, Optional
from flask import Response, stream_with_context
from config import logger

# Optional Redis import
try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    redis = None
    REDIS_AVAILABLE = False
    logger.info("SSE: Redis not installed, using in-memory event streaming")

class SSEManager:
    """Manage Server-Sent Events and Redis pub/sub"""

    def __init__(self, redis_url: str = None):
        """
        Initialize SSE manager with Redis connection

        Args:
            redis_url: Redis connection URL (optional)
        """
        self.redis_url = redis_url
        self.redis_client = None

        if redis_url and REDIS_AVAILABLE:
            try:
                self.redis_client = redis.from_url(
                    redis_url,
                    decode_responses=True,
                    socket_timeout=5,
                    socket_connect_timeout=5
                )
                # Test connection
                self.redis_client.ping()
                logger.info("SSE Manager: Redis connection established")
            except Exception as e:
                logger.warning(f"SSE Manager: Redis unavailable ({e}), SSE disabled")
                self.redis_client = None

    def publish_event(self, channel: str, event_type: str, data: dict):
        """
        Publish event to Redis channel

        Args:
            channel: Channel name (e.g., 'task:abc-123')
            event_type: Event type (e.g., 'progress', 'complete', 'error')
            data: Event data dictionary
        """
        if not self.redis_client:
            return

        try:
            event = {
                'type': event_type,
                'timestamp': time.time(),
                'data': data
            }

            self.redis_client.publish(channel, json.dumps(event))
            logger.debug(f"Published {event_type} event to {channel}")
        except Exception as e:
            logger.error(f"Failed to publish event: {e}")

    def publish_task_progress(self, task_id: str, status: str, progress: int, message: str = None):
        """
        Publish task progress event

        Args:
            task_id: Celery task ID
            status: Status message
            progress: Progress percentage (0-100)
            message: Optional additional message
        """
        self.publish_event(
            channel=f'task:{task_id}',
            event_type='progress',
            data={
                'task_id': task_id,
                'status': status,
                'progress': progress,
                'message': message
            }
        )

    def publish_task_output(self, task_id: str, output: str, is_error: bool = False):
        """
        Publish task output line

        Args:
            task_id: Celery task ID
            output: Output line
            is_error: Whether this is stderr output
        """
        self.publish_event(
            channel=f'task:{task_id}',
            event_type='output',
            data={
                'task_id': task_id,
                'output': output,
                'is_error': is_error
            }
        )

    def publish_task_complete(self, task_id: str, status: str, result: dict):
        """
        Publish task completion event

        Args:
            task_id: Celery task ID
            status: Final status (success, failure, timeout)
            result: Task result dictionary
        """
        self.publish_event(
            channel=f'task:{task_id}',
            event_type='complete',
            data={
                'task_id': task_id,
                'status': status,
                'result': result
            }
        )

    def publish_task_error(self, task_id: str, error: str):
        """
        Publish task error event

        Args:
            task_id: Celery task ID
            error: Error message
        """
        self.publish_event(
            channel=f'task:{task_id}',
            event_type='error',
            data={
                'task_id': task_id,
                'error': error
            }
        )

    def subscribe_to_task(self, task_id: str, timeout: int = 3600) -> Generator[str, None, None]:
        """
        Subscribe to task events and yield SSE-formatted messages

        Args:
            task_id: Celery task ID
            timeout: Maximum time to wait for events (seconds)

        Yields:
            SSE-formatted event strings
        """
        if not self.redis_client:
            yield self._format_sse_message('error', {'error': 'SSE not available (Redis not configured)'})
            return

        try:
            pubsub = self.redis_client.pubsub()
            channel = f'task:{task_id}'
            pubsub.subscribe(channel)

            logger.info(f"SSE: Client subscribed to {channel}")

            # Send connection established event
            yield self._format_sse_message('connected', {'task_id': task_id})

            # Listen for events with timeout
            start_time = time.time()
            task_completed = False

            for message in pubsub.listen():
                # Check timeout
                if time.time() - start_time > timeout:
                    yield self._format_sse_message('timeout', {'message': 'SSE connection timeout'})
                    break

                # Filter out subscription confirmation messages
                if message['type'] != 'message':
                    continue

                # Parse event
                try:
                    event = json.loads(message['data'])
                    event_type = event.get('type')
                    event_data = event.get('data', {})

                    # Yield SSE-formatted message
                    yield self._format_sse_message(event_type, event_data)

                    # Check if task completed
                    if event_type in ('complete', 'error'):
                        task_completed = True
                        # Wait a moment for any final messages
                        time.sleep(0.5)
                        break

                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse SSE event: {e}")
                    continue

            # Send close event
            if task_completed:
                yield self._format_sse_message('close', {'message': 'Task completed'})
            else:
                yield self._format_sse_message('close', {'message': 'Stream ended'})

        except Exception as e:
            logger.error(f"SSE subscription error: {e}")
            yield self._format_sse_message('error', {'error': str(e)})

        finally:
            try:
                pubsub.unsubscribe(channel)
                pubsub.close()
            except Exception as e:
                logger.debug(f"Pubsub cleanup failed: {e}")

    def _format_sse_message(self, event_type: str, data: dict) -> str:
        """
        Format SSE message according to specification

        Args:
            event_type: Event type
            data: Event data

        Returns:
            SSE-formatted string
        """
        # SSE format: event: <type>\ndata: <json>\n\n
        return f"event: {event_type}\ndata: {json.dumps(data)}\n\n"


def create_sse_response(generator: Generator[str, None, None]) -> Response:
    """
    Create Flask response for SSE stream

    Args:
        generator: Generator yielding SSE-formatted messages

    Returns:
        Flask Response with SSE headers
    """
    response = Response(
        stream_with_context(generator),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'X-Accel-Buffering': 'no',  # Disable nginx buffering
            'Connection': 'keep-alive'
        }
    )
    return response


# Global SSE manager instance (initialized in app.py)
sse_manager: Optional[SSEManager] = None


def init_sse_manager(redis_url: str = None):
    """
    Initialize global SSE manager

    Args:
        redis_url: Redis connection URL
    """
    global sse_manager
    sse_manager = SSEManager(redis_url)
    return sse_manager


def get_sse_manager() -> Optional[SSEManager]:
    """Get global SSE manager instance"""
    return sse_manager


__all__ = ['SSEManager', 'create_sse_response', 'init_sse_manager', 'get_sse_manager']
