#!/usr/bin/env python3
"""
Async SSH Manager Module

Provides asyncio-based SSH operations for parallel execution:
- Concurrent SSH connections to multiple servers
- Connection pooling and rate limiting
- Async command execution with timeout
- Error handling and connection retry logic
- Support for 100+ concurrent connections

Uses asyncssh library for async SSH/SFTP operations.

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import asyncio
import asyncssh
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class SSHResult:
    """Result from SSH command execution"""
    server_id: int
    server_name: str
    success: bool
    exit_code: Optional[int]
    stdout: str
    stderr: str
    duration_seconds: float
    error: Optional[str] = None
    timestamp: datetime = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow()


class AsyncSSHConnectionPool:
    """
    Manages a pool of async SSH connections

    Features:
    - Connection reuse (keep-alive)
    - Automatic reconnection on failure
    - Configurable max connections per server
    - Connection timeout and cleanup
    """

    def __init__(self, max_connections_per_host: int = 5):
        self.max_connections_per_host = max_connections_per_host
        self.connections: Dict[str, List[asyncssh.SSHClientConnection]] = {}
        self.connection_locks: Dict[str, asyncio.Semaphore] = {}
        self.active_connections: Dict[str, int] = {}

    def _get_host_key(self, hostname: str, port: int, username: str) -> str:
        """Generate unique key for host"""
        return f"{username}@{hostname}:{port}"

    async def get_connection(self, hostname: str, port: int, username: str,
                            password: Optional[str] = None,
                            key_path: Optional[str] = None,
                            timeout: int = 30) -> asyncssh.SSHClientConnection:
        """
        Get or create SSH connection from pool

        Args:
            hostname: Server hostname/IP
            port: SSH port
            username: SSH username
            password: SSH password (optional)
            key_path: Path to SSH private key (optional)
            timeout: Connection timeout in seconds

        Returns:
            Active SSH connection
        """
        host_key = self._get_host_key(hostname, port, username)

        # Initialize lock for this host if not exists
        if host_key not in self.connection_locks:
            self.connection_locks[host_key] = asyncio.Semaphore(self.max_connections_per_host)

        # Use async context manager for guaranteed semaphore release (HIGH-02 fix)
        async with self.connection_locks[host_key]:
            # Check if we have an active connection
            if host_key in self.connections and self.connections[host_key]:
                for conn in self.connections[host_key]:
                    if not conn.is_closed():
                        return conn

            # Create new connection
            logger.debug(f"Creating new SSH connection to {host_key}")

            # Prepare connection options
            options = {
                'known_hosts': None,  # Disable known_hosts check for automation
                'username': username,
                'connect_timeout': timeout,
            }

            # Add authentication
            if password:
                options['password'] = password
            elif key_path:
                options['client_keys'] = [key_path]

            # Connect
            conn = await asyncssh.connect(hostname, port=port, **options)

            # Store in pool
            if host_key not in self.connections:
                self.connections[host_key] = []
            self.connections[host_key].append(conn)

            # Track active connections
            self.active_connections[host_key] = self.active_connections.get(host_key, 0) + 1

            logger.info(f"SSH connection established to {host_key} (total: {self.active_connections[host_key]})")
            return conn

    async def close_all(self):
        """Close all pooled connections"""
        logger.info("Closing all SSH connections in pool")
        for host_key, conns in self.connections.items():
            for conn in conns:
                if not conn.is_closed():
                    conn.close()
                    await conn.wait_closed()
        self.connections.clear()
        self.active_connections.clear()


class AsyncSSHManager:
    """
    Async SSH Manager for parallel operations

    Features:
    - Execute commands on multiple servers concurrently
    - Connection pooling for performance
    - Configurable concurrency limits
    - Automatic retry on failure
    - Comprehensive error handling
    """

    def __init__(self, max_concurrent: int = 50, max_connections_per_host: int = 5):
        """
        Initialize async SSH manager

        Args:
            max_concurrent: Maximum concurrent operations (default: 50)
            max_connections_per_host: Max connections per server (default: 5)
        """
        self.max_concurrent = max_concurrent
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.pool = AsyncSSHConnectionPool(max_connections_per_host)
        self.results: List[SSHResult] = []

    async def execute_command(self, server_id: int, server_name: str,
                             hostname: str, port: int, username: str,
                             command: str, password: Optional[str] = None,
                             key_path: Optional[str] = None,
                             timeout: int = 600,
                             retry_count: int = 2) -> SSHResult:
        """
        Execute command on remote server asynchronously

        Args:
            server_id: Server database ID
            server_name: Server name for logging
            hostname: Server hostname/IP
            port: SSH port
            username: SSH username
            command: Command to execute
            password: SSH password (optional)
            key_path: SSH key path (optional)
            timeout: Command timeout in seconds
            retry_count: Number of retry attempts on failure

        Returns:
            SSHResult with execution details
        """
        start_time = datetime.utcnow()

        # Acquire semaphore (limit concurrent operations)
        async with self.semaphore:
            for attempt in range(retry_count + 1):
                try:
                    # Get connection from pool
                    conn = await self.pool.get_connection(
                        hostname, port, username, password, key_path
                    )

                    # Execute command with timeout
                    result = await asyncio.wait_for(
                        conn.run(command, check=False),
                        timeout=timeout
                    )

                    duration = (datetime.utcnow() - start_time).total_seconds()

                    # Create result object
                    ssh_result = SSHResult(
                        server_id=server_id,
                        server_name=server_name,
                        success=(result.exit_status == 0),
                        exit_code=result.exit_status,
                        stdout=result.stdout,
                        stderr=result.stderr,
                        duration_seconds=duration
                    )

                    logger.info(f"Command completed on {server_name}: exit={result.exit_status}, duration={duration:.2f}s")
                    return ssh_result

                except asyncio.TimeoutError:
                    duration = (datetime.utcnow() - start_time).total_seconds()
                    logger.warning(f"Command timeout on {server_name} (attempt {attempt + 1}/{retry_count + 1})")

                    if attempt == retry_count:
                        return SSHResult(
                            server_id=server_id,
                            server_name=server_name,
                            success=False,
                            exit_code=None,
                            stdout="",
                            stderr=f"Command timeout after {timeout}s",
                            duration_seconds=duration,
                            error="Timeout"
                        )

                except asyncssh.Error as e:
                    duration = (datetime.utcnow() - start_time).total_seconds()
                    logger.error(f"SSH error on {server_name} (attempt {attempt + 1}/{retry_count + 1}): {e}")

                    if attempt == retry_count:
                        return SSHResult(
                            server_id=server_id,
                            server_name=server_name,
                            success=False,
                            exit_code=None,
                            stdout="",
                            stderr=str(e),
                            duration_seconds=duration,
                            error=f"SSH error: {type(e).__name__}"
                        )

                    # Wait before retry
                    await asyncio.sleep(2 ** attempt)

                except Exception as e:
                    duration = (datetime.utcnow() - start_time).total_seconds()
                    logger.error(f"Unexpected error on {server_name}: {e}")

                    return SSHResult(
                        server_id=server_id,
                        server_name=server_name,
                        success=False,
                        exit_code=None,
                        stdout="",
                        stderr=str(e),
                        duration_seconds=duration,
                        error=f"Unexpected error: {type(e).__name__}"
                    )

    async def execute_on_servers(self, servers: List[Dict], command: str,
                                 timeout: int = 600) -> List[SSHResult]:
        """
        Execute command on multiple servers concurrently

        Args:
            servers: List of server config dicts with keys:
                     id, name, hostname, port, username, password, key_path
            command: Command to execute on all servers
            timeout: Command timeout per server

        Returns:
            List of SSHResult objects (one per server)
        """
        logger.info(f"Starting parallel execution on {len(servers)} servers")
        start_time = datetime.utcnow()

        # Create tasks for all servers
        tasks = []
        for server in servers:
            task = self.execute_command(
                server_id=server['id'],
                server_name=server['name'],
                hostname=server['hostname'],
                port=server.get('port', 22),
                username=server['username'],
                command=command,
                password=server.get('password'),
                key_path=server.get('key_path'),
                timeout=timeout
            )
            tasks.append(task)

        # Execute all tasks concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Process results
        ssh_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                server = servers[i]
                ssh_results.append(SSHResult(
                    server_id=server['id'],
                    server_name=server['name'],
                    success=False,
                    exit_code=None,
                    stdout="",
                    stderr=str(result),
                    duration_seconds=0,
                    error=f"Task exception: {type(result).__name__}"
                ))
            else:
                ssh_results.append(result)

        duration = (datetime.utcnow() - start_time).total_seconds()
        successful = sum(1 for r in ssh_results if r.success)

        logger.info(f"Parallel execution complete: {successful}/{len(servers)} successful, duration={duration:.2f}s")

        self.results = ssh_results
        return ssh_results

    async def cleanup(self):
        """Cleanup resources"""
        await self.pool.close_all()

    async def execute_script_content(self, server_id: int, server_name: str,
                                     hostname: str, port: int, username: str,
                                     script_content: str, password: Optional[str] = None,
                                     key_path: Optional[str] = None,
                                     timeout: int = 600,
                                     retry_count: int = 2,
                                     interpreter: str = "bash") -> SSHResult:
        """
        Execute script by streaming content via stdin - NO DEPLOYMENT REQUIRED

        This allows running audit scripts on remote hosts without pre-deploying
        the audit toolkit. The script content is passed directly to the interpreter.

        Args:
            server_id: Server database ID
            server_name: Server name for logging
            hostname: Server hostname/IP
            port: SSH port
            username: SSH username
            script_content: Full script content to execute
            password: SSH password (optional)
            key_path: SSH key path (optional)
            timeout: Command timeout in seconds
            retry_count: Number of retry attempts
            interpreter: Script interpreter (default: bash, can be powershell, python3)

        Returns:
            SSHResult with execution details
        """
        start_time = datetime.utcnow()

        # Build command that reads script from stdin
        if interpreter == "powershell":
            cmd = "powershell -NonInteractive -Command -"
        elif interpreter == "python3":
            cmd = "python3 -"
        else:
            cmd = "bash -s"

        async with self.semaphore:
            for attempt in range(retry_count + 1):
                try:
                    conn = await self.pool.get_connection(
                        hostname, port, username, password, key_path
                    )

                    # Execute with script content passed via stdin
                    result = await asyncio.wait_for(
                        conn.run(cmd, input=script_content, check=False),
                        timeout=timeout
                    )

                    duration = (datetime.utcnow() - start_time).total_seconds()

                    ssh_result = SSHResult(
                        server_id=server_id,
                        server_name=server_name,
                        success=(result.exit_status == 0),
                        exit_code=result.exit_status,
                        stdout=result.stdout,
                        stderr=result.stderr,
                        duration_seconds=duration
                    )

                    logger.info(f"Script streamed to {server_name}: exit={result.exit_status}, duration={duration:.2f}s")
                    return ssh_result

                except asyncio.TimeoutError:
                    duration = (datetime.utcnow() - start_time).total_seconds()
                    logger.warning(f"Script timeout on {server_name} (attempt {attempt + 1}/{retry_count + 1})")
                    if attempt == retry_count:
                        return SSHResult(
                            server_id=server_id,
                            server_name=server_name,
                            success=False,
                            exit_code=None,
                            stdout="",
                            stderr=f"Script timeout after {timeout}s",
                            duration_seconds=duration,
                            error="Timeout"
                        )

                except asyncssh.Error as e:
                    duration = (datetime.utcnow() - start_time).total_seconds()
                    logger.error(f"SSH error streaming to {server_name}: {e}")
                    if attempt == retry_count:
                        return SSHResult(
                            server_id=server_id,
                            server_name=server_name,
                            success=False,
                            exit_code=None,
                            stdout="",
                            stderr=str(e),
                            duration_seconds=duration,
                            error=f"SSH error: {type(e).__name__}"
                        )
                    await asyncio.sleep(2 ** attempt)

                except Exception as e:
                    duration = (datetime.utcnow() - start_time).total_seconds()
                    return SSHResult(
                        server_id=server_id,
                        server_name=server_name,
                        success=False,
                        exit_code=None,
                        stdout="",
                        stderr=str(e),
                        duration_seconds=duration,
                        error=f"Unexpected error: {type(e).__name__}"
                    )

    async def execute_scripts_on_servers(self, servers: List[Dict], script_content: str,
                                         timeout: int = 600,
                                         interpreter: str = "bash") -> List[SSHResult]:
        """
        Stream and execute script on multiple servers - NO DEPLOYMENT REQUIRED

        Args:
            servers: List of server config dicts
            script_content: Full script content to execute
            timeout: Command timeout per server
            interpreter: Script interpreter (bash, powershell, python3)

        Returns:
            List of SSHResult objects
        """
        logger.info(f"Starting parallel script streaming on {len(servers)} servers")
        start_time = datetime.utcnow()

        tasks = []
        for server in servers:
            task = self.execute_script_content(
                server_id=server['id'],
                server_name=server['name'],
                hostname=server['hostname'],
                port=server.get('port', 22),
                username=server['username'],
                script_content=script_content,
                password=server.get('password'),
                key_path=server.get('key_path'),
                timeout=timeout,
                interpreter=interpreter
            )
            tasks.append(task)

        results = await asyncio.gather(*tasks, return_exceptions=True)

        ssh_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                server = servers[i]
                ssh_results.append(SSHResult(
                    server_id=server['id'],
                    server_name=server['name'],
                    success=False,
                    exit_code=None,
                    stdout="",
                    stderr=str(result),
                    duration_seconds=0,
                    error=f"Task exception: {type(result).__name__}"
                ))
            else:
                ssh_results.append(result)

        duration = (datetime.utcnow() - start_time).total_seconds()
        successful = sum(1 for r in ssh_results if r.success)
        logger.info(f"Script streaming complete: {successful}/{len(servers)} successful, duration={duration:.2f}s")

        self.results = ssh_results
        return ssh_results

    def get_summary(self) -> Dict:
        """Get execution summary"""
        if not self.results:
            return {'total': 0, 'successful': 0, 'failed': 0, 'average_duration': 0}

        successful = sum(1 for r in self.results if r.success)
        failed = len(self.results) - successful
        avg_duration = sum(r.duration_seconds for r in self.results) / len(self.results)

        return {
            'total': len(self.results),
            'successful': successful,
            'failed': failed,
            'success_rate': (successful / len(self.results)) * 100,
            'average_duration': avg_duration,
            'total_duration': sum(r.duration_seconds for r in self.results)
        }


# Convenience function for one-off executions
async def execute_parallel_ssh(servers: List[Dict], command: str,
                               max_concurrent: int = 50,
                               timeout: int = 600) -> Tuple[List[SSHResult], Dict]:
    """
    Execute command on multiple servers concurrently (convenience function)

    Args:
        servers: List of server configurations
        command: Command to execute
        max_concurrent: Maximum concurrent operations
        timeout: Command timeout per server

    Returns:
        Tuple of (results list, summary dict)
    """
    manager = AsyncSSHManager(max_concurrent=max_concurrent)

    try:
        results = await manager.execute_on_servers(servers, command, timeout)
        summary = manager.get_summary()
        return results, summary

    finally:
        await manager.cleanup()
