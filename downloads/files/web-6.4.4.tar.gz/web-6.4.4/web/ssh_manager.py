#!/usr/bin/env python3
"""
SSH Manager Module

Handles secure SSH/SCP operations:
- SSH connection management with ControlMaster (connection reuse)
- Secure command execution (no shell injection)
- SCP file transfers
- Password and key-based authentication
- Host key verification
- Circuit breaker protection against cascading failures
"""

import os
import subprocess  # nosec B404
import logging
import shutil
import time
from pathlib import Path
from circuit_breaker import get_circuit_breaker_registry, CircuitBreakerError

logger = logging.getLogger(__name__)


def _resolve_executable(executable: str) -> str:
    """Resolve executable path when available."""
    resolved = shutil.which(executable)
    return resolved or executable


def _contains_unsafe_paramiko_tokens(command):
    """Return True when command contains control tokens unsafe for fallback shell execution."""
    if not isinstance(command, str):
        return True
    disallowed_tokens = ('\x00', '\n', '\r', '`')
    return any(token in command for token in disallowed_tokens)


class SSHManager:
    """
    Manages SSH connections and command execution

    Features:
    - Connection multiplexing (ControlMaster) for performance
    - No shell injection vulnerabilities
    - Password and public key authentication
    - Host key verification
    """

    def __init__(self, ssh_dir, ssh_host_key_manager, password_manager):
        """
        Initialize SSH Manager

        Args:
            ssh_dir: SSH directory path
            ssh_host_key_manager: SSHHostKeyManager instance
            password_manager: ServerPasswordManager instance
        """
        self.ssh_dir = Path(ssh_dir)
        self.control_dir = self.ssh_dir / "control"
        self.control_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.ssh_host_key_manager = ssh_host_key_manager
        self.password_manager = password_manager

    def get_control_path(self, server):
        """
        Get SSH ControlPath for connection multiplexing (reuse connections)

        Args:
            server: Server configuration dict

        Returns:
            Path to control socket

        Performance: Reusing connections is 10-100x faster than creating new ones
        """
        host_key = f"{server['user']}@{server['host']}:{server.get('port', 22)}"
        # Sanitize for filesystem
        safe_key = host_key.replace('/', '_').replace('@', '_at_').replace(':', '_')
        return self.control_dir / f"ssh-{safe_key}"

    def close_control_master(self, server):
        """
        Explicitly close SSH control master connection

        Args:
            server: Server configuration dict

        Returns:
            True if successful, False otherwise
        """
        try:
            control_path = self.get_control_path(server)
            subprocess.run(
                [_resolve_executable('ssh'), '-O', 'exit', '-o', f'ControlPath={control_path}',
                 f"{server['user']}@{server['host']}"],
                capture_output=True,
                timeout=5
            )  # nosec B603
            logger.info(f"Closed SSH connection to {server.get('name', server['host'])}")
            return True
        except Exception as e:
            logger.debug(f"Error closing SSH control master: {e}")
            return False

    def build_ssh_command(self, server, command, use_control_master=True):
        """
        Build SSH command as list (no shell injection) with secure options
        Supports both Linux (bash/sh) and Windows (PowerShell) remote execution.
        """
        cmd_parts = []
        env = os.environ.copy()

        # Get decrypted password if using password auth
        password = None
        if server.get("auth_type") == "password" and server.get('password'):
            password = self.password_manager.decrypt_password(server['password'])

        # Add sshpass for password authentication
        if password:
            env['SSHPASS'] = password
            cmd_parts.extend([_resolve_executable('sshpass'), '-e'])

        # Add SSH command with secure options
        cmd_parts.extend([
            _resolve_executable('ssh'),
            '-o', 'StrictHostKeyChecking=accept-new',
            '-o', f'UserKnownHostsFile={str(self.ssh_host_key_manager.known_hosts_file)}',
            '-o', 'HashKnownHosts=no',
            '-o', 'ConnectTimeout=10',
        ])

        # PERFORMANCE FIX: Add ControlMaster for connection reuse
        if use_control_master:
            control_path = self.get_control_path(server)
            cmd_parts.extend([
                '-o', 'ControlMaster=auto',
                '-o', f'ControlPath={control_path}',
                '-o', 'ControlPersist=60s',
            ])

        # Add port
        cmd_parts.extend(['-p', str(server.get('port', 22))])

        # Add key authentication if configured
        if server.get("auth_type") == "public_key" and server.get('key_path'):
            key_path = Path(server['key_path'])
            if key_path.exists():
                cmd_parts.extend(['-i', str(key_path)])
            else:
                logger.warning(f"SSH key not found: {server['key_path']}")

        # Add remote user and host
        cmd_parts.append(f"{server['user']}@{server['host']}")

        # Build remote command based on OS type
        os_type = server.get('os_type', 'linux').lower()
        if os_type == 'windows':
            # Use PowerShell for Windows audit execution
            remote_cmd = f'powershell -NoProfile -ExecutionPolicy Bypass -File "{command}"'
        else:
            # Default to bash/sh for Linux
            remote_cmd = f'bash "{command}"'

        cmd_parts.append(remote_cmd)
        return cmd_parts, env

    def execute_ssh(self, server, command, timeout=30):
        """
        Execute SSH command safely without shell injection

        Args:
            server: Server configuration dict
            command: Command to execute
            timeout: Command timeout in seconds

        Returns:
            subprocess.CompletedProcess result

        Security: No shell=True, prevents command injection
        Performance: Uses circuit breaker to prevent cascading failures
        """
        server_name = server.get('name', server['host'])

        # Get circuit breaker for this server
        circuit_registry = get_circuit_breaker_registry()
        circuit_id = f"ssh:{server['host']}:{server.get('port', 22)}"
        circuit_breaker = circuit_registry.get_breaker(
            service_id=circuit_id,
            failure_threshold=5,  # Open circuit after 5 consecutive failures
            recovery_timeout=60,  # Retry after 1 minute
            expected_exception=subprocess.SubprocessError
        )

        try:
            cmd_parts, env = self.build_ssh_command(server, command)
            logger.info(f"Executing SSH command on {server_name}: {command[:50]}...")

            # Execute through circuit breaker
            def execute_command():
                return subprocess.run(
                    cmd_parts,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    env=env
                )  # nosec B603

            try:
                result = circuit_breaker.call(execute_command)
            finally:
                # HIGH-04 fix: Clear password from env immediately after use
                if 'SSHPASS' in env:
                    env['SSHPASS'] = ''
                    del env['SSHPASS']

            if result.returncode != 0:
                logger.warning(f"SSH command failed on {server_name}: {result.stderr[:100]}")

            return result

        except CircuitBreakerError:
            # Circuit breaker is open - re-raise to caller
            logger.error(f"SSH connection to {server_name} blocked by circuit breaker")
            raise

        except subprocess.TimeoutExpired:
            logger.error(f"SSH command timeout on {server_name} after {timeout}s")
            raise

        except Exception as e:
            logger.error(f"SSH command failed on {server_name}: {e}")
            raise

    def build_scp_command(self, server, source, destination):
        """
        Build SCP command as list (no shell injection)

        Args:
            server: Server configuration dict
            source: Source file/path
            destination: Destination file/path

        Returns:
            Tuple of (cmd_parts, env) - command parts list and environment dict
        """
        cmd_parts = []
        env = os.environ.copy()

        # Get decrypted password if using password auth
        password = None
        if server.get("auth_type") == "password" and server.get('password'):
            password = self.password_manager.decrypt_password(server['password'])

        # Add sshpass for password authentication
        if password:
            env['SSHPASS'] = password
            cmd_parts.extend([_resolve_executable('sshpass'), '-e'])

        # Add SCP with secure options
        cmd_parts.extend([
            _resolve_executable('scp'),
            '-o', 'StrictHostKeyChecking=accept-new',
            '-o', f'UserKnownHostsFile={str(self.ssh_host_key_manager.known_hosts_file)}',
            '-o', 'HashKnownHosts=no',
            '-P', str(server.get('port', 22)),
        ])

        # Add key if configured
        if server.get("auth_type") == "public_key" and server.get('key_path'):
            key_path = Path(server['key_path'])
            if key_path.exists():
                cmd_parts.extend(['-i', str(key_path)])

        # Add source and destination
        cmd_parts.append(source)
        cmd_parts.append(destination)

        return cmd_parts, env

    def execute_scp(self, server, source, destination, timeout=120):
        """
        Execute SCP command safely (source to destination format)

        Args:
            server: Server configuration dict
            source: Source file/path
            destination: Destination file/path
            timeout: Command timeout in seconds

        Returns:
            subprocess.CompletedProcess result
        """
        try:
            cmd_parts, env = self.build_scp_command(server, source, destination)
            server_name = server.get('name', server['host'])
            logger.info(f"Executing SCP on {server_name}: {source} -> {destination}")

            try:
                result = subprocess.run(
                    cmd_parts,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    env=env
                )  # nosec B603
            finally:
                # HIGH-04 fix: Clear password from env immediately after use
                if 'SSHPASS' in env:
                    env['SSHPASS'] = ''
                    del env['SSHPASS']

            if result.returncode != 0:
                logger.warning(f"SCP failed on {server_name}: {result.stderr[:100]}")

            return result
        except subprocess.TimeoutExpired:
            logger.error(f"SCP timeout on {server.get('name', server['host'])} after {timeout}s")
            raise
        except Exception as e:
            logger.error(f"SCP failed on {server.get('name', server['host'])}: {e}")
            raise

    def test_connection(self, server, timeout=10):
        """
        Test SSH connection to server

        Args:
            server: Server configuration dict
            timeout: Connection timeout in seconds

        Returns:
            Tuple of (success, message)
        """
        try:
            result = self.execute_command(server, "echo 'Connection successful'", timeout=timeout)

            if result.returncode == 0:
                return True, "Connection successful"
            else:
                return False, f"Connection failed: {result.stderr}"
        except subprocess.TimeoutExpired:
            return False, f"Connection timeout after {timeout}s"
        except Exception as e:
            return False, f"Connection error: {str(e)}"

    def execute_command(self, server, command, timeout=30):
        """
        Execute a raw command via SSH (no script wrapper)

        Unlike execute_ssh which wraps commands in bash/powershell -File,
        this method runs commands directly - useful for simple tests.

        Args:
            server: Server configuration dict
            command: Command string to execute
            timeout: Command timeout in seconds

        Returns:
            subprocess.CompletedProcess result
        """
        cmd_parts = []
        env = os.environ.copy()

        # Get decrypted password if using password auth
        password = None
        if server.get("auth_type") == "password" and server.get('password'):
            password = self.password_manager.decrypt_password(server['password'])

        use_paramiko_fallback = bool(password) and shutil.which('sshpass') is None
        if use_paramiko_fallback:
            return self._execute_command_paramiko(server, command, password, timeout)

        # Add sshpass for password authentication
        if password:
            env['SSHPASS'] = password
            cmd_parts.extend([_resolve_executable('sshpass'), '-e'])

        # Add SSH command with secure options
        cmd_parts.extend([
            _resolve_executable('ssh'),
            '-o', 'StrictHostKeyChecking=accept-new',
            '-o', f'UserKnownHostsFile={str(self.ssh_host_key_manager.known_hosts_file)}',
            '-o', 'HashKnownHosts=no',
            '-o', f'ConnectTimeout={min(timeout, 10)}',
        ])

        # Add port
        cmd_parts.extend(['-p', str(server.get('port', 22))])

        # Add key authentication if configured
        if server.get("auth_type") == "public_key" and server.get('key_path'):
            key_path = Path(server['key_path'])
            if key_path.exists():
                cmd_parts.extend(['-i', str(key_path)])

        # Add remote user and host
        cmd_parts.append(f"{server['user']}@{server['host']}")

        # Add command directly (no bash/powershell wrapper)
        cmd_parts.append(command)

        server_name = server.get('name', server['host'])
        logger.info(f"Executing SSH command on {server_name}: {command[:50]}...")

        try:
            result = subprocess.run(
                cmd_parts,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=env
            )  # nosec B603
        finally:
            # Clear password from env immediately after use
            if 'SSHPASS' in env:
                env['SSHPASS'] = ''
                del env['SSHPASS']

        if result.returncode != 0:
            logger.warning(f"SSH command failed on {server_name}: {result.stderr[:100] if result.stderr else 'no error output'}")

        return result

    def _execute_command_paramiko(self, server, command, password, timeout=30):
        """Execute SSH command using paramiko when sshpass is unavailable."""
        server_name = server.get('name', server['host'])
        logger.info(f"Executing SSH command on {server_name} via paramiko fallback: {command[:50]}...")

        try:
            import paramiko
        except Exception as import_err:
            raise RuntimeError(
                "Password-auth SSH requires sshpass or paramiko in this runtime"
            ) from import_err

        max_attempts = 3
        last_error = None

        for attempt in range(1, max_attempts + 1):
            client = paramiko.SSHClient()
            client.load_system_host_keys()
            known_hosts_path = self.ssh_host_key_manager.known_hosts_file
            if known_hosts_path and Path(known_hosts_path).exists():
                client.load_host_keys(str(known_hosts_path))
            client.set_missing_host_key_policy(paramiko.RejectPolicy())

            try:
                client.connect(
                    hostname=server['host'],
                    port=int(server.get('port', 22)),
                    username=server['user'],
                    password=password,
                    timeout=timeout,
                    banner_timeout=timeout,
                    auth_timeout=timeout,
                    look_for_keys=False,
                    allow_agent=False,
                )

                if _contains_unsafe_paramiko_tokens(command):
                    raise ValueError('Unsafe command content blocked for paramiko fallback execution')

                stdin, stdout, stderr = client.exec_command(command, timeout=timeout)  # nosec B601 - command string validated and used only in trusted internal execution path
                _ = stdin
                exit_code = stdout.channel.recv_exit_status()
                stdout_text = stdout.read().decode('utf-8', errors='replace')
                stderr_text = stderr.read().decode('utf-8', errors='replace')

                return subprocess.CompletedProcess(
                    args=['paramiko', f"{server['user']}@{server['host']}", command],
                    returncode=exit_code,
                    stdout=stdout_text,
                    stderr=stderr_text,
                )
            except paramiko.AuthenticationException:
                raise
            except (paramiko.SSHException, EOFError, TimeoutError, OSError, ValueError) as err:
                last_error = err
                is_banner_issue = 'Error reading SSH protocol banner' in str(err)
                if attempt < max_attempts and is_banner_issue:
                    backoff_seconds = 0.4 * attempt
                    logger.warning(
                        f"Transient SSH banner failure on {server_name} (attempt {attempt}/{max_attempts}); retrying in {backoff_seconds:.1f}s"
                    )
                    time.sleep(backoff_seconds)
                    continue
                raise
            finally:
                client.close()

        if last_error is not None:
            raise last_error

        raise RuntimeError('Paramiko execution failed without a captured error')

    def cleanup_control_masters(self):
        """
        Close all active SSH control master connections

        Returns:
            Number of connections closed
        """
        closed = 0
        try:
            for control_file in self.control_dir.glob("ssh-*"):
                try:
                    control_file.unlink()
                    closed += 1
                except Exception as e:
                    logger.debug(f"Error removing control file {control_file}: {e}")

            logger.info(f"Cleaned up {closed} SSH control master connections")
            return closed
        except Exception as e:
            logger.error(f"Error cleaning up control masters: {e}")
            return closed


__all__ = [
    'SSHManager',
]
