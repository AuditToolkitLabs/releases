# Disclaimer

## Overview

The Security Audit Toolkit consists of two types of scripts:

| Type | Location | System Impact |
|------|----------|---------------|
| **Audit Scripts** | `audits/` | Read-only inspection |
| **Remediation Scripts** | `fix/` | **Modifies system configuration** |

## Access Controls

The toolkit includes built-in security controls to prevent unauthorized use:

| Control | Description |
|---------|-------------|
| **Two-Factor Authentication** | Requires two separate logins before accessing remediation features |
| **Superadmin Only** | Remediation/fix scripts are restricted to superadmin accounts |

These controls help ensure that only authorized personnel with elevated privileges can execute system-modifying operations.

## Remote Access Features (WRM/SSH)

The toolkit provides manual remote access capabilities via Windows Remote Management (WRM) and SSH. These features:

- **Do NOT execute automated changes** — the tool provides a connection interface only
- **Require manual user action** — any commands or changes are typed and executed by the user
- **Are pass-through connections** — the toolkit does not modify, intercept, or log commands

When using remote access features, **you are directly connected to the target system**. Any changes you make are your responsibility, identical to connecting via a standard terminal or remote desktop session.

## No Warranty

This software is provided **"AS IS"** without warranty of any kind, express or implied. See [LICENSE](LICENSE) for complete terms.

## Audit Scripts (Read-Only)

Audit scripts inspect your system configuration and report findings. They:

- ✅ Do NOT modify any files
- ✅ Do NOT change any settings
- ✅ Do NOT install or remove software
- ✅ Do NOT affect system operation

Audit scripts are designed to be safe for production environments.

## ⚠️ Remediation Scripts (System Modification)

**CRITICAL WARNING:** Remediation scripts in the `fix/` directory **WILL MODIFY YOUR SYSTEM**.

### Before Running ANY Fix Script:

1. **TEST IN NON-PRODUCTION FIRST**
   - Always test in a development or staging environment
   - Never run untested fixes in production

2. **REVIEW THE SCRIPT**
   - Read the script to understand what changes it makes
   - Verify the changes are appropriate for your environment

3. **BACKUP YOUR SYSTEM**
   - Create full system backups before applying fixes
   - Ensure you can restore if something goes wrong

4. **USE DRY-RUN MODE**
   - Most fix scripts support `--dry-run` or `DRY_RUN=true`
   - Review proposed changes before applying

5. **HAVE A ROLLBACK PLAN**
   - Know how to undo each change
   - Keep backup configurations accessible

### What Fix Scripts May Modify:

- System configuration files (`/etc/*`)
- Service configurations
- Firewall rules
- User permissions and access controls
- SSH settings
- Kernel parameters
- Security policies (SELinux, AppArmor)

### Potential Consequences of Fix Scripts:

- Loss of remote access (SSH lockout)
- Service disruptions
- Application failures
- Network connectivity issues
- Authentication problems
- Data access restrictions

## User Responsibility

By using this software, you acknowledge and accept that:

1. **You are responsible for testing** all scripts in your environment
2. **You are responsible for backups** before making changes
3. **You are responsible for understanding** what changes will be made
4. **You are responsible for compliance** with your organization's change management policies
5. **You are responsible for rollback** if changes cause problems

## Not Professional Advice

This tool does not constitute professional security advice. For:

- Regulatory compliance requirements
- Critical infrastructure security
- Contractual security obligations

Consult qualified security professionals.

## Limitation of Liability

**THE DEVELOPER(S), CONTRIBUTOR(S), AND COPYRIGHT HOLDER(S) ASSUME NO LIABILITY WHATSOEVER FOR:**

- System damage, corruption, or data loss from running any scripts
- Service outages or disruptions caused by configuration changes
- Security incidents, breaches, or vulnerabilities resulting from improper use or remediation
- Compliance failures from incomplete, incorrect, or misapplied fixes
- Business losses, revenue loss, or costs from system unavailability
- Loss of access to systems (including SSH/RDP lockouts)
- Any direct, indirect, incidental, special, consequential, or punitive damages
- Any actions taken based on audit results or recommendations
- Any use of remote access features (SSH/WinRM) and commands executed therein
- Any use of advanced features including but not limited to: fix scripts, remediation automation, scheduled tasks, batch operations, or API integrations

**THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.**

**MAXIMUM LIABILITY:** In jurisdictions that do not allow complete exclusion of liability, maximum liability is limited to the license fees paid (if any), or $0 for the free tier.

## Indemnification

You agree to indemnify, defend, and hold harmless the developer(s), contributor(s), and copyright holder(s) from and against any claims, damages, losses, liabilities, costs, and expenses (including reasonable attorneys' fees) arising from:

- Your use or misuse of the software
- Your violation of any applicable laws or regulations
- Any changes you make to systems using this software
- Your failure to maintain adequate backups
- Your failure to test changes in non-production environments first

## Environments Where Extra Caution is Required

Exercise extreme caution when using fix scripts in:

- ❌ Production servers with live traffic
- ❌ Systems without recent backups
- ❌ Environments with strict change control requirements
- ❌ Systems you are not authorized to modify
- ❌ Infrastructure serving critical business functions

## Recommended Workflow

```
1. Run AUDIT scripts → Review findings
                           ↓
2. Prioritize issues → Determine what needs fixing
                           ↓
3. TEST fix scripts → In non-production environment
                           ↓
4. Create backups → Full system backup
                           ↓
5. Run with DRY-RUN → Verify proposed changes
                           ↓
6. Apply fix → With change management approval
                           ↓
7. Verify → Confirm fix worked as expected
                           ↓
8. Document → Record changes made
```

## Acceptance

**By downloading, installing, or using this software, you acknowledge that you have read, understood, and agree to this disclaimer.**

If you do not agree to these terms, do not use the remediation (fix) scripts.

---

*Last updated: March 2026*
