// Dashboard widgets and charts for Reports tab
// Requires Chart.js library
// Enhanced with real data binding - February 10, 2026

/**
 * Escape HTML special characters to prevent XSS attacks
 * @param {string} str - Input string
 * @returns {string} Escaped string safe for innerHTML
 */
function escapeHtmlDashboard(str) {
    if (str === null || str === undefined) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
}

document.addEventListener('DOMContentLoaded', function() {
    // Dashboard customization is now opt-in only
    // The Reports tab has static content (health report, report generator)
    // This script only activates if user explicitly clicks "Customize Dashboard"
    const customizeBtn = document.getElementById('customize-dashboard-btn');
    if (customizeBtn) {
        customizeBtn.addEventListener('click', initDashboardCustomization);
    }
});

// Dashboard state
let dashboardState = {
    layout: null,
    widgets: [],
    refreshIntervals: {},
    apiKey: null
};

async function initDashboardCustomization() {
    // Get API key from page or session
    dashboardState.apiKey = document.querySelector('meta[name="api-key"]')?.content || 'default-key';
    
    // Try to load user's default layout
    try {
        const layouts = await fetchAPI('/api/dashboard/layouts');
        if (layouts.success && layouts.layouts.length > 0) {
            const defaultLayout = layouts.layouts.find(l => l.is_default) || layouts.layouts[0];
            await loadLayout(defaultLayout.id);
        } else {
            // Show template selector in a modal, not replacing the whole tab
            showLayoutSelectorModal();
        }
    } catch (e) {
        console.warn('Dashboard layouts not available:', e);
        alert('Dashboard customization is not available. Using default reports view.');
    }
}

// Legacy function - kept for backward compatibility
async function initDashboard() {
    // Do nothing - we don't auto-initialize anymore
    console.log('Dashboard: Using static reports view by default');
}

/**
 * Show layout selector in a modal (doesn't replace tab content)
 */
function showLayoutSelectorModal() {
    // Create modal if it doesn't exist
    let modal = document.getElementById('dashboard-layout-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'dashboard-layout-modal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Choose a Dashboard Layout</h3>
                    <button class="modal-close" onclick="closeDashboardModal()">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="layout-templates" id="modal-layout-templates">
                        <div class="template-card" data-template="overview">
                            <h4>📊 Overview Dashboard</h4>
                            <p>General system overview with key metrics</p>
                        </div>
                        <div class="template-card" data-template="operations">
                            <h4>⚙️ Operations Dashboard</h4>
                            <p>Focus on audit execution and scheduling</p>
                        </div>
                        <div class="template-card" data-template="compliance">
                            <h4>🛡️ Compliance Dashboard</h4>
                            <p>Compliance status and findings tracking</p>
                        </div>
                        <div class="template-card" data-template="server_health">
                            <h4>🖥️ Server Health Dashboard</h4>
                            <p>Server-centric health monitoring</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        
        // Add click handlers
        modal.querySelectorAll('.template-card').forEach(card => {
            card.addEventListener('click', async () => {
                const template = card.dataset.template;
                try {
                    const response = await fetchAPI('/api/dashboard/layouts', {
                        method: 'POST',
                        body: JSON.stringify({ template, name: `My ${template} Dashboard` })
                    });
                    if (response.success) {
                        closeDashboardModal();
                        await loadLayout(response.layout.id);
                    }
                } catch (e) {
                    console.error('Failed to create layout:', e);
                    alert('Failed to create dashboard layout');
                }
            });
        });
    }
    
    modal.classList.remove('d-none');
    modal.style.display = 'flex';
}

function closeDashboardModal() {
    const modal = document.getElementById('dashboard-layout-modal');
    if (modal) {
        modal.classList.add('d-none');
        modal.style.display = 'none';
    }
}

async function loadLayout(layoutId) {
    try {
        const response = await fetchAPI(`/api/dashboard/layouts/${layoutId}`);
        if (response.success) {
            dashboardState.layout = response.layout;
            dashboardState.widgets = response.layout.widgets || [];
            renderDashboard();
        }
    } catch (e) {
        console.error('Failed to load layout:', e);
        renderStaticDashboard();
    }
}

function renderLayoutSelector() {
    const container = document.getElementById('reports-tab');
    container.innerHTML = `
        <div class="layout-selector">
            <h3>Choose a Dashboard Layout</h3>
            <div class="layout-templates" id="layout-templates">
                <div class="template-card" data-template="overview">
                    <h4>📊 Overview Dashboard</h4>
                    <p>General system overview with key metrics</p>
                </div>
                <div class="template-card" data-template="operations">
                    <h4>⚙️ Operations Dashboard</h4>
                    <p>Focus on audit execution and scheduling</p>
                </div>
                <div class="template-card" data-template="compliance">
                    <h4>🛡️ Compliance Dashboard</h4>
                    <p>Compliance status and findings tracking</p>
                </div>
                <div class="template-card" data-template="server_health">
                    <h4>🖥️ Server Health Dashboard</h4>
                    <p>Server-centric health monitoring</p>
                </div>
            </div>
        </div>
    `;
    
    document.querySelectorAll('.template-card').forEach(card => {
        card.addEventListener('click', async () => {
            const template = card.dataset.template;
            try {
                const response = await fetchAPI('/api/dashboard/layouts', {
                    method: 'POST',
                    body: JSON.stringify({ template, name: `My ${template} Dashboard` })
                });
                if (response.success) {
                    await loadLayout(response.layout.id);
                }
            } catch (e) {
                console.error('Failed to create layout:', e);
            }
        });
    });
}

function renderDashboard() {
    const container = document.getElementById('reports-tab');
    const layout = dashboardState.layout;
    const layoutName = (layout?.name || '').toLowerCase();
    const showHeaderDiskBadge = layoutName.includes('overview');
    
    container.innerHTML = `
        <div class="dashboard-header">
            <h3>
                ${layout.name}
                ${showHeaderDiskBadge ? '<span id="disk-watermark-header-badge" class="badge badge-info">Disk: loading...</span>' : ''}
            </h3>
            <div class="dashboard-controls">
                <button class="btn btn-sm" onclick="refreshAllWidgets()">
                    <span class="icon">🔄</span> Refresh All
                </button>
                <button class="btn btn-sm" onclick="openWidgetPicker()">
                    <span class="icon">➕</span> Add Widget
                </button>
            </div>
        </div>
        <div class="dashboard-grid" id="dashboard-grid" 
             style="display: grid; grid-template-columns: repeat(${layout.grid?.columns || 4}, 1fr); gap: 16px;">
        </div>
    `;
    
    const grid = document.getElementById('dashboard-grid');
    
    // Sort widgets by position
    const widgets = [...dashboardState.widgets].sort((a, b) => {
        if (a.position.y !== b.position.y) return a.position.y - b.position.y;
        return a.position.x - b.position.x;
    });
    
    // Render each widget
    widgets.forEach(widget => {
        const widgetEl = createWidgetElement(widget);
        grid.appendChild(widgetEl);
        loadWidgetData(widget.id);
        
        // Set up refresh interval
        if (widget.refresh_interval > 0) {
            dashboardState.refreshIntervals[widget.id] = setInterval(
                () => loadWidgetData(widget.id),
                widget.refresh_interval * 1000
            );
        }
    });

    if (showHeaderDiskBadge) {
        refreshDiskWatermarkHeaderBadge();
    }
}

async function refreshDiskWatermarkHeaderBadge() {
    const badge = document.getElementById('disk-watermark-header-badge');
    if (!badge) return;

    badge.style.cursor = 'pointer';
    badge.title = 'Jump to storage pressure widget';
    badge.onclick = focusStoragePressureWidget;

    try {
        const response = await fetchAPI('/api/dashboard/storage-pressure');
        const disk = response?.storage_pressure?.disk_watermark || {};

        badge.className = 'badge badge-info';
        if (disk.enabled === false) {
            badge.className = 'badge badge-info';
            badge.textContent = 'Disk Guard: disabled';
            return;
        }

        if (disk.ingest_blocked) {
            badge.className = 'badge badge-error';
            badge.textContent = `Disk Guard: blocked (${disk.free_mb ?? 0}MB)`;
            return;
        }

        if (disk.level === 'warning') {
            badge.className = 'badge badge-warning';
            badge.textContent = `Disk Guard: warning (${disk.free_mb ?? 0}MB)`;
            return;
        }

        badge.className = 'badge badge-success';
        badge.textContent = `Disk Guard: ok (${disk.free_mb ?? 0}MB)`;
    } catch (e) {
        badge.className = 'badge badge-warning';
        badge.textContent = 'Disk Guard: unavailable';
    }
}

function createWidgetElement(widget) {
    const el = document.createElement('div');
    el.className = 'dashboard-widget';
    el.id = `widget-${widget.id}`;
    el.dataset.widgetType = widget.widget_type || '';
    el.style.gridColumn = `span ${widget.position.w}`;
    el.style.gridRow = `span ${widget.position.h}`;
    
    el.innerHTML = `
        <div class="widget-header">
            <h4>${widget.title}</h4>
            <div class="widget-actions">
                <button class="btn-icon" onclick="loadWidgetData(${widget.id})" title="Refresh">🔄</button>
                <button class="btn-icon" onclick="editWidget(${widget.id})" title="Edit">⚙️</button>
            </div>
        </div>
        <div class="widget-content" id="widget-content-${widget.id}">
            <div class="loading-spinner">Loading...</div>
        </div>
    `;
    
    return el;
}

function focusStoragePressureWidget() {
    const target = document.querySelector('.dashboard-widget[data-widget-type="storage_pressure"]');
    if (!target) {
        return;
    }

    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    const originalTransition = target.style.transition;
    const originalOutline = target.style.outline;
    target.style.transition = 'outline 0.2s ease';
    target.style.outline = '2px solid rgba(59, 130, 246, 0.9)';
    setTimeout(() => {
        target.style.outline = originalOutline;
        target.style.transition = originalTransition;
    }, 1200);
}

async function loadWidgetData(widgetId) {
    const widget = dashboardState.widgets.find(w => w.id === widgetId);
    if (!widget) return;
    
    const contentEl = document.getElementById(`widget-content-${widgetId}`);
    if (!contentEl) return;
    
    try {
        const response = await fetchAPI(`/api/dashboard/widgets/${widgetId}/data`);
        if (response.success) {
            renderWidgetContent(widget, response.data, contentEl);
        }
    } catch (e) {
        contentEl.innerHTML = `<div class="widget-error">Failed to load data</div>`;
    }
}

function renderWidgetContent(widget, data, contentEl) {
    switch (widget.widget_type) {
        case 'stat_card':
            renderStatCard(data, contentEl);
            break;
        case 'trend_chart':
            renderTrendChart(data, contentEl, widget);
            break;
        case 'recent_executions':
            renderRecentExecutions(data, contentEl);
            break;
        case 'top_risks':
            renderTopRisks(data, contentEl);
            break;
        case 'domain_breakdown':
            renderDomainBreakdown(data, contentEl, widget);
            break;
        case 'compliance_gauge':
            renderComplianceGauge(data, contentEl);
            break;
        case 'server_group_status':
            renderServerGroupStatus(data, contentEl);
            break;
        case 'schedule_timeline':
            renderScheduleTimeline(data, contentEl);
            break;
        case 'server_health_map':
            renderServerHealthMap(data, contentEl);
            break;
        case 'critical_findings':
            renderCriticalFindings(data, contentEl);
            break;
        case 'storage_pressure':
            renderStoragePressure(data, contentEl);
            break;
        default:
            contentEl.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
    }
}

function renderStatCard(data, el) {
    const color = data.color || '#3498db';
    const icon = data.icon || 'chart-bar';
    const iconMap = {
        'server': '🖥️',
        'file-text': '📄',
        'check-circle': '✅',
        'x-circle': '❌',
        'chart-bar': '📊',
        'clock': '⏱️'
    };
    
    el.innerHTML = `
        <div class="stat-card" style="border-left: 4px solid ${color}">
            <div class="stat-icon">${iconMap[icon] || '📈'}</div>
            <div class="stat-value" style="color: ${color}">${data.value}</div>
            <div class="stat-label">${data.title || data.metric}</div>
        </div>
    `;
}

function renderTrendChart(data, el, widget) {
    const canvasId = `chart-${widget.id}`;
    el.innerHTML = `<canvas id="${canvasId}"></canvas>`;
    
    if (window.Chart) {
        const ctx = document.getElementById(canvasId).getContext('2d');
        new Chart(ctx, {
            type: widget.config?.chart_type || 'line',
            data: {
                labels: data.labels,
                datasets: Object.keys(data.datasets).map((key, i) => ({
                    label: key.replace('_', ' '),
                    data: data.datasets[key],
                    borderColor: ['#27ae60', '#f39c12', '#e74c3c'][i % 3],
                    backgroundColor: ['rgba(39,174,96,0.1)', 'rgba(243,156,18,0.1)', 'rgba(231,76,60,0.1)'][i % 3],
                    fill: true
                }))
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
}

function renderRecentExecutions(data, el) {
    if (!data.executions || data.executions.length === 0) {
        el.innerHTML = '<p class="no-data">No recent executions</p>';
        return;
    }
    
    el.innerHTML = `
        <table class="widget-table">
            <thead>
                <tr>
                    <th>Server</th>
                    <th>Audit</th>
                    <th>Status</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                ${data.executions.map(e => `
                    <tr>
                        <td>${escapeHtmlDashboard(e.server_name)}</td>
                        <td>${escapeHtmlDashboard(e.audit_name)}</td>
                        <td class="status-${e.exit_code === 0 ? 'pass' : 'fail'}">
                            ${e.exit_code === 0 ? '✅' : '❌'}
                        </td>
                        <td>${formatTime(e.executed_at)}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function renderTopRisks(data, el) {
    if (!data.risks || data.risks.length === 0) {
        el.innerHTML = '<p class="no-data">No risks found</p>';
        return;
    }
    
    el.innerHTML = `
        <ul class="risk-list">
            ${data.risks.map(r => `
                <li class="risk-item severity-${escapeHtmlDashboard(r.severity)}">
                    <span class="risk-icon">⚠️</span>
                    <div class="risk-details">
                        <strong>${escapeHtmlDashboard(r.message)}</strong>
                        <small>${escapeHtmlDashboard(r.server)} | ${escapeHtmlDashboard(r.audit)}</small>
                    </div>
                </li>
            `).join('')}
        </ul>
    `;
}

function renderDomainBreakdown(data, el, widget) {
    const canvasId = `chart-${widget.id}`;
    el.innerHTML = `<canvas id="${canvasId}"></canvas>`;
    
    if (window.Chart) {
        const ctx = document.getElementById(canvasId).getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: [
                        '#3498db', '#2ecc71', '#f39c12', '#e74c3c', 
                        '#9b59b6', '#1abc9c', '#34495e'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'right' } }
            }
        });
    }
}

function renderComplianceGauge(data, el) {
    const score = data.score || 0;
    const status = data.status || 'unknown';
    const colorMap = { good: '#27ae60', warning: '#f39c12', critical: '#e74c3c' };
    
    el.innerHTML = `
        <div class="compliance-gauge">
            <div class="gauge-circle" style="--score: ${score}; --color: ${colorMap[status]}">
                <span class="gauge-value">${score}%</span>
            </div>
            <div class="gauge-label">${data.framework?.toUpperCase() || 'Overall'}</div>
            <div class="gauge-status status-${status}">${status}</div>
        </div>
    `;
}

function renderServerGroupStatus(data, el) {
    if (data.error) {
        el.innerHTML = `<div class="widget-error">${data.error}</div>`;
        return;
    }
    
    const statusColor = { healthy: '#27ae60', warning: '#f39c12', critical: '#e74c3c' };
    
    el.innerHTML = `
        <div class="group-status" style="border-color: ${data.color || '#3498db'}">
            <h5>${data.group_name}</h5>
            <div class="group-stats">
                <div class="stat">
                    <span class="value">${data.server_count}</span>
                    <span class="label">Servers</span>
                </div>
                <div class="stat">
                    <span class="value">${data.pass_rate}%</span>
                    <span class="label">Pass Rate</span>
                </div>
            </div>
            <div class="status-badge" style="background: ${statusColor[data.status]}">
                ${data.status}
            </div>
        </div>
    `;
}

function renderScheduleTimeline(data, el) {
    if (!data.events || data.events.length === 0) {
        el.innerHTML = '<p class="no-data">No upcoming events</p>';
        return;
    }
    
    el.innerHTML = `
        <div class="timeline">
            ${data.events.map(e => `
                <div class="timeline-event event-${e.type}">
                    <span class="event-time">${formatTime(e.scheduled_at || e.start)}</span>
                    <span class="event-name">${e.name}</span>
                    ${e.server ? `<span class="event-server">${e.server}</span>` : ''}
                </div>
            `).join('')}
        </div>
    `;
}

function renderServerHealthMap(data, el) {
    el.innerHTML = `
        <div class="health-summary">
            <span class="pass">✅ ${data.summary.pass}</span>
            <span class="fail">❌ ${data.summary.fail}</span>
            <span class="unknown">❓ ${data.summary.unknown}</span>
        </div>
        <div class="health-grid">
            ${data.servers.map(s => `
                <div class="server-tile status-${s.status}" title="${s.name}\n${s.hostname}">
                    ${s.name.substring(0, 8)}
                </div>
            `).join('')}
        </div>
    `;
}

function renderCriticalFindings(data, el) {
    const alertClass = data.alert ? 'alert-active' : 'alert-inactive';
    
    el.innerHTML = `
        <div class="critical-counter ${alertClass}">
            <div class="counter-value">${data.count}</div>
            <div class="counter-label">Critical Findings</div>
            ${data.alert ? '<div class="alert-badge">⚠️ ALERT</div>' : ''}
        </div>
    `;
}

function renderStoragePressure(data, el) {
    const levelClass = `status-${data.overall_level || 'ok'}`;
    const db = data.database || {};
    const agent = data.agent_results || {};
    const disk = data.disk_watermark || {};

    const dbPct = (db.usage_pct === null || db.usage_pct === undefined)
        ? 'unbounded'
        : `${db.usage_pct}%`;

    const topStandalone = (agent.top_standalone_hosts || []).slice(0, 3);

    el.innerHTML = `
        <div class="storage-pressure ${levelClass}">
            <div class="storage-overall">Overall: <strong>${escapeHtmlDashboard(data.overall_level || 'ok')}</strong></div>
            <div class="storage-metrics">
                <div><span>DB Records:</span> <strong>${db.count ?? 0}</strong></div>
                <div><span>DB Usage:</span> <strong>${dbPct}</strong></div>
                <div><span>Agent Files:</span> <strong>${agent.total_files ?? 0}</strong></div>
                <div><span>Hosts:</span> <strong>${agent.hosts_total ?? 0}</strong></div>
            </div>
            <div class="storage-metrics">
                <div><span>Disk Free:</span> <strong>${disk.free_mb ?? 0} MB (${disk.free_pct ?? 0}%)</strong></div>
                <div><span>Ingest Guard:</span> <strong>${disk.enabled === false ? 'disabled' : (disk.ingest_blocked ? 'blocked' : 'ok')}</strong></div>
            </div>
            ${topStandalone.length > 0 ? `
                <div class="storage-top-hosts">
                    <div class="label">Top Host Pressure</div>
                    <ul>
                        ${topStandalone.map(h => `<li>${escapeHtmlDashboard(h.host)}: ${h.usage_pct ?? 0}%</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
        </div>
    `;
}

// Helper functions
async function fetchAPI(url, options = {}) {
    const response = await fetch(url, {
        ...options,
        headers: {
            'Content-Type': 'application/json',
            'X-API-Key': dashboardState.apiKey,
            ...options.headers
        }
    });
    return response.json();
}

function formatTime(isoString) {
    if (!isoString) return '-';
    const date = new Date(isoString);
    return date.toLocaleString();
}

function refreshAllWidgets() {
    dashboardState.widgets.forEach(w => loadWidgetData(w.id));
    refreshDiskWatermarkHeaderBadge();
}

async function openWidgetPicker() {
    // Widget picker modal implementation
    const types = await fetchAPI('/api/dashboard/widget-types');
    if (!types.success) return;
    
    const modal = document.createElement('div');
    modal.className = 'modal widget-picker-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <h3>Add Widget</h3>
            <div class="widget-type-grid">
                ${types.widget_types.map(t => `
                    <div class="widget-type-card" data-type="${t.type}">
                        <div class="type-icon">${getTypeIcon(t.icon)}</div>
                        <div class="type-name">${t.name}</div>
                        <div class="type-desc">${t.description}</div>
                    </div>
                `).join('')}
            </div>
            <button class="btn" onclick="this.closest('.modal').remove()">Cancel</button>
        </div>
    `;
    document.body.appendChild(modal);
    
    modal.querySelectorAll('.widget-type-card').forEach(card => {
        card.addEventListener('click', async () => {
            const type = card.dataset.type;
            await addWidget(type);
            modal.remove();
        });
    });
}

async function addWidget(widgetType) {
    if (!dashboardState.layout) return;
    
    try {
        const response = await fetchAPI(`/api/dashboard/layouts/${dashboardState.layout.id}/widgets`, {
            method: 'POST',
            body: JSON.stringify({
                widget_type: widgetType,
                position: { x: 0, y: 99, w: 1, h: 1 }  // Add at bottom
            })
        });
        
        if (response.success) {
            dashboardState.widgets.push(response.widget);
            await loadLayout(dashboardState.layout.id);  // Refresh
        }
    } catch (e) {
        console.error('Failed to add widget:', e);
    }
}

function editWidget(widgetId) {
    // Widget edit modal - simplified implementation
    const widget = dashboardState.widgets.find(w => w.id === widgetId);
    if (!widget) return;
    
    const modal = document.createElement('div');
    modal.className = 'modal widget-edit-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <h3>Edit Widget</h3>
            <label>Title: <input type="text" id="widget-title" value="${widget.title || ''}"></label>
            <label>Refresh (sec): <input type="number" id="widget-refresh" value="${widget.refresh_interval || 60}"></label>
            <div class="modal-actions">
                <button class="btn btn-danger" onclick="deleteWidget(${widgetId}); this.closest('.modal').remove()">Delete</button>
                <button class="btn" onclick="this.closest('.modal').remove()">Cancel</button>
                <button class="btn btn-primary" onclick="saveWidget(${widgetId}); this.closest('.modal').remove()">Save</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

async function saveWidget(widgetId) {
    const title = document.getElementById('widget-title')?.value;
    const refresh = parseInt(document.getElementById('widget-refresh')?.value || 60);
    
    try {
        await fetchAPI(`/api/dashboard/widgets/${widgetId}`, {
            method: 'PUT',
            body: JSON.stringify({ title, refresh_interval: refresh })
        });
        await loadLayout(dashboardState.layout.id);
    } catch (e) {
        console.error('Failed to save widget:', e);
    }
}

async function deleteWidget(widgetId) {
    try {
        await fetchAPI(`/api/dashboard/widgets/${widgetId}`, { method: 'DELETE' });
        await loadLayout(dashboardState.layout.id);
    } catch (e) {
        console.error('Failed to delete widget:', e);
    }
}

function getTypeIcon(iconName) {
    const icons = {
        'chart-bar': '📊', 'server': '🖥️', 'shield-check': '🛡️', 'trending-up': '📈',
        'clock': '⏱️', 'alert-triangle': '⚠️', 'pie-chart': '🥧', 'calendar': '📅',
        'tool': '🔧', 'activity': '📉', 'grid': '📋', 'alert-octagon': '🚨', 'hard-drive': '💾'
    };
    return icons[iconName] || '📦';
}

// Fallback static dashboard (when API not available)
function renderStaticDashboard() {
    const dashboard = document.createElement('div');
    dashboard.className = 'dashboard-widgets';
    dashboard.innerHTML = `
        <div class="dashboard-row">
            <div class="dashboard-widget">
                <h4>Top Risks</h4>
                <ul id="top-risks-list"></ul>
            </div>
            <div class="dashboard-widget">
                <h4>Audit Coverage</h4>
                <canvas id="coverage-chart" width="200" height="200"></canvas>
            </div>
            <div class="dashboard-widget">
                <h4>Recent Failures</h4>
                <ul id="recent-failures-list"></ul>
            </div>
        </div>
        <div class="dashboard-row">
            <div class="dashboard-widget">
                <h4>Compliance Score</h4>
                <canvas id="compliance-chart" width="200" height="200"></canvas>
            </div>
            <div class="dashboard-widget">
                <h4>Risk Heatmap</h4>
                <canvas id="heatmap-chart" width="200" height="200"></canvas>
            </div>
        </div>
    `;
    const reportsTab = document.getElementById('reports-tab');
    reportsTab.insertBefore(dashboard, reportsTab.firstChild);

    renderStaticCoverageChart();
    renderStaticComplianceChart();
    loadStaticTopRisks();
    loadStaticRecentFailures();
}

function renderStaticCoverageChart() {
    if (window.Chart) {
        const ctx = document.getElementById('coverage-chart')?.getContext('2d');
        if (ctx) {
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Platform', 'Web', 'Data', 'Apps', 'Advanced'],
                    datasets: [{
                        data: [20, 15, 10, 25, 5],
                        backgroundColor: ['#4f46e5', '#10b981', '#f59e42', '#ef4444', '#6366f1']
                    }]
                },
                options: {responsive: false}
            });
        }
    }
}

function renderStaticComplianceChart() {
    if (window.Chart) {
        const ctx = document.getElementById('compliance-chart')?.getContext('2d');
        if (ctx) {
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['CIS', 'PCI', 'HIPAA', 'NIST'],
                    datasets: [{
                        label: 'Compliance %',
                        data: [85, 70, 60, 90],
                        backgroundColor: ['#10b981', '#f59e42', '#ef4444', '#6366f1']
                    }]
                },
                options: {responsive: false}
            });
        }
    }
}

function loadStaticTopRisks() {
    const el = document.getElementById('top-risks-list');
    if (el) el.innerHTML = '<li>SSH root login enabled</li><li>Firewall disabled</li><li>Unpatched OS</li>';
}

function loadStaticRecentFailures() {
    const el = document.getElementById('recent-failures-list');
    if (el) el.innerHTML = '<li>Web server misconfiguration</li><li>Database weak password</li>';
}
