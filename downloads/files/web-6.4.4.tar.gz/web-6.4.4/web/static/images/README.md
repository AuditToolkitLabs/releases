# Security Stock Images

Place security-themed stock images in this folder for use on the home page.

## Recommended Images

Download high-quality, royalty-free security images from:
- https://unsplash.com/s/photos/cybersecurity
- https://www.pexels.com/search/cyber%20security/
- https://pixabay.com/images/search/cybersecurity/

## Suggested Filenames

- `hero-bg.jpg` - Main background image (1920x1080 or larger)
- `security-pattern.png` - Subtle pattern overlay (optional)

## Recommended Themes

- Server racks with blue lighting
- Digital lock/shield icons
- Network connection visualization
- Dark tech aesthetic with accent colors (blue, green, cyan)

## Image Specifications

| Property | Recommendation |
|----------|----------------|
| Format | JPEG (photos) or PNG (graphics) |
| Resolution | 1920x1080 minimum |
| File Size | Under 500KB for web performance |
| Aspect Ratio | 16:9 for hero backgrounds |

## Current Default

The home page uses a CSS gradient fallback when no image is present.
To enable the background image, add `hero-bg.jpg` to this folder.
