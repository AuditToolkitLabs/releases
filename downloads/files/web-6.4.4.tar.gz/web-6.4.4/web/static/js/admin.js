/**
 * Admin Page JavaScript
 * Handles administration dashboard functionality
 */

// ============================================
// Toast Notification System
// ============================================
function showToast(message, type = 'info') {
    if (document.body) {
        document.body.dataset.lastToastMessage = message;
        document.body.dataset.lastToastType = type;
        document.body.dataset.lastToastTimestamp = String(Date.now());
    }

    // Remove existing toast if any
    const existingToast = document.querySelector('.admin-toast');
    if (existingToast) {
        existingToast.remove();
    }

    // Create toast element
    const toast = document.createElement('div');
    toast.className = `admin-toast admin-toast-${type}`;

    // Set icon based on type
    const icons = {
        'success': '✓',
        'error': '✗',
        'warning': '⚠',
        'info': 'ℹ'
    };
    const icon = icons[type] || icons['info'];

    toast.innerHTML = `
        <span class="admin-toast-icon">${icon}</span>
        <span class="admin-toast-message">${escapeHtml(message)}</span>
        <button class="admin-toast-close" onclick="this.parentElement.remove()">×</button>
    `;

    // Add styles if not already present
    if (!document.getElementById('admin-toast-styles')) {
        const style = document.createElement('style');
        style.id = 'admin-toast-styles';
        style.textContent = `
            .admin-toast {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 12px 16px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                gap: 10px;
                min-width: 280px;
                max-width: 450px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                z-index: 10000;
                animation: slideIn 0.3s ease;
                font-size: 0.9rem;
            }
            .admin-toast-success { background: #10b981; color: white; }
            .admin-toast-error { background: #ef4444; color: white; }
            .admin-toast-warning { background: #f59e0b; color: white; }
            .admin-toast-info { background: #3b82f6; color: white; }
            .admin-toast-icon { font-size: 1.2rem; flex-shrink: 0; }
            .admin-toast-message { flex: 1; }
            .admin-toast-close {
                background: none;
                border: none;
                color: inherit;
                font-size: 1.3rem;
                cursor: pointer;
                padding: 0;
                opacity: 0.8;
            }
            .admin-toast-close:hover { opacity: 1; }
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }

    // Add to document
    document.body.appendChild(toast);

    const logFn = type === 'error' ? console.error : console.log;
    logFn(`[${type.toUpperCase()}] ${message}`);

    // Auto-remove after delay
    const duration = type === 'error' ? 6000 : 4000;
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.animation = 'slideIn 0.3s ease reverse';
            setTimeout(() => toast.remove(), 300);
        }
    }, duration);
}

// XSS prevention helper
function escapeHtml(unsafe) {
    if (unsafe == null) return '';
    const div = document.createElement('div');
    div.textContent = String(unsafe);
    return div.innerHTML;
}

// Get CSRF token from meta tag or fetch from API
let cachedCsrfToken = null;

function getCsrfToken() {
    // First check meta tag
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta && meta.content) {
        return meta.content;
    }
    // Return cached token if available
    return cachedCsrfToken || '';
}

// Initialize CSRF token on page load
async function initCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (!meta || !meta.content) {
        try {
            const response = await fetch('/auth/csrf-token', { credentials: 'include' });
            const data = await response.json();
            cachedCsrfToken = data.csrf_token;
            // Update meta tag if exists
            if (meta) meta.content = cachedCsrfToken;
        } catch (error) {
            console.warn('Failed to fetch CSRF token:', error);
        }
    }
}

// Wrapper for fetch that includes session credentials and CSRF token
async function adminFetch(url, options = {}) {
    const csrfToken = getCsrfToken();
    const headers = { ...(options.headers || {}) };
    const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
    if (apiKey && !headers['X-API-Key']) {
        headers['X-API-Key'] = apiKey;
    }

    // Add CSRF token for state-changing requests
    if (options.method && ['POST', 'PUT', 'DELETE', 'PATCH'].includes(options.method.toUpperCase())) {
        if (csrfToken) {
            headers['X-CSRFToken'] = csrfToken;
        }
        if (!headers['Content-Type']) {
            headers['Content-Type'] = 'application/json';
        }
    }

    const response = await fetch(url, {
        ...options,
        credentials: 'include',
        headers
    });

    // Check if response is a redirect to login page (session expired)
    if (response.redirected && response.url.includes('/login')) {
        showToast('Session expired. Please refresh and log in again.', 'warning');
        throw new Error('Session expired');
    }

    return response;
}

// Helper to safely parse JSON response
async function safeJsonParse(response) {
    const text = await response.text();
    try {
        return JSON.parse(text);
    } catch (e) {
        console.error('Failed to parse JSON:', text.substring(0, 200));
        // Check if it looks like an HTML page (login redirect or error page)
        if (text.includes('<!DOCTYPE') || text.includes('<html')) {
            throw new Error('Server returned HTML instead of JSON - you may need to log in again');
        }
        throw new Error('Invalid server response');
    }
}

// State
let apiKeyVisible = false;
let currentApiKey = '';
let securitySettingsDirty = false;
let loadedSecuritySettings = {};

// ============================================
// Initialization
// ============================================
async function initAdmin() {
    // Setup event listeners FIRST so UI is immediately interactive
    setupEventListeners();

    // Initialize CSRF token (quick, needed for API calls)
    await initCsrfToken();

    // Check user role and hide SuperAdmin-only elements
    checkUserRoleVisibility();  // Don't await - let it run in background

    // Load data asynchronously - don't block UI interaction
    Promise.all([
        loadAdminStats(),
        loadBackups(),
        loadStorageDetails(),
        loadBackupSettings(),
        loadSystemInfo(),
        loadSettings(),
        loadUsers()
    ]).catch(err => console.error('Error loading admin data:', err));
}

async function checkUserRoleVisibility() {
    try {
        const response = await adminFetch('/auth/me');
        if (response.ok) {
            const data = await response.json();
            const userRole = data.user?.role || '';

            // Hide SuperAdmin-only elements for non-SuperAdmins
            const superAdminElements = document.querySelectorAll('.superadmin-only');
            const superAdminHeaders = document.querySelectorAll('.admin-nav-header.superadmin-only');

            if (userRole !== 'SuperAdmin') {
                superAdminElements.forEach(el => {
                    el.style.display = 'none';
                });
                // Hide the SuperAdmin Tools header(s)
                superAdminHeaders.forEach(header => {
                    header.style.display = 'none';
                });
                // Also hide the remote terminal panel and security panel
                const terminalPanel = document.getElementById('admin-panel-remote-terminal');
                if (terminalPanel) {
                    terminalPanel.style.display = 'none';
                }
                const securityPanel = document.getElementById('admin-panel-security');
                if (securityPanel) {
                    securityPanel.style.display = 'none';
                }
            }
        }
    } catch (error) {
        console.error('Failed to check user role:', error);
    }
}

function setupEventListeners() {
    // Refresh button
    const refreshBtn = document.getElementById('refresh-admin');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', initAdmin);
    }

    // API Key management
    const showKeyBtn = document.getElementById('admin-show-key');
    if (showKeyBtn) {
        showKeyBtn.addEventListener('click', toggleApiKeyVisibility);
    }

    const copyKeyBtn = document.getElementById('admin-copy-key');
    if (copyKeyBtn) {
        copyKeyBtn.addEventListener('click', copyApiKey);
    }

    const regenerateKeyBtn = document.getElementById('admin-regenerate-key');
    if (regenerateKeyBtn) {
        regenerateKeyBtn.addEventListener('click', regenerateApiKey);
    }

    // SSH Key Management
    initSSHKeysPanel();

    // API Keys Management
    initAPIKeysPanel();

    // Health check
    const healthCheckBtn = document.getElementById('admin-run-health-check');
    if (healthCheckBtn) {
        healthCheckBtn.addEventListener('click', loadHealthChecks);
    }

    // Email settings
    const emailEnabledCheckbox = document.getElementById('admin-email-enabled');
    if (emailEnabledCheckbox) {
        emailEnabledCheckbox.addEventListener('change', toggleEmailConfig);
    }

    const testEmailBtn = document.getElementById('admin-test-email');
    if (testEmailBtn) {
        testEmailBtn.addEventListener('click', sendTestEmail);
    }

    const saveEmailBtn = document.getElementById('admin-save-email');
    if (saveEmailBtn) {
        saveEmailBtn.addEventListener('click', saveEmailSettings);
    }

    // Backup management
    const createBackupBtn = document.getElementById('admin-create-backup');
    if (createBackupBtn) {
        createBackupBtn.addEventListener('click', openBackupModal);
    }

    // Backup modal buttons
    const closeBackupModalBtn = document.getElementById('close-backup-modal');
    if (closeBackupModalBtn) {
        closeBackupModalBtn.addEventListener('click', closeBackupModal);
    }

    const cancelBackupBtn = document.getElementById('cancel-backup-btn');
    if (cancelBackupBtn) {
        cancelBackupBtn.addEventListener('click', closeBackupModal);
    }

    const confirmBackupBtn = document.getElementById('confirm-backup-btn');
    if (confirmBackupBtn) {
        confirmBackupBtn.addEventListener('click', createBackupWithOptions);
    }

    // Backup encrypt checkbox toggle
    const backupEncryptCheckbox = document.getElementById('backup-encrypt');
    if (backupEncryptCheckbox) {
        backupEncryptCheckbox.addEventListener('change', function() {
            const passwordSection = document.getElementById('backup-password-section');
            if (passwordSection) {
                passwordSection.style.display = this.checked ? 'block' : 'none';
            }
        });
    }

    // Backup location select change
    const backupLocationSelect = document.getElementById('backup-location-select');
    if (backupLocationSelect) {
        backupLocationSelect.addEventListener('change', handleBackupLocationChange);
    }

    const cleanupBackupsBtn = document.getElementById('admin-cleanup-backups');
    if (cleanupBackupsBtn) {
        cleanupBackupsBtn.addEventListener('click', cleanupBackups);
    }

    // Backup Settings
    const saveBackupSettingsBtn = document.getElementById('save-backup-settings');
    if (saveBackupSettingsBtn) {
        saveBackupSettingsBtn.addEventListener('click', saveBackupSettings);
    }

    const resetBackupSettingsBtn = document.getElementById('reset-backup-settings');
    if (resetBackupSettingsBtn) {
        resetBackupSettingsBtn.addEventListener('click', resetBackupSettings);
    }

    const refreshStorageDetailsBtn = document.getElementById('refresh-storage-details');
    if (refreshStorageDetailsBtn) {
        refreshStorageDetailsBtn.addEventListener('click', loadStorageDetails);
    }

    // User Management
    const addUserBtn = document.getElementById('admin-add-user');
    if (addUserBtn) {
        addUserBtn.addEventListener('click', openAddUserModal);
    }

    const addUserForm = document.getElementById('add-user-form');
    if (addUserForm) {
        addUserForm.addEventListener('submit', handleAddUser);
    }

    const cancelAddUserBtn = document.getElementById('cancel-add-user');
    if (cancelAddUserBtn) {
        cancelAddUserBtn.addEventListener('click', closeAddUserModal);
    }

    const closeAddUserModalBtn = document.getElementById('close-add-user-modal');
    if (closeAddUserModalBtn) {
        closeAddUserModalBtn.addEventListener('click', closeAddUserModal);
    }

    // Edit User Modal event listeners
    const editUserForm = document.getElementById('edit-user-form');
    if (editUserForm) {
        editUserForm.addEventListener('submit', handleEditUser);
    }

    const cancelEditUserBtn = document.getElementById('cancel-edit-user');
    if (cancelEditUserBtn) {
        cancelEditUserBtn.addEventListener('click', closeEditUserModal);
    }

    const closeEditUserModalBtn = document.getElementById('close-edit-user-modal');
    if (closeEditUserModalBtn) {
        closeEditUserModalBtn.addEventListener('click', closeEditUserModal);
    }

    // Reset Password Modal event listeners
    const resetPasswordForm = document.getElementById('reset-password-form');
    if (resetPasswordForm) {
        resetPasswordForm.addEventListener('submit', handleResetPassword);
    }

    const cancelResetPasswordBtn = document.getElementById('cancel-reset-password');
    if (cancelResetPasswordBtn) {
        cancelResetPasswordBtn.addEventListener('click', closeResetPasswordModal);
    }

    const closeResetPasswordModalBtn = document.getElementById('close-reset-password-modal');
    if (closeResetPasswordModalBtn) {
        closeResetPasswordModalBtn.addEventListener('click', closeResetPasswordModal);
    }

    const configureLdapBtn = document.getElementById('admin-configure-ldap');
    if (configureLdapBtn) {
        configureLdapBtn.addEventListener('click', openLdapConfigModal);
    }

    const configureEntraBtn = document.getElementById('admin-configure-entra');
    if (configureEntraBtn) {
        configureEntraBtn.addEventListener('click', openEntraConfigModal);
    }

    // LDAP Modal buttons
    const closeLdapBtn = document.getElementById('close-ldap-modal');
    if (closeLdapBtn) closeLdapBtn.addEventListener('click', closeLdapConfigModal);
    const cancelLdapBtn = document.getElementById('cancel-ldap-btn');
    if (cancelLdapBtn) cancelLdapBtn.addEventListener('click', closeLdapConfigModal);
    const saveLdapBtn = document.getElementById('save-ldap-btn');
    if (saveLdapBtn) saveLdapBtn.addEventListener('click', saveLdapConfig);
    const testLdapBtn = document.getElementById('test-ldap-btn');
    if (testLdapBtn) testLdapBtn.addEventListener('click', testLdapConnection);

    // Entra Modal buttons
    const closeEntraBtn = document.getElementById('close-entra-modal');
    if (closeEntraBtn) closeEntraBtn.addEventListener('click', closeEntraConfigModal);
    const cancelEntraBtn = document.getElementById('cancel-entra-btn');
    if (cancelEntraBtn) cancelEntraBtn.addEventListener('click', closeEntraConfigModal);
    const saveEntraBtn = document.getElementById('save-entra-btn');
    if (saveEntraBtn) saveEntraBtn.addEventListener('click', saveEntraConfig);
    const testEntraBtn = document.getElementById('test-entra-btn');
    if (testEntraBtn) testEntraBtn.addEventListener('click', testEntraConfig);

    // LDAP security type changes port
    const ldapSecurity = document.getElementById('ldap-security');
    if (ldapSecurity) {
        ldapSecurity.addEventListener('change', () => {
            const portInput = document.getElementById('ldap-port');
            if (portInput) {
                portInput.value = ldapSecurity.value === 'ldaps' ? '636' : '389';
            }
        });
    }

    const userSearchInput = document.getElementById('admin-user-search');
    if (userSearchInput) {
        userSearchInput.addEventListener('input', debounce(filterUsers, 300));
    }

    // Security Settings (SuperAdmin only)
    const saveSecurityBtn = document.getElementById('save-security-settings');
    if (saveSecurityBtn) {
        saveSecurityBtn.addEventListener('click', saveSecuritySettings);
    }

    const resetSecurityBtn = document.getElementById('reset-security-settings');
    if (resetSecurityBtn) {
        resetSecurityBtn.addEventListener('click', resetSecuritySettings);
    }

    const applySecurityProfileBtn = document.getElementById('apply-security-profile');
    if (applySecurityProfileBtn) {
        applySecurityProfileBtn.addEventListener('click', applySecurityProfile);
    }

    bindSecurityProfileAutoCustomOnManualEdit();
    bindSecuritySettingsBeforeUnloadGuard();

        const applyRecommendedTlsProfileBtn = document.getElementById('apply-recommended-tls-profile');
        if (applyRecommendedTlsProfileBtn) {
            applyRecommendedTlsProfileBtn.addEventListener('click', applyRecommendedTlsProfile);
        }

    const refreshSecurityDiagnosticsBtn = document.getElementById('refresh-security-diagnostics');
    if (refreshSecurityDiagnosticsBtn) {
        refreshSecurityDiagnosticsBtn.addEventListener('click', loadSecurityDiagnostics);
    }

    // Admin navigation panel switching
    setupAdminNavigation();
}

// ============================================
// Navigation Panel Switching
// ============================================
function setupAdminNavigation() {
    const navItems = document.querySelectorAll('.admin-nav-item');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            // Special handling for shortcuts link
            if (item.id === 'admin-shortcuts-link') {
                if (window.KeyboardShortcuts && window.KeyboardShortcuts.show) {
                    window.KeyboardShortcuts.show();
                }
                return;
            }

            // Check for external link
            const externalUrl = item.getAttribute('data-external');
            if (externalUrl) {
                window.location.href = externalUrl;
                return;
            }

            const section = item.getAttribute('data-section');
            if (!section) return;

            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            // Update active panel
            const panels = document.querySelectorAll('.admin-panel');
            panels.forEach(panel => panel.classList.remove('active'));

            const targetPanel = document.getElementById(`admin-panel-${section}`);
            if (targetPanel) {
                targetPanel.classList.add('active');
            }

            // Notify section-specific modules (e.g., external sources panel) to load data lazily.
            document.dispatchEvent(new CustomEvent('adminPanelChanged', {
                detail: { section }
            }));

            // Panel-specific initialization
            if (section === 'email') {
                loadEmailSettings();
            } else if (section === 'backup') {
                loadBackups();
                loadStorageDetails();
                loadBackupSettings();
            } else if (section === 'system') {
                loadSystemInfo();
            }
        });
    });
}

// ============================================
// Stats Loading
// ============================================
async function loadAdminStats() {
    try {
        // Load health for uptime (quick mode skips slow Redis/Celery checks)
        const healthResponse = await adminFetch('/health?quick=true');
        if (healthResponse.ok) {
            const healthData = await healthResponse.json();

            // Update uptime (field is uptime_seconds)
            const uptimeEl = document.getElementById('admin-uptime');
            if (uptimeEl) {
                if (healthData.uptime_seconds !== undefined) {
                    uptimeEl.textContent = formatUptime(healthData.uptime_seconds);
                } else {
                    uptimeEl.textContent = 'N/A';
                }
            }

            // Update health status
            const healthStatusEl = document.getElementById('admin-health-status');
            if (healthStatusEl) {
                healthStatusEl.textContent = healthData.status || 'Unknown';
                healthStatusEl.className = 'admin-stat-value';
                if (healthData.status === 'healthy') {
                    healthStatusEl.style.color = '#15803d';
                } else if (healthData.status === 'degraded') {
                    healthStatusEl.style.color = '#b45309';
                } else {
                    healthStatusEl.style.color = '#dc2626';
                }
            }
        } else {
            // API call failed - show error
            const uptimeEl = document.getElementById('admin-uptime');
            if (uptimeEl) uptimeEl.textContent = 'Error';
        }

        // Load servers count
        const serversResponse = await adminFetch('/api/servers');
        if (serversResponse.ok) {
            const serversData = await serversResponse.json();
            const servers = serversData.servers || serversData;
            const serverCountEl = document.getElementById('admin-server-count');
            if (serverCountEl) {
                serverCountEl.textContent = Array.isArray(servers) ? servers.length : 0;
            }
        }

        // Load audits count
        const auditsResponse = await adminFetch('/api/audits');
        if (auditsResponse.ok) {
            const auditsData = await auditsResponse.json();
            const audits = auditsData.audits || auditsData;
            const auditCountEl = document.getElementById('admin-audit-count');
            if (auditCountEl) {
                auditCountEl.textContent = Array.isArray(audits) ? audits.length : 0;
            }
        }
    } catch (error) {
        console.error('Error loading admin stats:', error);
    }
}

function formatUptime(seconds) {
    if (seconds === undefined || seconds === null || seconds < 0) return '-';

    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (days > 0) {
        return `${days}d ${hours}h`;
    } else if (hours > 0) {
        return `${hours}h ${minutes}m`;
    } else if (minutes > 0) {
        return `${minutes}m`;
    } else {
        return `${secs}s`;
    }
}

// ============================================
// Health Checks
// ============================================
async function loadHealthChecks(quickMode = false) {
    const container = document.getElementById('admin-health-checks');
    if (!container) return;

    container.innerHTML = quickMode
        ? '<div class="loading">Loading health checks...</div>'
        : '<div class="loading">Loading health checks (this may take a moment)...</div>';

    try {
        // Quick mode skips slow Redis/Celery checks for faster page load
        const url = quickMode ? '/health?quick=true' : '/health';
        const response = await adminFetch(url);
        if (!response.ok) throw new Error('Failed to load health data');

        const data = await response.json();
        const checks = data.checks || {};

        let html = '';
        for (const [name, check] of Object.entries(checks)) {
            const status = check.status || check;
            const statusClass = getStatusClass(status);
            const displayName = name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

            html += `
                <div class="health-check-item">
                    <span class="health-check-name">${escapeHtml(displayName)}</span>
                    <span class="health-check-status ${statusClass}">${escapeHtml(status)}</span>
                </div>
            `;
        }

        container.innerHTML = html || '<div class="backup-empty">No health checks available</div>';
    } catch (error) {
        container.innerHTML = `<div class="backup-empty">Error: ${escapeHtml(error.message)}</div>`;
    }
}

function getStatusClass(status) {
    if (!status) return '';
    const s = status.toLowerCase();
    if (s === 'healthy' || s === 'running' || s === 'idle' || s === 'ok') return 'healthy';
    if (s === 'degraded' || s === 'warning') return 'degraded';
    return 'unhealthy';
}

// ============================================
// Backups Management
// ============================================
async function loadBackups() {
    const container = document.getElementById('admin-backup-list');
    if (!container) return;

    container.innerHTML = '<div class="loading">Loading backups...</div>';

    try {
        const response = await adminFetch('/api/backup/list?limit=5');
        if (!response.ok) throw new Error('Failed to load backups');

        const data = await response.json();
        const backups = data.backups || [];

        if (backups.length === 0) {
            container.innerHTML = '<div class="backup-empty">No backups found</div>';
            return;
        }

        let html = '';
        backups.forEach(backup => {
            const date = backup.created_at ? new Date(backup.created_at).toLocaleString() : '-';
            html += `
                <div class="backup-item">
                    <div>
                        <div class="backup-name">${escapeHtml(backup.filename || backup.name)}</div>
                        <div class="backup-date">${escapeHtml(date)}</div>
                    </div>
                    <div class="backup-actions">
                        <button class="btn btn-small" onclick="downloadBackup('${escapeHtml(backup.filename || backup.name)}')">⬇️</button>
                        <button class="btn btn-small btn-danger" onclick="deleteBackup('${escapeHtml(backup.filename || backup.name)}')">🗑️</button>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
    } catch (error) {
        container.innerHTML = `<div class="backup-empty">Error: ${escapeHtml(error.message)}</div>`;
    }
}

async function loadStorageDetails() {
    const backendEl = document.getElementById('storage-backend-type');
    const locationEl = document.getElementById('storage-location');
    const usageEl = document.getElementById('storage-total-usage');
    const healthEl = document.getElementById('storage-health');
    const categoriesEl = document.getElementById('storage-category-breakdown');
    const statusEl = document.getElementById('storage-details-status');

    if (!backendEl || !locationEl || !usageEl || !healthEl || !categoriesEl) {
        return;
    }

    if (statusEl) {
        statusEl.textContent = 'Loading...';
        statusEl.className = 'settings-status';
    }

    categoriesEl.innerHTML = '<div class="loading">Loading storage details...</div>';

    try {
        const [infoResp, statsResp, healthResp, configResp] = await Promise.all([
            adminFetch('/api/admin/storage/info'),
            adminFetch('/api/admin/storage/stats'),
            adminFetch('/api/admin/storage/health'),
            adminFetch('/api/admin/storage/config')
        ]);

        let infoData = null;
        let statsData = null;
        let healthData = null;
        let configData = null;

        if (infoResp.ok) {
            infoData = await infoResp.json();
        }

        if (statsResp.ok) {
            statsData = await statsResp.json();
        }

        if (healthResp.ok) {
            healthData = await healthResp.json();
        }

        if (configResp.ok) {
            configData = await configResp.json();
        }

        const storageInfo = infoData?.storage || {};
        const storageConfig = configData?.config || {};
        const stats = statsData?.stats || {};
        const categories = statsData?.categories || {};

        const rawBackendType = storageInfo.backend_type || storageInfo.type || storageInfo.backend || storageConfig.backend || '-';
        const backendDisplay = String(rawBackendType)
            .replace(/StorageBackend$/i, '')
            .replace(/_/g, ' ')
            .replace(/\b\w/g, ch => ch.toUpperCase());
        backendEl.textContent = backendDisplay;

        const backendKey = String(storageConfig.backend || rawBackendType).toLowerCase();
        let storageLocation = '-';

        if (backendKey.includes('s3') || backendKey.includes('minio') || backendKey.includes('object')) {
            const bucket = storageInfo.bucket || storageConfig.s3?.bucket || '(bucket not set)';
            const endpoint = storageInfo.endpoint || storageConfig.s3?.endpoint_url || '(default endpoint)';
            const prefix = storageInfo.prefix || storageConfig.s3?.prefix;
            storageLocation = prefix && prefix !== '(none)'
                ? `${bucket} @ ${endpoint} (${prefix})`
                : `${bucket} @ ${endpoint}`;
        } else {
            storageLocation =
                storageInfo.path ||
                storageInfo.base_path ||
                storageConfig.path ||
                storageInfo.endpoint ||
                '-';
        }

        locationEl.textContent = storageLocation;

        const totalFiles = Number(stats.total_files || 0);
        const totalSize = Number(stats.total_size || 0);
        usageEl.textContent = `${totalFiles.toLocaleString()} files • ${formatBytes(totalSize)}`;

        if (healthData) {
            const healthy = healthData.healthy === true;
            const latency = healthData.latency_ms != null ? `${healthData.latency_ms} ms` : 'N/A';
            healthEl.textContent = healthy ? `Healthy • ${latency}` : `Degraded • ${latency}`;
            healthEl.style.color = healthy ? '#15803d' : '#dc2626';
        } else {
            healthEl.textContent = 'Unavailable';
            healthEl.style.color = '';
        }

        const categoryRows = Object.entries(categories)
            .sort((a, b) => (b[1]?.total_size || 0) - (a[1]?.total_size || 0))
            .map(([name, category]) => {
                const fileCount = Number(category?.file_count || 0).toLocaleString();
                const totalCategorySize = formatBytes(Number(category?.total_size || 0));
                const displayName = name.replace(/_/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase());
                return `
                    <div class="backup-item">
                        <div>
                            <div class="backup-name">${escapeHtml(displayName)}</div>
                            <div class="backup-date">${fileCount} files</div>
                        </div>
                        <div class="backup-actions" style="align-items: center; color: var(--text-secondary); font-size: 0.85rem;">
                            ${escapeHtml(totalCategorySize)}
                        </div>
                    </div>
                `;
            });

        categoriesEl.innerHTML = categoryRows.length > 0
            ? categoryRows.join('')
            : '<div class="backup-empty">No storage category data available</div>';

        if (statusEl) {
            const timestamp = new Date().toLocaleTimeString();
            statusEl.textContent = `Updated ${timestamp}`;
            statusEl.className = 'settings-status success';
        }
    } catch (error) {
        console.error('Error loading storage details:', error);
        backendEl.textContent = '-';
        locationEl.textContent = '-';
        usageEl.textContent = '-';
        healthEl.textContent = 'Unavailable';
        healthEl.style.color = '';
        categoriesEl.innerHTML = `<div class="backup-empty">Error loading storage details: ${escapeHtml(error.message)}</div>`;

        if (statusEl) {
            statusEl.textContent = 'Failed to load storage details';
            statusEl.className = 'settings-status error';
        }
    }
}

function openBackupModal() {
    const modal = document.getElementById('backup-modal');
    if (!modal) return;

    // Reset form
    document.getElementById('backup-name').value = '';
    document.getElementById('backup-include-servers').checked = true;
    document.getElementById('backup-include-plans').checked = true;
    document.getElementById('backup-include-schedules').checked = true;
    document.getElementById('backup-include-settings').checked = true;
    document.getElementById('backup-include-history').checked = false;
    document.getElementById('backup-include-reports').checked = false;
    document.getElementById('backup-compress').checked = true;
    document.getElementById('backup-encrypt').checked = false;
    document.getElementById('backup-password').value = '';
    document.getElementById('backup-password-section').style.display = 'none';
    document.getElementById('backup-status').textContent = '';
    document.getElementById('confirm-backup-btn').disabled = false;
    document.getElementById('confirm-backup-btn').textContent = '📦 Create Backup';

    // Reset location options
    const locationSelect = document.getElementById('backup-location-select');
    if (locationSelect) locationSelect.value = 'local';
    hideAllBackupLocationSections();

    // Show local path section and load default path
    const localPathSection = document.getElementById('backup-local-path-section');
    if (localPathSection) localPathSection.style.display = 'block';
    loadDefaultBackupPath();

    // Reset location input fields
    const customPath = document.getElementById('backup-custom-path');
    if (customPath) customPath.value = '';
    const networkPath = document.getElementById('backup-network-path');
    if (networkPath) networkPath.value = '';
    const networkFolder = document.getElementById('backup-network-folder');
    if (networkFolder) networkFolder.value = '';
    const networkUser = document.getElementById('backup-network-user');
    if (networkUser) networkUser.value = '';
    const networkPass = document.getElementById('backup-network-pass');
    if (networkPass) networkPass.value = '';
    const cloudProvider = document.getElementById('backup-cloud-provider');
    if (cloudProvider) cloudProvider.value = 's3';
    const cloudBucket = document.getElementById('backup-cloud-bucket');
    if (cloudBucket) cloudBucket.value = '';
    const cloudPrefix = document.getElementById('backup-cloud-prefix');
    if (cloudPrefix) cloudPrefix.value = '';

    modal.style.display = 'flex';
}

async function loadDefaultBackupPath() {
    const pathEl = document.getElementById('backup-default-path');
    const statusEl = document.getElementById('backup-default-path-status');
    const customPathEl = document.getElementById('backup-custom-path');
    const networkPathEl = document.getElementById('backup-network-path');

    if (!pathEl) return;

    try {
        const response = await adminFetch('/api/backup/info');
        if (response.ok) {
            const data = await response.json();
            pathEl.textContent = data.default_path || 'Unknown';

            if (statusEl) {
                if (data.default_path_writable) {
                    statusEl.textContent = '✅';
                    statusEl.title = 'Directory exists and is writable';
                } else if (data.default_path_exists) {
                    statusEl.textContent = '⚠️';
                    statusEl.title = 'Directory exists but is not writable';
                } else {
                    statusEl.textContent = '❌';
                    statusEl.title = 'Directory does not exist';
                }
            }

            // Set OS-appropriate placeholders
            if (customPathEl && data.example_path) {
                customPathEl.placeholder = data.example_path;
            }
            if (networkPathEl && data.network_example) {
                networkPathEl.placeholder = data.network_example;
            }
        } else {
            pathEl.textContent = 'Unable to retrieve';
        }
    } catch (error) {
        console.error('Failed to load backup info:', error);
        pathEl.textContent = 'Error loading path';
    }
}

function hideAllBackupLocationSections() {
    const sections = ['backup-local-path-section', 'backup-custom-path-section', 'backup-network-section', 'backup-cloud-section'];
    sections.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
}

function handleBackupLocationChange() {
    const locationSelect = document.getElementById('backup-location-select');
    if (!locationSelect) return;

    const selected = locationSelect.value;
    hideAllBackupLocationSections();

    switch (selected) {
        case 'local':
            document.getElementById('backup-local-path-section').style.display = 'block';
            break;
        case 'custom':
            document.getElementById('backup-custom-path-section').style.display = 'block';
            break;
        case 'network':
            document.getElementById('backup-network-section').style.display = 'block';
            break;
        case 'cloud':
            document.getElementById('backup-cloud-section').style.display = 'block';
            break;
    }
}

function closeBackupModal() {
    const modal = document.getElementById('backup-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// ============================================
// Directory Browser for Backup Location
// ============================================

let directoryBrowserTargetInput = null;
let directoryBrowserCurrentPath = '/';
let directoryBrowserParentPath = null;

function openDirectoryBrowser(targetInputId) {
    directoryBrowserTargetInput = targetInputId;
    const modal = document.getElementById('directory-browser-modal');
    if (modal) {
        modal.style.display = 'flex';
        // Start browsing from root or home directory
        browseDirectory('');
    }
}

function closeDirectoryBrowser() {
    const modal = document.getElementById('directory-browser-modal');
    if (modal) {
        modal.style.display = 'none';
    }
    directoryBrowserTargetInput = null;
}

async function browseDirectory(path) {
    const listingEl = document.getElementById('directory-listing');
    const currentPathEl = document.getElementById('dir-current-path');
    const writableEl = document.getElementById('dir-writable-indicator');
    const parentBtn = document.getElementById('dir-parent-btn');
    const selectBtn = document.getElementById('dir-select-btn');

    if (!listingEl) return;

    // Show loading state
    listingEl.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">Loading...</div>';

    try {
        const response = await adminFetch('/api/backup/browse', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: path, show_files: false })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to browse directory');
        }

        const data = await response.json();
        directoryBrowserCurrentPath = data.current_path;
        directoryBrowserParentPath = data.parent_path;

        // Update UI
        if (currentPathEl) currentPathEl.textContent = data.current_path;
        if (parentBtn) parentBtn.disabled = !data.parent_path;

        if (writableEl) {
            if (data.is_writable) {
                writableEl.textContent = '✅ Writable';
                writableEl.style.color = '#22c55e';
            } else {
                writableEl.textContent = '🔒 Read-only';
                writableEl.style.color = '#f59e0b';
            }
        }

        // Enable/disable select button based on writability
        if (selectBtn) {
            selectBtn.disabled = !data.is_writable;
            selectBtn.title = data.is_writable ? 'Select this directory for backups' : 'Cannot select read-only directory';
        }

        // Render directory listing
        if (data.items.length === 0) {
            listingEl.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">📭 Empty directory</div>';
        } else {
            let html = '<div class="dir-listing">';
            for (const item of data.items) {
                if (item.is_dir) {
                    const writableIcon = item.writable ? '✅' : '🔒';
                    html += `
                        <div class="dir-item" onclick="browseDirectory('${escapeHtml(item.path)}')" style="cursor: pointer;">
                            <span class="dir-icon">📁</span>
                            <span class="dir-name">${escapeHtml(item.name)}</span>
                            <span class="dir-status" title="${item.writable ? 'Writable' : 'Read-only'}">${writableIcon}</span>
                        </div>
                    `;
                }
            }
            html += '</div>';
            listingEl.innerHTML = html;
        }

    } catch (error) {
        console.error('Directory browse error:', error);
        listingEl.innerHTML = `<div style="text-align: center; padding: 2rem; color: #ef4444;">❌ ${escapeHtml(error.message)}</div>`;
    }
}

function navigateToParent() {
    if (directoryBrowserParentPath) {
        browseDirectory(directoryBrowserParentPath);
    }
}

function selectCurrentDirectory() {
    if (directoryBrowserTargetInput && directoryBrowserCurrentPath) {
        const input = document.getElementById(directoryBrowserTargetInput);
        if (input) {
            input.value = directoryBrowserCurrentPath;
        }
    }
    closeDirectoryBrowser();
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// LDAP / Active Directory Configuration
// ============================================

function openLdapConfigModal() {
    const modal = document.getElementById('ldap-config-modal');
    if (modal) {
        modal.style.display = 'flex';
        loadLdapConfig();
    }
}

function closeLdapConfigModal() {
    const modal = document.getElementById('ldap-config-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function loadLdapConfig() {
    try {
        const response = await adminFetch('/api/admin/auth/ldap');
        if (response.ok) {
            const data = await response.json();
            if (data.config) {
                const c = data.config;
                setInputValue('ldap-server', c.server);
                setInputValue('ldap-port', c.port);
                setInputValue('ldap-security', c.security);
                setInputValue('ldap-type', c.type);
                setInputValue('ldap-bind-dn', c.bind_dn);
                setInputValue('ldap-base-dn', c.base_dn);
                setInputValue('ldap-user-filter', c.user_filter);
                setInputValue('ldap-username-attr', c.username_attr);
                setInputValue('ldap-email-attr', c.email_attr);
                setInputValue('ldap-admin-group', c.admin_group);
                setInputValue('ldap-analyst-group', c.analyst_group);
                setCheckboxValue('ldap-enabled', c.enabled);
                setCheckboxValue('ldap-allow-local', c.allow_local !== false);
                setCheckboxValue('ldap-auto-create', c.auto_create !== false);
                setCheckboxValue('ldap-verify-cert', c.verify_cert !== false);

                // Update status badge
                updateAuthProviderStatus('ldap', c.enabled);
            }
        }
    } catch (error) {
        console.error('Failed to load LDAP config:', error);
    }
}

async function saveLdapConfig() {
    const btn = document.getElementById('save-ldap-btn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Saving...';

    const config = {
        server: document.getElementById('ldap-server').value.trim(),
        port: parseInt(document.getElementById('ldap-port').value) || 389,
        security: document.getElementById('ldap-security').value,
        type: document.getElementById('ldap-type').value,
        bind_dn: document.getElementById('ldap-bind-dn').value.trim(),
        bind_password: document.getElementById('ldap-bind-password').value,
        base_dn: document.getElementById('ldap-base-dn').value.trim(),
        user_filter: document.getElementById('ldap-user-filter').value.trim(),
        username_attr: document.getElementById('ldap-username-attr').value.trim() || 'sAMAccountName',
        email_attr: document.getElementById('ldap-email-attr').value.trim() || 'mail',
        admin_group: document.getElementById('ldap-admin-group').value.trim(),
        analyst_group: document.getElementById('ldap-analyst-group').value.trim(),
        enabled: document.getElementById('ldap-enabled').checked,
        allow_local: document.getElementById('ldap-allow-local').checked,
        auto_create: document.getElementById('ldap-auto-create').checked,
        verify_cert: document.getElementById('ldap-verify-cert').checked
    };

    // Validate required fields if enabled
    if (config.enabled) {
        if (!config.server || !config.bind_dn || !config.base_dn) {
            showToast('Please fill in all required fields', 'error');
            btn.disabled = false;
            btn.textContent = originalText;
            return;
        }
    }

    try {
        const response = await adminFetch('/api/admin/auth/ldap', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });

        const data = await response.json();

        if (data.success) {
            showToast('LDAP configuration saved successfully', 'success');
            updateAuthProviderStatus('ldap', config.enabled);
            closeLdapConfigModal();
        } else {
            showToast(data.error || 'Failed to save LDAP configuration', 'error');
        }
    } catch (error) {
        showToast('Error saving configuration: ' + error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
}

async function testLdapConnection() {
    const btn = document.getElementById('test-ldap-btn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Testing...';

    const config = {
        server: document.getElementById('ldap-server').value.trim(),
        port: parseInt(document.getElementById('ldap-port').value) || 389,
        security: document.getElementById('ldap-security').value,
        bind_dn: document.getElementById('ldap-bind-dn').value.trim(),
        bind_password: document.getElementById('ldap-bind-password').value,
        base_dn: document.getElementById('ldap-base-dn').value.trim(),
        verify_cert: document.getElementById('ldap-verify-cert').checked
    };

    if (!config.server || !config.bind_dn) {
        showToast('Please enter server address and bind DN', 'error');
        btn.disabled = false;
        btn.textContent = originalText;
        return;
    }

    try {
        const response = await adminFetch('/api/admin/auth/ldap/test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });

        const data = await response.json();

        if (data.success) {
            showToast('✅ LDAP connection successful!', 'success');
        } else {
            showToast('❌ Connection failed: ' + (data.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        showToast('❌ Connection test failed: ' + error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
}

// ============================================
// Microsoft Entra ID Configuration
// ============================================

function openEntraConfigModal() {
    const modal = document.getElementById('entra-config-modal');
    if (modal) {
        modal.style.display = 'flex';
        loadEntraConfig();
    }
}

function closeEntraConfigModal() {
    const modal = document.getElementById('entra-config-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function loadEntraConfig() {
    try {
        const response = await adminFetch('/api/admin/auth/entra');
        if (response.ok) {
            const data = await response.json();
            if (data.config) {
                const c = data.config;
                setInputValue('entra-tenant-id', c.tenant_id);
                setInputValue('entra-client-id', c.client_id);
                setInputValue('entra-redirect-uri', c.redirect_uri);
                setInputValue('entra-superadmin-group', c.superadmin_group);
                setInputValue('entra-admin-group', c.admin_group);
                setInputValue('entra-analyst-group', c.analyst_group);
                setInputValue('entra-viewer-group', c.viewer_group);
                setInputValue('entra-default-role', c.default_role || 'viewer');
                setCheckboxValue('entra-enabled', c.enabled);
                setCheckboxValue('entra-allow-local', c.allow_local !== false);
                setCheckboxValue('entra-auto-create', c.auto_create !== false);
                setCheckboxValue('entra-sync-groups', c.sync_groups);

                // Update status badge
                updateAuthProviderStatus('entra', c.enabled);
            }
        }
    } catch (error) {
        console.error('Failed to load Entra ID config:', error);
    }
}

async function saveEntraConfig() {
    const btn = document.getElementById('save-entra-btn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Saving...';

    const config = {
        tenant_id: document.getElementById('entra-tenant-id').value.trim(),
        client_id: document.getElementById('entra-client-id').value.trim(),
        client_secret: document.getElementById('entra-client-secret').value,
        redirect_uri: document.getElementById('entra-redirect-uri').value.trim(),
        superadmin_group: document.getElementById('entra-superadmin-group').value.trim(),
        admin_group: document.getElementById('entra-admin-group').value.trim(),
        analyst_group: document.getElementById('entra-analyst-group').value.trim(),
        viewer_group: document.getElementById('entra-viewer-group').value.trim(),
        default_role: document.getElementById('entra-default-role').value,
        enabled: document.getElementById('entra-enabled').checked,
        allow_local: document.getElementById('entra-allow-local').checked,
        auto_create: document.getElementById('entra-auto-create').checked,
        sync_groups: document.getElementById('entra-sync-groups').checked
    };

    // Validate required fields if enabled
    if (config.enabled) {
        if (!config.tenant_id || !config.client_id || !config.redirect_uri) {
            showToast('Please fill in Tenant ID, Client ID, and Redirect URI', 'error');
            btn.disabled = false;
            btn.textContent = originalText;
            return;
        }
    }

    try {
        const response = await adminFetch('/api/admin/auth/entra', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });

        const data = await response.json();

        if (data.success) {
            showToast('Entra ID configuration saved successfully', 'success');
            updateAuthProviderStatus('entra', config.enabled);
            closeEntraConfigModal();
        } else {
            showToast(data.error || 'Failed to save Entra ID configuration', 'error');
        }
    } catch (error) {
        showToast('Error saving configuration: ' + error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
}

async function testEntraConfig() {
    const btn = document.getElementById('test-entra-btn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Testing...';

    const config = {
        tenant_id: document.getElementById('entra-tenant-id').value.trim(),
        client_id: document.getElementById('entra-client-id').value.trim(),
        client_secret: document.getElementById('entra-client-secret').value
    };

    if (!config.tenant_id || !config.client_id) {
        showToast('Please enter Tenant ID and Client ID', 'error');
        btn.disabled = false;
        btn.textContent = originalText;
        return;
    }

    try {
        const response = await adminFetch('/api/admin/auth/entra/test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });

        const data = await response.json();

        if (data.success) {
            showToast('✅ Entra ID configuration valid!', 'success');
        } else {
            showToast('❌ Configuration test failed: ' + (data.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        showToast('❌ Configuration test failed: ' + error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
}

// Helper to update auth provider status badge in UI
function updateAuthProviderStatus(provider, enabled) {
    const card = document.querySelector(`#admin-configure-${provider}`);
    if (card) {
        const statusBadge = card.closest('.auth-provider-card')?.querySelector('.status-badge');
        if (statusBadge) {
            if (enabled) {
                statusBadge.textContent = 'Configured';
                statusBadge.style.background = 'var(--success-color)';
            } else {
                statusBadge.textContent = 'Not Configured';
                statusBadge.style.background = 'var(--warning-color)';
            }
        }
    }
}

// Helper functions for form inputs
function setInputValue(id, value) {
    const el = document.getElementById(id);
    if (el && value !== undefined && value !== null) {
        el.value = value;
    }
}

function setCheckboxValue(id, value) {
    const el = document.getElementById(id);
    if (el) {
        el.checked = !!value;
    }
}

async function createBackupWithOptions() {
    const btn = document.getElementById('confirm-backup-btn');
    const statusEl = document.getElementById('backup-status');

    if (!btn) return;

    // Get selected location
    const locationSelect = document.getElementById('backup-location-select');
    const locationType = locationSelect ? locationSelect.value : 'local';

    // Gather options
    const options = {
        name: document.getElementById('backup-name').value.trim(),
        include: {
            servers: document.getElementById('backup-include-servers').checked,
            plans: document.getElementById('backup-include-plans').checked,
            schedules: document.getElementById('backup-include-schedules').checked,
            settings: document.getElementById('backup-include-settings').checked,
            history: document.getElementById('backup-include-history').checked,
            reports: document.getElementById('backup-include-reports').checked
        },
        compress: document.getElementById('backup-compress').checked,
        encrypt: document.getElementById('backup-encrypt').checked,
        location: {
            type: locationType
        }
    };

    // Add location-specific details
    if (locationType === 'custom') {
        const customPath = document.getElementById('backup-custom-path').value.trim();
        if (!customPath) {
            statusEl.textContent = '⚠️ Please enter a custom backup path';
            statusEl.style.color = '#f59e0b';
            return;
        }
        options.location.path = customPath;
    } else if (locationType === 'network') {
        const networkPath = document.getElementById('backup-network-path').value.trim();
        if (!networkPath) {
            statusEl.textContent = '⚠️ Please enter a network share path';
            statusEl.style.color = '#f59e0b';
            return;
        }
        options.location.path = networkPath;
        options.location.folder = document.getElementById('backup-network-folder').value.trim();
        options.location.username = document.getElementById('backup-network-user').value.trim();
        options.location.password = document.getElementById('backup-network-pass').value;
    } else if (locationType === 'cloud') {
        const bucket = document.getElementById('backup-cloud-bucket').value.trim();
        if (!bucket) {
            statusEl.textContent = '⚠️ Please enter a bucket/container name';
            statusEl.style.color = '#f59e0b';
            return;
        }
        options.location.provider = document.getElementById('backup-cloud-provider').value;
        options.location.bucket = bucket;
        options.location.prefix = document.getElementById('backup-cloud-prefix').value.trim();
    }

    // Check if at least one item is selected
    const hasSelection = Object.values(options.include).some(v => v);
    if (!hasSelection) {
        statusEl.textContent = '⚠️ Select at least one item to backup';
        statusEl.style.color = '#f59e0b';
        return;
    }

    // Check encryption password
    if (options.encrypt) {
        const password = document.getElementById('backup-password').value;
        if (!password || password.length < 6) {
            statusEl.textContent = '⚠️ Encryption password must be at least 6 characters';
            statusEl.style.color = '#f59e0b';
            return;
        }
        options.password = password;
    }

    btn.disabled = true;
    btn.textContent = '⏳ Creating...';
    statusEl.textContent = 'Creating backup...';
    statusEl.style.color = 'var(--text-secondary)';

    try {
        const response = await adminFetch('/api/backup/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(options)
        });

        const data = await response.json();

        if (data.success) {
            statusEl.textContent = '✅ Backup created successfully!';
            statusEl.style.color = '#10b981';
            showMessage('Backup created successfully!', 'success');
            await loadBackups();

            // Close modal after short delay
            setTimeout(() => {
                closeBackupModal();
            }, 1500);
        } else {
            statusEl.textContent = '❌ ' + (data.error || 'Failed to create backup');
            statusEl.style.color = '#ef4444';
            btn.disabled = false;
            btn.textContent = '📦 Create Backup';
        }
    } catch (error) {
        statusEl.textContent = '❌ Error: ' + error.message;
        statusEl.style.color = '#ef4444';
        btn.disabled = false;
        btn.textContent = '📦 Create Backup';
    }
}

async function createBackup() {
    const btn = document.getElementById('admin-create-backup');
    if (!btn) return;

    btn.disabled = true;
    btn.textContent = '⏳ Creating...';

    try {
        const response = await adminFetch('/api/backup/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        const data = await response.json();

        if (data.success) {
            showMessage('Backup created successfully!', 'success');
            await loadBackups();
        } else {
            showMessage(data.error || 'Failed to create backup', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = '📦 Create Backup';
    }
}

async function cleanupBackups() {
    // Get configured keep_count from settings
    const keepCountEl = document.getElementById('setting-backup-keep-count');
    const keepCount = keepCountEl ? parseInt(keepCountEl.value) || 10 : 10;

    if (!confirm(`Delete old backups (keep last ${keepCount})?`)) return;

    try {
        const response = await adminFetch('/api/backup/cleanup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ keep_count: keepCount })
        });

        const data = await response.json();

        if (data.success) {
            showMessage(`Cleaned up ${data.deleted_count || 0} old backups`, 'success');
            await loadBackups();
        } else {
            showMessage(data.error || 'Cleanup failed', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

async function downloadBackup(filename) {
    window.open(`/api/backup/download/${encodeURIComponent(filename)}`, '_blank');
}

async function deleteBackup(filename) {
    if (!confirm(`Delete backup "${filename}"?`)) return;

    try {
        const response = await adminFetch(`/api/backup/delete/${encodeURIComponent(filename)}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showMessage('Backup deleted', 'success');
            await loadBackups();
        } else {
            showMessage(data.error || 'Delete failed', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// ============================================
// Backup Settings
// ============================================
async function loadBackupSettings() {
    try {
        const response = await adminFetch('/api/admin/security-settings');
        if (!response.ok) return;

        const settings = await response.json();
        const s = settings.settings || {};

        // Backup Configuration
        setInputById('setting-backup-retention-days', s.backup_retention_days || 30);
        setInputById('setting-backup-keep-count', s.backup_keep_count || 10);
        setCheckboxById('setting-backup-compress', s.backup_compress !== false);
        setCheckboxById('setting-backup-encrypt', s.backup_encrypt);
        setCheckboxById('setting-backup-auto-enabled', s.backup_auto_enabled);
        setSelectById('setting-backup-schedule', s.backup_schedule || 'daily');
        setInputById('setting-backup-max-size', s.backup_max_size || 500);

    } catch (error) {
        console.error('Error loading backup settings:', error);
    }
}

async function saveBackupSettings() {
    const statusEl = document.getElementById('backup-settings-status');
    const saveBtn = document.getElementById('save-backup-settings');

    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving...';
    }

    // First, load existing settings to preserve other values
    let existingSettings = {};
    try {
        const response = await adminFetch('/api/admin/security-settings');
        if (response.ok) {
            const data = await response.json();
            existingSettings = data.settings || {};
        }
    } catch (e) {
        console.warn('Could not load existing settings:', e);
    }

    // Merge backup settings with existing
    const settings = {
        ...existingSettings,
        backup_retention_days: parseInt(document.getElementById('setting-backup-retention-days')?.value) || 30,
        backup_keep_count: parseInt(document.getElementById('setting-backup-keep-count')?.value) || 10,
        backup_compress: document.getElementById('setting-backup-compress')?.checked || false,
        backup_encrypt: document.getElementById('setting-backup-encrypt')?.checked || false,
        backup_auto_enabled: document.getElementById('setting-backup-auto-enabled')?.checked || false,
        backup_schedule: document.getElementById('setting-backup-schedule')?.value || 'daily',
        backup_max_size: parseInt(document.getElementById('setting-backup-max-size')?.value) || 500
    };

    try {
        const response = await adminFetch('/api/admin/security-settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ settings })
        });

        const data = await response.json();

        if (response.ok) {
            if (statusEl) {
                statusEl.textContent = '✅ Backup settings saved';
                statusEl.className = 'settings-status success';
                setTimeout(() => { statusEl.textContent = ''; }, 3000);
            }
        } else {
            throw new Error(data.error || 'Failed to save settings');
        }
    } catch (error) {
        console.error('Error saving backup settings:', error);
        if (statusEl) {
            statusEl.textContent = '❌ ' + error.message;
            statusEl.className = 'settings-status error';
        }
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.textContent = '💾 Save Backup Settings';
        }
    }
}

function resetBackupSettings() {
    if (!confirm('Reset backup settings to defaults?')) return;

    setInputById('setting-backup-retention-days', 30);
    setInputById('setting-backup-keep-count', 10);
    setCheckboxById('setting-backup-compress', true);
    setCheckboxById('setting-backup-encrypt', false);
    setCheckboxById('setting-backup-auto-enabled', false);
    setSelectById('setting-backup-schedule', 'daily');
    setInputById('setting-backup-max-size', 500);

    const statusEl = document.getElementById('backup-settings-status');
    if (statusEl) {
        statusEl.textContent = '↩️ Settings reset to defaults (not yet saved)';
        statusEl.className = 'settings-status';
    }
}

// ============================================
// System Information
// ============================================
async function loadSystemInfo() {
    try {
        const response = await adminFetch('/health');
        if (!response.ok) return;

        const data = await response.json();

        // Version
        const versionEl = document.getElementById('admin-version');
        if (versionEl) {
            versionEl.textContent = data.version || '5.1.5';
        }

        // Environment
        const envEl = document.getElementById('admin-environment');
        if (envEl) {
            envEl.textContent = data.environment || 'Development';
        }

        // Database
        const dbEl = document.getElementById('admin-database');
        if (dbEl && data.checks && data.checks.database) {
            dbEl.textContent = data.checks.database.type || 'SQLite';
        }

        // Redis
        const redisEl = document.getElementById('admin-redis');
        if (redisEl && data.checks && data.checks.redis) {
            redisEl.textContent = data.checks.redis.status === 'healthy' ? 'Connected' : 'Disabled';
        }

        // Celery
        const celeryEl = document.getElementById('admin-celery');
        if (celeryEl && data.checks && data.checks.celery) {
            celeryEl.textContent = data.checks.celery.workers || '0';
        }

        // Start time
        const startEl = document.getElementById('admin-start-time');
        if (startEl && data.start_time) {
            startEl.textContent = new Date(data.start_time).toLocaleString();
        }
    } catch (error) {
        console.error('Error loading system info:', error);
    }
}

// ============================================
// Settings
// ============================================
async function loadSettings() {
    try {
        const response = await adminFetch('/api/settings');
        if (!response.ok) return;

        const settings = await response.json();

        // Email settings
        const emailEnabled = document.getElementById('admin-email-enabled');
        if (emailEnabled) {
            emailEnabled.checked = settings.email?.enabled || false;
            toggleEmailConfig();
        }

        if (settings.email) {
            setValueIfExists('admin-smtp-host', settings.email.smtp_host);
            setValueIfExists('admin-smtp-port', settings.email.smtp_port);
            setValueIfExists('admin-smtp-user', settings.email.smtp_user);
            setValueIfExists('admin-smtp-from', settings.email.from_address);
            setValueIfExists('admin-smtp-to', settings.email.to_address);
        }

        // Load security settings (SuperAdmin only)
        await loadSecuritySettings();
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

async function loadSecuritySettings() {
    try {
        const response = await adminFetch('/api/admin/security-settings');
        if (!response.ok) return;

        const settings = await response.json();
        const s = settings.settings || {};
        loadedSecuritySettings = s;

        // Authentication & Access
        setInputById('setting-session-timeout', s.session_timeout || 30);
        setInputById('setting-max-login-attempts', s.max_login_attempts || 5);
        setInputById('setting-lockout-duration', s.lockout_duration || 15);
        setCheckboxById('setting-enforce-2fa', s.enforce_2fa);

        // Password Policy
        setInputById('setting-password-min-length', s.password_min_length || 12);
        setCheckboxById('setting-password-uppercase', s.password_uppercase !== false);
        setCheckboxById('setting-password-numbers', s.password_numbers !== false);
        setCheckboxById('setting-password-special', s.password_special !== false);
        setInputById('setting-password-expiry', s.password_expiry || 90);
        setInputById('setting-password-history', s.password_history || 5);

        // Audit Execution
        setInputById('setting-audit-timeout', s.audit_timeout || 300);
        setInputById('setting-result-retention', s.result_retention || 90);
        setInputById('setting-result-retention-max-records', s.result_retention_max_records ?? 100000);
        setInputById('setting-hypervisor-result-retention-days', s.hypervisor_result_retention_days ?? 90);
        setInputById('setting-hypervisor-result-retention-max-records', s.hypervisor_result_retention_max_records ?? 100000);
        setInputById('setting-report-artifact-retention-days', s.report_artifact_retention_days ?? 90);
        setInputById('setting-report-artifact-max-files', s.report_artifact_max_files ?? 10000);
        setCheckboxById('setting-evidence-retention-enabled', s.evidence_retention_enabled !== false);
        setInputById('setting-evidence-retention-days', s.evidence_retention_days ?? 30);
        setCheckboxById('setting-cleanup-old-executions-enabled', s.cleanup_old_executions_enabled !== false);
        setInputById('setting-cleanup-old-executions-interval-minutes', s.cleanup_old_executions_interval_minutes ?? 1440);
        setCheckboxById('setting-cleanup-analytics-history-enabled', s.cleanup_analytics_history_enabled !== false);
        setInputById('setting-cleanup-analytics-history-interval-minutes', s.cleanup_analytics_history_interval_minutes ?? 1440);
        setInputById('setting-postgres-maintenance-interval-minutes', s.postgres_maintenance_interval_minutes ?? 360);

        // User Management Defaults
        setSelectById('setting-default-role', s.default_role || 'Viewer');
        setCheckboxById('setting-auto-approve-users', s.auto_approve_users);
        setCheckboxById('setting-self-registration', s.self_registration);
        setInputById('setting-max-users', s.max_users || 0);

        // Maintenance
        setCheckboxById('setting-maintenance-mode', s.maintenance_mode);
        setInputById('setting-maintenance-message', s.maintenance_message || '');

        // Network & Security
        setInputById('setting-ip-whitelist', s.ip_whitelist || '');
        setInputById('setting-ip-blacklist', s.ip_blacklist || '');
        setCheckboxById('setting-enforce-https', s.enforce_https);
        setSelectById('setting-tls-minimum-version-toolkit', s.tls_minimum_version_toolkit || 'TLSv1_3');
        setSelectById('setting-tls-minimum-version-external', s.tls_minimum_version_external || 'TLSv1_2');
        setSelectById('setting-tls-maximum-version', s.tls_maximum_version || 'TLSv1_3');
        setCheckboxById('setting-tls-certificate-verification', s.tls_certificate_verification !== false);
        setCheckboxById('setting-tls-strict-mode', s.tls_strict_mode);
        setCheckboxById('setting-tls-log-version', s.tls_log_version !== false);
        setInputById('setting-tls-cipher-suites', s.tls_cipher_suites || 'ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!DSS:!RC4:!DES');

        // Critical Hardening Controls
        setCheckboxById('setting-security-backup-encrypt', s.backup_encrypt);
        setCheckboxById('setting-security-backup-compress', s.backup_compress !== false);
        setCheckboxById('setting-security-backup-auto-enabled', s.backup_auto_enabled);
        setInputById('setting-security-backup-retention-days', s.backup_retention_days ?? 30);
        setInputById('setting-security-backup-keep-count', s.backup_keep_count ?? 10);
        setInputById('setting-security-backup-max-size', s.backup_max_size ?? 500);
        setSelectById('setting-security-backup-schedule', s.backup_schedule || 'daily');
        setCheckboxById('setting-backup-include-shared-data', s.backup_include_shared_data !== false);
        setInputById(
            'setting-backup-shared-data-paths',
            s.backup_shared_data_paths || '/opt/audit-toolkit/data/agents,/opt/audit-toolkit/shared/asset-discovery-data,/opt/audit-toolkit/shared/asset-discovery-logs'
        );
        setCheckboxById('setting-agent-tls-verify', s.agent_tls_verify !== false);
        setCheckboxById('setting-agent-tls-pinning-enabled', s.agent_tls_pinning_enabled);
        setInputById('setting-agent-tls-pinned-cert-hash', s.agent_tls_pinned_cert_hash || '');
        setCheckboxById('setting-agent-encrypt-keys-at-rest', s.agent_encrypt_keys_at_rest !== false);
        setCheckboxById('setting-fleet-agent-result-encryption-enabled', s.fleet_agent_result_encryption_enabled);
        setSelectById('setting-fleet-agent-result-encryption-algorithm', s.fleet_agent_result_encryption_algorithm || 'fernet-aes128');
        setCheckboxById('setting-agent-require-approval', s.agent_require_approval);
        setCheckboxById('setting-agent-auto-approve-known-hosts', s.agent_auto_approve_known_hosts !== false);
        setInputById('setting-agent-api-key-rotation-days', s.agent_api_key_rotation_days ?? 0);
        setInputById('setting-agent-api-key-grace-period-hours', s.agent_api_key_grace_period_hours ?? 24);
        setSelectById('setting-ssh-host-key-policy', s.ssh_host_key_policy || 'warn');
        setCheckboxById('setting-fleet-agent-enforce-signed-config', s.fleet_agent_enforce_signed_config !== false);
        setInputById('setting-fleet-agent-config-max-age-seconds', s.fleet_agent_config_max_age_seconds ?? 900);
        setInputById('setting-fleet-agent-config-signing-key', s.fleet_agent_config_signing_key || '');
        setCheckboxById('setting-fleet-agent-require-request-signatures', s.fleet_agent_require_request_signatures);
        setInputById('setting-fleet-agent-request-signature-max-age-seconds', s.fleet_agent_request_signature_max_age_seconds ?? 300);
        setInputById('setting-fleet-agent-request-signing-key', s.fleet_agent_request_signing_key || '');
        setCheckboxById('setting-fleet-agent-request-signature-ecdsa-dual-verify-enabled', s.fleet_agent_request_signature_ecdsa_dual_verify_enabled);
        setInputById('setting-fleet-agent-request-signature-ecdsa-public-key', s.fleet_agent_request_signature_ecdsa_public_key || '');
        setSelectById('setting-fleet-agent-result-encryption-key-derivation', s.fleet_agent_result_encryption_key_derivation || 'agent_id');
        setInputById('setting-fleet-agent-results-encryption-key-custom', s.fleet_agent_results_encryption_key_custom || '');

        // Advanced (Restart Required)
        setInputById('setting-rate-limit', s.rate_limit || 100);
        setInputById('setting-max-concurrent-audits', s.max_concurrent_audits || 5);
        setInputById('setting-worker-pool-size', s.worker_pool_size || 4);
        setSelectById('setting-log-level', s.log_level || 'INFO');
        setInputById('setting-cors-origins', s.cors_origins || '');

        // Agent Throttle Settings
        setInputById('setting-agent-cpu-nice-level', s.agent_cpu_nice_level ?? 19);
        setSelectById('setting-agent-process-priority', s.agent_process_priority || 'Idle');
        setSelectById('setting-agent-io-class', s.agent_io_class || 'idle');
        setInputById('setting-agent-min-free-memory-pct', s.agent_min_free_memory_pct ?? 10);
        setInputById('setting-agent-max-load-average', s.agent_max_load_average ?? 0);
        setInputById('setting-agent-max-cpu-pct', s.agent_max_cpu_pct ?? 0);
        setInputById('setting-agent-upload-rate-limit', s.agent_upload_rate_limit ?? 0);
        setInputById('setting-agent-download-rate-limit', s.agent_download_rate_limit ?? 0);
        setInputById('setting-agent-local-result-max-files', s.agent_local_result_max_files ?? 1000);
        setInputById('setting-agent-local-min-free-disk-mb', s.agent_local_min_free_disk_mb ?? 512);
        setInputById('setting-agent-local-min-free-disk-pct', s.agent_local_min_free_disk_pct ?? 3);
        setInputById('setting-standalone-agent-results-rate-limit-per-hour', s.standalone_agent_results_rate_limit_per_hour ?? 100);
        setInputById('setting-fleet-agent-results-rate-limit-per-hour', s.fleet_agent_results_rate_limit_per_hour ?? 200);
        setInputById('setting-hypervisor-agent-results-rate-limit-per-hour', s.hypervisor_agent_results_rate_limit_per_hour ?? 200);
        setInputById('setting-asset-discovery-results-rate-limit-per-hour', s.asset_discovery_results_rate_limit_per_hour ?? 200);
        setInputById('setting-standalone-agent-result-max-files-per-host', s.standalone_agent_result_max_files_per_host ?? 5000);
        setInputById('setting-fleet-agent-result-max-files-per-host', s.fleet_agent_result_max_files_per_host ?? 5000);
        setCheckboxById('setting-agent-result-ingest-disk-guard-enabled', s.agent_result_ingest_disk_guard_enabled !== false);
        setInputById('setting-agent-result-ingest-min-free-disk-mb', s.agent_result_ingest_min_free_disk_mb ?? 1024);
        setInputById('setting-agent-result-ingest-min-free-disk-pct', s.agent_result_ingest_min_free_disk_pct ?? 5);
        // Asset Discovery Service Rate Limits
        setInputById('setting-asset-discovery-api-rate-limit-per-minute', s.asset_discovery_api_rate_limit_per_minute ?? 100);
        setInputById('setting-asset-discovery-scan-rate-limit-per-minute', s.asset_discovery_scan_rate_limit_per_minute ?? 20);
        setInputById('setting-asset-discovery-cve-sync-rate-limit-per-minute', s.asset_discovery_cve_sync_rate_limit_per_minute ?? 10);
        setInputById('setting-asset-discovery-dashboard-rate-limit-per-minute', s.asset_discovery_dashboard_rate_limit_per_minute ?? 60);
        // Authentication Rate Limits
        setInputById('setting-auth-login-rate-limit-per-minute', s.auth_login_rate_limit_per_minute ?? 5);
        setInputById('setting-auth-password-reset-rate-limit-per-minute', s.auth_password_reset_rate_limit_per_minute ?? 3);
        setInputById('setting-auth-registration-rate-limit-per-minute', s.auth_registration_rate_limit_per_minute ?? 5);
        setInputById('setting-auth-2fa-rate-limit-per-minute', s.auth_2fa_rate_limit_per_minute ?? 10);
        // API Operation Rate Limits
        setInputById('setting-api-general-rate-limit-per-minute', s.api_general_rate_limit_per_minute ?? 100);
        setInputById('setting-api-write-rate-limit-per-minute', s.api_write_rate_limit_per_minute ?? 30);
        setInputById('setting-api-export-rate-limit-per-minute', s.api_export_rate_limit_per_minute ?? 10);
        setInputById('setting-api-import-rate-limit-per-minute', s.api_import_rate_limit_per_minute ?? 5);
        setInputById('setting-api-search-rate-limit-per-minute', s.api_search_rate_limit_per_minute ?? 60);
        setInputById('setting-analytics-max-result-set-size', s.analytics_max_result_set_size ?? 10000);
        // Scheduled Operations Rate Limits
        setInputById('setting-schedule-list-rate-limit-per-minute', s.schedule_list_rate_limit_per_minute ?? 100);
        setInputById('setting-schedule-create-rate-limit-per-minute', s.schedule_create_rate_limit_per_minute ?? 20);
        setInputById('setting-schedule-run-rate-limit-per-minute', s.schedule_run_rate_limit_per_minute ?? 10);
        setInputById('setting-report-generate-rate-limit-per-minute', s.report_generate_rate_limit_per_minute ?? 10);
        // Agent Communication Rate Limits
        setInputById('setting-agent-heartbeat-rate-limit-per-minute', s.agent_heartbeat_rate_limit_per_minute ?? 30);
        setInputById('setting-agent-command-poll-rate-limit-per-minute', s.agent_command_poll_rate_limit_per_minute ?? 20);
        setInputById('setting-agent-registration-rate-limit-per-minute', s.agent_registration_rate_limit_per_minute ?? 5);
        // Audit Execution Rate Limits
        setInputById('setting-audit-start-rate-limit-per-minute', s.audit_start_rate_limit_per_minute ?? 10);
        setInputById('setting-audit-status-rate-limit-per-minute', s.audit_status_rate_limit_per_minute ?? 60);
        setInputById('setting-agent-max-concurrent-audits', s.agent_max_concurrent_audits ?? 1);
        setInputById('setting-agent-audit-timeout', s.agent_audit_timeout ?? 3600);
        setInputById('setting-agent-command-batch-size', s.agent_command_batch_size ?? 5);
        setInputById('setting-agent-batch-delay', s.agent_batch_delay ?? 5);
        setInputById('setting-agent-heartbeat-interval', s.agent_heartbeat_interval ?? 30);
        setInputById('setting-agent-poll-interval', s.agent_poll_interval ?? 60);

        // Log Retention
        setInputById('setting-log-max-bytes', s.log_max_bytes ?? 20971520);
        setInputById('setting-log-backup-count', s.log_backup_count ?? 14);
        setSelectById('setting-log-rotation-when', s.log_rotation_when || 'midnight');
        setInputById('setting-log-rotation-interval', s.log_rotation_interval ?? 1);
        setInputById('setting-execution-log-retention-days', s.execution_log_retention_days ?? 14);
        setInputById('setting-execution-log-max-files', s.execution_log_max_files ?? 14);

        setSecuritySettingsDirty(false);

        await loadSecurityDiagnostics();

    } catch (error) {
        console.error('Error loading security settings:', error);
    }
}

async function loadSecurityDiagnostics() {
    const statusEl = document.getElementById('security-diagnostics-status');

    const setDiagValue = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    };

    const setDiagSeverity = (id, severity) => {
        const el = document.getElementById(id);
        if (!el) return;

        if (severity === 'danger') {
            el.style.color = 'var(--danger-color)';
            el.style.fontWeight = '600';
            return;
        }

        if (severity === 'warning') {
            el.style.color = 'var(--warning-color)';
            el.style.fontWeight = '600';
            return;
        }

        if (severity === 'success') {
            el.style.color = 'var(--success-color)';
            el.style.fontWeight = '600';
            return;
        }

        el.style.color = '';
        el.style.fontWeight = '';
    };

    try {
        if (statusEl) {
            statusEl.textContent = 'Loading diagnostics...';
        }

        const response = await adminFetch('/api/admin/security-settings/diagnostics');
        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.error || 'Failed to load security diagnostics');
        }

        const limits = data.diagnostics?.effective_upload_limits || {};
        const guardrails = data.diagnostics?.storage_guardrails || {};
        const secrets = data.diagnostics?.secrets || {};
        updateSecuritySecretsBanner(secrets);
        setDiagValue('security-diagnostics-tier', limits.tier || '-');
        setDiagValue('security-diagnostics-standalone', limits.standalone || '-');
        setDiagValue('security-diagnostics-managed', limits.managed || '-');
        setDiagValue('security-diagnostics-hypervisor', limits.hypervisor || '-');
        setDiagValue('security-diagnostics-asset-discovery', limits.asset_discovery || '-');
        setDiagValue('security-diagnostics-retention-days', guardrails.result_retention_days ?? '-');
        setDiagValue('security-diagnostics-retention-max-records', guardrails.result_retention_max_records ?? '-');
        setDiagValue('security-diagnostics-hypervisor-retention-days', guardrails.hypervisor_result_retention_days ?? '-');
        setDiagValue('security-diagnostics-hypervisor-retention-max-records', guardrails.hypervisor_result_retention_max_records ?? '-');
        setDiagValue('security-diagnostics-report-artifact-retention-days', guardrails.report_artifact_retention_days ?? '-');
        setDiagValue('security-diagnostics-report-artifact-max-files', guardrails.report_artifact_max_files ?? '-');
        setDiagValue('security-diagnostics-cleanup-old-executions-enabled',
            guardrails.cleanup_old_executions_enabled === undefined
                ? '-'
                : (guardrails.cleanup_old_executions_enabled ? 'Enabled' : 'Disabled'));
        setDiagValue(
            'security-diagnostics-cleanup-old-executions-interval',
            guardrails.cleanup_old_executions_interval_minutes !== undefined
                ? `${guardrails.cleanup_old_executions_interval_minutes} min`
                : '-'
        );
        setDiagValue('security-diagnostics-cleanup-analytics-history-enabled',
            guardrails.cleanup_analytics_history_enabled === undefined
                ? '-'
                : (guardrails.cleanup_analytics_history_enabled ? 'Enabled' : 'Disabled'));
        setDiagValue(
            'security-diagnostics-cleanup-analytics-history-interval',
            guardrails.cleanup_analytics_history_interval_minutes !== undefined
                ? `${guardrails.cleanup_analytics_history_interval_minutes} min`
                : '-'
        );
        setDiagValue('security-diagnostics-postgres-maintenance-enabled',
            guardrails.postgres_maintenance_enabled === undefined
                ? '-'
                : (guardrails.postgres_maintenance_enabled ? 'Enabled' : 'Disabled'));
        setDiagValue(
            'security-diagnostics-postgres-maintenance-interval',
            guardrails.postgres_maintenance_interval_minutes !== undefined
                ? `${guardrails.postgres_maintenance_interval_minutes} min`
                : '-'
        );
        setDiagValue('security-diagnostics-agent-local-files-per-target', guardrails.agent_local_result_max_files ?? '-');
        if (
            guardrails.agent_local_min_free_disk_mb !== undefined ||
            guardrails.agent_local_min_free_disk_pct !== undefined
        ) {
            setDiagValue(
                'security-diagnostics-agent-local-min-free-disk',
                `${guardrails.agent_local_min_free_disk_mb ?? '-'} MB / ${guardrails.agent_local_min_free_disk_pct ?? '-'}%`
            );
        } else {
            setDiagValue('security-diagnostics-agent-local-min-free-disk', '-');
        }
        setDiagValue('security-diagnostics-standalone-files-per-host', guardrails.standalone_agent_result_max_files_per_host ?? '-');
        setDiagValue('security-diagnostics-managed-files-per-host', guardrails.fleet_agent_result_max_files_per_host ?? '-');
        setDiagValue('security-diagnostics-disk-guard-enabled',
            guardrails.agent_result_ingest_disk_guard_enabled === undefined
                ? '-'
                : (guardrails.agent_result_ingest_disk_guard_enabled ? 'Enabled' : 'Disabled'));

        if (
            guardrails.agent_result_ingest_min_free_disk_mb !== undefined ||
            guardrails.agent_result_ingest_min_free_disk_pct !== undefined
        ) {
            setDiagValue(
                'security-diagnostics-min-free-disk',
                `${guardrails.agent_result_ingest_min_free_disk_mb ?? '-'} MB / ${guardrails.agent_result_ingest_min_free_disk_pct ?? '-'}%`
            );
        } else {
            setDiagValue('security-diagnostics-min-free-disk', '-');
        }

        setDiagValue('security-diagnostics-backup-retention-days', guardrails.backup_retention_days ?? '-');
        setDiagValue('security-diagnostics-backup-keep-count', guardrails.backup_keep_count ?? '-');
        setDiagValue(
            'security-diagnostics-backup-max-size',
            guardrails.backup_max_size_mb !== undefined ? `${guardrails.backup_max_size_mb} MB` : '-'
        );
        setDiagValue(
            'security-diagnostics-backup-include-shared-data',
            guardrails.backup_include_shared_data === undefined
                ? '-'
                : (guardrails.backup_include_shared_data ? 'Enabled' : 'Disabled')
        );
        setDiagValue(
            'security-diagnostics-backup-shared-data-paths',
            guardrails.backup_shared_data_paths || '-'
        );

        const retentionDays = Number(guardrails.result_retention_days);
        if (!Number.isNaN(retentionDays)) {
            setDiagSeverity(
                'security-diagnostics-retention-days',
                retentionDays < 14 ? 'danger' : retentionDays < 30 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-retention-days', null);
        }

        const retentionMaxRecords = Number(guardrails.result_retention_max_records);
        if (!Number.isNaN(retentionMaxRecords)) {
            setDiagSeverity(
                'security-diagnostics-retention-max-records',
                retentionMaxRecords === 0 ? 'warning' : retentionMaxRecords < 10000 ? 'success' : 'warning'
            );
        } else {
            setDiagSeverity('security-diagnostics-retention-max-records', null);
        }

        const reportArtifactRetentionDays = Number(guardrails.report_artifact_retention_days);
        if (!Number.isNaN(reportArtifactRetentionDays)) {
            setDiagSeverity(
                'security-diagnostics-report-artifact-retention-days',
                reportArtifactRetentionDays < 14 ? 'danger' : reportArtifactRetentionDays < 30 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-report-artifact-retention-days', null);
        }

        const hypervisorRetentionDays = Number(guardrails.hypervisor_result_retention_days);
        if (!Number.isNaN(hypervisorRetentionDays)) {
            setDiagSeverity(
                'security-diagnostics-hypervisor-retention-days',
                hypervisorRetentionDays < 14 ? 'danger' : hypervisorRetentionDays < 30 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-hypervisor-retention-days', null);
        }

        const hypervisorRetentionMaxRecords = Number(guardrails.hypervisor_result_retention_max_records);
        if (!Number.isNaN(hypervisorRetentionMaxRecords)) {
            setDiagSeverity(
                'security-diagnostics-hypervisor-retention-max-records',
                hypervisorRetentionMaxRecords === 0 ? 'warning' : hypervisorRetentionMaxRecords < 10000 ? 'success' : 'warning'
            );
        } else {
            setDiagSeverity('security-diagnostics-hypervisor-retention-max-records', null);
        }

        const reportArtifactMaxFiles = Number(guardrails.report_artifact_max_files);
        if (!Number.isNaN(reportArtifactMaxFiles)) {
            setDiagSeverity(
                'security-diagnostics-report-artifact-max-files',
                reportArtifactMaxFiles === 0 ? 'warning' : reportArtifactMaxFiles > 200000 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-report-artifact-max-files', null);
        }

        if (guardrails.cleanup_old_executions_enabled === undefined) {
            setDiagSeverity('security-diagnostics-cleanup-old-executions-enabled', null);
        } else {
            setDiagSeverity(
                'security-diagnostics-cleanup-old-executions-enabled',
                guardrails.cleanup_old_executions_enabled ? 'success' : 'danger'
            );
        }

        const cleanupOldExecutionsInterval = Number(guardrails.cleanup_old_executions_interval_minutes);
        if (!Number.isNaN(cleanupOldExecutionsInterval)) {
            setDiagSeverity(
                'security-diagnostics-cleanup-old-executions-interval',
                cleanupOldExecutionsInterval < 30 ? 'warning' : cleanupOldExecutionsInterval > 4320 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-cleanup-old-executions-interval', null);
        }

        if (guardrails.cleanup_analytics_history_enabled === undefined) {
            setDiagSeverity('security-diagnostics-cleanup-analytics-history-enabled', null);
        } else {
            setDiagSeverity(
                'security-diagnostics-cleanup-analytics-history-enabled',
                guardrails.cleanup_analytics_history_enabled ? 'success' : 'danger'
            );
        }

        const cleanupAnalyticsInterval = Number(guardrails.cleanup_analytics_history_interval_minutes);
        if (!Number.isNaN(cleanupAnalyticsInterval)) {
            setDiagSeverity(
                'security-diagnostics-cleanup-analytics-history-interval',
                cleanupAnalyticsInterval < 30 ? 'warning' : cleanupAnalyticsInterval > 4320 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-cleanup-analytics-history-interval', null);
        }

        if (guardrails.postgres_maintenance_enabled === undefined) {
            setDiagSeverity('security-diagnostics-postgres-maintenance-enabled', null);
        } else {
            setDiagSeverity(
                'security-diagnostics-postgres-maintenance-enabled',
                guardrails.postgres_maintenance_enabled ? 'success' : 'danger'
            );
        }

        const postgresMaintenanceInterval = Number(guardrails.postgres_maintenance_interval_minutes);
        if (!Number.isNaN(postgresMaintenanceInterval)) {
            setDiagSeverity(
                'security-diagnostics-postgres-maintenance-interval',
                postgresMaintenanceInterval < 30 ? 'warning' : postgresMaintenanceInterval > 1440 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-postgres-maintenance-interval', null);
        }

        const standaloneFilesPerHost = Number(guardrails.standalone_agent_result_max_files_per_host);
        if (!Number.isNaN(standaloneFilesPerHost)) {
            setDiagSeverity(
                'security-diagnostics-standalone-files-per-host',
                standaloneFilesPerHost === 0 ? 'warning' : standaloneFilesPerHost > 20000 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-standalone-files-per-host', null);
        }

        const managedFilesPerHost = Number(guardrails.fleet_agent_result_max_files_per_host);
        if (!Number.isNaN(managedFilesPerHost)) {
            setDiagSeverity(
                'security-diagnostics-managed-files-per-host',
                managedFilesPerHost === 0 ? 'warning' : managedFilesPerHost > 20000 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-managed-files-per-host', null);
        }

        const agentLocalFilesPerTarget = Number(guardrails.agent_local_result_max_files);
        if (!Number.isNaN(agentLocalFilesPerTarget)) {
            setDiagSeverity(
                'security-diagnostics-agent-local-files-per-target',
                agentLocalFilesPerTarget === 0 ? 'warning' : agentLocalFilesPerTarget > 20000 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-agent-local-files-per-target', null);
        }

        const agentLocalMinFreeDiskMb = Number(guardrails.agent_local_min_free_disk_mb);
        const agentLocalMinFreeDiskPct = Number(guardrails.agent_local_min_free_disk_pct);
        if (!Number.isNaN(agentLocalMinFreeDiskMb) || !Number.isNaN(agentLocalMinFreeDiskPct)) {
            let localDiskSeverity = 'success';
            if ((!Number.isNaN(agentLocalMinFreeDiskMb) && agentLocalMinFreeDiskMb < 256) || (!Number.isNaN(agentLocalMinFreeDiskPct) && agentLocalMinFreeDiskPct < 2)) {
                localDiskSeverity = 'danger';
            } else if ((!Number.isNaN(agentLocalMinFreeDiskMb) && agentLocalMinFreeDiskMb < 512) || (!Number.isNaN(agentLocalMinFreeDiskPct) && agentLocalMinFreeDiskPct < 3)) {
                localDiskSeverity = 'warning';
            }
            setDiagSeverity('security-diagnostics-agent-local-min-free-disk', localDiskSeverity);
        } else {
            setDiagSeverity('security-diagnostics-agent-local-min-free-disk', null);
        }

        if (guardrails.agent_result_ingest_disk_guard_enabled === undefined) {
            setDiagSeverity('security-diagnostics-disk-guard-enabled', null);
        } else {
            setDiagSeverity(
                'security-diagnostics-disk-guard-enabled',
                guardrails.agent_result_ingest_disk_guard_enabled ? 'success' : 'danger'
            );
        }

        const minFreeDiskMb = Number(guardrails.agent_result_ingest_min_free_disk_mb);
        const minFreeDiskPct = Number(guardrails.agent_result_ingest_min_free_disk_pct);
        if (!Number.isNaN(minFreeDiskMb) || !Number.isNaN(minFreeDiskPct)) {
            let minFreeDiskSeverity = 'success';
            if ((!Number.isNaN(minFreeDiskMb) && minFreeDiskMb < 1024) || (!Number.isNaN(minFreeDiskPct) && minFreeDiskPct < 5)) {
                minFreeDiskSeverity = 'danger';
            } else if ((!Number.isNaN(minFreeDiskMb) && minFreeDiskMb < 2048) || (!Number.isNaN(minFreeDiskPct) && minFreeDiskPct < 8)) {
                minFreeDiskSeverity = 'warning';
            }
            setDiagSeverity('security-diagnostics-min-free-disk', minFreeDiskSeverity);
        } else {
            setDiagSeverity('security-diagnostics-min-free-disk', null);
        }

        const backupRetentionDays = Number(guardrails.backup_retention_days);
        if (!Number.isNaN(backupRetentionDays)) {
            setDiagSeverity(
                'security-diagnostics-backup-retention-days',
                backupRetentionDays < 7 ? 'danger' : backupRetentionDays < 30 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-backup-retention-days', null);
        }

        const backupKeepCount = Number(guardrails.backup_keep_count);
        if (!Number.isNaN(backupKeepCount)) {
            setDiagSeverity(
                'security-diagnostics-backup-keep-count',
                backupKeepCount < 2 ? 'danger' : backupKeepCount < 5 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-backup-keep-count', null);
        }

        const backupMaxSizeMb = Number(guardrails.backup_max_size_mb);
        if (!Number.isNaN(backupMaxSizeMb)) {
            setDiagSeverity(
                'security-diagnostics-backup-max-size',
                backupMaxSizeMb > 10000 ? 'danger' : backupMaxSizeMb > 5000 || backupMaxSizeMb < 200 ? 'warning' : 'success'
            );
        } else {
            setDiagSeverity('security-diagnostics-backup-max-size', null);
        }

        if (guardrails.backup_include_shared_data === undefined) {
            setDiagSeverity('security-diagnostics-backup-include-shared-data', null);
        } else {
            setDiagSeverity(
                'security-diagnostics-backup-include-shared-data',
                guardrails.backup_include_shared_data ? 'success' : 'warning'
            );
        }

        const sharedDataPaths = String(guardrails.backup_shared_data_paths || '').trim();
        if (!sharedDataPaths) {
            setDiagSeverity('security-diagnostics-backup-shared-data-paths', 'warning');
        } else {
            setDiagSeverity('security-diagnostics-backup-shared-data-paths', 'success');
        }

        // Log Retention
        setDiagValue(
            'security-diagnostics-log-max-bytes',
            guardrails.log_max_bytes !== undefined
                ? `${(guardrails.log_max_bytes / (1024 * 1024)).toFixed(1)} MB (${guardrails.log_max_bytes} bytes)`
                : '-'
        );
        setDiagValue('security-diagnostics-log-backup-count', guardrails.log_backup_count ?? '-');
        setDiagValue('security-diagnostics-log-rotation-when', guardrails.log_rotation_when || '-');
        setDiagValue('security-diagnostics-log-rotation-interval', guardrails.log_rotation_interval ?? '-');
        setDiagValue(
            'security-diagnostics-execution-log-retention-days',
            guardrails.execution_log_retention_days !== undefined
                ? `${guardrails.execution_log_retention_days} days`
                : '-'
        );
        setDiagValue(
            'security-diagnostics-execution-log-max-files',
            guardrails.execution_log_max_files !== undefined
                ? (guardrails.execution_log_max_files === 0 ? 'Unlimited' : String(guardrails.execution_log_max_files))
                : '-'
        );
        const logMaxBytes = Number(guardrails.log_max_bytes);
        if (!Number.isNaN(logMaxBytes)) {
            setDiagSeverity(
                'security-diagnostics-log-max-bytes',
                logMaxBytes < 5242880 ? 'warning' : logMaxBytes > 209715200 ? 'warning' : 'success'
            );
        }
        const logBackupCount = Number(guardrails.log_backup_count);
        if (!Number.isNaN(logBackupCount)) {
            setDiagSeverity(
                'security-diagnostics-log-backup-count',
                logBackupCount < 3 ? 'warning' : 'success'
            );
        }
        const execLogRetentionDays = Number(guardrails.execution_log_retention_days);
        if (!Number.isNaN(execLogRetentionDays)) {
            setDiagSeverity(
                'security-diagnostics-execution-log-retention-days',
                execLogRetentionDays < 7 ? 'warning' : 'success'
            );
        }

        if (statusEl) {
            statusEl.textContent = `Updated ${new Date().toLocaleTimeString()}`;
        }
    } catch (error) {
        console.error('Error loading security diagnostics:', error);
        if (statusEl) {
            statusEl.textContent = `Diagnostics unavailable: ${error.message}`;
        }
    }
}

function updateSecuritySecretsBanner(secrets) {
    const banner = document.getElementById('security-secrets-banner');
    if (!banner) {
        return;
    }

    const isProduction = !!secrets.is_production;
    const flaskSecretSet = !!secrets.flask_secret_key_set;
    const dbKeySet = !!secrets.db_field_encryption_key_set;
    const hardeningRequired = secrets.production_hardening_required !== false;

    const missingItems = [];
    if (!flaskSecretSet) missingItems.push('FLASK_SECRET_KEY');
    if (!dbKeySet) missingItems.push('DB_FIELD_ENCRYPTION_KEY');
    if (!hardeningRequired) missingItems.push('PRODUCTION_HARDENING_REQUIRED=true');

    if (isProduction && missingItems.length > 0) {
        banner.className = 'security-secrets-banner warning';
        banner.style.display = 'flex';
        banner.innerHTML = `
            <span>⚠️</span>
            <div>
                <strong>Production secrets required.</strong>
                Missing: ${escapeHtml(missingItems.join(', '))}. Run <code>scripts/setup-secrets</code> or set env vars.
            </div>
        `;
        return;
    }

    if (isProduction) {
        banner.className = 'security-secrets-banner success';
        banner.style.display = 'flex';
        banner.innerHTML = `
            <span>✅</span>
            <div>
                <strong>Production secrets configured.</strong>
                Startup hardening checks are enabled.
            </div>
        `;
        return;
    }

    if (missingItems.length > 0) {
        banner.className = 'security-secrets-banner info';
        banner.style.display = 'flex';
        banner.innerHTML = `
            <span>ℹ️</span>
            <div>
                <strong>Secrets not set (dev mode).</strong>
                Before production, set: ${escapeHtml(missingItems.join(', '))}.
            </div>
        `;
        return;
    }

    banner.style.display = 'none';
}

function setCheckboxById(id, value) {
    const el = document.getElementById(id);
    if (el) el.checked = !!value;
}

function setInputById(id, value) {
    const el = document.getElementById(id);
    if (el) el.value = value;
}

function setSelectById(id, value) {
    const el = document.getElementById(id);
    if (el) el.value = value;
}

function setSecuritySettingsDirty(isDirty) {
    securitySettingsDirty = !!isDirty;
    const indicator = document.getElementById('security-settings-dirty-indicator');
    if (!indicator) {
        return;
    }

    indicator.style.display = securitySettingsDirty ? 'inline-flex' : 'none';
    indicator.className = securitySettingsDirty ? 'settings-status' : 'settings-status';
}

function bindSecuritySettingsBeforeUnloadGuard() {
    if (window.__securitySettingsBeforeUnloadBound) {
        return;
    }

    window.addEventListener('beforeunload', (event) => {
        if (!securitySettingsDirty) {
            return;
        }

        event.preventDefault();
        event.returnValue = '';
    });

    window.__securitySettingsBeforeUnloadBound = true;
}

async function saveSecuritySettings() {
    const statusEl = document.getElementById('security-settings-status');
    const saveBtn = document.getElementById('save-security-settings');

    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving...';
    }

    const persistedSettings = loadedSecuritySettings || {};

    const settings = {
        // Authentication & Access
        session_timeout: parseInt(document.getElementById('setting-session-timeout')?.value) || 30,
        max_login_attempts: parseInt(document.getElementById('setting-max-login-attempts')?.value) || 5,
        lockout_duration: parseInt(document.getElementById('setting-lockout-duration')?.value) || 15,
        enforce_2fa: document.getElementById('setting-enforce-2fa')?.checked || false,

        // Password Policy
        password_min_length: parseInt(document.getElementById('setting-password-min-length')?.value) || 12,
        password_uppercase: document.getElementById('setting-password-uppercase')?.checked || false,
        password_numbers: document.getElementById('setting-password-numbers')?.checked || false,
        password_special: document.getElementById('setting-password-special')?.checked || false,
        password_expiry: parseInt(document.getElementById('setting-password-expiry')?.value) || 90,
        password_history: parseInt(document.getElementById('setting-password-history')?.value) || 5,

        // Audit Execution
        audit_timeout: parseInt(document.getElementById('setting-audit-timeout')?.value) || 300,
        result_retention: parseInt(document.getElementById('setting-result-retention')?.value) || 90,
        result_retention_max_records: parseInt(document.getElementById('setting-result-retention-max-records')?.value) ?? 100000,
        hypervisor_result_retention_days: parseInt(document.getElementById('setting-hypervisor-result-retention-days')?.value) ?? 90,
        hypervisor_result_retention_max_records: parseInt(document.getElementById('setting-hypervisor-result-retention-max-records')?.value) ?? 100000,
        report_artifact_retention_days: parseInt(document.getElementById('setting-report-artifact-retention-days')?.value) ?? 90,
        report_artifact_max_files: parseInt(document.getElementById('setting-report-artifact-max-files')?.value) ?? 10000,
        evidence_retention_enabled: document.getElementById('setting-evidence-retention-enabled')?.checked ?? true,
        evidence_retention_days: Math.max(1, parseInt(document.getElementById('setting-evidence-retention-days')?.value) || 30),
        cleanup_old_executions_enabled: document.getElementById('setting-cleanup-old-executions-enabled')?.checked ?? true,
        cleanup_old_executions_interval_minutes: parseInt(document.getElementById('setting-cleanup-old-executions-interval-minutes')?.value) ?? 1440,
        cleanup_analytics_history_enabled: document.getElementById('setting-cleanup-analytics-history-enabled')?.checked ?? true,
        cleanup_analytics_history_interval_minutes: parseInt(document.getElementById('setting-cleanup-analytics-history-interval-minutes')?.value) ?? 1440,
        postgres_maintenance_interval_minutes: parseInt(document.getElementById('setting-postgres-maintenance-interval-minutes')?.value) ?? 360,

        // User Management Defaults
        default_role: document.getElementById('setting-default-role')?.value || 'Viewer',
        auto_approve_users: document.getElementById('setting-auto-approve-users')?.checked || false,
        self_registration: document.getElementById('setting-self-registration')?.checked || false,
        max_users: parseInt(document.getElementById('setting-max-users')?.value) || 0,

        // Maintenance
        maintenance_mode: document.getElementById('setting-maintenance-mode')?.checked || false,
        maintenance_message: document.getElementById('setting-maintenance-message')?.value || '',

        // Network & Security
        ip_whitelist: document.getElementById('setting-ip-whitelist')?.value || '',
        ip_blacklist: document.getElementById('setting-ip-blacklist')?.value || '',
        enforce_https: document.getElementById('setting-enforce-https')?.checked || false,
        tls_minimum_version_toolkit: document.getElementById('setting-tls-minimum-version-toolkit')?.value || 'TLSv1_3',
        tls_minimum_version_external: document.getElementById('setting-tls-minimum-version-external')?.value || 'TLSv1_2',
        tls_maximum_version: document.getElementById('setting-tls-maximum-version')?.value || 'TLSv1_3',
        tls_certificate_verification: document.getElementById('setting-tls-certificate-verification')?.checked ?? true,
        tls_strict_mode: document.getElementById('setting-tls-strict-mode')?.checked || false,
        tls_log_version: document.getElementById('setting-tls-log-version')?.checked ?? true,
        tls_cipher_suites: document.getElementById('setting-tls-cipher-suites')?.value || 'ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!DSS:!RC4:!DES',

        // Critical Hardening Controls
        backup_encrypt: document.getElementById('setting-security-backup-encrypt')?.checked || false,
        backup_compress: document.getElementById('setting-security-backup-compress')?.checked ?? true,
        backup_auto_enabled: document.getElementById('setting-security-backup-auto-enabled')?.checked || false,
        backup_retention_days: parseInt(document.getElementById('setting-security-backup-retention-days')?.value) ?? 30,
        backup_keep_count: parseInt(document.getElementById('setting-security-backup-keep-count')?.value) ?? 10,
        backup_max_size: parseInt(document.getElementById('setting-security-backup-max-size')?.value) ?? 500,
        backup_schedule: document.getElementById('setting-security-backup-schedule')?.value || 'daily',
        backup_include_shared_data: document.getElementById('setting-backup-include-shared-data')?.checked ?? true,
        backup_shared_data_paths: document.getElementById('setting-backup-shared-data-paths')?.value || '/opt/audit-toolkit/data/agents,/opt/audit-toolkit/shared/asset-discovery-data,/opt/audit-toolkit/shared/asset-discovery-logs',
        agent_tls_verify: document.getElementById('setting-agent-tls-verify')?.checked ?? true,
        agent_tls_pinning_enabled: document.getElementById('setting-agent-tls-pinning-enabled')?.checked || false,
        agent_tls_pinned_cert_hash: document.getElementById('setting-agent-tls-pinned-cert-hash')?.value || '',
        agent_encrypt_keys_at_rest: document.getElementById('setting-agent-encrypt-keys-at-rest')?.checked ?? true,
        fleet_agent_result_encryption_enabled: document.getElementById('setting-fleet-agent-result-encryption-enabled')?.checked || false,
        fleet_agent_result_encryption_algorithm: document.getElementById('setting-fleet-agent-result-encryption-algorithm')?.value || 'fernet-aes128',
        agent_require_approval: document.getElementById('setting-agent-require-approval')?.checked || false,
        agent_auto_approve_known_hosts: document.getElementById('setting-agent-auto-approve-known-hosts')?.checked ?? true,
        agent_api_key_rotation_days: parseInt(document.getElementById('setting-agent-api-key-rotation-days')?.value) ?? 0,
        agent_api_key_grace_period_hours: parseInt(document.getElementById('setting-agent-api-key-grace-period-hours')?.value) ?? 24,
        ssh_host_key_policy: document.getElementById('setting-ssh-host-key-policy')?.value || 'warn',
        fleet_agent_enforce_signed_config: document.getElementById('setting-fleet-agent-enforce-signed-config')?.checked ?? true,
        fleet_agent_config_max_age_seconds: parseInt(document.getElementById('setting-fleet-agent-config-max-age-seconds')?.value) ?? 900,
        fleet_agent_config_signing_key: document.getElementById('setting-fleet-agent-config-signing-key')?.value || '',
        fleet_agent_require_request_signatures: document.getElementById('setting-fleet-agent-require-request-signatures')?.checked || false,
        fleet_agent_request_signature_max_age_seconds: parseInt(document.getElementById('setting-fleet-agent-request-signature-max-age-seconds')?.value) ?? 300,
        fleet_agent_request_signing_key: document.getElementById('setting-fleet-agent-request-signing-key')?.value || '',
        fleet_agent_request_signature_ecdsa_dual_verify_enabled: document.getElementById('setting-fleet-agent-request-signature-ecdsa-dual-verify-enabled')?.checked || false,
        fleet_agent_request_signature_ecdsa_public_key: document.getElementById('setting-fleet-agent-request-signature-ecdsa-public-key')?.value || '',
        fleet_agent_result_encryption_key_derivation: document.getElementById('setting-fleet-agent-result-encryption-key-derivation')?.value || 'agent_id',
        fleet_agent_results_encryption_key_custom: document.getElementById('setting-fleet-agent-results-encryption-key-custom')?.value || '',

        // Advanced (Restart Required)
        rate_limit: parseInt(document.getElementById('setting-rate-limit')?.value) || 100,
        max_concurrent_audits: parseInt(document.getElementById('setting-max-concurrent-audits')?.value) || 5,
        worker_pool_size: parseInt(document.getElementById('setting-worker-pool-size')?.value) || 4,
        log_level: document.getElementById('setting-log-level')?.value || 'INFO',
        cors_origins: document.getElementById('setting-cors-origins')?.value || '',

        // Agent Throttle Settings
        agent_cpu_nice_level: parseInt(document.getElementById('setting-agent-cpu-nice-level')?.value) ?? 19,
        agent_process_priority: document.getElementById('setting-agent-process-priority')?.value || 'Idle',
        agent_io_class: document.getElementById('setting-agent-io-class')?.value || 'idle',
        agent_min_free_memory_pct: parseInt(document.getElementById('setting-agent-min-free-memory-pct')?.value) ?? 10,
        agent_max_load_average: parseFloat(document.getElementById('setting-agent-max-load-average')?.value) ?? 0,
        agent_max_cpu_pct: parseInt(document.getElementById('setting-agent-max-cpu-pct')?.value) ?? 0,
        agent_upload_rate_limit: parseInt(document.getElementById('setting-agent-upload-rate-limit')?.value) ?? 0,
        agent_download_rate_limit: parseInt(document.getElementById('setting-agent-download-rate-limit')?.value) ?? 0,
        agent_local_result_max_files: parseInt(document.getElementById('setting-agent-local-result-max-files')?.value) ?? 1000,
        agent_local_min_free_disk_mb: parseInt(document.getElementById('setting-agent-local-min-free-disk-mb')?.value) ?? 512,
        agent_local_min_free_disk_pct: parseInt(document.getElementById('setting-agent-local-min-free-disk-pct')?.value) ?? 3,
        standalone_agent_results_rate_limit_per_hour: parseInt(document.getElementById('setting-standalone-agent-results-rate-limit-per-hour')?.value) ?? 100,
        fleet_agent_results_rate_limit_per_hour: parseInt(document.getElementById('setting-fleet-agent-results-rate-limit-per-hour')?.value) ?? 200,
        hypervisor_agent_results_rate_limit_per_hour: parseInt(document.getElementById('setting-hypervisor-agent-results-rate-limit-per-hour')?.value) ?? 200,
        asset_discovery_results_rate_limit_per_hour: parseInt(document.getElementById('setting-asset-discovery-results-rate-limit-per-hour')?.value) ?? 200,
        standalone_agent_result_max_files_per_host: parseInt(document.getElementById('setting-standalone-agent-result-max-files-per-host')?.value) ?? 5000,
        fleet_agent_result_max_files_per_host: parseInt(document.getElementById('setting-fleet-agent-result-max-files-per-host')?.value) ?? 5000,
        agent_result_ingest_disk_guard_enabled: document.getElementById('setting-agent-result-ingest-disk-guard-enabled')?.checked ?? true,
        agent_result_ingest_min_free_disk_mb: parseInt(document.getElementById('setting-agent-result-ingest-min-free-disk-mb')?.value) ?? 1024,
        agent_result_ingest_min_free_disk_pct: parseInt(document.getElementById('setting-agent-result-ingest-min-free-disk-pct')?.value) ?? 5,
        agent_result_ingest_max_body_kb: parseInt(persistedSettings.agent_result_ingest_max_body_kb) || 2048,
        agent_result_ingest_max_results_per_request: parseInt(persistedSettings.agent_result_ingest_max_results_per_request) || 100,
        agent_result_ingest_max_checks_per_result: parseInt(persistedSettings.agent_result_ingest_max_checks_per_result) || 500,
        agent_result_ingest_max_output_chars: parseInt(persistedSettings.agent_result_ingest_max_output_chars) || 200000,
        agent_discovery_ingest_max_body_kb: parseInt(persistedSettings.agent_discovery_ingest_max_body_kb) || 2048,
        agent_discovery_ingest_max_items_per_collection: parseInt(persistedSettings.agent_discovery_ingest_max_items_per_collection) || 5000,
        agent_discovery_ingest_max_total_items: parseInt(persistedSettings.agent_discovery_ingest_max_total_items) || 50000,
        history_summary_retention_days: parseInt(persistedSettings.history_summary_retention_days) || 365,
        compliance_history_retention_days: parseInt(persistedSettings.compliance_history_retention_days) || 365,
        postgres_database_size_warn_mb: parseInt(persistedSettings.postgres_database_size_warn_mb) || 10240,
        postgres_database_size_critical_mb: parseInt(persistedSettings.postgres_database_size_critical_mb) || 20480,
        postgres_table_size_warn_mb: parseInt(persistedSettings.postgres_table_size_warn_mb) || 2048,
        postgres_maintenance_enabled: persistedSettings.postgres_maintenance_enabled ?? true,
        postgres_maintenance_vacuum_analyze_enabled: persistedSettings.postgres_maintenance_vacuum_analyze_enabled ?? true,
        server_tls_certificate_chain_installed: persistedSettings.server_tls_certificate_chain_installed ?? false,
        server_tls_certificate_source: persistedSettings.server_tls_certificate_source || '',
        server_tls_certificate_last_updated: persistedSettings.server_tls_certificate_last_updated || '',
        server_tls_certificate_subject: persistedSettings.server_tls_certificate_subject || '',
        server_tls_certificate_issuer: persistedSettings.server_tls_certificate_issuer || '',
        server_tls_certificate_not_before: persistedSettings.server_tls_certificate_not_before || '',
        server_tls_certificate_not_after: persistedSettings.server_tls_certificate_not_after || '',
        server_tls_certificate_fingerprint_sha256: persistedSettings.server_tls_certificate_fingerprint_sha256 || '',
        server_tls_runtime_apply_status: persistedSettings.server_tls_runtime_apply_status || '',
        server_tls_runtime_apply_message: persistedSettings.server_tls_runtime_apply_message || '',
        server_tls_runtime_last_attempt_at: persistedSettings.server_tls_runtime_last_attempt_at || '',
        // Asset Discovery Service Rate Limits
        asset_discovery_api_rate_limit_per_minute: parseInt(document.getElementById('setting-asset-discovery-api-rate-limit-per-minute')?.value) ?? 100,
        asset_discovery_scan_rate_limit_per_minute: parseInt(document.getElementById('setting-asset-discovery-scan-rate-limit-per-minute')?.value) ?? 20,
        asset_discovery_cve_sync_rate_limit_per_minute: parseInt(document.getElementById('setting-asset-discovery-cve-sync-rate-limit-per-minute')?.value) ?? 10,
        asset_discovery_dashboard_rate_limit_per_minute: parseInt(document.getElementById('setting-asset-discovery-dashboard-rate-limit-per-minute')?.value) ?? 60,
        // Authentication Rate Limits
        auth_login_rate_limit_per_minute: parseInt(document.getElementById('setting-auth-login-rate-limit-per-minute')?.value) ?? 5,
        auth_password_reset_rate_limit_per_minute: parseInt(document.getElementById('setting-auth-password-reset-rate-limit-per-minute')?.value) ?? 3,
        auth_registration_rate_limit_per_minute: parseInt(document.getElementById('setting-auth-registration-rate-limit-per-minute')?.value) ?? 5,
        auth_2fa_rate_limit_per_minute: parseInt(document.getElementById('setting-auth-2fa-rate-limit-per-minute')?.value) ?? 10,
        // API Operation Rate Limits
        api_general_rate_limit_per_minute: parseInt(document.getElementById('setting-api-general-rate-limit-per-minute')?.value) ?? 100,
        api_write_rate_limit_per_minute: parseInt(document.getElementById('setting-api-write-rate-limit-per-minute')?.value) ?? 30,
        api_export_rate_limit_per_minute: parseInt(document.getElementById('setting-api-export-rate-limit-per-minute')?.value) ?? 10,
        api_import_rate_limit_per_minute: parseInt(document.getElementById('setting-api-import-rate-limit-per-minute')?.value) ?? 5,
        api_search_rate_limit_per_minute: parseInt(document.getElementById('setting-api-search-rate-limit-per-minute')?.value) ?? 60,
        analytics_max_result_set_size: parseInt(document.getElementById('setting-analytics-max-result-set-size')?.value) ?? 10000,
        // Scheduled Operations Rate Limits
        schedule_list_rate_limit_per_minute: parseInt(document.getElementById('setting-schedule-list-rate-limit-per-minute')?.value) ?? 100,
        schedule_create_rate_limit_per_minute: parseInt(document.getElementById('setting-schedule-create-rate-limit-per-minute')?.value) ?? 20,
        schedule_run_rate_limit_per_minute: parseInt(document.getElementById('setting-schedule-run-rate-limit-per-minute')?.value) ?? 10,
        report_generate_rate_limit_per_minute: parseInt(document.getElementById('setting-report-generate-rate-limit-per-minute')?.value) ?? 10,
        // Agent Communication Rate Limits
        agent_heartbeat_rate_limit_per_minute: parseInt(document.getElementById('setting-agent-heartbeat-rate-limit-per-minute')?.value) ?? 30,
        agent_command_poll_rate_limit_per_minute: parseInt(document.getElementById('setting-agent-command-poll-rate-limit-per-minute')?.value) ?? 20,
        agent_registration_rate_limit_per_minute: parseInt(document.getElementById('setting-agent-registration-rate-limit-per-minute')?.value) ?? 5,
        // Audit Execution Rate Limits
        audit_start_rate_limit_per_minute: parseInt(document.getElementById('setting-audit-start-rate-limit-per-minute')?.value) ?? 10,
        audit_status_rate_limit_per_minute: parseInt(document.getElementById('setting-audit-status-rate-limit-per-minute')?.value) ?? 60,
        agent_max_concurrent_audits: parseInt(document.getElementById('setting-agent-max-concurrent-audits')?.value) ?? 1,
        agent_audit_timeout: parseInt(document.getElementById('setting-agent-audit-timeout')?.value) ?? 3600,
        agent_command_batch_size: parseInt(document.getElementById('setting-agent-command-batch-size')?.value) ?? 5,
        agent_batch_delay: parseInt(document.getElementById('setting-agent-batch-delay')?.value) ?? 5,
        agent_heartbeat_interval: parseInt(document.getElementById('setting-agent-heartbeat-interval')?.value) ?? 30,
        agent_poll_interval: parseInt(document.getElementById('setting-agent-poll-interval')?.value) ?? 60,
        // Log Retention
        log_max_bytes: parseInt(document.getElementById('setting-log-max-bytes')?.value) || 20971520,
        log_backup_count: parseInt(document.getElementById('setting-log-backup-count')?.value) || 14,
        log_rotation_when: document.getElementById('setting-log-rotation-when')?.value || 'midnight',
        log_rotation_interval: parseInt(document.getElementById('setting-log-rotation-interval')?.value) || 1,
        execution_log_retention_days: parseInt(document.getElementById('setting-execution-log-retention-days')?.value) || 14,
        execution_log_max_files: (() => {
            const value = parseInt(document.getElementById('setting-execution-log-max-files')?.value, 10);
            return Number.isNaN(value) ? 14 : value;
        })(),
    };

    try {
        const response = await adminFetch('/api/admin/security-settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ settings })
        });

        const data = await response.json();

        if (response.ok) {
            if (statusEl) {
                statusEl.textContent = '✅ Settings saved successfully';
                statusEl.className = 'settings-status success';
                setTimeout(() => { statusEl.textContent = ''; }, 3000);
            }
            setSecuritySettingsDirty(false);
            await loadSecurityDiagnostics();
        } else {
            throw new Error(data.error || 'Failed to save settings');
        }
    } catch (error) {
        console.error('Error saving security settings:', error);
        if (statusEl) {
            statusEl.textContent = '❌ ' + error.message;
            statusEl.className = 'settings-status error';
        }
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.textContent = '💾 Save Settings';
        }
    }
}

function resetSecuritySettings() {
    if (!confirm('Reset all security settings to their default values?')) return;

    // Authentication & Access
    setInputById('setting-session-timeout', 30);
    setInputById('setting-max-login-attempts', 5);
    setInputById('setting-lockout-duration', 15);
    setCheckboxById('setting-enforce-2fa', false);

    // Password Policy
    setInputById('setting-password-min-length', 12);
    setCheckboxById('setting-password-uppercase', true);
    setCheckboxById('setting-password-numbers', true);
    setCheckboxById('setting-password-special', true);
    setInputById('setting-password-expiry', 90);
    setInputById('setting-password-history', 5);

    // Audit Execution
    setInputById('setting-audit-timeout', 300);
    setInputById('setting-result-retention', 90);
    setInputById('setting-result-retention-max-records', 100000);
    setInputById('setting-hypervisor-result-retention-days', 90);
    setInputById('setting-hypervisor-result-retention-max-records', 100000);
    setInputById('setting-report-artifact-retention-days', 90);
    setInputById('setting-report-artifact-max-files', 10000);
    setCheckboxById('setting-cleanup-old-executions-enabled', true);
    setInputById('setting-cleanup-old-executions-interval-minutes', 1440);
    setCheckboxById('setting-cleanup-analytics-history-enabled', true);
    setInputById('setting-cleanup-analytics-history-interval-minutes', 1440);
    setInputById('setting-postgres-maintenance-interval-minutes', 360);

    // User Management Defaults
    setSelectById('setting-default-role', 'Viewer');
    setCheckboxById('setting-auto-approve-users', false);
    setCheckboxById('setting-self-registration', false);
    setInputById('setting-max-users', 0);

    // Maintenance
    setCheckboxById('setting-maintenance-mode', false);
    setInputById('setting-maintenance-message', '');

    // Network & Security
    setInputById('setting-ip-whitelist', '');
    setInputById('setting-ip-blacklist', '');
    setCheckboxById('setting-enforce-https', false);
    setSelectById('setting-tls-minimum-version-toolkit', 'TLSv1_3');
    setSelectById('setting-tls-minimum-version-external', 'TLSv1_2');
    setSelectById('setting-tls-maximum-version', 'TLSv1_3');
    setCheckboxById('setting-tls-certificate-verification', true);
    setCheckboxById('setting-tls-strict-mode', false);
    setCheckboxById('setting-tls-log-version', true);
    setInputById('setting-tls-cipher-suites', 'ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!DSS:!RC4:!DES');

    // Critical Hardening Controls
    setCheckboxById('setting-security-backup-encrypt', false);
    setCheckboxById('setting-security-backup-compress', true);
    setCheckboxById('setting-security-backup-auto-enabled', false);
    setInputById('setting-security-backup-retention-days', 30);
    setInputById('setting-security-backup-keep-count', 10);
    setInputById('setting-security-backup-max-size', 500);
    setSelectById('setting-security-backup-schedule', 'daily');
    setCheckboxById('setting-backup-include-shared-data', true);
    setInputById('setting-backup-shared-data-paths', '/opt/audit-toolkit/data/agents,/opt/audit-toolkit/shared/asset-discovery-data,/opt/audit-toolkit/shared/asset-discovery-logs');
    setCheckboxById('setting-agent-tls-verify', true);
    setCheckboxById('setting-agent-tls-pinning-enabled', false);
    setInputById('setting-agent-tls-pinned-cert-hash', '');
    setCheckboxById('setting-agent-encrypt-keys-at-rest', true);
    setCheckboxById('setting-fleet-agent-result-encryption-enabled', false);
    setSelectById('setting-fleet-agent-result-encryption-algorithm', 'fernet-aes128');
    setCheckboxById('setting-agent-require-approval', false);
    setCheckboxById('setting-agent-auto-approve-known-hosts', true);
    setInputById('setting-agent-api-key-rotation-days', 0);
    setInputById('setting-agent-api-key-grace-period-hours', 24);
    setSelectById('setting-ssh-host-key-policy', 'warn');
    setCheckboxById('setting-fleet-agent-enforce-signed-config', true);
    setInputById('setting-fleet-agent-config-max-age-seconds', 900);
    setInputById('setting-fleet-agent-config-signing-key', '');
    setCheckboxById('setting-fleet-agent-require-request-signatures', false);
    setInputById('setting-fleet-agent-request-signature-max-age-seconds', 300);
    setInputById('setting-fleet-agent-request-signing-key', '');
    setCheckboxById('setting-fleet-agent-request-signature-ecdsa-dual-verify-enabled', false);
    setInputById('setting-fleet-agent-request-signature-ecdsa-public-key', '');
    setSelectById('setting-fleet-agent-result-encryption-key-derivation', 'agent_id');
    setInputById('setting-fleet-agent-results-encryption-key-custom', '');

    // Advanced (Restart Required)
    setInputById('setting-rate-limit', 100);
    setInputById('setting-max-concurrent-audits', 5);
    setInputById('setting-worker-pool-size', 4);
    setSelectById('setting-log-level', 'INFO');
    setInputById('setting-cors-origins', '');

    // Agent Throttle Settings
    setInputById('setting-agent-cpu-nice-level', 19);
    setSelectById('setting-agent-process-priority', 'Idle');
    setSelectById('setting-agent-io-class', 'idle');
    setInputById('setting-agent-min-free-memory-pct', 10);
    setInputById('setting-agent-max-load-average', 0);
    setInputById('setting-agent-max-cpu-pct', 0);
    setInputById('setting-agent-upload-rate-limit', 0);
    setInputById('setting-agent-download-rate-limit', 0);
    setInputById('setting-agent-local-result-max-files', 1000);
    setInputById('setting-agent-local-min-free-disk-mb', 512);
    setInputById('setting-agent-local-min-free-disk-pct', 3);
    setInputById('setting-standalone-agent-results-rate-limit-per-hour', 100);
    setInputById('setting-fleet-agent-results-rate-limit-per-hour', 200);
    setInputById('setting-hypervisor-agent-results-rate-limit-per-hour', 200);
    setInputById('setting-asset-discovery-results-rate-limit-per-hour', 200);
    setInputById('setting-standalone-agent-result-max-files-per-host', 5000);
    setInputById('setting-fleet-agent-result-max-files-per-host', 5000);
    setCheckboxById('setting-agent-result-ingest-disk-guard-enabled', true);
    setInputById('setting-agent-result-ingest-min-free-disk-mb', 1024);
    setInputById('setting-agent-result-ingest-min-free-disk-pct', 5);
    setInputById('setting-agent-max-concurrent-audits', 1);
    setInputById('setting-agent-audit-timeout', 3600);
    setInputById('setting-agent-command-batch-size', 5);
    setInputById('setting-agent-batch-delay', 5);
    setInputById('setting-agent-heartbeat-interval', 30);
    setInputById('setting-agent-poll-interval', 60);

    // Log Retention
    setInputById('setting-log-max-bytes', 20971520);
    setInputById('setting-log-backup-count', 14);
    setSelectById('setting-log-rotation-when', 'midnight');
    setInputById('setting-log-rotation-interval', 1);
    setInputById('setting-execution-log-retention-days', 14);
    setInputById('setting-execution-log-max-files', 14);

    const statusEl = document.getElementById('security-settings-status');
    if (statusEl) {
        statusEl.textContent = '↩️ Settings reset to defaults (not yet saved)';
        statusEl.className = 'settings-status';
    }

    const profileSelector = document.getElementById('security-profile-selector');
    if (profileSelector) {
        profileSelector.value = 'custom';
    }

    setSecuritySettingsDirty(true);
}

const SECURITY_PROFILE_PRESETS = {
    maximum: {
        session_timeout: 15,
        max_login_attempts: 3,
        lockout_duration: 30,
        enforce_2fa: true,
        password_min_length: 14,
        password_uppercase: true,
        password_numbers: true,
        password_special: true,
        password_expiry: 60,
        password_history: 12,
        rate_limit: 50,
        max_concurrent_audits: 3,
        worker_pool_size: 4,
        backup_encrypt: true,
        backup_retention_days: 2555,
        backup_schedule: 'twice_daily',
        agent_require_approval: true,
        agent_auto_approve_known_hosts: false,
        agent_api_key_rotation_days: 90,
        agent_api_key_grace_period_hours: 24,
        agent_tls_verify: true,
        ssh_host_key_policy: 'strict',
        tls_minimum_version_toolkit: 'TLSv1_3',
        tls_minimum_version_external: 'TLSv1_3',
        tls_certificate_verification: true,
        tls_strict_mode: true,
        api_general_rate_limit_per_minute: 50,
        api_write_rate_limit_per_minute: 20,
        api_search_rate_limit_per_minute: 40,
        auth_login_rate_limit_per_minute: 3,
        asset_discovery_api_rate_limit_per_minute: 60,
        asset_discovery_scan_rate_limit_per_minute: 10,
        asset_discovery_cve_sync_rate_limit_per_minute: 5,
        agent_registration_rate_limit_per_minute: 2,
        analytics_max_result_set_size: 10000
    },
    balanced: {
        session_timeout: 30,
        max_login_attempts: 5,
        lockout_duration: 15,
        enforce_2fa: true,
        password_min_length: 12,
        password_uppercase: true,
        password_numbers: true,
        password_special: true,
        password_expiry: 90,
        password_history: 5,
        rate_limit: 100,
        max_concurrent_audits: 5,
        worker_pool_size: 4,
        backup_encrypt: true,
        backup_retention_days: 90,
        backup_schedule: 'daily',
        agent_require_approval: false,
        agent_auto_approve_known_hosts: true,
        agent_api_key_rotation_days: 90,
        agent_api_key_grace_period_hours: 24,
        agent_tls_verify: true,
        ssh_host_key_policy: 'warn',
        tls_minimum_version_toolkit: 'TLSv1_3',
        tls_minimum_version_external: 'TLSv1_2',
        tls_certificate_verification: true,
        tls_strict_mode: false,
        api_general_rate_limit_per_minute: 100,
        api_write_rate_limit_per_minute: 30,
        api_search_rate_limit_per_minute: 60,
        auth_login_rate_limit_per_minute: 5,
        asset_discovery_api_rate_limit_per_minute: 100,
        asset_discovery_scan_rate_limit_per_minute: 20,
        asset_discovery_cve_sync_rate_limit_per_minute: 10,
        agent_registration_rate_limit_per_minute: 5,
        analytics_max_result_set_size: 10000
    },
    ha: {
        session_timeout: 60,
        max_login_attempts: 5,
        lockout_duration: 10,
        enforce_2fa: false,
        password_min_length: 10,
        password_uppercase: true,
        password_numbers: true,
        password_special: false,
        password_expiry: 180,
        password_history: 3,
        rate_limit: 200,
        max_concurrent_audits: 10,
        worker_pool_size: 8,
        backup_encrypt: false,
        backup_retention_days: 14,
        backup_schedule: 'daily',
        agent_require_approval: false,
        agent_auto_approve_known_hosts: true,
        agent_api_key_rotation_days: 0,
        agent_api_key_grace_period_hours: 24,
        agent_tls_verify: true,
        ssh_host_key_policy: 'warn',
        tls_minimum_version_toolkit: 'TLSv1_3',
        tls_minimum_version_external: 'TLSv1_2',
        tls_certificate_verification: true,
        tls_strict_mode: false,
        api_general_rate_limit_per_minute: 200,
        api_write_rate_limit_per_minute: 60,
        api_search_rate_limit_per_minute: 120,
        auth_login_rate_limit_per_minute: 5,
        asset_discovery_api_rate_limit_per_minute: 150,
        asset_discovery_scan_rate_limit_per_minute: 30,
        asset_discovery_cve_sync_rate_limit_per_minute: 10,
        agent_registration_rate_limit_per_minute: 5,
        analytics_max_result_set_size: 20000
    }
};

function bindSecurityProfileAutoCustomOnManualEdit() {
    const securityPanel = document.getElementById('admin-panel-security');
    if (!securityPanel || securityPanel.dataset.profileAutoCustomBound === 'true') {
        return;
    }

    const handleManualEdit = (event) => {
        if (!event.isTrusted) {
            return;
        }

        const target = event.target;
        if (!(target instanceof HTMLElement)) {
            return;
        }

        const selector = document.getElementById('security-profile-selector');
        if (!selector || selector.value === 'custom') {
            return;
        }

        const ignoredIds = new Set([
            'security-profile-selector',
            'apply-security-profile',
            'save-security-settings',
            'reset-security-settings',
            'refresh-security-diagnostics'
        ]);

        if (ignoredIds.has(target.id)) {
            return;
        }

        const isSecuritySettingField = target.id && target.id.startsWith('setting-');
        if (!isSecuritySettingField) {
            return;
        }

        setSecuritySettingsDirty(true);

        selector.value = 'custom';

        const statusEl = document.getElementById('security-settings-status');
        if (statusEl) {
            statusEl.textContent = '✏️ Manual changes detected. Profile switched to Custom (not saved).';
            statusEl.className = 'settings-status';
        }
    };

    securityPanel.addEventListener('input', handleManualEdit);
    securityPanel.addEventListener('change', handleManualEdit);
    securityPanel.dataset.profileAutoCustomBound = 'true';
}

function applySecuritySettingToForm(key, value) {
    const idOverrides = {
        backup_encrypt: 'setting-security-backup-encrypt',
        backup_compress: 'setting-security-backup-compress',
        backup_auto_enabled: 'setting-security-backup-auto-enabled',
        backup_retention_days: 'setting-security-backup-retention-days',
        backup_keep_count: 'setting-security-backup-keep-count',
        backup_max_size: 'setting-security-backup-max-size',
        backup_schedule: 'setting-security-backup-schedule',
        backup_include_shared_data: 'setting-backup-include-shared-data',
        backup_shared_data_paths: 'setting-backup-shared-data-paths'
    };

    const fieldId = idOverrides[key] || `setting-${key.replace(/_/g, '-')}`;
    const el = document.getElementById(fieldId);
    if (!el) return;

    if (el.type === 'checkbox') {
        el.checked = !!value;
    } else {
        el.value = value;
    }
}

function applySecurityProfile() {
    const selector = document.getElementById('security-profile-selector');
    const statusEl = document.getElementById('security-settings-status');
    if (!selector) return;

    const selected = selector.value;
    if (!selected || selected === 'custom') {
        if (statusEl) {
            statusEl.textContent = 'ℹ️ Custom selected. No preset applied.';
            statusEl.className = 'settings-status';
        }
        return;
    }

    const preset = SECURITY_PROFILE_PRESETS[selected];
    if (!preset) {
        if (statusEl) {
            statusEl.textContent = '❌ Unknown security profile selected.';
            statusEl.className = 'settings-status error';
        }
        return;
    }

    Object.entries(preset).forEach(([key, value]) => applySecuritySettingToForm(key, value));
    setSecuritySettingsDirty(true);

    if (statusEl) {
        const label = selected === 'maximum' ? 'Maximum Security' : selected === 'balanced' ? 'Balanced' : 'High Availability';
        statusEl.textContent = `🧩 ${label} profile applied to form (not saved). Review and click Save Settings to persist.`;
        statusEl.className = 'settings-status';
    }
}

function applyRecommendedTlsProfile() {
    setSelectById('setting-tls-minimum-version-toolkit', 'TLSv1_3');
    setSelectById('setting-tls-minimum-version-external', 'TLSv1_2');
    setSelectById('setting-tls-maximum-version', 'TLSv1_3');
    setCheckboxById('setting-tls-certificate-verification', true);
    setCheckboxById('setting-tls-strict-mode', true);
    setCheckboxById('setting-tls-log-version', true);
    setInputById('setting-tls-cipher-suites', 'ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!DSS:!RC4:!DES');

    const statusEl = document.getElementById('security-settings-status');
    if (statusEl) {
        statusEl.textContent = '🛡️ Recommended TLS profile applied (Toolkit TLSv1.3, External TLSv1.2+). Click Save to apply.';
        statusEl.className = 'settings-status';
    }
}

function setValueIfExists(id, value) {
    const el = document.getElementById(id);
    if (el && value) el.value = value;
}

function toggleEmailConfig() {
    const emailEnabled = document.getElementById('admin-email-enabled');
    const emailConfig = document.getElementById('admin-email-config');

    if (emailEnabled && emailConfig) {
        emailConfig.classList.toggle('d-none', !emailEnabled.checked);
    }
}

function toggleTransport() {
    const transport = document.querySelector('input[name="email-transport"]:checked')?.value || 'smtp';
    const smtpFields = document.getElementById('email-smtp-fields');
    const graphFields = document.getElementById('email-graph-fields');
    if (smtpFields) smtpFields.classList.toggle('d-none', transport !== 'smtp');
    if (graphFields) graphFields.classList.toggle('d-none', transport !== 'graph');
}

// Load existing email settings on panel init
async function loadEmailSettings() {
    try {
        const response = await adminFetch('/api/admin/email/settings');
        const data = await response.json();

        if (data.success && data.email) {
            const email = data.email;

            // Populate form fields
            const enabledEl = document.getElementById('admin-email-enabled');
            if (enabledEl) {
                enabledEl.checked = email.enabled || false;
                toggleEmailConfig();
            }

            // Transport radio
            const transport = email.transport || 'smtp';
            const smtpRadio = document.getElementById('email-transport-smtp');
            const graphRadio = document.getElementById('email-transport-graph');
            if (smtpRadio) smtpRadio.checked = transport !== 'graph';
            if (graphRadio) graphRadio.checked = transport === 'graph';
            toggleTransport();

            const smtpFields = {
                'admin-smtp-host': email.smtp_host || '',
                'admin-smtp-port': email.smtp_port || 587,
                'admin-smtp-user': email.smtp_user || '',
                'admin-smtp-password': email.smtp_password || '',
                'admin-smtp-from': email.from_address || '',
                'admin-smtp-to': email.to_address || ''
            };

            for (const [id, value] of Object.entries(smtpFields)) {
                const el = document.getElementById(id);
                if (el) el.value = value;
            }

            // Graph fields
            const graphFieldMap = {
                'admin-graph-tenant-id': email.graph_tenant_id || '',
                'admin-graph-client-id': email.graph_client_id || '',
                'admin-graph-client-secret': email.graph_client_secret || '',
                'admin-graph-sender-user': email.graph_sender_user || ''
            };
            for (const [id, value] of Object.entries(graphFieldMap)) {
                const el = document.getElementById(id);
                if (el) el.value = value;
            }

            // Notification triggers
            const notifyOn = email.notify_on || {};
            const failuresEl = document.getElementById('admin-notify-failures');
            const warningsEl = document.getElementById('admin-notify-warnings');
            const completionEl = document.getElementById('admin-notify-completion');

            if (failuresEl) failuresEl.checked = notifyOn.failures !== false;
            if (warningsEl) warningsEl.checked = notifyOn.warnings === true;
            if (completionEl) completionEl.checked = notifyOn.completion === true;

            // Show current config display if configured
            if (data.configured) {
                showEmailConfigDisplay(email);
            } else {
                hideEmailConfigDisplay();
            }
        } else {
            hideEmailConfigDisplay();
        }
    } catch (error) {
        console.error('Failed to load email settings:', error);
        hideEmailConfigDisplay();
    }
}

function showEmailConfigDisplay(email) {
    const configDisplay = document.getElementById('email-current-config');
    const statusEl = document.getElementById('email-config-status');

    if (configDisplay) {
        configDisplay.style.display = 'block';

        const transport = email.transport || 'smtp';
        const transportEl = document.getElementById('email-display-transport');
        if (transportEl) transportEl.textContent = transport === 'graph' ? 'Microsoft 365 (Graph)' : 'SMTP';

        const displayFrom = document.getElementById('email-display-from');
        if (displayFrom) displayFrom.textContent = (transport === 'graph' ? email.graph_from_address : email.from_address) || email.from_address || '-';

        const displayTo = document.getElementById('email-display-to');
        if (displayTo) displayTo.textContent = email.to_address || '-';

        // SMTP-specific rows
        const hostRow = document.getElementById('email-display-host-row');
        const portRow = document.getElementById('email-display-port-row');
        const userRow = document.getElementById('email-display-user-row');
        const tenantRow = document.getElementById('email-display-tenant-row');

        if (transport === 'graph') {
            if (hostRow) hostRow.style.display = 'none';
            if (portRow) portRow.style.display = 'none';
            if (userRow) userRow.style.display = 'none';
            if (tenantRow) {
                tenantRow.style.display = '';
                const tenantEl = document.getElementById('email-display-tenant');
                if (tenantEl) tenantEl.textContent = email.graph_tenant_id ? email.graph_tenant_id.substring(0, 8) + '…' : '-';
            }
        } else {
            if (hostRow) hostRow.style.display = '';
            if (portRow) portRow.style.display = '';
            if (userRow) userRow.style.display = '';
            if (tenantRow) tenantRow.style.display = 'none';

            const displayHost = document.getElementById('email-display-host');
            const displayPort = document.getElementById('email-display-port');
            const displayUser = document.getElementById('email-display-user');
            if (displayHost) displayHost.textContent = email.smtp_host || '-';
            if (displayPort) displayPort.textContent = email.smtp_port || '587';
            if (displayUser) displayUser.textContent = email.smtp_user || '-';
        }
    }

    if (statusEl) {
        const enabledText = email.enabled ? '✓ Enabled' : '⏸️ Disabled';
        const color = email.enabled ? '#22c55e' : '#f59e0b';
        statusEl.innerHTML = `<span style="color: ${color};">${enabledText}</span>`;
    }
}

function hideEmailConfigDisplay() {
    const configDisplay = document.getElementById('email-current-config');
    const statusEl = document.getElementById('email-config-status');

    if (configDisplay) {
        configDisplay.style.display = 'none';
    }
    if (statusEl) {
        statusEl.innerHTML = '<span style="color: var(--text-secondary);">Not configured</span>';
    }
}

function editEmailSettings() {
    // Scroll to form and enable the toggle to show configuration
    const enabledEl = document.getElementById('admin-email-enabled');
    if (enabledEl && !enabledEl.checked) {
        enabledEl.checked = true;
        toggleEmailConfig();
    }

    // Scroll to form
    const form = document.getElementById('email-config-form');
    if (form) {
        form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // Focus on first editable field
    const hostInput = document.getElementById('admin-smtp-host');
    if (hostInput) {
        setTimeout(() => hostInput.focus(), 300);
    }
}

async function saveEmailSettings() {
    const transport = document.querySelector('input[name="email-transport"]:checked')?.value || 'smtp';

    const settings = {
        enabled: document.getElementById('admin-email-enabled')?.checked || false,
        transport,
        smtp_host: document.getElementById('admin-smtp-host')?.value || '',
        smtp_port: parseInt(document.getElementById('admin-smtp-port')?.value) || 587,
        smtp_user: document.getElementById('admin-smtp-user')?.value || '',
        smtp_password: document.getElementById('admin-smtp-password')?.value || '',
        from_address: document.getElementById('admin-smtp-from')?.value || '',
        to_address: document.getElementById('admin-smtp-to')?.value || '',
        graph_tenant_id: document.getElementById('admin-graph-tenant-id')?.value || '',
        graph_client_id: document.getElementById('admin-graph-client-id')?.value || '',
        graph_client_secret: document.getElementById('admin-graph-client-secret')?.value || '',
        graph_sender_user: document.getElementById('admin-graph-sender-user')?.value || '',
        notify_on: {
            failures: document.getElementById('admin-notify-failures')?.checked || false,
            warnings: document.getElementById('admin-notify-warnings')?.checked || false,
            completion: document.getElementById('admin-notify-completion')?.checked || false
        }
    };

    try {
        const response = await adminFetch('/api/admin/email/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(settings)
        });

        const data = await response.json();

        if (data.success) {
            showMessage('Email settings saved!', 'success');
            // Refresh display
            loadEmailSettings();
        } else {
            showMessage(data.error || 'Failed to save settings', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

async function sendTestEmail() {
    const transport = document.querySelector('input[name="email-transport"]:checked')?.value || 'smtp';

    const testSettings = {
        transport,
        smtp_host: document.getElementById('admin-smtp-host')?.value || '',
        smtp_port: parseInt(document.getElementById('admin-smtp-port')?.value) || 587,
        smtp_user: document.getElementById('admin-smtp-user')?.value || '',
        smtp_password: document.getElementById('admin-smtp-password')?.value || '',
        from_address: document.getElementById('admin-smtp-from')?.value || '',
        to_address: document.getElementById('admin-smtp-to')?.value || '',
        graph_tenant_id: document.getElementById('admin-graph-tenant-id')?.value || '',
        graph_client_id: document.getElementById('admin-graph-client-id')?.value || '',
        graph_client_secret: document.getElementById('admin-graph-client-secret')?.value || '',
        graph_sender_user: document.getElementById('admin-graph-sender-user')?.value || ''
    };

    // Validate required fields per transport
    if (transport === 'graph' && !testSettings.graph_tenant_id) {
        showMessage('Please enter Microsoft 365 Tenant ID', 'error');
        return;
    }
    if (transport !== 'graph' && !testSettings.smtp_host) {
        showMessage('Please enter SMTP host', 'error');
        return;
    }
    if (!testSettings.to_address) {
        showMessage('Please enter recipient email address', 'error');
        return;
    }

    try {
        const response = await adminFetch('/api/admin/email/test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(testSettings)
        });

        const data = await response.json();

        if (data.success) {
            showMessage(data.message || 'Test email sent!', 'success');
        } else {
            showMessage(data.error || 'Failed to send test email', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

async function deleteEmailSettings() {
    if (!confirm('Remove all email settings? This cannot be undone.')) return;

    try {
        const response = await adminFetch('/api/admin/email/delete', {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showMessage('Email settings removed', 'success');
            // Clear SMTP fields
            ['admin-smtp-host', 'admin-smtp-user', 'admin-smtp-password', 'admin-smtp-from', 'admin-smtp-to'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });
            const portEl = document.getElementById('admin-smtp-port');
            if (portEl) portEl.value = '587';
            // Clear Graph fields
            ['admin-graph-tenant-id', 'admin-graph-client-id', 'admin-graph-client-secret', 'admin-graph-sender-user'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });
            const enabledEl = document.getElementById('admin-email-enabled');
            if (enabledEl) enabledEl.checked = false;
            toggleEmailConfig();
            hideEmailConfigDisplay();
        } else {
            showMessage(data.error || 'Failed to remove settings', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// ============================================
// API Key Management
// ============================================
async function toggleApiKeyVisibility() {
    const keyEl = document.getElementById('admin-api-key');
    const btn = document.getElementById('admin-show-key');

    if (!keyEl || !btn) return;

    if (apiKeyVisible) {
        keyEl.textContent = '••••••••••••••••';
        btn.textContent = '👁️ Show';
        apiKeyVisible = false;
    } else {
        // Fetch actual key
        try {
            const response = await adminFetch('/api/settings/api-key');
            if (response.ok) {
                const data = await response.json();
                currentApiKey = data.api_key || '';
                keyEl.textContent = currentApiKey;
                btn.textContent = '🙈 Hide';
                apiKeyVisible = true;
            }
        } catch (error) {
            showMessage('Failed to load API key', 'error');
        }
    }
}

async function copyApiKey() {
    if (!currentApiKey) {
        // Fetch if not loaded
        try {
            const response = await adminFetch('/api/settings/api-key');
            if (response.ok) {
                const data = await response.json();
                currentApiKey = data.api_key || '';
            }
        } catch (error) {
            showMessage('Failed to load API key', 'error');
            return;
        }
    }

    try {
        await navigator.clipboard.writeText(currentApiKey);
        showMessage('API key copied to clipboard!', 'success');
    } catch (error) {
        showMessage('Failed to copy to clipboard', 'error');
    }
}

async function regenerateApiKey() {
    if (!confirm('Regenerate API key? This will invalidate all existing sessions.')) return;

    try {
        const response = await adminFetch('/api/settings/api-key', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        const data = await response.json();

        if (data.success) {
            currentApiKey = data.api_key || '';
            const keyEl = document.getElementById('admin-api-key');
            if (keyEl && apiKeyVisible) {
                keyEl.textContent = currentApiKey;
            }
            showMessage('API key regenerated! Please update your clients.', 'success');
            // Refresh API keys list
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to regenerate key', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Initialize API Keys panel event listeners
function initAPIKeysPanel() {
    // Create key button
    const createBtn = document.getElementById('btn-create-api-key');
    if (createBtn) {
        createBtn.addEventListener('click', createAPIKey);
    }

    // Refresh button
    const refreshBtn = document.getElementById('btn-refresh-api-keys');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', loadAPIKeysList);
    }

    // Hypervisor keys refresh button
    const hvRefreshBtn = document.getElementById('btn-refresh-hypervisor-keys');
    if (hvRefreshBtn) {
        hvRefreshBtn.addEventListener('click', loadAPIKeysList);
    }

    const managedRefreshBtn = document.getElementById('btn-refresh-fleet-agent-keys');
    if (managedRefreshBtn) {
        managedRefreshBtn.addEventListener('click', loadAPIKeysList);
    }

    // Hypervisor key validity quick-select
    const hvValiditySelect = document.getElementById('hypervisor-key-validity-quick');
    if (hvValiditySelect) {
        hvValiditySelect.addEventListener('change', saveHypervisorKeyValidity);
        // Load current setting
        loadHypervisorKeyValidity();
    }

    // Modal buttons
    const copyNewKeyBtn = document.getElementById('btn-copy-new-api-key');
    if (copyNewKeyBtn) {
        copyNewKeyBtn.addEventListener('click', copyNewAPIKey);
    }

    const closeModalBtn = document.getElementById('btn-close-api-key-modal');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeAPIKeyModal);
    }

    // Load initial data
    loadAPIKeysList();
}

// Load all API keys from backend
async function loadAPIKeysList() {
    const listContainer = document.getElementById('api-keys-list');
    if (!listContainer) return;

    listContainer.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">Loading API keys...</div>';

    try {
        const response = await adminFetch('/api/admin/api-keys/list');
        const data = await response.json();

        if (data.success) {
            updateAPIKeyStats(data);
            renderAPIKeysList(data.keys || []);
            // Also render hypervisor keys in their dedicated section
            renderHypervisorKeysList(data.keys || []);
            // Also render managed server agent keys in their dedicated section
            renderFleetAgentKeysList(data.keys || []);
        } else {
            listContainer.innerHTML = `<div style="text-align: center; padding: 2rem; color: #ef4444;">Error: ${data.error || 'Failed to load API keys'}</div>`;
        }
    } catch (error) {
        listContainer.innerHTML = `<div style="text-align: center; padding: 2rem; color: #ef4444;">Error: ${error.message}</div>`;
    }
}

// Update stats counters
function updateAPIKeyStats(data) {
    const totalEl = document.getElementById('api-keys-total');
    const activeEl = document.getElementById('api-keys-active');
    const agentEl = document.getElementById('api-keys-agent');
    const expiredEl = document.getElementById('api-keys-expired');
    const hypervisorEl = document.getElementById('api-keys-hypervisor');

    if (totalEl) totalEl.textContent = data.total || 0;
    if (activeEl) activeEl.textContent = data.active || 0;
    if (agentEl) agentEl.textContent = data.agent_keys || 0;
    if (expiredEl) expiredEl.textContent = data.expired || 0;
    if (hypervisorEl) hypervisorEl.textContent = data.hypervisor_keys || 0;
}

// Render the API keys table
function renderAPIKeysList(keys) {
    const container = document.getElementById('api-keys-list');
    if (!container) return;

    if (!keys || keys.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">No API keys found. Create one above.</div>';
        return;
    }

    const table = document.createElement('table');
    table.style.cssText = 'width: 100%; border-collapse: collapse;';
    table.innerHTML = `
        <thead>
            <tr style="background: var(--bg-primary); border-bottom: 2px solid var(--border-color);">
                <th style="padding: 0.75rem; text-align: left; font-weight: 600;">Name</th>
                <th style="padding: 0.75rem; text-align: left; font-weight: 600;">Type</th>
                <th style="padding: 0.75rem; text-align: left; font-weight: 600;">Key Preview</th>
                <th style="padding: 0.75rem; text-align: left; font-weight: 600;">Scope</th>
                <th style="padding: 0.75rem; text-align: left; font-weight: 600;">Created</th>
                <th style="padding: 0.75rem; text-align: left; font-weight: 600;">Status</th>
                <th style="padding: 0.75rem; text-align: center; font-weight: 600;">Actions</th>
            </tr>
        </thead>
        <tbody id="api-keys-tbody"></tbody>
    `;

    container.innerHTML = '';
    container.appendChild(table);

    const tbody = document.getElementById('api-keys-tbody');

    keys.forEach(key => {
        const row = document.createElement('tr');
        row.style.borderBottom = '1px solid var(--border-color)';

        const isExpired = key.expired || key.status === 'expired';
        const isSystem = key.type === 'system';
        const isHypervisor = key.type === 'hypervisor_agent';
        const isAgent = key.type === 'agent';
        const isFleetAgent = isAgent && (key.type_name === 'Managed Server Agent' || !!key.server_id);
        const isRevoked = key.status === 'revoked';
        const isExpiringSoon = key.status === 'expiring_soon';

        // Status color
        let statusColor = '#22c55e'; // green = active
        if (isExpired) statusColor = '#ef4444'; // red
        else if (isRevoked) statusColor = '#6b7280'; // gray
        else if (isExpiringSoon) statusColor = '#f97316'; // orange
        else if (key.status === 'offline') statusColor = '#f59e0b'; // amber

        // Type icons
        let typeIcon = '🔑';
        let typeBadge = key.type;
        if (isSystem) {
            typeIcon = '🔐';
            typeBadge = 'System';
        } else if (isHypervisor) {
            typeIcon = '🖥️';
            typeBadge = 'Hypervisor';
        } else if (isFleetAgent) {
            typeIcon = '🔗';
            typeBadge = 'Fleet Agent';
        } else if (isAgent) {
            typeIcon = '🤖';
            typeBadge = 'Agent';
        } else if (key.type === 'custom') {
            typeIcon = '🔑';
            typeBadge = 'Custom';
        }

        // Encryption badge
        const encryptedBadge = key.encrypted ?
            '<span style="background: #22c55e20; color: #22c55e; padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.7rem; margin-left: 0.25rem;">🔒 Encrypted</span>' : '';

        // Platform info for hypervisor keys
        let platformInfo = '';
        if (isHypervisor) {
            let expiryInfo = '';
            if (key.key_expires_at) {
                const expiresDate = new Date(key.key_expires_at).toLocaleDateString();
                if (key.expires_in_days !== null && key.expires_in_days !== undefined) {
                    if (key.expires_in_days <= 0) {
                        expiryInfo = ` | <span style="color: #ef4444;">⚠️ Key expired</span>`;
                    } else if (key.expires_in_days <= 14) {
                        expiryInfo = ` | <span style="color: #f97316;">⏳ Expires in ${key.expires_in_days}d</span>`;
                    } else {
                        expiryInfo = ` | Expires: ${expiresDate}`;
                    }
                } else {
                    expiryInfo = ` | Expires: ${expiresDate}`;
                }
            } else if (key.key_validity_days === 0) {
                expiryInfo = ' | <span style="color: #22c55e;">∞ Never expires</span>';
            }

            // Format validity period label
            let validityLabel = '';
            if (key.key_validity_days === 30) validityLabel = '30 days';
            else if (key.key_validity_days === 90) validityLabel = '3 months';
            else if (key.key_validity_days === 180) validityLabel = '6 months';
            else if (key.key_validity_days === 365) validityLabel = '1 year';
            else if (key.key_validity_days === 0) validityLabel = 'Never';
            else if (key.key_validity_days) validityLabel = `${key.key_validity_days} days`;

            platformInfo = `<div style="font-size: 0.75rem; color: var(--text-secondary); margin-top: 0.25rem;">`;
            if (key.platform) platformInfo += `Platform: ${key.platform}`;
            if (key.hostname) platformInfo += ` | ${key.hostname}`;
            if (validityLabel) platformInfo += ` | Validity: ${validityLabel}`;
            platformInfo += expiryInfo;
            platformInfo += `</div>`;
        }

        // Actions based on key type
        let actions = '';
        if (isSystem) {
            actions = `<button class="btn btn-small btn-primary" onclick="regenerateSystemKey()" title="Regenerate system key">🔄 Regenerate</button>`;
        } else if (isHypervisor) {
            if (isRevoked) {
                actions = `<button class="btn btn-small btn-danger" onclick="deleteHypervisorKey('${key.agent_id || key.id}')" title="Delete agent">🗑️ Delete</button>`;
            } else {
                actions = `
                    <button class="btn btn-small btn-primary" onclick="rotateHypervisorKey('${key.agent_id || key.id}')" title="Rotate key">🔄</button>
                    <button class="btn btn-small btn-warning" onclick="revokeHypervisorKey('${key.agent_id || key.id}')" title="Revoke key">⛔</button>
                `;
            }
        } else if (isFleetAgent) {
            if (isRevoked) {
                actions = `<button class="btn btn-small btn-danger" onclick="deleteFleetAgentKey('${key.agent_id || key.id}')" title="Delete agent">🗑️ Delete</button>`;
            } else {
                actions = `
                    <button class="btn btn-small btn-primary" onclick="rotateFleetAgentKey('${key.agent_id || key.id}')" title="Rotate key">🔄</button>
                    <button class="btn btn-small btn-warning" onclick="revokeFleetAgentKey('${key.agent_id || key.id}')" title="Revoke key">⛔</button>
                `;
            }
        } else {
            actions = `<button class="btn btn-small btn-danger" onclick="revokeAPIKey('${key.id}')" title="Revoke this key">🗑️</button>`;
        }

        // Status text
        let statusText = key.status || 'active';
        if (isExpired) statusText = '⚠️ Expired';
        else if (isRevoked) statusText = '⛔ Revoked';
        else if (isExpiringSoon) statusText = '⏳ Expiring';
        else if (key.status === 'offline') statusText = '⚠️ Offline';
        else if (key.status === 'online') statusText = '✅ Online';

        row.innerHTML = `
            <td style="padding: 0.75rem;">
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <span style="width: 8px; height: 8px; border-radius: 50%; background: ${statusColor};"></span>
                    <strong>${escapeHtml(key.name)}</strong>
                    ${encryptedBadge}
                </div>
                ${key.description ? `<div style="font-size: 0.8rem; color: var(--text-secondary);">${escapeHtml(key.description)}</div>` : ''}
                ${platformInfo}
            </td>
            <td style="padding: 0.75rem;">
                <span style="display: inline-flex; align-items: center; gap: 0.25rem; padding: 0.25rem 0.5rem; background: var(--bg-primary); border-radius: 4px; font-size: 0.85rem;">
                    ${typeIcon} ${typeBadge}
                </span>
            </td>
            <td style="padding: 0.75rem;">
                <code style="font-size: 0.85rem; color: var(--text-secondary);">${key.key_preview || key.preview || '••••••••'}</code>
            </td>
            <td style="padding: 0.75rem;">
                <div style="display: flex; gap: 0.25rem; flex-wrap: wrap;">
                    ${(key.scope || ['read']).map(s => `<span style="background: ${s === 'admin' ? '#7c3aed20' : (s === 'hypervisor_agent' ? '#f9731620' : '#3b82f620')}; color: ${s === 'admin' ? '#7c3aed' : (s === 'hypervisor_agent' ? '#f97316' : '#3b82f6')}; padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.75rem;">${s}</span>`).join('')}
                </div>
            </td>
            <td style="padding: 0.75rem; font-size: 0.85rem; color: var(--text-secondary);">
                ${key.created || 'N/A'}
            </td>
            <td style="padding: 0.75rem; font-size: 0.85rem; color: ${isExpired || isRevoked ? '#ef4444' : 'var(--text-secondary)'};">
                ${statusText}
            </td>
            <td style="padding: 0.75rem; text-align: center;">
                <div style="display: flex; gap: 0.25rem; justify-content: center;">
                    ${actions}
                </div>
            </td>
        `;

        tbody.appendChild(row);
    });
}

// Create a new API key
async function createAPIKey() {
    const nameInput = document.getElementById('new-api-key-name');
    const typeSelect = document.getElementById('new-api-key-type');
    const expirySelect = document.getElementById('new-api-key-expiry');
    const descInput = document.getElementById('new-api-key-desc');
    const scopeCheckboxes = document.querySelectorAll('.new-api-key-scope:checked');

    const name = nameInput?.value?.trim();
    if (!name) {
        showMessage('Please enter a key name', 'error');
        return;
    }

    const type = typeSelect?.value || 'custom';
    const expiryDays = parseInt(expirySelect?.value || '90', 10);
    const description = descInput?.value?.trim() || '';
    const scope = Array.from(scopeCheckboxes).map(cb => cb.value);

    if (scope.length === 0) {
        showMessage('Please select at least one permission', 'error');
        return;
    }

    try {
        const response = await adminFetch('/api/admin/api-keys/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, type, expiry_days: expiryDays, description, scope })
        });

        const data = await response.json();

        if (data.success) {
            // Show the key in modal
            const keyDisplay = document.getElementById('new-api-key-display');
            if (keyDisplay) keyDisplay.textContent = data.key?.api_key || data.key;

            const modal = document.getElementById('new-api-key-modal');
            if (modal) modal.style.display = 'flex';

            // Clear form
            if (nameInput) nameInput.value = '';
            if (descInput) descInput.value = '';

            // Refresh list
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to create API key', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Revoke an API key
async function revokeAPIKey(keyId) {
    if (!confirm('Revoke this API key? This action cannot be undone.')) return;

    try {
        const response = await adminFetch(`/api/admin/api-keys/${keyId}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showMessage('API key revoked successfully', 'success');
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to revoke API key', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Regenerate system API key
async function regenerateSystemKey() {
    if (!confirm('⚠️ Regenerate the system API key?\n\nThis will invalidate all existing sessions using the current key. Make sure you have access to update any integrations using this key.')) return;

    try {
        const response = await adminFetch('/api/admin/api-keys/system/regenerate', {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            // Show the new key in modal
            const keyDisplay = document.getElementById('new-api-key-display');
            if (keyDisplay) keyDisplay.textContent = data.api_key;

            const modal = document.getElementById('new-api-key-modal');
            if (modal) {
                modal.style.display = 'flex';
                // Update modal title
                const modalTitle = modal.querySelector('h3');
                if (modalTitle) modalTitle.textContent = 'System Key Regenerated';
            }

            showMessage('System API key regenerated successfully', 'success');
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to regenerate system key', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Rotate hypervisor agent key
async function rotateHypervisorKey(agentId) {
    if (!confirm('Rotate the API key for this hypervisor agent?\n\nThe agent will need to be updated with the new key to continue communicating.')) return;

    try {
        const response = await adminFetch(`/api/admin/api-keys/hypervisor/${agentId}/rotate`, {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            // Show the new key in modal
            const keyDisplay = document.getElementById('new-api-key-display');
            if (keyDisplay) keyDisplay.textContent = data.new_key;

            const modal = document.getElementById('new-api-key-modal');
            if (modal) {
                modal.style.display = 'flex';
                // Update modal title
                const modalTitle = modal.querySelector('h3');
                if (modalTitle) modalTitle.textContent = 'Hypervisor Agent Key Rotated';
            }

            showMessage('Hypervisor agent key rotated successfully. Update the agent with the new key.', 'success');
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to rotate hypervisor key', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Revoke hypervisor agent key
async function revokeHypervisorKey(agentId) {
    if (!confirm('⚠️ Revoke the API key for this hypervisor agent?\n\nThe agent will no longer be able to communicate with the server. This action can be undone by rotating the key.')) return;

    try {
        const response = await adminFetch(`/api/admin/api-keys/hypervisor/${agentId}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showMessage('Hypervisor agent key revoked successfully', 'success');
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to revoke hypervisor key', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Delete hypervisor agent completely
async function deleteHypervisorKey(agentId) {
    if (!confirm('🗑️ Permanently delete this hypervisor agent?\n\nThis will remove all data associated with this agent. This action cannot be undone.')) return;

    try {
        const response = await adminFetch(`/api/admin/api-keys/hypervisor/${agentId}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ permanent: true })
        });

        const data = await response.json();

        if (data.success) {
            showMessage('Hypervisor agent deleted successfully', 'success');
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to delete hypervisor agent', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Rotate managed server agent key
async function rotateFleetAgentKey(agentId) {
    if (!confirm('Rotate the API key for this managed server agent?\n\nThe agent will need to be updated with the new key to continue communicating.')) return;

    try {
        const response = await adminFetch(`/api/admin/api-keys/fleet-agent/${agentId}/rotate`, {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            const keyDisplay = document.getElementById('new-api-key-display');
            if (keyDisplay) keyDisplay.textContent = data.new_key;

            const modal = document.getElementById('new-api-key-modal');
            if (modal) {
                modal.style.display = 'flex';
                const modalTitle = modal.querySelector('h3');
                if (modalTitle) modalTitle.textContent = 'Fleet Agent Key Rotated';
            }

            showMessage('Managed server agent key rotated successfully. Update the agent with the new key.', 'success');
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to rotate fleet agent key', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Revoke managed server agent key
async function revokeFleetAgentKey(agentId) {
    if (!confirm('⚠️ Revoke the API key for this managed server agent?\n\nThe agent will no longer be able to communicate with the server. This action can be undone by rotating the key.')) return;

    try {
        const response = await adminFetch(`/api/admin/api-keys/fleet-agent/${agentId}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showMessage('Managed server agent key revoked successfully', 'success');
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to revoke fleet agent key', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Delete managed server agent completely
async function deleteFleetAgentKey(agentId) {
    if (!confirm('🗑️ Permanently delete this managed server agent?\n\nThis will remove all data associated with this agent. This action cannot be undone.')) return;

    try {
        const response = await adminFetch(`/api/admin/api-keys/fleet-agent/${agentId}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ permanent: true })
        });

        const data = await response.json();

        if (data.success) {
            showMessage('Managed server agent deleted successfully', 'success');
            loadAPIKeysList();
        } else {
            showMessage(data.error || 'Failed to delete managed server agent', 'error');
        }
    } catch (error) {
        showMessage('Error: ' + error.message, 'error');
    }
}

// Load hypervisor key validity setting
async function loadHypervisorKeyValidity() {
    try {
        const response = await adminFetch('/api/admin/security-settings');
        const data = await response.json();
        if (data.success && data.settings) {
            const select = document.getElementById('hypervisor-key-validity-quick');
            if (select) {
                select.value = data.settings.hypervisor_key_validity_days || 90;
            }
        }
    } catch (error) {
        console.error('Failed to load hypervisor key validity:', error);
    }
}

// Save hypervisor key validity setting
async function saveHypervisorKeyValidity() {
    const select = document.getElementById('hypervisor-key-validity-quick');
    if (!select) return;

    try {
        const response = await adminFetch('/api/admin/security-settings', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                hypervisor_key_validity_days: parseInt(select.value)
            })
        });
        const data = await response.json();
        if (data.success) {
            showToast('Default hypervisor key validity updated', 'success');
        } else {
            showToast(data.error || 'Failed to save setting', 'error');
        }
    } catch (error) {
        showToast('Error saving setting: ' + error.message, 'error');
    }
}

// Render hypervisor keys in their dedicated section
function renderHypervisorKeysList(keys) {
    const container = document.getElementById('hypervisor-keys-list');
    if (!container) return;

    // Filter to only hypervisor keys
    const hvKeys = keys.filter(k => k.type === 'hypervisor_agent');

    if (!hvKeys || hvKeys.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 1.5rem; color: var(--text-secondary);">
                <span style="font-size: 1.5rem;">🖥️</span><br>
                No hypervisor agents registered yet.<br>
                <a href="#" onclick="document.querySelector('[data-tab=hypervisors]').click(); return false;" style="color: var(--primary-color);">Register an agent →</a>
            </div>`;
        return;
    }

    let html = `
        <table style="width: 100%; border-collapse: collapse; font-size: 0.9rem;">
            <thead>
                <tr style="background: var(--bg-primary); border-bottom: 2px solid var(--border-color);">
                    <th style="padding: 0.6rem; text-align: left;">Agent</th>
                    <th style="padding: 0.6rem; text-align: left;">Platform</th>
                    <th style="padding: 0.6rem; text-align: left;">Key Validity</th>
                    <th style="padding: 0.6rem; text-align: left;">Status</th>
                    <th style="padding: 0.6rem; text-align: center;">Actions</th>
                </tr>
            </thead>
            <tbody>`;

    hvKeys.forEach(key => {
        const isExpired = key.status === 'expired';
        const isRevoked = key.status === 'revoked';
        const isExpiringSoon = key.status === 'expiring_soon';
        const isOnline = key.status === 'online';

        // Status indicator color
        let statusColor = '#22c55e'; // green = online/active
        let statusText = '🟢 Active';
        if (isExpired) {
            statusColor = '#ef4444';
            statusText = '🔴 Key Expired';
        } else if (isRevoked) {
            statusColor = '#6b7280';
            statusText = '⚫ Revoked';
        } else if (isExpiringSoon) {
            statusColor = '#f59e0b';
            statusText = '🟡 Expiring Soon';
        } else if (key.status === 'offline') {
            statusColor = '#f59e0b';
            statusText = '🟠 Offline';
        }

        // Key validity display
        let validityLabel = '';
        if (key.key_validity_days === 30) validityLabel = '30 days';
        else if (key.key_validity_days === 90) validityLabel = '3 months';
        else if (key.key_validity_days === 180) validityLabel = '6 months';
        else if (key.key_validity_days === 365) validityLabel = '1 year';
        else if (key.key_validity_days === 0) validityLabel = '∞ Never';
        else validityLabel = key.key_validity_days ? `${key.key_validity_days}d` : 'N/A';

        // Expiry info
        let expiryInfo = '';
        if (key.key_expires_at) {
            const expiresDate = new Date(key.key_expires_at).toLocaleDateString();
            if (key.expires_in_days !== null && key.expires_in_days !== undefined) {
                if (key.expires_in_days <= 0) {
                    expiryInfo = `<span style="color: #ef4444;">Expired ${expiresDate}</span>`;
                } else if (key.expires_in_days <= 14) {
                    expiryInfo = `<span style="color: #f97316;">${key.expires_in_days}d left</span>`;
                } else {
                    expiryInfo = `Expires: ${expiresDate}`;
                }
            } else {
                expiryInfo = `Expires: ${expiresDate}`;
            }
        } else if (key.key_validity_days === 0) {
            expiryInfo = '<span style="color: #22c55e;">Never expires</span>';
        }

        // Actions
        let actions = '';
        if (isRevoked) {
            actions = `<button class="btn btn-small btn-danger" onclick="deleteHypervisorKey('${key.agent_id}')" title="Delete permanently">🗑️</button>`;
        } else {
            actions = `
                <button class="btn btn-small btn-primary" onclick="rotateHypervisorKey('${key.agent_id}')" title="Rotate API key">🔄</button>
                <button class="btn btn-small btn-warning" onclick="revokeHypervisorKey('${key.agent_id}')" title="Revoke key">⛔</button>
            `;
        }

        html += `
            <tr style="border-bottom: 1px solid var(--border-color);">
                <td style="padding: 0.6rem;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span style="width: 8px; height: 8px; border-radius: 50%; background: ${statusColor};"></span>
                        <strong>${escapeHtml(key.hostname || key.name || key.agent_id)}</strong>
                    </div>
                    ${key.hypervisor_id ? `<div style="font-size: 0.75rem; color: var(--text-muted);">ID: ${key.hypervisor_id}</div>` : ''}
                </td>
                <td style="padding: 0.6rem;">
                    <span style="background: var(--bg-primary); padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.8rem;">
                        ${escapeHtml(key.platform || 'Unknown')}
                    </span>
                </td>
                <td style="padding: 0.6rem;">
                    <div>${validityLabel}</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted);">${expiryInfo}</div>
                </td>
                <td style="padding: 0.6rem; color: ${isExpired || isRevoked ? '#ef4444' : 'var(--text-secondary)'};">
                    ${statusText}
                </td>
                <td style="padding: 0.6rem; text-align: center;">
                    <div style="display: flex; gap: 0.25rem; justify-content: center;">
                        ${actions}
                    </div>
                </td>
            </tr>`;
    });

    html += '</tbody></table>';
    container.innerHTML = html;
}

// Render managed server agent keys in their dedicated section
function renderFleetAgentKeysList(keys) {
    const container = document.getElementById('fleet-agent-keys-list');
    if (!container) return;

    const managedKeys = keys.filter(k => k.type === 'agent' && (k.type_name === 'Managed Server Agent' || !!k.server_id));

    if (!managedKeys || managedKeys.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 1.5rem; color: var(--text-secondary);">
                <span style="font-size: 1.5rem;">🔗</span><br>
                No managed server agents registered yet.<br>
                <a href="#" onclick="document.querySelector('[data-tab=servers]').click(); return false;" style="color: var(--primary-color);">Add a server with Fleet Agent →</a>
            </div>`;
        return;
    }

    let html = `
        <table style="width: 100%; border-collapse: collapse; font-size: 0.9rem;">
            <thead>
                <tr style="background: var(--bg-primary); border-bottom: 2px solid var(--border-color);">
                    <th style="padding: 0.6rem; text-align: left;">Agent</th>
                    <th style="padding: 0.6rem; text-align: left;">OS</th>
                    <th style="padding: 0.6rem; text-align: left;">Key Validity</th>
                    <th style="padding: 0.6rem; text-align: left;">Status</th>
                    <th style="padding: 0.6rem; text-align: center;">Actions</th>
                </tr>
            </thead>
            <tbody>`;

    managedKeys.forEach(key => {
        const isExpired = key.status === 'expired';
        const isRevoked = key.status === 'revoked';
        const isExpiringSoon = key.status === 'expiring_soon';

        let statusColor = '#22c55e';
        let statusText = '🟢 Active';
        if (isExpired) {
            statusColor = '#ef4444';
            statusText = '🔴 Key Expired';
        } else if (isRevoked) {
            statusColor = '#6b7280';
            statusText = '⚫ Revoked';
        } else if (isExpiringSoon) {
            statusColor = '#f59e0b';
            statusText = '🟡 Expiring Soon';
        } else if (key.status === 'offline') {
            statusColor = '#f59e0b';
            statusText = '🟠 Offline';
        } else if (key.status === 'online') {
            statusText = '🟢 Online';
        }

        let validityLabel = '';
        if (key.validity_days === 30) validityLabel = '30 days';
        else if (key.validity_days === 90) validityLabel = '3 months';
        else if (key.validity_days === 180) validityLabel = '6 months';
        else if (key.validity_days === 365) validityLabel = '1 year';
        else if (key.validity_days === 0) validityLabel = '∞ Never';
        else validityLabel = key.validity_days ? `${key.validity_days}d` : 'N/A';

        let expiryInfo = '';
        if (key.expires) {
            const expiresDate = new Date(key.expires).toLocaleDateString();
            expiryInfo = `Expires: ${expiresDate}`;
        } else if (key.validity_days === 0) {
            expiryInfo = '<span style="color: #22c55e;">Never expires</span>';
        }

        let actions = '';
        if (isRevoked) {
            actions = `<button class="btn btn-small btn-danger" onclick="deleteFleetAgentKey('${key.agent_id}')" title="Delete permanently">🗑️</button>`;
        } else {
            actions = `
                <button class="btn btn-small btn-primary" onclick="rotateFleetAgentKey('${key.agent_id}')" title="Rotate API key">🔄</button>
                <button class="btn btn-small btn-warning" onclick="revokeFleetAgentKey('${key.agent_id}')" title="Revoke key">⛔</button>
            `;
        }

        html += `
            <tr style="border-bottom: 1px solid var(--border-color);">
                <td style="padding: 0.6rem;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span style="width: 8px; height: 8px; border-radius: 50%; background: ${statusColor};"></span>
                        <strong>${escapeHtml(key.hostname || key.name || key.agent_id)}</strong>
                    </div>
                    ${key.server_id ? `<div style="font-size: 0.75rem; color: var(--text-muted);">Server: ${escapeHtml(key.server_id)}</div>` : ''}
                </td>
                <td style="padding: 0.6rem;">
                    <span style="background: var(--bg-primary); padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.8rem; text-transform: capitalize;">
                        ${escapeHtml(key.os_type || 'unknown')}
                    </span>
                </td>
                <td style="padding: 0.6rem;">
                    <div>${validityLabel}</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted);">${expiryInfo}</div>
                </td>
                <td style="padding: 0.6rem; color: ${isExpired || isRevoked ? '#ef4444' : 'var(--text-secondary)'};">
                    ${statusText}
                </td>
                <td style="padding: 0.6rem; text-align: center;">
                    <div style="display: flex; gap: 0.25rem; justify-content: center;">
                        ${actions}
                    </div>
                </td>
            </tr>`;
    });

    html += '</tbody></table>';
    container.innerHTML = html;
}

// Copy the newly created key
function copyNewAPIKey() {
    const keyDisplay = document.getElementById('new-api-key-display');
    if (keyDisplay && keyDisplay.textContent) {
        navigator.clipboard.writeText(keyDisplay.textContent)
            .then(() => showMessage('API key copied to clipboard!', 'success'))
            .catch(() => showMessage('Failed to copy to clipboard', 'error'));
    }
}

// Close the new key modal
function closeAPIKeyModal() {
    const modal = document.getElementById('new-api-key-modal');
    if (modal) modal.style.display = 'none';
}

// Utility: Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text || '';
    return div.innerHTML;
}

// ============================================
// Message Display
// ============================================
function showMessage(message, type) {
    // Try to use existing message container or create one
    let container = document.querySelector('.admin-message-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'admin-message-container';
        container.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999;';
        document.body.appendChild(container);
    }

    const div = document.createElement('div');
    div.className = `admin-message ${type}`;
    div.style.cssText = `
        background: ${type === 'success' ? '#dcfce7' : '#fee2e2'};
        color: ${type === 'success' ? '#15803d' : '#dc2626'};
        padding: 12px 20px;
        border-radius: 8px;
        margin-bottom: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease;
    `;
    div.textContent = message;

    container.appendChild(div);

    setTimeout(() => {
        div.style.opacity = '0';
        div.style.transform = 'translateX(100%)';
        setTimeout(() => div.remove(), 300);
    }, 4000);
}

// ============================================
// User Management
// ============================================
async function loadUsers() {
    const tableBody = document.getElementById('admin-users-table');
    if (!tableBody) return;

    try {
        const response = await adminFetch('/api/admin/users');
        if (response.ok) {
            const data = await response.json();
            const users = data.users || [];

            if (users.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-secondary);">No users found</td></tr>';
                return;
            }

            tableBody.innerHTML = users.map(user => `
                <tr>
                    <td><strong>${escapeHtml(user.username)}</strong></td>
                    <td>${escapeHtml(user.email || '-')}</td>
                    <td><span class="role-badge role-${escapeHtml(user.role?.toLowerCase())}">${escapeHtml(user.role || 'Unknown')}</span></td>
                    <td>${escapeHtml(getAuthProviderLabel(user.auth_provider))}</td>
                    <td>${user.is_active !== false ? '<span style="color: var(--success-color);">✓ Active</span>' : '<span style="color: var(--error-color);">✗ Inactive</span>'}</td>
                    <td>
                        <button class="btn btn-small" onclick="editUser(${user.id})" title="Edit">✏️</button>
                        <button class="btn btn-small btn-warning" onclick="resetUserPassword(${user.id})" title="Reset Password">🔑</button>
                        ${user.username !== 'admin' ? `<button class="btn btn-small btn-danger" onclick="deleteUser(${user.id}, '${escapeHtml(user.username)}', '${escapeHtml(user.role || 'Unknown')}')" title="Delete">🗑️</button>` : ''}
                    </td>
                </tr>
            `).join('');
        } else if (response.status === 401 || response.status === 403) {
            tableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--warning-color);">⚠️ Insufficient permissions to view users</td></tr>';
        } else {
            throw new Error('Failed to load users');
        }
    } catch (error) {
        console.error('Error loading users:', error);
        tableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--error-color);">Failed to load users</td></tr>';
    }
}

function getAuthProviderLabel(provider) {
    switch (provider) {
        case 'local': return '🔐 Local';
        case 'ldap': return '🏢 LDAP/AD';
        case 'entra_id': return '☁️ Entra ID';
        default: return provider || 'Local';
    }
}

function editUser(userId) {
    openEditUserModal(userId);
}

function resetUserPassword(userId) {
    openResetPasswordModal(userId);
}

async function deleteUser(userId, username, role) {
    // Show the delete confirmation modal instead of browser confirm
    const modal = document.getElementById('delete-user-modal');
    if (!modal) {
        // Fallback to browser confirm if modal not found
        if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
            return;
        }
        await performDeleteUser(userId);
        return;
    }

    // Populate modal with user info
    document.getElementById('delete-user-id').value = userId;
    document.getElementById('delete-user-username').textContent = username || 'Unknown User';
    document.getElementById('delete-user-role').textContent = role || 'Unknown Role';

    // Show modal
    modal.style.display = 'flex';
}

async function performDeleteUser(userId) {
    try {
        const response = await adminFetch(`/api/admin/users/${userId}`, {
            method: 'DELETE'
        });

        if (response.status === 401) {
            showToast('Session expired - please log in again', 'error');
            return;
        }
        if (response.status === 403) {
            showToast('Permission denied - cannot delete this user', 'error');
            return;
        }

        const data = await safeJsonParse(response);

        if (response.ok && data.success) {
            showToast(data.message || 'User deleted successfully', 'success');
            loadUsers(); // Refresh the users table
        } else {
            const errorMsg = data.error || `Failed to delete user (HTTP ${response.status})`;
            console.error('Delete user failed:', errorMsg, data);
            showToast(errorMsg, 'error');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showToast('Network error deleting user: ' + error.message, 'error');
    }
}

// Initialize delete user modal event listeners
document.addEventListener('DOMContentLoaded', function() {
    const deleteUserModal = document.getElementById('delete-user-modal');
    const closeBtn = document.getElementById('close-delete-user-modal');
    const confirmBtn = document.getElementById('confirm-delete-user');
    const cancelBtn = document.getElementById('cancel-delete-user');

    function closeDeleteUserModal() {
        if (deleteUserModal) {
            deleteUserModal.style.display = 'none';
        }
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', closeDeleteUserModal);
    }

    if (cancelBtn) {
        cancelBtn.addEventListener('click', closeDeleteUserModal);
    }

    if (confirmBtn) {
        confirmBtn.addEventListener('click', async function() {
            const userId = document.getElementById('delete-user-id').value;
            closeDeleteUserModal();
            if (userId) {
                await performDeleteUser(userId);
            }
        });
    }

    // Close on click outside modal content
    if (deleteUserModal) {
        deleteUserModal.addEventListener('click', function(e) {
            if (e.target === deleteUserModal) {
                closeDeleteUserModal();
            }
        });
    }
});

// ============================================
// Edit User Modal
// ============================================
async function openEditUserModal(userId) {
    const modal = document.getElementById('edit-user-modal');
    if (!modal) {
        showToast('Edit modal not found - please refresh the page', 'error');
        return;
    }

    try {
        const response = await adminFetch(`/api/admin/users/${userId}`);

        if (response.status === 401) {
            showToast('Session expired - please log in again', 'error');
            return;
        }
        if (response.status === 403) {
            showToast('Permission denied - Admin role required', 'error');
            return;
        }
        if (response.status === 404) {
            showToast('User not found', 'error');
            return;
        }

        const data = await safeJsonParse(response);

        if (response.ok && data.success && data.user) {
            const user = data.user;
            document.getElementById('edit-user-id').value = user.id;
            document.getElementById('edit-username').value = user.username || '';
            document.getElementById('edit-email').value = user.email || '';
            document.getElementById('edit-display-name').value = user.display_name || '';
            document.getElementById('edit-role').value = user.role || 'Analyst';
            document.getElementById('edit-auth-provider').value = user.auth_provider || 'local';
            document.getElementById('edit-is-active').checked = user.is_active !== false;
            document.getElementById('edit-mfa-enabled').checked = user.mfa_enabled === true;
            document.getElementById('edit-must-change-password').checked = user.must_change_password === true;

            modal.style.display = 'flex';
        } else {
            showToast(data.error || 'Failed to load user', 'error');
        }
    } catch (error) {
        showToast('Error loading user: ' + error.message, 'error');
    }
}

function closeEditUserModal() {
    const modal = document.getElementById('edit-user-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function handleEditUser(e) {
    e.preventDefault();

    const userId = document.getElementById('edit-user-id').value;
    const username = document.getElementById('edit-username').value.trim();
    const email = document.getElementById('edit-email').value.trim();
    const displayName = document.getElementById('edit-display-name').value.trim();
    const role = document.getElementById('edit-role').value;
    const authProvider = document.getElementById('edit-auth-provider').value;
    const isActive = document.getElementById('edit-is-active').checked;
    const mfaEnabled = document.getElementById('edit-mfa-enabled').checked;
    const mustChangePassword = document.getElementById('edit-must-change-password').checked;

    if (!username || !email || !role) {
        showToast('Please fill in all required fields', 'error');
        return;
    }

    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '⏳ Saving...';
    submitBtn.disabled = true;

    try {
        const response = await adminFetch(`/api/admin/users/${userId}`, {
            method: 'PUT',
            body: JSON.stringify({
                username: username,
                email: email,
                display_name: displayName || username,
                role: role,
                auth_provider: authProvider,
                is_active: isActive,
                mfa_enabled: mfaEnabled,
                must_change_password: mustChangePassword
            })
        });

        const data = await safeJsonParse(response);

        if (response.ok && data.success) {
            showToast(data.message || 'User updated successfully', 'success');
            closeEditUserModal();
            loadUsers(); // Refresh the users table
        } else {
            showToast(data.error || 'Failed to update user', 'error');
        }
    } catch (error) {
        console.error('Error updating user:', error);
        showToast('Failed to update user: ' + error.message, 'error');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

// ============================================
// Reset Password Modal
// ============================================
async function openResetPasswordModal(userId) {
    const modal = document.getElementById('reset-password-modal');
    if (!modal) {
        showToast('Reset password modal not found - please refresh the page', 'error');
        return;
    }

    try {
        const response = await adminFetch(`/api/admin/users/${userId}`);

        if (response.status === 401) {
            showToast('Session expired - please log in again', 'error');
            return;
        }
        if (response.status === 403) {
            showToast('Permission denied - Admin role required', 'error');
            return;
        }

        const data = await safeJsonParse(response);

        if (response.ok && data.success && data.user) {
            document.getElementById('reset-password-user-id').value = userId;
            document.getElementById('reset-password-username').textContent = `User: ${data.user.username}`;
            document.getElementById('reset-new-password').value = '';
            document.getElementById('reset-confirm-password').value = '';
            modal.style.display = 'flex';
            document.getElementById('reset-new-password').focus();
        } else {
            showToast(data.error || 'Failed to load user', 'error');
        }
    } catch (error) {
        showToast('Error loading user: ' + error.message, 'error');
    }
}

function closeResetPasswordModal() {
    const modal = document.getElementById('reset-password-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function handleResetPassword(e) {
    e.preventDefault();

    const userId = document.getElementById('reset-password-user-id').value;
    const newPassword = document.getElementById('reset-new-password').value;
    const confirmPassword = document.getElementById('reset-confirm-password').value;

    if (newPassword !== confirmPassword) {
        showToast('Passwords do not match', 'error');
        return;
    }

    // Password strength check
    const hasUpper = /[A-Z]/.test(newPassword);
    const hasLower = /[a-z]/.test(newPassword);
    const hasNumber = /[0-9]/.test(newPassword);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(newPassword);

    if (newPassword.length < 12 || !hasUpper || !hasLower || !hasNumber || !hasSpecial) {
        showToast('Password must be at least 12 characters with uppercase, lowercase, number, and special character', 'error');
        return;
    }

    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '⏳ Resetting...';
    submitBtn.disabled = true;

    try {
        const response = await adminFetch(`/api/admin/users/${userId}/reset-password`, {
            method: 'POST',
            body: JSON.stringify({
                password: newPassword
            })
        });

        const data = await safeJsonParse(response);

        if (response.ok && data.success) {
            showToast(data.message || 'Password reset successfully', 'success');
            closeResetPasswordModal();
            loadUsers(); // Refresh to show updated status
        } else {
            showToast(data.error || 'Failed to reset password', 'error');
        }
    } catch (error) {
        console.error('Error resetting password:', error);
        showToast('Failed to reset password: ' + error.message, 'error');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

function filterUsers() {
    const searchInput = document.getElementById('admin-user-search');
    const tableBody = document.getElementById('admin-users-table');
    if (!searchInput || !tableBody) return;

    const filter = searchInput.value.toLowerCase();
    const rows = tableBody.querySelectorAll('tr');

    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ============================================
// Add User Modal
// ============================================
function openAddUserModal() {
    const modal = document.getElementById('add-user-modal');
    if (modal) {
        modal.style.display = 'flex';
        // Clear form completely (reset + explicit value clearing for autocomplete)
        const form = document.getElementById('add-user-form');
        if (form) {
            form.reset();
            // Explicitly clear all input values to prevent autocomplete showing old values
            document.getElementById('new-username').value = '';
            document.getElementById('new-email').value = '';
            document.getElementById('new-display-name').value = '';
            document.getElementById('new-password').value = '';
            document.getElementById('new-role').value = 'Analyst';
            document.getElementById('new-must-change-password').checked = true;
        }
        // Focus on username field after a small delay (helps with autocomplete)
        setTimeout(() => {
            const usernameInput = document.getElementById('new-username');
            if (usernameInput) usernameInput.focus();
        }, 50);
    }
}

function closeAddUserModal() {
    const modal = document.getElementById('add-user-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function handleAddUser(e) {
    e.preventDefault();

    const username = document.getElementById('new-username').value.trim();
    const email = document.getElementById('new-email').value.trim();
    const displayName = document.getElementById('new-display-name').value.trim();
    const password = document.getElementById('new-password').value;
    const role = document.getElementById('new-role').value;
    const mustChangePassword = document.getElementById('new-must-change-password').checked;

    // Client-side validation
    if (!username || !email || !password || !role) {
        showToast('Please fill in all required fields', 'error');
        return;
    }

    // Password strength check
    const hasUpper = /[A-Z]/.test(password);
    const hasLower = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if (password.length < 12 || !hasUpper || !hasLower || !hasNumber || !hasSpecial) {
        showToast('Password must be at least 12 characters with uppercase, lowercase, number, and special character', 'error');
        return;
    }

    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '⏳ Creating...';
    submitBtn.disabled = true;

    try {
        const response = await adminFetch('/api/admin/users', {
            method: 'POST',
            body: JSON.stringify({
                username: username,
                email: email,
                display_name: displayName || username,
                password: password,
                role: role,
                must_change_password: mustChangePassword
            })
        });

        const data = await safeJsonParse(response);

        if (response.ok && data.success) {
            showToast(`User "${username}" created successfully`, 'success');
            closeAddUserModal();
            loadUsers(); // Refresh the users table
        } else {
            showToast(data.error || 'Failed to create user', 'error');
        }
    } catch (error) {
        console.error('Error creating user:', error);
        showToast('Failed to create user: ' + error.message, 'error');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

// Close modal on outside click
document.addEventListener('click', function(e) {
    const addUserModal = document.getElementById('add-user-modal');
    if (e.target === addUserModal) {
        closeAddUserModal();
    }
    const editUserModal = document.getElementById('edit-user-modal');
    if (e.target === editUserModal) {
        closeEditUserModal();
    }
    const resetPasswordModal = document.getElementById('reset-password-modal');
    if (e.target === resetPasswordModal) {
        closeResetPasswordModal();
    }
});

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeAddUserModal();
        closeEditUserModal();
        closeResetPasswordModal();
    }
});

// ============================================
// Initialize when DOM ready
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize if we're on the admin tab
    const adminTab = document.getElementById('admin-tab');
    if (adminTab) {
        // Initialize when admin tab becomes active
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.target.classList.contains('active')) {
                    initAdmin();
                }
            });
        });

        observer.observe(adminTab, { attributes: true, attributeFilter: ['class'] });

        // Also init if tab is already active
        if (adminTab.classList.contains('active')) {
            initAdmin();
        }
    }
});

// ============================================
// Remote Terminal Functions
// ============================================

let terminal = null;
let terminalSocket = null;
let fitAddon = null;
let commandHistory = [];
let terminalAccessToken = null;
let terminalTokenExpires = null;

// Terminal Authentication Functions
async function checkTerminalAuth() {
    try {
        const response = await adminFetch('/api/terminal/authenticate/status');
        if (response.ok) {
            const data = await response.json();
            return data.authenticated;
        }
        return false;
    } catch (error) {
        console.error('Terminal auth check failed:', error);
        return false;
    }
}

function showTerminalAuthModal() {
    const modal = document.getElementById('terminal-auth-modal');
    const errorEl = document.getElementById('terminal-auth-error');
    const passwordInput = document.getElementById('terminal-auth-password');

    if (modal) {
        modal.style.display = 'flex';
        if (errorEl) errorEl.style.display = 'none';
        if (passwordInput) {
            passwordInput.value = '';
            passwordInput.focus();
        }
    }
}

function hideTerminalAuthModal() {
    const modal = document.getElementById('terminal-auth-modal');
    const passwordInput = document.getElementById('terminal-auth-password');

    if (modal) modal.style.display = 'none';
    if (passwordInput) passwordInput.value = '';
}

async function authenticateTerminal(password) {
    const errorEl = document.getElementById('terminal-auth-error');
    const submitBtn = document.getElementById('terminal-auth-submit');

    try {
        if (submitBtn) submitBtn.disabled = true;

        const response = await adminFetch('/api/terminal/authenticate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ password })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Authentication failed');
        }

        // Store token
        terminalAccessToken = data.token;
        terminalTokenExpires = new Date(data.expires_at);

        // Hide modal and show terminal
        hideTerminalAuthModal();
        enableTerminalPanel(true);

        // Show expiry timer
        updateTerminalAuthTimer();

        return true;

    } catch (error) {
        if (errorEl) {
            errorEl.textContent = error.message;
            errorEl.style.display = 'block';
        }
        return false;
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
}

async function revokeTerminalAuth() {
    try {
        await adminFetch('/api/terminal/authenticate/revoke', {
            method: 'POST'
        });
    } catch (error) {
        console.error('Terminal auth revoke failed:', error);
    }

    terminalAccessToken = null;
    terminalTokenExpires = null;
    enableTerminalPanel(false);
}

function updateTerminalAuthTimer() {
    const timerEl = document.getElementById('terminal-auth-timer');
    if (!timerEl || !terminalTokenExpires) return;

    const update = () => {
        if (!terminalTokenExpires) {
            timerEl.textContent = '';
            return;
        }

        const remaining = Math.max(0, (terminalTokenExpires - new Date()) / 1000);

        if (remaining <= 0) {
            timerEl.textContent = 'Session expired - Re-authenticate required';
            timerEl.style.color = '#dc2626';
            terminalAccessToken = null;
            terminalTokenExpires = null;
            return;
        }

        const mins = Math.floor(remaining / 60);
        const secs = Math.floor(remaining % 60);
        timerEl.textContent = `Terminal auth expires in ${mins}:${secs.toString().padStart(2, '0')}`;
        timerEl.style.color = remaining < 300 ? '#eab308' : '#22c55e';

        setTimeout(update, 1000);
    };

    update();
}

function enableTerminalPanel(enabled) {
    const connectBtn = document.getElementById('terminal-connect');
    const serverSelect = document.getElementById('terminal-server');
    const authNotice = document.getElementById('terminal-auth-notice');

    if (connectBtn) connectBtn.disabled = !enabled;
    if (serverSelect) serverSelect.disabled = !enabled;

    if (authNotice) {
        if (enabled) {
            authNotice.innerHTML = '<span style="color: #22c55e;">✓ Terminal access authenticated</span> <span id="terminal-auth-timer" style="font-size: 0.75rem;"></span> <button class="btn btn-small btn-secondary" onclick="revokeTerminalAuth()">🔒 Lock</button>';
        } else {
            authNotice.innerHTML = '<span style="color: #dc2626;">🔒 Authentication required</span> <button class="btn btn-small btn-primary" onclick="showTerminalAuthModal()">🔓 Unlock Terminal</button>';
        }
    }
}

function setupTerminalAuthListeners() {
    // Form submit
    const form = document.getElementById('terminal-auth-form');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const password = document.getElementById('terminal-auth-password')?.value;
            if (password) {
                await authenticateTerminal(password);
            }
        });
    }

    // Close button
    const closeBtn = document.getElementById('close-terminal-auth-modal');
    if (closeBtn) {
        closeBtn.addEventListener('click', hideTerminalAuthModal);
    }

    // Cancel button
    const cancelBtn = document.getElementById('cancel-terminal-auth');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', hideTerminalAuthModal);
    }

    // Click outside to close
    const modal = document.getElementById('terminal-auth-modal');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                hideTerminalAuthModal();
            }
        });
    }
}

async function checkTerminalFeatureEnabled() {
    try {
        const response = await adminFetch('/api/terminal/status');
        if (response.ok) {
            const data = await response.json();
            return {
                available: true,
                enabled: data.enabled,
                details: data
            };
        }

        let payload = {};
        try {
            payload = await response.json();
        } catch (parseError) {
            payload = {};
        }

        return {
            available: false,
            enabled: false,
            details: payload,
            status: response.status
        };
    } catch (error) {
        console.error('Terminal status check failed:', error);
        return {
            available: false,
            enabled: false,
            details: {
                error: error.message
            }
        };
    }
}

function showTerminalDisabledMessage(status = {}) {
    const authNotice = document.getElementById('terminal-auth-notice');
    const details = status.details || {};
    const licenseDenied = details.code === 'FEATURE_UNAVAILABLE';

    if (authNotice) {
        if (licenseDenied) {
            authNotice.innerHTML = `
                <div style="text-align: center; padding: 1rem;">
                    <div style="font-size: 2rem; margin-bottom: 0.5rem;">🔐</div>
                    <div style="color: #f59e0b; font-weight: 600; margin-bottom: 0.5rem;">Remote Terminal Requires SuperAdmin + Add-On Access</div>
                    <div style="font-size: 0.875rem; color: #d1d5db; line-height: 1.5;">
                        ${escapeHtml(details.reason || 'This terminal tool is not available on the current license.')}<br>
                        ${details.upgrade_tier ? `Required entitlement: <strong>${escapeHtml(details.upgrade_tier)}</strong>.` : ''}
                    </div>
                </div>
            `;
            authNotice.style.background = 'rgba(245, 158, 11, 0.12)';
            authNotice.style.borderColor = '#f59e0b';
        } else {
            authNotice.innerHTML = `
                <div style="text-align: center; padding: 1rem;">
                    <div style="font-size: 2rem; margin-bottom: 0.5rem;">🚫</div>
                    <div style="color: #9ca3af; font-weight: 600; margin-bottom: 0.5rem;">Remote Terminal Feature is Disabled</div>
                    <div style="font-size: 0.875rem; color: #6b7280;">
                        This feature must be enabled during deployment.<br>
                        Set <code style="background: #374151; padding: 0.1rem 0.3rem; border-radius: 3px;">TERMINAL_ENABLED=true</code> in environment configuration.
                    </div>
                </div>
            `;
            authNotice.style.background = 'rgba(107, 114, 128, 0.1)';
            authNotice.style.borderColor = '#6b7280';
        }
    }

    // Disable all controls
    const controls = ['terminal-server', 'terminal-protocol', 'terminal-shell', 'terminal-connect', 'terminal-sudo'];
    controls.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.disabled = true;
    });
}

async function initRemoteTerminal() {
    // First check if terminal feature is enabled and licensed
    const terminalStatus = await checkTerminalFeatureEnabled();

    if (!terminalStatus.available || !terminalStatus.enabled) {
        showTerminalDisabledMessage(terminalStatus);
        return;
    }

    // Setup auth modal listeners
    setupTerminalAuthListeners();

    // Check if already authenticated
    const isAuthenticated = await checkTerminalAuth();
    enableTerminalPanel(isAuthenticated);

    if (isAuthenticated) {
        // Restore token from session (if browser refreshed)
        // Token is automatically stored in session cookie
        terminalAccessToken = 'session'; // Flag to use session-based token
    }

    // Load servers into dropdown
    loadServersForTerminal();

    // Update shell options based on protocol
    const protocolSelect = document.getElementById('terminal-protocol');
    if (protocolSelect) {
        protocolSelect.addEventListener('change', function() {
            updateShellOptions(this.value);
        });
    }

    // Connect button
    const connectBtn = document.getElementById('terminal-connect');
    if (connectBtn) {
        connectBtn.addEventListener('click', connectTerminal);
    }

    // Disconnect button
    const disconnectBtn = document.getElementById('terminal-disconnect');
    if (disconnectBtn) {
        disconnectBtn.addEventListener('click', disconnectTerminal);
    }

    // Clear button
    const clearBtn = document.getElementById('terminal-clear');
    if (clearBtn) {
        clearBtn.addEventListener('click', clearTerminal);
    }
}

async function loadServersForTerminal() {
    const serverSelect = document.getElementById('terminal-server');
    if (!serverSelect) return;

    try {
        const response = await adminFetch('/api/servers');
        if (response.ok) {
            const data = await response.json();
            const servers = data.servers || data || [];

            serverSelect.innerHTML = '<option value="">Select a server...</option>';
            servers.forEach(server => {
                const option = document.createElement('option');
                option.value = server.id || server.name;
                option.textContent = `${server.name} (${server.ip || server.hostname || 'N/A'})`;
                option.dataset.hostname = server.hostname || server.ip || '';
                option.dataset.os = server.os || 'unknown';
                serverSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Failed to load servers:', error);
        serverSelect.innerHTML = '<option value="">Failed to load servers</option>';
    }
}

function updateShellOptions(protocol) {
    const shellSelect = document.getElementById('terminal-shell');
    if (!shellSelect) return;

    shellSelect.innerHTML = '';

    if (protocol === 'ssh') {
        shellSelect.innerHTML = `
            <option value="bash">Bash</option>
            <option value="sh">sh</option>
            <option value="zsh">zsh</option>
        `;
    } else {
        shellSelect.innerHTML = `
            <option value="powershell">PowerShell</option>
            <option value="cmd">CMD</option>
        `;
    }
}

function updateTerminalStatus(status, message) {
    const statusEl = document.getElementById('terminal-status');
    if (statusEl) {
        statusEl.className = `terminal-status ${status}`;
        statusEl.textContent = message || getStatusText(status);
    }
}

function getStatusText(status) {
    const texts = {
        'disconnected': '● Disconnected',
        'connecting': '● Connecting...',
        'connected': '● Connected',
        'error': '● Error'
    };
    return texts[status] || '● Unknown';
}

let currentSessionId = null;
let pollingInterval = null;
let inputBuffer = '';

async function connectTerminal() {
    const serverSelect = document.getElementById('terminal-server');
    const protocolSelect = document.getElementById('terminal-protocol');
    const shellSelect = document.getElementById('terminal-shell');
    const sudoCheck = document.getElementById('terminal-sudo');

    if (!serverSelect.value) {
        alert('Please select a server');
        return;
    }

    updateTerminalStatus('connecting');

    // Hide placeholder, show terminal
    const placeholder = document.getElementById('terminal-placeholder');
    const terminalEl = document.getElementById('terminal');

    if (placeholder) placeholder.style.display = 'none';
    if (terminalEl) terminalEl.style.display = 'block';

    // Initialize xterm.js if not already
    if (!terminal && typeof Terminal !== 'undefined') {
        terminal = new Terminal({
            cursorBlink: true,
            fontFamily: "'Monaco', 'Menlo', 'Ubuntu Mono', monospace",
            fontSize: 14,
            theme: {
                background: '#1e1e1e',
                foreground: '#d4d4d4',
                cursor: '#d4d4d4',
                selection: 'rgba(255, 255, 255, 0.3)',
                black: '#000000',
                red: '#cd3131',
                green: '#0dbc79',
                yellow: '#e5e510',
                blue: '#2472c8',
                magenta: '#bc3fbc',
                cyan: '#11a8cd',
                white: '#e5e5e5'
            }
        });

        if (typeof FitAddon !== 'undefined') {
            fitAddon = new FitAddon.FitAddon();
            terminal.loadAddon(fitAddon);
        }

        if (typeof WebLinksAddon !== 'undefined') {
            terminal.loadAddon(new WebLinksAddon.WebLinksAddon());
        }

        terminal.open(terminalEl);
        if (fitAddon) fitAddon.fit();

        // Handle window resize
        window.addEventListener('resize', () => {
            if (fitAddon) fitAddon.fit();
        });
    } else if (terminal) {
        terminal.clear();
    }

    // Check if authenticated for terminal
    if (!terminalAccessToken) {
        const isAuth = await checkTerminalAuth();
        if (!isAuth) {
            showTerminalAuthModal();
            updateTerminalStatus('disconnected');
            return;
        }
    }

    // Connect via REST API
    try {
        const headers = {
            'Content-Type': 'application/json'
        };

        // Include terminal token if available
        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch('/api/terminal/sessions', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({
                server_id: serverSelect.value,
                protocol: protocolSelect.value,
                shell: shellSelect.value,
                sudo: sudoCheck.checked
            })
        });

        const data = await response.json();

        if (!response.ok) {
            // Check if auth is required
            if (data.code === 'TERMINAL_AUTH_REQUIRED') {
                showTerminalAuthModal();
                updateTerminalStatus('disconnected');
                return;
            }
            throw new Error(data.error || 'Connection failed');
        }

        currentSessionId = data.session_id;
        updateTerminalStatus('connected');
        enableTerminalControls(true);
        terminal.writeln(`\r\n\x1b[32m[Connected to ${data.server}]\x1b[0m\r\n`);

        // Start polling for output
        startOutputPolling();

        // Handle terminal input
        terminal.onData(data => {
            sendTerminalInput(data);
        });

    } catch (error) {
        console.error('Failed to connect:', error);
        updateTerminalStatus('error', `● ${error.message}`);
        terminal.writeln(`\r\n\x1b[31m[Error: ${error.message}]\x1b[0m\r\n`);
    }
}

function startOutputPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
    }

    pollingInterval = setInterval(async () => {
        if (!currentSessionId) {
            clearInterval(pollingInterval);
            return;
        }

        try {
            const headers = {};
            if (terminalAccessToken && terminalAccessToken !== 'session') {
                headers['X-Terminal-Token'] = terminalAccessToken;
            }

            const response = await adminFetch(`/api/terminal/sessions/${currentSessionId}/output`, {
                headers: headers
            });

            if (!response.ok) {
                if (response.status === 404) {
                    handleDisconnect('Session expired');
                }
                return;
            }

            const data = await response.json();

            if (data.output) {
                terminal.write(data.output);
            }

            if (!data.running) {
                handleDisconnect(data.error || 'Session ended');
            }

        } catch (error) {
            console.error('Polling error:', error);
        }
    }, 100); // Poll every 100ms
}

async function sendTerminalInput(inputData) {
    if (!currentSessionId) return;

    try {
        // Track command for history
        inputBuffer += inputData;
        if (inputData.includes('\r') || inputData.includes('\n')) {
            const cmd = inputBuffer.trim();
            if (cmd) {
                addToHistory(cmd, new Date().toISOString());
            }
            inputBuffer = '';
        }

        const headers = {
            'Content-Type': 'application/json'
        };

        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        await adminFetch(`/api/terminal/sessions/${currentSessionId}/input`, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ input: inputData })
        });
    } catch (error) {
        console.error('Send input error:', error);
    }
}

async function disconnectTerminal() {
    if (!currentSessionId) {
        handleDisconnect('Not connected');
        return;
    }

    try {
        const headers = {};

        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        await adminFetch(`/api/terminal/sessions/${currentSessionId}`, {
            method: 'DELETE',
            headers: headers
        });
    } catch (error) {
        console.error('Disconnect error:', error);
    }

    handleDisconnect('User disconnected');
}

function handleDisconnect(reason) {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
    }

    currentSessionId = null;
    updateTerminalStatus('disconnected');
    enableTerminalControls(false);

    if (terminal) {
        terminal.writeln(`\r\n\x1b[33m[${reason}]\x1b[0m\r\n`);
    }
}

function enableTerminalControls(enabled) {
    const clearBtn = document.getElementById('terminal-clear');
    const disconnectBtn = document.getElementById('terminal-disconnect');
    const connectBtn = document.getElementById('terminal-connect');

    if (clearBtn) clearBtn.disabled = !enabled;
    if (disconnectBtn) disconnectBtn.disabled = !enabled;
    if (connectBtn) connectBtn.disabled = enabled;
}

function clearTerminal() {
    if (terminal) {
        terminal.clear();
    }
}

function addToHistory(command, timestamp) {
    const historyEl = document.getElementById('terminal-history');
    if (!historyEl) return;

    // Remove empty message if present
    const emptyMsg = historyEl.querySelector('.history-empty');
    if (emptyMsg) emptyMsg.remove();

    const entry = document.createElement('div');
    entry.className = 'history-entry';
    entry.innerHTML = `
        <span class="history-time">${new Date(timestamp).toLocaleTimeString()}</span>
        <span class="history-cmd">${escapeHtml(command)}</span>
    `;
    historyEl.appendChild(entry);
    historyEl.scrollTop = historyEl.scrollHeight;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Initialize terminal when remote-terminal section is shown
document.addEventListener('click', function(e) {
    if (e.target.closest('[data-section="remote-terminal"]')) {
        setTimeout(initRemoteTerminal, 100);
    }
});

// ============================================================================
// Connection Profiles
// ============================================================================

let connectionProfiles = [];

async function loadConnectionProfiles() {
    const listEl = document.getElementById('terminal-profiles-list');
    if (!listEl) return;

    try {
        const headers = {};
        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch('/api/terminal/profiles', { headers });

        if (response.ok) {
            const data = await response.json();
            connectionProfiles = data.profiles || [];
            renderConnectionProfiles();
        } else if (response.status === 403) {
            listEl.innerHTML = '<div class="profiles-empty">Authenticate to view saved profiles</div>';
        }
    } catch (error) {
        console.error('Failed to load profiles:', error);
        listEl.innerHTML = '<div class="profiles-empty">Failed to load profiles</div>';
    }
}

function renderConnectionProfiles() {
    const listEl = document.getElementById('terminal-profiles-list');
    if (!listEl) return;

    if (connectionProfiles.length === 0) {
        listEl.innerHTML = '<div class="profiles-empty">No saved profiles yet. Create one for quick access.</div>';
        return;
    }

    listEl.innerHTML = connectionProfiles.map(profile => `
        <div class="profile-card" onclick="connectWithProfile(${profile.id})">
            <div class="profile-card-header">
                <span class="profile-name">${escapeHtml(profile.name)}</span>
                ${profile.environment ? `<span class="profile-env ${profile.environment}">${profile.environment}</span>` : ''}
            </div>
            <div class="profile-details">
                <div class="profile-host">📡 ${escapeHtml(profile.hostname)}:${profile.port}</div>
                ${profile.description ? `<div>${escapeHtml(profile.description)}</div>` : ''}
            </div>
            <div class="profile-meta">
                <span>👤 ${escapeHtml(profile.username)} • ${profile.protocol.toUpperCase()}</span>
                <div class="profile-actions">
                    <button class="profile-action-btn" onclick="event.stopPropagation(); editProfile(${profile.id})" title="Edit">✏️</button>
                    <button class="profile-action-btn" onclick="event.stopPropagation(); deleteProfile(${profile.id})" title="Delete">🗑️</button>
                </div>
            </div>
        </div>
    `).join('');
}

function showNewProfileModal() {
    document.getElementById('connection-profile-form').reset();
    document.getElementById('connection-profile-form').dataset.editId = '';

    // Show/hide per-profile restrictions based on global setting
    const restrictionsSection = document.getElementById('profile-restrictions-section');
    if (restrictionsSection) {
        restrictionsSection.style.display = window.profileRestrictionsEnabled ? 'block' : 'none';
    }

    document.getElementById('connection-profile-modal').classList.add('active');
}

async function saveConnectionProfile(event) {
    event.preventDefault();

    const form = document.getElementById('connection-profile-form');
    const editId = form.dataset.editId;

    // Gather per-profile access days
    const profileAccessDays = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
        .filter(day => document.getElementById(`profile-day-${day}`)?.checked)
        .join(',');

    const profileData = {
        name: document.getElementById('profile-name').value,
        description: document.getElementById('profile-description').value,
        hostname: document.getElementById('profile-hostname').value,
        port: parseInt(document.getElementById('profile-port').value) || 22,
        protocol: document.getElementById('profile-protocol').value,
        username: document.getElementById('profile-username').value,
        password: document.getElementById('profile-password').value,
        ssh_key_path: document.getElementById('profile-ssh-key').value,
        default_shell: document.getElementById('profile-shell').value,
        use_sudo: document.getElementById('profile-sudo').checked,
        is_shared: document.getElementById('profile-shared').checked,
        environment: document.getElementById('profile-environment').value,
        // Per-profile access restrictions (only if feature enabled)
        access_hours_start: document.getElementById('profile-access-start')?.value || '',
        access_hours_end: document.getElementById('profile-access-end')?.value || '',
        access_days: profileAccessDays
    };

    const headers = {
        'Content-Type': 'application/json'
    };

    if (terminalAccessToken && terminalAccessToken !== 'session') {
        headers['X-Terminal-Token'] = terminalAccessToken;
    }

    try {
        const url = editId ? `/api/terminal/profiles/${editId}` : '/api/terminal/profiles';
        const method = editId ? 'PUT' : 'POST';

        const response = await adminFetch(url, {
            method,
            headers,
            body: JSON.stringify(profileData)
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Failed to save profile');
        }

        closeModal('connection-profile-modal');
        loadConnectionProfiles();
        showNotification(editId ? 'Profile updated successfully' : 'Profile created successfully', 'success');

    } catch (error) {
        console.error('Failed to save profile:', error);
        showNotification(error.message, 'error');
    }
}

async function editProfile(profileId) {
    try {
        const headers = {};
        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch(`/api/terminal/profiles/${profileId}`, { headers });

        if (!response.ok) {
            throw new Error('Failed to load profile');
        }

        const data = await response.json();
        const profile = data.profile;

        // Populate form
        document.getElementById('profile-name').value = profile.name || '';
        document.getElementById('profile-description').value = profile.description || '';
        document.getElementById('profile-hostname').value = profile.hostname || '';
        document.getElementById('profile-port').value = profile.port || 22;
        document.getElementById('profile-protocol').value = profile.protocol || 'ssh';
        document.getElementById('profile-username').value = profile.username || '';
        document.getElementById('profile-ssh-key').value = profile.ssh_key_path || '';
        document.getElementById('profile-shell').value = profile.default_shell || 'bash';
        document.getElementById('profile-sudo').checked = profile.use_sudo || false;
        document.getElementById('profile-shared').checked = profile.is_shared || false;
        document.getElementById('profile-environment').value = profile.environment || '';

        // Populate per-profile access restrictions
        const restrictionsSection = document.getElementById('profile-restrictions-section');
        if (restrictionsSection && window.profileRestrictionsEnabled) {
            restrictionsSection.style.display = 'block';
            document.getElementById('profile-access-start').value = profile.access_hours_start || '';
            document.getElementById('profile-access-end').value = profile.access_hours_end || '';

            // Reset all day checkboxes first
            ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'].forEach(day => {
                const checkbox = document.getElementById(`profile-day-${day}`);
                if (checkbox) checkbox.checked = false;
            });

            // Set enabled days from profile
            if (profile.access_days) {
                const days = profile.access_days.split(',').map(d => d.trim().toLowerCase());
                days.forEach(day => {
                    const checkbox = document.getElementById(`profile-day-${day}`);
                    if (checkbox) checkbox.checked = true;
                });
            }
        } else if (restrictionsSection) {
            restrictionsSection.style.display = 'none';
        }

        document.getElementById('connection-profile-form').dataset.editId = profileId;
        document.getElementById('connection-profile-modal').classList.add('active');

    } catch (error) {
        console.error('Failed to load profile:', error);
        showNotification(error.message, 'error');
    }
}

async function deleteProfile(profileId) {
    if (!confirm('Are you sure you want to delete this profile?')) return;

    try {
        const headers = {};

        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch(`/api/terminal/profiles/${profileId}`, {
            method: 'DELETE',
            headers
        });

        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || 'Failed to delete profile');
        }

        loadConnectionProfiles();
        showNotification('Profile deleted', 'success');

    } catch (error) {
        console.error('Failed to delete profile:', error);
        showNotification(error.message, 'error');
    }
}

async function connectWithProfile(profileId) {
    if (!currentSessionId === null) {
        if (!confirm('You have an active session. Disconnect and connect to this server?')) return;
        await disconnectTerminal();
    }

    updateTerminalStatus('connecting');

    // Show terminal
    const placeholder = document.getElementById('terminal-placeholder');
    const terminalEl = document.getElementById('terminal');
    if (placeholder) placeholder.style.display = 'none';
    if (terminalEl) terminalEl.style.display = 'block';

    // Initialize xterm if needed
    if (!terminal && typeof Terminal !== 'undefined') {
        terminal = new Terminal({
            cursorBlink: true,
            fontFamily: "'Monaco', 'Menlo', 'Ubuntu Mono', monospace",
            fontSize: 14,
            theme: {
                background: '#1e1e1e',
                foreground: '#d4d4d4'
            }
        });

        if (typeof FitAddon !== 'undefined') {
            fitAddon = new FitAddon.FitAddon();
            terminal.loadAddon(fitAddon);
        }

        terminal.open(terminalEl);
        if (fitAddon) fitAddon.fit();
    } else if (terminal) {
        terminal.clear();
    }

    try {
        const headers = {
            'Content-Type': 'application/json'
        };

        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch(`/api/terminal/profiles/${profileId}/connect`, {
            method: 'POST',
            headers
        });

        const data = await response.json();

        if (!response.ok) {
            if (data.code === 'TERMINAL_AUTH_REQUIRED') {
                showTerminalAuthModal();
                updateTerminalStatus('disconnected');
                return;
            }
            throw new Error(data.error || 'Connection failed');
        }

        currentSessionId = data.session_id;
        updateTerminalStatus('connected');
        enableTerminalControls(true);
        terminal.writeln(`\r\n\x1b[32m[Connected to ${data.server} via saved profile]\x1b[0m\r\n`);

        startOutputPolling();
        terminal.onData(data => sendTerminalInput(data));

    } catch (error) {
        console.error('Failed to connect with profile:', error);
        updateTerminalStatus('error', `● ${error.message}`);
        if (terminal) terminal.writeln(`\r\n\x1b[31m[Error: ${error.message}]\x1b[0m\r\n`);
    }
}

// ============================================================================
// Session Recordings
// ============================================================================

let recordingsOffset = 0;
const recordingsLimit = 6;

async function loadSessionRecordings() {
    const listEl = document.getElementById('terminal-recordings-list');
    if (!listEl) return;

    try {
        const headers = {};
        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch(`/api/terminal/recordings?limit=${recordingsLimit}&offset=${recordingsOffset}`, { headers });

        if (response.ok) {
            const data = await response.json();
            renderSessionRecordings(data.recordings || [], data.total);
        } else if (response.status === 403) {
            listEl.innerHTML = '<div class="recordings-empty">Authenticate to view session recordings</div>';
        }
    } catch (error) {
        console.error('Failed to load recordings:', error);
        listEl.innerHTML = '<div class="recordings-empty">Failed to load recordings</div>';
    }
}

function renderSessionRecordings(recordings, total) {
    const listEl = document.getElementById('terminal-recordings-list');
    const paginationEl = document.getElementById('terminal-recordings-pagination');

    if (!listEl) return;

    if (recordings.length === 0) {
        listEl.innerHTML = '<div class="recordings-empty">No recordings yet. Session recordings appear here for playback and audit.</div>';
        if (paginationEl) paginationEl.style.display = 'none';
        return;
    }

    listEl.innerHTML = recordings.map(rec => `
        <div class="recording-card ${rec.flagged_for_review ? 'flagged' : ''}">
            <div class="recording-header">
                <span class="recording-user">👤 ${escapeHtml(rec.username)}</span>
                <span class="recording-time">${formatDateTime(rec.started_at)}</span>
            </div>
            <div class="recording-server">📡 ${escapeHtml(rec.server_hostname)}</div>
            <div class="recording-stats">
                <span class="recording-stat">⏱️ ${formatDuration(rec.duration_seconds)}</span>
                <span class="recording-stat">💬 ${rec.command_count} commands</span>
                <span class="recording-stat">${rec.status === 'completed' ? '✅' : '⚠️'} ${rec.status}</span>
                ${rec.flagged_for_review ? '<span class="recording-stat">🚩 Flagged</span>' : ''}
            </div>
            <div class="recording-actions">
                <button class="btn btn-small btn-primary" onclick="playRecording(${rec.id})">▶ Play</button>
                <button class="btn btn-small btn-secondary" onclick="toggleRecordingFlag(${rec.id}, ${!rec.flagged_for_review})">${rec.flagged_for_review ? '🏳️ Unflag' : '🚩 Flag'}</button>
                <button class="btn btn-small btn-danger" onclick="deleteRecording(${rec.id})">🗑️</button>
            </div>
        </div>
    `).join('');

    // Update pagination
    if (paginationEl && total > recordingsLimit) {
        paginationEl.style.display = 'flex';
        document.getElementById('recordings-page-info').textContent =
            `${recordingsOffset + 1}-${Math.min(recordingsOffset + recordingsLimit, total)} of ${total}`;
        document.getElementById('recordings-prev').disabled = recordingsOffset === 0;
        document.getElementById('recordings-next').disabled = recordingsOffset + recordingsLimit >= total;
    }
}

function formatDateTime(isoString) {
    if (!isoString) return '-';
    const date = new Date(isoString);
    return date.toLocaleString();
}

function formatDuration(seconds) {
    if (!seconds) return '0s';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
}

let playbackTerminal = null;
let playbackEvents = [];
let playbackIndex = 0;
let playbackTimer = null;
let playbackSpeed = 1;

async function playRecording(recordingId) {
    try {
        const headers = {};
        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch(`/api/terminal/recordings/${recordingId}/playback`, { headers });

        if (!response.ok) {
            throw new Error('Failed to load recording');
        }

        const data = await response.json();

        // Populate modal
        document.getElementById('playback-user').textContent = data.username;
        document.getElementById('playback-server').textContent = data.server;
        document.getElementById('playback-started').textContent = formatDateTime(data.started_at);
        document.getElementById('playback-duration').textContent = formatDuration(data.duration_seconds);

        // Parse commands
        let commands = [];
        try {
            commands = typeof data.commands === 'string' ? JSON.parse(data.commands || '[]') : [];
        } catch (e) {}

        document.getElementById('playback-commands').innerHTML = commands.length > 0
            ? commands.map(c => `<div class="command-item"><span class="command-time">${c.t.toFixed(1)}s</span><span class="command-text">${escapeHtml(c.cmd)}</span></div>`).join('')
            : '<div style="color: #6b7280; font-style: italic;">No commands recorded</div>';

        // Initialize playback terminal
        const termContainer = document.getElementById('playback-terminal');
        if (playbackTerminal) {
            playbackTerminal.dispose();
        }

        playbackTerminal = new Terminal({
            cursorBlink: false,
            fontFamily: "'Monaco', 'Menlo', 'Ubuntu Mono', monospace",
            fontSize: 14,
            theme: { background: '#1e1e1e', foreground: '#d4d4d4' }
        });

        playbackTerminal.open(termContainer);

        if (typeof FitAddon !== 'undefined') {
            const fit = new FitAddon.FitAddon();
            playbackTerminal.loadAddon(fit);
            setTimeout(() => fit.fit(), 100);
        }

        // Store events for playback
        playbackEvents = data.events || [];
        playbackIndex = 0;

        // Show modal
        document.getElementById('recording-playback-modal').classList.add('active');

    } catch (error) {
        console.error('Failed to play recording:', error);
        showNotification(error.message, 'error');
    }
}

function startPlayback() {
    if (playbackTimer) clearInterval(playbackTimer);
    if (playbackIndex >= playbackEvents.length) {
        playbackIndex = 0;
        playbackTerminal.clear();
    }

    document.getElementById('playback-play').disabled = true;
    document.getElementById('playback-pause').disabled = false;

    const startTime = playbackEvents[playbackIndex]?.t || 0;
    let lastTime = performance.now();
    let elapsedTime = startTime;

    playbackTimer = setInterval(() => {
        const now = performance.now();
        elapsedTime += ((now - lastTime) / 1000) * playbackSpeed;
        lastTime = now;

        while (playbackIndex < playbackEvents.length && playbackEvents[playbackIndex].t <= elapsedTime) {
            const event = playbackEvents[playbackIndex];
            if (event.type === 'o' && event.data) {
                playbackTerminal.write(event.data);
            }
            playbackIndex++;
        }

        // Update time display
        const totalDuration = playbackEvents.length > 0 ? playbackEvents[playbackEvents.length - 1].t : 0;
        document.getElementById('playback-time').textContent =
            `${formatDuration(elapsedTime)} / ${formatDuration(totalDuration)}`;

        if (playbackIndex >= playbackEvents.length) {
            pausePlayback();
        }
    }, 50);
}

function pausePlayback() {
    if (playbackTimer) {
        clearInterval(playbackTimer);
        playbackTimer = null;
    }
    document.getElementById('playback-play').disabled = false;
    document.getElementById('playback-pause').disabled = true;
}

function restartPlayback() {
    pausePlayback();
    playbackIndex = 0;
    if (playbackTerminal) playbackTerminal.clear();
    document.getElementById('playback-time').textContent = `0:00 / ${formatDuration(playbackEvents.length > 0 ? playbackEvents[playbackEvents.length - 1].t : 0)}`;
}

async function toggleRecordingFlag(recordingId, flagged) {
    try {
        const headers = {
            'Content-Type': 'application/json'
        };

        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch(`/api/terminal/recordings/${recordingId}/flag`, {
            method: 'POST',
            headers,
            body: JSON.stringify({ flagged })
        });

        if (!response.ok) {
            throw new Error('Failed to update flag');
        }

        loadSessionRecordings();
        showNotification(flagged ? 'Recording flagged for review' : 'Flag removed', 'success');

    } catch (error) {
        console.error('Failed to flag recording:', error);
        showNotification(error.message, 'error');
    }
}

async function deleteRecording(recordingId) {
    if (!confirm('Are you sure you want to delete this recording?')) return;

    try {
        const headers = {};

        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch(`/api/terminal/recordings/${recordingId}`, {
            method: 'DELETE',
            headers
        });

        if (!response.ok) {
            throw new Error('Failed to delete recording');
        }

        loadSessionRecordings();
        showNotification('Recording deleted', 'success');

    } catch (error) {
        console.error('Failed to delete recording:', error);
        showNotification(error.message, 'error');
    }
}

// ============================================================================
// Access Schedule
// ============================================================================

async function loadAccessSchedule() {
    try {
        const headers = {};
        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch('/api/terminal/config', { headers });

        if (response.ok) {
            const config = await response.json();

            document.getElementById('access-hours-value').textContent = config.access_hours || '24/7';
            document.getElementById('access-days-value').textContent = config.access_days || 'All days';
            document.getElementById('access-timezone-value').textContent = config.access_timezone || 'UTC';

            const statusEl = document.getElementById('access-current-status');
            if (config.time_access_allowed) {
                statusEl.className = 'access-value badge badge-success';
                statusEl.textContent = 'Allowed';
            } else {
                statusEl.className = 'access-value badge badge-danger';
                statusEl.textContent = 'Restricted';
                statusEl.title = config.time_access_message || '';
            }

            // Update recording status
            const recordingBadge = document.getElementById('recording-enabled-badge');
            if (recordingBadge) {
                if (config.recording_enabled) {
                    recordingBadge.className = 'badge badge-success';
                    recordingBadge.textContent = 'Enabled';
                } else {
                    recordingBadge.className = 'badge badge-warning';
                    recordingBadge.textContent = 'Disabled';
                }
            }

            // Update profiles section visibility
            updateProfilesSectionVisibility(config.profiles_enabled);

            // Store profile restrictions enabled state for profile modal
            window.profileRestrictionsEnabled = config.profile_restrictions_enabled;
        }
    } catch (error) {
        console.error('Failed to load access schedule:', error);
    }
}

function updateProfilesSectionVisibility(enabled) {
    const profilesSection = document.getElementById('terminal-profiles-section');
    if (profilesSection) {
        if (enabled) {
            profilesSection.style.display = '';
            profilesSection.style.opacity = '1';
        } else {
            profilesSection.style.display = 'none';
        }
    }
}

function updateProfileRestrictionsState() {
    const profilesEnabled = document.getElementById('settings-profiles').checked;
    const restrictionsCheckbox = document.getElementById('settings-profile-restrictions');
    const restrictionsGroup = document.getElementById('profile-restrictions-group');

    if (restrictionsCheckbox && restrictionsGroup) {
        if (profilesEnabled) {
            restrictionsCheckbox.disabled = false;
            restrictionsGroup.style.opacity = '1';
        } else {
            restrictionsCheckbox.checked = false;
            restrictionsCheckbox.disabled = true;
            restrictionsGroup.style.opacity = '0.5';
        }
    }
}

// ============================================================================
// Terminal Settings Management
// ============================================================================

async function showTerminalSettingsModal() {
    // Load current settings
    try {
        const headers = {};
        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch('/api/terminal/settings', { headers });

        if (!response.ok) {
            if (response.status === 403) {
                showNotification('Terminal authentication required to configure settings', 'error');
                return;
            }
            throw new Error('Failed to load settings');
        }

        const data = await response.json();
        const settings = data.settings;

        // Populate form with current values
        document.getElementById('settings-hours-start').value = settings.access_hours_start || '';
        document.getElementById('settings-hours-end').value = settings.access_hours_end || '';
        document.getElementById('settings-timezone').value = settings.access_timezone || 'UTC';

        // Set day checkboxes
        const activeDays = (settings.access_days || '').toLowerCase().split(',').map(d => d.trim());
        ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'].forEach(day => {
            const checkbox = document.getElementById(`day-${day}`);
            if (checkbox) {
                checkbox.checked = activeDays.includes(day);
            }
        });

        // Session limits
        document.getElementById('settings-max-sessions').value = settings.max_sessions || 5;
        document.getElementById('settings-session-timeout').value = settings.session_timeout_minutes || 60;
        document.getElementById('settings-idle-timeout').value = settings.idle_timeout_minutes || 15;
        document.getElementById('settings-token-validity').value = settings.token_validity_minutes || 30;

        // Feature toggles
        document.getElementById('settings-secondary-auth').checked = settings.require_secondary_auth !== false;
        document.getElementById('settings-recording').checked = settings.recording_enabled !== false;
        document.getElementById('settings-profiles').checked = settings.profiles_enabled === true;
        document.getElementById('settings-profile-restrictions').checked = settings.profile_restrictions_enabled === true;

        // Update profile restrictions toggle state based on profiles_enabled
        updateProfileRestrictionsState();

        // Security
        document.getElementById('settings-allowed-ips').value = settings.allowed_ips || '';
        document.getElementById('settings-command-blacklist').value = settings.command_blacklist || '';

        // Recording settings
        document.getElementById('settings-recording-max-size').value = settings.recording_max_size_mb || 50;
        document.getElementById('settings-recording-retention').value = settings.recording_retention_days || 90;

        // Show modal
        document.getElementById('terminal-settings-modal').classList.add('active');

    } catch (error) {
        console.error('Failed to load settings:', error);
        showNotification(error.message, 'error');
    }
}

async function saveTerminalSettings(event) {
    event.preventDefault();

    // Gather form values
    const accessDays = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
        .filter(day => document.getElementById(`day-${day}`)?.checked)
        .join(',');

    const settingsData = {
        access_hours_start: document.getElementById('settings-hours-start').value || '',
        access_hours_end: document.getElementById('settings-hours-end').value || '',
        access_timezone: document.getElementById('settings-timezone').value || 'UTC',
        access_days: accessDays,
        max_sessions: parseInt(document.getElementById('settings-max-sessions').value) || 5,
        session_timeout_minutes: parseInt(document.getElementById('settings-session-timeout').value) || 60,
        idle_timeout_minutes: parseInt(document.getElementById('settings-idle-timeout').value) || 15,
        token_validity_minutes: parseInt(document.getElementById('settings-token-validity').value) || 30,
        require_secondary_auth: document.getElementById('settings-secondary-auth').checked,
        recording_enabled: document.getElementById('settings-recording').checked,
        profiles_enabled: document.getElementById('settings-profiles').checked,
        profile_restrictions_enabled: document.getElementById('settings-profile-restrictions').checked,
        allowed_ips: document.getElementById('settings-allowed-ips').value || '',
        command_blacklist: document.getElementById('settings-command-blacklist').value || '',
        recording_max_size_mb: parseInt(document.getElementById('settings-recording-max-size').value) || 50,
        recording_retention_days: parseInt(document.getElementById('settings-recording-retention').value) || 90
    };

    try {
        const headers = {
            'Content-Type': 'application/json'
        };

        if (terminalAccessToken && terminalAccessToken !== 'session') {
            headers['X-Terminal-Token'] = terminalAccessToken;
        }

        const response = await adminFetch('/api/terminal/settings', {
            method: 'PUT',
            headers,
            body: JSON.stringify(settingsData)
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Failed to save settings');
        }

        closeModal('terminal-settings-modal');
        loadAccessSchedule();  // Refresh the display
        showNotification('Settings saved successfully', 'success');

    } catch (error) {
        console.error('Failed to save settings:', error);
        showNotification(error.message, 'error');
    }
}

// ============================================================================
// Initialize Terminal Features
// ============================================================================

// Override initRemoteTerminal to also load profiles and recordings
const originalInitRemoteTerminal = initRemoteTerminal;
async function initRemoteTerminalExtended() {
    await originalInitRemoteTerminal.call(this);

    // Setup profile form listener
    const profileForm = document.getElementById('connection-profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', saveConnectionProfile);
    }

    // Setup new profile button
    const newProfileBtn = document.getElementById('terminal-new-profile');
    if (newProfileBtn) {
        newProfileBtn.addEventListener('click', showNewProfileModal);
    }

    // Setup refresh recordings button
    const refreshRecordingsBtn = document.getElementById('terminal-refresh-recordings');
    if (refreshRecordingsBtn) {
        refreshRecordingsBtn.addEventListener('click', loadSessionRecordings);
    }

    // Setup recordings pagination
    document.getElementById('recordings-prev')?.addEventListener('click', () => {
        recordingsOffset = Math.max(0, recordingsOffset - recordingsLimit);
        loadSessionRecordings();
    });

    document.getElementById('recordings-next')?.addEventListener('click', () => {
        recordingsOffset += recordingsLimit;
        loadSessionRecordings();
    });

    // Setup playback controls
    document.getElementById('playback-play')?.addEventListener('click', startPlayback);
    document.getElementById('playback-pause')?.addEventListener('click', pausePlayback);
    document.getElementById('playback-restart')?.addEventListener('click', restartPlayback);
    document.getElementById('playback-speed')?.addEventListener('input', (e) => {
        playbackSpeed = parseFloat(e.target.value);
        document.getElementById('playback-speed-label').textContent = `${playbackSpeed}x`;
    });

    // Setup settings form listener
    const settingsForm = document.getElementById('terminal-settings-form');
    if (settingsForm) {
        settingsForm.addEventListener('submit', saveTerminalSettings);
    }

    // Setup profiles checkbox listener to toggle profile restrictions availability
    const profilesCheckbox = document.getElementById('settings-profiles');
    if (profilesCheckbox) {
        profilesCheckbox.addEventListener('change', updateProfileRestrictionsState);
    }

    // Always load access schedule (SuperAdmin via Flask-Login is sufficient)
    loadAccessSchedule();

    // Load additional data when terminal authenticated
    const isAuth = await checkTerminalAuth();
    if (isAuth) {
        loadConnectionProfiles();
        loadSessionRecordings();

        // Enable buttons
        document.getElementById('terminal-new-profile')?.removeAttribute('disabled');
        document.getElementById('terminal-refresh-recordings')?.removeAttribute('disabled');
    }
}

// Replace the original function
initRemoteTerminal = initRemoteTerminalExtended;

// Helper function for notifications
function showNotification(message, type = 'info') {
    showToast(message, type);
}

// Modal helper
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        // Cleanup playback when closing
        if (modalId === 'recording-playback-modal') {
            pausePlayback();
        }
    }
}

// ============================================
// Debug Management (Support Team)
// ============================================
async function loadDebugStatus() {
    try {
        const response = await adminFetch('/api/debug/status');
        if (!response.ok) return;

        const status = await response.json();
        const state = status.state || {};

        // Update status indicator
        const indicator = document.getElementById('debug-status-indicator');
        if (indicator) {
            const isActive = state.server_debug || state.client_debug || state.sql_debug;
            indicator.textContent = isActive ? 'Active' : 'Disabled';
            indicator.className = `status-badge ${isActive ? 'status-running' : 'status-inactive'}`;
        }

        // Update individual status displays
        updateDebugIndicator('debug-server-status', state.server_debug);
        updateDebugIndicator('debug-client-status', state.client_debug);
        updateDebugIndicator('debug-sql-status', state.sql_debug);

        const levelEl = document.getElementById('debug-level-status');
        if (levelEl) levelEl.textContent = state.log_level || 'INFO';

        // Update auto-disable countdown
        const autoDisableEl = document.getElementById('debug-auto-disable');
        const timeRemainingEl = document.getElementById('debug-time-remaining');
        if (autoDisableEl && timeRemainingEl) {
            if (status.auto_disable_at) {
                const remaining = Math.max(0, Math.ceil(status.minutes_until_disable || 0));
                timeRemainingEl.textContent = remaining;
                autoDisableEl.style.display = remaining > 0 ? 'block' : 'none';
            } else {
                autoDisableEl.style.display = 'none';
            }
        }

        // Update toggle states
        setCheckboxById('setting-js-debug', state.client_debug);
        setCheckboxById('setting-sql-debug', state.sql_debug);
        setCheckboxById('setting-sse-debug', state.sse_debug);
        setInputById('setting-debug-timeout', state.auto_disable_minutes || 30);

    } catch (error) {
        console.error('Error loading debug status:', error);
    }
}

function updateDebugIndicator(elementId, isEnabled) {
    const el = document.getElementById(elementId);
    if (el) {
        el.textContent = isEnabled ? '🟢 On' : '⚫ Off';
        el.style.color = isEnabled ? 'var(--color-success)' : 'var(--text-muted)';
    }
}

async function enableAllDebug() {
    try {
        const timeout = parseInt(document.getElementById('setting-debug-timeout')?.value) || 30;

        const response = await adminFetch('/api/debug/enable', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                server_debug: true,
                client_debug: true,
                sql_debug: true,
                sse_debug: true,
                wizard_debug: true,
                log_level: 'DEBUG',
                auto_disable_minutes: timeout
            })
        });

        if (response.ok) {
            showNotification('Debug mode enabled. Auto-disables in ' + timeout + ' minutes.', 'warning');
            await loadDebugStatus();
            applyClientDebugSettings();
        } else {
            const err = await response.json();
            showNotification('Failed to enable debug: ' + (err.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error enabling debug:', error);
        showNotification('Error enabling debug mode', 'error');
    }
}

async function disableAllDebug() {
    try {
        const response = await adminFetch('/api/debug/disable', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        if (response.ok) {
            showNotification('Debug mode disabled. Logs reset to INFO level.', 'success');
            await loadDebugStatus();
            applyClientDebugSettings();
        } else {
            const err = await response.json();
            showNotification('Failed to disable debug: ' + (err.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error disabling debug:', error);
        showNotification('Error disabling debug mode', 'error');
    }
}

async function refreshDebugStatus() {
    await loadDebugStatus();
    showNotification('Debug status refreshed', 'info');
}

async function applyClientDebugSettings() {
    // Fetch current client debug config and apply to JS flags
    try {
        const response = await adminFetch('/api/debug/client-config');
        if (!response.ok) return;

        const config = await response.json();

        // Apply to global debug flags (these are in wizard.js and sse-client.js)
        if (typeof window.WIZARD_DEBUG !== 'undefined') {
            window.WIZARD_DEBUG = config.wizard_debug || false;
        }
        if (typeof window.SSE_DEBUG !== 'undefined') {
            window.SSE_DEBUG = config.sse_debug || false;
        }

        // Log that debug settings were applied
        if (config.client_debug) {
            console.log('[Debug] Client debug settings applied:', config);
        }
    } catch (error) {
        console.error('Error applying client debug settings:', error);
    }
}

// Load debug status when settings panel opens
document.addEventListener('DOMContentLoaded', function() {
    // Check for admin panel and load debug status
    const settingsPanel = document.getElementById('admin-settings-panel');
    if (settingsPanel) {
        // Load debug status when navigating to settings
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.target.classList?.contains('active')) {
                    loadDebugStatus();
                }
            });
        });
        observer.observe(settingsPanel, { attributes: true, attributeFilter: ['class'] });
    }
});

// Export for global access
window.showToast = showToast;
window.escapeHtml = escapeHtml;
window.initAdmin = initAdmin;
window.downloadBackup = downloadBackup;
window.deleteBackup = deleteBackup;
window.openAddUserModal = openAddUserModal;
window.closeAddUserModal = closeAddUserModal;
window.editUser = editUser;
window.resetUserPassword = resetUserPassword;
window.deleteUser = deleteUser;
window.initRemoteTerminal = initRemoteTerminal;
window.connectTerminal = connectTerminal;
window.disconnectTerminal = disconnectTerminal;
window.showTerminalAuthModal = showTerminalAuthModal;
window.hideTerminalAuthModal = hideTerminalAuthModal;
window.authenticateTerminal = authenticateTerminal;
window.revokeTerminalAuth = revokeTerminalAuth;
window.connectWithProfile = connectWithProfile;
window.editProfile = editProfile;
window.deleteProfile = deleteProfile;
window.playRecording = playRecording;
window.toggleRecordingFlag = toggleRecordingFlag;
window.deleteRecording = deleteRecording;
window.closeModal = closeModal;
window.showTerminalSettingsModal = showTerminalSettingsModal;
window.saveTerminalSettings = saveTerminalSettings;
window.enableAllDebug = enableAllDebug;
window.disableAllDebug = disableAllDebug;
window.refreshDebugStatus = refreshDebugStatus;
window.loadDebugStatus = loadDebugStatus;

// ============================================
// Collapsible Sidebar
// ============================================

/**
 * Initialize admin sidebar toggle functionality
 */
function initSidebarToggle() {
    const sidebar = document.getElementById('admin-sidebar');
    const toggleBtn = document.getElementById('admin-sidebar-toggle');

    if (!sidebar || !toggleBtn) return;

    // Load saved state from localStorage
    const isCollapsed = localStorage.getItem('adminSidebarCollapsed') === 'true';
    if (isCollapsed) {
        sidebar.classList.add('collapsed');
    }

    // Toggle handler
    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        const collapsed = sidebar.classList.contains('collapsed');
        localStorage.setItem('adminSidebarCollapsed', collapsed);
    });

    // Keyboard shortcut Ctrl+B to toggle sidebar
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'b' && !e.shiftKey && !e.altKey) {
            // Only toggle if admin tab is active
            const adminTab = document.getElementById('admin-tab');
            if (adminTab && adminTab.classList.contains('active')) {
                e.preventDefault();
                toggleBtn.click();
            }
        }
    });
}

// Initialize sidebar toggle when DOM is ready
document.addEventListener('DOMContentLoaded', initSidebarToggle);

// ============================================
// Script Review Module (Admin/SuperAdmin)
// Read-only audit script viewing
// ============================================

let scriptReviewState = {
    tree: null,
    categories: [],
    currentScript: null,
    initialized: false
};

/**
 * Toggle script browser visibility
 */
function toggleScriptBrowser() {
    const panel = document.getElementById('script-browser-panel');
    const toggle = document.getElementById('script-browser-toggle');
    if (!panel || !toggle) return;

    const isCollapsed = panel.style.display === 'none';
    panel.style.display = isCollapsed ? 'block' : 'none';
    toggle.textContent = isCollapsed ? '▼' : '▶';
}
window.toggleScriptBrowser = toggleScriptBrowser;

/**
 * Initialize script review functionality
 */
async function initScriptReview() {
    if (scriptReviewState.initialized) return;

    console.log('[ScriptReview] Initializing...');

    // Setup anti-copy protection
    setupAntiCopyProtection();

    // Setup event listeners
    setupScriptReviewListeners();

    // Load script tree
    await loadScriptTree();

    // Load categories
    await loadScriptCategories();

    scriptReviewState.initialized = true;
    console.log('[ScriptReview] Initialized successfully');
}

/**
 * Setup anti-copy protections for script viewer
 */
function setupAntiCopyProtection() {
    const viewer = document.getElementById('script-viewer-content');
    if (!viewer) return;

    // Prevent right-click context menu
    viewer.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        showNotification('Script copying is disabled for security', 'warning');
        return false;
    });

    // Prevent copy keyboard shortcut
    viewer.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && (e.key === 'c' || e.key === 'C' || e.key === 'a' || e.key === 'A')) {
            e.preventDefault();
            showNotification('Script copying is disabled for security', 'warning');
            return false;
        }
    });

    // Prevent copy event
    viewer.addEventListener('copy', (e) => {
        e.preventDefault();
        showNotification('Script copying is disabled for security', 'warning');
        return false;
    });

    // Prevent drag
    viewer.addEventListener('dragstart', (e) => {
        e.preventDefault();
        return false;
    });

    // Prevent selection via selectstart
    viewer.addEventListener('selectstart', (e) => {
        e.preventDefault();
        return false;
    });
}

/**
 * Setup event listeners for script review
 */
function setupScriptReviewListeners() {
    // Clear button - CSP-compliant event listener
    const clearBtn = document.getElementById('script-clear-btn');
    if (clearBtn) {
        clearBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            clearScriptSelection();
        });
        console.log('[ScriptReview] Clear button listener attached');
    }

    // Browser header toggle - CSP-compliant event listener
    const browserHeader = document.getElementById('script-browser-header');
    if (browserHeader) {
        browserHeader.addEventListener('click', (e) => {
            e.preventDefault();
            toggleScriptBrowser();
        });
        console.log('[ScriptReview] Browser header listener attached');
    }

    // Platform filter change
    const platformFilter = document.getElementById('script-filter-platform');
    if (platformFilter) {
        platformFilter.addEventListener('change', () => {
            loadScriptTree();
            updateCategoryFilter();
        });
    }

    // Category filter change
    const categoryFilter = document.getElementById('script-filter-category');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', loadScriptTree);
    }

    // Search input
    const searchInput = document.getElementById('script-search');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', () => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(loadScriptTree, 300);
        });
    }

    // Filter button
    const filterBtn = document.getElementById('script-apply-filter');
    if (filterBtn) {
        filterBtn.addEventListener('click', loadScriptTree);
    }
}

/**
 * Load script tree from API
 */
async function loadScriptTree() {
    const treeContainer = document.getElementById('script-tree');
    if (!treeContainer) return;

    // Show loading
    treeContainer.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">Loading scripts...</div>';

    try {
        // Build query params
        const params = new URLSearchParams();

        const platform = document.getElementById('script-filter-platform')?.value;
        const category = document.getElementById('script-filter-category')?.value;
        const search = document.getElementById('script-search')?.value;

        if (platform) params.append('platform', platform);
        if (category) params.append('category', category);
        if (search) params.append('search', search);

        const url = `/api/superadmin/audits/tree${params.toString() ? '?' + params.toString() : ''}`;
        const response = await adminFetch(url);

        if (!response.ok) {
            if (response.status === 401 || response.status === 403) {
                treeContainer.innerHTML = '<div style="text-align: center; padding: 2rem; color: #dc2626;">Access denied. Admin or SuperAdmin role required.</div>';
                return;
            }
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();
        scriptReviewState.tree = data.tree || data;

        // Render tree
        renderScriptTree(scriptReviewState.tree, treeContainer);

    } catch (error) {
        console.error('[ScriptReview] Failed to load tree:', error);
        treeContainer.innerHTML = '<div style="text-align: center; padding: 2rem; color: #dc2626;">Failed to load scripts: ' + escapeHtml(error.message) + '</div>';
    }
}

/**
 * Render script tree recursively
 */
function renderScriptTree(node, container, depth = 0) {
    container.innerHTML = '';

    if (!node || (!node.children && !node.scripts)) {
        container.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">No scripts found</div>';
        return;
    }

    // Render folders/categories
    if (node.children) {
        for (const [name, child] of Object.entries(node.children)) {
            const folderEl = document.createElement('div');
            folderEl.className = 'tree-folder';
            folderEl.innerHTML = `
                <span class="tree-folder-icon">📁</span>
                <span class="tree-folder-name">${escapeHtml(name)}</span>
            `;

            const childrenContainer = document.createElement('div');
            childrenContainer.className = 'tree-children';
            childrenContainer.style.display = depth < 1 ? 'block' : 'none';

            folderEl.addEventListener('click', (e) => {
                e.stopPropagation();
                const icon = folderEl.querySelector('.tree-folder-icon');
                if (childrenContainer.style.display === 'none') {
                    childrenContainer.style.display = 'block';
                    icon.textContent = '📂';
                } else {
                    childrenContainer.style.display = 'none';
                    icon.textContent = '📁';
                }
            });

            container.appendChild(folderEl);
            renderScriptTree(child, childrenContainer, depth + 1);
            container.appendChild(childrenContainer);
        }
    }

    // Render scripts
    if (node.scripts && Array.isArray(node.scripts)) {
        for (const script of node.scripts) {
            const fileEl = document.createElement('div');
            fileEl.className = 'tree-file';
            fileEl.setAttribute('data-path', script.path);

            const icon = script.name.endsWith('.ps1') ? '📘' :
                        script.name.endsWith('.sh') ? '📜' : '📄';

            fileEl.innerHTML = `
                <span class="tree-file-icon">${icon}</span>
                <span class="tree-file-name">${escapeHtml(script.name)}</span>
            `;

            fileEl.addEventListener('click', (e) => {
                e.stopPropagation();
                // Remove active from all files
                document.querySelectorAll('#script-tree .tree-file').forEach(f => f.classList.remove('active'));
                fileEl.classList.add('active');
                loadScriptContent(script.path);
            });

            container.appendChild(fileEl);
        }
    }
}

/**
 * Load script content
 */
async function loadScriptContent(path) {
    const codeEl = document.getElementById('script-code');
    const titleEl = document.getElementById('script-viewer-title');
    const pathEl = document.getElementById('script-viewer-path');

    if (!codeEl) return;

    codeEl.textContent = 'Loading...';

    try {
        const response = await adminFetch(`/api/superadmin/audits/scripts/view?path=${encodeURIComponent(path)}`);

        if (!response.ok) {
            if (response.status === 403) {
                codeEl.textContent = 'Access denied - path not allowed';
                return;
            }
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();
        console.log('[ScriptReview] API response:', JSON.stringify(data, null, 2));

        // API returns: { success, script: { content, metadata: {...}, line_count }, readonly, message }
        const script = data.script || {};
        const content = script.content || '';
        const metadata = script.metadata || {};

        console.log('[ScriptReview] Script metadata:', metadata);
        console.log('[ScriptReview] Content length:', content.length);

        // Update viewer with script content
        codeEl.textContent = content || 'No content available';

        // Update title and path
        const scriptName = metadata.name || path.split('/').pop();
        if (titleEl) titleEl.textContent = scriptName;
        if (pathEl) pathEl.textContent = metadata.path || path;

        // Update info stats - note: API uses size_bytes not size
        updateScriptInfo({
            line_count: script.line_count || (content ? content.split('\n').length : 0),
            size: metadata.size_bytes || metadata.size || (content ? content.length : 0),
            name: scriptName,
            path: metadata.path || path,
            extension: metadata.extension
        });

        // Enable clear button
        const clearBtn = document.getElementById('script-clear-btn');
        if (clearBtn) clearBtn.disabled = false;

        scriptReviewState.currentScript = script;

    } catch (error) {
        console.error('[ScriptReview] Failed to load script:', error);
        codeEl.textContent = 'Error loading script: ' + error.message;
    }
}

/**
 * Update script info display
 */
function updateScriptInfo(data) {
    console.log('[ScriptReview] updateScriptInfo called with:', data);

    const linesEl = document.getElementById('script-info-lines');
    const sizeEl = document.getElementById('script-info-size');
    const typeEl = document.getElementById('script-info-type');
    const platformEl = document.getElementById('script-info-platform');

    if (linesEl) {
        linesEl.textContent = data.line_count || '-';
    }
    if (sizeEl) {
        sizeEl.textContent = formatBytes(data.size || 0);
    }
    if (typeEl) {
        // Use extension from data or extract from name
        let ext = data.extension || '';
        if (!ext && data.name) {
            const parts = data.name.split('.');
            ext = parts.length > 1 ? '.' + parts.pop() : '';
        }
        typeEl.textContent = ext ? ext.replace('.', '').toUpperCase() : '-';
    }
    if (platformEl) {
        const path = data.path || '';
        const platform = path.includes('linux') ? 'Linux' :
                        path.includes('windows') ? 'Windows' :
                        path.includes('hypervisors') ? 'Hypervisor' : '-';
        platformEl.textContent = platform;
    }
}

/**
 * Format bytes to human readable
 */
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

/**
 * Load script categories
 */
async function loadScriptCategories() {
    try {
        const response = await adminFetch('/api/superadmin/audits/categories');
        if (!response.ok) return;

        const data = await response.json();
        scriptReviewState.categories = data.categories || [];

        updateCategoryFilter();

    } catch (error) {
        console.error('[ScriptReview] Failed to load categories:', error);
    }
}

/**
 * Update category filter dropdown
 */
function updateCategoryFilter() {
    const categoryFilter = document.getElementById('script-filter-category');
    if (!categoryFilter) return;

    const platform = document.getElementById('script-filter-platform')?.value || '';

    // Filter categories by selected platform
    let categories = scriptReviewState.categories;
    if (platform) {
        categories = categories.filter(c => c.platform === platform);
    }

    // Build options
    let html = '<option value="">All Categories</option>';
    categories.forEach(cat => {
        html += `<option value="${escapeHtml(cat.name)}">${escapeHtml(cat.name)} (${cat.count})</option>`;
    });

    categoryFilter.innerHTML = html;
}

// Initialize script review when panel becomes active
document.addEventListener('DOMContentLoaded', () => {
    // Watch for script-review panel activation
    const panel = document.getElementById('admin-panel-script-review');
    if (panel) {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.attributeName === 'class') {
                    if (panel.classList.contains('active')) {
                        initScriptReview();
                    }
                }
            });
        });
        observer.observe(panel, { attributes: true });
    }

    // Also initialize on nav click
    const navItem = document.querySelector('[data-section="script-review"]');
    if (navItem) {
        navItem.addEventListener('click', () => {
            setTimeout(initScriptReview, 100);
        });
    }
});

// Export for global access
window.initScriptReview = initScriptReview;
window.loadScriptTree = loadScriptTree;
window.loadScriptContent = loadScriptContent;
/**
 * Clear script selection and reset viewer to initial state
 */
function clearScriptSelection() {
    console.log('[ScriptReview] Clear button clicked');

    const defaultText = 'Select a script from the browser above to view its contents.\n\nTip: Click on folders to expand them and see available scripts.';

    // Reset code viewer - multiple approaches to ensure it clears
    const codeEl = document.getElementById('script-code');
    console.log('[ScriptReview] Found script-code element:', codeEl);
    if (codeEl) {
        // Clear using multiple methods
        codeEl.innerHTML = '';
        codeEl.innerText = defaultText;
        // Force reflow
        void codeEl.offsetHeight;
        console.log('[ScriptReview] Reset code content, new length:', codeEl.textContent.length);
    } else {
        console.error('[ScriptReview] ERROR: script-code element not found!');
    }

    // Also scroll viewer to top
    const viewerContent = document.getElementById('script-viewer-content');
    if (viewerContent) {
        viewerContent.scrollTop = 0;
    }

    // Reset title and path
    const titleEl = document.getElementById('script-viewer-title');
    const pathEl = document.getElementById('script-viewer-path');
    if (titleEl) {
        titleEl.textContent = 'No script selected';
        console.log('[ScriptReview] Reset title');
    }
    if (pathEl) {
        pathEl.textContent = '';
    }

    // Reset info stats
    const linesEl = document.getElementById('script-info-lines');
    const sizeEl = document.getElementById('script-info-size');
    const typeEl = document.getElementById('script-info-type');
    const platformEl = document.getElementById('script-info-platform');
    if (linesEl) linesEl.textContent = '-';
    if (sizeEl) sizeEl.textContent = '-';
    if (typeEl) typeEl.textContent = '-';
    if (platformEl) platformEl.textContent = '-';

    // Remove active state from tree items
    document.querySelectorAll('#script-tree .tree-file').forEach(f => f.classList.remove('active'));

    // Clear state
    scriptReviewState.currentScript = null;

    console.log('[ScriptReview] Selection cleared successfully');

    // Show notification
    if (typeof showNotification === 'function') {
        showNotification('Script selection cleared', 'info');
    }

    return false;
}
window.clearScriptSelection = clearScriptSelection;

// ============================================================================
// Self-Audit Module
// ============================================================================

/**
 * Self-Audit state management
 */
const selfAuditState = {
    lastReport: null,
    isRunning: false
};

/**
 * Initialize self-audit panel
 */
function initSelfAuditPanel() {
    console.log('[SelfAudit] Initializing self-audit panel');

    // Bind button handlers
    const fullAuditBtn = document.getElementById('btn-full-self-audit');
    const versionCheckBtn = document.getElementById('btn-version-check');
    const depScanBtn = document.getElementById('btn-dependency-scan');
    const configValidateBtn = document.getElementById('btn-config-validate');

    if (fullAuditBtn) {
        fullAuditBtn.addEventListener('click', runFullSelfAudit);
    }
    if (versionCheckBtn) {
        versionCheckBtn.addEventListener('click', checkForUpdates);
    }
    if (depScanBtn) {
        depScanBtn.addEventListener('click', scanDependencies);
    }
    if (configValidateBtn) {
        configValidateBtn.addEventListener('click', validateConfiguration);
    }

    // Load quick status on panel activation
    loadQuickStatus();
}

/**
 * Load quick status for the self-audit panel
 */
async function loadQuickStatus() {
    console.log('[SelfAudit] Loading quick status');

    try {
        const response = await adminFetch('/api/superadmin/self-audit/quick');

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();

        if (data.success && data.status) {
            const status = data.status;

            // Update quick status cards
            const versionEl = document.getElementById('self-audit-version');
            const commitEl = document.getElementById('self-audit-commit');
            const scriptsEl = document.getElementById('self-audit-scripts');
            const statusEl = document.getElementById('self-audit-status');

            if (versionEl) versionEl.textContent = status.version || '-';
            if (commitEl) commitEl.textContent = status.git_commit || '-';
            if (scriptsEl) scriptsEl.textContent = status.audit_script_count || '-';
            if (statusEl) {
                statusEl.textContent = status.status || '-';
                statusEl.style.color = status.status === 'operational' ? '#10b981' : '#f59e0b';
            }
        }
    } catch (error) {
        console.error('[SelfAudit] Failed to load quick status:', error);
    }
}

/**
 * Run full self-audit
 */
async function runFullSelfAudit() {
    console.log('[SelfAudit] Running full self-audit');

    if (selfAuditState.isRunning) {
        showNotification('Audit already in progress', 'warning');
        return;
    }

    selfAuditState.isRunning = true;
    const btn = document.getElementById('btn-full-self-audit');
    const originalText = btn ? btn.textContent : '';

    try {
        if (btn) {
            btn.disabled = true;
            btn.textContent = '⏳ Running audit...';
        }

        const response = await adminFetch('/api/superadmin/self-audit?include_deps=true');

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();

        if (data.success && data.report) {
            selfAuditState.lastReport = data.report;
            displaySelfAuditReport(data.report);
            showNotification('Self-audit completed', 'success');
        } else {
            throw new Error(data.error || 'Unknown error');
        }
    } catch (error) {
        console.error('[SelfAudit] Audit failed:', error);
        showNotification('Self-audit failed: ' + error.message, 'error');
    } finally {
        selfAuditState.isRunning = false;
        if (btn) {
            btn.disabled = false;
            btn.textContent = originalText || '🔬 Run Full Self-Audit';
        }
    }
}

/**
 * Display self-audit report
 */
function displaySelfAuditReport(report) {
    console.log('[SelfAudit] Displaying report:', report);

    // Update findings summary
    const summary = report.summary || {};
    document.getElementById('findings-critical').textContent = summary.critical || 0;
    document.getElementById('findings-errors').textContent = summary.errors || 0;
    document.getElementById('findings-warnings').textContent = summary.warnings || 0;
    document.getElementById('findings-info').textContent = summary.info || 0;

    // Update quick status
    document.getElementById('self-audit-version').textContent = report.toolkit_version || '-';

    if (report.sections) {
        // Git info
        if (report.sections.git) {
            document.getElementById('self-audit-commit').textContent = report.sections.git.commit || '-';
        }

        // Script stats
        if (report.sections.audit_scripts) {
            document.getElementById('self-audit-scripts').textContent = report.sections.audit_scripts.total_scripts || '-';
        }

        // System info
        if (report.sections.system) {
            const sys = report.sections.system;
            const sysInfoEl = document.getElementById('self-audit-system-info');
            if (sysInfoEl) {
                sysInfoEl.style.display = 'block';
                document.getElementById('sys-platform').textContent = `${sys.platform} ${sys.platform_release}`;
                document.getElementById('sys-python').textContent = sys.python_version || '-';
                document.getElementById('sys-hostname').textContent = sys.hostname || '-';
                document.getElementById('sys-deployment').textContent = sys.deployment_type || '-';
                document.getElementById('sys-memory').textContent = sys.memory_total_gb ? `${sys.memory_total_gb} GB` : '-';
                document.getElementById('sys-disk').textContent = sys.disk_total_gb ? `${sys.disk_total_gb} GB` : '-';
            }
        }
    }

    // Update status
    const statusEl = document.getElementById('self-audit-status');
    if (statusEl) {
        const statusColors = {
            'healthy': '#10b981',
            'degraded': '#f59e0b',
            'unhealthy': '#ef4444',
            'critical': '#dc2626'
        };
        const statusEmoji = {
            'healthy': '✅',
            'degraded': '⚠️',
            'unhealthy': '❌',
            'critical': '🚨'
        };
        statusEl.textContent = `${statusEmoji[report.overall_status] || ''} ${report.overall_status || 'Unknown'}`;
        statusEl.style.color = statusColors[report.overall_status] || '#6b7280';
    }

    // Display findings
    const findingsListEl = document.getElementById('self-audit-findings-list');
    if (findingsListEl) {
        if (report.findings && report.findings.length > 0) {
            const findingsHtml = report.findings.map(f => {
                const severityColors = {
                    'critical': '#dc2626',
                    'error': '#ef4444',
                    'warning': '#f59e0b',
                    'info': '#3b82f6'
                };
                const severityIcons = {
                    'critical': '🚨',
                    'error': '❌',
                    'warning': '⚠️',
                    'info': 'ℹ️'
                };
                return `
                    <div style="padding: 0.75rem; margin-bottom: 0.5rem; background: var(--card-bg); border-radius: 6px; border-left: 4px solid ${severityColors[f.severity] || '#6b7280'};">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-weight: 600;">${severityIcons[f.severity] || '•'} [${f.category}] ${f.title}</span>
                            <span style="font-size: 0.75rem; padding: 0.25rem 0.5rem; background: ${severityColors[f.severity]}20; color: ${severityColors[f.severity]}; border-radius: 4px;">${f.severity}</span>
                        </div>
                        <div style="color: var(--text-secondary); margin-top: 0.25rem;">${escapeHtml(f.message)}</div>
                        ${f.recommendation ? `<div style="color: #10b981; margin-top: 0.5rem; font-size: 0.85rem;">→ ${escapeHtml(f.recommendation)}</div>` : ''}
                    </div>
                `;
            }).join('');
            findingsListEl.innerHTML = findingsHtml;
        } else {
            findingsListEl.innerHTML = '<div style="text-align: center; color: #10b981; padding: 2rem;">✅ No issues found - system is healthy</div>';
        }
    }
}

/**
 * Check for toolkit updates
 */
async function checkForUpdates() {
    console.log('[SelfAudit] Checking for updates');

    const btn = document.getElementById('btn-version-check');
    const originalText = btn ? btn.textContent : '';

    try {
        if (btn) {
            btn.disabled = true;
            btn.textContent = '⏳ Checking...';
        }

        const response = await adminFetch('/api/superadmin/self-audit/version');

        const data = await response.json();

        if (data.success && data.version) {
            const v = data.version;
            if (v.update_available) {
                showNotification(`Update available: ${v.latest_version} (current: ${v.current_version})`, 'info');
            } else if (v.error) {
                showNotification(`Version check: ${v.error}`, 'warning');
            } else {
                showNotification(`You are running the latest version (${v.current_version})`, 'success');
            }

            // Update version display
            const versionEl = document.getElementById('self-audit-version');
            if (versionEl && v.current_version) {
                versionEl.textContent = v.update_available
                    ? `${v.current_version} → ${v.latest_version}`
                    : v.current_version;
            }
        }
    } catch (error) {
        console.error('[SelfAudit] Version check failed:', error);
        showNotification('Version check failed: ' + error.message, 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = originalText || '🔄 Check for Updates';
        }
    }
}

/**
 * Scan dependencies for vulnerabilities
 */
async function scanDependencies() {
    console.log('[SelfAudit] Scanning dependencies');

    const btn = document.getElementById('btn-dependency-scan');
    const originalText = btn ? btn.textContent : '';

    try {
        if (btn) {
            btn.disabled = true;
            btn.textContent = '⏳ Scanning...';
        }

        const response = await adminFetch('/api/superadmin/self-audit/dependencies');

        const data = await response.json();

        if (data.success && data.scan) {
            const scan = data.scan;
            if (scan.vulnerable_packages > 0) {
                showNotification(`Found ${scan.vulnerable_packages} vulnerable packages!`, 'error');
            } else if (scan.error) {
                showNotification(`Scan issue: ${scan.error}`, 'warning');
            } else {
                showNotification(`All ${scan.total_packages} packages are secure`, 'success');
            }

            // Update findings if we have them
            if (scan.vulnerabilities && scan.vulnerabilities.length > 0) {
                const findingsListEl = document.getElementById('self-audit-findings-list');
                if (findingsListEl) {
                    const vulnHtml = scan.vulnerabilities.map(v => `
                        <div style="padding: 0.75rem; margin-bottom: 0.5rem; background: var(--card-bg); border-radius: 6px; border-left: 4px solid #ef4444;">
                            <div style="font-weight: 600;">❌ ${v.package} ${v.installed_version}</div>
                            <div style="color: var(--text-secondary); margin-top: 0.25rem;">${v.vulnerability_id}</div>
                            <div style="color: #10b981; margin-top: 0.5rem; font-size: 0.85rem;">→ Upgrade to ${v.fix_versions.join(' or ') || 'latest'}</div>
                        </div>
                    `).join('');
                    findingsListEl.innerHTML = vulnHtml || '<div style="text-align: center; color: #10b981; padding: 2rem;">✅ No vulnerabilities found</div>';
                }

                document.getElementById('findings-errors').textContent = scan.vulnerable_packages;
            }
        }
    } catch (error) {
        console.error('[SelfAudit] Dependency scan failed:', error);
        showNotification('Dependency scan failed: ' + error.message, 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = originalText || '🔐 Scan Dependencies';
        }
    }
}

/**
 * Validate configuration
 */
async function validateConfiguration() {
    console.log('[SelfAudit] Validating configuration');

    const btn = document.getElementById('btn-config-validate');
    const originalText = btn ? btn.textContent : '';

    try {
        if (btn) {
            btn.disabled = true;
            btn.textContent = '⏳ Validating...';
        }

        const response = await adminFetch('/api/superadmin/self-audit/config');

        const data = await response.json();

        if (data.success && data.configuration) {
            const config = data.configuration;

            if (config.valid) {
                showNotification('Configuration is valid', 'success');
            } else {
                showNotification('Configuration has issues', 'warning');
            }

            // Display config checks
            const findingsListEl = document.getElementById('self-audit-findings-list');
            if (findingsListEl) {
                let html = '';

                if (config.checks && config.checks.length > 0) {
                    html += config.checks.map(c => `
                        <div style="padding: 0.5rem 0.75rem; margin-bottom: 0.25rem; background: #d1fae520; border-radius: 4px; color: #10b981;">
                            ✓ ${escapeHtml(c)}
                        </div>
                    `).join('');
                }

                if (config.warnings && config.warnings.length > 0) {
                    html += config.warnings.map(w => `
                        <div style="padding: 0.5rem 0.75rem; margin-bottom: 0.25rem; background: #fef3c720; border-radius: 4px; color: #f59e0b;">
                            ⚠️ ${escapeHtml(w)}
                        </div>
                    `).join('');
                }

                if (config.errors && config.errors.length > 0) {
                    html += config.errors.map(e => `
                        <div style="padding: 0.5rem 0.75rem; margin-bottom: 0.25rem; background: #fee2e220; border-radius: 4px; color: #ef4444;">
                            ❌ ${escapeHtml(e)}
                        </div>
                    `).join('');
                }

                findingsListEl.innerHTML = html || '<div style="text-align: center; color: #10b981; padding: 2rem;">✅ Configuration is valid</div>';
            }
        }
    } catch (error) {
        console.error('[SelfAudit] Config validation failed:', error);
        showNotification('Config validation failed: ' + error.message, 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = originalText || '⚙️ Validate Config';
        }
    }
}

// Watch for self-audit panel activation
const selfAuditPanel = document.getElementById('admin-panel-self-audit');
if (selfAuditPanel) {
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                if (selfAuditPanel.classList.contains('active')) {
                    console.log('[SelfAudit] Panel activated');
                    initSelfAuditPanel();
                }
            }
        });
    });
    observer.observe(selfAuditPanel, { attributes: true });
}

// Initialize self-audit when nav item is clicked
const selfAuditNavItem = document.querySelector('[data-section="self-audit"]');
if (selfAuditNavItem) {
    selfAuditNavItem.addEventListener('click', () => {
        setTimeout(() => {
            initSelfAuditPanel();
        }, 100);
    });
}

// ============================================
// SSH Keys Management
// ============================================

function initSSHKeysPanel() {
    const generateBtn = document.getElementById('ssh-generate-key');
    if (generateBtn) {
        generateBtn.addEventListener('click', generateSSHKey);
    }

    const refreshBtn = document.getElementById('ssh-refresh-keys');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', loadSSHKeys);
    }

    const saveDefaultBtn = document.getElementById('ssh-save-default');
    if (saveDefaultBtn) {
        saveDefaultBtn.addEventListener('click', saveDefaultSSHKey);
    }

    const deployBtn = document.getElementById('ssh-deploy-key');
    if (deployBtn) {
        deployBtn.addEventListener('click', deploySSHKey);
    }

    // Watch for SSH keys panel activation
    const sshKeysPanel = document.getElementById('admin-panel-ssh-keys');
    if (sshKeysPanel) {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    if (sshKeysPanel.classList.contains('active')) {
                        loadSSHKeys();
                        loadDefaultSSHKey();
                    }
                }
            });
        });
        observer.observe(sshKeysPanel, { attributes: true });
    }

    // Initialize when nav item is clicked
    const sshKeysNavItem = document.querySelector('[data-section="ssh-keys"]');
    if (sshKeysNavItem) {
        sshKeysNavItem.addEventListener('click', () => {
            setTimeout(() => {
                loadSSHKeys();
                loadDefaultSSHKey();
            }, 100);
        });
    }
}

async function loadSSHKeys() {
    const tbody = document.getElementById('ssh-keys-tbody');
    const totalEl = document.getElementById('ssh-keys-total');
    const deployedEl = document.getElementById('ssh-keys-deployed');
    const unusedEl = document.getElementById('ssh-keys-unused');
    const defaultSelect = document.getElementById('ssh-default-key');
    const deploySelect = document.getElementById('ssh-deploy-key-select');

    if (!tbody) return;

    try {
        const response = await apiFetch('/api/admin/ssh-keys/list');
        const data = await response.json();

        if (data.success && data.keys) {
            const keys = data.keys;

            // Update stats
            if (totalEl) totalEl.textContent = keys.length;
            if (deployedEl) deployedEl.textContent = keys.filter(k => k.deployed_count > 0).length;
            if (unusedEl) unusedEl.textContent = keys.filter(k => !k.deployed_count).length;

            // Populate key selects
            if (defaultSelect) {
                defaultSelect.innerHTML = '<option value="">Select default key...</option>' +
                    keys.map(k => `<option value="${escapeHtml(k.name)}">${escapeHtml(k.name)} (${k.type})</option>`).join('');
            }
            if (deploySelect) {
                deploySelect.innerHTML = '<option value="">Select key...</option>' +
                    keys.map(k => `<option value="${escapeHtml(k.name)}">${escapeHtml(k.name)}</option>`).join('');
            }

            if (keys.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="5" style="text-align: center; color: var(--text-secondary); padding: 2rem;">
                            No SSH keys found. Generate a new key to get started.
                        </td>
                    </tr>
                `;
                return;
            }

            tbody.innerHTML = keys.map(key => `
                <tr>
                    <td><strong>${escapeHtml(key.name)}</strong>${key.is_default ? ' <span style="color: #22c55e; font-size: 0.75rem;">✓ Default</span>' : ''}</td>
                    <td><code style="font-size: 0.8rem;">${escapeHtml(key.type || 'unknown')}</code></td>
                    <td><code style="font-size: 0.75rem; color: var(--text-secondary);">${escapeHtml(key.fingerprint || 'N/A')}</code></td>
                    <td style="font-size: 0.85rem; color: var(--text-secondary);">${key.created ? new Date(key.created).toLocaleDateString() : 'Unknown'}</td>
                    <td>
                        <div style="display: flex; gap: 0.5rem;">
                            <button class="btn btn-small" onclick="viewSSHPublicKey('${escapeHtml(key.name)}')" title="View Public Key">👁️</button>
                            <button class="btn btn-small btn-danger" onclick="deleteSSHKey('${escapeHtml(key.name)}')" title="Delete">🗑️</button>
                        </div>
                    </td>
                </tr>
            `).join('');
        } else {
            throw new Error(data.error || 'Failed to load SSH keys');
        }
    } catch (error) {
        console.error('[SSH Keys] Load failed:', error);
        tbody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align: center; color: #ef4444; padding: 2rem;">
                    ⚠️ Error loading SSH keys: ${escapeHtml(error.message)}
                </td>
            </tr>
        `;
    }
}

async function loadDefaultSSHKey() {
    const defaultSelect = document.getElementById('ssh-default-key');
    if (!defaultSelect) return;

    try {
        const response = await apiFetch('/api/admin/ssh-keys/default');
        const data = await response.json();

        if (data.success && data.default_key) {
            defaultSelect.value = data.default_key;
        }
    } catch (error) {
        console.error('[SSH Keys] Load default failed:', error);
    }
}

async function generateSSHKey() {
    const nameInput = document.getElementById('ssh-key-name');
    const typeSelect = document.getElementById('ssh-key-type');
    const btn = document.getElementById('ssh-generate-key');

    if (!nameInput || !typeSelect) return;

    const name = nameInput.value.trim();
    const type = typeSelect.value;

    if (!name) {
        showNotification('Please enter a key name', 'error');
        return;
    }

    // Validate key name (alphanumeric, hyphens, underscores only)
    if (!/^[a-zA-Z0-9_\-]+$/.test(name)) {
        showNotification('Key name can only contain letters, numbers, hyphens, and underscores', 'error');
        return;
    }

    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Generating...';

    try {
        const response = await apiFetch('/api/admin/ssh-keys/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, key_type: type })
        });

        const data = await response.json();

        if (data.success) {
            showNotification(`SSH key '${name}' generated successfully`, 'success');
            nameInput.value = '';
            loadSSHKeys();
        } else {
            throw new Error(data.error || 'Failed to generate key');
        }
    } catch (error) {
        console.error('[SSH Keys] Generate failed:', error);
        showNotification('Failed to generate SSH key: ' + error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
}

async function saveDefaultSSHKey() {
    const defaultSelect = document.getElementById('ssh-default-key');
    const btn = document.getElementById('ssh-save-default');

    if (!defaultSelect) return;

    const keyName = defaultSelect.value;
    if (!keyName) {
        showNotification('Please select a key', 'error');
        return;
    }

    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Saving...';

    try {
        const response = await apiFetch('/api/admin/ssh-keys/default', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key_name: keyName })
        });

        const data = await response.json();

        if (data.success) {
            showNotification(`'${keyName}' set as default SSH key`, 'success');
            loadSSHKeys();
        } else {
            throw new Error(data.error || 'Failed to save default key');
        }
    } catch (error) {
        console.error('[SSH Keys] Save default failed:', error);
        showNotification('Failed to save default key: ' + error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
}

async function viewSSHPublicKey(keyName) {
    try {
        const response = await apiFetch(`/api/admin/ssh-keys/${encodeURIComponent(keyName)}/public`);
        const data = await response.json();

        if (data.success && data.public_key) {
            // Show in a modal or alert
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 10000;';
            modal.innerHTML = `
                <div style="background: var(--card-bg, #1c2128); border: 1px solid var(--border-color, #30363d); border-radius: 12px; padding: 1.5rem; max-width: 700px; width: 90%;">
                    <h3 style="margin: 0 0 1rem 0;">🔑 Public Key: ${escapeHtml(keyName)}</h3>
                    <textarea readonly style="width: 100%; height: 150px; background: var(--bg-primary, #0d1117); color: var(--text-primary, #e6edf3); border: 1px solid var(--border-color, #30363d); border-radius: 8px; padding: 0.75rem; font-family: monospace; font-size: 0.8rem; resize: vertical;">${escapeHtml(data.public_key)}</textarea>
                    <div style="margin-top: 1rem; display: flex; gap: 0.5rem; justify-content: flex-end;">
                        <button class="btn btn-secondary" onclick="navigator.clipboard.writeText('${escapeHtml(data.public_key).replace(/'/g, "\\'")}'); this.textContent = '✓ Copied!';">📋 Copy</button>
                        <button class="btn btn-primary" onclick="this.closest('.modal-overlay').remove()">Close</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            modal.addEventListener('click', (e) => {
                if (e.target === modal) modal.remove();
            });
        } else {
            throw new Error(data.error || 'Failed to get public key');
        }
    } catch (error) {
        console.error('[SSH Keys] View public key failed:', error);
        showNotification('Failed to get public key: ' + error.message, 'error');
    }
}

async function deleteSSHKey(keyName) {
    if (!confirm(`Are you sure you want to delete the SSH key '${keyName}'?\n\nThis action cannot be undone.`)) {
        return;
    }

    try {
        const response = await apiFetch(`/api/admin/ssh-keys/${encodeURIComponent(keyName)}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showNotification(`SSH key '${keyName}' deleted`, 'success');
            loadSSHKeys();
        } else {
            throw new Error(data.error || 'Failed to delete key');
        }
    } catch (error) {
        console.error('[SSH Keys] Delete failed:', error);
        showNotification('Failed to delete SSH key: ' + error.message, 'error');
    }
}

// Toggle server selection visibility based on dropdown value
function toggleServerSelection(value) {
    const container = document.getElementById('ssh-server-selection-container');
    if (!container) return;

    if (value === 'selected') {
        container.style.display = 'block';
        loadDeployServerList();
    } else {
        container.style.display = 'none';
    }
}

// Load servers into the deployment selection list
async function loadDeployServerList() {
    const listEl = document.getElementById('ssh-server-selection-list');
    if (!listEl) return;

    listEl.innerHTML = '<div style="color: var(--text-secondary); font-size: 0.9rem;">Loading servers...</div>';

    try {
        const response = await apiFetch('/api/servers');
        const data = await response.json();

        // Filter to Linux servers only (SSH key deployment)
        const servers = (data.servers || data || []).filter(s => s.os_type !== 'windows');

        if (servers.length === 0) {
            listEl.innerHTML = '<div style="color: var(--text-secondary); font-size: 0.9rem;">No Linux servers found. Add servers in the Connect tab.</div>';
            return;
        }

        listEl.innerHTML = servers.map(server => `
            <label style="display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 0.75rem; background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 6px; cursor: pointer; transition: background 0.15s;">
                <input type="checkbox" class="ssh-deploy-server-checkbox" value="${server.id}" data-name="${escapeHtml(server.name || server.host)}" style="width: 18px; height: 18px;">
                <div style="flex: 1; min-width: 0;">
                    <div style="font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${escapeHtml(server.name || 'Unnamed')}</div>
                    <div style="font-size: 0.8rem; color: var(--text-secondary);">${escapeHtml(server.host)}:${server.port || 22} • ${escapeHtml(server.user || 'root')}</div>
                </div>
                <span style="font-size: 0.75rem; padding: 0.2rem 0.5rem; border-radius: 4px; background: ${server.status === 'online' ? '#22c55e20' : '#ef444420'}; color: ${server.status === 'online' ? '#22c55e' : '#ef4444'};">
                    ${server.status === 'online' ? '● Online' : '○ Offline'}
                </span>
            </label>
        `).join('');

        // Add change listeners to update count
        listEl.querySelectorAll('.ssh-deploy-server-checkbox').forEach(cb => {
            cb.addEventListener('change', updateDeploySelectedCount);
        });

        updateDeploySelectedCount();

    } catch (error) {
        console.error('[SSH Keys] Failed to load servers:', error);
        listEl.innerHTML = '<div style="color: #ef4444; font-size: 0.9rem;">Failed to load servers: ' + escapeHtml(error.message) + '</div>';
    }
}

// Update selected server count display
function updateDeploySelectedCount() {
    const countEl = document.getElementById('ssh-deploy-selected-count');
    const checkboxes = document.querySelectorAll('.ssh-deploy-server-checkbox:checked');
    if (countEl) {
        countEl.textContent = checkboxes.length;
    }
}

// Select or deselect all servers in deploy list
function selectAllDeployServers(select) {
    document.querySelectorAll('.ssh-deploy-server-checkbox').forEach(cb => {
        cb.checked = select;
    });
    updateDeploySelectedCount();
}

// Get selected server IDs for deployment
function getSelectedDeployServerIds() {
    const checkboxes = document.querySelectorAll('.ssh-deploy-server-checkbox:checked');
    return Array.from(checkboxes).map(cb => parseInt(cb.value, 10));
}

async function deploySSHKey() {
    const keySelect = document.getElementById('ssh-deploy-key-select');
    const serversSelect = document.getElementById('ssh-deploy-servers');
    const btn = document.getElementById('ssh-deploy-key');

    if (!keySelect || !serversSelect) return;

    const keyName = keySelect.value;
    const target = serversSelect.value;

    if (!keyName) {
        showNotification('Please select a key to deploy', 'error');
        return;
    }

    // Determine which servers to deploy to
    let serverIds;
    if (target === 'all') {
        serverIds = 'all';
    } else {
        serverIds = getSelectedDeployServerIds();
        if (serverIds.length === 0) {
            showNotification('Please select at least one server', 'error');
            return;
        }
    }

    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Deploying...';

    try {
        const response = await apiFetch('/api/admin/ssh-keys/deploy', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                key_name: keyName,
                server_ids: serverIds,
                update_server_auth: true,
                backup_authorized_keys: true
            })
        });

        const data = await response.json();

        if (data.success || data.partial_success) {
            const results = data.results || {};
            const deployed = results.deployed || 0;
            const failed = results.failed || 0;
            const updated = results.updated || 0;

            let msg = `Key deployed to ${deployed} server(s)`;
            if (updated > 0) msg += `, ${updated} updated to key auth`;
            if (failed > 0) msg += ` (${failed} failed)`;

            showNotification(msg, failed > 0 ? 'warning' : 'success');

            // Show detailed results if any failures
            if (failed > 0 && results.details) {
                const failedServers = results.details.filter(d => d.status === 'failed');
                console.warn('[SSH Keys] Deploy failures:', failedServers);
            }

            loadSSHKeys();
        } else {
            throw new Error(data.error || 'Failed to deploy key');
        }
    } catch (error) {
        console.error('[SSH Keys] Deploy failed:', error);
        showNotification('Failed to deploy SSH key: ' + error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
}

// Make SSH key functions globally available
window.viewSSHPublicKey = viewSSHPublicKey;
window.deleteSSHKey = deleteSSHKey;
window.toggleServerSelection = toggleServerSelection;
window.selectAllDeployServers = selectAllDeployServers;
window.loadDeployServerList = loadDeployServerList;
