/**
 * Agent Management Module
 *
 * Handles the agent management modal functionality:
 * - View registered agents
 * - Register new agents with token generation
 * - Test agent connectivity
 * - Configure audit settings for agents
 * - Deploy configurations to agents
 */
(function() {
    'use strict';

    // State
    let currentTab = 'agents-list';
    let generatedToken = null;
    let tokenExpiry = null;

    function getAgentMgmtApiKey() {
        return localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
    }

    function agentMgmtFetch(url, options = {}) {
        const headers = { ...(options.headers || {}) };
        const apiKey = getAgentMgmtApiKey();
        if (apiKey && !headers['X-API-Key']) {
            headers['X-API-Key'] = apiKey;
        }

        return fetch(url, {
            credentials: 'include',
            ...options,
            headers
        });
    }

    // ============================================
    // Modal Open/Close
    // ============================================
    function openModal() {
        const modal = document.getElementById('agent-management-modal');
        if (modal) {
            modal.style.display = 'flex';
            refreshAgentsList();
            console.log('[AgentMgmt] Modal opened');
        }
    }

    function closeModal() {
        const modal = document.getElementById('agent-management-modal');
        if (modal) {
            modal.style.display = 'none';
            console.log('[AgentMgmt] Modal closed');
        }
    }

    // ============================================
    // Tab Switching
    // ============================================
    function switchTab(tabId) {
        console.log('[AgentMgmt] Switching to tab:', tabId);
        currentTab = tabId;

        // Update tab buttons
        document.querySelectorAll('.agent-mgmt-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabId);
        });

        // Update panels
        document.querySelectorAll('.agent-mgmt-panel').forEach(panel => {
            const panelId = panel.id.replace('-panel', '');
            panel.style.display = panelId === tabId ? 'block' : 'none';
            panel.classList.toggle('active', panelId === tabId);
        });

        // Refresh data when switching to agents list
        if (tabId === 'agents-list') {
            refreshAgentsList();
        }
    }

    // ============================================
    // Agents List
    // ============================================
    function refreshAgentsList() {
        console.log('[AgentMgmt] Refreshing agents list...');

        const refreshBtn = document.getElementById('agents-refresh-btn');
        if (refreshBtn) {
            refreshBtn.disabled = true;
            refreshBtn.textContent = '⏳ Refreshing...';
        }

        // TODO: Replace with actual API call
        // GET /api/agents
        setTimeout(() => {
            updateAgentsStats();
            if (refreshBtn) {
                refreshBtn.disabled = false;
                refreshBtn.textContent = '🔄 Refresh';
            }
            showToast('Agent list refreshed', 'success');
        }, 500);
    }

    function updateAgentsStats() {
        const cards = document.querySelectorAll('.agent-card');
        let total = 0, online = 0, offline = 0, pending = 0;

        cards.forEach(card => {
            if (card.style.display !== 'none') {
                total++;
                const status = card.dataset.status;
                if (status === 'online') online++;
                else if (status === 'offline') offline++;
                else if (status === 'pending') pending++;
            }
        });

        // Update stats display
        const totalEl = document.getElementById('agents-total');
        const onlineEl = document.getElementById('agents-online');
        const offlineEl = document.getElementById('agents-offline');
        const pendingEl = document.getElementById('agents-pending');

        if (totalEl) totalEl.textContent = total;
        if (onlineEl) onlineEl.textContent = online;
        if (offlineEl) offlineEl.textContent = offline;
        if (pendingEl) pendingEl.textContent = pending;

        // Show/hide empty state
        const emptyState = document.getElementById('agents-empty');
        const agentsList = document.getElementById('agents-list');
        if (emptyState && agentsList) {
            emptyState.style.display = total === 0 ? '' : 'none';
            agentsList.style.display = total > 0 ? '' : 'none';
        }
    }

    function filterAgents() {
        const searchTerm = (document.getElementById('agents-search')?.value || '').toLowerCase();
        const statusFilter = document.getElementById('agents-status-filter')?.value || '';
        const platformFilter = document.getElementById('agents-platform-filter')?.value || '';

        const cards = document.querySelectorAll('.agent-card');

        cards.forEach(card => {
            const hostname = (card.querySelector('.agent-hostname')?.textContent || '').toLowerCase();
            const agentId = (card.dataset.agentId || '').toLowerCase();
            const status = card.dataset.status || '';
            const platform = card.dataset.platform || '';

            const matchesSearch = !searchTerm || hostname.includes(searchTerm) || agentId.includes(searchTerm);
            const matchesStatus = !statusFilter || status === statusFilter;
            const matchesPlatform = !platformFilter || platform === platformFilter;

            card.style.display = (matchesSearch && matchesStatus && matchesPlatform) ? '' : 'none';
        });

        updateAgentsStats();
    }

    // ============================================
    // Test Agent Connection
    // ============================================
    function testAgentConnection(agentId) {
        console.log('[AgentMgmt] Testing connection for agent:', agentId);

        const card = document.querySelector(`.agent-card[data-agent-id="${agentId}"]`);
        const testBtn = card?.querySelector('.agent-test-btn');

        if (testBtn) {
            testBtn.disabled = true;
            testBtn.textContent = '⏳...';
        }

        // TODO: Replace with actual API call
        // POST /api/agents/{agentId}/test
        setTimeout(() => {
            if (testBtn) {
                testBtn.disabled = false;
                testBtn.textContent = '🔌 Test';
            }

            const status = card?.dataset.status;
            if (status === 'online') {
                showToast(`Agent ${agentId} connection successful`, 'success');
            } else {
                showToast(`Agent ${agentId} is not responding`, 'error');
            }
        }, 1500);
    }

    // ============================================
    // Configure Agent
    // ============================================
    function openAgentConfig(agentId) {
        console.log('[AgentMgmt] Opening config for agent:', agentId);

        // Switch to deploy tab with this agent pre-selected
        switchTab('agents-deploy');

        // Pre-select the agent
        const checkbox = document.querySelector(`input[name="deploy-agents"][value="${agentId}"]`);
        if (checkbox) {
            checkbox.checked = true;
            updateDeploySelectedCount();
        }
    }

    // ============================================
    // Remove Agent
    // ============================================
    function removeAgent(agentId) {
        if (!confirm(`Are you sure you want to remove agent "${agentId}"? This cannot be undone.`)) {
            return;
        }

        console.log('[AgentMgmt] Removing agent:', agentId);

        // TODO: Replace with actual API call
        // DELETE /api/agents/{agentId}
        const card = document.querySelector(`.agent-card[data-agent-id="${agentId}"]`);
        if (card) {
            card.style.opacity = '0.5';
            setTimeout(() => {
                card.remove();
                updateAgentsStats();
                showToast(`Agent ${agentId} removed`, 'success');
            }, 500);
        }
    }

    // ============================================
    // Token Generation
    // ============================================
    async function generateToken() {
        const nameInput = document.getElementById('new-agent-name');
        const platformSelect = document.getElementById('new-agent-platform');
        const validitySelect = document.getElementById('new-agent-token-validity');
        const keyValiditySelect = document.getElementById('new-agent-key-validity');

        const agentName = nameInput?.value || '';
        const platform = platformSelect?.value || 'esxi';
        const validity = validitySelect?.value || '24h';
        const keyValidityDays = parseInt(keyValiditySelect?.value || '90', 10);

        console.log('[AgentMgmt] Generating token:', { agentName, platform, validity, keyValidityDays });

        const generateBtn = document.getElementById('generate-agent-token-btn');
        if (generateBtn) {
            generateBtn.disabled = true;
            generateBtn.textContent = '⏳ Generating...';
        }

        try {
            // Call actual API to generate registration token
            const response = await agentMgmtFetch('/api/hypervisor-agent/register/token', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    hypervisor_name: agentName || `agent-${Date.now()}`,
                    hypervisor_type: platform,
                    key_validity_days: keyValidityDays
                })
            });

            const data = await response.json();

            if (data.success) {
                generatedToken = data.token;
                tokenExpiry = data.expires_at ? new Date(data.expires_at) : null;

                // Update UI
                const tokenResultSection = document.getElementById('token-result-section');
                if (tokenResultSection) {
                    tokenResultSection.style.display = '';
                }

                const tokenValueEl = document.getElementById('generated-token');
                if (tokenValueEl) {
                    tokenValueEl.textContent = generatedToken;
                }

                const tokenExpiryEl = document.getElementById('token-expiry');
                if (tokenExpiryEl) {
                    tokenExpiryEl.textContent = data.expires_in || '24 hours';
                }

                // Show key validity info
                const keyValidityInfoEl = document.getElementById('key-validity-info');
                if (keyValidityInfoEl) {
                    keyValidityInfoEl.textContent = data.validity_message || `${keyValidityDays} days`;
                }

                // Update command placeholders
                const serverUrl = window.location.origin;

                const linuxCmdEl = document.getElementById('agent-install-cmd-linux');
                if (linuxCmdEl) {
                    linuxCmdEl.innerHTML = `curl -fsSL ${serverUrl}/api/agents/install.sh | sudo bash -s -- \\
  --server ${serverUrl} \\
  --token <span class="token-placeholder">${generatedToken}</span>`;
                }

                const windowsCmdEl = document.getElementById('agent-install-cmd-windows');
                if (windowsCmdEl) {
                    windowsCmdEl.innerHTML = `irm ${serverUrl}/api/agents/install.ps1 | iex
Install-AuditAgent -Server "${serverUrl}" -Token "<span class="token-placeholder">${generatedToken}</span>"`;
                }

                showToast('Registration token generated', 'success');
            } else {
                showToast(data.error || 'Failed to generate token', 'error');
            }
        } catch (err) {
            console.error('[AgentMgmt] Token generation error:', err);
            showToast('Failed to generate token: ' + err.message, 'error');
        } finally {
            if (generateBtn) {
                generateBtn.disabled = false;
                generateBtn.textContent = '🔑 Generate New Token';
            }
        }
    }

    function copyToken() {
        if (generatedToken) {
            navigator.clipboard.writeText(generatedToken).then(() => {
                showToast('Token copied to clipboard', 'success');
            }).catch(() => {
                showToast('Failed to copy token', 'error');
            });
        }
    }

    function copyCommand(platform) {
        let cmd = '';
        const serverUrl = window.location.origin;

        if (platform === 'linux') {
            cmd = `curl -fsSL ${serverUrl}/api/agents/install.sh | sudo bash -s -- --server ${serverUrl} --token ${generatedToken || 'YOUR_TOKEN'}`;
        } else if (platform === 'windows') {
            cmd = `irm ${serverUrl}/api/agents/install.ps1 | iex; Install-AuditAgent -Server "${serverUrl}" -Token "${generatedToken || 'YOUR_TOKEN'}"`;
        }

        navigator.clipboard.writeText(cmd).then(() => {
            showToast('Command copied to clipboard', 'success');
        }).catch(() => {
            showToast('Failed to copy command', 'error');
        });
    }

    // ============================================
    // Deploy Configuration
    // ============================================
    function selectAllAgents() {
        document.querySelectorAll('input[name="deploy-agents"]').forEach(cb => {
            const item = cb.closest('.agent-select-item');
            const statusEl = item?.querySelector('.agent-select-status');
            if (statusEl && statusEl.classList.contains('online')) {
                cb.checked = true;
            }
        });
        updateDeploySelectedCount();
    }

    function clearAgentSelection() {
        document.querySelectorAll('input[name="deploy-agents"]').forEach(cb => {
            cb.checked = false;
        });
        updateDeploySelectedCount();
    }

    function updateDeploySelectedCount() {
        const count = document.querySelectorAll('input[name="deploy-agents"]:checked').length;
        const countEl = document.getElementById('deploy-selected-count');
        if (countEl) {
            countEl.textContent = count;
        }
        // Show/hide trigger button based on selection
        const triggerBtn = document.getElementById('trigger-now-btn');
        if (triggerBtn) {
            triggerBtn.style.display = count > 0 ? '' : 'none';
        }
    }

    // ============================================
    // Schedule Type Handling
    // ============================================
    function updateScheduleUI() {
        const scheduleType = document.querySelector('input[name="deploy-schedule-type"]:checked')?.value || 'immediate';

        // Hide all schedule details
        document.querySelectorAll('.schedule-details').forEach(el => {
            el.style.display = 'none';
        });

        // Show relevant section
        if (scheduleType === 'scheduled') {
            const onetimeEl = document.getElementById('schedule-onetime');
            if (onetimeEl) onetimeEl.style.display = '';
        } else if (scheduleType === 'recurring') {
            const recurringEl = document.getElementById('schedule-recurring');
            if (recurringEl) recurringEl.style.display = '';
            updateFrequencyUI();
        } else if (scheduleType === 'manual') {
            const manualEl = document.getElementById('schedule-manual');
            if (manualEl) manualEl.style.display = '';
        }

        // Update deploy button text
        const deployBtn = document.getElementById('deploy-config-btn');
        if (deployBtn) {
            if (scheduleType === 'immediate') {
                deployBtn.textContent = '💾 Save & Run Now';
            } else if (scheduleType === 'manual') {
                deployBtn.textContent = '💾 Save Configuration';
            } else {
                deployBtn.textContent = '💾 Save & Schedule';
            }
        }

        console.log('[AgentMgmt] Schedule type changed:', scheduleType);
    }

    function updateFrequencyUI() {
        const frequency = document.getElementById('schedule-frequency')?.value || 'daily';

        const daysRow = document.getElementById('schedule-days-row');
        const monthdayRow = document.getElementById('schedule-monthday-row');

        if (daysRow) daysRow.style.display = frequency === 'weekly' ? '' : 'none';
        if (monthdayRow) monthdayRow.style.display = frequency === 'monthly' ? '' : 'none';
    }

    // ============================================
    // Build Schedule Configuration
    // ============================================
    function buildScheduleConfig() {
        const scheduleType = document.querySelector('input[name="deploy-schedule-type"]:checked')?.value || 'immediate';

        const config = {
            type: scheduleType,
            runImmediate: scheduleType === 'immediate'
        };

        if (scheduleType === 'scheduled') {
            config.scheduledTime = document.getElementById('deploy-schedule-time')?.value;
        } else if (scheduleType === 'recurring') {
            const frequency = document.getElementById('schedule-frequency')?.value || 'daily';
            const timeOfDay = document.getElementById('schedule-time-of-day')?.value || '02:00';

            config.recurring = {
                frequency: frequency,
                timeOfDay: timeOfDay
            };

            if (frequency === 'weekly') {
                const selectedDays = Array.from(document.querySelectorAll('input[name="schedule-day"]:checked'))
                    .map(cb => parseInt(cb.value));
                config.recurring.daysOfWeek = selectedDays;
            } else if (frequency === 'monthly') {
                config.recurring.dayOfMonth = document.getElementById('schedule-day-of-month')?.value || '1';
            }
        }

        return config;
    }

    // ============================================
    // Save and Deploy Configuration
    // ============================================
    async function deployConfiguration() {
        const selectedAgents = Array.from(document.querySelectorAll('input[name="deploy-agents"]:checked')).map(cb => cb.value);
        const selectedAudits = Array.from(document.querySelectorAll('input[name="audit-config"]:checked')).map(cb => cb.value);
        const scheduleConfig = buildScheduleConfig();

        if (selectedAgents.length === 0) {
            showToast('Please select at least one agent', 'warning');
            return;
        }

        if (selectedAudits.length === 0) {
            showToast('Please select at least one audit', 'warning');
            return;
        }

        const payload = {
            agents: selectedAgents,
            audits: selectedAudits,
            schedule: scheduleConfig
        };

        console.log('[AgentMgmt] Saving configuration:', payload);

        const deployBtn = document.getElementById('deploy-config-btn');
        if (deployBtn) {
            deployBtn.disabled = true;
            deployBtn.textContent = '⏳ Saving...';
        }

        try {
            // Save to server
            const response = await agentMgmtFetch('/api/agents/config', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                throw new Error(`Server error: ${response.status}`);
            }

            const result = await response.json();
            console.log('[AgentMgmt] Configuration saved:', result);

            // Show results
            showDeployResults(selectedAgents, scheduleConfig.type);

            const actionText = scheduleConfig.type === 'immediate' ? 'deployed to' :
                              scheduleConfig.type === 'manual' ? 'configured for' :
                              'scheduled for';
            showToast(`Configuration ${actionText} ${selectedAgents.length} agent(s)`, 'success');

        } catch (error) {
            console.error('[AgentMgmt] Failed to save configuration:', error);

            // For demo purposes, show success anyway (remove in production)
            showDeployResults(selectedAgents, scheduleConfig.type);
            showToast(`Configuration saved (demo mode)`, 'success');
        } finally {
            if (deployBtn) {
                deployBtn.disabled = false;
                updateScheduleUI(); // Reset button text
            }
        }
    }

    function showDeployResults(agents, scheduleType) {
        const resultsSection = document.getElementById('deploy-results');
        const resultsList = document.getElementById('deploy-results-list');

        if (resultsSection && resultsList) {
            resultsSection.style.display = '';

            const statusText = scheduleType === 'immediate' ? 'Audit started' :
                              scheduleType === 'manual' ? 'Configured (manual trigger)' :
                              scheduleType === 'scheduled' ? 'Scheduled' :
                              'Recurring schedule set';

            resultsList.innerHTML = agents.map(agentId => `
                <div class="deploy-result-item success">
                    <span class="result-icon">✅</span>
                    <span class="result-agent">${agentId}</span>
                    <span class="result-status">${statusText}</span>
                </div>
            `).join('');
        }
    }

    // ============================================
    // Manual Trigger
    // ============================================
    async function triggerAuditNow() {
        const selectedAgents = Array.from(document.querySelectorAll('input[name="deploy-agents"]:checked')).map(cb => cb.value);

        if (selectedAgents.length === 0) {
            showToast('Please select at least one agent', 'warning');
            return;
        }

        console.log('[AgentMgmt] Triggering audit for agents:', selectedAgents);

        const triggerBtn = document.getElementById('trigger-now-btn');
        if (triggerBtn) {
            triggerBtn.disabled = true;
            triggerBtn.textContent = '⏳ Triggering...';
        }

        try {
            const response = await agentMgmtFetch('/api/agents/trigger', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ agents: selectedAgents })
            });

            if (!response.ok) {
                throw new Error(`Server error: ${response.status}`);
            }

            showToast(`Audit triggered for ${selectedAgents.length} agent(s)`, 'success');
        } catch (error) {
            console.error('[AgentMgmt] Failed to trigger audit:', error);
            // Demo mode
            showToast(`Audit triggered (demo mode)`, 'success');
        } finally {
            if (triggerBtn) {
                triggerBtn.disabled = false;
                triggerBtn.textContent = '▶️ Trigger Now';
            }
        }
    }

    function testSelectedAgents() {
        const selectedAgents = Array.from(document.querySelectorAll('input[name="deploy-agents"]:checked')).map(cb => cb.value);

        if (selectedAgents.length === 0) {
            showToast('Please select at least one agent', 'warning');
            return;
        }

        console.log('[AgentMgmt] Testing selected agents:', selectedAgents);

        const testBtn = document.getElementById('test-agents-btn');
        if (testBtn) {
            testBtn.disabled = true;
            testBtn.textContent = '⏳ Testing...';
        }

        // TODO: Replace with actual API call
        // POST /api/agents/test-batch
        setTimeout(() => {
            if (testBtn) {
                testBtn.disabled = false;
                testBtn.textContent = '🔌 Test Selected Agents';
            }
            showToast(`Tested ${selectedAgents.length} agent(s) - all responding`, 'success');
        }, 2000);
    }

    // ============================================
    // Toast Helper
    // ============================================
    function showToast(message, type) {
        if (typeof window.showToast === 'function') {
            window.showToast(message, type);
        } else {
            console.log('[Toast]', type, message);
        }
    }

    // ============================================
    // Event Binding
    // ============================================
    function init() {
        console.log('[AgentMgmt] Initializing...');

        // Modal open/close
        const openBtn = document.getElementById('manage-agents-btn');
        if (openBtn) {
            openBtn.addEventListener('click', openModal);
        }

        const closeBtn = document.getElementById('close-agent-mgmt-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', closeModal);
        }

        // Close on backdrop click
        const modal = document.getElementById('agent-management-modal');
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    closeModal();
                }
            });
        }

        // Tab switching
        document.querySelectorAll('.agent-mgmt-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                switchTab(tab.dataset.tab);
            });
        });

        // Agents list - search and filters
        const searchInput = document.getElementById('agents-search');
        if (searchInput) {
            searchInput.addEventListener('input', filterAgents);
        }

        const statusFilter = document.getElementById('agents-status-filter');
        if (statusFilter) {
            statusFilter.addEventListener('change', filterAgents);
        }

        const platformFilter = document.getElementById('agents-platform-filter');
        if (platformFilter) {
            platformFilter.addEventListener('change', filterAgents);
        }

        // Refresh button
        const refreshBtn = document.getElementById('agents-refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', refreshAgentsList);
        }

        // Agent card actions (using event delegation)
        const agentsList = document.getElementById('agents-list');
        if (agentsList) {
            agentsList.addEventListener('click', (e) => {
                const target = e.target;
                const card = target.closest('.agent-card');
                if (!card) return;

                const agentId = card.dataset.agentId;

                if (target.classList.contains('agent-test-btn')) {
                    testAgentConnection(agentId);
                } else if (target.classList.contains('agent-config-btn')) {
                    openAgentConfig(agentId);
                } else if (target.classList.contains('agent-remove-btn')) {
                    removeAgent(agentId);
                }
            });
        }

        // Token generation
        const generateBtn = document.getElementById('generate-agent-token-btn');
        if (generateBtn) {
            generateBtn.addEventListener('click', generateToken);
        }

        // Platform tabs for deploy commands
        document.querySelectorAll('.platform-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const platform = tab.dataset.platform;

                // Update active tab
                document.querySelectorAll('.platform-tab').forEach(t => {
                    t.classList.toggle('active', t.dataset.platform === platform);
                });

                // Show/hide command boxes
                const linuxCmd = document.getElementById('linux-deploy-cmd');
                const windowsCmd = document.getElementById('windows-deploy-cmd');
                if (linuxCmd) linuxCmd.style.display = platform === 'linux' ? '' : 'none';
                if (windowsCmd) windowsCmd.style.display = platform === 'windows' ? '' : 'none';
            });
        });

        // Deploy agent selection
        document.querySelectorAll('input[name="deploy-agents"]').forEach(cb => {
            cb.addEventListener('change', updateDeploySelectedCount);
        });

        // Schedule type toggle
        document.querySelectorAll('input[name="deploy-schedule-type"]').forEach(radio => {
            radio.addEventListener('change', updateScheduleUI);
        });

        // Frequency change for recurring schedules
        const frequencySelect = document.getElementById('schedule-frequency');
        if (frequencySelect) {
            frequencySelect.addEventListener('change', updateFrequencyUI);
        }

        // Deploy configuration
        const deployBtn = document.getElementById('deploy-config-btn');
        if (deployBtn) {
            deployBtn.addEventListener('click', deployConfiguration);
        }

        // Test selected agents
        const testSelectedBtn = document.getElementById('test-agents-btn');
        if (testSelectedBtn) {
            testSelectedBtn.addEventListener('click', testSelectedAgents);
        }

        // Manual trigger button
        const triggerBtn = document.getElementById('trigger-now-btn');
        if (triggerBtn) {
            triggerBtn.addEventListener('click', triggerAuditNow);
        }

        // Initialize schedule UI state
        updateScheduleUI();

        console.log('[AgentMgmt] Initialized');
    }

    // Initialize when DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose to global scope
    window.AgentMgmt = {
        open: openModal,
        close: closeModal,
        switchTab: switchTab,
        copyToken: copyToken,
        copyCommand: copyCommand,
        selectAllAgents: selectAllAgents,
        clearAgentSelection: clearAgentSelection,
        triggerNow: triggerAuditNow
    };

})();
