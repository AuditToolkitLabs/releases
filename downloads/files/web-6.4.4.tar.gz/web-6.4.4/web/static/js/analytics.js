/**
 * Analytics page JavaScript
 * Handles analytics data loading and visualization
 */

/**
 * XSS prevention helper
 * @param {*} unsafe - Unsafe input
 * @returns {string} - HTML-escaped string
 */
function escapeHtml(unsafe) {
    if (unsafe == null) return '';
    var div = document.createElement('div');
    div.textContent = String(unsafe);
    return div.innerHTML;
}

// Global state
var trendsData = null;
var complianceChart = null;

/**
 * Load analytics data
 */
async function loadAnalytics() {
    var days = document.getElementById('daysSelect').value;
    var dashboard = document.getElementById('dashboard');
    dashboard.innerHTML = '<div class="loading">Loading analytics data...</div>';
    clearError();
    
    try {
        var response = await fetch('/api/analytics/trends?days=' + days, { credentials: 'include' });
        var data = await response.json();
        
        if (!data.success) {
            throw new Error(data.error || 'Failed to load analytics');
        }
        
        trendsData = data.trends;
        renderDashboard();
        
    } catch (error) {
        showError('Error loading analytics: ' + error.message);
        dashboard.innerHTML = '';
    }
}

/**
 * Render the analytics dashboard
 */
function renderDashboard() {
    var dashboard = document.getElementById('dashboard');
    
    var html = '<div class="dashboard-grid">' +
        '<div class="card">' +
            '<h2>Overall Compliance</h2>' +
            '<div class="metric-value">' + trendsData.overall_compliance.avg_score.toFixed(1) + '%</div>' +
            '<div class="metric-label">' + trendsData.overall_compliance.total_servers + ' servers monitored</div>' +
            '<div class="metric-label">' + trendsData.overall_compliance.total_checks.toLocaleString() + ' checks performed</div>' +
        '</div>' +
        '<div class="card">' +
            '<h2>Top Performer</h2>' +
            renderTopPerformer() +
        '</div>' +
        '<div class="card">' +
            '<h2>Most Improved</h2>' +
            renderMostImproved() +
        '</div>' +
        '<div class="card">' +
            '<h2>Needs Attention</h2>' +
            renderNeedsAttention() +
        '</div>' +
    '</div>' +
    '<div class="dashboard-grid">' +
        '<div class="card">' +
            '<h2>Top 5 Performers</h2>' +
            '<ul class="server-list">' + renderServerList(trendsData.top_performers) + '</ul>' +
        '</div>' +
        '<div class="card">' +
            '<h2>Bottom 5 Performers</h2>' +
            '<ul class="server-list">' + renderServerList(trendsData.bottom_performers) + '</ul>' +
        '</div>' +
        '<div class="card">' +
            '<h2>Improving Servers</h2>' +
            '<ul class="server-list">' + renderServerList(trendsData.improving_servers, true) + '</ul>' +
        '</div>' +
        '<div class="card">' +
            '<h2>Declining Servers</h2>' +
            '<ul class="server-list">' + renderServerList(trendsData.declining_servers, true) + '</ul>' +
        '</div>' +
    '</div>';
    
    dashboard.innerHTML = html;
}

/**
 * Render top performer card content
 */
function renderTopPerformer() {
    var top = trendsData.top_performers[0];
    if (!top) return '<p>No data available</p>';
    
    return '<div class="metric-value">' + parseFloat(top.current_score).toFixed(1) + '%</div>' +
        '<div class="metric-label">' + escapeHtml(top.server_name) + '</div>' +
        '<div class="metric-label">' + (parseInt(top.total_checks, 10) || 0) + ' checks</div>';
}

/**
 * Render most improved card content
 */
function renderMostImproved() {
    var improved = trendsData.improving_servers[0];
    if (!improved) return '<p>No improvements detected</p>';
    
    return '<div class="metric-value">+' + parseFloat(improved.trend).toFixed(1) + '%</div>' +
        '<div class="metric-label">' + escapeHtml(improved.server_name) + '</div>' +
        '<span class="trend-badge trend-improving">Improving</span>';
}

/**
 * Render needs attention card content
 */
function renderNeedsAttention() {
    var bottom = trendsData.bottom_performers[0];
    if (!bottom) return '<p>All servers performing well</p>';
    
    return '<div class="metric-value score-danger">' + parseFloat(bottom.current_score).toFixed(1) + '%</div>' +
        '<div class="metric-label">' + escapeHtml(bottom.server_name) + '</div>' +
        '<div class="metric-label">' + (parseInt(bottom.failed_checks, 10) || 0) + ' failed checks</div>';
}

/**
 * Render server list
 * @param {Array} servers - List of server objects
 * @param {boolean} showTrend - Whether to show trend badges
 */
function renderServerList(servers, showTrend) {
    if (!servers || servers.length === 0) {
        return '<li class="server-item">No data available</li>';
    }
    
    return servers.map(function(server) {
        var scoreClass = server.current_score >= 90 ? 'score-good' :
                       server.current_score >= 75 ? 'score-warning' : 'score-danger';
        
        var trendBadge = '';
        if (showTrend && server.trend) {
            var trendClass = server.trend > 0 ? 'trend-improving' :
                           server.trend < 0 ? 'trend-declining' : 'trend-stable';
            var trendSymbol = server.trend > 0 ? '+' : '';
            trendBadge = '<span class="trend-badge ' + trendClass + '">' + trendSymbol + server.trend.toFixed(1) + '%</span>';
        }
        
        return '<li class="server-item">' +
            '<div>' +
                '<span class="server-name">' + escapeHtml(server.server_name) + '</span>' +
                trendBadge +
            '</div>' +
            '<span class="server-score ' + scoreClass + '">' + parseFloat(server.current_score).toFixed(1) + '%</span>' +
        '</li>';
    }).join('');
}

/**
 * Show error message
 * @param {string} message - Error message to display
 */
function showError(message) {
    var container = document.getElementById('errorContainer');
    container.innerHTML = '<div class="error">' + escapeHtml(message) + '</div>';
}

/**
 * Clear error message
 */
function clearError() {
    document.getElementById('errorContainer').innerHTML = '';
}

/**
 * Handle aggregation button click
 */
async function runAggregation() {
    var btn = document.getElementById('aggregateBtn');
    btn.disabled = true;
    btn.textContent = 'Running...';
    
    try {
        var response = await fetch('/api/analytics/aggregate', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        var data = await response.json();
        
        if (data.success) {
            alert('Aggregation complete:\n' + data.summaries_created + ' summaries\n' + data.compliance_records_created + ' compliance records');
            loadAnalytics();  // Reload data
        } else {
            showError('Aggregation failed: ' + data.error);
        }
    } catch (error) {
        showError('Error triggering aggregation: ' + error.message);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Run Aggregation';
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Load analytics on page load
    loadAnalytics();
    
    // Load button handler
    document.getElementById('loadBtn').addEventListener('click', function() {
        loadAnalytics();
    });
    
    // Aggregate button handler
    document.getElementById('aggregateBtn').addEventListener('click', runAggregation);
});
