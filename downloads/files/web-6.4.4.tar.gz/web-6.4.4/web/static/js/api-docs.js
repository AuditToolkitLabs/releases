/**
 * API Documentation page JavaScript
 * Initializes Swagger UI with custom configuration
 */

document.addEventListener('DOMContentLoaded', function() {
    // Wait for Swagger UI to be ready
    initSwaggerUI();
});

/**
 * Initialize Swagger UI
 */
function initSwaggerUI() {
    // Determine base URL dynamically
    var baseUrl = window.location.origin;
    
    var ui = SwaggerUIBundle({
        url: baseUrl + "/static/openapi.yaml",
        dom_id: '#swagger-ui',
        deepLinking: true,
        presets: [
            SwaggerUIBundle.presets.apis,
            SwaggerUIStandalonePreset
        ],
        plugins: [
            SwaggerUIBundle.plugins.DownloadUrl
        ],
        layout: "StandaloneLayout",
        defaultModelsExpandDepth: 1,
        defaultModelExpandDepth: 1,
        docExpansion: "list",
        filter: true,
        syntaxHighlight: {
            activate: true,
            theme: "agate"
        },
        tryItOutEnabled: true,
        requestInterceptor: function(request) {
            // Add API key from localStorage if set via Authorize button
            var apiKey = localStorage.getItem('swagger_api_key');
            if (apiKey && !request.headers['X-API-Key']) {
                request.headers['X-API-Key'] = apiKey;
            }
            return request;
        },
        onComplete: function() {
            // Restore API key from localStorage
            var apiKey = localStorage.getItem('swagger_api_key');
            if (apiKey) {
                // Auto-fill authorization
                ui.preauthorizeApiKey('ApiKeyAuth', apiKey);
            }
        },
        persistAuthorization: true
    });
    
    window.ui = ui;
    
    // Save API key to localStorage when set
    var originalAuthorize = ui.authActions.authorize;
    ui.authActions.authorize = function(payload) {
        if (payload && payload.ApiKeyAuth) {
            localStorage.setItem('swagger_api_key', payload.ApiKeyAuth.value);
        }
        return originalAuthorize.call(this, payload);
    };
}
