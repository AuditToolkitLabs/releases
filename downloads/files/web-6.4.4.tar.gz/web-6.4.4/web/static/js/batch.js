/**
 * Batch Execution Page JavaScript
 * Handles multi-server/multi-audit batch execution UI
 */

// XSS prevention helper
function escapeHtml(unsafe) {
    if (unsafe == null) return '';
    const div = document.createElement('div');
    div.textContent = String(unsafe);
    return div.innerHTML;
}

// Global state
let servers = [];
let audits = [];
let executions = [];
let selectedServers = new Set();
let selectedAudits = new Set();

// API configuration
const API_KEY = localStorage.getItem('api_key') || prompt('Enter API Key:');
if (API_KEY) localStorage.setItem('api_key', API_KEY);

const API_BASE = window.location.origin;

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    loadServers();
    loadAudits();
    loadSettings();
    loadExecutions();

    // Auto-refresh executions every 5 seconds
    setInterval(updateExecutions, 5000);

    // Button event listeners
    var selectAllServersBtn = document.getElementById('select-all-servers-btn');
    if (selectAllServersBtn) selectAllServersBtn.addEventListener('click', selectAllServers);

    var clearServerSelectionBtn = document.getElementById('clear-server-selection-btn');
    if (clearServerSelectionBtn) clearServerSelectionBtn.addEventListener('click', clearServerSelection);

    var selectAllAuditsBtn = document.getElementById('select-all-audits-btn');
    if (selectAllAuditsBtn) selectAllAuditsBtn.addEventListener('click', selectAllAudits);

    var clearAuditSelectionBtn = document.getElementById('clear-audit-selection-btn');
    if (clearAuditSelectionBtn) clearAuditSelectionBtn.addEventListener('click', clearAuditSelection);

    var startBatchExecutionBtn = document.getElementById('start-batch-execution-btn');
    if (startBatchExecutionBtn) startBatchExecutionBtn.addEventListener('click', startBatchExecution);

    var refreshAllBtn = document.getElementById('refresh-all-btn');
    if (refreshAllBtn) refreshAllBtn.addEventListener('click', refreshAll);

    // Select change listener
    var executionMode = document.getElementById('execution-mode');
    if (executionMode) executionMode.addEventListener('change', toggleExecutionMode);
});

async function apiRequest(endpoint, options = {}) {
    options.headers = options.headers || {};
    options.headers['X-API-Key'] = API_KEY;
    options.headers['Content-Type'] = 'application/json';
    options.credentials = 'include';

    const response = await fetch(`${API_BASE}${endpoint}`, options);
    if (!response.ok) {
        throw new Error(`API error: ${response.statusText}`);
    }
    return response.json();
}

async function loadServers() {
    try {
        const data = await apiRequest('/api/v2/servers');
        servers = data.servers || [];

        document.getElementById('total-servers').textContent = servers.length;
        renderServerList();
    } catch (error) {
        console.error('Failed to load servers:', error);
        alert('Failed to load servers. Check API key and connection.');
    }
}

async function loadAudits() {
    try {
        const data = await apiRequest('/api/v2/audits');
        audits = data.audits || [];

        document.getElementById('total-audits').textContent = audits.length;
        renderAuditList();
        renderAuditSelect();
    } catch (error) {
        console.error('Failed to load audits:', error);
    }
}

async function loadSettings() {
    try {
        const data = await apiRequest('/api/v2/batch/settings');
        document.getElementById('max-concurrent-input').value = data.max_concurrent_ssh;
        document.getElementById('max-concurrent').textContent = data.max_concurrent_ssh;
    } catch (error) {
        console.error('Failed to load settings:', error);
    }
}

async function loadExecutions() {
    // Load from localStorage for now (in real app, would fetch from API)
    const stored = localStorage.getItem('batch_executions');
    executions = stored ? JSON.parse(stored) : [];
    renderExecutions();
}

function renderServerList() {
    const container = document.getElementById('server-list');

    if (servers.length === 0) {
        container.innerHTML = '<div class="empty-state"><p>No servers found</p></div>';
        return;
    }

    container.innerHTML = servers.map(server => `
        <div class="multi-select-item ${selectedServers.has(server.id) ? 'selected' : ''}"
             onclick="toggleServer(${parseInt(server.id, 10)})">
            <input type="checkbox" ${selectedServers.has(server.id) ? 'checked' : ''}
                   onclick="event.stopPropagation(); toggleServer(${parseInt(server.id, 10)})">
            <div>
                <strong>${escapeHtml(server.name)}</strong><br>
                <small>${escapeHtml(server.hostname)}:${escapeHtml(server.port)}</small>
            </div>
        </div>
    `).join('');

    document.getElementById('selected-servers-count').textContent = selectedServers.size;
}

function renderAuditList() {
    const container = document.getElementById('audit-list');

    if (audits.length === 0) {
        container.innerHTML = '<div class="empty-state"><p>No audits found</p></div>';
        return;
    }

    container.innerHTML = audits.map(audit => `
        <div class="multi-select-item ${selectedAudits.has(audit.file_path) ? 'selected' : ''}"
             onclick="toggleAudit('${escapeHtml(audit.file_path).replace(/'/g, "\\'")}')">
            <input type="checkbox" ${selectedAudits.has(audit.file_path) ? 'checked' : ''}
                   onclick="event.stopPropagation(); toggleAudit('${escapeHtml(audit.file_path).replace(/'/g, "\\'")}')">
            <div>
                <strong>${escapeHtml(audit.name)}</strong><br>
                <small>${escapeHtml(audit.domain)} › ${escapeHtml(audit.category)}</small>
            </div>
        </div>
    `).join('');

    document.getElementById('selected-audits-count').textContent = selectedAudits.size;
}

function renderAuditSelect() {
    const select = document.getElementById('audit-select');

    if (audits.length === 0) {
        select.innerHTML = '<option value="">No audits available</option>';
        return;
    }

    select.innerHTML = '<option value="">-- Select an audit --</option>' +
        audits.map(audit =>
            `<option value="${escapeHtml(audit.file_path)}">${escapeHtml(audit.name)} (${escapeHtml(audit.domain)}/${escapeHtml(audit.category)})</option>`
        ).join('');
}

function toggleServer(serverId) {
    if (selectedServers.has(serverId)) {
        selectedServers.delete(serverId);
    } else {
        selectedServers.add(serverId);
    }
    renderServerList();
}

function toggleAudit(auditPath) {
    if (selectedAudits.has(auditPath)) {
        selectedAudits.delete(auditPath);
    } else {
        selectedAudits.add(auditPath);
    }
    renderAuditList();
}

function selectAllServers() {
    selectedServers = new Set(servers.map(s => s.id));
    renderServerList();
}

function clearServerSelection() {
    selectedServers.clear();
    renderServerList();
}

function selectAllAudits() {
    selectedAudits = new Set(audits.map(a => a.file_path));
    renderAuditList();
}

function clearAuditSelection() {
    selectedAudits.clear();
    renderAuditList();
}

function toggleExecutionMode() {
    const mode = document.getElementById('execution-mode').value;
    const singleGroup = document.getElementById('single-audit-group');
    const matrixGroup = document.getElementById('matrix-audit-group');

    if (mode === 'single') {
        singleGroup.classList.remove('d-none');
        matrixGroup.classList.add('d-none');
    } else {
        singleGroup.classList.add('d-none');
        matrixGroup.classList.remove('d-none');
    }
}

async function startBatchExecution() {
    const mode = document.getElementById('execution-mode').value;
    const serverIds = Array.from(selectedServers);
    const maxConcurrent = parseInt(document.getElementById('max-concurrent-input').value);
    const timeout = parseInt(document.getElementById('timeout-input').value);

    // Get stream mode: true = agentless (stream scripts), false = deployed (local package)
    const streamModeEl = document.getElementById('stream-mode');
    const streamMode = streamModeEl ? streamModeEl.value !== 'deployed' : true;

    if (serverIds.length === 0) {
        alert('Please select at least one server');
        return;
    }

    try {
        let result;

        if (mode === 'single') {
            const auditPath = document.getElementById('audit-select').value;
            if (!auditPath) {
                alert('Please select an audit');
                return;
            }

            result = await apiRequest('/api/v2/batch/audits/execute', {
                method: 'POST',
                body: JSON.stringify({
                    server_ids: serverIds,
                    audit_path: auditPath,
                    max_concurrent: maxConcurrent,
                    timeout: timeout,
                    stream_mode: streamMode
                })
            });
        } else {
            const auditPaths = Array.from(selectedAudits);
            if (auditPaths.length === 0) {
                alert('Please select at least one audit');
                return;
            }

            result = await apiRequest('/api/v2/batch/audits/matrix', {
                method: 'POST',
                body: JSON.stringify({
                    server_ids: serverIds,
                    audit_paths: auditPaths,
                    max_concurrent: maxConcurrent,
                    timeout: timeout,
                    stream_mode: streamMode
                })
            });
        }

        // Add to executions list
        const execution = {
            task_id: result.task_id,
            mode: mode,
            servers_count: result.servers_count || serverIds.length,
            audits_count: result.audits_count || 1,
            started_at: new Date().toISOString(),
            state: 'PENDING',
            progress: 0
        };

        executions.unshift(execution);
        localStorage.setItem('batch_executions', JSON.stringify(executions));

        renderExecutions();
        updateExecutions();

        document.getElementById('active-executions').textContent =
            executions.filter(e => ['PENDING', 'STARTED', 'RUNNING'].includes(e.state)).length;

        alert(`Batch execution started! Task ID: ${result.task_id}`);
    } catch (error) {
        console.error('Execution failed:', error);
        alert(`Failed to start execution: ${error.message}`);
    }
}

async function updateExecutions() {
    const activeExecutions = executions.filter(e =>
        ['PENDING', 'STARTED', 'RUNNING'].includes(e.state)
    );

    for (const execution of activeExecutions) {
        try {
            const status = await apiRequest(`/api/v2/batch/status/${execution.task_id}`);

            execution.state = status.state;
            execution.progress = status.progress || 0;
            execution.status_message = status.status;

            if (status.state === 'SUCCESS') {
                const results = await apiRequest(`/api/v2/batch/results/${execution.task_id}`);
                execution.results = results;
            }
        } catch (error) {
            console.error(`Failed to update execution ${execution.task_id}:`, error);
        }
    }

    localStorage.setItem('batch_executions', JSON.stringify(executions));
    renderExecutions();

    document.getElementById('active-executions').textContent = activeExecutions.length;
}

function renderExecutions() {
    const container = document.getElementById('execution-list');

    if (executions.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">📭</div>
                <p>No executions yet. Start your first batch audit above!</p>
            </div>
        `;
        return;
    }

    container.innerHTML = executions.map(exec => {
        const statusClass = escapeHtml(exec.state).toLowerCase();
        const isActive = ['PENDING', 'STARTED', 'RUNNING'].includes(exec.state);

        return `
            <div class="execution-item ${isActive ? 'loading' : ''}">
                <div class="execution-header">
                    <div class="execution-title">
                        ${exec.mode === 'single' ? '📋' : '🎯'}
                        ${exec.mode === 'single' ? 'Single' : 'Matrix'} Execution
                    </div>
                    <div class="execution-status status-${statusClass}">
                        ${escapeHtml(exec.state)}
                    </div>
                </div>

                ${isActive ? `
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${parseInt(exec.progress, 10) || 0}%">
                            ${parseInt(exec.progress, 10) || 0}%
                        </div>
                    </div>
                    <p style="text-align: center; color: #666;">
                        ${escapeHtml(exec.status_message) || 'Processing...'}
                    </p>
                ` : ''}

                <div class="execution-details">
                    <div class="detail-item">
                        <div class="detail-value">${parseInt(exec.servers_count, 10) || 0}</div>
                        <div class="detail-label">Servers</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-value">${parseInt(exec.audits_count, 10) || 0}</div>
                        <div class="detail-label">Audits</div>
                    </div>
                    ${exec.results && exec.results.summary ? `
                        <div class="detail-item">
                            <div class="detail-value">${parseInt(exec.results.summary.successful_servers, 10) || 0}</div>
                            <div class="detail-label">Successful</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-value">${parseInt(exec.results.summary.failed_servers, 10) || 0}</div>
                            <div class="detail-label">Failed</div>
                        </div>
                    ` : ''}
                </div>

                <div style="margin-top: 15px; font-size: 0.9em; color: #666;">
                    <strong>Task ID:</strong> ${escapeHtml(exec.task_id)}<br>
                    <strong>Started:</strong> ${new Date(exec.started_at).toLocaleString()}
                </div>
            </div>
        `;
    }).join('');
}

function refreshAll() {
    loadServers();
    loadAudits();
    loadSettings();
    updateExecutions();
}
