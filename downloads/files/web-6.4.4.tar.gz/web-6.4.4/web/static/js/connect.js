/**
 * Connect Tab JavaScript
 * Handles interactive server connection setup
 */

(function() {
    'use strict';

    // Distribution/Version Data
    const osDistributions = {
        linux: [
            { value: 'ubuntu', label: 'Ubuntu', icon: '🐧' },
            { value: 'debian', label: 'Debian', icon: '🐧' },
            { value: 'rhel', label: 'Red Hat Enterprise Linux', icon: '🎩' },
            { value: 'centos', label: 'CentOS / Rocky Linux', icon: '🏔️' },
            { value: 'fedora', label: 'Fedora', icon: '🎩' },
            { value: 'opensuse', label: 'openSUSE', icon: '🦎' },
            { value: 'arch', label: 'Arch Linux', icon: '🏹' },
            { value: 'alpine', label: 'Alpine Linux', icon: '🏔️' },
            { value: 'amazon', label: 'Amazon Linux', icon: '☁️' },
            { value: 'oracle', label: 'Oracle Linux', icon: '🔴' }
        ],
        windows: [
            { value: 'windows-server', label: 'Windows Server', icon: '🪟' },
            { value: 'windows-desktop', label: 'Windows Desktop', icon: '🖥️' }
        ],
        hypervisor: [
            { value: 'esxi', label: 'VMware ESXi', icon: '🟢' },
            { value: 'proxmox', label: 'Proxmox VE', icon: '🟠' },
            { value: 'hyperv', label: 'Hyper-V', icon: '🔵' },
            { value: 'xenserver', label: 'XenServer / XCP-ng', icon: '🟣' },
            { value: 'nutanix', label: 'Nutanix AHV', icon: '🔶' },
            { value: 'kvm', label: 'KVM / libvirt', icon: '🐧' }
        ]
    };

    const distroVersions = {
        // Linux distributions
        'ubuntu': [
            { value: '24.04', label: 'Ubuntu 24.04 LTS (Noble Numbat)' },
            { value: '22.04', label: 'Ubuntu 22.04 LTS (Jammy Jellyfish)' },
            { value: '20.04', label: 'Ubuntu 20.04 LTS (Focal Fossa)' },
            { value: '18.04', label: 'Ubuntu 18.04 LTS (Bionic Beaver)' }
        ],
        'debian': [
            { value: '12', label: 'Debian 12 (Bookworm)' },
            { value: '11', label: 'Debian 11 (Bullseye)' },
            { value: '10', label: 'Debian 10 (Buster)' }
        ],
        'rhel': [
            { value: '9', label: 'RHEL 9' },
            { value: '8', label: 'RHEL 8' },
            { value: '7', label: 'RHEL 7' }
        ],
        'centos': [
            { value: '9-stream', label: 'CentOS Stream 9' },
            { value: '8-stream', label: 'CentOS Stream 8' },
            { value: 'rocky-9', label: 'Rocky Linux 9' },
            { value: 'rocky-8', label: 'Rocky Linux 8' },
            { value: 'alma-9', label: 'AlmaLinux 9' },
            { value: 'alma-8', label: 'AlmaLinux 8' }
        ],
        'fedora': [
            { value: '40', label: 'Fedora 40' },
            { value: '39', label: 'Fedora 39' },
            { value: '38', label: 'Fedora 38' }
        ],
        'opensuse': [
            { value: 'leap-15.6', label: 'openSUSE Leap 15.6' },
            { value: 'leap-15.5', label: 'openSUSE Leap 15.5' },
            { value: 'tumbleweed', label: 'openSUSE Tumbleweed' }
        ],
        'arch': [
            { value: 'rolling', label: 'Arch Linux (Rolling Release)' }
        ],
        'alpine': [
            { value: '3.20', label: 'Alpine Linux 3.20' },
            { value: '3.19', label: 'Alpine Linux 3.19' },
            { value: '3.18', label: 'Alpine Linux 3.18' }
        ],
        'amazon': [
            { value: '2023', label: 'Amazon Linux 2023' },
            { value: '2', label: 'Amazon Linux 2' }
        ],
        'oracle': [
            { value: '9', label: 'Oracle Linux 9' },
            { value: '8', label: 'Oracle Linux 8' }
        ],
        // Windows distributions
        'windows-server': [
            { value: '2025', label: 'Windows Server 2025' },
            { value: '2022', label: 'Windows Server 2022' },
            { value: '2019', label: 'Windows Server 2019' },
            { value: '2016', label: 'Windows Server 2016' }
        ],
        'windows-desktop': [
            { value: '11', label: 'Windows 11' },
            { value: '10', label: 'Windows 10' }
        ],
        // Hypervisor distributions
        'esxi': [
            { value: '8.0', label: 'ESXi 8.0' },
            { value: '7.0', label: 'ESXi 7.0' },
            { value: '6.7', label: 'ESXi 6.7' },
            { value: '6.5', label: 'ESXi 6.5' }
        ],
        'proxmox': [
            { value: '8.x', label: 'Proxmox VE 8.x' },
            { value: '7.x', label: 'Proxmox VE 7.x' }
        ],
        'hyperv': [
            { value: '2022', label: 'Hyper-V Server 2022' },
            { value: '2019', label: 'Hyper-V Server 2019' },
            { value: '2016', label: 'Hyper-V Server 2016' }
        ],
        'xenserver': [
            { value: '8.x', label: 'XenServer 8.x / XCP-ng 8.x' },
            { value: '7.x', label: 'XenServer 7.x' }
        ],
        'nutanix': [
            { value: 'ahv', label: 'Nutanix AHV (Latest)' }
        ],
        'kvm': [
            { value: 'libvirt', label: 'KVM with libvirt' }
        ]
    };

    // Permission information by OS
    const permissionInfo = {
        linux: `
            <h4>🐧 Linux Server Requirements</h4>
            <p><strong>Recommended:</strong> Dedicated audit user with targeted sudo permissions</p>

            <div class="permission-section">
                <h5>Quick Setup (run on target server):</h5>
                <pre class="code-block">
# Create audit user
sudo useradd -m -s /bin/bash audit-user
sudo passwd audit-user

# Configure SSH key auth (recommended)
sudo mkdir -p /home/audit-user/.ssh
sudo chmod 700 /home/audit-user/.ssh

# Add sudoers permissions for audit commands
echo 'audit-user ALL=(ALL) NOPASSWD: /usr/sbin/auditctl, /usr/bin/systemctl status *, /sbin/iptables -L *' | sudo tee /etc/sudoers.d/audit-user</pre>
            </div>

            <p><strong>Required access for full audits:</strong></p>
            <ul>
                <li>Read: <code>/etc/shadow</code>, <code>/etc/sudoers</code>, <code>/etc/ssh/sshd_config</code></li>
                <li>Sudo: <code>systemctl</code>, <code>iptables</code>, <code>auditctl</code>, <code>firewall-cmd</code></li>
            </ul>
            <p><a href="/docs/TARGET-HOST-REQUIREMENTS.md" target="_blank">📖 Full documentation</a></p>
        `,
        windows: `
            <h4>🪟 Windows Server Requirements</h4>
            <p><strong>Recommended:</strong> Local Administrators group membership or delegated admin</p>

            <div class="permission-section">
                <h5>Quick Setup (run on target server as Administrator):</h5>
                <pre class="code-block">
# Enable WinRM
Enable-PSRemoting -Force

# Allow unencrypted for testing (use HTTPS in production)
Set-Item WSMan:\\localhost\\Service\\AllowUnencrypted -Value $true

# Configure firewall
New-NetFirewallRule -Name "WinRM-HTTP" -DisplayName "WinRM HTTP" -Enabled True -Profile Any -Action Allow -Protocol TCP -LocalPort 5985

# For HTTPS (recommended for production):
# New-NetFirewallRule -Name "WinRM-HTTPS" -DisplayName "WinRM HTTPS" -Enabled True -Profile Any -Action Allow -Protocol TCP -LocalPort 5986</pre>
            </div>

            <p><strong>Username formats:</strong></p>
            <ul>
                <li>Local account: <code>Administrator</code> or <code>.\\Administrator</code></li>
                <li>Domain account: <code>DOMAIN\\Username</code> or <code>user@domain.com</code></li>
            </ul>

            <p><strong>Required for audits:</strong></p>
            <ul>
                <li>Audit Policy, Windows Defender status, Security Policy</li>
                <li>BitLocker status, Windows Update, Event Logs</li>
            </ul>
            <p><a href="/docs/TARGET-HOST-REQUIREMENTS.md" target="_blank">📖 Full documentation</a></p>
        `,
        hypervisor: `
            <h4>🖥️ Hypervisor Requirements</h4>
            <p><strong>Connection type varies by hypervisor platform:</strong></p>

            <div class="permission-section">
                <h5>VMware ESXi:</h5>
                <ul>
                    <li>SSH enabled on the host</li>
                    <li>Root or administrator access</li>
                    <li>Port 22 (SSH) or 443 (API)</li>
                </ul>

                <h5>Proxmox VE:</h5>
                <ul>
                    <li>SSH access to the Proxmox host</li>
                    <li>Root or sudo user</li>
                    <li>Port 22 (SSH)</li>
                </ul>

                <h5>Hyper-V:</h5>
                <ul>
                    <li>WinRM enabled (same as Windows Server)</li>
                    <li>Hyper-V Administrators group membership</li>
                    <li>Port 5985/5986 (WinRM)</li>
                </ul>
            </div>

            <p><strong>Required for audits:</strong></p>
            <ul>
                <li>VM inventory and configuration</li>
                <li>Network configuration</li>
                <li>Storage configuration</li>
                <li>Security settings</li>
            </ul>
            <p><a href="/docs/TARGET-HOST-REQUIREMENTS.md" target="_blank">📖 Full documentation</a></p>
        `
    };


    // State
    let currentOS = 'linux';
    let currentDistro = '';
    let currentVersion = '';
    let cachedServers = [];  // Cache all servers for filtering
    let connectTabInitialized = false;
    let currentSearchFilter = '';
    let currentUserRole = null;
    let isSuperAdmin = false;
    let canManageConnectionMethod = false;

    // Initialize when DOM is ready or immediately if already loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initConnectTab);
    } else {
        // DOM already loaded, init immediately
        setTimeout(initConnectTab, 0);
    }

    // Also load servers when connect tab becomes active
    document.addEventListener('tabChanged', function(e) {
        if (e.detail && e.detail.tab === 'connect') {
            console.log('Connect tab activated, loading servers...');
            loadServers();
        }
    });

    function initConnectTab() {
        // Always load servers first - this is the critical function
        loadServers();
        fetchCurrentUserRole();

        // Check if wizard form elements exist (they may have been removed)
        const osTypeInputs = document.querySelectorAll('input[name="os-type"]');
        if (!osTypeInputs.length) {
            console.log('Connect tab: No wizard form elements found, server list loaded.');
            return;
        }

        // OS type change handler
        osTypeInputs.forEach(input => {
            input.addEventListener('change', handleOSChange);
        });

        // Distro change handler
        const distroSelect = document.getElementById('connect-distro');
        if (distroSelect) {
            distroSelect.addEventListener('change', handleDistroChange);
        }

        // Auth method change handler
        const authInputs = document.querySelectorAll('input[name="auth-method"]');
        authInputs.forEach(input => {
            input.addEventListener('change', handleAuthMethodChange);
        });

        // Execution mode change handler
        const execModeInputs = document.querySelectorAll('input[name="execution-mode"]');
        execModeInputs.forEach(input => {
            input.addEventListener('change', function() {
                // Update selected class on rows
                document.querySelectorAll('.execution-mode-row').forEach(row => {
                    row.classList.remove('selected');
                });
                const parentRow = this.closest('.execution-mode-row');
                if (parentRow) {
                    parentRow.classList.add('selected');
                }
                handleExecutionModeChange();
            });
        });

        // Table row click handlers for execution mode
        document.querySelectorAll('.execution-mode-row').forEach(row => {
            row.addEventListener('click', function(e) {
                if (e.target.type === 'radio') return; // Let radio handle itself
                const radio = this.querySelector('input[type="radio"]');
                if (radio) {
                    radio.checked = true;
                    radio.dispatchEvent(new Event('change', { bubbles: true }));
                }
            });
        });

        // Test connection button
        const testBtn = document.getElementById('test-connection');
        if (testBtn) {
            testBtn.addEventListener('click', testConnection);
        }

        // Save server button
        const saveBtn = document.getElementById('save-server');
        if (saveBtn) {
            saveBtn.addEventListener('click', saveServer);
        }

        // Initialize with default values
        handleOSChange();
        handleExecutionModeChange();
        updatePermissionInfo();
        // loadServers() already called at start of initConnectTab
    }

    async function fetchCurrentUserRole() {
        try {
            const response = await fetch('/auth/me', {
                headers: getHeaders(),
                credentials: 'include'
            });

            if (!response.ok) {
                return;
            }

            const data = await response.json();
            currentUserRole = data?.user?.role || null;
            isSuperAdmin = currentUserRole === 'SuperAdmin';
            canManageConnectionMethod = ['Admin', 'SuperAdmin'].includes(currentUserRole);
            applyServerConnectionMethodEditPermission();
            if (cachedServers.length > 0) {
                renderServerList(cachedServers);
            }
        } catch (error) {
            console.warn('Could not determine current user role for connect tab:', error);
        }
    }

    function applyServerConnectionMethodEditPermission() {
        const connectionSelect = document.getElementById('edit-server-connection');
        if (!connectionSelect) {
            return;
        }

        const lockMethodChanges = currentUserRole !== null && !canManageConnectionMethod;
        connectionSelect.disabled = lockMethodChanges;
        connectionSelect.title = lockMethodChanges
            ? 'Only Admin or SuperAdmin can change connection method for existing servers'
            : '';
    }

    function getServerMethodOptions(server) {
        if (server.os_type === 'windows') {
            return ['winrm', 'fleet-agent'];
        }
        if (server.os_type === 'linux') {
            return ['ssh', 'fleet-agent'];
        }
        if (server.os_type === 'hypervisor') {
            return ['hypervisor', 'ssh', 'winrm', 'fleet-agent'];
        }
        return ['ssh', 'winrm', 'fleet-agent', 'hypervisor'];
    }

    function formatConnectionMethodLabel(method) {
        const m = String(method || '').toLowerCase();
        if (m === 'fleet-agent' || m === 'fleet_agent' || m === 'agent') return 'Fleet Agent';
        if (m === 'ssh') return 'SSH';
        if (m === 'winrm') return 'WinRM';
        if (m === 'hypervisor') return 'Hypervisor';
        return method || 'Unknown';
    }

    function handleOSChange() {
        const selectedOS = document.querySelector('input[name="os-type"]:checked').value;
        currentOS = selectedOS;

        // Update distro dropdown
        const distroSelect = document.getElementById('connect-distro');
        distroSelect.innerHTML = '<option value="">-- Select Distribution --</option>';

        const distros = osDistributions[selectedOS] || [];
        distros.forEach(distro => {
            const option = document.createElement('option');
            option.value = distro.value;
            option.textContent = `${distro.icon} ${distro.label}`;
            distroSelect.appendChild(option);
        });

        // Clear version dropdown
        const versionSelect = document.getElementById('connect-version');
        versionSelect.innerHTML = '<option value="">-- Select Version --</option>';

        // Update port hint
        const portHint = document.getElementById('port-hint');
        const portInput = document.getElementById('connect-port');
        const usernameInput = document.getElementById('connect-username');
        const usernameHint = document.getElementById('username-hint');

        if (selectedOS === 'windows') {
            portInput.value = 5986;  // HTTPS by default for security
            portHint.textContent = 'WinRM port: 5986 (HTTPS/TLS) - Secure transport required';
            usernameInput.placeholder = 'e.g., Administrator or DOMAIN\\User';
            if (usernameHint) {
                usernameHint.textContent = 'Use DOMAIN\\User for domain accounts, or local username for local accounts';
                usernameHint.style.display = 'block';
            }
        } else if (selectedOS === 'hypervisor') {
            portInput.value = 22;  // Default SSH, but may vary
            portHint.textContent = 'SSH port: 22 (ESXi/Proxmox) or WinRM: 5986 (Hyper-V)';
            usernameInput.placeholder = 'e.g., root or Administrator';
            if (usernameHint) {
                usernameHint.textContent = 'Use root for ESXi/Proxmox, Administrator for Hyper-V';
                usernameHint.style.display = 'block';
            }
        } else {
            portInput.value = 22;
            portHint.textContent = 'SSH port: 22 (encrypted transport)';
            usernameInput.placeholder = 'e.g., root or audit-user';
            if (usernameHint) {
                usernameHint.textContent = 'Use a dedicated audit user with sudo permissions for security';
                usernameHint.style.display = 'block';
            }
        }

        // Update auth options visibility
        const keyOption = document.getElementById('auth-key-option');
        const certOption = document.getElementById('auth-cert-option');

        if (selectedOS === 'windows') {
            // Show certificate option for Windows
            certOption.style.display = 'block';
        } else {
            // Hide certificate option for Linux
            certOption.style.display = 'none';
            // Reset to password if certificate was selected
            const selectedAuth = document.querySelector('input[name="auth-method"]:checked');
            if (selectedAuth && selectedAuth.value === 'certificate') {
                document.querySelector('input[name="auth-method"][value="password"]').checked = true;
                handleAuthMethodChange();
            }
        }

        // Update permission info
        updatePermissionInfo();

        // Update filtered servers list
        updateFilteredServers();
    }

    function handleDistroChange() {
        const distroSelect = document.getElementById('connect-distro');
        const versionSelect = document.getElementById('connect-version');
        currentDistro = distroSelect.value;

        // Clear and populate version dropdown
        versionSelect.innerHTML = '<option value="">-- Select Version --</option>';

        const versions = distroVersions[currentDistro] || [];
        versions.forEach(version => {
            const option = document.createElement('option');
            option.value = version.value;
            option.textContent = version.label;
            versionSelect.appendChild(option);
        });

        // Auto-select first version if available
        if (versions.length > 0) {
            versionSelect.value = versions[0].value;
            currentVersion = versions[0].value;
        }
    }

    function handleAuthMethodChange() {
        const selectedAuth = document.querySelector('input[name="auth-method"]:checked').value;

        const passwordField = document.getElementById('password-field');
        const keyFileField = document.getElementById('key-file-field');
        const keyPassphraseField = document.getElementById('key-passphrase-field');

        // Hide all first
        passwordField.style.display = 'none';
        keyFileField.style.display = 'none';
        keyPassphraseField.style.display = 'none';

        // Show relevant fields
        switch (selectedAuth) {
            case 'password':
                passwordField.style.display = 'block';
                break;
            case 'key':
                keyFileField.style.display = 'block';
                keyPassphraseField.style.display = 'block';
                break;
            case 'certificate':
                keyFileField.style.display = 'block';
                keyPassphraseField.style.display = 'block';
                document.querySelector('#key-file-field label').textContent = 'Certificate Path';
                break;
        }
    }

    function handleExecutionModeChange() {
        const selectedMode = document.querySelector('input[name="execution-mode"]:checked')?.value || 'stream';
        const warningDiv = document.getElementById('deployed-mode-warning');

        if (warningDiv) {
            if (selectedMode === 'deployed') {
                warningDiv.classList.remove('d-none');
                warningDiv.style.display = 'block';
            } else {
                warningDiv.classList.add('d-none');
                warningDiv.style.display = 'none';
            }
        }
    }

    function updatePermissionInfo() {
        const permissionDetails = document.getElementById('permission-details');
        if (permissionDetails) {
            permissionDetails.innerHTML = permissionInfo[currentOS] || '';
        }
    }

    async function testConnection() {
        const resultDiv = document.getElementById('connection-result');
        resultDiv.style.display = 'block';
        resultDiv.className = 'connection-result testing';
        resultDiv.innerHTML = `
            <div class="result-header">
                <span class="result-icon">⏳</span>
                <span class="result-title">Testing connection...</span>
            </div>
            <pre class="result-details">Attempting to connect to server...</pre>
        `;

        const serverData = getServerFormData();

        if (!serverData.hostname || !serverData.username) {
            showConnectionResult(false, 'Please fill in hostname and username');
            return;
        }

        try {
            // First, create/update the server
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {
                'Content-Type': 'application/json'
            };
            if (apiKey) {
                headers['X-API-Key'] = apiKey;
            }

            // Test using the test endpoint
            const response = await fetch('/api/servers/test-connection', {
                method: 'POST',
                credentials: 'include',
                headers: headers,
                body: JSON.stringify({
                    hostname: serverData.hostname,
                    port: serverData.port,
                    username: serverData.username,
                    password: serverData.password,
                    auth_method: serverData.auth_method,
                    key_path: serverData.key_path,
                    os_type: currentOS
                })
            });

            const data = await response.json();

            if (data.success) {
                showConnectionResult(true, data.message || 'Connection successful!', data.details);
            } else {
                showConnectionResult(false, data.error || 'Connection failed', data.details);
            }
        } catch (error) {
            showConnectionResult(false, 'Connection test failed: ' + error.message);
        }
    }

    function showConnectionResult(success, message, details = '') {
        const resultDiv = document.getElementById('connection-result');
        resultDiv.className = 'connection-result ' + (success ? 'success' : 'failure');
        resultDiv.innerHTML = `
            <div class="result-header">
                <span class="result-icon">${success ? '✅' : '❌'}</span>
                <span class="result-title">${escapeHtml(message)}</span>
            </div>
            ${details ? `<pre class="result-details">${escapeHtml(details)}</pre>` : ''}
        `;
    }

    async function saveServer() {
        const serverData = getServerFormData();

        if (!serverData.name || !serverData.hostname || !serverData.username) {
            alert('Please fill in all required fields (Server Name, Hostname, Username)');
            return;
        }

        try {
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {
                'Content-Type': 'application/json'
            };
            if (apiKey) {
                headers['X-API-Key'] = apiKey;
            }

            const response = await fetch('/api/servers', {
                method: 'POST',
                credentials: 'include',
                headers: headers,
                body: JSON.stringify({
                    name: serverData.name,
                    hostname: serverData.hostname,
                    port: serverData.port,
                    username: serverData.username,
                    password: serverData.password,
                    auth_method: serverData.auth_method,
                    key_path: serverData.key_path,
                    os_type: currentOS,
                    distro: currentDistro,
                    version: currentVersion,
                    description: serverData.description
                })
            });

            const data = await response.json();

            if (data.success || response.ok) {
                alert('Server saved successfully!');
                clearForm();
                loadServers();
            } else {
                alert('Failed to save server: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            alert('Error saving server: ' + error.message);
        }
    }

    function getServerFormData() {
        const authMethod = document.querySelector('input[name="auth-method"]:checked').value;
        const port = parseInt(document.getElementById('connect-port').value) || (currentOS === 'windows' ? 5986 : 22);
        const protocol = currentOS === 'windows' ? 'winrm' : 'ssh';

        // Determine SSL based on port (5986 = HTTPS, 5985 = HTTP for WinRM)
        const useSSL = currentOS === 'windows' && (port === 5986 || port !== 5985);

        // Get execution mode (stream or deployed)
        const executionModeRadio = document.querySelector('input[name="execution-mode"]:checked');
        const executionMode = executionModeRadio ? executionModeRadio.value : 'stream';

        return {
            name: document.getElementById('connect-name').value.trim(),
            hostname: document.getElementById('connect-hostname').value.trim(),
            port: port,
            username: document.getElementById('connect-username').value.trim(),
            password: document.getElementById('connect-password').value,
            auth_method: authMethod,
            key_path: document.getElementById('connect-keyfile').value.trim(),
            description: document.getElementById('connect-description').value.trim(),
            os_type: currentOS,
            protocol: protocol,
            use_ssl: useSSL,
            verify_ssl: true,  // Always verify SSL certificates for security
            execution_mode: executionMode
        };
    }

    function clearForm() {
        document.getElementById('connect-name').value = '';
        document.getElementById('connect-hostname').value = '';
        document.getElementById('connect-port').value = currentOS === 'windows' ? 5986 : 22;
        document.getElementById('connect-username').value = '';
        document.getElementById('connect-password').value = '';
        document.getElementById('connect-keyfile').value = '';
        document.getElementById('connect-passphrase').value = '';
        document.getElementById('connect-description').value = '';
        document.getElementById('connect-distro').value = '';
        document.getElementById('connect-version').innerHTML = '<option value="">-- Select Version --</option>';

        const resultDiv = document.getElementById('connection-result');
        resultDiv.style.display = 'none';
    }

    /**
     * Get headers for API requests including API key if available
     */
    function getHeaders() {
        const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
        const headers = {};
        if (apiKey) {
            headers['X-API-Key'] = apiKey;
        }
        return headers;
    }

    async function loadServers(options = {}) {
        const serversList = document.getElementById('connect-servers-list');
        if (!serversList) return;

        const showLoading = options.showLoading !== false && cachedServers.length === 0;

        if (showLoading) {
            serversList.innerHTML = '<p class="loading">Loading servers...</p>';
        }

        try {
            const response = await fetch('/api/servers', {
                headers: getHeaders(),
                credentials: 'include'
            });
            const data = await response.json();

            if (data.servers && data.servers.length > 0) {
                // Cache servers for filtering
                cachedServers = data.servers;

                // Update stats
                updateConnectStats(data.servers);

                // Update filtered servers in selection box
                updateFilteredServers();

                // Render the list
                renderServerList(cachedServers);
            } else {
                cachedServers = [];
                updateConnectStats([]);
                updateFilteredServers();
                serversList.innerHTML = '<p class="info-text">No servers configured. Click "Add Server" to add your first server.</p>';
            }
        } catch (error) {
            serversList.innerHTML = `<p class="error-text">Failed to load servers: ${error.message}</p>`;
        }
    }

    function renderServerList(servers) {
        const serversList = document.getElementById('connect-servers-list');
        if (!serversList) return;

        // Apply search filter
        let filteredServers = servers;
        if (currentSearchFilter) {
            const search = currentSearchFilter.toLowerCase();
            filteredServers = servers.filter(s =>
                (s.name || '').toLowerCase().includes(search) ||
                (s.hostname || '').toLowerCase().includes(search) ||
                (s.username || '').toLowerCase().includes(search) ||
                (s.os_type || '').toLowerCase().includes(search)
            );
        }

        if (filteredServers.length === 0) {
            if (currentSearchFilter) {
                serversList.innerHTML = '<p class="info-text">No servers match your search.</p>';
            } else {
                serversList.innerHTML = '<p class="info-text">No servers configured. Click "Add Server" to add your first server.</p>';
            }
            return;
        }

        // Build compact list HTML
        const headerRow = `
            <div class="connect-server-list-header">
                <span>Name</span>
                <span>Host</span>
                <span>User</span>
                <span>Status</span>
                <span>Actions</span>
            </div>
        `;

        const rows = filteredServers.map(server => {
            const status = server.last_test_success === true ? 'online' :
                          server.last_test_success === false ? 'offline' : 'untested';
            const statusLabel = status === 'online' ? 'Online' :
                               status === 'offline' ? 'Offline' : 'Untested';
            return `
                <div class="connect-server-row" data-server-id="${server.id}">
                    <div class="connect-server-name-col">
                        <span class="connect-server-icon">${getOsIcon(server.os_type)}</span>
                        <span class="connect-server-name">${escapeHtml(server.name)}</span>
                    </div>
                    <div class="connect-server-host">${escapeHtml(server.hostname)}:${server.port || 22}</div>
                    <div class="connect-server-user">${escapeHtml(server.username || 'N/A')}</div>
                    <div class="connect-server-status">
                        <span class="status-dot ${status}"></span>
                        <span>${statusLabel}</span>
                    </div>
                    <div class="connect-server-actions">
                        <button class="btn-icon" onclick="connectTab.testServer(${server.id})" title="Test">🔍</button>
                        ${canManageConnectionMethod ? `<button class="btn-icon" onclick="connectTab.changeServerConnectionMethod(${server.id})" title="Change Connection Method">🔄</button>` : ''}
                        <button class="btn-icon" onclick="openEditServerModal(${server.id})" title="Edit">✏️</button>
                        <button class="btn-icon btn-icon-danger" onclick="connectTab.deleteServer(${server.id})" title="Delete">🗑️</button>
                    </div>
                </div>
            `;
        }).join('');

        serversList.innerHTML = headerRow + rows;
    }

    function filterServerList(searchTerm) {
        currentSearchFilter = searchTerm;
        renderServerList(cachedServers);
    }

    async function testServer(serverId) {
        try {
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {};
            if (apiKey) {
                headers['X-API-Key'] = apiKey;
            }

            const response = await fetch(`/api/servers/${serverId}/test`, {
                method: 'POST',
                credentials: 'include',
                headers
            });
            const data = await response.json();

            if (data.success) {
                alert('✅ Connection successful!');
            } else {
                alert('❌ Connection failed: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            alert('Error testing server: ' + error.message);
        }
    }

    async function changeServerConnectionMethod(serverId) {
        if (!canManageConnectionMethod) {
            alert('Only Admin or SuperAdmin can change connection method for existing servers.');
            return;
        }

        const server = cachedServers.find(s => s.id === serverId);
        if (!server) {
            alert('Server not found');
            return;
        }

        const options = getServerMethodOptions(server);
        const currentMethod = String(server.connection_method || '').toLowerCase();
        const optionText = options.map((method, index) => `${index + 1}) ${formatConnectionMethodLabel(method)} (${method})`).join('\n');

        const input = prompt(
            `Change connection method for ${server.name || server.hostname}\n\n${optionText}\n\nEnter option number or method value:`,
            currentMethod || options[0]
        );

        if (input === null) return;

        let selectedMethod = String(input).trim().toLowerCase();
        const idx = parseInt(selectedMethod, 10);
        if (!Number.isNaN(idx) && idx >= 1 && idx <= options.length) {
            selectedMethod = options[idx - 1];
        }
        if (selectedMethod === 'agent') {
            selectedMethod = 'fleet-agent';
        }

        if (!options.includes(selectedMethod)) {
            alert(`Invalid selection. Allowed methods: ${options.join(', ')}`);
            return;
        }

        if ((currentMethod || 'ssh') === selectedMethod) {
            return;
        }

        try {
            const response = await fetch(`/api/servers/${serverId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    ...getHeaders()
                },
                credentials: 'include',
                body: JSON.stringify({ connection_method: selectedMethod })
            });

            const data = await response.json();
            if (response.ok && data.success) {
                if (typeof showToast === 'function') {
                    showToast(`Connection method updated to ${formatConnectionMethodLabel(selectedMethod)}`, 'success');
                }
                loadServers({ showLoading: false });
            } else {
                alert('Failed to change connection method: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            alert('Error changing connection method: ' + error.message);
        }
    }

    async function deleteServer(serverId) {
        if (!confirm('Are you sure you want to delete this server?')) {
            return;
        }

        try {
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {};
            if (apiKey) {
                headers['X-API-Key'] = apiKey;
            }

            const response = await fetch(`/api/servers/${serverId}`, {
                method: 'DELETE',
                credentials: 'include',
                headers
            });

            if (response.ok) {
                loadServers();
            } else {
                const data = await response.json();
                alert('Failed to delete server: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            alert('Error deleting server: ' + error.message);
        }
    }

    function editServer(serverId) {
        openEditServerModal(serverId);
    }

    async function openEditServerModal(serverId) {
        const modal = document.getElementById('edit-server-modal');
        if (!modal) {
            alert('Edit modal not found');
            return;
        }

        // Fetch server data
        try {
            const response = await fetch(`/api/servers/${serverId}`, {
                headers: getHeaders()
            });

            if (response.ok) {
                const data = await response.json();
                if (data.success && data.server) {
                    const server = data.server;

                    document.getElementById('edit-server-id').value = server.id;
                    document.getElementById('edit-server-name').value = server.name || '';
                    document.getElementById('edit-server-host').value = server.host || server.hostname || '';
                    document.getElementById('edit-server-port').value = server.port || 22;
                    document.getElementById('edit-server-user').value = server.user || server.username || '';
                    document.getElementById('edit-server-os').value = server.os_type || 'linux';
                    document.getElementById('edit-server-connection').value = server.connection_method || 'ssh';
                    document.getElementById('edit-server-execution-mode').value = server.execution_mode || 'stream';

                    const form = document.getElementById('edit-server-form');
                    if (form) {
                        form.dataset.originalConnectionMethod = server.connection_method || 'ssh';
                    }

                    // Set elevation method and update options based on OS
                    const elevationMethodEl = document.getElementById('edit-server-elevation-method');
                    if (elevationMethodEl) {
                        updateElevationOptions('edit-server-elevation-method', server.os_type || 'linux');
                        elevationMethodEl.value = server.elevation_method || 'sudo';
                        toggleJeaEndpointField('edit');
                    }

                    // Set JEA endpoint
                    const jeaEndpointEl = document.getElementById('edit-server-jea-endpoint');
                    if (jeaEndpointEl) {
                        jeaEndpointEl.value = server.jea_endpoint || 'SecurityAudit.ReadOnly';
                    }

                    document.getElementById('edit-server-description').value = server.description || '';
                    document.getElementById('edit-server-tags').value = server.tags || '';
                    document.getElementById('edit-server-path').value = server.remote_path || '/opt/security-audit-toolkit';

                    // Reset credential fields (don't pre-populate for security)
                    const authTypeSelect = document.getElementById('edit-server-auth-type');
                    if (authTypeSelect) {
                        authTypeSelect.value = ''; // Keep current
                    }
                    const passwordField = document.getElementById('edit-server-password');
                    if (passwordField) passwordField.value = '';
                    const keyPathField = document.getElementById('edit-server-key-path');
                    if (keyPathField) keyPathField.value = server.key_path || '';
                    const passphraseField = document.getElementById('edit-server-passphrase');
                    if (passphraseField) passphraseField.value = '';

                    // Show current auth info hint
                    if (server.has_password) {
                        authTypeSelect.querySelector('option[value=""]').textContent = '-- Keep Current (Password) --';
                    } else if (server.has_key) {
                        authTypeSelect.querySelector('option[value=""]').textContent = '-- Keep Current (SSH Key) --';
                    } else {
                        authTypeSelect.querySelector('option[value=""]').textContent = '-- Keep Current --';
                    }

                    // Hide credential fields initially
                    if (typeof toggleEditServerCredFields === 'function') {
                        toggleEditServerCredFields();
                    }

                    modal.style.display = 'flex';
                    if (currentUserRole === null) {
                        await fetchCurrentUserRole();
                    }
                    applyServerConnectionMethodEditPermission();
                } else {
                    alert('Failed to load server data: ' + (data.error || 'Unknown error'));
                }
            } else {
                const data = await response.json();
                alert('Failed to load server: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error loading server:', error);
            alert('Error loading server: ' + error.message);
        }
    }

    function closeEditServerModal() {
        const modal = document.getElementById('edit-server-modal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    async function handleEditServer(e) {
        e.preventDefault();

        const serverId = document.getElementById('edit-server-id').value;
        const name = document.getElementById('edit-server-name').value.trim();
        const hostname = document.getElementById('edit-server-host').value.trim();
        const port = parseInt(document.getElementById('edit-server-port').value) || 22;
        const username = document.getElementById('edit-server-user').value.trim();
        const osType = document.getElementById('edit-server-os').value;
        const connectionMethod = document.getElementById('edit-server-connection').value;
        const executionMode = document.getElementById('edit-server-execution-mode').value;
        const elevationMethod = document.getElementById('edit-server-elevation-method')?.value || 'sudo';
        const jeaEndpoint = document.getElementById('edit-server-jea-endpoint')?.value?.trim() || null;
        const description = document.getElementById('edit-server-description').value.trim();
        const tags = document.getElementById('edit-server-tags').value.trim();
        const remotePath = document.getElementById('edit-server-path').value.trim();

        if (!name || !hostname || !username) {
            alert('Please fill in all required fields');
            return;
        }

        const originalConnectionMethod = e.target.dataset.originalConnectionMethod || connectionMethod;
        if (!canManageConnectionMethod && connectionMethod !== originalConnectionMethod) {
            alert('Only Admin or SuperAdmin can change connection method for existing servers.');
            return;
        }

        const submitBtn = e.target.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '⏳ Saving...';
        submitBtn.disabled = true;

        try {
            const response = await fetch(`/api/servers/${serverId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    ...getHeaders()
                },
                body: JSON.stringify((() => {
                    const payload = {
                        name: name,
                        hostname: hostname,
                        port: port,
                        username: username,
                        os_type: osType,
                        connection_method: connectionMethod,
                        execution_mode: executionMode,
                        elevation_method: elevationMethod,
                        jea_endpoint: jeaEndpoint,
                        description: description,
                        tags: tags,
                        remote_path: remotePath
                    };

                    // Include credentials if auth type is selected (user wants to update)
                    const authType = document.getElementById('edit-server-auth-type')?.value;
                    if (authType) {
                        payload.auth_type = authType;
                        if (authType === 'password') {
                            const password = document.getElementById('edit-server-password')?.value;
                            if (password) {
                                payload.password = password;
                            }
                        } else if (authType === 'public_key') {
                            const keyPath = document.getElementById('edit-server-key-path')?.value;
                            if (keyPath) {
                                payload.key_path = keyPath;
                            }
                            const passphrase = document.getElementById('edit-server-passphrase')?.value;
                            if (passphrase) {
                                payload.key_passphrase = passphrase;
                            }
                        }
                    }

                    return payload;
                })())
            });

            const data = await response.json();

            if (response.ok && data.success) {
                closeEditServerModal();
                loadServers(); // Refresh the servers list
                // Dispatch custom event for other components (like wizard) to know server was updated
                window.dispatchEvent(new CustomEvent('serverUpdated', { detail: { serverId } }));
                if (typeof showToast === 'function') {
                    showToast('Server updated successfully', 'success');
                }
            } else {
                alert('Failed to update server: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error updating server:', error);
            alert('Error updating server: ' + error.message);
        } finally {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }

    // Setup edit server modal event listeners
    function setupEditServerModal() {
        const form = document.getElementById('edit-server-form');
        if (form) {
            form.addEventListener('submit', handleEditServer);
        }

        const cancelBtn = document.getElementById('cancel-edit-server');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', closeEditServerModal);
        }

        const closeBtn = document.getElementById('close-edit-server-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', closeEditServerModal);
        }

        // Close on outside click
        const modal = document.getElementById('edit-server-modal');
        if (modal) {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeEditServerModal();
                }
            });
        }

        // Close on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const modal = document.getElementById('edit-server-modal');
                if (modal && modal.style.display !== 'none') {
                    closeEditServerModal();
                }
            }
        });
    }

    // Call setup when DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupEditServerModal);
    } else {
        setupEditServerModal();
    }

    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Get OS icon based on os_type
    function getOsIcon(osType) {
        const icons = {
            linux: '🐧',
            windows: '🪟',
            hypervisor: '🖥️'
        };
        return icons[osType] || '🖥️';
    }

    // Get human-readable label for elevation method
    function getElevationLabel(method) {
        const labels = {
            // Linux
            sudo: 'sudo',
            sudo_nopasswd: 'sudo NOPASSWD',
            audit_wrapper: 'Audit Wrapper',
            // Windows
            runas: 'RunAs',
            jea: 'JEA Endpoint',
            admin: 'Administrator',
            // Common
            none: 'None'
        };
        return labels[method] || method || 'sudo';
    }

    // Update filtered servers list based on selected OS
    function updateFilteredServers() {
        const existingServersList = document.getElementById('existing-servers-list');
        const serverCountBadge = document.getElementById('filtered-server-count');
        const existingServersBox = document.getElementById('existing-servers-box');

        if (!existingServersList) return;

        // Ensure the box is visible
        if (existingServersBox) {
            existingServersBox.style.display = 'block';
        }

        const filteredServers = cachedServers.filter(s => s.os_type === currentOS);
        const count = filteredServers.length;

        if (serverCountBadge) {
            serverCountBadge.textContent = `${count} server${count !== 1 ? 's' : ''}`;
        }

        if (count === 0) {
            const osLabel = currentOS.charAt(0).toUpperCase() + currentOS.slice(1);
            existingServersList.className = 'existing-servers-list';
            existingServersList.innerHTML = `
                <div class="empty-state">
                    <span class="empty-state-icon">${getOsIcon(currentOS)}</span>
                    <strong>No ${osLabel} Servers</strong>
                    <p style="margin: 0.5rem 0 0; color: var(--text-muted);">Use the form below to configure your first ${osLabel} server.</p>
                </div>
            `;
            return;
        }

        // Render as compact list view
        const headerRow = `
            <div class="existing-servers-list-header">
                <span>Name</span>
                <span>Host</span>
                <span>Status</span>
                <span></span>
            </div>
        `;

        const rows = filteredServers.map(server => {
            const status = server.last_test_success === true ? 'online' :
                          server.last_test_success === false ? 'offline' : 'untested';
            const statusLabel = status === 'online' ? 'Online' :
                               status === 'offline' ? 'Offline' : 'Untested';

            return `
                <div class="server-list-row" data-server-id="${server.id}">
                    <div class="server-list-name-col">
                        <span class="server-list-icon">${getOsIcon(server.os_type)}</span>
                        <span class="server-list-name">${escapeHtml(server.name)}</span>
                    </div>
                    <div class="server-list-host">${escapeHtml(server.hostname)}:${server.port || 22}</div>
                    <div class="server-list-status">
                        <span class="status-dot ${status}"></span>
                        <span>${statusLabel}</span>
                    </div>
                    <div class="server-list-actions">
                        <button class="btn-icon" onclick="connectTab.quickTestServer(${server.id})" title="Test Connection">🔍</button>
                        <button class="btn-icon" onclick="openEditServerModal(${server.id})" title="Edit">✏️</button>
                    </div>
                </div>
            `;
        }).join('');

        existingServersList.className = 'existing-servers-list-view';
        existingServersList.innerHTML = headerRow + rows;
    }

    // Quick test a server from the filtered list
    async function quickTestServer(serverId) {
        const serverItem = document.querySelector(`.server-list-row[data-server-id="${serverId}"]`);
        if (serverItem) {
            serverItem.classList.add('testing');
        }

        try {
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {};
            if (apiKey) {
                headers['X-API-Key'] = apiKey;
            }

            const response = await fetch(`/api/servers/${serverId}/test`, {
                method: 'POST',
                credentials: 'include',
                headers
            });
            const data = await response.json();

            if (serverItem) {
                serverItem.classList.remove('testing');
                serverItem.classList.add(data.success ? 'test-success' : 'test-failed');
                setTimeout(() => {
                    serverItem.classList.remove('test-success', 'test-failed');
                }, 3000);
            }

            if (data.success) {
                alert('✅ Connection successful!');
            } else {
                alert('❌ Connection failed: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            if (serverItem) {
                serverItem.classList.remove('testing');
                serverItem.classList.add('test-failed');
                setTimeout(() => serverItem.classList.remove('test-failed'), 3000);
            }
            alert('Error testing server: ' + error.message);
        }
    }

    // Load server details into form for editing
    function loadServerToForm(serverId) {
        const server = cachedServers.find(s => s.id === serverId);
        if (!server) {
            alert('Server not found');
            return;
        }

        // Set OS type
        const osRadio = document.querySelector(`input[name="os-type"][value="${server.os_type}"]`);
        if (osRadio) {
            osRadio.checked = true;
            handleOSChange();
        }

        // Set distribution if available
        setTimeout(() => {
            const distroSelect = document.getElementById('connect-distro');
            if (distroSelect && server.distro) {
                distroSelect.value = server.distro;
                handleDistroChange();
            }

            // Set version if available
            setTimeout(() => {
                const versionSelect = document.getElementById('connect-version');
                if (versionSelect && server.version) {
                    versionSelect.value = server.version;
                }
            }, 100);
        }, 100);

        // Fill in server details
        document.getElementById('connect-name').value = server.name || '';
        document.getElementById('connect-hostname').value = server.hostname || '';
        document.getElementById('connect-port').value = server.port || 22;
        document.getElementById('connect-description').value = server.description || '';
        document.getElementById('connect-username').value = server.username || '';

        // Set auth method
        if (server.auth_method) {
            const authRadio = document.querySelector(`input[name="auth-method"][value="${server.auth_method}"]`);
            if (authRadio) {
                authRadio.checked = true;
                handleAuthMethodChange();
            }
        }

        // Set execution mode
        const execMode = server.execution_mode || 'stream';
        const execRadio = document.querySelector(`input[name="execution-mode"][value="${execMode}"]`);
        if (execRadio) {
            execRadio.checked = true;
            handleExecutionModeChange();
        }

        // Scroll to form
        document.getElementById('step-details')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // Update Connect panel stats
    function updateConnectStats(servers) {
        const total = servers.length;
        const linux = servers.filter(s => s.os_type === 'linux').length;
        const windows = servers.filter(s => s.os_type === 'windows').length;
        const hypervisor = servers.filter(s => s.os_type === 'hypervisor').length;
        const online = servers.filter(s => s.status === 'online' || s.last_test_success === true).length;

        // Update stat displays
        const totalStat = document.getElementById('connect-total-servers');
        const linuxStat = document.getElementById('connect-linux-count');
        const windowsStat = document.getElementById('connect-windows-count');
        const hypervisorStat = document.getElementById('connect-hypervisor-count');
        const onlineStat = document.getElementById('connect-online-count');

        if (totalStat) totalStat.textContent = total;
        if (linuxStat) linuxStat.textContent = linux;
        if (windowsStat) windowsStat.textContent = windows;
        if (hypervisorStat) hypervisorStat.textContent = hypervisor;
        if (onlineStat) onlineStat.textContent = online;
    }

    // =========================================================================
    // Elevation Method Helpers
    // =========================================================================

    /**
     * Linux elevation options
     */
    const linuxElevationOptions = [
        { value: 'sudo', label: 'sudo (standard) - Requires sudo password' },
        { value: 'sudo_nopasswd', label: 'sudo NOPASSWD (automation) - Passwordless sudo' },
        { value: 'audit_wrapper', label: 'Audit Wrapper (least-privilege) - Restricted commands only' },
        { value: 'none', label: 'None - Run as connected user (limited audits)' }
    ];

    /**
     * Windows elevation options
     */
    const windowsElevationOptions = [
        { value: 'runas', label: 'RunAs (standard) - Windows elevation prompt' },
        { value: 'jea', label: 'JEA Endpoint (least-privilege) - Constrained PowerShell' },
        { value: 'admin', label: 'Administrator (direct) - Run as admin user' },
        { value: 'none', label: 'None - Run as connected user (limited audits)' }
    ];

    /**
     * Update elevation method dropdown options based on OS type
     * @param {string} selectId - ID of the elevation method select element
     * @param {string} osType - 'linux' or 'windows'
     */
    function updateElevationOptions(selectId, osType) {
        const select = document.getElementById(selectId);
        if (!select) return;

        const options = osType === 'windows' ? windowsElevationOptions : linuxElevationOptions;
        const currentValue = select.value;

        // Clear and rebuild options
        select.innerHTML = '';
        options.forEach(opt => {
            const option = document.createElement('option');
            option.value = opt.value;
            option.textContent = opt.label;
            select.appendChild(option);
        });

        // Try to restore previous value if still valid
        const validValues = options.map(o => o.value);
        if (validValues.includes(currentValue)) {
            select.value = currentValue;
        } else {
            // Set default based on OS
            select.value = osType === 'windows' ? 'runas' : 'sudo';
        }

        // Update JEA endpoint visibility
        const prefix = selectId.includes('edit') ? 'edit' : '';
        toggleJeaEndpointField(prefix);
    }

    /**
     * Toggle JEA endpoint field visibility based on elevation method
     * @param {string} prefix - 'edit' for edit modal, empty for add modal
     */
    function toggleJeaEndpointField(prefix) {
        const elevationSelect = document.getElementById(prefix ? `${prefix}-server-elevation-method` : 'server-elevation-method');
        const jeaGroup = document.getElementById(prefix ? `${prefix}-jea-endpoint-group` : 'jea-endpoint-group');

        if (!elevationSelect || !jeaGroup) return;

        if (elevationSelect.value === 'jea') {
            jeaGroup.classList.remove('d-none');
        } else {
            jeaGroup.classList.add('d-none');
        }
    }

    /**
     * Handle OS type change - update elevation options and protocol info
     * @param {string} prefix - 'edit' for edit modal, empty for add modal
     */
    function handleOsTypeChange(prefix) {
        const osSelect = document.getElementById(prefix ? `${prefix}-server-os` : 'server-os');
        if (!osSelect) return;

        const osType = osSelect.value;
        const elevationSelectId = prefix ? `${prefix}-server-elevation-method` : 'server-elevation-method';

        updateElevationOptions(elevationSelectId, osType);
    }

    /**
     * Handle elevation method change - toggle JEA endpoint visibility
     * @param {string} prefix - 'edit' for edit modal, empty for add modal
     */
    function handleElevationMethodChange(prefix) {
        toggleJeaEndpointField(prefix);
    }

    // Expose functions globally for onclick handlers
    window.connectTab = {
        testServer,
        deleteServer,
        editServer,
        loadServers,
        quickTestServer,
        loadServerToForm,
        openEditServerModal,
        filterServerList,
        changeServerConnectionMethod
    };

    // Global functions for HTML onchange handlers
    window.updateElevationOptions = updateElevationOptions;
    window.toggleJeaEndpointField = toggleJeaEndpointField;
    window.handleOsTypeChange = handleOsTypeChange;
    window.handleElevationMethodChange = handleElevationMethodChange;
    window.openEditServerModal = openEditServerModal;

})();
