/**
 * Dashboard page JavaScript
 * Handles dashboard data loading and refresh
 */

// API key from localStorage
var API_KEY = localStorage.getItem('api_key') || '';

/**
 * Make API call with authentication
 * @param {string} endpoint - API endpoint to call
 * @returns {Promise<Object|null>} - Response data or null on error
 */
async function apiCall(endpoint) {
    var headers = { 'Content-Type': 'application/json' };
    if (API_KEY) headers['X-API-Key'] = API_KEY;

    try {
        var response = await fetch(endpoint, { headers: headers, credentials: 'include' });
        if (!response.ok) throw new Error('HTTP ' + response.status);
        return await response.json();
    } catch (error) {
        console.error('API call failed: ' + endpoint, error);
        return null;
    }
}

/**
 * Refresh all dashboard data
 */
async function refreshDashboard() {
    document.getElementById('last-refresh').textContent = new Date().toLocaleTimeString();
    await Promise.all([
        refreshHealth(),
        refreshSummary(),
        refreshStorageUsage(),
        refreshExecutions(),
        refreshServers()
    ]);
}

/**
 * Refresh health status panel
 */
async function refreshHealth() {
    var container = document.getElementById('health-content');
    container.innerHTML = '<div class="health-loading">Loading...</div>';

    var data = await apiCall('/health');
    if (!data) {
        container.innerHTML = '<div class="health-error">Failed to load health data</div>';
        return;
    }

    var statusClass = data.status === 'healthy' ? 'healthy' : 'unhealthy';
    var html = '<div class="health-overall ' + statusClass + '">' +
        '<span class="health-status">' + (data.status === 'healthy' ? '✅' : '⚠️') + '</span>' +
        '<span class="health-label">Overall: ' + data.status + '</span>' +
        '</div><div class="health-items">';

    // Dependencies
    if (data.dependencies) {
        for (var name in data.dependencies) {
            if (data.dependencies.hasOwnProperty(name)) {
                var dep = data.dependencies[name];
                var depStatus = dep.available || dep.status === 'healthy' ? 'healthy' : 'unhealthy';
                html += '<div class="health-item ' + depStatus + '">' +
                    '<span class="health-icon">' + (depStatus === 'healthy' ? '✅' : '❌') + '</span>' +
                    '<span class="health-name">' + name + '</span>' +
                    '<span class="health-detail">' + (dep.latency_ms ? dep.latency_ms + 'ms' : dep.status || 'N/A') + '</span>' +
                    '</div>';
            }
        }
    }

    html += '</div>';
    container.innerHTML = html;
}

/**
 * Refresh summary statistics
 */
async function refreshSummary() {
    var data = await apiCall('/api/dashboard/summary');
    if (!data || !data.success) return;

    var summary = data.summary || {};
    document.getElementById('total-servers').textContent = summary.total_servers || 0;
    document.getElementById('total-audits').textContent = summary.total_audits || 0;
    document.getElementById('total-pass').textContent = summary.total_pass || 0;
    document.getElementById('total-warn').textContent = summary.total_warn || 0;
    document.getElementById('total-fail').textContent = summary.total_fail || 0;

    // Update compliance score
    var total = (summary.total_pass || 0) + (summary.total_warn || 0) + (summary.total_fail || 0);
    if (total > 0) {
        var score = Math.round((summary.total_pass / total) * 100);
        document.getElementById('compliance-score').textContent = score + '%';
        document.getElementById('pass-rate').textContent = Math.round((summary.total_pass / total) * 100) + '%';
        document.getElementById('warn-rate').textContent = Math.round((summary.total_warn / total) * 100) + '%';
        document.getElementById('fail-rate').textContent = Math.round((summary.total_fail / total) * 100) + '%';

        // Update score ring
        var circle = document.getElementById('score-circle');
        var circumference = 2 * Math.PI * 45;
        var offset = circumference - (score / 100) * circumference;
        circle.style.strokeDasharray = circumference;
        circle.style.strokeDashoffset = offset;
    }

    // Update distribution chart
    updateDistributionChart(summary.audit_by_domain || {});
}

/**
 * Refresh storage usage summary widget
 */
async function refreshStorageUsage() {
    var auditStorageEl = document.getElementById('total-storage-used');
    var diskFreeEl = document.getElementById('total-disk-free');
    var auditSubstatusEl = document.getElementById('storage-usage-substatus');
    var diskStatusEl = document.getElementById('storage-pressure-status');
    var diskRowEl = document.getElementById('row-disk');

    if (!auditStorageEl || !diskFreeEl) return;

    if (diskRowEl) {
        diskRowEl.classList.remove('warning');
        diskRowEl.classList.remove('critical');
    }

    var responses = await Promise.all([
        apiCall('/api/admin/storage/stats'),
        apiCall('/api/dashboard/storage-pressure')
    ]);

    var data = responses[0];
    var pressureData = responses[1];

    // Audit Data Storage Row
    if (!data || !data.success || !data.stats) {
        auditStorageEl.textContent = 'N/A';
        auditStorageEl.title = 'Storage stats unavailable for current user/session';
        if (auditSubstatusEl) {
            auditSubstatusEl.textContent = 'Unavailable';
        }
    } else {
        var totalSize = Number(data.stats.total_size || 0);
        var totalFiles = Number(data.stats.total_files || 0);
        auditStorageEl.textContent = formatDashboardBytes(totalSize);
        auditStorageEl.title = totalFiles.toLocaleString() + ' files';
        if (auditSubstatusEl) {
            auditSubstatusEl.textContent = totalFiles.toLocaleString() + ' audit files';
        }
    }

    // System Disk Free Row
    if (!pressureData || !pressureData.success || !pressureData.storage_pressure) {
        diskFreeEl.textContent = 'N/A';
        if (diskStatusEl) {
            diskStatusEl.textContent = 'Threshold telemetry unavailable';
        }
        return;
    }

    var storagePressure = pressureData.storage_pressure;
    var overallLevel = (storagePressure.overall_level || '').toLowerCase();
    var diskWatermark = storagePressure.disk_watermark || {};
    var dbUsage = storagePressure.database || {};
    var standalone = (storagePressure.agent_result_files || {}).standalone || {};
    var managedFallback = (storagePressure.agent_result_files || {}).managed_fallback || {};

    var diskFreePct = diskWatermark.free_pct != null ? diskWatermark.free_pct : 'N/A';
    var diskFreeMb = diskWatermark.free_mb != null ? diskWatermark.free_mb : 'N/A';
    diskFreeEl.textContent = typeof diskFreePct === 'number' ? diskFreePct + '%' : diskFreePct;
    diskFreeEl.title = diskFreeMb + ' MB free';

    var pressureReasons = [];
    if (diskWatermark.ingest_blocked) {
        pressureReasons.push('Ingest blocked by low disk watermark');
    } else if (diskWatermark.level === 'warning') {
        pressureReasons.push('Disk free space approaching guardrail');
    } else if (diskWatermark.level === 'critical') {
        pressureReasons.push('CRITICAL: Disk space critical');
    }

    if (dbUsage.level === 'critical' || dbUsage.level === 'warning') {
        var dbPct = typeof dbUsage.usage_pct === 'number' ? Math.round(dbUsage.usage_pct) + '%' : 'N/A';
        pressureReasons.push('Database retention: ' + dbPct);
    }

    if ((standalone.hosts_warning_or_higher || 0) > 0) {
        pressureReasons.push(standalone.hosts_warning_or_higher + ' standalone host(s) near file cap');
    }

    if ((managedFallback.hosts_warning_or_higher || 0) > 0) {
        pressureReasons.push(managedFallback.hosts_warning_or_higher + ' managed host(s) near file cap');
    }

    if (diskRowEl) {
        if (overallLevel === 'critical') {
            diskRowEl.classList.add('critical');
        } else if (overallLevel === 'warning') {
            diskRowEl.classList.add('warning');
        }
    }

    if (diskStatusEl) {
        if (overallLevel === 'critical') {
            diskStatusEl.textContent = pressureReasons.length > 0
                ? 'ALERT: ' + pressureReasons[0]
                : 'ALERT: Storage guardrail breached';
        } else if (overallLevel === 'warning') {
            diskStatusEl.textContent = pressureReasons.length > 0
                ? 'Warning: ' + pressureReasons[0]
                : 'Warning: Disk space approaching guardrail';
        } else {
            diskStatusEl.textContent = 'OK: Healthy';
        }
    }

    var tooltipParts = [
        'Disk free: ' + diskFreeMb + ' MB (' + diskFreePct + '%)',
        'DB usage: ' + (dbUsage.usage_pct != null ? Math.round(dbUsage.usage_pct) + '%' : 'N/A'),
        'DB engine: ' + (dbUsage.db_engine || 'unknown'),
        'DB size: ' + (dbUsage.physical_size_bytes != null ? formatDashboardBytes(Number(dbUsage.physical_size_bytes)) : 'N/A')
    ];
    if (Array.isArray(dbUsage.largest_tables) && dbUsage.largest_tables.length > 0) {
        var largest = dbUsage.largest_tables[0] || {};
        if (largest.table_name) {
            tooltipParts.push(
                'Largest table: ' + largest.table_name + ' (' +
                formatDashboardBytes(Number(largest.size_bytes || 0)) + ')'
            );
        }
    }
    if (pressureReasons.length > 0) {
        tooltipParts = tooltipParts.concat(pressureReasons);
    }
    diskFreeEl.title = tooltipParts.join(' | ');
}

/**
 * Update the audit distribution chart
 * @param {Object} domains - Domain counts object
 */
function updateDistributionChart(domains) {
    var container = document.getElementById('distribution-chart');
    var legend = document.getElementById('distribution-legend');

    var colors = {
        platform: '#4a90d9',
        network: '#50c878',
        web: '#f39c12',
        data: '#9b59b6',
        apps: '#e74c3c',
        storage: '#1abc9c',
        automation: '#34495e'
    };

    // Create bar chart
    var chartHtml = '<div class="bar-chart">';
    var legendHtml = '';
    var total = Object.values(domains).reduce(function(a, b) { return a + b; }, 0) || 1;

    for (var domain in domains) {
        if (domains.hasOwnProperty(domain)) {
            var count = domains[domain];
            var percent = Math.round((count / total) * 100);
            var color = colors[domain] || '#666';
            chartHtml += '<div class="bar-item" style="width: ' + percent + '%; background: ' + color + ';" title="' + domain + ': ' + count + '"></div>';
            legendHtml += '<div class="legend-item">' +
                '<span class="legend-color" style="background: ' + color + ';"></span>' +
                '<span class="legend-label">' + domain + '</span>' +
                '<span class="legend-value">' + count + '</span>' +
                '</div>';
        }
    }
    chartHtml += '</div>';

    container.innerHTML = chartHtml || '<div class="no-data">No audit data</div>';
    legend.innerHTML = legendHtml || '';
}

// Cached executions for search filtering
var _executions_cache = [];

/**
 * Toggle a collapsible execution group
 */
function toggleExecGroup(key) {
    var body = document.getElementById('exec-body-' + key);
    var chevron = document.getElementById('exec-chevron-' + key);
    var header = body.previousElementSibling;
    var isCollapsed = body.classList.contains('collapsed');
    if (isCollapsed) {
        body.classList.remove('collapsed');
        chevron.textContent = '▾';
        header.setAttribute('aria-expanded', 'true');
    } else {
        body.classList.add('collapsed');
        chevron.textContent = '▸';
        header.setAttribute('aria-expanded', 'false');
    }
}

/**
 * Render filtered executions into the two grouped tables
 */
function renderExecutions(filter) {
    var term = (filter || '').toLowerCase().trim();
    var all = _executions_cache;

    var filtered = term ? all.filter(function(e) {
        return (e.server_name || '').toLowerCase().includes(term) ||
               (e.audit_name || '').toLowerCase().includes(term) ||
               (e.status || '').toLowerCase().includes(term);
    }) : all;

    var failures = filtered.filter(function(e) { return e.status === 'failure' || e.status === 'failed'; });
    var successes = filtered.filter(function(e) { return e.status === 'success'; });

    document.getElementById('exec-count-fail').textContent = failures.length;
    document.getElementById('exec-count-success').textContent = successes.length;

    function buildRows(list) {
        if (list.length === 0) return '<tr class="empty-row"><td colspan="4">No results</td></tr>';
        return list.map(function(exec) {
            var time = new Date(exec.executed_at).toLocaleString();
            var score = exec.summary ? formatScore(exec.summary) : '-';
            return '<tr>' +
                '<td>' + time + '</td>' +
                '<td>' + (exec.server_name || 'Unknown') + '</td>' +
                '<td>' + (exec.audit_name || 'Unknown') + '</td>' +
                '<td>' + score + '</td>' +
                '</tr>';
        }).join('');
    }

    document.getElementById('executions-tbody-fail').innerHTML = buildRows(failures);
    document.getElementById('executions-tbody-success').innerHTML = buildRows(successes);
}

/**
 * Refresh recent executions table
 */
async function refreshExecutions() {
    var tbodyFail = document.getElementById('executions-tbody-fail');
    var tbodySuccess = document.getElementById('executions-tbody-success');
    tbodyFail.innerHTML = '<tr class="loading-row"><td colspan="4">Loading…</td></tr>';
    tbodySuccess.innerHTML = '<tr class="loading-row"><td colspan="4">Loading…</td></tr>';

    var data = await apiCall('/api/dashboard/recent-executions?limit=50');
    if (!data || !data.success) {
        tbodyFail.innerHTML = '<tr class="error-row"><td colspan="4">Failed to load</td></tr>';
        tbodySuccess.innerHTML = '';
        return;
    }

    _executions_cache = data.executions || [];

    // Wire up search box (only once)
    var searchEl = document.getElementById('executions-search');
    if (searchEl && !searchEl.dataset.wired) {
        searchEl.dataset.wired = '1';
        searchEl.addEventListener('input', function() {
            renderExecutions(this.value);
        });
    }

    renderExecutions(searchEl ? searchEl.value : '');
}

/**
 * Format execution score summary
 * @param {Object|string} summary - Summary object or JSON string
 * @returns {string} - Formatted score string
 */
function formatScore(summary) {
    try {
        var s = typeof summary === 'string' ? JSON.parse(summary) : summary;
        return (s.pass || 0) + '/' + (s.warn || 0) + '/' + (s.fail || 0);
    } catch (e) {
        return '-';
    }
}

/**
 * Format bytes to human readable value
 * @param {number} bytes
 * @returns {string}
 */
function formatDashboardBytes(bytes) {
    if (!bytes || bytes <= 0) return '0 B';
    var unit = 1024;
    var sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    var sizeIndex = Math.floor(Math.log(bytes) / Math.log(unit));
    var value = bytes / Math.pow(unit, sizeIndex);
    return value.toFixed(sizeIndex === 0 ? 0 : 1) + ' ' + sizes[sizeIndex];
}

/**
 * Refresh servers list
 */
async function refreshServers() {
    var container = document.getElementById('servers-list');
    container.innerHTML = '<div class="loading-item">Loading...</div>';

    var data = await apiCall('/api/servers');
    if (!data || !data.servers) {
        container.innerHTML = '<div class="error-item">Failed to load servers</div>';
        return;
    }

    if (data.servers.length === 0) {
        container.innerHTML = '<div class="empty-item">No servers configured</div>';
        return;
    }

    var html = '';
    var displayCount = Math.min(data.servers.length, 8);
    for (var i = 0; i < displayCount; i++) {
        var server = data.servers[i];
        var lastAudit = server.last_audit_at ?
            new Date(server.last_audit_at).toLocaleDateString() : 'Never';
        html += '<div class="server-item">' +
            '<span class="server-icon">🖥️</span>' +
            '<div class="server-info">' +
            '<span class="server-name">' + server.name + '</span>' +
            '<span class="server-host">' + server.hostname + '</span>' +
            '</div>' +
            '<span class="server-last-audit">Last: ' + lastAudit + '</span>' +
            '</div>';
    }
    if (data.servers.length > 8) {
        html += '<div class="more-servers">+' + (data.servers.length - 8) + ' more...</div>';
    }
    container.innerHTML = html;
}

// Initialize dashboard on page load
document.addEventListener('DOMContentLoaded', function() {
    refreshDashboard();
    // Auto-refresh every 60 seconds
    setInterval(refreshDashboard, 60000);

    // Button event listeners
    var refreshHealthBtn = document.getElementById('refresh-health-btn');
    if (refreshHealthBtn) {
        refreshHealthBtn.addEventListener('click', refreshHealth);
    }

    var refreshDashboardBtn = document.getElementById('refresh-dashboard-btn');
    if (refreshDashboardBtn) {
        refreshDashboardBtn.addEventListener('click', refreshDashboard);
    }

    var runBtn = document.getElementById('quick-action-run-btn');
    if (runBtn) {
        runBtn.addEventListener('click', function() {
            var selected = document.querySelector('input[name="quick-action"]:checked');
            if (!selected) return;
            var routes = {
                'run-audit':       '/console#audits',
                'view-reports':    '/console#reports',
                'software-report': '/asset-discovery/software-report/latest',
                'schedule-audit':  '/console#schedule',
                'api-docs':        '/api/docs'
            };
            if (selected.value === 'refresh') {
                refreshDashboard();
            } else if (routes[selected.value]) {
                window.location.href = routes[selected.value];
            }
        });
    }
});
