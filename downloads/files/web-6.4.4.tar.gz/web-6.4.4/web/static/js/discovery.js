/**
 * Discovery Tab JavaScript
 * Handles server selection and system discovery
 */

(function() {
    'use strict';

    // State
    let servers = [];
    let selectedServers = new Set();
    let currentFilter = 'all';
    let discoveryResults = [];
    let isDiscoveryRunning = false;
    let serverSearchFilter = '';

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        initDiscoveryTab();
    });

    function initDiscoveryTab() {
        // Check if discovery tab elements exist
        const serverList = document.getElementById('discovery-server-list');
        if (!serverList) return;

        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', handleFilterChange);
        });

        // Selection buttons
        document.getElementById('select-all-servers')?.addEventListener('click', selectAllServers);
        document.getElementById('deselect-all-servers')?.addEventListener('click', deselectAllServers);
        document.getElementById('refresh-server-list')?.addEventListener('click', loadServers);

        // Run discovery button
        document.getElementById('run-discovery')?.addEventListener('click', runDiscovery);

        // Deploy fleet agent button
        document.getElementById('deploy-fleet-agent-btn')?.addEventListener('click', deployFleetAgent);

        // Clear output
        document.getElementById('clear-discovery-output')?.addEventListener('click', clearResults);

        // Toggle raw output
        document.getElementById('toggle-raw-output')?.addEventListener('click', toggleRawOutput);

        // Parallel slider
        const parallelSlider = document.getElementById('discovery-parallel');
        if (parallelSlider) {
            parallelSlider.addEventListener('input', function() {
                document.getElementById('parallel-value').textContent = this.value;
            });
        }

        // Limit slider
        const limitSlider = document.getElementById('discovery-limit');
        if (limitSlider) {
            limitSlider.addEventListener('input', function() {
                document.getElementById('limit-value').textContent = this.value;
            });
        }

        // Lightweight mode disables scope options
        const lightweightCheckbox = document.getElementById('discover-lightweight');
        if (lightweightCheckbox) {
            lightweightCheckbox.addEventListener('change', function() {
                const scopeCheckboxes = ['discover-packages', 'discover-services', 'discover-updates', 'discover-security'];
                scopeCheckboxes.forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.disabled = this.checked;
                });
            });
        }

        // Export buttons
        document.getElementById('export-discovery-json')?.addEventListener('click', exportJSON);
        document.getElementById('export-discovery-csv')?.addEventListener('click', exportCSV);

        // Load servers on init
        loadServers();
    }

    async function loadServers() {
        const serverList = document.getElementById('discovery-server-list');
        const noServersMsg = document.getElementById('no-servers-message');

        serverList.innerHTML = '<p class="loading">Loading servers from database...</p>';
        noServersMsg.style.display = 'none';

        try {
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {};
            if (apiKey) {
                headers['X-API-Key'] = apiKey;
            }

            const response = await fetch('/api/servers', { headers, credentials: 'include' });
            const data = await response.json();

            if (data.servers && data.servers.length > 0) {
                servers = data.servers;
                renderServerList();
            } else {
                servers = [];
                serverList.innerHTML = '';
                noServersMsg.style.display = 'block';
            }
        } catch (error) {
            serverList.innerHTML = `<p class="error-text">Error loading servers: ${error.message}</p>`;
            console.error('Error loading servers:', error);
        }

        updateSelectedCount();
        updateRunButton();
    }

    function renderServerList() {
        const serverList = document.getElementById('discovery-server-list');

        if (servers.length === 0) {
            serverList.innerHTML = '';
            document.getElementById('no-servers-message').style.display = 'block';
            return;
        }

        // Apply both OS filter and search filter
        let filteredServers = servers;
        if (currentFilter !== 'all') {
            filteredServers = filteredServers.filter(s => (s.os_type || 'linux') === currentFilter);
        }
        if (serverSearchFilter) {
            const search = serverSearchFilter.toLowerCase();
            filteredServers = filteredServers.filter(s =>
                (s.name || '').toLowerCase().includes(search) ||
                (s.hostname || '').toLowerCase().includes(search) ||
                (s.username || '').toLowerCase().includes(search) ||
                (s.os_type || '').toLowerCase().includes(search) ||
                (s.description || '').toLowerCase().includes(search)
            );
        }

        if (filteredServers.length === 0) {
            serverList.innerHTML = '<p class="info-text">No servers match your filters.</p>';
            return;
        }

        // Build compact list header
        const headerRow = `
            <div class="discovery-server-list-header">
                <span class="discovery-col-checkbox"><input type="checkbox" id="discovery-select-all" title="Select All"></span>
                <span>Name</span>
                <span>Host</span>
                <span>User</span>
                <span>Status</span>
                <span>Description</span>
            </div>
        `;

        const rows = filteredServers.map(server => {
            const osType = server.os_type || 'linux';
            const isSelected = selectedServers.has(server.id);
            const osIcon = osType === 'windows' ? '🪟' : (osType === 'hypervisor' ? '🖥️' : '🐧');
            const status = server.last_test_success === true ? 'online' :
                          server.last_test_success === false ? 'offline' : 'untested';
            const statusLabel = status === 'online' ? 'Online' :
                               status === 'offline' ? 'Offline' : 'Untested';

            return `
                <div class="discovery-server-row ${isSelected ? 'selected' : ''}" data-server-id="${server.id}" data-os-type="${osType}">
                    <div class="discovery-col-checkbox">
                        <input type="checkbox" class="server-row-checkbox" ${isSelected ? 'checked' : ''}>
                    </div>
                    <div class="discovery-server-name-col">
                        <span class="discovery-server-icon">${osIcon}</span>
                        <span class="discovery-server-name">${escapeHtml(server.name)}</span>
                    </div>
                    <div class="discovery-server-host">${escapeHtml(server.hostname)}:${server.port || 22}</div>
                    <div class="discovery-server-user">${escapeHtml(server.username || 'N/A')}</div>
                    <div class="discovery-server-status">
                        <span class="status-dot ${status}"></span>
                        <span>${statusLabel}</span>
                    </div>
                    <div class="discovery-server-desc">${server.description ? escapeHtml(server.description) : '—'}</div>
                </div>
            `;
        }).join('');

        serverList.innerHTML = headerRow + rows;

        // Add select-all handler
        const selectAllCheckbox = serverList.querySelector('#discovery-select-all');
        if (selectAllCheckbox) {
            // Reflect current state
            const visibleIds = filteredServers.map(s => s.id);
            const allVisibleSelected = visibleIds.every(id => selectedServers.has(id));
            selectAllCheckbox.checked = allVisibleSelected && visibleIds.length > 0;

            selectAllCheckbox.addEventListener('change', (e) => {
                const visibleRows = serverList.querySelectorAll('.discovery-server-row');
                visibleRows.forEach(row => {
                    const serverId = parseInt(row.dataset.serverId, 10);
                    const checkbox = row.querySelector('.server-row-checkbox');
                    checkbox.checked = e.target.checked;
                    if (e.target.checked) {
                        selectedServers.add(serverId);
                        row.classList.add('selected');
                    } else {
                        selectedServers.delete(serverId);
                        row.classList.remove('selected');
                    }
                });
                updateSelectedCount();
                updateRunButton();
            });
        }

        // Add row click handlers
        serverList.querySelectorAll('.discovery-server-row').forEach(row => {
            row.addEventListener('click', (e) => {
                // Skip if clicking on checkbox directly
                if (e.target.type === 'checkbox') {
                    const serverId = parseInt(row.dataset.serverId, 10);
                    if (e.target.checked) {
                        selectedServers.add(serverId);
                        row.classList.add('selected');
                    } else {
                        selectedServers.delete(serverId);
                        row.classList.remove('selected');
                    }
                    updateSelectedCount();
                    updateRunButton();
                    return;
                }

                discoveryTab.toggleServer(parseInt(row.dataset.serverId, 10));
            });
        });
    }

    function filterServerSearch(searchTerm) {
        serverSearchFilter = searchTerm;
        renderServerList();
    }

    function handleFilterChange(e) {
        // Update active button
        document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');

        currentFilter = e.target.dataset.filter;

        // Re-render list with new filter
        renderServerList();

        updateSelectedCount();
    }

    function toggleServer(serverId) {
        if (selectedServers.has(serverId)) {
            selectedServers.delete(serverId);
        } else {
            selectedServers.add(serverId);
        }

        // Update UI
        const row = document.querySelector(`.discovery-server-row[data-server-id="${serverId}"]`);
        const checkbox = row?.querySelector('.server-row-checkbox');

        if (row) {
            row.classList.toggle('selected', selectedServers.has(serverId));
        }
        if (checkbox) {
            checkbox.checked = selectedServers.has(serverId);
        }

        updateSelectedCount();
        updateRunButton();
    }

    function selectAllServers() {
        const visibleRows = document.querySelectorAll('.discovery-server-row:not(.hidden)');
        visibleRows.forEach(row => {
            const serverId = parseInt(row.dataset.serverId);
            selectedServers.add(serverId);
            row.classList.add('selected');
            const checkbox = row.querySelector('.server-row-checkbox');
            if (checkbox) checkbox.checked = true;
        });

        updateSelectedCount();
        updateRunButton();
    }

    function deselectAllServers() {
        selectedServers.clear();

        document.querySelectorAll('.discovery-server-row').forEach(row => {
            row.classList.remove('selected');
            const checkbox = row.querySelector('.server-row-checkbox');
            if (checkbox) checkbox.checked = false;
        });

        updateSelectedCount();
        updateRunButton();
    }

    function updateSelectedCount() {
        const countEl = document.getElementById('selected-count');
        const countValue = document.getElementById('selected-server-count');

        if (selectedServers.size > 0) {
            countEl.style.display = 'block';
            countValue.textContent = selectedServers.size;
        } else {
            countEl.style.display = 'none';
        }
    }

    function updateRunButton() {
        const runBtn = document.getElementById('run-discovery');
        if (runBtn) {
            runBtn.disabled = selectedServers.size === 0 || isDiscoveryRunning;
            runBtn.textContent = isDiscoveryRunning
                ? '⏳ Discovery Running...'
                : `🔍 Run Discovery on ${selectedServers.size} Server(s)`;
        }

        // Also update fleet agent deploy button
        const deployAgentBtn = document.getElementById('deploy-fleet-agent-btn');
        if (deployAgentBtn) {
            deployAgentBtn.disabled = selectedServers.size === 0;
        }
    }

    async function runDiscovery() {
        if (selectedServers.size === 0) {
            alert('Please select at least one server');
            return;
        }

        isDiscoveryRunning = true;
        updateRunButton();

        // Get options
        const format = document.getElementById('discovery-format').value;
        const discoverPackages = document.getElementById('discover-packages')?.checked ?? true;
        const discoverServices = document.getElementById('discover-services')?.checked ?? true;
        const discoverUpdates = document.getElementById('discover-updates')?.checked ?? true;
        const discoverSecurity = document.getElementById('discover-security')?.checked ?? false;
        const parallelCount = parseInt(document.getElementById('discovery-parallel')?.value || 5);

        // Performance options
        const lightweight = document.getElementById('discover-lightweight')?.checked ?? false;
        const throttle = document.getElementById('discover-throttle')?.checked ?? false;
        const limit = parseInt(document.getElementById('discovery-limit')?.value || 100);

        // Show progress
        const progressDiv = document.getElementById('discovery-progress');
        const progressBar = document.getElementById('discovery-progress-bar');
        const progressText = document.getElementById('discovery-progress-text');
        const progressCount = document.getElementById('discovery-progress-count');
        const currentServerEl = document.getElementById('discovery-current-server');

        progressDiv.style.display = 'block';
        progressBar.style.width = '0%';
        progressText.textContent = 'Starting discovery...';
        progressCount.textContent = `0 / ${selectedServers.size}`;

        // Clear previous results
        discoveryResults = [];
        document.getElementById('discovery-server-results').innerHTML = '';
        document.getElementById('discovery-results-summary').style.display = 'none';

        // Get selected server details
        const selectedServerList = servers.filter(s => selectedServers.has(s.id));

        let completed = 0;
        let successful = 0;
        let failed = 0;
        let totalPackages = 0;
        let totalServices = 0;

        try {
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {
                'Content-Type': 'application/json'
            };
            if (apiKey) {
                headers['X-API-Key'] = apiKey;
            }

            // Process servers (in batches based on parallel count)
            for (let i = 0; i < selectedServerList.length; i += parallelCount) {
                const batch = selectedServerList.slice(i, i + parallelCount);

                const batchPromises = batch.map(async (server) => {
                    currentServerEl.textContent = `Discovering: ${server.name} (${server.hostname})`;

                    try {
                        const response = await fetch('/api/discovery/run', {
                            method: 'POST',
                            credentials: 'include',
                            headers,
                            body: JSON.stringify({
                                server_id: server.id,
                                format: format,
                                options: {
                                    packages: discoverPackages,
                                    services: discoverServices,
                                    updates: discoverUpdates,
                                    security: discoverSecurity,
                                    lightweight: lightweight,
                                    throttle: throttle,
                                    limit: limit > 0 ? limit : null
                                }
                            })
                        });

                        const result = await response.json();

                        if (result.success) {
                            successful++;
                            totalPackages += result.data?.packages?.length || 0;
                            totalServices += result.data?.services?.length || 0;
                        } else {
                            failed++;
                        }

                        discoveryResults.push({
                            server: server,
                            success: result.success,
                            data: result.data || null,
                            error: result.error || null,
                            timestamp: new Date().toISOString()
                        });

                        return result;
                    } catch (error) {
                        failed++;
                        discoveryResults.push({
                            server: server,
                            success: false,
                            data: null,
                            error: error.message,
                            timestamp: new Date().toISOString()
                        });
                        return { success: false, error: error.message };
                    }
                });

                await Promise.all(batchPromises);

                completed += batch.length;
                progressBar.style.width = `${(completed / selectedServerList.length) * 100}%`;
                progressCount.textContent = `${completed} / ${selectedServerList.length}`;
            }

            progressText.textContent = 'Discovery complete!';
            currentServerEl.textContent = '';

            // Update summary
            document.getElementById('result-total-servers').textContent = selectedServerList.length;
            document.getElementById('result-success-count').textContent = successful;
            document.getElementById('result-error-count').textContent = failed;
            document.getElementById('result-packages-count').textContent = totalPackages;
            document.getElementById('result-services-count').textContent = totalServices;
            document.getElementById('discovery-results-summary').style.display = 'flex';

            // Render results
            renderDiscoveryResults();

            // Check for recommendations
            if (successful > 0) {
                loadRecommendations();
            }

        } catch (error) {
            progressText.textContent = 'Discovery failed: ' + error.message;
            console.error('Discovery error:', error);
        } finally {
            isDiscoveryRunning = false;
            updateRunButton();

            // Hide progress after delay
            setTimeout(() => {
                progressDiv.style.display = 'none';
            }, 3000);
        }
    }

    async function deployFleetAgent() {
        if (selectedServers.size === 0) {
            alert('Please select at least one server');
            return;
        }

        // Get server IDs from selected servers
        const serverIds = Array.from(selectedServers);

        // Get agent settings from the fleet agent config panel (in deploy tab) or use defaults
        // These elements may not exist if user hasn't visited deploy tab
        const serverUrl = document.getElementById('fleet-agent-server-url')?.value || window.location.origin;
        const apiKey = document.getElementById('fleet-agent-api-key')?.value || '';
        const pollingInterval = document.getElementById('fleet-agent-poll-interval')?.value || '60';
        const autoSync = document.getElementById('fleet-agent-auto-sync')?.checked ?? true;

        // Get connection method - default to 'auto' which will detect based on server OS
        const connectionMethodRadio = document.querySelector('input[name="fleet-agent-connection"]:checked');
        const connectionMethod = connectionMethodRadio?.value || 'auto';

        // Confirm deployment
        const methodLabel = connectionMethod === 'auto' ? 'auto-detected method' : connectionMethod.toUpperCase();
        const confirmMsg = `Deploy Fleet Agent to ${serverIds.length} server(s) via ${methodLabel}?\n\nThis will:\n- Install the fleet agent to each server\n- Configure it to communicate with this server\n- Enable automatic audit scheduling`;
        if (!confirm(confirmMsg)) {
            return;
        }

        // Show progress
        const progressDiv = document.getElementById('discovery-progress');
        const progressText = document.getElementById('discovery-progress-text');
        const progressBar = document.getElementById('discovery-progress-fill');

        progressDiv.style.display = 'block';
        progressText.textContent = `Deploying fleet agent via ${methodLabel}...`;
        progressBar.style.width = '10%';

        try {
            const deployRequestApiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const deployHeaders = {
                'Content-Type': 'application/json'
            };
            if (deployRequestApiKey) {
                deployHeaders['X-API-Key'] = deployRequestApiKey;
            }

            const response = await fetch('/api/deploy/fleet-agent', {
                method: 'POST',
                credentials: 'include',
                headers: deployHeaders,
                body: JSON.stringify({
                    server_ids: serverIds,
                    connection_method: connectionMethod,
                    config: {
                        server_url: serverUrl,
                        api_key: apiKey,
                        poll_interval: parseInt(pollingInterval),
                        auto_sync: autoSync
                    }
                })
            });

            progressBar.style.width = '70%';

            const result = await response.json();

            if (result.success) {
                progressBar.style.width = '100%';

                // Handle API-only deployment (returns download links)
                if (result.method === 'api') {
                    progressText.textContent = 'API-only deployment configured. See download links.';
                    showApiDeploymentResult(result);
                    return;
                }

                // Count successes and failures
                const results = result.results || [];
                const successful = results.filter(r => r.success).length;
                const failed = results.filter(r => !r.success).length;

                progressText.textContent = `Agent deployment complete: ${successful} succeeded, ${failed} failed`;

                // Show detailed results if there were issues
                if (failed > 0) {
                    const failures = results.filter(r => !r.success);
                    let failMsg = 'Deployment failures:\n\n';
                    failures.forEach(f => {
                        failMsg += `• ${f.server}: ${f.error}\n`;
                    });
                    alert(failMsg);
                }
            } else {
                progressBar.style.width = '100%';
                progressText.textContent = `Deployment failed: ${result.error}`;
                alert('Agent deployment failed: ' + result.error);
            }

        } catch (error) {
            progressText.textContent = 'Deployment failed: ' + error.message;
            console.error('Deploy fleet agent error:', error);
            alert('Agent deployment failed: ' + error.message);
        } finally {
            // Hide progress after delay
            setTimeout(() => {
                progressDiv.style.display = 'none';
            }, 5000);
        }
    }

    /**
     * Display API-only deployment result with download links
     */
    function showApiDeploymentResult(result) {
        const links = result.download_links || {};
        const instructions = result.instructions || {};

        let msg = 'API-Only Deployment Configured\n\n';
        msg += 'Agents must be installed manually using the download links below.\n\n';
        msg += 'Download URLs:\n';
        msg += `• Windows Script: ${links.windows_script || 'N/A'}\n`;
        msg += `• Linux Script: ${links.linux_script || 'N/A'}\n`;
        msg += `• Windows Package: ${links.windows_package || 'N/A'}\n`;
        msg += `• Linux Package: ${links.linux_package || 'N/A'}\n\n`;
        msg += 'Installation Instructions:\n';
        msg += `Windows:\n${instructions.windows || 'See documentation'}\n\n`;
        msg += `Linux:\n${instructions.linux || 'See documentation'}`;

        alert(msg);

        // Also log to console for easy access
        console.log('API Deployment Result:', result);
    }

    function renderDiscoveryResults() {
        const container = document.getElementById('discovery-server-results');

        container.innerHTML = discoveryResults.map((result, index) => {
            const server = result.server;
            const data = result.data || {};
            const osInfo = data.os_info || {};
            const packages = data.packages || [];
            const services = data.services || [];
            const updates = data.updates || [];

            return `
                <div class="server-result-card" data-index="${index}">
                    <div class="server-result-header" onclick="discoveryTab.toggleResultCard(${index})">
                        <span class="result-status-icon">${result.success ? '✅' : '❌'}</span>
                        <div class="result-server-info">
                            <span class="result-server-name">${escapeHtml(server.name)}</span>
                            <span class="result-server-host">${escapeHtml(server.hostname)}</span>
                        </div>
                        <div class="result-quick-stats">
                            ${result.success ? `
                                <span>📦 ${packages.length} packages</span>
                                <span>⚙️ ${services.length} services</span>
                                ${updates.length > 0 ? `<span>⬆️ ${updates.length} updates</span>` : ''}
                            ` : `<span class="error-text">${escapeHtml(result.error || 'Connection failed')}</span>`}
                        </div>
                        <span class="expand-icon">▼</span>
                    </div>
                    <div class="server-result-body">
                        ${result.success ? `
                            ${osInfo.name ? `
                                <div class="result-section">
                                    <h5>Operating System</h5>
                                    <p>${escapeHtml(osInfo.name || 'Unknown')} ${escapeHtml(osInfo.version || '')}</p>
                                </div>
                            ` : ''}
                            ${packages.length > 0 ? `
                                <div class="result-section">
                                    <h5>Key Packages (${packages.length} total)</h5>
                                    <div class="result-list">
                                        ${packages.slice(0, 20).map(pkg => `<span class="result-item">${escapeHtml(pkg.name || pkg)}</span>`).join('')}
                                        ${packages.length > 20 ? `<span class="result-item">+${packages.length - 20} more</span>` : ''}
                                    </div>
                                </div>
                            ` : ''}
                            ${services.length > 0 ? `
                                <div class="result-section">
                                    <h5>Running Services (${services.length} total)</h5>
                                    <div class="result-list">
                                        ${services.slice(0, 15).map(svc => `<span class="result-item">${escapeHtml(svc.name || svc)}</span>`).join('')}
                                        ${services.length > 15 ? `<span class="result-item">+${services.length - 15} more</span>` : ''}
                                    </div>
                                </div>
                            ` : ''}
                            ${updates.length > 0 ? `
                                <div class="result-section">
                                    <h5>Available Updates (${updates.length})</h5>
                                    <div class="result-list">
                                        ${updates.slice(0, 10).map(upd => `<span class="result-item">${escapeHtml(upd.name || upd)}</span>`).join('')}
                                        ${updates.length > 10 ? `<span class="result-item">+${updates.length - 10} more</span>` : ''}
                                    </div>
                                </div>
                            ` : ''}
                        ` : `
                            <div class="result-section">
                                <h5>Error Details</h5>
                                <pre class="error-details">${escapeHtml(result.error || 'Unknown error')}</pre>
                            </div>
                        `}
                    </div>
                </div>
            `;
        }).join('');
    }

    function toggleResultCard(index) {
        const card = document.querySelector(`.server-result-card[data-index="${index}"]`);
        if (card) {
            card.classList.toggle('expanded');
        }
    }

    async function loadRecommendations() {
        const recommendationsDiv = document.getElementById('discovery-recommendations');
        const recommendationsList = document.getElementById('recommendations-list');

        try {
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {
                'Content-Type': 'application/json'
            };
            if (apiKey) {
                headers['X-API-Key'] = apiKey;
            }

            // Collect all discovered packages and services
            const allPackages = [];
            const allServices = [];

            discoveryResults.forEach(result => {
                if (result.success && result.data) {
                    if (result.data.packages) {
                        allPackages.push(...result.data.packages.map(p => p.name || p));
                    }
                    if (result.data.services) {
                        allServices.push(...result.data.services.map(s => s.name || s));
                    }
                }
            });

            const response = await fetch('/api/discovery/recommendations', {
                method: 'POST',
                credentials: 'include',
                headers,
                body: JSON.stringify({
                    packages: [...new Set(allPackages)],
                    services: [...new Set(allServices)]
                })
            });

            const data = await response.json();

            if (data.recommendations && data.recommendations.length > 0) {
                recommendationsList.innerHTML = data.recommendations.map(rec => `
                    <div class="audit-item">
                        <label class="checkbox-label">
                            <input type="checkbox" name="recommended-audit" value="${escapeHtml(rec.audit_id || rec.name)}">
                            <span>${escapeHtml(rec.name)}</span>
                        </label>
                        <p class="audit-description">${escapeHtml(rec.description || '')}</p>
                        <span class="audit-reason">Reason: ${escapeHtml(rec.reason || 'Based on detected software')}</span>
                    </div>
                `).join('');

                recommendationsDiv.style.display = 'block';
            }
        } catch (error) {
            console.error('Error loading recommendations:', error);
        }
    }

    function clearResults() {
        discoveryResults = [];
        document.getElementById('discovery-server-results').innerHTML = '';
        document.getElementById('discovery-results-summary').style.display = 'none';
        document.getElementById('discovery-recommendations').style.display = 'none';
        document.getElementById('discovery-output-display').textContent =
            'Select servers above and click "Run Discovery" to analyze systems...';
    }

    function toggleRawOutput() {
        const output = document.getElementById('discovery-output-display');
        if (output.style.display === 'none') {
            output.style.display = 'block';
            // Populate with raw JSON of results
            output.textContent = JSON.stringify(discoveryResults, null, 2);
        } else {
            output.style.display = 'none';
        }
    }

    function exportJSON() {
        if (discoveryResults.length === 0) {
            alert('No discovery results to export');
            return;
        }

        const data = {
            exported_at: new Date().toISOString(),
            total_servers: discoveryResults.length,
            successful: discoveryResults.filter(r => r.success).length,
            failed: discoveryResults.filter(r => !r.success).length,
            results: discoveryResults
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `discovery-results-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }

    function exportCSV() {
        if (discoveryResults.length === 0) {
            alert('No discovery results to export');
            return;
        }

        const headers = ['Server Name', 'Hostname', 'OS Type', 'Status', 'Packages Count', 'Services Count', 'Updates Count', 'Error'];
        const rows = discoveryResults.map(r => [
            r.server.name,
            r.server.hostname,
            r.server.os_type || 'linux',
            r.success ? 'Success' : 'Failed',
            r.data?.packages?.length || 0,
            r.data?.services?.length || 0,
            r.data?.updates?.length || 0,
            r.error || ''
        ]);

        const csv = [
            headers.join(','),
            ...rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
        ].join('\n');

        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `discovery-results-${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    }

    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Expose functions globally for onclick handlers
    window.discoveryTab = {
        toggleServer,
        toggleResultCard,
        loadServers,
        filterServerSearch
    };

})();


/**
 * Discovery History Module
 * Handles viewing stored discovery results from the Reports tab
 */
(function() {
    'use strict';

    let discoveryHistory = [];
    let currentDetailResult = null;

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        initDiscoveryHistory();
    });

    function initDiscoveryHistory() {
        // Check if reports tab elements exist
        const historyList = document.getElementById('discovery-history-list');
        if (!historyList) return;

        // Refresh button
        document.getElementById('refresh-discovery-history')?.addEventListener('click', loadDiscoveryHistory);

        // Server filter
        document.getElementById('discovery-server-filter')?.addEventListener('change', filterDiscoveryHistory);

        // Search input
        const searchInput = document.getElementById('discovery-history-search');
        if (searchInput) {
            searchInput.addEventListener('input', debounce(filterDiscoveryHistory, 300));
        }

        // Load on init
        loadDiscoveryHistory();
    }

    // Debounce helper
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func.apply(this, args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    async function loadDiscoveryHistory() {
        const historyList = document.getElementById('discovery-history-list');
        const serverFilter = document.getElementById('discovery-server-filter');

        historyList.innerHTML = '<p class="loading">Loading discovery history...</p>';

        try {
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {};
            if (apiKey) {
                headers['X-API-Key'] = apiKey;
            }

            const response = await fetch('/api/discovery/results?limit=50', { headers, credentials: 'include' });
            const data = await response.json();

            if (data.results && data.results.length > 0) {
                discoveryHistory = data.results;
                renderDiscoveryHistory();
                populateServerFilter();
            } else {
                discoveryHistory = [];
                historyList.innerHTML = `
                    <div class="empty-state">
                        <p>No discovery results found.</p>
                        <p class="info-text">Run discovery on servers from the Discovery tab to see results here.</p>
                    </div>
                `;
            }
        } catch (error) {
            historyList.innerHTML = `<p class="error-text">Error loading discovery history: ${error.message}</p>`;
            console.error('Error loading discovery history:', error);
        }
    }

    function populateServerFilter() {
        const serverFilter = document.getElementById('discovery-server-filter');
        if (!serverFilter) return;

        // Get unique servers
        const servers = new Map();
        discoveryHistory.forEach(result => {
            if (result.server_id && result.server_name) {
                servers.set(result.server_id, result.server_name);
            }
        });

        // Clear and rebuild options
        serverFilter.innerHTML = '<option value="">All Servers</option>';
        servers.forEach((name, id) => {
            const option = document.createElement('option');
            option.value = id;
            option.textContent = name;
            serverFilter.appendChild(option);
        });
    }

    function filterDiscoveryHistory() {
        const serverFilter = document.getElementById('discovery-server-filter');
        const searchInput = document.getElementById('discovery-history-search');
        const serverId = serverFilter?.value;
        const searchQuery = searchInput?.value?.toLowerCase().trim() || '';

        let filtered = [...discoveryHistory];

        // Filter by server
        if (serverId) {
            filtered = filtered.filter(r => r.server_id == serverId);
        }

        // Filter by search query
        if (searchQuery) {
            filtered = filtered.filter(r => {
                const serverName = (r.server_name || '').toLowerCase();
                const hostname = (r.hostname || '').toLowerCase();
                const osName = (r.os_info?.pretty_name || r.os_info?.name || '').toLowerCase();
                return serverName.includes(searchQuery) || hostname.includes(searchQuery) || osName.includes(searchQuery);
            });
        }

        renderDiscoveryHistory(filtered);
    }

    function renderDiscoveryHistory(results = null) {
        const historyList = document.getElementById('discovery-history-list');
        const displayResults = results || discoveryHistory;

        if (displayResults.length === 0) {
            historyList.innerHTML = `
                <div class="empty-state">
                    <p>No discovery results found.</p>
                </div>
            `;
            return;
        }

        historyList.innerHTML = displayResults.map((result, index) => {
            const osInfo = result.os_info || {};
            const osName = osInfo.pretty_name || osInfo.name || 'Unknown OS';
            const osVersion = osInfo.version_id || osInfo.version || '';
            const kernel = osInfo.kernel || '';
            const packages = result.packages || [];
            const services = result.services || [];
            const updates = result.updates || [];
            const recommendations = result.recommendations || [];
            const timestamp = new Date(result.timestamp).toLocaleString();
            const osType = result.os_type || 'linux';

            return `
                <div class="discovery-history-card" data-result-id="${result.id}">
                    <div class="discovery-history-header" onclick="discoveryHistory.viewDetail(${result.id})">
                        <div class="discovery-history-server">
                            <span class="discovery-history-icon">${osType === 'windows' ? '🪟' : '🐧'}</span>
                            <div>
                                <div class="discovery-history-name">${escapeHtml(result.server_name || 'Unknown')}</div>
                                <div class="discovery-history-host">${escapeHtml(result.hostname || '')}</div>
                            </div>
                        </div>
                        <div class="discovery-history-meta">
                            <span class="discovery-history-timestamp">${timestamp}</span>
                            <span class="discovery-history-status ${result.success ? 'success' : 'failed'}">
                                ${result.success ? '✓ Success' : '✗ Failed'}
                            </span>
                        </div>
                    </div>

                    ${osName !== 'Unknown OS' ? `
                        <div class="discovery-history-os">
                            <div class="discovery-os-name">${escapeHtml(osName)}</div>
                            ${osVersion ? `<div class="discovery-os-version">Version: ${escapeHtml(osVersion)}</div>` : ''}
                            ${kernel ? `<div class="discovery-os-kernel">Kernel: ${escapeHtml(kernel)}</div>` : ''}
                        </div>
                    ` : ''}

                    <div class="discovery-history-summary">
                        <div class="discovery-summary-item">
                            <div class="discovery-summary-value">${packages.length}</div>
                            <div class="discovery-summary-label">Packages</div>
                        </div>
                        <div class="discovery-summary-item">
                            <div class="discovery-summary-value">${services.length}</div>
                            <div class="discovery-summary-label">Services</div>
                        </div>
                        <div class="discovery-summary-item">
                            <div class="discovery-summary-value">${updates.length}</div>
                            <div class="discovery-summary-label">Updates</div>
                        </div>
                        <div class="discovery-summary-item">
                            <div class="discovery-summary-value">${recommendations.length}</div>
                            <div class="discovery-summary-label">Recommendations</div>
                        </div>
                    </div>

                    <div class="discovery-history-actions">
                        <button class="btn btn-small btn-primary" onclick="discoveryHistory.viewDetail(${result.id})">
                            📋 View Details
                        </button>
                        <button class="btn btn-small" onclick="discoveryHistory.exportResult(${result.id})">
                            📥 Export
                        </button>
                        <button class="btn btn-small" onclick="discoveryHistory.deleteResult(${result.id})"
                                style="background: rgba(239, 68, 68, 0.2); color: #ef4444;">
                            🗑️ Delete
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    async function viewDetail(resultId) {
        const modal = document.getElementById('discovery-detail-modal');
        const content = document.getElementById('discovery-detail-content');
        const title = document.getElementById('discovery-detail-title');

        if (!modal || !content) return;

        // Find result in cache or fetch
        let result = discoveryHistory.find(r => r.id === resultId);

        if (!result) {
            try {
                const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
                const headers = {};
                if (apiKey) headers['X-API-Key'] = apiKey;

                const response = await fetch(`/api/discovery/result/${resultId}`, { headers, credentials: 'include' });
                const data = await response.json();
                if (data.result) {
                    result = data.result;
                }
            } catch (error) {
                alert('Error loading discovery details: ' + error.message);
                return;
            }
        }

        if (!result) {
            alert('Discovery result not found');
            return;
        }

        currentDetailResult = result;
        title.textContent = `Discovery Details - ${result.server_name || result.hostname}`;

        const osInfo = result.os_info || {};
        const packages = result.packages || [];
        const services = result.services || [];
        const updates = result.updates || [];
        const security = result.security || {};
        const recommendations = result.recommendations || [];

        content.innerHTML = `
            <div class="discovery-detail-grid">
                <!-- OS Information -->
                <div class="discovery-detail-section">
                    <h4>📋 System Information</h4>
                    <table class="discovery-detail-table">
                        <tr><th>OS Name</th><td>${escapeHtml(osInfo.pretty_name || osInfo.name || 'Unknown')}</td></tr>
                        <tr><th>Version</th><td>${escapeHtml(osInfo.version_id || osInfo.version || 'N/A')}</td></tr>
                        <tr><th>Kernel</th><td>${escapeHtml(osInfo.kernel || 'N/A')}</td></tr>
                        <tr><th>Architecture</th><td>${escapeHtml(osInfo.architecture || 'N/A')}</td></tr>
                        <tr><th>Hostname</th><td>${escapeHtml(osInfo.hostname || result.hostname || 'N/A')}</td></tr>
                        <tr><th>Distribution</th><td>${escapeHtml(osInfo.id || 'N/A')}</td></tr>
                    </table>
                </div>

                <!-- Security Status -->
                <div class="discovery-detail-section">
                    <h4>🔒 Security Status</h4>
                    ${Object.keys(security).length > 0 ? `
                        <div class="security-status ${security.firewall_active ? 'enabled' : 'disabled'}">
                            ${security.firewall_active ? '✓' : '✗'} Firewall:
                            ${security.firewall_active ? `Active (${security.firewall_type || 'unknown'})` : 'Inactive'}
                        </div>
                        <div class="security-status ${security.selinux_status === 'enforcing' ? 'enabled' : security.selinux_status === 'permissive' ? 'warning' : 'disabled'}">
                            SELinux: ${escapeHtml(security.selinux_status || 'Not detected')}
                        </div>
                        <div class="security-status ${security.apparmor_status === 'enabled' ? 'enabled' : 'disabled'}">
                            AppArmor: ${escapeHtml(security.apparmor_status || 'Not detected')}
                        </div>
                        <div class="security-status ${security.fail2ban_active ? 'enabled' : 'disabled'}">
                            Fail2ban: ${security.fail2ban_active ? 'Active' : 'Inactive'}
                        </div>
                        ${security.ssh_root_login !== undefined ? `
                            <div class="security-status ${!security.ssh_root_login ? 'enabled' : 'warning'}">
                                SSH Root Login: ${security.ssh_root_login ? 'Enabled (⚠️)' : 'Disabled'}
                            </div>
                        ` : ''}
                        ${security.password_auth !== undefined ? `
                            <div class="security-status ${!security.password_auth ? 'enabled' : 'warning'}">
                                Password Auth: ${security.password_auth ? 'Enabled' : 'Disabled (Key-only)'}
                            </div>
                        ` : ''}
                    ` : '<p class="info-text">Security scan not performed. Enable "Security Configuration" option when running discovery.</p>'}
                </div>

                <!-- Installed Packages -->
                <div class="discovery-detail-section">
                    <h4>📦 Installed Packages (${packages.length})</h4>
                    <div class="discovery-package-list">
                        ${packages.length > 0 ? `
                            <table class="discovery-detail-table">
                                <thead>
                                    <tr><th>Package</th><th>Version</th></tr>
                                </thead>
                                <tbody>
                                    ${packages.slice(0, 50).map(pkg => `
                                        <tr>
                                            <td>${escapeHtml(pkg.name || pkg)}</td>
                                            <td>${escapeHtml(pkg.version || 'N/A')}</td>
                                        </tr>
                                    `).join('')}
                                    ${packages.length > 50 ? `
                                        <tr><td colspan="2" class="info-text">... and ${packages.length - 50} more packages</td></tr>
                                    ` : ''}
                                </tbody>
                            </table>
                        ` : '<p class="info-text">No packages discovered</p>'}
                    </div>
                </div>

                <!-- Running Services -->
                <div class="discovery-detail-section">
                    <h4>⚙️ Running Services (${services.length})</h4>
                    <div class="discovery-package-list">
                        ${services.length > 0 ? `
                            <table class="discovery-detail-table">
                                <thead>
                                    <tr><th>Service</th><th>Status</th></tr>
                                </thead>
                                <tbody>
                                    ${services.slice(0, 30).map(svc => `
                                        <tr>
                                            <td>${escapeHtml(svc.name || svc)}</td>
                                            <td>${escapeHtml(svc.status || 'running')}</td>
                                        </tr>
                                    `).join('')}
                                    ${services.length > 30 ? `
                                        <tr><td colspan="2" class="info-text">... and ${services.length - 30} more services</td></tr>
                                    ` : ''}
                                </tbody>
                            </table>
                        ` : '<p class="info-text">No services discovered</p>'}
                    </div>
                </div>

                <!-- Available Updates -->
                <div class="discovery-detail-section full-width">
                    <h4>⬆️ Available Updates (${updates.length})</h4>
                    ${updates.length > 0 ? `
                        <table class="discovery-detail-table">
                            <thead>
                                <tr><th>Package</th><th>Current</th><th>Available</th></tr>
                            </thead>
                            <tbody>
                                ${updates.slice(0, 20).map(upd => `
                                    <tr>
                                        <td>${escapeHtml(upd.name || upd)}</td>
                                        <td>${escapeHtml(upd.current || 'N/A')}</td>
                                        <td>${escapeHtml(upd.available || 'N/A')}</td>
                                    </tr>
                                `).join('')}
                                ${updates.length > 20 ? `
                                    <tr><td colspan="3" class="info-text">... and ${updates.length - 20} more updates</td></tr>
                                ` : ''}
                            </tbody>
                        </table>
                    ` : '<p class="info-text">System is up to date</p>'}
                </div>

                <!-- Audit Recommendations -->
                <div class="discovery-detail-section full-width">
                    <h4>🎯 Recommended Audits (${recommendations.length})</h4>
                    ${recommendations.length > 0 ? `
                        ${recommendations.map(rec => `
                            <div class="discovery-recommendation-card">
                                <div class="recommendation-name">${escapeHtml(rec.name)}</div>
                                <div class="recommendation-desc">${escapeHtml(rec.description || '')}</div>
                                <div class="recommendation-reason">${escapeHtml(rec.reason || '')}</div>
                            </div>
                        `).join('')}
                    ` : '<p class="info-text">No specific audit recommendations based on discovered software</p>'}
                </div>
            </div>
        `;

        modal.style.display = 'flex';
    }

    async function deleteResult(resultId) {
        if (!confirm('Are you sure you want to delete this discovery result?')) {
            return;
        }

        try {
            const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
            const headers = {};
            if (apiKey) headers['X-API-Key'] = apiKey;

            const response = await fetch(`/api/discovery/result/${resultId}`, {
                method: 'DELETE',
                credentials: 'include',
                headers
            });

            const data = await response.json();
            if (data.success) {
                // Remove from cache and re-render
                discoveryHistory = discoveryHistory.filter(r => r.id !== resultId);
                renderDiscoveryHistory();
            } else {
                alert('Error deleting result: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            alert('Error deleting result: ' + error.message);
        }
    }

    function exportResult(resultId) {
        const result = discoveryHistory.find(r => r.id === resultId);
        if (!result) {
            alert('Result not found');
            return;
        }

        const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `discovery-${result.server_name || result.hostname}-${result.timestamp.split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }

    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Global functions for modal
    window.closeDiscoveryDetailModal = function() {
        const modal = document.getElementById('discovery-detail-modal');
        if (modal) modal.style.display = 'none';
        currentDetailResult = null;
    };

    window.exportDiscoveryDetail = function(format) {
        if (!currentDetailResult) return;

        if (format === 'json') {
            const blob = new Blob([JSON.stringify(currentDetailResult, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `discovery-detail-${currentDetailResult.server_name || 'server'}.json`;
            a.click();
            URL.revokeObjectURL(url);
        } else if (format === 'csv') {
            // Export packages as CSV
            const packages = currentDetailResult.packages || [];
            const headers = ['Package Name', 'Version', 'Description'];
            const rows = packages.map(p => [
                p.name || '',
                p.version || '',
                (p.description || '').replace(/"/g, '""')
            ]);
            const csv = [
                headers.join(','),
                ...rows.map(r => r.map(c => `"${c}"`).join(','))
            ].join('\n');

            const blob = new Blob([csv], { type: 'text/csv' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `discovery-packages-${currentDetailResult.server_name || 'server'}.csv`;
            a.click();
            URL.revokeObjectURL(url);
        }
    };

    // Expose functions globally
    window.discoveryHistory = {
        viewDetail,
        deleteResult,
        exportResult,
        reload: loadDiscoveryHistory
    };

    // Add event listeners for modal buttons
    document.addEventListener('DOMContentLoaded', function() {
        var closeBtn = document.getElementById('discovery-modal-close');
        if (closeBtn) closeBtn.addEventListener('click', window.closeDiscoveryDetailModal);

        var closeBtnFooter = document.getElementById('discovery-modal-close-btn');
        if (closeBtnFooter) closeBtnFooter.addEventListener('click', window.closeDiscoveryDetailModal);

        var exportJsonBtn = document.getElementById('export-discovery-json');
        if (exportJsonBtn) exportJsonBtn.addEventListener('click', function() {
            window.exportDiscoveryDetail('json');
        });

        var exportCsvBtn = document.getElementById('export-discovery-csv');
        if (exportCsvBtn) exportCsvBtn.addEventListener('click', function() {
            window.exportDiscoveryDetail('csv');
        });
    });

})();
