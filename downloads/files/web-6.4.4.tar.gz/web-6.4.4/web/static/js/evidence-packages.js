/**
 * Evidence Packages UI — Reports tab
 *
 * Controls:
 *   - Package list with per-row Verify and Download buttons
 *   - Cleanup Preview (dry_run: true) → banner with candidate count
 *   - Run Cleanup  (dry_run: false) → banner with deleted count
 *   - Verify modal showing file-level integrity results
 */

(function () {
    'use strict';

    // ------------------------------------------------------------------ //
    // Helpers
    // ------------------------------------------------------------------ //

    function escHtml(v) {
        if (v == null) return '';
        const d = document.createElement('div');
        d.textContent = String(v);
        return d.innerHTML;
    }

    function parseApiErrorDetails(message) {
        const text = String(message || '');
        const jsonStart = text.indexOf('{');
        if (jsonStart === -1) return null;
        try {
            return JSON.parse(text.slice(jsonStart));
        } catch (_err) {
            return null;
        }
    }

    function buildPackagesLoadErrorHtml(err) {
        const details = parseApiErrorDetails(err && err.message);
        if (details && details.code === 'FEATURE_UNAVAILABLE') {
            const upgradeTier = details.upgrade_tier ? ` ${escHtml(details.upgrade_tier)}` : '';
            const trialNote = details.trial_eligible
                ? '<p>You can also start an eligible trial from the licensing area.</p>'
                : '';

            return `
                <div class="reports-empty-state">
                    <div class="reports-empty-icon">📦</div>
                    <h3>Evidence Packages Are Not Enabled</h3>
                    <p>The Evidence Packager is not available on this license.</p>
                    <p>${escHtml(details.reason || 'This feature requires a higher license tier.')}</p>
                    <p>Upgrade to the${upgradeTier} tier to create, verify, and download evidence packages from Console Reports.</p>
                    ${trialNote}
                </div>`;
        }

        return `
            <div class="reports-empty-state">
                <div class="reports-empty-icon">⚠️</div>
                <h3>Packages Could Not Be Loaded</h3>
                <p>Evidence packages are temporarily unavailable. Refresh the page and try again.</p>
            </div>`;
    }

    function getCsrfToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        return (meta && meta.content) ? meta.content : '';
    }

    async function apiRequest(endpoint, options = {}) {
        const method = (options.method || 'GET').toUpperCase();
        const headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});
        if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method)) {
            headers['X-CSRFToken'] = getCsrfToken();
        }
        const resp = await fetch(endpoint, {
            ...options,
            method,
            headers,
            credentials: 'include',
        });
        if (!resp.ok) {
            const txt = await resp.text().catch(() => resp.statusText);
            throw new Error(`${method} ${endpoint} → ${resp.status}: ${txt}`);
        }
        return resp.json();
    }

    // ------------------------------------------------------------------ //
    // Banner helpers
    // ------------------------------------------------------------------ //

    function showBanner(type, html) {
        const el = document.getElementById('evidence-cleanup-banner');
        if (!el) return;
        el.className = `evidence-banner evidence-banner-${type}`;
        el.innerHTML = html;
        el.classList.remove('d-none');
    }

    function hideBanner() {
        const el = document.getElementById('evidence-cleanup-banner');
        if (el) el.classList.add('d-none');
    }

    // ------------------------------------------------------------------ //
    // Module-level retention state (populated on init)
    // ------------------------------------------------------------------ //

    let _retentionEnabled = true;
    let _retentionDays = 30;

    async function loadEvidenceSettings() {
        try {
            const data = await apiRequest('/api/evidence/settings');
            _retentionEnabled = data.evidence_retention_enabled !== false;
            _retentionDays = Math.max(1, parseInt(data.evidence_retention_days) || 30);
        } catch (_e) {
            // Keep defaults — non-fatal
        }
    }

    // ------------------------------------------------------------------ //
    // Render package list
    // ------------------------------------------------------------------ //

    function renderPackages(packages) {
        const container = document.getElementById('evidence-packages-list');
        if (!container) return;

        if (!packages || packages.length === 0) {
            container.innerHTML = `
                <div class="reports-empty-state">
                    <div class="reports-empty-icon">🗂️</div>
                    <h3>No Evidence Packages</h3>
                    <p>Collect evidence for a compliance assessment to create packages</p>
                </div>`;
            return;
        }

        container.innerHTML = packages.map(pkg => {
            const verifiedBadge = buildVerifiedBadge(pkg);
            const exportedAt = pkg.exported_at
                ? new Date(pkg.exported_at).toLocaleString()
                : (pkg.created_at ? new Date(pkg.created_at).toLocaleString() : '—');
            const framework = escHtml(pkg.framework || '—');
            const org = escHtml(pkg.organization || '—');
            const itemCount = pkg.items_count != null ? pkg.items_count : (pkg.items ? pkg.items.length : '—');

            return `
            <div class="evidence-package-card" data-package-id="${escHtml(pkg.package_id)}">
                <div class="evidence-package-meta">
                    <span class="evidence-package-name">${escHtml(pkg.name || pkg.package_id)}</span>
                    <span class="evidence-package-detail">
                        Framework: <strong>${framework}</strong> &nbsp;|&nbsp;
                        Org: <strong>${org}</strong> &nbsp;|&nbsp;
                        Items: <strong>${itemCount}</strong> &nbsp;|&nbsp;
                        Exported: <strong>${exportedAt}</strong>
                    </span>
                    <div class="evidence-package-badges">${verifiedBadge}</div>
                </div>
                <div class="evidence-package-actions">
                    <button class="btn btn-small evidence-verify-btn" data-id="${escHtml(pkg.package_id)}" title="Verify archive integrity">🔐 Verify</button>
                    <button class="btn btn-small btn-secondary evidence-download-btn" data-id="${escHtml(pkg.package_id)}" title="Download ZIP">⬇ Download</button>
                </div>
            </div>`;
        }).join('');

        // Bind per-row buttons
        container.querySelectorAll('.evidence-verify-btn').forEach(btn => {
            btn.addEventListener('click', () => verifyPackage(btn.dataset.id));
        });
        container.querySelectorAll('.evidence-download-btn').forEach(btn => {
            btn.addEventListener('click', () => downloadPackage(btn.dataset.id));
        });
    }

    function buildVerifiedBadge(pkg) {
        if (pkg.last_verified_at == null) {
            return '<span class="evidence-badge evidence-badge-na">Not verified</span>';
        }
        const when = new Date(pkg.last_verified_at).toLocaleString();
        const ok = pkg.last_verified_ok;
        const cls = ok ? 'evidence-badge-ok' : 'evidence-badge-fail';
        const label = ok ? `✔ Verified ${when}` : `✘ Failed ${when}`;
        return `<span class="evidence-badge ${cls}">${escHtml(label)}</span>`;
    }

    // ------------------------------------------------------------------ //
    // Load packages
    // ------------------------------------------------------------------ //

    async function loadEvidencePackages() {
        const container = document.getElementById('evidence-packages-list');
        if (!container) return;
        container.innerHTML = '<div class="reports-empty-state"><p>Loading…</p></div>';
        hideBanner();
        try {
            const data = await apiRequest('/api/evidence/packages');
            renderPackages(data.packages || []);
        } catch (err) {
            container.innerHTML = buildPackagesLoadErrorHtml(err);
        }
    }

    // ------------------------------------------------------------------ //
    // Verify
    // ------------------------------------------------------------------ //

    async function verifyPackage(packageId) {
        const modal = document.getElementById('evidence-verify-modal');
        const content = document.getElementById('evidence-verify-content');
        if (!modal || !content) return;

        content.innerHTML = '<p>Verifying archive…</p>';
        modal.classList.remove('d-none');

        try {
            const data = await apiRequest(`/api/evidence/packages/${encodeURIComponent(packageId)}/verify`);
            const r = data.verification || data;
            const statusIcon = r.verified ? '✅' : '❌';
            const mismatches = (r.mismatches || []).map(m => `<li>${escHtml(m)}</li>`).join('');
            const errors = (r.errors || []).map(e => `<li>${escHtml(e)}</li>`).join('');

            content.innerHTML = `
                <p><strong>Result:</strong> ${statusIcon} ${r.verified ? 'Archive integrity confirmed' : 'Integrity check FAILED'}</p>
                <p><strong>Files checked:</strong> ${escHtml(r.checked_files)}</p>
                <p><strong>Manifest checksum:</strong> ${r.manifest_checksum_valid ? '✅ valid' : '❌ invalid / not present'}</p>
                ${mismatches ? `<p><strong>Mismatches:</strong></p><ul>${mismatches}</ul>` : ''}
                ${errors    ? `<p><strong>Errors:</strong></p><ul>${errors}</ul>` : ''}
            `;
            // Refresh list to update badge
            loadEvidencePackages();
        } catch (err) {
            content.innerHTML = `<p style="color:red;">Verification failed: ${escHtml(err.message)}</p>`;
        }
    }

    // ------------------------------------------------------------------ //
    // Download
    // ------------------------------------------------------------------ //

    function downloadPackage(packageId) {
        const url = `/api/evidence/packages/${encodeURIComponent(packageId)}/export?download=true`;
        window.location.href = url;
    }

    // ------------------------------------------------------------------ //
    // Cleanup preview / run
    // ------------------------------------------------------------------ //

    async function runCleanup(dryRun) {
        const btn = document.getElementById(dryRun ? 'evidence-cleanup-preview-btn' : 'evidence-cleanup-run-btn');
        if (btn) btn.disabled = true;
        hideBanner();

        try {
            const data = await apiRequest('/api/evidence/exports/cleanup', {
                method: 'POST',
                body: JSON.stringify({ days_to_keep: _retentionDays, dry_run: dryRun }),
            });

            if (dryRun) {
                const count = data.candidates || 0;
                if (count === 0) {
                    showBanner('info', '🔍 No packages are eligible for cleanup (all within retention window).');
                } else {
                    const ids = (data.candidate_package_ids || []).map(id => `<code>${escHtml(id)}</code>`).join(', ');
                    showBanner('warning',
                        `🔍 <strong>${count} package(s)</strong> are older than ${data.days_to_keep} days and would be removed: ${ids}`);
                }
            } else {
                const removed = data.candidates || 0;
                const deleted = (data.deleted_paths || []).length;
                if (removed === 0) {
                    showBanner('success', '✅ Cleanup complete — no packages required removal.');
                } else {
                    showBanner('success',
                        `✅ Cleanup complete — removed <strong>${removed}</strong> package(s), deleted <strong>${deleted}</strong> file(s).`);
                    loadEvidencePackages();
                }
            }
        } catch (err) {
            showBanner('danger', `❌ Cleanup failed: ${escHtml(err.message)}`);
        } finally {
            if (btn) btn.disabled = false;
        }
    }

    // ------------------------------------------------------------------ //
    // Init
    // ------------------------------------------------------------------ //

    function init() {
        // Load retention settings (non-blocking)
        loadEvidenceSettings();

        // Refresh button
        const refreshBtn = document.getElementById('refresh-evidence-packages');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', loadEvidencePackages);
        }

        // Cleanup buttons
        const previewBtn = document.getElementById('evidence-cleanup-preview-btn');
        if (previewBtn) previewBtn.addEventListener('click', () => runCleanup(true));

        const runBtn = document.getElementById('evidence-cleanup-run-btn');
        if (runBtn) {
            runBtn.addEventListener('click', () => {
                if (!confirm(`Delete all evidence exports older than ${_retentionDays} day(s)? This cannot be undone.`)) return;
                runCleanup(false);
            });
        }

        // Modal close buttons
        ['evidence-verify-modal-close', 'evidence-verify-modal-close-btn'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('click', () => {
                const modal = document.getElementById('evidence-verify-modal');
                if (modal) modal.classList.add('d-none');
            });
        });

        // Load on Reports tab activation
        const reportsTabBtn = document.querySelector('[data-tab="reports"]');
        if (reportsTabBtn) {
            reportsTabBtn.addEventListener('click', loadEvidencePackages);
        }

        // Also load if reports tab is already visible on page load
        const reportsTab = document.getElementById('reports-tab');
        if (reportsTab && !reportsTab.classList.contains('d-none') && getComputedStyle(reportsTab).display !== 'none') {
            loadEvidencePackages();
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
