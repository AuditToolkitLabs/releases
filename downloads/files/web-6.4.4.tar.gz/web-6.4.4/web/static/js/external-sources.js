/**
 * External Sources + External Push Ingest Admin Panel
 *
 * - External producer registry management (Business + Advanced Operations Pack)
 * - Dead-letter queue management
 * - External push ingest tuning (Advanced Operations Pack add-on)
 */

let _dlqOffset = 0;
const _DLQ_PAGE_SIZE = 25;
let _dlqTotal = 0;

let _pushSettingsLoaded = false;
let _pushSettingsEnabled = false;
let _externalSourcesRoleAllowed = true;

const _EXTERNAL_SOURCES_AUTH = {
    title: 'External Sources Access Authentication',
    notice: 'Re-enter your password to unlock External Sources management. Access is logged for audit and tracking.',
    buttonText: 'Authenticate & Access External Sources',
    successText: 'External Sources access authorized',
    authenticateUrl: '/api/external-sources/authenticate',
    statusUrl: '/api/external-sources/authenticate/status',
};

function _escHtml(str) {
    if (str == null) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function _setPanelNotice(message, kind = 'info') {
    const el = document.getElementById('ext-src-license-notice');
    if (!el) return;

    const palette = {
        info: { bg: '#0b3b63', border: '#2563eb', text: '#dbeafe' },
        success: { bg: '#0f3d26', border: '#22c55e', text: '#dcfce7' },
        warning: { bg: '#4a3000', border: '#f59e0b', text: '#fde68a' },
        danger: { bg: '#4b1d1d', border: '#ef4444', text: '#fecaca' },
    };
    const c = palette[kind] || palette.info;

    el.style.display = 'block';
    el.style.background = c.bg;
    el.style.border = `1px solid ${c.border}`;
    el.style.color = c.text;
    el.textContent = message;
}

function _togglePushSettingsForm(enabled, message = '') {
    const form = document.getElementById('ext-push-settings-form');
    const saveBtn = document.getElementById('ext-push-save-btn');
    const lockMsg = document.getElementById('ext-push-locked-message');

    if (form) {
        form.querySelectorAll('input, button').forEach((el) => {
            if (el.id === 'ext-push-save-btn') return;
            el.disabled = !enabled;
        });
    }
    if (saveBtn) saveBtn.disabled = !enabled;

    if (lockMsg) {
        lockMsg.style.display = enabled ? 'none' : 'block';
        lockMsg.textContent = message || 'Push ingest tuning is locked until the Advanced Operations Pack add-on is active.';
    }
}

async function _ensureExternalSourcesUnlocked() {
    if (!window.SensitiveToolAuth) {
        return false;
    }
    return window.SensitiveToolAuth.ensureUnlocked(_EXTERNAL_SOURCES_AUTH);
}

async function _externalSourcesFetch(url, options = {}) {
    const doFetch = () => (window.SensitiveToolAuth ? window.SensitiveToolAuth.authFetch(url, options) : fetch(url, { ...options, credentials: 'same-origin' }));

    let response = await doFetch();
    if (response.status !== 403) {
        return response;
    }

    let data = null;
    try {
        data = await response.clone().json();
    } catch (err) {
        return response;
    }

    if (data?.code !== 'EXTERNAL_SOURCES_AUTH_REQUIRED') {
        return response;
    }

    const unlocked = await _ensureExternalSourcesUnlocked();
    if (!unlocked) {
        return response;
    }

    return doFetch();
}

async function loadExternalPushLicenseStatus() {
    const statusDataEl = document.getElementById('ext-push-license-status');
    if (statusDataEl) {
        statusDataEl.textContent = 'Checking license...';
    }

    try {
        const [assetResp, dataResp] = await Promise.all([
            _externalSourcesFetch('/api/features/external_asset_push/status', { credentials: 'same-origin' }),
            _externalSourcesFetch('/api/features/external_data_push/status', { credentials: 'same-origin' }),
        ]);

        const asset = await assetResp.json();
        const data = await dataResp.json();

        const assetAvailable = !!asset.available;
        const dataAvailable = !!data.available;

        _pushSettingsEnabled = assetAvailable;

        if (statusDataEl) {
            statusDataEl.innerHTML = `
                <span style="display:inline-flex;align-items:center;gap:0.35rem;margin-right:0.8rem;">
                    <strong>Findings Push:</strong>
                    <span style="color:${dataAvailable ? '#22c55e' : '#ef4444'};">${dataAvailable ? 'Enabled' : 'Disabled'}</span>
                </span>
                <span style="display:inline-flex;align-items:center;gap:0.35rem;">
                    <strong>Assets Push:</strong>
                    <span style="color:${assetAvailable ? '#22c55e' : '#ef4444'};">${assetAvailable ? 'Enabled' : 'Disabled'}</span>
                </span>
            `;
        }

        if (assetAvailable) {
            _setPanelNotice('Advanced Operations Pack add-on is active. External push ingest configuration is available.', 'success');
            _togglePushSettingsForm(true);
        } else {
            const reason = asset.reason || 'Business tier plus Advanced Operations Pack add-on required';
            _setPanelNotice(`External push ingest tuning is locked: ${reason}.`, 'warning');
            _togglePushSettingsForm(false, 'Business tier plus Advanced Operations Pack add-on is required for push ingest tuning and setup.');
        }
    } catch (err) {
        _pushSettingsEnabled = false;
        if (statusDataEl) statusDataEl.textContent = 'Unable to resolve feature status.';
        _setPanelNotice('Unable to verify feature licensing at this time. External push tuning is locked.', 'danger');
        _togglePushSettingsForm(false, 'Unable to verify license status.');
    }
}

async function checkExternalSourcesRoleAccess() {
    try {
        const response = await fetch('/auth/me', { credentials: 'same-origin' });
        if (!response.ok) {
            return false;
        }
        const data = await response.json();
        return data.user?.role === 'SuperAdmin';
    } catch (err) {
        return false;
    }
}

async function loadPushIngestAdminSettings() {
    if (!_pushSettingsEnabled) return;

    const statusEl = document.getElementById('ext-push-settings-status');
    if (statusEl) {
        statusEl.style.display = 'block';
        statusEl.style.color = 'var(--text-secondary)';
        statusEl.textContent = 'Loading push ingest settings...';
    }

    try {
        const resp = await _externalSourcesFetch('/api/ingest/v1/admin/settings', {
            method: 'GET',
            credentials: 'same-origin',
        });
        const data = await resp.json();

        if (!resp.ok || !data.success) {
            throw new Error(data.error || `HTTP ${resp.status}`);
        }

        const s = data.settings || {};
        const setChecked = (id, value) => {
            const el = document.getElementById(id);
            if (el) el.checked = !!value;
        };
        const setValue = (id, value) => {
            const el = document.getElementById(id);
            if (el) el.value = String(value ?? '');
        };

        setChecked('ext-push-enabled', s.enabled !== false);
        setChecked('ext-push-require-contract', s.require_contract_version_header !== false);
        setValue('ext-push-findings-rate', s.findings_per_minute ?? 1000);
        setValue('ext-push-assets-rate', s.assets_per_minute ?? 100);
        setValue('ext-push-max-batch', s.max_batch_items ?? 500);

        if (statusEl) {
            statusEl.style.color = '#22c55e';
            statusEl.textContent = 'Settings loaded.';
        }

        _pushSettingsLoaded = true;
    } catch (err) {
        if (statusEl) {
            statusEl.style.color = '#ef4444';
            statusEl.textContent = `Failed to load settings: ${err.message}`;
        }
    }
}

async function savePushIngestAdminSettings() {
    if (!_pushSettingsEnabled) return;

    const statusEl = document.getElementById('ext-push-settings-status');
    const saveBtn = document.getElementById('ext-push-save-btn');

    const payload = {
        enabled: document.getElementById('ext-push-enabled')?.checked ?? true,
        require_contract_version_header: document.getElementById('ext-push-require-contract')?.checked ?? true,
        findings_per_minute: parseInt(document.getElementById('ext-push-findings-rate')?.value || '1000', 10),
        assets_per_minute: parseInt(document.getElementById('ext-push-assets-rate')?.value || '100', 10),
        max_batch_items: parseInt(document.getElementById('ext-push-max-batch')?.value || '500', 10),
    };

    if (saveBtn) saveBtn.disabled = true;
    if (statusEl) {
        statusEl.style.display = 'block';
        statusEl.style.color = 'var(--text-secondary)';
        statusEl.textContent = 'Saving settings...';
    }

    try {
        const resp = await _externalSourcesFetch('/api/ingest/v1/admin/settings', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'X-Ingest-Contract-Version': '1',
            },
            credentials: 'same-origin',
            body: JSON.stringify(payload),
        });
        const data = await resp.json();

        if (!resp.ok || !data.success) {
            throw new Error(data.error || `HTTP ${resp.status}`);
        }

        if (statusEl) {
            statusEl.style.color = '#22c55e';
            statusEl.textContent = 'Settings saved.';
        }
    } catch (err) {
        if (statusEl) {
            statusEl.style.color = '#ef4444';
            statusEl.textContent = `Save failed: ${err.message}`;
        }
    } finally {
        if (saveBtn) saveBtn.disabled = false;
    }
}

async function registerExternalSource() {
    if (!_externalSourcesRoleAllowed) {
        _setPanelNotice('External Sources management requires the SuperAdmin role.', 'warning');
        return;
    }

    if (!(await _ensureExternalSourcesUnlocked())) {
        _setPanelNotice('Secondary authentication is required before External Sources access is granted.', 'warning');
        return;
    }

    const btn = document.getElementById('ext-src-register-btn');
    const errorEl = document.getElementById('ext-src-error');
    const keyReveal = document.getElementById('ext-src-key-reveal');

    const name = (document.getElementById('ext-src-name').value || '').trim();
    const sourceType = (document.getElementById('ext-src-type').value || '').trim();
    const contactEmail = (document.getElementById('ext-src-email').value || '').trim();
    const webhookUrl = (document.getElementById('ext-src-webhook').value || '').trim();

    errorEl.style.display = 'none';
    keyReveal.style.display = 'none';

    if (!name || !sourceType) {
        errorEl.textContent = 'Producer Name and Source Type are required.';
        errorEl.style.display = 'block';
        return;
    }

    btn.disabled = true;
    btn.textContent = 'Registering...';

    try {
        const payload = { name, source_type: sourceType };
        if (contactEmail) payload.contact_email = contactEmail;
        if (webhookUrl) payload.webhook_url = webhookUrl;

        const resp = await _externalSourcesFetch('/api/external-sources/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Ingest-Contract-Version': '1',
            },
            body: JSON.stringify(payload),
            credentials: 'same-origin',
        });

        const data = await resp.json();

        if (!resp.ok || !data.success) {
            const msg = data.errors
                ? Object.values(data.errors).join('; ')
                : (data.error || 'Registration failed');
            errorEl.textContent = msg;
            errorEl.style.display = 'block';
            return;
        }

        document.getElementById('ext-src-revealed-key').textContent = data.api_key;
        document.getElementById('ext-src-revealed-id').textContent = data.producer_id;
        keyReveal.style.display = 'block';

        document.getElementById('ext-src-name').value = '';
        document.getElementById('ext-src-type').value = '';
        document.getElementById('ext-src-email').value = '';
        document.getElementById('ext-src-webhook').value = '';

        await loadExternalSources();
    } catch (err) {
        errorEl.textContent = 'Network error: ' + err.message;
        errorEl.style.display = 'block';
    } finally {
        btn.disabled = false;
        btn.textContent = 'Register Producer';
    }
}

function copyExtSrcKey() {
    const key = document.getElementById('ext-src-revealed-key').textContent;
    if (!key) return;

    navigator.clipboard.writeText(key).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = key;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
    });
}

async function loadExternalSources() {
    if (!_externalSourcesRoleAllowed) {
        const listEl = document.getElementById('ext-src-list');
        if (listEl) {
            listEl.innerHTML = '<div style="text-align:center;color:var(--text-secondary);padding:1.5rem;">External Sources management requires the SuperAdmin role.</div>';
        }
        return;
    }

    const listEl = document.getElementById('ext-src-list');
    if (!listEl) return;

    listEl.innerHTML = '<div style="text-align:center;padding:1.5rem;color:var(--text-secondary);">Loading...</div>';

    try {
        const resp = await _externalSourcesFetch('/api/external-sources/list', { credentials: 'same-origin' });
        const data = await resp.json();

        if (!resp.ok || !data.success) {
            listEl.innerHTML = `<div style="color:#ef4444;padding:1rem;">${_escHtml(data.error || 'Failed to load sources')}</div>`;
            return;
        }

        if (!data.sources || data.sources.length === 0) {
            listEl.innerHTML = '<div style="text-align:center;color:var(--text-secondary);padding:1.5rem;" id="ext-src-list-empty">No external producers registered yet.</div>';
            return;
        }

        const rows = data.sources.map((s) => {
            const lastSeen = s.last_seen_at ? new Date(s.last_seen_at).toLocaleString() : 'Never';
            const created = s.created_at ? new Date(s.created_at).toLocaleString() : '-';
            const statusColor = s.status === 'active' ? '#22c55e' : '#ef4444';
            return `
            <div style="border:1px solid var(--border-color);border-radius:6px;padding:0.9rem;margin-bottom:0.65rem;background:var(--card-bg);">
                <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;">
                    <div style="flex:1;min-width:0;">
                        <div style="font-weight:600;font-size:0.95rem;margin-bottom:0.2rem;">
                            ${_escHtml(s.name)}
                            <span style="font-weight:normal;font-size:0.78rem;color:var(--text-secondary);margin-left:0.5rem;">${_escHtml(s.source_type)}</span>
                        </div>
                        <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:0.15rem;">
                            ID: <code style="font-size:0.8rem;">${_escHtml(s.producer_id)}</code>
                            &nbsp;·&nbsp; Key prefix: <code style="font-size:0.8rem;">${_escHtml(s.api_key_prefix || '-')}...</code>
                        </div>
                        ${s.contact_email ? `<div style="font-size:0.8rem;color:var(--text-muted);">${_escHtml(s.contact_email)}</div>` : ''}
                        <div style="font-size:0.78rem;color:var(--text-muted);margin-top:0.25rem;">
                            Registered ${created} by ${_escHtml(s.created_by || '-')} · Last seen: ${lastSeen}
                        </div>
                    </div>
                    <div style="display:flex;align-items:center;gap:0.6rem;flex-shrink:0;">
                        <span style="font-size:0.78rem;color:${statusColor};border:1px solid ${statusColor};border-radius:4px;padding:0.15rem 0.45rem;">${_escHtml(s.status)}</span>
                        <button class="btn btn-small btn-danger" onclick="revokeExternalSource('${_escHtml(s.producer_id)}', '${_escHtml(s.name)}')">Revoke</button>
                    </div>
                </div>
            </div>`;
        }).join('');

        listEl.innerHTML = rows;
    } catch (err) {
        listEl.innerHTML = `<div style="color:#ef4444;padding:1rem;">Network error: ${_escHtml(err.message)}</div>`;
    }
}

async function revokeExternalSource(producerId, name) {
    if (!_externalSourcesRoleAllowed) {
        _setPanelNotice('External Sources management requires the SuperAdmin role.', 'warning');
        return;
    }

    if (!confirm(`Revoke producer "${name}" (${producerId})?\n\nThis will permanently invalidate their API key.`)) {
        return;
    }

    try {
        const resp = await _externalSourcesFetch(`/api/external-sources/${encodeURIComponent(producerId)}`, {
            method: 'DELETE',
            headers: { 'X-Ingest-Contract-Version': '1' },
            credentials: 'same-origin',
        });
        const data = await resp.json();

        if (!resp.ok || !data.success) {
            alert(data.error || 'Revocation failed');
            return;
        }

        await loadExternalSources();
    } catch (err) {
        alert('Network error: ' + err.message);
    }
}

async function loadDeadLetters() {
    if (!_externalSourcesRoleAllowed) {
        const listEl = document.getElementById('dlq-list');
        if (listEl) {
            listEl.innerHTML = '<div style="text-align:center;color:var(--text-secondary);padding:1.5rem;">Dead-letter management requires the SuperAdmin role.</div>';
        }
        return;
    }

    const listEl = document.getElementById('dlq-list');
    const pagEl = document.getElementById('dlq-pagination');
    if (!listEl) return;

    const unresolvedOnly = document.getElementById('dlq-unresolved-only')?.checked || false;
    const params = new URLSearchParams({ limit: _DLQ_PAGE_SIZE, offset: _dlqOffset });
    if (unresolvedOnly) params.set('unresolved_only', 'true');

    listEl.innerHTML = '<div style="text-align:center;padding:1.5rem;color:var(--text-secondary);">Loading...</div>';

    try {
        const resp = await _externalSourcesFetch(`/api/external-sources/dead-letters?${params}`, { credentials: 'same-origin' });
        const data = await resp.json();

        if (!resp.ok || !data.success) {
            listEl.innerHTML = `<div style="color:#ef4444;padding:1rem;">${_escHtml(data.error || 'Failed to load dead-letter queue')}</div>`;
            return;
        }

        _dlqTotal = data.total || 0;

        if (!data.items || data.items.length === 0) {
            listEl.innerHTML = '<div style="text-align:center;color:var(--text-secondary);padding:1.5rem;">No dead-letter entries found.</div>';
            if (pagEl) pagEl.style.display = 'none';
            return;
        }

        listEl.innerHTML = data.items.map((e) => _renderDlqEntry(e)).join('');

        if (pagEl) {
            pagEl.style.display = 'flex';
            const from = _dlqOffset + 1;
            const to = Math.min(_dlqOffset + data.items.length, _dlqTotal);
            const pageInfo = document.getElementById('dlq-page-info');
            if (pageInfo) pageInfo.textContent = `${from}-${to} of ${_dlqTotal}`;
            const prevBtn = document.getElementById('dlq-prev-btn');
            const nextBtn = document.getElementById('dlq-next-btn');
            if (prevBtn) prevBtn.disabled = _dlqOffset === 0;
            if (nextBtn) nextBtn.disabled = (_dlqOffset + _DLQ_PAGE_SIZE) >= _dlqTotal;
        }
    } catch (err) {
        listEl.innerHTML = `<div style="color:#ef4444;padding:1rem;">Network error: ${_escHtml(err.message)}</div>`;
    }
}

function dlqChangePage(direction) {
    _dlqOffset = Math.max(0, _dlqOffset + direction * _DLQ_PAGE_SIZE);
    loadDeadLetters();
}

function _renderDlqEntry(e) {
    const failedAt = e.created_at ? new Date(e.created_at).toLocaleString() : '-';
    const replayedAt = e.replayed_at ? new Date(e.replayed_at).toLocaleString() : 'Never';

    let statusBadge;
    if (!e.replay_status) {
        statusBadge = '<span style="font-size:0.75rem;color:#f59e0b;border:1px solid #f59e0b;border-radius:4px;padding:0.1rem 0.4rem;">pending</span>';
    } else if (e.replay_status === 'success') {
        statusBadge = '<span style="font-size:0.75rem;color:#22c55e;border:1px solid #22c55e;border-radius:4px;padding:0.1rem 0.4rem;">replayed</span>';
    } else {
        statusBadge = '<span style="font-size:0.75rem;color:#ef4444;border:1px solid #ef4444;border-radius:4px;padding:0.1rem 0.4rem;">replay failed</span>';
    }

    const rawPayload = e.payload ? JSON.stringify(e.payload, null, 2) : '-';
    const preview = _escHtml(rawPayload.substring(0, 400)) + (rawPayload.length > 400 ? '\n...' : '');
    const replayDisabled = e.replay_status === 'success' ? 'disabled title="Already replayed successfully"' : '';

    return `<div style="border:1px solid var(--border-color);border-radius:6px;padding:0.9rem;margin-bottom:0.65rem;background:var(--card-bg);">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;">
            <div style="flex:1;min-width:0;">
                <div style="font-weight:600;font-size:0.9rem;margin-bottom:0.2rem;">
                    <code style="font-size:0.78rem;">${_escHtml(e.id)}</code>&nbsp;${statusBadge}
                </div>
                <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:0.2rem;">
                    Producer: <code style="font-size:0.78rem;">${_escHtml(e.producer_id || '-')}</code>
                    &nbsp;·&nbsp; Endpoint: <code style="font-size:0.78rem;">${_escHtml(e.endpoint || '-')}</code>
                </div>
                <div style="font-size:0.8rem;color:#ef4444;margin-bottom:0.25rem;">Error: ${_escHtml(e.error || '-')}</div>
                <details style="font-size:0.78rem;color:var(--text-muted);">
                    <summary style="cursor:pointer;">Payload preview</summary>
                    <pre style="margin:0.4rem 0 0;background:var(--bg-primary);border-radius:4px;padding:0.5rem;overflow-x:auto;font-size:0.75rem;white-space:pre-wrap;word-break:break-all;">${preview}</pre>
                </details>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:0.3rem;">
                    Failed: ${failedAt} · Last replay: ${replayedAt}
                    ${e.replayed_by ? ' by ' + _escHtml(e.replayed_by) : ''}
                    ${e.replay_error ? '<span style="color:#ef4444;"> · ' + _escHtml(e.replay_error) + '</span>' : ''}
                </div>
            </div>
            <div style="display:flex;flex-direction:column;gap:0.4rem;flex-shrink:0;">
                <button class="btn btn-small" onclick="replayDlqEntry('${_escHtml(e.id)}')" ${replayDisabled}>Replay</button>
                <button class="btn btn-small btn-danger" onclick="deleteDlqEntry('${_escHtml(e.id)}')">Dismiss</button>
            </div>
        </div>
    </div>`;
}

async function replayDlqEntry(dlqId) {
    if (!_externalSourcesRoleAllowed) {
        _setPanelNotice('Dead-letter replay requires the SuperAdmin role.', 'warning');
        return;
    }

    try {
        const resp = await _externalSourcesFetch(`/api/external-sources/dead-letters/${encodeURIComponent(dlqId)}/replay`, {
            method: 'POST',
            headers: { 'X-Ingest-Contract-Version': '1' },
            credentials: 'same-origin',
        });
        const data = await resp.json();
        if (!resp.ok || !data.success) {
            alert('Replay failed: ' + (data.error || `HTTP ${resp.status}`));
        }
        await loadDeadLetters();
    } catch (err) {
        alert('Network error: ' + err.message);
    }
}

async function deleteDlqEntry(dlqId) {
    if (!_externalSourcesRoleAllowed) {
        _setPanelNotice('Dead-letter dismissal requires the SuperAdmin role.', 'warning');
        return;
    }

    if (!confirm(`Permanently dismiss dead-letter entry ${dlqId}?\n\nThis cannot be undone.`)) return;
    try {
        const resp = await _externalSourcesFetch(`/api/external-sources/dead-letters/${encodeURIComponent(dlqId)}`, {
            method: 'DELETE',
            headers: { 'X-Ingest-Contract-Version': '1' },
            credentials: 'same-origin',
        });
        const data = await resp.json();
        if (!resp.ok || !data.success) {
            alert('Dismiss failed: ' + (data.error || `HTTP ${resp.status}`));
        }
        await loadDeadLetters();
    } catch (err) {
        alert('Network error: ' + err.message);
    }
}

async function initExternalSourcesPanel() {
    _externalSourcesRoleAllowed = await checkExternalSourcesRoleAccess();
    if (!_externalSourcesRoleAllowed) {
        _setPanelNotice('External Sources management requires the SuperAdmin role and the Advanced Operations Pack add-on.', 'warning');
        _togglePushSettingsForm(false, 'External Sources management requires the SuperAdmin role.');
        await loadExternalSources();
        await loadDeadLetters();
        return;
    }

    if (!(await _ensureExternalSourcesUnlocked())) {
        _setPanelNotice('Secondary authentication is required before External Sources access is granted.', 'warning');
        _togglePushSettingsForm(false, 'Unlock External Sources with your password to continue.');
        return;
    }

    await loadExternalPushLicenseStatus();
    if (_pushSettingsEnabled) {
        await loadPushIngestAdminSettings();
    }
    await loadExternalSources();
    await loadDeadLetters();
}

document.addEventListener('DOMContentLoaded', () => {
    const saveBtn = document.getElementById('ext-push-save-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', savePushIngestAdminSettings);
    }

    document.addEventListener('adminPanelChanged', (e) => {
        if (e.detail && e.detail.section === 'external-sources') {
            initExternalSourcesPanel();
        }
    });
});
