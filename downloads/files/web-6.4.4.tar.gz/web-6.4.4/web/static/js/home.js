/**
 * Home page JavaScript
 * Handles tab navigation from home page to console
 * Also handles home tab in console
 */

document.addEventListener('DOMContentLoaded', function() {
    // Handle tab navigation from home page
    document.querySelectorAll('.nav-link[data-tab]').forEach(function(link) {
        link.addEventListener('click', function(e) {
            var tab = e.currentTarget.dataset.tab;
            sessionStorage.setItem('initialTab', tab);
        });
    });

    // Console home tab functionality
    setupHomeNavigation();
    loadHomeStats();
    setupHomeLicenseActions();
    refreshHomeLicenseStatus();
});

function getHomeApiKey() {
    return localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
}

function homeFetch(url, options = {}) {
    const headers = { ...(options.headers || {}) };
    const apiKey = getHomeApiKey();
    if (apiKey && !headers['X-API-Key']) {
        headers['X-API-Key'] = apiKey;
    }

    return fetch(url, {
        credentials: 'include',
        ...options,
        headers
    });
}

/**
 * Setup home navigation links to switch tabs
 */
function setupHomeNavigation() {
    const navLinks = document.querySelectorAll('.home-nav-link[data-navigate], .tab-breadcrumb-home[data-navigate]');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const tabName = this.getAttribute('data-navigate');

            // Find and click the tab button
            const tabButton = document.querySelector(`.tab-button[data-tab="${tabName}"]`);
            if (tabButton) {
                tabButton.click();
            }
        });
    });
}

/**
 * Load and display home stats
 */
function loadHomeStats() {
    // Server count
    updateServerCount();

    // Hypervisor count
    updateHypervisorCount();

    // Audit count
    updateAuditCount();

    // Plan count
    updatePlanCount();

    // Report count
    updateReportCount();

    // Storage usage
    updateStorageUsage();
}

function updateServerCount() {
    homeFetch('/api/servers')
        .then(response => response.json())
        .then(data => {
            const count = data.servers ? data.servers.length : 0;
            const el = document.getElementById('home-server-count');
            if (el) el.textContent = count;
        })
        .catch(() => {
            const el = document.getElementById('home-server-count');
            if (el) el.textContent = '0';
        });
}

function updateHypervisorCount() {
    homeFetch('/api/hypervisors/stats')
        .then(response => response.json())
        .then(data => {
            const count = data.stats && data.stats.total ? data.stats.total : 0;
            const el = document.getElementById('home-hypervisor-count');
            if (el) el.textContent = count;
        })
        .catch(() => {
            const el = document.getElementById('home-hypervisor-count');
            if (el) el.textContent = '0';
        });
}

function updateAuditCount() {
    homeFetch('/api/audits')
        .then(response => response.json())
        .then(data => {
            let count = 0;
            if (data.audits) {
                // Count all audits across categories
                if (Array.isArray(data.audits)) {
                    count = data.audits.length;
                } else {
                    Object.values(data.audits).forEach(category => {
                        if (Array.isArray(category)) {
                            count += category.length;
                        }
                    });
                }
            }
            const el = document.getElementById('home-audit-count');
            if (el) el.textContent = count;
        })
        .catch(() => {
            const el = document.getElementById('home-audit-count');
            if (el) el.textContent = '0';
        });
}

function updatePlanCount() {
    homeFetch('/api/plans')
        .then(response => response.json())
        .then(data => {
            const count = data.plans ? data.plans.length : 0;
            const el = document.getElementById('home-plan-count');
            if (el) el.textContent = count;
        })
        .catch(() => {
            const el = document.getElementById('home-plan-count');
            if (el) el.textContent = '0';
        });
}

function updateReportCount() {
    homeFetch('/api/history?limit=1000')
        .then(response => response.json())
        .then(data => {
            const count = data.reports ? data.reports.length : 0;
            const el = document.getElementById('home-report-count');
            if (el) el.textContent = count;
        })
        .catch(() => {
            const el = document.getElementById('home-report-count');
            if (el) el.textContent = '0';
        });
}

function updateStorageUsage() {
    const auditStorageEl = document.getElementById('home-storage-usage');
    const auditSubstatusEl = document.getElementById('home-storage-substatus');
    const diskFreeEl = document.getElementById('home-disk-free');
    const diskStatusEl = document.getElementById('home-disk-status');
    const diskCardEl = document.getElementById('home-disk-space-card');

    if (!auditStorageEl || !diskFreeEl) return;

    if (diskCardEl) {
        diskCardEl.classList.remove('warning', 'critical');
    }

    Promise.all([
        homeFetch('/api/admin/storage/stats').then(response => {
            if (!response.ok) {
                throw new Error('Storage stats unavailable');
            }
            return response.json();
        }),
        homeFetch('/api/dashboard/storage-pressure').then(response => {
            if (!response.ok) {
                throw new Error('Storage pressure unavailable');
            }
            return response.json();
        })
    ])
        .then(([statsData, pressureResponse]) => {
            // Audit Data Storage Card
            const totalSize = Number(statsData?.stats?.total_size || 0);
            const totalFiles = Number(statsData?.stats?.total_files || 0);
            auditStorageEl.textContent = formatHomeBytes(totalSize);
            auditStorageEl.title = `${totalFiles.toLocaleString()} files`;
            if (auditSubstatusEl) {
                auditSubstatusEl.textContent = `${totalFiles.toLocaleString()} audit files`;
            }

            const pressure = pressureResponse?.storage_pressure;
            if (!pressure) {
                diskFreeEl.textContent = 'N/A';
                if (diskStatusEl) diskStatusEl.textContent = 'Threshold data unavailable';
                return;
            }

            // System Disk Space Card
            const overallLevel = String(pressure.overall_level || '').toLowerCase();
            const diskWatermark = pressure.disk_watermark || {};
            const dbUsage = pressure.database || {};

            const diskFreeMb = diskWatermark.free_mb != null ? diskWatermark.free_mb : 'N/A';
            const diskFreePct = diskWatermark.free_pct != null ? diskWatermark.free_pct : 'N/A';
            diskFreeEl.textContent = typeof diskFreePct === 'number' ? `${diskFreePct}%` : diskFreePct;
            diskFreeEl.title = `${diskFreeMb} MB free`;

            const diskReasons = [];
            if (diskWatermark.ingest_blocked) {
                diskReasons.push('Ingest blocked by low disk watermark');
            } else if (diskWatermark.level === 'warning') {
                diskReasons.push('Disk space approaching guardrail threshold');
            } else if (diskWatermark.level === 'critical') {
                diskReasons.push('CRITICAL: Disk space critical');
            }

            const dbReasons = [];
            if (dbUsage.level === 'critical' || dbUsage.level === 'warning') {
                const dbPct = typeof dbUsage.usage_pct === 'number' ? `${Math.round(dbUsage.usage_pct)}%` : 'N/A';
                dbReasons.push(`Database retention: ${dbPct}`);
            }

            if (diskCardEl) {
                diskCardEl.classList.remove('warning', 'critical');
                if (overallLevel === 'critical') {
                    diskCardEl.classList.add('critical');
                } else if (overallLevel === 'warning') {
                    diskCardEl.classList.add('warning');
                }
            }

            if (diskStatusEl) {
                if (overallLevel === 'critical') {
                    diskStatusEl.textContent = diskReasons.length > 0 ? diskReasons[0] : 'ALERT: Storage guardrail breached';
                } else if (overallLevel === 'warning') {
                    diskStatusEl.textContent = diskReasons.length > 0 ? diskReasons[0] : 'Warning: Disk space nearing guardrail';
                } else {
                    diskStatusEl.textContent = 'OK: Healthy';
                }
                if (dbReasons.length > 0) {
                    diskStatusEl.title = [diskReasons[0] || '', ...dbReasons].filter(Boolean).join(' | ');
                }
            }
        })
        .catch(() => {
            auditStorageEl.textContent = 'N/A';
            auditStorageEl.title = 'Storage stats unavailable';
            if (auditSubstatusEl) auditSubstatusEl.textContent = 'Unavailable';
            diskFreeEl.textContent = 'N/A';
            if (diskStatusEl) diskStatusEl.textContent = 'Disk metrics unavailable';
        });
}

function formatHomeBytes(bytes) {
    if (!bytes || bytes <= 0) return '0 B';
    const unit = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const sizeIndex = Math.floor(Math.log(bytes) / Math.log(unit));
    const value = bytes / Math.pow(unit, sizeIndex);
    return `${value.toFixed(sizeIndex === 0 ? 0 : 1)} ${sizes[sizeIndex]}`;
}

function setupHomeLicenseActions() {
    const button = document.getElementById('home-license-apply');
    const input = document.getElementById('home-license-key');

    if (!button || !input) {
        return;
    }

    button.addEventListener('click', applyHomeLicenseKey);
    input.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            applyHomeLicenseKey();
        }
    });
}

function setHomeLicenseStatus(message, level) {
    const status = document.getElementById('home-license-status');
    if (!status) {
        return;
    }

    status.classList.remove('success', 'error');
    if (level === 'success') {
        status.classList.add('success');
    } else if (level === 'error') {
        status.classList.add('error');
    }
    status.textContent = message;
}

function setHomeLicenseApplyDisabled(disabled) {
    const button = document.getElementById('home-license-apply');
    if (button) {
        button.disabled = disabled;
    }
}

async function refreshHomeLicenseStatus() {
    const statusNode = document.getElementById('home-license-status');
    if (!statusNode) {
        return;
    }

    try {
        const response = await homeFetch('/api/license/status');
        const data = await response.json();
        const license = (data && data.license) || {};
        const tier = String(license.tier || 'free').toUpperCase();
        const expires = license.expires || 'Never';
        setHomeLicenseStatus(`Current license: ${tier} (expires: ${expires})`, '');
    } catch (_error) {
        setHomeLicenseStatus('Unable to read current license status.', 'error');
    }
}

async function applyHomeLicenseKey() {
    const input = document.getElementById('home-license-key');
    if (!input) {
        return;
    }

    const key = input.value.trim();
    if (!key) {
        setHomeLicenseStatus('Please enter a license key.', 'error');
        return;
    }

    setHomeLicenseApplyDisabled(true);
    setHomeLicenseStatus('Applying license key...', '');

    try {
        const keygenResponse = await homeFetch('/api/license/keygen/validate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key })
        });
        const keygenPayload = await keygenResponse.json();

        if (keygenResponse.ok && keygenPayload.success) {
            let statusMsg;
            if (keygenPayload.addon) {
                const addons = (keygenPayload.addons_applied || []).join(', ') || 'add-on';
                statusMsg = `Add-on activated: ${addons}.`;
            } else {
                const tier = String(keygenPayload.tier || 'unknown').toUpperCase();
                statusMsg = `License applied successfully. Active tier: ${tier}.`;
            }
            setHomeLicenseStatus(statusMsg, 'success');
            input.value = '';
            await refreshHomeLicenseStatus();
            return;
        }

        if (keygenPayload && keygenPayload.code === 'KEYGEN_NOT_CONFIGURED') {
            const fallbackResponse = await homeFetch('/api/license/activate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key })
            });
            const fallbackPayload = await fallbackResponse.json();

            if (fallbackResponse.ok && fallbackPayload.success) {
                const tier = String(fallbackPayload.tier || 'unknown').toUpperCase();
                setHomeLicenseStatus(`License applied successfully. Active tier: ${tier}.`, 'success');
                input.value = '';
                await refreshHomeLicenseStatus();
                return;
            }

            const fallbackError = fallbackPayload.error || fallbackPayload.message || 'License activation failed.';
            setHomeLicenseStatus(fallbackError, 'error');
            return;
        }

        const errorMessage = keygenPayload.error || keygenPayload.message || 'License activation failed.';
        setHomeLicenseStatus(errorMessage, 'error');
    } catch (_error) {
        setHomeLicenseStatus('License activation failed due to a network or server error.', 'error');
    } finally {
        setHomeLicenseApplyDisabled(false);
    }
}

// Make loadHomeStats available globally for refresh
window.refreshHomeStats = loadHomeStats;

/**
 * Toggle disclaimer visibility
 */
function toggleDisclaimer(event) {
    event.preventDefault();
    const toggle = event.currentTarget;
    const content = document.getElementById('disclaimerContent');

    if (content.classList.contains('show')) {
        content.classList.remove('show');
        toggle.classList.remove('expanded');
    } else {
        content.classList.add('show');
        toggle.classList.add('expanded');
    }
}

// Make toggleDisclaimer available globally
window.toggleDisclaimer = toggleDisclaimer;
