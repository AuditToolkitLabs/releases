/**
 * Hypervisor Wizard - Simplified version following main wizard pattern
 *
 * This wizard handles hypervisor onboarding with modes:
 * - New: connect → discovery → audits → configure → schedule → run → review → export
 * - Existing: hypervisors → discovery → audits → configure → schedule → run → review → export
 */
(function() {
    'use strict';

    // Step names for the hypervisor wizard (all modes)
    const HV_STEPS_NEW = ['connect', 'discovery', 'audits', 'configure', 'schedule', 'run', 'review', 'export'];
    const HV_STEPS_EXISTING = ['hypervisors', 'discovery', 'audits', 'configure', 'schedule', 'run', 'review', 'export'];
    let HV_STEPS = HV_STEPS_NEW;

    // Port defaults by hypervisor type
    const PORT_DEFAULTS = {
        esxi: 443,
        vcenter: 443,
        proxmox: 8006,
        xen: 443,
        kvm: 22,
        nutanix: 9440
    };

    const HYPERVISOR_TYPE_LABELS = {
        esxi: 'ESXi',
        vcenter: 'vCenter',
        proxmox: 'Proxmox',
        xen: 'Xen',
        kvm: 'KVM',
        nutanix: 'Nutanix'
    };

    // Current state
    let currentStep = 'connect';
    let currentMode = 'new';
    let existingHypervisors = [];

    function getHvWizardApiKey() {
        return localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
    }

    function hvWizardFetch(url, options = {}) {
        const headers = { ...(options.headers || {}) };
        const apiKey = getHvWizardApiKey();
        if (apiKey && !headers['X-API-Key']) {
            headers['X-API-Key'] = apiKey;
        }

        return fetch(url, {
            credentials: 'include',
            ...options,
            headers
        });
    }

    // ============================================
    // Mode Switching (New / Existing)
    // ============================================
    function setMode(mode) {
        console.log('[HV-Wizard] Setting mode:', mode);
        currentMode = mode;

        const modal = document.getElementById('hypervisor-wizard-modal');
        if (!modal) return;

        // Update steps array based on mode
        HV_STEPS = (mode === 'existing') ? HV_STEPS_EXISTING : HV_STEPS_NEW;

        // Update mode buttons
        modal.querySelectorAll('.hv-wizard-mode-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });

        // Show/hide nav items based on mode
        // First step varies by mode
        const connectNav = modal.querySelector('.hv-wizard-nav-item[data-step="connect"]');
        const hypervisorsNav = modal.querySelector('.hv-wizard-nav-item[data-step="hypervisors"]');

        if (connectNav) connectNav.style.display = mode === 'new' ? '' : 'none';
        if (hypervisorsNav) hypervisorsNav.style.display = mode === 'existing' ? '' : 'none';

        // Go to first step of current mode
        const firstStep = (mode === 'existing') ? 'hypervisors' : 'connect';
        goToStep(firstStep);

        if (mode === 'existing') {
            loadExistingHypervisors();
        }
    }

    // ============================================
    // Step Navigation (follows wizard.js pattern)
    // ============================================
    function goToStep(stepName) {
        console.log('[HV-Wizard] Going to step:', stepName);

        // Update navigation - remove active from all
        const modal = document.getElementById('hypervisor-wizard-modal');
        if (!modal) {
            console.error('[HV-Wizard] Modal not found!');
            return;
        }

        const navItems = modal.querySelectorAll('.hv-wizard-nav-item');
        console.log('[HV-Wizard] Found nav items:', navItems.length);
        navItems.forEach(item => {
            item.classList.remove('active');
        });

        // Add active to matching nav item
        const activeNav = modal.querySelector('.hv-wizard-nav-item[data-step="' + stepName + '"]');
        if (activeNav) {
            activeNav.classList.add('active');
            console.log('[HV-Wizard] Set nav active:', stepName);
        } else {
            console.warn('[HV-Wizard] Nav item not found for step:', stepName);
        }

        // Update content panels - hide all (all modes)
        console.log('[HV-Wizard] Hiding all step panels...');
        const allSteps = [...new Set([...HV_STEPS_NEW, ...HV_STEPS_EXISTING])];
        allSteps.forEach(step => {
            const panel = document.getElementById('hv-wizard-step-' + step);
            if (panel) {
                panel.classList.remove('active');
                panel.style.display = 'none';
                console.log('[HV-Wizard] Hidden panel:', step);
            }
        });

        // Show target step
        const targetStep = document.getElementById('hv-wizard-step-' + stepName);
        if (targetStep) {
            targetStep.classList.add('active');
            targetStep.style.display = 'flex';
            console.log('[HV-Wizard] Activated step:', stepName, 'display:', targetStep.style.display);

            // Force visibility check
            const computed = window.getComputedStyle(targetStep);
            console.log('[HV-Wizard] Computed display:', computed.display, 'visibility:', computed.visibility);
        } else {
            console.error('[HV-Wizard] Target step panel not found:', 'hv-wizard-step-' + stepName);
        }

        currentStep = stepName;
    }

    // ============================================
    // Open/Close Wizard
    // ============================================
    function openWizard() {
        const modal = document.getElementById('hypervisor-wizard-modal');
        if (modal) {
            modal.style.display = 'flex';
            goToStep('connect');
            console.log('[HV-Wizard] Wizard opened');
        }
    }

    function closeWizard() {
        const modal = document.getElementById('hypervisor-wizard-modal');
        if (modal) {
            modal.style.display = 'none';
            console.log('[HV-Wizard] Wizard closed');
        }
    }

    // ============================================
    // Form Handlers
    // ============================================
    function updateAuthFields() {
        const authMethod = document.getElementById('hv-wizard-auth-method');
        const passwordGroup = document.getElementById('hv-wizard-password-group');
        const tokenGroup = document.getElementById('hv-wizard-token-group');

        if (!authMethod) return;

        const method = authMethod.value;
        if (passwordGroup) passwordGroup.style.display = (method === 'password' || method === 'key') ? '' : 'none';
        if (tokenGroup) tokenGroup.style.display = method === 'token' ? '' : 'none';
    }

    function updatePortDefault() {
        const typeSelect = document.getElementById('hv-wizard-type');
        const portInput = document.getElementById('hv-wizard-port');

        if (!portInput || !typeSelect) return;

        portInput.value = PORT_DEFAULTS[typeSelect.value] || 443;
    }

    // ============================================
    // Connection Method Handling
    // ============================================
    function updateConnectionMethod() {
        const methodRadios = document.querySelectorAll('input[name="hv-wizard-method"]');
        const portHint = document.querySelector('.wizard-port-hint');
        const portInput = document.getElementById('hv-wizard-port');

        let selectedMethod = 'api';
        methodRadios.forEach(radio => {
            if (radio.checked) {
                selectedMethod = radio.value;
            }
        });

        // Update port hint based on method
        if (portHint) {
            if (selectedMethod === 'ssh') {
                portHint.textContent = 'Default: 22 (SSH)';
                if (portInput) portInput.value = 22;
            } else {
                portHint.textContent = 'Default: 443 (HTTPS API)';
                updatePortDefault(); // Restore port based on hypervisor type
            }
        }

        // Update protocol badge
        const protocolBadge = document.querySelector('.wizard-protocol-badge');
        const protocolDesc = document.querySelector('.wizard-protocol-desc');
        if (protocolBadge && protocolDesc) {
            if (selectedMethod === 'ssh') {
                protocolBadge.textContent = '🔐 SSH';
                protocolDesc.textContent = 'Secure shell connection';
            } else {
                protocolBadge.textContent = '🔌 HTTPS API';
                protocolDesc.textContent = 'Direct API connection';
            }
        }
    }

    // ============================================
    // Audit Selection Helpers
    // ============================================
    function selectAllAudits() {
        document.querySelectorAll('.wizard-audit-option input[type="checkbox"]').forEach(cb => {
            cb.checked = true;
        });
    }

    function clearAllAudits() {
        document.querySelectorAll('.wizard-audit-option input[type="checkbox"]').forEach(cb => {
            cb.checked = false;
        });
    }

    function selectSecurityAudits() {
        clearAllAudits();
        const securityAudits = ['security', 'hardening', 'network'];
        document.querySelectorAll('.wizard-audit-option input[type="checkbox"]').forEach(cb => {
            if (securityAudits.includes(cb.value)) {
                cb.checked = true;
            }
        });
    }

    // ============================================
    // Discovery Scan
    // ============================================
    async function startDiscoveryScan() {
        const scanBtn = document.getElementById('hv-wizard-scan-btn');
        const statusSpan = document.getElementById('hv-scan-status');
        const resultsDiv = document.getElementById('hv-discovery-results');
        const statsDiv = document.getElementById('hv-discovery-stats');

        if (!scanBtn) return;

        scanBtn.disabled = true;
        scanBtn.textContent = '⏳ Scanning...';
        if (statusSpan) statusSpan.textContent = 'Connecting to hypervisor...';

        // Simulate discovery (replace with actual API call)
        setTimeout(() => {
            if (statusSpan) statusSpan.textContent = 'Discovering virtual machines...';
        }, 1000);

        setTimeout(() => {
            scanBtn.disabled = false;
            scanBtn.textContent = '🔍 Rescan';
            if (statusSpan) statusSpan.innerHTML = '<span style="color: #10b981;">✅ Discovery complete</span>';

            // Show mock results
            if (resultsDiv) {
                resultsDiv.innerHTML = `
                    <div class="discovery-list">
                        <div class="discovery-item">
                            <span class="item-icon">💻</span>
                            <span class="item-name">web-server-01</span>
                            <span class="item-status status-running">Running</span>
                        </div>
                        <div class="discovery-item">
                            <span class="item-icon">💻</span>
                            <span class="item-name">db-server-01</span>
                            <span class="item-status status-running">Running</span>
                        </div>
                        <div class="discovery-item">
                            <span class="item-icon">💻</span>
                            <span class="item-name">app-server-01</span>
                            <span class="item-status status-stopped">Stopped</span>
                        </div>
                    </div>
                `;
            }

            // Show stats
            if (statsDiv) {
                statsDiv.style.display = '';
                document.getElementById('hv-stat-vms').textContent = '3';
                document.getElementById('hv-stat-hosts').textContent = '1';
                document.getElementById('hv-stat-datastores').textContent = '2';
                document.getElementById('hv-stat-networks').textContent = '1';
            }
        }, 2500);
    }

    // ============================================
    // Run Audit
    // ============================================
    function updateRunSummary() {
        let name = document.getElementById('hv-wizard-name')?.value || '-';
        let method = 'api';

        if (currentMode === 'existing') {
            const selected = getSelectedExistingHypervisors();
            if (selected.length > 0) {
                name = selected.length === 1
                    ? selected[0].name
                    : `${selected[0].name} (+${selected.length - 1} more)`;

                const methods = new Set(selected.map(hv => (hv.connection_method || 'api').toLowerCase()));
                if (methods.size === 1) {
                    method = methods.has('ssh') ? 'ssh' : 'api';
                } else {
                    method = 'mixed';
                }
            }
        } else {
            const methodRadios = document.querySelectorAll('input[name="hv-wizard-method"]');
            methodRadios.forEach(r => { if (r.checked) method = r.value; });
        }

        const checkedAudits = document.querySelectorAll('.wizard-audit-option input:checked').length;

        if (document.getElementById('hv-run-target')) {
            document.getElementById('hv-run-target').textContent = name;
        }
        if (document.getElementById('hv-run-method')) {
            document.getElementById('hv-run-method').textContent = method === 'mixed'
                ? 'Mixed (Configured per hypervisor)'
                : (method === 'api' ? 'Direct API' : 'SSH');
        }
        if (document.getElementById('hv-run-checks')) {
            document.getElementById('hv-run-checks').textContent = checkedAudits;
        }
    }

    async function runAudit() {
        const runBtn = document.getElementById('hv-wizard-run-btn');
        const progressSection = document.getElementById('hv-run-progress');
        const resultsSection = document.getElementById('hv-run-results');
        const progressBar = document.getElementById('hv-progress-bar');
        const progressText = document.getElementById('hv-progress-text');
        const progressPercent = document.getElementById('hv-progress-percent');
        const liveLog = document.getElementById('hv-live-log');

        if (!runBtn) return;

        runBtn.disabled = true;
        runBtn.textContent = '⏳ Running...';

        // Show progress section
        if (progressSection) progressSection.style.display = '';
        if (resultsSection) resultsSection.style.display = 'none';

        // Simulate progress
        const steps = [
            { progress: 10, text: 'Connecting to hypervisor...', log: '🔗 Establishing connection' },
            { progress: 25, text: 'Running security audits...', log: '🔐 Checking lockdown mode' },
            { progress: 40, text: 'Auditing network config...', log: '🌐 Analyzing vSwitch settings' },
            { progress: 55, text: 'Checking VM hardening...', log: '💻 Scanning VM configurations' },
            { progress: 70, text: 'Verifying storage...', log: '💾 Checking datastore permissions' },
            { progress: 85, text: 'Finalizing results...', log: '📊 Compiling audit report' },
            { progress: 100, text: 'Complete!', log: '✅ Audit completed successfully' }
        ];

        let stepIndex = 0;
        const interval = setInterval(() => {
            if (stepIndex >= steps.length) {
                clearInterval(interval);
                showAuditResults();
                return;
            }

            const step = steps[stepIndex];
            if (progressBar) progressBar.style.width = step.progress + '%';
            if (progressText) progressText.textContent = step.text;
            if (progressPercent) progressPercent.textContent = step.progress + '%';
            if (liveLog) {
                const logClass = step.progress === 100 ? 'log-success' : '';
                liveLog.innerHTML += `<div class="log-entry ${logClass}">${step.log}</div>`;
                liveLog.scrollTop = liveLog.scrollHeight;
            }

            stepIndex++;
        }, 800);
    }

    function showAuditResults() {
        const runBtn = document.getElementById('hv-wizard-run-btn');
        const toReviewBtn = document.getElementById('hv-wizard-to-review');

        if (runBtn) {
            runBtn.disabled = false;
            runBtn.textContent = '🔄 Run Again';
        }

        // Show the "View Results" button
        if (toReviewBtn) {
            toReviewBtn.style.display = '';
        }

        // Update review step with results
        const passCount = 42;
        const warnCount = 7;
        const failCount = 3;
        const skipCount = 2;

        if (document.getElementById('hv-review-pass')) {
            document.getElementById('hv-review-pass').textContent = passCount;
        }
        if (document.getElementById('hv-review-warn')) {
            document.getElementById('hv-review-warn').textContent = warnCount;
        }
        if (document.getElementById('hv-review-fail')) {
            document.getElementById('hv-review-fail').textContent = failCount;
        }
        if (document.getElementById('hv-review-skip')) {
            document.getElementById('hv-review-skip').textContent = skipCount;
        }

        // Populate findings list with mock data
        const findingsList = document.getElementById('hv-findings-list');
        if (findingsList) {
            findingsList.innerHTML = `
                <div class="finding-item finding-fail">
                    <span class="finding-status">❌</span>
                    <span class="finding-name">SSH Enabled on ESXi Host</span>
                    <span class="finding-severity">Critical</span>
                </div>
                <div class="finding-item finding-fail">
                    <span class="finding-status">❌</span>
                    <span class="finding-name">Lockdown Mode Disabled</span>
                    <span class="finding-severity">High</span>
                </div>
                <div class="finding-item finding-fail">
                    <span class="finding-status">❌</span>
                    <span class="finding-name">Expired SSL Certificate</span>
                    <span class="finding-severity">Medium</span>
                </div>
                <div class="finding-item finding-warn">
                    <span class="finding-status">⚠️</span>
                    <span class="finding-name">VM Copy/Paste Not Disabled</span>
                    <span class="finding-severity">Low</span>
                </div>
                <div class="finding-item finding-warn">
                    <span class="finding-status">⚠️</span>
                    <span class="finding-name">Snapshots Older Than 7 Days</span>
                    <span class="finding-severity">Low</span>
                </div>
                <div class="finding-item finding-pass">
                    <span class="finding-status">✅</span>
                    <span class="finding-name">vSwitch Security Policies</span>
                    <span class="finding-severity">-</span>
                </div>
            `;
        }
    }

    // ============================================
    // Schedule Handlers
    // ============================================
    function toggleScheduleConfig() {
        const scheduleMode = document.querySelector('input[name="hv-schedule-mode"]:checked');
        const scheduleConfig = document.getElementById('hv-schedule-config');

        if (scheduleConfig) {
            scheduleConfig.style.display = scheduleMode && scheduleMode.value === 'schedule' ? '' : 'none';
        }

        // Update schedule preview
        updateSchedulePreview();
    }

    function updateScheduleFrequency() {
        const frequency = document.getElementById('hv-schedule-frequency')?.value;
        const dayGroup = document.getElementById('hv-schedule-day-group');
        const cronGroup = document.getElementById('hv-schedule-cron-group');

        if (dayGroup) dayGroup.style.display = frequency === 'weekly' ? '' : 'none';
        if (cronGroup) cronGroup.style.display = frequency === 'custom' ? '' : 'none';

        updateSchedulePreview();
    }

    function updateSchedulePreview() {
        const name = document.getElementById('hv-wizard-name')?.value || '-';
        const frequency = document.getElementById('hv-schedule-frequency')?.value || 'daily';
        const time = document.getElementById('hv-schedule-time')?.value || '02:00';

        if (document.getElementById('hv-schedule-preview-target')) {
            document.getElementById('hv-schedule-preview-target').textContent = name;
        }

        if (document.getElementById('hv-schedule-preview-freq')) {
            let freqText = frequency.charAt(0).toUpperCase() + frequency.slice(1);
            if (frequency === 'weekly') {
                const daySelect = document.getElementById('hv-schedule-day');
                const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                const dayIndex = daySelect ? parseInt(daySelect.value) : 0;
                freqText = days[dayIndex] + 's';
            }
            document.getElementById('hv-schedule-preview-freq').textContent = freqText + ' at ' + time;
        }

        // Calculate next run
        if (document.getElementById('hv-schedule-preview-next')) {
            const now = new Date();
            const [hours, minutes] = time.split(':').map(Number);
            const next = new Date(now);
            next.setHours(hours, minutes, 0, 0);
            if (next <= now) {
                next.setDate(next.getDate() + 1);
            }
            document.getElementById('hv-schedule-preview-next').textContent = next.toLocaleString();
        }
    }

    function toggleScheduleEmail() {
        const emailCheckbox = document.getElementById('hv-schedule-notify-email');
        const emailGroup = document.getElementById('hv-schedule-email-group');

        if (emailGroup) {
            emailGroup.style.display = emailCheckbox && emailCheckbox.checked ? '' : 'none';
        }
    }

    // ============================================
    // Plan Save Handlers
    // ============================================
    function togglePlanDetails() {
        const checkbox = document.getElementById('hv-config-save-plan');
        const planDetails = document.getElementById('hv-plan-details');

        if (planDetails) {
            planDetails.style.display = checkbox && checkbox.checked ? '' : 'none';
        }
    }

    // ============================================
    // Export Handlers
    // ============================================
    function exportReport(format) {
        showToast(`Exporting ${format.toUpperCase()} report...`, 'info');

        // Simulate export
        setTimeout(() => {
            showToast(`${format.toUpperCase()} report downloaded successfully!`, 'success');
        }, 1000);
    }

    function finishWizard() {
        showToast('Audit workflow complete!', 'success');
        closeWizard();
    }

    // ============================================
    // Hypervisor Selection Helpers (Existing Mode)
    // ============================================
    function updateHypervisorSelectionCount() {
        const checkboxes = document.querySelectorAll('input[name="hv-select"]:checked');
        const count = checkboxes.length;

        const countEl = document.getElementById('hv-selection-count');
        const summaryEl = document.getElementById('hv-wizard-selected-summary');
        const skipBtn = document.getElementById('hv-wizard-skip-audits');

        if (countEl) {
            countEl.textContent = `${count} selected`;
        }
        if (summaryEl) {
            summaryEl.textContent = `${count} hypervisor${count !== 1 ? 's' : ''} selected`;
        }
        if (skipBtn) {
            skipBtn.style.display = count > 0 ? '' : 'none';
        }

        updateRunSummary();
    }

    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        const div = document.createElement('div');
        div.textContent = String(text);
        return div.innerHTML;
    }

    function normalizeHypervisorStatus(status) {
        if (!status) return 'offline';
        if (status === 'online') return 'online';
        if (status === 'warning' || status === 'warn') return 'warning';
        return 'offline';
    }

    function getSelectedExistingHypervisors() {
        const selectedIds = Array.from(document.querySelectorAll('input[name="hv-select"]:checked'))
            .map(cb => parseInt(cb.value, 10))
            .filter(Number.isFinite);

        return existingHypervisors.filter(hv => selectedIds.includes(hv.id));
    }

    function renderExistingHypervisors() {
        const listContainer = document.getElementById('hv-wizard-list');
        if (!listContainer) return;

        if (!existingHypervisors.length) {
            listContainer.innerHTML = '';
            updateHypervisorSelectionCount();
            filterHypervisorList();
            return;
        }

        listContainer.innerHTML = existingHypervisors.map(hv => {
            const status = normalizeHypervisorStatus(hv.status);
            const type = (hv.hypervisor_type || '').toLowerCase();
            const typeLabel = HYPERVISOR_TYPE_LABELS[type] || (hv.hypervisor_type || 'Unknown');
            const methodLabel = (hv.connection_method || 'api').toLowerCase() === 'ssh' ? 'SSH' : 'API';

            return `
                <div class="hv-list-item">
                    <label class="hv-list-checkbox">
                        <input type="checkbox" name="hv-select" value="${hv.id}">
                        <div class="hv-list-content" data-connection-method="${escapeHtml(hv.connection_method || 'api')}">
                            <div class="hv-list-main">
                                <span class="hv-list-icon">🖥️</span>
                                <span class="hv-list-name">${escapeHtml(hv.name || hv.hostname)}</span>
                                <span class="hv-list-type badge-${escapeHtml(type)}">${escapeHtml(typeLabel)}</span>
                            </div>
                            <div class="hv-list-details">
                                <span class="hv-list-vms">${escapeHtml(hv.hostname || '-')}</span>
                                <span class="hv-list-status status-${escapeHtml(status)}">● ${escapeHtml(status.charAt(0).toUpperCase() + status.slice(1))}</span>
                                <span class="hv-list-last-audit">Method: ${escapeHtml(methodLabel)}</span>
                            </div>
                        </div>
                    </label>
                </div>`;
        }).join('');

        listContainer.querySelectorAll('input[name="hv-select"]').forEach(cb => {
            cb.addEventListener('change', updateHypervisorSelectionCount);
        });

        updateHypervisorSelectionCount();
        filterHypervisorList();
    }

    async function loadExistingHypervisors() {
        try {
            const response = await hvWizardFetch('/api/hypervisors?per_page=100');
            const data = await response.json();

            existingHypervisors = data.success ? (data.hypervisors || []) : [];
            renderExistingHypervisors();
        } catch (e) {
            console.error('[HV-Wizard] Failed to load existing hypervisors:', e);
            existingHypervisors = [];
            renderExistingHypervisors();
        }
    }

    function filterHypervisorList() {
        const searchTerm = (document.getElementById('hv-wizard-search')?.value || '').toLowerCase();
        const typeFilter = document.getElementById('hv-wizard-type-filter')?.value || '';
        const statusFilter = document.getElementById('hv-wizard-status-filter')?.value || '';

        const items = document.querySelectorAll('.hv-list-item');
        let visibleCount = 0;

        items.forEach(item => {
            const nameEl = item.querySelector('.hv-list-name');
            const typeEl = item.querySelector('.hv-list-type');
            const statusEl = item.querySelector('.hv-list-status');

            const name = (nameEl?.textContent || '').toLowerCase();
            const type = typeEl?.classList.contains('badge-' + typeFilter) || !typeFilter;
            const statusClass = statusEl?.classList;
            const status = !statusFilter ||
                (statusFilter === 'online' && statusClass?.contains('status-online')) ||
                (statusFilter === 'offline' && statusClass?.contains('status-offline')) ||
                (statusFilter === 'warning' && statusClass?.contains('status-warning'));

            const matchesSearch = !searchTerm || name.includes(searchTerm);
            const matchesType = type;
            const matchesStatus = status;

            if (matchesSearch && matchesType && matchesStatus) {
                item.style.display = '';
                visibleCount++;
            } else {
                item.style.display = 'none';
            }
        });

        // Show/hide empty state
        const emptyState = document.getElementById('hv-list-empty');
        const listContainer = document.getElementById('hv-wizard-list');

        if (emptyState && listContainer) {
            emptyState.style.display = visibleCount === 0 ? '' : 'none';
            listContainer.style.display = visibleCount > 0 ? '' : 'none';
        }
    }

    // Toast helper
    function showToast(message, type) {
        if (typeof window.showToast === 'function') {
            window.showToast(message, type);
        } else {
            console.log('[Toast]', message);
        }
    }

    async function testConnection() {
        const resultSpan = document.getElementById('hv-wizard-test-result');
        const testBtn = document.getElementById('hv-wizard-test-btn');

        if (!resultSpan || !testBtn) return;

        const hostname = document.getElementById('hv-wizard-hostname')?.value;
        const port = document.getElementById('hv-wizard-port')?.value;
        const username = document.getElementById('hv-wizard-username')?.value;

        if (!hostname || !username) {
            resultSpan.innerHTML = '<span style="color: #ef4444;">⚠️ Fill in hostname and username first</span>';
            return;
        }

        testBtn.disabled = true;
        resultSpan.innerHTML = '<span style="color: #6b7280;">⏳ Testing...</span>';

        // Simulate test (replace with actual API call)
        setTimeout(() => {
            testBtn.disabled = false;
            resultSpan.innerHTML = '<span style="color: #10b981;">✅ Connection successful</span>';
        }, 1500);
    }

    // ============================================
    // Event Binding
    // ============================================
    function init() {
        console.log('[HV-Wizard] Initializing...');

        const modal = document.getElementById('hypervisor-wizard-modal');
        if (!modal) {
            console.warn('[HV-Wizard] Modal not found');
            return;
        }

        // Mode button clicks
        modal.querySelectorAll('.hv-wizard-mode-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const mode = btn.dataset.mode;
                if (mode) {
                    setMode(mode);
                }
            });
        });

        // Nav item clicks - direct navigation
        modal.querySelectorAll('.hv-wizard-nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation(); // Prevent main wizard from catching this
                const step = item.dataset.step;
                console.log('[HV-Wizard] Nav item clicked, step:', step);
                if (step) {
                    goToStep(step);
                }
            });
        });

        // Next buttons
        modal.querySelectorAll('.hv-wizard-next').forEach(btn => {
            btn.addEventListener('click', () => {
                const nextStep = btn.dataset.next;
                if (nextStep) {
                    goToStep(nextStep);
                }
            });
        });

        // Previous buttons
        modal.querySelectorAll('.hv-wizard-prev').forEach(btn => {
            btn.addEventListener('click', () => {
                const prevStep = btn.dataset.prev;
                if (prevStep) {
                    goToStep(prevStep);
                }
            });
        });

        // Hypervisor Selection Handlers (Existing Mode)
        const hvSelectAllBtn = document.getElementById('hv-select-all');
        const hvSelectNoneBtn = document.getElementById('hv-select-none');
        const hvSearchInput = document.getElementById('hv-wizard-search');
        const hvTypeFilter = document.getElementById('hv-wizard-type-filter');
        const hvStatusFilter = document.getElementById('hv-wizard-status-filter');

        if (hvSelectAllBtn) {
            hvSelectAllBtn.addEventListener('click', () => {
                modal.querySelectorAll('input[name="hv-select"]').forEach(cb => {
                    if (cb.closest('.hv-list-item')?.style.display !== 'none') {
                        cb.checked = true;
                    }
                });
                updateHypervisorSelectionCount();
            });
        }

        if (hvSelectNoneBtn) {
            hvSelectNoneBtn.addEventListener('click', () => {
                modal.querySelectorAll('input[name="hv-select"]').forEach(cb => {
                    cb.checked = false;
                });
                updateHypervisorSelectionCount();
            });
        }

        // Initial selection state tracking for any pre-rendered list content
        modal.querySelectorAll('input[name="hv-select"]').forEach(cb => {
            cb.addEventListener('change', updateHypervisorSelectionCount);
        });

        // Search and filter
        if (hvSearchInput) {
            hvSearchInput.addEventListener('input', filterHypervisorList);
        }
        if (hvTypeFilter) {
            hvTypeFilter.addEventListener('change', filterHypervisorList);
        }
        if (hvStatusFilter) {
            hvStatusFilter.addEventListener('change', filterHypervisorList);
        }

        // Auth method toggle
        const authMethod = document.getElementById('hv-wizard-auth-method');
        if (authMethod) {
            authMethod.addEventListener('change', updateAuthFields);
        }

        // Hypervisor type changes port default
        const typeSelect = document.getElementById('hv-wizard-type');
        if (typeSelect) {
            typeSelect.addEventListener('change', updatePortDefault);
        }

        // Connection method toggle
        document.querySelectorAll('input[name="hv-wizard-method"]').forEach(radio => {
            radio.addEventListener('change', updateConnectionMethod);
        });

        // Test connection button
        const testBtn = document.getElementById('hv-wizard-test-btn');
        if (testBtn) {
            testBtn.addEventListener('click', testConnection);
        }

        // Discovery scan button
        const scanBtn = document.getElementById('hv-wizard-scan-btn');
        if (scanBtn) {
            scanBtn.addEventListener('click', startDiscoveryScan);
        }

        // Audit selection buttons
        const selectAllBtn = document.getElementById('hv-select-all-audits');
        const selectNoneBtn = document.getElementById('hv-select-none-audits');
        const selectSecurityBtn = document.getElementById('hv-select-security-audits');

        if (selectAllBtn) selectAllBtn.addEventListener('click', selectAllAudits);
        if (selectNoneBtn) selectNoneBtn.addEventListener('click', clearAllAudits);
        if (selectSecurityBtn) selectSecurityBtn.addEventListener('click', selectSecurityAudits);

        // Run audit button
        const runBtn = document.getElementById('hv-wizard-run-btn');
        if (runBtn) {
            runBtn.addEventListener('click', runAudit);
        }

        // Update summary when navigating to run step
        const runNavItem = modal.querySelector('.wizard-nav-item[data-step="run"]');
        if (runNavItem) {
            runNavItem.addEventListener('click', updateRunSummary);
        }
        modal.querySelectorAll('.hv-wizard-next[data-next="run"]').forEach(btn => {
            btn.addEventListener('click', updateRunSummary);
        });

        // Save as Plan checkbox toggle
        const savePlanCheckbox = document.getElementById('hv-config-save-plan');
        if (savePlanCheckbox) {
            savePlanCheckbox.addEventListener('change', togglePlanDetails);
        }

        // Schedule mode toggle
        document.querySelectorAll('input[name="hv-schedule-mode"]').forEach(radio => {
            radio.addEventListener('change', toggleScheduleConfig);
        });

        // Schedule frequency change
        const scheduleFreq = document.getElementById('hv-schedule-frequency');
        if (scheduleFreq) {
            scheduleFreq.addEventListener('change', updateScheduleFrequency);
        }

        // Schedule time change
        const scheduleTime = document.getElementById('hv-schedule-time');
        if (scheduleTime) {
            scheduleTime.addEventListener('change', updateSchedulePreview);
        }

        // Schedule day change
        const scheduleDay = document.getElementById('hv-schedule-day');
        if (scheduleDay) {
            scheduleDay.addEventListener('change', updateSchedulePreview);
        }

        // Schedule email toggle
        const scheduleEmailCheckbox = document.getElementById('hv-schedule-notify-email');
        if (scheduleEmailCheckbox) {
            scheduleEmailCheckbox.addEventListener('change', toggleScheduleEmail);
        }

        // Export buttons
        const exportPdf = document.getElementById('hv-export-pdf');
        const exportHtml = document.getElementById('hv-export-html');
        const exportJson = document.getElementById('hv-export-json');
        const exportCsv = document.getElementById('hv-export-csv');

        if (exportPdf) exportPdf.addEventListener('click', () => exportReport('pdf'));
        if (exportHtml) exportHtml.addEventListener('click', () => exportReport('html'));
        if (exportJson) exportJson.addEventListener('click', () => exportReport('json'));
        if (exportCsv) exportCsv.addEventListener('click', () => exportReport('csv'));

        // Finish button
        const finishBtn = document.getElementById('hv-wizard-finish');
        if (finishBtn) {
            finishBtn.addEventListener('click', finishWizard);
        }

        // Run another audit button
        const runAnotherBtn = document.getElementById('hv-run-another');
        if (runAnotherBtn) {
            runAnotherBtn.addEventListener('click', () => {
                goToStep('connect');
            });
        }

        // Close on backdrop click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeWizard();
            }
        });

        // Escape key to close
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && modal.style.display !== 'none') {
                closeWizard();
            }
        });

        console.log('[HV-Wizard] Initialized successfully');

        // Prime existing list so existing mode reflects current configured hypervisors/methods
        loadExistingHypervisors();
    }

    // Initialize when DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose to global scope
    window.HvWizard = {
        open: openWizard,
        close: closeWizard,
        goToStep: goToStep,
        setMode: setMode
    };

})();
