/**
 * Hypervisors Tab JavaScript
 * Manages hypervisor operations: list, add, edit, delete, test connection, run audit, view history
 */

(function() {
    'use strict';

    // State
    let hypervisors = [];
    let selectedHypervisor = null;
    let licenseStatus = null;  // Cached license status
    let currentUserRole = null;
    let isSuperAdmin = false;
    let canManageConnectionMethod = false;

    function getApiKey() {
        return localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
    }

    function hypervisorFetch(url, options = {}) {
        const headers = { ...(options.headers || {}) };
        const apiKey = getApiKey();
        if (apiKey && !headers['X-API-Key']) {
            headers['X-API-Key'] = apiKey;
        }

        return fetch(url, {
            credentials: 'include',
            ...options,
            headers
        });
    }

    // Hypervisor type metadata
    const hypervisorTypes = {
        esxi: { label: 'VMware ESXi', icon: '🟢', defaultPort: 443 },
        vcenter: { label: 'VMware vCenter', icon: '🔵', defaultPort: 443 },
        proxmox: { label: 'Proxmox VE', icon: '🟠', defaultPort: 8006 },
        xen: { label: 'XCP-ng / Xen', icon: '🟣', defaultPort: 443 },
        kvm: { label: 'KVM / libvirt', icon: '🐧', defaultPort: 22 },
        nutanix: { label: 'Nutanix AHV', icon: '🔶', defaultPort: 9440 },
        xo: { label: 'Xen Orchestra', icon: '🌐', defaultPort: 443 }
    };

    // ==========================================================================
    // License Checking - Hypervisors require Professional+ license
    // ==========================================================================

    /**
     * Check hypervisor license status and update UI accordingly
     */
    async function checkLicenseStatus() {
        try {
            const response = await hypervisorFetch('/api/hypervisors/license-status');
            const data = await response.json();

            licenseStatus = data;

            const licenseBanner = document.getElementById('hypervisors-license-required');
            const licensedContent = document.getElementById('hypervisors-licensed-content');

            if (!data.has_access) {
                // No license - show upgrade banner
                if (licenseBanner) licenseBanner.style.display = 'flex';
                if (licensedContent) licensedContent.style.display = 'none';
                console.log('[Hypervisors] License required - showing upgrade banner');
                return false;
            } else {
                // Has license - show content
                if (licenseBanner) licenseBanner.style.display = 'none';
                if (licensedContent) licensedContent.style.display = 'flex';

                // Show beta banner if applicable
                if (data.beta_enabled) {
                    showBetaBanner();
                }

                // Show tier limits if applicable
                if (data.limits && data.limits.max_hypervisors) {
                    showTierLimits(data.limits);
                }

                console.log(`[Hypervisors] Licensed tier: ${data.tier}`);
                return true;
            }
        } catch (error) {
            console.error('[Hypervisors] License check failed:', error);
            // On error, allow access (fail open for dev/testing)
            const licenseBanner = document.getElementById('hypervisors-license-required');
            const licensedContent = document.getElementById('hypervisors-licensed-content');
            if (licenseBanner) licenseBanner.style.display = 'none';
            if (licensedContent) licensedContent.style.display = 'flex';
            return true;
        }
    }

    /**
     * Show beta testing banner
     */
    function showBetaBanner() {
        const header = document.querySelector('.hypervisors-header');
        if (!header || document.querySelector('.beta-testing-banner')) return;

        const banner = document.createElement('div');
        banner.className = 'beta-testing-banner';
        banner.innerHTML = `
            <span class="beta-icon">🧪</span>
            <div class="beta-content">
                <div class="beta-title">Beta Testing Mode</div>
                <div class="beta-description">
                    Hypervisor features are enabled for beta testing. Some features may be limited.
                </div>
            </div>
        `;
        header.parentNode.insertBefore(banner, header.nextSibling);
    }

    /**
     * Show tier-based limits info
     */
    function showTierLimits(limits) {
        const statsSection = document.querySelector('.hypervisors-stats');
        if (!statsSection || document.querySelector('.tier-limits-info')) return;

        if (limits.max_hypervisors) {
            const info = document.createElement('div');
            info.className = 'tier-limits-info';
            info.style.cssText = 'padding: 0.75rem 1rem; background: var(--bg-secondary); border-radius: 8px; font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 1rem;';
            info.innerHTML = `
                <span style="color: var(--accent-color);">📊 License Limits:</span>
                Using <strong>${limits.current_hypervisors || 0}</strong> of <strong>${limits.max_hypervisors}</strong> hypervisors.
                ${limits.allowed_platforms && limits.allowed_platforms !== 'all' ?
                    `Platforms: ${limits.allowed_platforms.join(', ')}.` : ''}
                <a href="/pricing?feature=hypervisor" style="color: var(--accent-color); margin-left: 0.5rem;">Upgrade for more →</a>
            `;
            statsSection.parentNode.insertBefore(info, statsSection);
        }
    }

    /**
     * Check if a specific feature is available based on license
     */
    function isFeatureAvailable(featureName) {
        if (!licenseStatus || !licenseStatus.features) return true; // Allow if not loaded
        const feature = licenseStatus.features[featureName];
        return feature ? feature.available : true;
    }

    // Initialize when DOM is ready
    function init() {
        bindEventListeners();
        fetchCurrentUserRole();
        console.log('[Hypervisors] Module initialized');
    }

    async function fetchCurrentUserRole() {
        try {
            const response = await hypervisorFetch('/auth/me');
            if (!response.ok) return;

            const data = await response.json();
            currentUserRole = data?.user?.role || null;
            isSuperAdmin = currentUserRole === 'SuperAdmin';
            canManageConnectionMethod = ['Admin', 'SuperAdmin'].includes(currentUserRole);
            applyHypervisorConnectionMethodEditPermission();
            if (hypervisors.length > 0) {
                loadHypervisors();
            }
        } catch (error) {
            console.warn('[Hypervisors] Unable to determine role for connection method editing:', error);
        }
    }

    function applyHypervisorConnectionMethodEditPermission(isEditing = false) {
        const connMethodSelect = document.getElementById('hypervisor-form-connection-method');
        if (!connMethodSelect) return;

        const lockMethodChanges = isEditing && currentUserRole !== null && !canManageConnectionMethod;
        connMethodSelect.disabled = lockMethodChanges;
        connMethodSelect.title = lockMethodChanges
            ? 'Only Admin or SuperAdmin can change connection method for existing hypervisors'
            : '';
    }

    // Bind all event listeners
    function bindEventListeners() {
        // Header buttons
        const refreshBtn = document.getElementById('refresh-hypervisors');
        const addBtn = document.getElementById('add-hypervisor-btn');

        if (refreshBtn) {
            refreshBtn.addEventListener('click', async () => {
                await loadAll();
                showToast('Hypervisors refreshed', 'success');
            });
        }

        if (addBtn) {
            // Use wizard if available, otherwise fall back to modal
            addBtn.addEventListener('click', () => {
                if (typeof window.HvWizard !== 'undefined') {
                    window.HvWizard.open();
                } else {
                    openModal();
                }
            });
        }

        // Filters
        const typeFilter = document.getElementById('hypervisors-type-filter');
        const statusFilter = document.getElementById('hypervisors-status-filter');
        const searchInput = document.getElementById('hypervisors-search');
        const searchClearBtn = document.getElementById('hypervisors-search-clear');

        if (typeFilter) typeFilter.addEventListener('change', loadHypervisors);
        if (statusFilter) statusFilter.addEventListener('change', loadHypervisors);
        if (searchInput) {
            searchInput.addEventListener('input', debounce(() => {
                // Show/hide clear button
                if (searchClearBtn) {
                    searchClearBtn.style.display = searchInput.value ? 'block' : 'none';
                }
                loadHypervisors();
            }, 300));
        }
        if (searchClearBtn) {
            searchClearBtn.addEventListener('click', () => {
                if (searchInput) {
                    searchInput.value = '';
                    searchClearBtn.style.display = 'none';
                    loadHypervisors();
                }
            });
        }

        // Detail panel action buttons
        bindDetailPanelButtons();

        // Modal event listeners
        bindModalEventListeners();
    }

    // Bind detail panel buttons
    function bindDetailPanelButtons() {
        const testBtn = document.getElementById('hypervisors-btn-test');
        const auditBtn = document.getElementById('hypervisors-btn-audit');
        const historyBtn = document.getElementById('hypervisors-btn-history');
        const editBtn = document.getElementById('hypervisors-btn-edit');
        const deleteBtn = document.getElementById('hypervisors-btn-delete');
        const closeOutputBtn = document.getElementById('hypervisors-close-output');
        const closeDetailBtn = document.getElementById('hypervisors-detail-close');

        if (testBtn) testBtn.addEventListener('click', () => {
            if (selectedHypervisor) testConnection(selectedHypervisor.id);
        });
        if (auditBtn) auditBtn.addEventListener('click', () => {
            if (selectedHypervisor) runAudit(selectedHypervisor.id);
        });
        if (historyBtn) historyBtn.addEventListener('click', () => {
            if (selectedHypervisor) viewHistory(selectedHypervisor.id);
        });
        if (editBtn) editBtn.addEventListener('click', () => {
            if (selectedHypervisor) {
                if (typeof window.HvWizard !== 'undefined') {
                    window.HvWizard.open(selectedHypervisor);
                } else {
                    openModal(selectedHypervisor);
                }
            }
        });
        if (deleteBtn) deleteBtn.addEventListener('click', () => {
            if (selectedHypervisor) deleteHypervisor(selectedHypervisor.id);
        });
        if (closeOutputBtn) closeOutputBtn.addEventListener('click', () => {
            const outputPanel = document.getElementById('hypervisors-output-panel');
            if (outputPanel) outputPanel.style.display = 'none';
        });
        if (closeDetailBtn) closeDetailBtn.addEventListener('click', () => {
            const detailPanel = document.getElementById('hypervisors-detail-panel');
            if (detailPanel) detailPanel.style.display = 'none';
            selectedHypervisor = null;
            // Remove selected state from table rows
            document.querySelectorAll('.hypervisors-table tbody tr.selected').forEach(row => {
                row.classList.remove('selected');
            });
        });
    }

    // Bind modal event listeners
    function bindModalEventListeners() {
        const modal = document.getElementById('hypervisor-modal');
        const closeModalBtn = document.getElementById('close-hypervisor-modal');
        const cancelBtn = document.getElementById('cancel-hypervisor');
        const form = document.getElementById('hypervisor-form');
        const testModalBtn = document.getElementById('hypervisor-test-connection-btn');
        const historyModal = document.getElementById('hypervisor-history-modal');
        const closeHistoryBtn = document.getElementById('close-hypervisor-history-modal');

        if (closeModalBtn) closeModalBtn.addEventListener('click', closeModal);
        if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
        if (form) form.addEventListener('submit', handleFormSubmit);
        if (testModalBtn) testModalBtn.addEventListener('click', testConnectionFromModal);

        if (closeHistoryBtn) closeHistoryBtn.addEventListener('click', () => {
            if (historyModal) historyModal.style.display = 'none';
        });

        // Close modals on background click
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) closeModal();
            });
        }
        if (historyModal) {
            historyModal.addEventListener('click', (e) => {
                if (e.target === historyModal) historyModal.style.display = 'none';
            });
        }

        // Connection method dropdown change
        const connectionMethodSelect = document.getElementById('hypervisor-form-connection-method');
        if (connectionMethodSelect) {
            connectionMethodSelect.addEventListener('change', handleHypervisorConnectionChange);
        }

        // Authentication type dropdown change
        const authSelect = document.getElementById('hypervisor-form-auth');
        if (authSelect) {
            authSelect.addEventListener('change', handleHypervisorAuthChange);
        }

        // Hypervisor type dropdown change
        const typeSelect = document.getElementById('hypervisor-form-type');
        if (typeSelect) {
            typeSelect.addEventListener('change', handleHypervisorTypeChange);
        }
    }

    // Handle hypervisor type dropdown change
    function handleHypervisorTypeChange() {
        const typeSelect = document.getElementById('hypervisor-form-type');
        const type = typeSelect?.value || 'esxi';
        const portInput = document.getElementById('hypervisor-form-port');
        const connectionMethod = document.getElementById('hypervisor-form-connection-method')?.value || 'api';

        // Set default port based on hypervisor type and connection method
        const typeInfo = hypervisorTypes[type];
        if (typeInfo && connectionMethod === 'api' && portInput && !portInput.value) {
            portInput.value = typeInfo.defaultPort;
        }
    }

    // Handle connection method dropdown change (API vs SSH)
    function handleHypervisorConnectionChange() {
        const method = document.getElementById('hypervisor-form-connection-method')?.value || 'api';
        const authSelect = document.getElementById('hypervisor-form-auth');
        const portInput = document.getElementById('hypervisor-form-port');
        const elevationGroup = document.getElementById('hypervisor-elevation-group');
        const verifySSLGroup = document.getElementById('hypervisor-form-verify-ssl')?.closest('.form-group');

        if (method === 'ssh') {
            // SSH connection: show key/password auth, elevation, hide token
            if (authSelect) {
                // Remove token option, keep password and key
                authSelect.innerHTML = `
                    <option value="password">Password</option>
                    <option value="key">SSH Key</option>
                `;
            }
            if (portInput && !portInput.value) portInput.value = '22';
            if (elevationGroup) elevationGroup.classList.remove('d-none');
            if (verifySSLGroup) verifySSLGroup.classList.add('d-none');
        } else {
            // API connection: show password/token auth, hide elevation
            if (authSelect) {
                authSelect.innerHTML = `
                    <option value="password">Password</option>
                    <option value="token">API Token</option>
                `;
            }
            const typeSelect = document.getElementById('hypervisor-form-type');
            const typeInfo = hypervisorTypes[typeSelect?.value || 'esxi'];
            if (portInput && !portInput.value) portInput.value = typeInfo?.defaultPort || '443';
            if (elevationGroup) elevationGroup.classList.add('d-none');
            if (verifySSLGroup) verifySSLGroup.classList.remove('d-none');
        }

        // Trigger auth change to update visible fields
        handleHypervisorAuthChange();
    }

    // Handle authentication type dropdown change
    function handleHypervisorAuthChange() {
        const authType = document.getElementById('hypervisor-form-auth')?.value || 'password';
        const passwordGroup = document.getElementById('hypervisor-password-group');
        const keyGroup = document.getElementById('hypervisor-key-group');
        const passphraseGroup = document.getElementById('hypervisor-passphrase-group');
        const tokenGroup = document.getElementById('hypervisor-token-group');

        // Hide all auth groups first
        if (passwordGroup) passwordGroup.classList.add('d-none');
        if (keyGroup) keyGroup.classList.add('d-none');
        if (passphraseGroup) passphraseGroup.classList.add('d-none');
        if (tokenGroup) tokenGroup.classList.add('d-none');

        // Show appropriate group based on selection
        if (authType === 'password') {
            if (passwordGroup) passwordGroup.classList.remove('d-none');
        } else if (authType === 'key') {
            if (keyGroup) keyGroup.classList.remove('d-none');
            if (passphraseGroup) passphraseGroup.classList.remove('d-none');
        } else if (authType === 'token') {
            if (tokenGroup) tokenGroup.classList.remove('d-none');
        }
    }

    // Expose handlers to window scope for inline HTML calls
    window.handleHypervisorTypeChange = handleHypervisorTypeChange;
    window.handleHypervisorConnectionChange = handleHypervisorConnectionChange;
    window.handleHypervisorAuthChange = handleHypervisorAuthChange;

    // Load statistics
    async function loadStats() {
        try {
            const response = await hypervisorFetch('/api/hypervisors/stats');
            const data = await response.json();

            if (data.success) {
                const stats = data.stats || {};
                updateElement('hypervisors-total-count', stats.total || 0);
                updateElement('hypervisors-online-count', stats.online || 0);
                updateElement('hypervisors-offline-count', (stats.offline || 0) + (stats.error || 0));
                updateElement('hypervisors-audits-24h', stats.recent_audits_24h || 0);
            }
        } catch (e) {
            console.error('[Hypervisors] Error loading stats:', e);
        }
    }

    // Load hypervisors list
    async function loadHypervisors() {
        const tableBody = document.getElementById('hypervisors-table-body');
        const emptyState = document.getElementById('hypervisors-empty-state');
        const noResults = document.getElementById('hypervisors-no-results');
        const tableContainer = document.querySelector('.hypervisors-table-container');

        // Fallback for old list-based layout
        const listEl = document.getElementById('hypervisors-list');

        const typeFilter = document.getElementById('hypervisors-type-filter')?.value || '';
        const statusFilter = document.getElementById('hypervisors-status-filter')?.value || '';
        const searchQuery = document.getElementById('hypervisors-search')?.value || '';

        let url = '/api/hypervisors?per_page=100';
        if (typeFilter) url += `&type=${encodeURIComponent(typeFilter)}`;
        if (statusFilter) url += `&status=${encodeURIComponent(statusFilter)}`;

        // Show loading state
        if (tableBody) {
            tableBody.innerHTML = `
                <tr class="hypervisors-loading-row">
                    <td colspan="7">
                        <div class="hypervisors-loading">
                            <div class="hypervisors-loading-spinner"></div>
                            <p>Loading hypervisors...</p>
                        </div>
                    </td>
                </tr>`;
        }
        if (emptyState) emptyState.style.display = 'none';
        if (noResults) noResults.style.display = 'none';

        try {
            const response = await hypervisorFetch(url);
            const data = await response.json();

            if (data.success) {
                hypervisors = data.hypervisors || [];

                // Client-side search filter
                if (searchQuery) {
                    const query = searchQuery.toLowerCase();
                    hypervisors = hypervisors.filter(hv =>
                        hv.name.toLowerCase().includes(query) ||
                        hv.hostname.toLowerCase().includes(query) ||
                        (hv.description && hv.description.toLowerCase().includes(query)) ||
                        (hv.datacenter && hv.datacenter.toLowerCase().includes(query)) ||
                        (hypervisorTypes[hv.hypervisor_type]?.label.toLowerCase().includes(query))
                    );
                }

                renderHypervisors(tableBody, emptyState, noResults, searchQuery);
            } else {
                if (tableBody) {
                    tableBody.innerHTML = `
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 2rem;">
                                ⚠️ Error: ${escapeHtml(data.error || 'Unknown error')}
                            </td>
                        </tr>`;
                }
            }
        } catch (e) {
            console.error('[Hypervisors] Error loading hypervisors:', e);
            if (tableBody) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 2rem;">
                            ⚠️ Failed to load hypervisors
                        </td>
                    </tr>`;
            }
        }
    }

    // Render hypervisors as table rows
    function renderHypervisors(tableBody, emptyState, noResults, searchQuery) {
        updateElement('hypervisors-showing-count', hypervisors.length);

        if (hypervisors.length === 0) {
            if (tableBody) tableBody.innerHTML = '';

            // Show appropriate empty state
            if (searchQuery) {
                if (noResults) noResults.style.display = 'flex';
                if (emptyState) emptyState.style.display = 'none';
            } else {
                if (emptyState) emptyState.style.display = 'flex';
                if (noResults) noResults.style.display = 'none';
            }
            return;
        }

        // Hide empty states
        if (emptyState) emptyState.style.display = 'none';
        if (noResults) noResults.style.display = 'none';

        if (!tableBody) return;

        tableBody.innerHTML = hypervisors.map(hv => {
            const typeInfo = hypervisorTypes[hv.hypervisor_type] || { label: hv.hypervisor_type, icon: '📦' };
            const isSelected = selectedHypervisor?.id === hv.id;
            const lastAudit = formatDate(hv.last_audit_at);

            return `
                <tr class="${isSelected ? 'selected' : ''}" data-id="${hv.id}">
                    <td>
                        <span class="hypervisors-status-badge ${hv.status}">
                            ${hv.status.charAt(0).toUpperCase() + hv.status.slice(1)}
                        </span>
                    </td>
                    <td>
                        <div class="cell-name">
                            <span class="icon">${typeInfo.icon}</span>
                            <span class="name-text">${escapeHtml(hv.name)}</span>
                        </div>
                    </td>
                    <td class="cell-type">${typeInfo.label}</td>
                    <td class="cell-hostname">${escapeHtml(hv.hostname)}:${hv.port}</td>
                    <td>${escapeHtml(hv.datacenter || '-')}</td>
                    <td>${lastAudit}</td>
                    <td class="cell-actions">
                        <button class="btn-icon" onclick="event.stopPropagation(); window.HypervisorsModule.selectHypervisor(${hv.id})" title="View Details">👁️</button>
                        <button class="btn-icon" onclick="event.stopPropagation(); window.HypervisorsModule.testConnection(${hv.id})" title="Test Connection">🔌</button>
                        <button class="btn-icon" onclick="event.stopPropagation(); window.HypervisorsModule.runAudit(${hv.id})" title="Run Audit">▶</button>
                        ${canManageConnectionMethod ? `<button class="btn-icon" onclick="event.stopPropagation(); window.HypervisorsModule.changeConnectionMethod(${hv.id})" title="Change Connection Method">🔄</button>` : ''}
                        <button class="btn-icon" onclick="event.stopPropagation(); window.HypervisorsModule.openModal(${hv.id})" title="Edit">✏️</button>
                        <button class="btn-icon btn-danger" onclick="event.stopPropagation(); window.HypervisorsModule.deleteHypervisor(${hv.id})" title="Delete">🗑️</button>
                    </td>
                </tr>`;
        }).join('');

        // Add click handlers for row selection
        tableBody.querySelectorAll('tr[data-id]').forEach(row => {
            row.addEventListener('click', () => {
                const id = parseInt(row.dataset.id);
                selectHypervisor(id);
            });
        });
    }

    // Select hypervisor
    function selectHypervisor(id) {
        selectedHypervisor = hypervisors.find(h => h.id === id);
        if (!selectedHypervisor) return;

        const detailPanel = document.getElementById('hypervisors-detail-panel');
        if (detailPanel) {
            detailPanel.style.display = 'flex';

            const typeInfo = hypervisorTypes[selectedHypervisor.hypervisor_type] || { label: selectedHypervisor.hypervisor_type };

            updateElement('hypervisors-detail-name', selectedHypervisor.name);
            updateElement('hypervisors-detail-type', typeInfo.label);
            updateElement('hypervisors-detail-hostname', `${selectedHypervisor.hostname}:${selectedHypervisor.port}`);
            updateElement('hypervisors-detail-datacenter', selectedHypervisor.datacenter || '-');
            updateElement('hypervisors-detail-last-audit', formatDate(selectedHypervisor.last_audit_at));

            const statusEl = document.getElementById('hypervisors-detail-status');
            if (statusEl) {
                statusEl.innerHTML = `
                    <span class="hypervisors-status-badge ${selectedHypervisor.status}">
                        ${selectedHypervisor.status.charAt(0).toUpperCase() + selectedHypervisor.status.slice(1)}
                    </span>`;
            }
        }

        // Highlight selected row in table
        document.querySelectorAll('.hypervisors-table tbody tr').forEach(row => {
            row.classList.toggle('selected', row.dataset.id == id);
        });

        // Fallback: highlight old list items if they exist
        document.querySelectorAll('.hypervisors-list-item').forEach(item => {
            item.classList.toggle('selected', item.dataset.id == id);
        });
    }

    // Test connection
    async function testConnection(id) {
        const hv = hypervisors.find(h => h.id === id);
        if (!hv) return;

        showToast(`Testing connection to ${hv.name}...`, 'info');

        try {
            const response = await hypervisorFetch(`/api/hypervisors/${id}/test`, { method: 'POST' });
            const data = await response.json();

            if (data.success) {
                showToast(`Connection to ${hv.name} successful!`, 'success');
            } else {
                showToast(`Connection to ${hv.name} failed: ${data.message || data.error}`, 'error');
            }

            // Reload to update status
            await loadAll();
            if (selectedHypervisor?.id === id) {
                selectHypervisor(id);
            }
        } catch (e) {
            showToast(`Error testing connection: ${e.message}`, 'error');
        }
    }

    // Run audit
    async function runAudit(id) {
        const hv = hypervisors.find(h => h.id === id);
        if (!hv) return;

        showToast(`Starting audit on ${hv.name}...`, 'info');

        const outputPanel = document.getElementById('hypervisors-output-panel');
        const outputContent = document.getElementById('hypervisors-output-content');

        if (outputPanel) outputPanel.style.display = 'block';
        if (outputContent) outputContent.innerHTML = '<div class="output-line info">Starting audit...</div>';

        try {
            const response = await hypervisorFetch(`/api/hypervisors/${id}/audit`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ audit_type: 'security' })
            });
            const data = await response.json();

            if (data.success) {
                showToast(`Audit completed on ${hv.name}`, 'success');
                if (outputContent && data.execution?.output) {
                    formatAuditOutput(outputContent, data.execution.output);
                }
            } else {
                showToast(`Audit failed: ${data.error}`, 'error');
                if (outputContent) {
                    outputContent.innerHTML = `<div class="output-line fail">Error: ${escapeHtml(data.error)}</div>`;
                }
            }

            await loadAll();
        } catch (e) {
            showToast(`Error running audit: ${e.message}`, 'error');
            if (outputContent) {
                outputContent.innerHTML = `<div class="output-line fail">Error: ${e.message}</div>`;
            }
        }
    }

    async function changeConnectionMethod(id) {
        if (!canManageConnectionMethod) {
            showToast('Only Admin or SuperAdmin can change connection method for existing hypervisors', 'error');
            return;
        }

        const hv = hypervisors.find(h => h.id === id);
        if (!hv) return;

        const currentMethod = (hv.connection_method || 'api').toLowerCase();
        const input = prompt(
            `Change connection method for ${hv.name}\n\n1) API (api)\n2) SSH (ssh)\n\nEnter option number or method value:`,
            currentMethod
        );

        if (input === null) return;

        let selectedMethod = String(input).trim().toLowerCase();
        if (selectedMethod === '1') selectedMethod = 'api';
        if (selectedMethod === '2') selectedMethod = 'ssh';

        if (!['api', 'ssh'].includes(selectedMethod)) {
            showToast('Invalid method. Use api or ssh.', 'error');
            return;
        }

        if (selectedMethod === currentMethod) {
            return;
        }

        try {
            const response = await hypervisorFetch(`/api/hypervisors/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ connection_method: selectedMethod })
            });
            const result = await response.json();

            if (response.ok && result.success) {
                showToast(`Connection method updated to ${selectedMethod.toUpperCase()}`, 'success');
                await loadAll();
                if (selectedHypervisor?.id === id) selectHypervisor(id);
            } else {
                showToast(result.error || 'Failed to update connection method', 'error');
            }
        } catch (e) {
            showToast(`Error updating connection method: ${e.message}`, 'error');
        }
    }

    // Format audit output
    function formatAuditOutput(container, output) {
        const lines = output.split('\n');
        container.innerHTML = lines.map(line => {
            let cls = '';
            if (line.includes('[PASS]')) cls = 'pass';
            else if (line.includes('[WARN]')) cls = 'warn';
            else if (line.includes('[FAIL]')) cls = 'fail';
            else if (line.includes('[SKIP]')) cls = 'skip';
            else if (line.includes('===') || line.includes('---')) cls = 'info';
            return `<div class="output-line ${cls}">${escapeHtml(line)}</div>`;
        }).join('');
    }

    // View history
    async function viewHistory(id) {
        const hv = hypervisors.find(h => h.id === id);
        if (!hv) return;

        const modal = document.getElementById('hypervisor-history-modal');
        const content = document.getElementById('hypervisor-history-content');

        if (modal) modal.style.display = 'flex';
        if (content) {
            content.innerHTML = `
                <div class="loading-state">
                    <div class="spinner"></div>
                    <p>Loading history for ${escapeHtml(hv.name)}...</p>
                </div>`;
        }

        try {
            const response = await hypervisorFetch(`/api/hypervisors/${id}/history?limit=20`);
            const data = await response.json();

            if (!content) return;

            if (data.success && data.executions?.length > 0) {
                content.innerHTML = `
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Duration</th>
                                <th>Results</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${data.executions.map(exec => `
                                <tr>
                                    <td>${formatDate(exec.started_at)}</td>
                                    <td>${exec.audit_type || 'security'}</td>
                                    <td><span class="status-badge ${exec.status === 'success' ? 'online' : 'offline'}">${exec.status}</span></td>
                                    <td>${exec.duration_seconds ? exec.duration_seconds.toFixed(1) + 's' : '-'}</td>
                                    <td>
                                        ${exec.checks_passed !== null ? `
                                            <span style="color: var(--color-success);">✓${exec.checks_passed}</span>
                                            <span style="color: var(--color-warning);">⚠${exec.checks_warned || 0}</span>
                                            <span style="color: var(--color-danger);">✗${exec.checks_failed || 0}</span>
                                        ` : '-'}
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>`;
            } else if (data.success) {
                content.innerHTML = `<div class="empty-state"><p>No audit history for this hypervisor yet.</p></div>`;
            } else {
                content.innerHTML = `<div class="empty-state">Error: ${data.error}</div>`;
            }
        } catch (e) {
            if (content) {
                content.innerHTML = `<div class="empty-state">Failed to load history: ${e.message}</div>`;
            }
        }
    }

    // Open add/edit modal
    function openModal(hvOrId = null) {
        const modal = document.getElementById('hypervisor-modal');
        if (!modal) return;

        let hv = null;
        if (typeof hvOrId === 'number') {
            hv = hypervisors.find(h => h.id === hvOrId);
        } else if (hvOrId && typeof hvOrId === 'object') {
            hv = hvOrId;
        }

        // Check license limits when adding new hypervisor
        if (!hv && licenseStatus && licenseStatus.limits) {
            const { max_hypervisors, current_hypervisors } = licenseStatus.limits;
            if (max_hypervisors && current_hypervisors >= max_hypervisors) {
                showToast(`You've reached the limit of ${max_hypervisors} hypervisors for your plan. Upgrade to add more.`, 'warning');
                return;
            }
        }

        // Set modal title and button text
        const titleEl = document.getElementById('hypervisor-modal-title');
        const saveBtn = document.getElementById('save-hypervisor');
        if (titleEl) titleEl.textContent = hv ? 'Edit Hypervisor' : 'Add Hypervisor';
        if (saveBtn) saveBtn.textContent = hv ? 'Save Changes' : 'Add Hypervisor';

        const form = document.getElementById('hypervisor-form');
        if (form) {
            form.dataset.originalConnectionMethod = hv?.connection_method || 'api';
            form.reset();
        }

        // Populate form fields
        setValue('hypervisor-form-id', hv?.id || '');
        setValue('hypervisor-form-name', hv?.name || '');
        setValue('hypervisor-form-hostname', hv?.hostname || '');
        setValue('hypervisor-form-port', hv?.port || '443');
        setValue('hypervisor-form-username', hv?.username || '');
        setValue('hypervisor-form-password', '');
        setValue('hypervisor-form-key', hv?.ssh_key || '');
        setValue('hypervisor-form-passphrase', '');
        setValue('hypervisor-form-api-token', '');
        setValue('hypervisor-form-datacenter', hv?.datacenter || '');
        setValue('hypervisor-form-cluster', hv?.cluster || '');
        setValue('hypervisor-form-description', hv?.description || '');
        setValue('hypervisor-form-tags', hv?.tags || '');

        // Hypervisor type dropdown
        const typeSelect = document.getElementById('hypervisor-form-type');
        if (typeSelect) {
            typeSelect.value = hv?.hypervisor_type || 'esxi';

            // Filter platforms based on license
            if (licenseStatus && licenseStatus.limits && licenseStatus.limits.allowed_platforms !== 'all') {
                const allowedPlatforms = licenseStatus.limits.allowed_platforms || [];
                Array.from(typeSelect.options).forEach(option => {
                    const isAllowed = allowedPlatforms.includes(option.value);
                    option.disabled = !isAllowed;
                    if (!isAllowed) {
                        option.text = option.text.replace(/ \(upgrade.*\)$/, '') + ' (upgrade required)';
                    }
                });
            }
        }

        // Connection method dropdown
        const connMethodSelect = document.getElementById('hypervisor-form-connection-method');
        if (connMethodSelect) {
            connMethodSelect.value = hv?.connection_method || 'api';
        }

        // Elevation method
        const elevMethod = document.getElementById('hypervisor-form-elevation-method');
        if (elevMethod) {
            elevMethod.value = hv?.elevation_method || 'none';
        }

        // Verify SSL checkbox
        const verifySSL = document.getElementById('hypervisor-form-verify-ssl');
        if (verifySSL) verifySSL.checked = hv?.verify_ssl !== false;

        // Trigger connection change to build the proper auth options first
        handleHypervisorConnectionChange();

        // Then apply authentication selection and field visibility
        const authSelect = document.getElementById('hypervisor-form-auth');
        if (authSelect) {
            if ((hv?.connection_method || 'api') === 'ssh') {
                authSelect.value = hv?.ssh_auth_method === 'key' ? 'key' : 'password';
            } else {
                authSelect.value = hv?.api_token ? 'token' : 'password';
            }
        }
        handleHypervisorAuthChange();

        // Clear connection test result
        const testResult = document.getElementById('hypervisor-test-result');
        if (testResult) {
            testResult.innerHTML = '';
            testResult.style.display = 'none';
        }

        applyHypervisorConnectionMethodEditPermission(Boolean(hv));

        modal.style.display = 'flex';
    }

    // Close modal
    function closeModal() {
        const modal = document.getElementById('hypervisor-modal');
        if (modal) modal.style.display = 'none';
    }

    // Handle form submit
    async function handleFormSubmit(e) {
        e.preventDefault();

        const id = document.getElementById('hypervisor-form-id')?.value;
        const connectionMethod = document.getElementById('hypervisor-form-connection-method')?.value || 'api';
        const authType = document.getElementById('hypervisor-form-auth')?.value || 'password';
        const originalConnectionMethod = e.target.dataset.originalConnectionMethod || connectionMethod;

        if (id && !canManageConnectionMethod && connectionMethod !== originalConnectionMethod) {
            showToast('Only Admin or SuperAdmin can change connection method for existing hypervisors', 'error');
            return;
        }

        const data = {
            name: document.getElementById('hypervisor-form-name')?.value,
            hypervisor_type: document.getElementById('hypervisor-form-type')?.value || 'esxi',
            hostname: document.getElementById('hypervisor-form-hostname')?.value,
            port: parseInt(document.getElementById('hypervisor-form-port')?.value) || undefined,
            connection_method: connectionMethod,
            username: document.getElementById('hypervisor-form-username')?.value || undefined,
            datacenter: document.getElementById('hypervisor-form-datacenter')?.value || undefined,
            cluster: document.getElementById('hypervisor-form-cluster')?.value || undefined,
            description: document.getElementById('hypervisor-form-description')?.value || undefined,
            tags: document.getElementById('hypervisor-form-tags')?.value || undefined
        };

        // Add auth fields based on connection method and auth type
        if (connectionMethod === 'api') {
            if (authType === 'token') {
                data.api_token = document.getElementById('hypervisor-form-api-token')?.value || undefined;
            } else {
                data.password = document.getElementById('hypervisor-form-password')?.value || undefined;
            }
            data.verify_ssl = document.getElementById('hypervisor-form-verify-ssl')?.checked;
        } else {
            // SSH connection
            data.ssh_auth_method = authType;
            if (authType === 'key') {
                data.ssh_key = document.getElementById('hypervisor-form-key')?.value || undefined;
                data.ssh_passphrase = document.getElementById('hypervisor-form-passphrase')?.value || undefined;
            } else {
                data.password = document.getElementById('hypervisor-form-password')?.value || undefined;
            }
            data.elevation_method = document.getElementById('hypervisor-form-elevation-method')?.value || 'none';
        }

        // Validate required fields
        if (!data.name || !data.hypervisor_type || !data.hostname) {
            showToast('Name, type, and hostname are required', 'error');
            return;
        }

        try {
            const url = id ? `/api/hypervisors/${id}` : '/api/hypervisors';
            const method = id ? 'PUT' : 'POST';

            const response = await hypervisorFetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                showToast(id ? 'Hypervisor updated' : 'Hypervisor added', 'success');
                closeModal();
                await loadAll();
            } else {
                showToast(`Error: ${result.error}`, 'error');
            }
        } catch (e) {
            showToast(`Error: ${e.message}`, 'error');
        }
    }

    // Delete hypervisor
    async function deleteHypervisor(id) {
        const hv = hypervisors.find(h => h.id === id);
        if (!hv) return;

        if (!confirm(`Are you sure you want to delete "${hv.name}"?\n\nThis will also delete all audit history for this hypervisor.`)) {
            return;
        }

        try {
            const response = await hypervisorFetch(`/api/hypervisors/${id}`, { method: 'DELETE' });
            const data = await response.json();

            if (data.success) {
                showToast(`Deleted ${hv.name}`, 'success');
                if (selectedHypervisor?.id === id) {
                    selectedHypervisor = null;
                    const detailPanel = document.getElementById('hypervisors-detail-panel');
                    if (detailPanel) detailPanel.style.display = 'none';
                }
                await loadAll();
            } else {
                showToast(`Delete failed: ${data.error}`, 'error');
            }
        } catch (e) {
            showToast(`Error: ${e.message}`, 'error');
        }
    }

    // Test connection from modal
    async function testConnectionFromModal() {
        const connectionMethod = document.getElementById('hypervisor-form-connection-method')?.value || 'api';
        const authType = document.getElementById('hypervisor-form-auth')?.value || 'password';
        const resultEl = document.getElementById('hypervisor-test-result');

        const data = {
            hostname: document.getElementById('hypervisor-form-hostname')?.value,
            port: parseInt(document.getElementById('hypervisor-form-port')?.value) || undefined,
            hypervisor_type: document.getElementById('hypervisor-form-type')?.value,
            connection_method: connectionMethod
        };

        // Add auth fields based on connection method
        if (connectionMethod === 'api') {
            data.username = document.getElementById('hypervisor-form-username')?.value;
            if (authType === 'token') {
                data.api_token = document.getElementById('hypervisor-form-api-token')?.value;
            } else {
                data.password = document.getElementById('hypervisor-form-password')?.value;
            }
            data.verify_ssl = document.getElementById('hypervisor-form-verify-ssl')?.checked;
        } else {
            data.username = document.getElementById('hypervisor-form-username')?.value;
            data.ssh_auth_method = authType;

            if (authType === 'password') {
                data.password = document.getElementById('hypervisor-form-password')?.value;
            } else {
                data.ssh_key = document.getElementById('hypervisor-form-key')?.value;
                data.ssh_passphrase = document.getElementById('hypervisor-form-passphrase')?.value;
            }
        }

        if (!data.hostname || !data.hypervisor_type) {
            showToast('Hostname and type are required', 'error');
            return;
        }

        // Show testing state
        if (resultEl) {
            resultEl.innerHTML = '<span class="testing"><i class="fas fa-spinner fa-spin"></i> Testing connection...</span>';
            resultEl.className = 'connection-test-result testing';
            resultEl.style.display = 'block';
        }
        showToast('Testing connection...', 'info');

        try {
            const response = await hypervisorFetch('/api/hypervisors/test-connection', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await response.json();

            if (result.success) {
                if (resultEl) {
                    resultEl.innerHTML = `<span class="success"><i class="fas fa-check-circle"></i> Connection successful!</span>`;
                    resultEl.className = 'connection-test-result success';
                }
                showToast('Connection successful!', 'success');
            } else {
                if (resultEl) {
                    resultEl.innerHTML = `<span class="error"><i class="fas fa-times-circle"></i> ${result.message || result.error || 'Connection failed'}</span>`;
                    resultEl.className = 'connection-test-result error';
                }
                showToast(`Connection failed: ${result.message || result.error}`, 'error');
            }
        } catch (e) {
            if (resultEl) {
                resultEl.innerHTML = `<span class="error"><i class="fas fa-times-circle"></i> ${e.message}</span>`;
                resultEl.className = 'connection-test-result error';
            }
            showToast(`Error: ${e.message}`, 'error');
        }
    }

    // Load all data (with license check)
    async function loadAll() {
        // Check license first
        const hasAccess = await checkLicenseStatus();
        if (!hasAccess) {
            console.log('[Hypervisors] Skipping data load - no license');
            return;
        }
        await Promise.all([loadStats(), loadHypervisors()]);
    }

    // Helper: Update element text content
    function updateElement(id, value) {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    }

    // Helper: Set input value
    function setValue(id, value) {
        const el = document.getElementById(id);
        if (el) el.value = value;
    }

    // Helper: Escape HTML
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Helper: Format date
    function formatDate(dateStr) {
        if (!dateStr) return 'Never';
        try {
            const date = new Date(dateStr);
            return date.toLocaleString();
        } catch (e) {
            return dateStr;
        }
    }

    // Helper: Debounce function
    function debounce(fn, delay) {
        let timeoutId;
        return function(...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => fn.apply(this, args), delay);
        };
    }

    // Helper: Show toast notification (use global if available)
    function showToast(message, type = 'info') {
        if (typeof window.showToast === 'function') {
            window.showToast(message, type);
        } else {
            console.log(`[${type.toUpperCase()}] ${message}`);
        }
    }

    // Called when tab is activated
    function onTabActivated() {
        console.log('[Hypervisors] Tab activated, loading data...');
        loadAll();
    }

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Listen for tab changes
    document.addEventListener('tabChanged', function(e) {
        if (e.detail && e.detail.tab === 'hypervisors') {
            console.log('[Hypervisors] Tab activated via tabChanged event');
            onTabActivated();
        }
    });

    // Expose public API
    window.HypervisorsModule = {
        init,
        loadAll,
        loadStats,
        loadHypervisors,
        selectHypervisor,
        testConnection,
        changeConnectionMethod,
        runAudit,
        viewHistory,
        openModal,
        deleteHypervisor,
        onTabActivated
    };

})();
