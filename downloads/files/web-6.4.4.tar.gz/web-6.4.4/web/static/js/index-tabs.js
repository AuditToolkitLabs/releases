/**
 * Index Page Tab Switching JavaScript
 * Handles tab navigation in the main console
 */
(function() {
    // Wait for DOM
    document.addEventListener('DOMContentLoaded', function() {
        console.log('Tab initialization starting...');
        
        // Helper function to activate a tab
        function activateTab(tabName) {
            // Remove active from all buttons
            document.querySelectorAll('.tab-button').forEach(function(btn) {
                btn.classList.remove('active');
            });
            
            // Add active to target button
            var targetButton = document.querySelector('.tab-button[data-tab="' + tabName + '"]');
            if (targetButton) {
                targetButton.classList.add('active');
            }
            
            // Hide all tab content
            document.querySelectorAll('.tab-content').forEach(function(content) {
                content.classList.remove('active');
                content.style.display = 'none';
            });
            
            // Show selected tab content
            var targetTab = document.getElementById(tabName + '-tab');
            if (targetTab) {
                targetTab.classList.add('active');
                targetTab.style.display = 'block';
                console.log('Activated tab: ' + tabName);
                
                // Dispatch tabChanged event for other modules to listen
                document.dispatchEvent(new CustomEvent('tabChanged', {
                    detail: { tab: tabName }
                }));
                return true;
            }
            return false;
        }
        
        // Check for initial tab from URL hash (e.g., /console#discovery)
        var hash = window.location.hash.replace('#', '');
        if (hash && activateTab(hash)) {
            console.log('Activated tab from URL hash: ' + hash);
        } 
        // Check for initial tab from sessionStorage (set by home page)
        else {
            var initialTab = sessionStorage.getItem('initialTab');
            if (initialTab) {
                sessionStorage.removeItem('initialTab');
                if (activateTab(initialTab)) {
                    console.log('Activated tab from sessionStorage: ' + initialTab);
                }
            }
        }
        
        // Get all tab buttons
        var tabButtons = document.querySelectorAll('.tab-button');
        console.log('Found ' + tabButtons.length + ' tab buttons');
        
        // Add click handlers to each
        tabButtons.forEach(function(button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                var tabName = this.getAttribute('data-tab');
                console.log('Tab clicked: ' + tabName);
                
                // Remove active from all buttons
                document.querySelectorAll('.tab-button').forEach(function(btn) {
                    btn.classList.remove('active');
                });
                
                // Add active to clicked button
                this.classList.add('active');
                
                // Hide all tab content
                document.querySelectorAll('.tab-content').forEach(function(content) {
                    content.classList.remove('active');
                    content.style.display = 'none';
                });
                
                // Show selected tab content
                var targetTab = document.getElementById(tabName + '-tab');
                if (targetTab) {
                    targetTab.classList.add('active');
                    targetTab.style.display = 'block';
                    console.log('Activated tab: ' + tabName + '-tab');
                    
                    // Dispatch tabChanged event for other modules to listen
                    document.dispatchEvent(new CustomEvent('tabChanged', {
                        detail: { tab: tabName }
                    }));
                } else {
                    console.error('Tab not found: ' + tabName + '-tab');
                }
            });
        });
        
        console.log('Tab initialization complete');
    });
})();
