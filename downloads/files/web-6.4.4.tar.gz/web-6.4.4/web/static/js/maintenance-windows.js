/**
 * Maintenance Windows Management
 * Handles CRUD operations and UI for maintenance windows in the scheduler panel
 * Requires Admin+ role for modifications
 */

// XSS prevention helper
function escapeMaintenanceHtml(unsafe) {
    if (unsafe == null) return '';
    const div = document.createElement('div');
    div.textContent = String(unsafe);
    return div.innerHTML;
}

// Helper to get maintenance API key
function getMaintenanceApiKey() {
    return localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
}

// API wrapper with credentials
async function maintenanceFetch(url, options = {}) {
    const defaultOptions = { credentials: 'include' };
    const headers = { ...(options.headers || {}) };
    const apiKey = getMaintenanceApiKey();
    if (apiKey && !headers['X-API-Key']) {
        headers['X-API-Key'] = apiKey;
    }

    return fetch(url, {
        ...defaultOptions,
        ...options,
        headers
    });
}

const MAINTENANCE_API = '/api/maintenance-windows';
let maintenanceWindows = [];
let currentUserRole = null;

/**
 * Initialize maintenance windows module
 */
async function initMaintenanceWindows() {
    console.log('[MaintenanceWindows] Initializing...');

    // Check user role first
    await checkUserRole();

    if (!canManageMaintenanceWindows()) {
        console.log('[MaintenanceWindows] User is not admin, hiding section');
        return; // Don't show section for non-admin users
    }

    console.log('[MaintenanceWindows] User is admin, showing section');

    // Show the maintenance section
    const section = document.getElementById('maintenance-windows-section');
    if (section) {
        section.style.display = 'block';
        console.log('[MaintenanceWindows] Section displayed');
    } else {
        console.error('[MaintenanceWindows] Section element not found!');
    }

    // Show maintenance stat card
    const statCard = document.getElementById('maintenance-stat-card');
    if (statCard) {
        statCard.style.display = 'flex';
    }

    // Setup event listeners
    setupMaintenanceEventListeners();

    // Populate server dropdown
    await populateMaintenanceServerDropdown();

    // Load maintenance windows
    await loadMaintenanceWindows();
}

/**
 * Check current user's role
 */
async function checkUserRole() {
    try {
        const response = await maintenanceFetch('/auth/me');
        if (response.ok) {
            const data = await response.json();
            currentUserRole = data.user?.role || null;
            console.log('[MaintenanceWindows] User role:', currentUserRole);
        } else {
            console.warn('[MaintenanceWindows] Auth check failed:', response.status);
        }
    } catch (error) {
        console.error('Error checking user role:', error);
        currentUserRole = null;
    }
}

/**
 * Check if current user can manage maintenance windows (Admin+)
 */
function canManageMaintenanceWindows() {
    const adminRoles = ['Admin', 'SuperAdmin', 'admin', 'superadmin'];
    const canManage = currentUserRole && adminRoles.includes(currentUserRole);
    console.log('[MaintenanceWindows] canManage:', canManage, 'role:', currentUserRole);
    return canManage;
}

/**
 * Setup event listeners for maintenance windows
 */
function setupMaintenanceEventListeners() {
    // Create button
    const createBtn = document.getElementById('create-maintenance-window');
    if (createBtn) {
        createBtn.addEventListener('click', () => openMaintenanceModal());
    }

    // Refresh button
    const refreshBtn = document.getElementById('refresh-maintenance-windows');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', loadMaintenanceWindows);
    }

    // Modal close buttons
    const closeModalBtn = document.getElementById('close-maintenance-modal');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeMaintenanceModal);
    }

    const cancelModalBtn = document.getElementById('cancel-maintenance-modal');
    if (cancelModalBtn) {
        cancelModalBtn.addEventListener('click', closeMaintenanceModal);
    }

    // Save button
    const saveBtn = document.getElementById('save-maintenance-window');
    if (saveBtn) {
        saveBtn.addEventListener('click', saveMaintenanceWindow);
    }

    // Window type change
    const typeSelect = document.getElementById('maintenance-type');
    if (typeSelect) {
        typeSelect.addEventListener('change', handleWindowTypeChange);
    }

    // Delete modal buttons
    const closeDeleteBtn = document.getElementById('close-delete-maintenance-modal');
    if (closeDeleteBtn) {
        closeDeleteBtn.addEventListener('click', closeDeleteModal);
    }

    const cancelDeleteBtn = document.getElementById('cancel-delete-maintenance');
    if (cancelDeleteBtn) {
        cancelDeleteBtn.addEventListener('click', closeDeleteModal);
    }

    const confirmDeleteBtn = document.getElementById('confirm-delete-maintenance');
    if (confirmDeleteBtn) {
        confirmDeleteBtn.addEventListener('click', confirmDeleteMaintenanceWindow);
    }
}

/**
 * Populate server dropdown in modal
 */
async function populateMaintenanceServerDropdown() {
    const select = document.getElementById('maintenance-server');
    if (!select) return;

    try {
        const response = await maintenanceFetch('/api/servers');
        if (response.ok) {
            const data = await response.json();
            const servers = data.servers || [];

            // Keep first two options (placeholder and "all")
            while (select.options.length > 2) {
                select.remove(2);
            }

            servers.forEach(server => {
                const option = document.createElement('option');
                option.value = server.id;
                option.textContent = `${server.name} (${server.hostname})`;
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error loading servers:', error);
    }
}

/**
 * Load maintenance windows from API
 */
async function loadMaintenanceWindows() {
    const listContainer = document.getElementById('maintenance-windows-list');
    if (!listContainer) return;

    listContainer.innerHTML = `
        <div class="maintenance-loading">
            <div class="schedule-loading-spinner"></div>
            <p>Loading maintenance windows...</p>
        </div>
    `;

    try {
        const response = await maintenanceFetch(MAINTENANCE_API);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();
        maintenanceWindows = data.windows || [];

        // Update stat counter
        const activeCount = maintenanceWindows.filter(w => w.is_active).length;
        const countEl = document.getElementById('maintenance-active-count');
        if (countEl) {
            countEl.textContent = activeCount;
        }

        // Check for currently active windows
        checkActiveMaintenanceBanner();

        // Render list
        renderMaintenanceWindows();

    } catch (error) {
        console.error('Error loading maintenance windows:', error);
        listContainer.innerHTML = `
            <div class="maintenance-empty">
                <div class="maintenance-empty-icon">⚠️</div>
                <p>Failed to load maintenance windows</p>
                <button class="btn btn-small" onclick="loadMaintenanceWindows()">
                    🔄 Retry
                </button>
            </div>
        `;
    }
}

/**
 * Check and display active maintenance banner
 */
function checkActiveMaintenanceBanner() {
    const banner = document.getElementById('active-maintenance-banner');
    if (!banner) return;

    const now = new Date();
    const activeWindow = maintenanceWindows.find(w => {
        if (!w.is_active) return false;

        if (w.window_type === 'one_time') {
            const start = new Date(w.start_time);
            const end = new Date(w.end_time);
            return now >= start && now <= end;
        }

        // For daily/recurring, check time of day
        if (w.window_type === 'daily' && w.daily_start_time && w.daily_end_time) {
            const nowTime = now.getHours() * 60 + now.getMinutes();
            const [startH, startM] = w.daily_start_time.split(':').map(Number);
            const [endH, endM] = w.daily_end_time.split(':').map(Number);
            const startMinutes = startH * 60 + startM;
            const endMinutes = endH * 60 + endM;
            return nowTime >= startMinutes && nowTime <= endMinutes;
        }

        return false;
    });

    if (activeWindow) {
        banner.style.display = 'flex';
        document.getElementById('active-maintenance-name').textContent =
            escapeMaintenanceHtml(activeWindow.name);

        let timeText = '';
        if (activeWindow.window_type === 'one_time') {
            const end = new Date(activeWindow.end_time);
            timeText = `Ends: ${end.toLocaleString()}`;
        } else if (activeWindow.daily_end_time) {
            timeText = `Ends daily at ${activeWindow.daily_end_time}`;
        }
        document.getElementById('active-maintenance-time').textContent = timeText;
    } else {
        banner.style.display = 'none';
    }
}

/**
 * Render maintenance windows list
 */
function renderMaintenanceWindows() {
    const listContainer = document.getElementById('maintenance-windows-list');
    if (!listContainer) return;

    if (maintenanceWindows.length === 0) {
        listContainer.innerHTML = `
            <div class="maintenance-empty">
                <div class="maintenance-empty-icon">🔧</div>
                <p>No maintenance windows configured</p>
                <p style="font-size: 0.85rem; margin-top: 0.5rem;">
                    Maintenance windows temporarily pause scheduled audits
                </p>
            </div>
        `;
        return;
    }

    const html = maintenanceWindows.map(window => {
        const isActive = window.is_active;
        const icon = getWindowTypeIcon(window.window_type);
        const timeInfo = formatWindowTime(window);
        const serverInfo = window.server_id === 'all' || !window.server_id
            ? 'All Servers'
            : `Server #${window.server_id}`;

        return `
            <div class="maintenance-card ${isActive ? 'active' : 'inactive'}"
                 data-window-id="${window.id}">
                <div class="maintenance-card-icon">${icon}</div>
                <div class="maintenance-card-info">
                    <div class="maintenance-card-name">
                        ${escapeMaintenanceHtml(window.name)}
                    </div>
                    <div class="maintenance-card-meta">
                        <span class="maintenance-card-type">
                            ${getWindowTypeLabel(window.window_type)}
                        </span>
                        <span class="maintenance-card-time">
                            ⏰ ${escapeMaintenanceHtml(timeInfo)}
                        </span>
                        <span>🖥️ ${escapeMaintenanceHtml(serverInfo)}</span>
                    </div>
                </div>
                <div class="maintenance-card-actions">
                    <button class="btn btn-small"
                            onclick="toggleMaintenanceWindow(${window.id})"
                            title="${isActive ? 'Disable' : 'Enable'}">
                        ${isActive ? '⏸️ Disable' : '▶️ Enable'}
                    </button>
                    <button class="btn btn-small btn-secondary"
                            onclick="editMaintenanceWindow(${window.id})"
                            title="Edit">
                        ✏️
                    </button>
                    <button class="btn btn-small btn-danger"
                            onclick="deleteMaintenanceWindow(${window.id})"
                            title="Delete">
                        🗑️
                    </button>
                </div>
            </div>
        `;
    }).join('');

    listContainer.innerHTML = html;
}

/**
 * Get icon for window type
 */
function getWindowTypeIcon(type) {
    const icons = {
        'one_time': '📅',
        'recurring': '🔄',
        'daily': '☀️'
    };
    return icons[type] || '🔧';
}

/**
 * Get label for window type
 */
function getWindowTypeLabel(type) {
    const labels = {
        'one_time': 'One-Time',
        'recurring': 'Recurring',
        'daily': 'Daily'
    };
    return labels[type] || type;
}

/**
 * Format window time info for display
 */
function formatWindowTime(window) {
    if (window.window_type === 'one_time') {
        const start = new Date(window.start_time);
        const end = new Date(window.end_time);
        return `${start.toLocaleDateString()} ${start.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} - ${end.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    }

    if (window.window_type === 'daily') {
        return `Daily ${window.daily_start_time || '00:00'} - ${window.daily_end_time || '00:00'}`;
    }

    if (window.window_type === 'recurring') {
        const days = window.recurrence_days || '';
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const selectedDays = days.split(',')
            .filter(d => d)
            .map(d => dayNames[parseInt(d)] || d)
            .join(', ');
        return `${selectedDays || 'No days'} ${window.daily_start_time || ''} - ${window.daily_end_time || ''}`;
    }

    return 'Unknown';
}

/**
 * Open maintenance window modal for create/edit
 */
function openMaintenanceModal(windowId = null) {
    const modal = document.getElementById('maintenance-window-modal');
    if (!modal) return;

    // Reset form
    document.getElementById('maintenance-window-form').reset();
    document.getElementById('maintenance-id').value = '';
    document.getElementById('maintenance-type').value = 'one_time';
    handleWindowTypeChange();

    // Set title
    const title = document.getElementById('maintenance-modal-title');
    title.textContent = windowId ? '🔧 Edit Maintenance Window' : '🔧 Create Maintenance Window';

    // If editing, populate form
    if (windowId) {
        const window = maintenanceWindows.find(w => w.id === windowId);
        if (window) {
            document.getElementById('maintenance-id').value = window.id;
            document.getElementById('maintenance-name').value = window.name || '';
            document.getElementById('maintenance-type').value = window.window_type || 'one_time';
            document.getElementById('maintenance-server').value = window.server_id || '';
            document.getElementById('maintenance-reason').value = window.reason || '';
            document.getElementById('maintenance-active').checked = window.is_active;

            handleWindowTypeChange();

            // Populate type-specific fields
            if (window.window_type === 'one_time') {
                if (window.start_time) {
                    document.getElementById('maintenance-start').value =
                        formatDateTimeLocal(window.start_time);
                }
                if (window.end_time) {
                    document.getElementById('maintenance-end').value =
                        formatDateTimeLocal(window.end_time);
                }
            } else if (window.window_type === 'daily') {
                document.getElementById('maintenance-daily-start').value =
                    window.daily_start_time || '02:00';
                document.getElementById('maintenance-daily-end').value =
                    window.daily_end_time || '04:00';
            } else if (window.window_type === 'recurring') {
                document.getElementById('maintenance-recur-start').value =
                    window.daily_start_time || '02:00';
                document.getElementById('maintenance-recur-end').value =
                    window.daily_end_time || '04:00';

                // Check recurrence days
                const days = (window.recurrence_days || '').split(',');
                document.querySelectorAll('input[name="recurrence-day"]').forEach(cb => {
                    cb.checked = days.includes(cb.value);
                });
            }
        }
    }

    modal.style.display = 'flex';
}

/**
 * Format ISO date for datetime-local input
 */
function formatDateTimeLocal(isoDate) {
    const date = new Date(isoDate);
    return date.toISOString().slice(0, 16);
}

/**
 * Close maintenance modal
 */
function closeMaintenanceModal() {
    const modal = document.getElementById('maintenance-window-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

/**
 * Handle window type change - show/hide relevant fields
 */
function handleWindowTypeChange() {
    const type = document.getElementById('maintenance-type').value;

    document.getElementById('one-time-fields').style.display =
        type === 'one_time' ? 'block' : 'none';
    document.getElementById('daily-fields').style.display =
        type === 'daily' ? 'block' : 'none';
    document.getElementById('recurring-fields').style.display =
        type === 'recurring' ? 'block' : 'none';
}

/**
 * Save maintenance window (create or update)
 */
async function saveMaintenanceWindow() {
    const id = document.getElementById('maintenance-id').value;
    const name = document.getElementById('maintenance-name').value.trim();
    const type = document.getElementById('maintenance-type').value;
    const serverId = document.getElementById('maintenance-server').value;
    const reason = document.getElementById('maintenance-reason').value.trim();
    const isActive = document.getElementById('maintenance-active').checked;

    // Validation
    if (!name) {
        alert('Please enter a window name');
        return;
    }

    if (!serverId) {
        alert('Please select a server scope');
        return;
    }

    // Build payload based on type
    const payload = {
        name,
        window_type: type,
        server_id: serverId === 'all' ? null : parseInt(serverId),
        reason,
        is_active: isActive
    };

    if (type === 'one_time') {
        const startTime = document.getElementById('maintenance-start').value;
        const endTime = document.getElementById('maintenance-end').value;

        if (!startTime || !endTime) {
            alert('Please specify start and end times');
            return;
        }

        payload.start_time = new Date(startTime).toISOString();
        payload.end_time = new Date(endTime).toISOString();
    } else if (type === 'daily') {
        payload.daily_start_time = document.getElementById('maintenance-daily-start').value;
        payload.daily_end_time = document.getElementById('maintenance-daily-end').value;
    } else if (type === 'recurring') {
        payload.daily_start_time = document.getElementById('maintenance-recur-start').value;
        payload.daily_end_time = document.getElementById('maintenance-recur-end').value;

        const selectedDays = Array.from(
            document.querySelectorAll('input[name="recurrence-day"]:checked')
        ).map(cb => cb.value);

        if (selectedDays.length === 0) {
            alert('Please select at least one recurrence day');
            return;
        }

        payload.recurrence_days = selectedDays.join(',');
    }

    try {
        const url = id ? `${MAINTENANCE_API}/${id}` : MAINTENANCE_API;
        const method = id ? 'PUT' : 'POST';

        const response = await maintenanceFetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || `HTTP ${response.status}`);
        }

        closeMaintenanceModal();
        await loadMaintenanceWindows();

        showNotification(
            id ? '✅ Maintenance window updated' : '✅ Maintenance window created',
            'success'
        );

    } catch (error) {
        console.error('Error saving maintenance window:', error);
        alert(`Failed to save: ${error.message}`);
    }
}

/**
 * Toggle maintenance window active state
 */
async function toggleMaintenanceWindow(windowId) {
    try {
        const response = await maintenanceFetch(
            `${MAINTENANCE_API}/${windowId}/toggle`,
            { method: 'POST' }
        );

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        await loadMaintenanceWindows();

    } catch (error) {
        console.error('Error toggling maintenance window:', error);
        alert('Failed to toggle maintenance window');
    }
}

/**
 * Edit maintenance window
 */
function editMaintenanceWindow(windowId) {
    openMaintenanceModal(windowId);
}

/**
 * Open delete confirmation modal
 */
function deleteMaintenanceWindow(windowId) {
    const window = maintenanceWindows.find(w => w.id === windowId);
    if (!window) return;

    document.getElementById('delete-maintenance-id').value = windowId;
    document.getElementById('delete-maintenance-name').textContent =
        escapeMaintenanceHtml(window.name);
    document.getElementById('delete-maintenance-type').textContent =
        getWindowTypeLabel(window.window_type);

    const modal = document.getElementById('delete-maintenance-modal');
    if (modal) {
        modal.style.display = 'flex';
    }
}

/**
 * Close delete confirmation modal
 */
function closeDeleteModal() {
    const modal = document.getElementById('delete-maintenance-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

/**
 * Confirm and execute deletion
 */
async function confirmDeleteMaintenanceWindow() {
    const windowId = document.getElementById('delete-maintenance-id').value;
    if (!windowId) return;

    try {
        const response = await maintenanceFetch(
            `${MAINTENANCE_API}/${windowId}`,
            { method: 'DELETE' }
        );

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        closeDeleteModal();
        await loadMaintenanceWindows();

        showNotification('✅ Maintenance window deleted', 'success');

    } catch (error) {
        console.error('Error deleting maintenance window:', error);
        alert('Failed to delete maintenance window');
    }
}

/**
 * Show notification (uses existing notification system if available)
 */
function showNotification(message, type = 'info') {
    // Try to use existing notification system
    if (typeof showToast === 'function') {
        showToast(message, type);
        return;
    }

    // Fallback: simple console log
    console.log(`[${type.toUpperCase()}] ${message}`);
}

// ============================================
// Global Maintenance Alert (shown on all pages)
// ============================================

let globalMaintenanceCheckInterval = null;
let maintenanceAlertDismissed = false;

/**
 * Check for active maintenance windows and show global alert
 */
async function checkGlobalMaintenanceAlert() {
    if (maintenanceAlertDismissed) {
        return; // User dismissed, don't check until page reload
    }

    try {
        const response = await maintenanceFetch(
            '/api/enhanced-schedule/maintenance-windows/active'
        );

        if (!response.ok) {
            // Silently fail - endpoint might not exist or user not authenticated
            return;
        }

        const data = await response.json();
        const activeWindow = data.active_window;

        if (activeWindow) {
            showGlobalMaintenanceAlert(activeWindow);
        } else {
            hideGlobalMaintenanceAlert();
        }
    } catch (error) {
        // Silently ignore - this is a background check
        console.debug('Maintenance alert check failed:', error);
    }
}

/**
 * Show the global maintenance alert banner
 */
function showGlobalMaintenanceAlert(window) {
    const alert = document.getElementById('global-maintenance-alert');
    if (!alert) return;

    const nameEl = document.getElementById('global-maintenance-name');
    const timeEl = document.getElementById('global-maintenance-time');

    if (nameEl) {
        nameEl.textContent = escapeMaintenanceHtml(window.name || 'Maintenance');
    }

    if (timeEl) {
        let timeText = '';
        if (window.end_time) {
            const end = new Date(window.end_time);
            const now = new Date();
            const diff = end - now;

            if (diff > 0) {
                const hours = Math.floor(diff / (1000 * 60 * 60));
                const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

                if (hours > 0) {
                    timeText = `Ends in ${hours}h ${minutes}m`;
                } else {
                    timeText = `Ends in ${minutes}m`;
                }
            } else {
                timeText = `Ends: ${end.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
            }
        } else if (window.daily_end_time) {
            timeText = `Ends daily at ${window.daily_end_time}`;
        }
        timeEl.textContent = timeText;
    }

    alert.style.display = 'block';
    document.body.classList.add('maintenance-alert-active');
}

/**
 * Hide the global maintenance alert banner
 */
function hideGlobalMaintenanceAlert() {
    const alert = document.getElementById('global-maintenance-alert');
    if (alert) {
        alert.style.display = 'none';
        document.body.classList.remove('maintenance-alert-active');
    }
}

/**
 * Dismiss the maintenance alert (user action)
 */
function dismissMaintenanceAlert() {
    maintenanceAlertDismissed = true;
    hideGlobalMaintenanceAlert();
}

/**
 * Start periodic global maintenance check
 */
function startGlobalMaintenanceCheck() {
    // Check immediately
    checkGlobalMaintenanceAlert();

    // Then check every 2 minutes
    if (!globalMaintenanceCheckInterval) {
        globalMaintenanceCheckInterval = setInterval(
            checkGlobalMaintenanceAlert,
            120000  // 2 minutes
        );
    }
}

/**
 * Stop periodic global maintenance check
 */
function stopGlobalMaintenanceCheck() {
    if (globalMaintenanceCheckInterval) {
        clearInterval(globalMaintenanceCheckInterval);
        globalMaintenanceCheckInterval = null;
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Wait a bit for other scripts to load
    setTimeout(initMaintenanceWindows, 500);

    // Start global maintenance alert check (for all users)
    setTimeout(startGlobalMaintenanceCheck, 1000);

    // Attach dismiss button listener (CSP-compliant)
    const dismissBtn = document.getElementById('maintenance-alert-dismiss-btn');
    if (dismissBtn) {
        dismissBtn.addEventListener('click', dismissMaintenanceAlert);
    }
});

// Also init when schedule tab is shown
document.addEventListener('tabChanged', (e) => {
    if (e.detail && e.detail.tab === 'schedule') {
        initMaintenanceWindows();
    }
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    stopGlobalMaintenanceCheck();
});
