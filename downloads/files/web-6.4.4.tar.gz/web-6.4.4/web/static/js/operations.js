/**
 * Operations Dashboard JavaScript
 * Real-time monitoring for scheduled audits, batch jobs, and server execution
 */

/**
 * Wrapper for fetch that includes session credentials
 * @param {string} url - URL to fetch
 * @param {object} options - Fetch options (optional)
 * @returns {Promise<Response>} Fetch response
 */
async function opsFetch(url, options = {}) {
    const defaultOptions = { credentials: 'include' };
    const headers = { ...(options.headers || {}) };
    const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
    if (apiKey && !headers['X-API-Key']) {
        headers['X-API-Key'] = apiKey;
    }

    return fetch(url, { ...defaultOptions, ...options, headers });
}

const operations = {
    refreshInterval: null,
    autoRefreshEnabled: true,
    refreshRate: 60000, // 60 seconds - increased to prevent rate limiting
    lastLoadTime: 0, // Timestamp of last successful load
    minLoadInterval: 5000, // Minimum 5 seconds between loads
    eventSource: null,
    expandedOutput: false,
    isLoading: false, // Prevent concurrent loads
    initialized: false, // Prevent duplicate init calls

    // =========================================
    // Initialization
    // =========================================
    init() {
        // Prevent duplicate initialization
        if (this.initialized) {
            console.log('[Operations] Already initialized, refreshing data only...');
            this.loadDashboardData();
            return;
        }
        this.initialized = true;
        console.log('Operations dashboard initializing...');
        this.bindEvents();
        this.loadDashboardData();
        this.startAutoRefresh();
        this.setupSSE();
    },

    bindEvents() {
        // Refresh button
        const refreshBtn = document.getElementById('refresh-ops-dashboard');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadDashboardData());
        }

        // Server filter
        const serverFilter = document.getElementById('server-panel-filter');
        if (serverFilter) {
            serverFilter.addEventListener('change', (e) => this.filterServerPanels(e.target.value));
        }

        // Live output toggle
        const liveOutputHeader = document.querySelector('.ops-live-header');
        if (liveOutputHeader) {
            liveOutputHeader.addEventListener('click', () => this.toggleLiveOutput());
        }

        // Export buttons
        document.querySelectorAll('[onclick*="exportLiveOutput"]').forEach(btn => {
            btn.onclick = (e) => {
                const format = e.target.textContent.includes('TXT') ? 'txt' : 'json';
                this.exportLiveOutput(format);
            };
        });
    },

    // =========================================
    // Data Loading
    // =========================================
    async loadDashboardData() {
        // Prevent concurrent loads
        if (this.isLoading) {
            console.log('[Operations] Already loading, skipping...');
            return;
        }

        // Enforce minimum interval between loads to prevent rate limiting
        const now = Date.now();
        if (now - this.lastLoadTime < this.minLoadInterval) {
            console.log('[Operations] Too soon since last load, skipping...');
            return;
        }

        this.isLoading = true;
        this.lastLoadTime = now;

        try {
            console.log('[Operations] Loading dashboard data...');

            // Load sequentially to reduce connection pressure
            const activeJobs = await this.fetchActiveJobs();
            const jobQueue = await this.fetchJobQueue();
            const serverStatus = await this.fetchServerStatus();
            const recentCompletions = await this.fetchRecentCompletions();

            console.log('[Operations] Data loaded:', {
                activeJobs: activeJobs?.length || 0,
                jobQueue: jobQueue?.length || 0,
                serverStatus: serverStatus?.length || 0,
                recentCompletions: recentCompletions?.length || 0
            });

            this.updateOverviewStats(activeJobs, jobQueue, recentCompletions);
            this.renderActiveJobs(activeJobs);
            this.renderJobQueue(jobQueue);
            this.renderServerPanels(serverStatus);
            this.renderRecentCompletions(recentCompletions);
            this.updateLastRefreshTime();

        } catch (error) {
            console.error('Error loading dashboard data:', error);
        } finally {
            this.isLoading = false;
        }
    },

    async fetchActiveJobs() {
        try {
            const response = await opsFetch('/api/monitoring/active-jobs');
            if (response.ok) {
                return await response.json();
            }
        } catch (e) {
            console.log('Active jobs endpoint not available, using mock data');
        }
        // Mock data for development
        return [];
    },

    async fetchJobQueue() {
        try {
            const response = await opsFetch('/api/monitoring/queue');
            if (response.ok) {
                return await response.json();
            }
        } catch (e) {
            console.log('Job queue endpoint not available, using mock data');
        }
        // Mock data - could be populated from schedules
        return [];
    },

    async fetchServerStatus() {
        try {
            const response = await opsFetch('/api/servers/status', { credentials: 'same-origin' });
            if (response.ok) {
                const data = await response.json();
                // Extract servers array from response
                return data.servers || [];
            }
        } catch (e) {
            console.log('Server status endpoint not available');
        }
        // Get from servers list
        try {
            const response = await opsFetch('/api/servers', { credentials: 'same-origin' });
            if (response.ok) {
                const data = await response.json();
                const servers = data.servers || [];
                console.log('[Operations] Loaded servers:', servers);
                return servers.map(s => ({
                    ...s,
                    status: 'idle',
                    lastRun: null,
                    lastResult: null
                }));
            } else {
                console.log('[Operations] Servers API returned:', response.status);
            }
        } catch (e) {
            console.log('Servers endpoint not available:', e);
        }
        return [];
    },

    async fetchRecentCompletions() {
        try {
            const response = await opsFetch('/api/monitoring/completions?limit=10');
            if (response.ok) {
                return await response.json();
            }
        } catch (e) {
            console.log('Completions endpoint not available, using mock data');
        }
        // Could fetch from audit history
        return [];
    },

    // =========================================
    // Overview Stats
    // =========================================
    updateOverviewStats(activeJobs, queue, completions) {
        // Update stat values
        const activeEl = document.getElementById('ops-active-jobs');
        const queuedEl = document.getElementById('ops-queued-jobs');
        if (activeEl) activeEl.textContent = activeJobs.length || 0;
        if (queuedEl) queuedEl.textContent = queue.length || 0;

        // Get server count from panels
        const serverCount = document.querySelectorAll('.ops-server-panel').length ||
                           document.getElementById('server-panel-filter')?.options.length - 1 || 0;
        const serversEl = document.getElementById('ops-active-servers');
        if (serversEl) serversEl.textContent = serverCount;

        // Calculate today's stats from completions
        const today = new Date().toDateString();
        const todayCompletions = completions.filter(c =>
            new Date(c.completedAt).toDateString() === today
        );

        let passCount = 0, warnCount = 0, failCount = 0;
        todayCompletions.forEach(c => {
            passCount += c.passCount || 0;
            warnCount += c.warnCount || 0;
            failCount += c.failCount || 0;
        });

        const passEl = document.getElementById('ops-today-success');
        const warnEl = document.getElementById('ops-today-warnings');
        const failEl = document.getElementById('ops-today-failures');
        if (passEl) passEl.textContent = passCount;
        if (warnEl) warnEl.textContent = warnCount;
        if (failEl) failEl.textContent = failCount;
    },

    // =========================================
    // Active Jobs Rendering
    // =========================================
    renderActiveJobs(jobs) {
        const container = document.getElementById('active-jobs-list');
        const badge = document.getElementById('active-jobs-count');

        if (badge) badge.textContent = jobs.length;

        if (!jobs || jobs.length === 0) {
            container.innerHTML = `
                <div class="ops-empty-state">
                    <div class="ops-empty-icon">⏸️</div>
                    <p>No active jobs running</p>
                    <p class="ops-empty-hint">Schedule audits or run manually to see progress here</p>
                </div>
            `;
            return;
        }

        container.innerHTML = jobs.map(job => `
            <div class="ops-job-card" data-job-id="${job.id}">
                <div class="ops-job-header">
                    <div class="ops-job-title">
                        <span class="ops-job-name">${this.escapeHtml(job.name)}</span>
                        <span class="ops-job-type">${job.type || 'audit'}</span>
                    </div>
                    <div class="ops-job-status">
                        <span class="status-badge status-running">⏳ Running</span>
                    </div>
                </div>
                <div class="ops-job-server">
                    🖥️ ${this.escapeHtml(job.server || 'Multiple Servers')}
                </div>
                <div class="ops-job-progress">
                    <div class="ops-job-progress-bar">
                        <div class="ops-job-progress-fill" style="width: ${job.progress || 0}%"></div>
                    </div>
                    <span class="ops-job-progress-text">${job.progress || 0}%</span>
                </div>
                <div class="ops-job-stats">
                    <span class="ops-job-stat pass">✓ ${job.passCount || 0}</span>
                    <span class="ops-job-stat warn">⚠ ${job.warnCount || 0}</span>
                    <span class="ops-job-stat fail">✗ ${job.failCount || 0}</span>
                </div>
                <div class="ops-job-actions">
                    <button class="btn btn-sm btn-secondary" onclick="operations.viewJobOutput('${job.id}')">
                        📄 View Output
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="operations.cancelJob('${job.id}')">
                        ⏹ Cancel
                    </button>
                </div>
            </div>
        `).join('');
    },

    // =========================================
    // Job Queue Rendering
    // =========================================
    renderJobQueue(queue) {
        const container = document.getElementById('job-queue-list');
        const badge = document.getElementById('queued-jobs-count');

        if (badge) badge.textContent = queue.length;

        if (!queue || queue.length === 0) {
            container.innerHTML = `
                <div class="ops-empty-state">
                    <div class="ops-empty-icon">📅</div>
                    <p>No scheduled jobs in queue</p>
                    <p class="ops-empty-hint">Set up schedules for automated audits</p>
                </div>
            `;
            return;
        }

        container.innerHTML = queue.map(job => {
            const scheduledTime = new Date(job.scheduledAt);
            const countdown = this.formatCountdown(scheduledTime);

            return `
                <div class="ops-queue-item" data-job-id="${job.id}">
                    <div class="ops-queue-info">
                        <span class="ops-queue-name">${this.escapeHtml(job.name)}</span>
                        <span class="ops-queue-time">Scheduled: ${scheduledTime.toLocaleString()}</span>
                    </div>
                    <div class="ops-queue-countdown">
                        <span class="countdown-value">${countdown}</span>
                        <button class="btn btn-sm btn-secondary" onclick="operations.runJobNow('${job.id}')" title="Run Now">
                            ▶️
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="operations.removeFromQueue('${job.id}')" title="Remove">
                            ✕
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    },

    formatCountdown(futureDate) {
        const now = new Date();
        const diff = futureDate - now;

        if (diff < 0) return 'Overdue';

        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

        if (hours > 24) {
            const days = Math.floor(hours / 24);
            return `${days}d ${hours % 24}h`;
        }
        return `${hours}h ${minutes}m`;
    },

    // =========================================
    // Server Panels Rendering
    // =========================================
    renderServerPanels(servers) {
        const container = document.getElementById('server-execution-panels');
        const filter = document.getElementById('server-panel-filter');

        if (!servers || servers.length === 0) {
            container.innerHTML = `
                <div class="ops-empty-state" style="grid-column: span 3;">
                    <div class="ops-empty-icon">🖥️</div>
                    <p>No servers configured</p>
                    <p class="ops-empty-hint">Add servers in the Connect tab to monitor them here</p>
                </div>
            `;
            return;
        }

        // Update filter options
        if (filter) {
            const currentValue = filter.value;
            filter.innerHTML = '<option value="all">All Servers</option>' +
                servers.map(s => `<option value="${s.id}">${this.escapeHtml(s.name)}</option>`).join('');
            filter.value = currentValue || 'all';
        }

        container.innerHTML = servers.map(server => {
            const statusClass = server.status || 'idle';
            const osIcon = server.os_type === 'windows' ? '🪟' : '🐧';
            const hostDisplay = server.hostname || server.host || server.ip_address || 'Unknown';

            return `
                <div class="ops-server-panel ${statusClass}" data-server-id="${server.id}">
                    <div class="ops-server-header">
                        <div class="ops-server-info">
                            <span class="ops-server-icon">${osIcon}</span>
                            <div>
                                <div class="ops-server-name">${this.escapeHtml(server.name)}</div>
                                <div class="ops-server-host">${this.escapeHtml(hostDisplay)}</div>
                            </div>
                        </div>
                        <div class="ops-server-status-dot ${statusClass}" title="${this.capitalizeFirst(statusClass)}"></div>
                    </div>
                    ${server.lastRun ? `
                        <div class="ops-server-last-run">
                            Last run: ${new Date(server.lastRun).toLocaleString()}
                        </div>
                    ` : `
                        <div class="ops-server-last-run">
                            No recent audits
                        </div>
                    `}
                    ${server.lastResult ? `
                        <div class="ops-server-metrics">
                            <span class="ops-server-metric stat-pass">✓ ${server.lastResult.pass || 0}</span>
                            <span class="ops-server-metric stat-warn">⚠ ${server.lastResult.warn || 0}</span>
                            <span class="ops-server-metric stat-fail">✗ ${server.lastResult.fail || 0}</span>
                        </div>
                    ` : ''}
                    <div class="ops-server-actions">
                        <button class="btn btn-sm btn-primary" onclick="operations.runAuditOnServer('${server.id}')">
                            ▶️ Run Audit
                        </button>
                        <button class="btn btn-sm btn-secondary" onclick="operations.viewServerHistory('${server.id}')">
                            📋 History
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    },

    filterServerPanels(value) {
        const panels = document.querySelectorAll('.ops-server-panel');
        panels.forEach(panel => {
            if (value === 'all' || panel.dataset.serverId === value) {
                panel.style.display = '';
            } else {
                panel.style.display = 'none';
            }
        });
    },

    // =========================================
    // Recent Completions Rendering
    // =========================================
    renderRecentCompletions(completions) {
        const container = document.getElementById('recent-completions-list');

        if (!completions || completions.length === 0) {
            container.innerHTML = `
                <div class="ops-empty-state">
                    <div class="ops-empty-icon">📊</div>
                    <p>No recent completions</p>
                    <p class="ops-empty-hint">Completed audits will appear here</p>
                </div>
            `;
            return;
        }

        container.innerHTML = completions.map(item => {
            const statusIcon = item.status === 'success' ? '✅' :
                              item.status === 'warning' ? '⚠️' : '❌';
            const completedTime = new Date(item.completedAt);
            const timeAgo = this.formatTimeAgo(completedTime);

            return `
                <div class="ops-completion-item" onclick="operations.viewCompletionDetails('${item.id}')">
                    <div class="ops-completion-info">
                        <span class="ops-completion-status">${statusIcon}</span>
                        <div class="ops-completion-details">
                            <span class="ops-completion-name">${this.escapeHtml(item.name)}</span>
                            <span class="ops-completion-meta">${this.escapeHtml(item.server)} • ${item.duration || 'N/A'}</span>
                        </div>
                    </div>
                    <div class="ops-completion-stats">
                        <span class="ops-completion-stat pass">✓ ${item.passCount || 0}</span>
                        <span class="ops-completion-stat warn">⚠ ${item.warnCount || 0}</span>
                        <span class="ops-completion-stat fail">✗ ${item.failCount || 0}</span>
                    </div>
                    <span class="ops-completion-time">${timeAgo}</span>
                </div>
            `;
        }).join('');
    },

    formatTimeAgo(date) {
        const now = new Date();
        const diff = now - date;
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days}d ago`;
        if (hours > 0) return `${hours}h ago`;
        if (minutes > 0) return `${minutes}m ago`;
        return 'Just now';
    },

    // =========================================
    // Live Output Panel
    // =========================================
    toggleLiveOutput() {
        const panel = document.querySelector('.ops-live-output');
        const chevron = document.getElementById('expand-live-output');

        this.expandedOutput = !this.expandedOutput;

        if (this.expandedOutput) {
            panel.classList.add('expanded');
            chevron.textContent = '▼';
        } else {
            panel.classList.remove('expanded');
            chevron.textContent = '▶';
        }
    },

    updateLiveOutput(jobId, output, stats) {
        const display = document.getElementById('output-display');
        const jobName = document.querySelector('.live-job-name');

        if (jobName && jobId) {
            jobName.textContent = `Job: ${jobId}`;
        }

        if (display && output) {
            display.textContent += output + '\n';
            display.scrollTop = display.scrollHeight;
        }

        // Update stats
        if (stats) {
            const passEl = document.querySelector('.ops-live-summary .stat-pass .stat-value');
            const warnEl = document.querySelector('.ops-live-summary .stat-warn .stat-value');
            const failEl = document.querySelector('.ops-live-summary .stat-fail .stat-value');
            const skipEl = document.querySelector('.ops-live-summary .stat-skip .stat-value');

            if (passEl) passEl.textContent = stats.pass || 0;
            if (warnEl) warnEl.textContent = stats.warn || 0;
            if (failEl) failEl.textContent = stats.fail || 0;
            if (skipEl) skipEl.textContent = stats.skip || 0;
        }
    },

    clearLiveOutput() {
        const display = document.getElementById('output-display');
        if (display) {
            display.textContent = '';
        }
        document.querySelector('.live-job-name').textContent = 'No active job';
    },

    exportLiveOutput(format) {
        const display = document.getElementById('output-display');
        if (!display) return;

        const content = display.textContent;
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `audit-output-${Date.now()}.${format}`;
        a.click();
        URL.revokeObjectURL(url);
    },

    // =========================================
    // Job Actions
    // =========================================
    async cancelJob(jobId) {
        if (!confirm('Are you sure you want to cancel this job?')) return;

        try {
            const response = await opsFetch(`/api/monitoring/jobs/${jobId}/cancel`, {
                method: 'POST'
            });

            if (response.ok) {
                this.showNotification('Job cancelled', 'success');
                this.loadDashboardData();
            } else {
                throw new Error('Failed to cancel job');
            }
        } catch (error) {
            console.error('Error cancelling job:', error);
            this.showNotification('Failed to cancel job', 'error');
        }
    },

    async viewJobOutput(jobId) {
        this.expandedOutput = true;
        const panel = document.querySelector('.ops-live-output');
        panel.classList.add('expanded');
        const expandBtn = document.getElementById('expand-live-output');
        if (expandBtn) expandBtn.textContent = '⬇️';

        // Subscribe to job output
        this.subscribeToJobOutput(jobId);
    },

    async runJobNow(jobId) {
        try {
            const response = await opsFetch(`/api/monitoring/queue/${jobId}/run`, {
                method: 'POST'
            });

            if (response.ok) {
                this.showNotification('Job started', 'success');
                this.loadDashboardData();
            } else {
                throw new Error('Failed to start job');
            }
        } catch (error) {
            console.error('Error starting job:', error);
            this.showNotification('Failed to start job', 'error');
        }
    },

    async removeFromQueue(jobId) {
        if (!confirm('Remove this job from the queue?')) return;

        try {
            const response = await opsFetch(`/api/monitoring/queue/${jobId}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                this.showNotification('Job removed from queue', 'success');
                this.loadDashboardData();
            } else {
                throw new Error('Failed to remove job');
            }
        } catch (error) {
            console.error('Error removing job:', error);
            this.showNotification('Failed to remove job', 'error');
        }
    },

    // =========================================
    // Server Actions
    // =========================================
    async runAuditOnServer(serverId) {
        // Update button to show loading
        const btn = document.querySelector(`[data-server-id="${serverId}"] .btn-primary`);
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '⏳ Starting...';
        }

        try {
            const response = await opsFetch('/api/audit/run', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify({ serverId })
            });

            if (response.ok) {
                const data = await response.json();
                this.showNotification(`Audit started on server`, 'success');

                // Expand live output and start watching
                this.expandLiveOutput();
                this.startWatchingJob(data.jobId);

                // Update server panel to show running status
                const panel = document.querySelector(`[data-server-id="${serverId}"]`);
                if (panel) {
                    panel.classList.remove('idle');
                    panel.classList.add('running');
                    const statusDot = panel.querySelector('.ops-server-status-dot');
                    if (statusDot) {
                        statusDot.classList.remove('idle');
                        statusDot.classList.add('running');
                        statusDot.title = 'Running';
                    }
                }

                // Refresh data after a short delay
                setTimeout(() => this.loadDashboardData(), 1000);
            } else {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to start audit');
            }
        } catch (error) {
            console.error('Error starting audit:', error);
            this.showNotification(`Failed to start audit: ${error.message}`, 'error');
        } finally {
            // Reset button
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '▶️ Run Audit';
            }
        }
    },

    expandLiveOutput() {
        this.expandedOutput = true;
        const panel = document.querySelector('.ops-live-output');
        const body = document.getElementById('live-output-body');
        if (panel) panel.classList.add('expanded');
        if (body) body.style.display = 'block';
    },

    startWatchingJob(jobId) {
        // Poll for job updates
        this.watchingJobId = jobId;
        this.pollJobOutput(jobId);
    },

    async pollJobOutput(jobId) {
        if (this.watchingJobId !== jobId) return;

        try {
            const response = await opsFetch(`/api/monitoring/jobs/${jobId}/output`, {
                credentials: 'same-origin'
            });

            if (response.ok) {
                const data = await response.json();

                // Update live output display
                const display = document.getElementById('output-display');
                const jobName = document.getElementById('live-output-job-name');
                const statusBadge = document.getElementById('live-output-status');

                if (display) {
                    display.textContent = data.output || '';
                    display.scrollTop = display.scrollHeight;
                }

                if (jobName) jobName.textContent = `Job: ${jobId.substring(0, 8)}...`;

                if (statusBadge) {
                    statusBadge.textContent = data.status === 'running' ? 'Running' : 'Completed';
                    statusBadge.className = `status-badge status-${data.status}`;
                }

                // Update stats
                if (data.stats) {
                    const passEl = document.getElementById('live-stat-pass');
                    const warnEl = document.getElementById('live-stat-warn');
                    const failEl = document.getElementById('live-stat-fail');
                    const skipEl = document.getElementById('live-stat-skip');

                    if (passEl) passEl.textContent = data.stats.pass || 0;
                    if (warnEl) warnEl.textContent = data.stats.warn || 0;
                    if (failEl) failEl.textContent = data.stats.fail || 0;
                    if (skipEl) skipEl.textContent = data.stats.skip || 0;
                }

                // Continue polling if still running
                if (data.status === 'running') {
                    setTimeout(() => this.pollJobOutput(jobId), 1000);
                } else {
                    // Job completed
                    this.watchingJobId = null;
                    this.showNotification('Audit completed!', 'success');
                    this.loadDashboardData();
                }
            }
        } catch (error) {
            console.error('Error polling job output:', error);
            this.watchingJobId = null;
        }
    },

    viewServerHistory(serverId) {
        // Switch to Reports tab and filter by server
        const reportsTab = document.querySelector('[data-tab="reports"]');
        if (reportsTab) {
            reportsTab.click();
            // Set server filter if available
            setTimeout(() => {
                const serverFilter = document.getElementById('reportServerFilter');
                if (serverFilter) {
                    serverFilter.value = serverId;
                    serverFilter.dispatchEvent(new Event('change'));
                }
            }, 100);
        }
    },

    viewCompletionDetails(completionId) {
        // Switch to Reports tab and show specific report
        const reportsTab = document.querySelector('[data-tab="reports"]');
        if (reportsTab) {
            reportsTab.click();
            setTimeout(() => {
                // Trigger report load
                if (typeof loadReportDetails === 'function') {
                    loadReportDetails(completionId);
                }
            }, 100);
        }
    },

    // =========================================
    // Real-time Updates (SSE)
    // =========================================
    setupSSE() {
        if (this.eventSource) {
            this.eventSource.close();
        }

        try {
            this.eventSource = new EventSource('/api/monitoring/stream');

            this.eventSource.onmessage = (event) => {
                const data = JSON.parse(event.data);
                this.handleSSEMessage(data);
            };

            this.eventSource.onerror = (error) => {
                console.log('SSE connection error, will retry...');
                this.eventSource.close();
                setTimeout(() => this.setupSSE(), 5000);
            };

            this.eventSource.addEventListener('job_started', (event) => {
                const data = JSON.parse(event.data);
                this.loadDashboardData();
                this.showNotification(`Job started: ${data.name}`, 'info');
            });

            this.eventSource.addEventListener('job_progress', (event) => {
                const data = JSON.parse(event.data);
                this.updateJobProgress(data);
            });

            this.eventSource.addEventListener('job_completed', (event) => {
                const data = JSON.parse(event.data);
                this.loadDashboardData();
                this.showNotification(`Job completed: ${data.name}`, 'success');
            });

            this.eventSource.addEventListener('job_output', (event) => {
                const data = JSON.parse(event.data);
                this.updateLiveOutput(data.jobId, data.output, data.stats);
            });

        } catch (error) {
            console.log('SSE not available, using polling only');
        }
    },

    handleSSEMessage(data) {
        switch (data.type) {
            case 'refresh':
                this.loadDashboardData();
                break;
            case 'output':
                this.updateLiveOutput(data.jobId, data.output, data.stats);
                break;
        }
    },

    subscribeToJobOutput(jobId) {
        // If SSE is available, we're already subscribed
        // Otherwise, poll for output
        this.pollJobOutput(jobId);
    },

    async pollJobOutput(jobId) {
        try {
            const response = await opsFetch(`/api/monitoring/jobs/${jobId}/output`);
            if (response.ok) {
                const data = await response.json();
                this.updateLiveOutput(jobId, data.output, data.stats);

                if (data.status === 'running') {
                    setTimeout(() => this.pollJobOutput(jobId), 1000);
                }
            }
        } catch (error) {
            console.log('Error polling job output:', error);
        }
    },

    updateJobProgress(data) {
        const card = document.querySelector(`.ops-job-card[data-job-id="${data.jobId}"]`);
        if (!card) return;

        const progressFill = card.querySelector('.ops-job-progress-fill');
        const progressText = card.querySelector('.ops-job-progress-text');

        if (progressFill) progressFill.style.width = `${data.progress}%`;
        if (progressText) progressText.textContent = `${data.progress}%`;

        // Update stats
        const passEl = card.querySelector('.ops-job-stat.pass');
        const warnEl = card.querySelector('.ops-job-stat.warn');
        const failEl = card.querySelector('.ops-job-stat.fail');

        if (passEl && data.passCount !== undefined) passEl.innerHTML = `✓ ${data.passCount}`;
        if (warnEl && data.warnCount !== undefined) warnEl.innerHTML = `⚠ ${data.warnCount}`;
        if (failEl && data.failCount !== undefined) failEl.innerHTML = `✗ ${data.failCount}`;
    },

    // =========================================
    // Auto Refresh
    // =========================================
    startAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }

        this.refreshInterval = setInterval(() => {
            if (this.autoRefreshEnabled) {
                this.loadDashboardData();
            }
        }, this.refreshRate);
    },

    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    },

    updateLastRefreshTime() {
        const el = document.querySelector('.ops-last-update');
        if (el) {
            el.textContent = `Last updated: ${new Date().toLocaleTimeString()}`;
        }
    },

    // =========================================
    // Utility Functions
    // =========================================
    escapeHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    },

    capitalizeFirst(str) {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    },

    showNotification(message, type = 'info') {
        // Use existing notification system if available
        if (typeof showNotification === 'function') {
            showNotification(message, type);
        } else {
            console.log(`[${type}] ${message}`);
        }
    },

    // =========================================
    // Cleanup
    // =========================================
    destroy() {
        this.stopAutoRefresh();
        if (this.eventSource) {
            this.eventSource.close();
        }
    }
};

// Initialize when Execution tab is shown
document.addEventListener('DOMContentLoaded', () => {
    // Check if we're on the execution tab
    const executionTab = document.querySelector('[data-tab="execution"]');
    if (executionTab) {
        executionTab.addEventListener('click', () => {
            setTimeout(() => operations.init(), 100);
        });
    }

    // Also init if execution tab is already visible or URL hash is #execution
    const executionPane = document.getElementById('execution-tab');
    const isExecutionHash = window.location.hash === '#execution';

    if ((executionPane && executionPane.classList.contains('active')) || isExecutionHash) {
        setTimeout(() => operations.init(), 200);
    }

    // Listen for hash changes
    window.addEventListener('hashchange', () => {
        if (window.location.hash === '#execution') {
            setTimeout(() => operations.init(), 100);
        }
    });
});

// Handle tab visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        operations.stopAutoRefresh();
    } else {
        operations.startAutoRefresh();
    }
});
