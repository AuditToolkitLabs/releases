/**
 * Overview page JavaScript
 * Handles code copy functionality and TOC navigation
 */

/**
 * Copy code block content to clipboard
 * @param {HTMLButtonElement} button - The copy button clicked
 */
function copyCode(button) {
    var codeBlock = button.previousElementSibling;
    var code = codeBlock.textContent;
    navigator.clipboard.writeText(code).then(function() {
        var originalText = button.textContent;
        button.textContent = '✓ Copied!';
        button.classList.add('copied');
        setTimeout(function() {
            button.textContent = originalText;
            button.classList.remove('copied');
        }, 2000);
    });
}

document.addEventListener('DOMContentLoaded', function() {
    // Smooth scroll for TOC links
    document.querySelectorAll('.toc a').forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            var target = document.querySelector(link.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
    
    // Copy button event listeners
    document.querySelectorAll('.copy-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            copyCode(btn);
        });
    });
});
