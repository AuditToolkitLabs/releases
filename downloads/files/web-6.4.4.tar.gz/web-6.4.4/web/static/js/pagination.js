/**
 * Frontend Pagination Helper for Security Audit Toolkit
 * 
 * Provides utilities for handling cursor-based pagination in the web UI.
 * Works with the backend pagination API implemented in pagination.py
 * 
 * Author: Security Audit Toolkit Team
 * Date: February 6, 2026
 */

class PaginationHelper {
    /**
     * Create a new pagination helper
     * 
     * @param {string} endpoint - API endpoint URL (e.g., '/api/servers')
     * @param {Object} options - Configuration options
     * @param {number} options.limit - Page size (default: 50)
     * @param {Function} options.onData - Callback for new data: (items, pagination) => void
     * @param {Function} options.onError - Error callback: (error) => void
     * @param {Object} options.filters - Additional query params (e.g., {domain: 'platform'})
     * @param {boolean} options.autoLoad - Auto-load next page when scrolling (default: false)
     * @param {string} options.apiKey - API key header value (optional)
     */
    constructor(endpoint, options = {}) {
        this.endpoint = endpoint;
        this.limit = options.limit || 50;
        this.onData = options.onData || console.log;
        this.onError = options.onError || console.error;
        this.filters = options.filters || {};
        this.autoLoad = options.autoLoad || false;
        this.apiKey = options.apiKey || null;
        
        // State
        this.currentCursor = null;
        this.previousCursors = [];
        this.hasNext = false;
        this.hasPrevious = false;
        this.loading = false;
        this.allData = [];
        
        // Auto-load setup
        if (this.autoLoad) {
            this.setupAutoLoad();
        }
    }
    
    /**
     * Build URL with query parameters
     * 
     * @param {string|null} cursor - Pagination cursor
     * @returns {string} Complete URL with query params
     */
    buildUrl(cursor = null) {
        const params = new URLSearchParams();
        
        // Add pagination params
        if (cursor) {
            params.append('cursor', cursor);
        }
        params.append('limit', this.limit);
        
        // Add filter params
        for (const [key, value] of Object.entries(this.filters)) {
            if (value !== null && value !== undefined) {
                params.append(key, value);
            }
        }
        
        return `${this.endpoint}?${params.toString()}`;
    }
    
    /**
     * Make API request with proper headers
     * 
     * @param {string} url - Request URL
     * @returns {Promise<Object>} API response
     */
    async fetch(url) {
        const headers = {
            'Content-Type': 'application/json'
        };
        
        if (this.apiKey) {
            headers['X-API-Key'] = this.apiKey;
        }
        
        const response = await fetch(url, { headers, credentials: 'include' });
        
        if (!response.ok) {
            throw new Error(`API error: ${response.status} ${response.statusText}`);
        }
        
        return await response.json();
    }
    
    /**
     * Load first page
     * 
     * @param {boolean} reset - Clear existing data (default: true)
     * @returns {Promise<Object>} Page data and pagination metadata
     */
    async loadFirst(reset = true) {
        if (this.loading) return;
        
        this.loading = true;
        
        try {
            const url = this.buildUrl(null);
            const data = await this.fetch(url);
            
            if (!data.success) {
                throw new Error(data.error || 'API request failed');
            }
            
            // Extract data based on endpoint type
            const items = this.extractItems(data);
            const pagination = data.pagination || {};
            
            // Update state
            if (reset) {
                this.allData = items;
                this.previousCursors = [];
            } else {
                this.allData.push(...items);
            }
            
            this.currentCursor = null;
            this.hasNext = pagination.has_next || false;
            this.hasPrevious = false;
            
            // Trigger callback
            this.onData(items, pagination);
            
            return { items, pagination };
        } catch (error) {
            this.onError(error);
            throw error;
        } finally {
            this.loading = false;
        }
    }
    
    /**
     * Load next page
     * 
     * @returns {Promise<Object>} Page data and pagination metadata
     */
    async loadNext() {
        if (this.loading || !this.hasNext) return;
        
        this.loading = true;
        
        try {
            const url = this.buildUrl(this.currentCursor);
            const data = await this.fetch(url);
            
            if (!data.success) {
                throw new Error(data.error || 'API request failed');
            }
            
            const items = this.extractItems(data);
            const pagination = data.pagination || {};
            
            // Save current cursor to previous stack
            if (this.currentCursor) {
                this.previousCursors.push(this.currentCursor);
            }
            
            // Update state
            this.currentCursor = pagination.next_cursor || null;
            this.hasNext = pagination.has_next || false;
            this.hasPrevious = this.previousCursors.length > 0;
            this.allData.push(...items);
            
            // Trigger callback
            this.onData(items, pagination);
            
            return { items, pagination };
        } catch (error) {
            this.onError(error);
            throw error;
        } finally {
            this.loading = false;
        }
    }
    
    /**
     * Load previous page (not implemented for cursor pagination)
     * 
     * Note: Cursor-based pagination is forward-only by design.
     * To go back, you need to re-fetch from the beginning.
     */
    async loadPrevious() {
        console.warn('Previous page not supported in cursor pagination. Use loadFirst() to restart.');
        return null;
    }
    
    /**
     * Load all pages (use with caution for large datasets)
     * 
     * @param {number} maxPages - Maximum pages to load (default: 100)
     * @returns {Promise<Array>} All items
     */
    async loadAll(maxPages = 100) {
        await this.loadFirst(true);
        
        let page = 1;
        while (this.hasNext && page < maxPages) {
            await this.loadNext();
            page++;
        }
        
        return this.allData;
    }
    
    /**
     * Extract items array from API response
     * 
     * @param {Object} data - API response
     * @returns {Array} Items array
     */
    extractItems(data) {
        // Try different response formats
        if (data.servers) return data.servers;
        if (data.audits) return data.audits;
        if (data.tasks) return data.tasks;
        if (data.data) return data.data;
        if (Array.isArray(data)) return data;
        
        console.warn('Unknown response format, using empty array');
        return [];
    }
    
    /**
     * Setup auto-loading when scroll reaches bottom
     */
    setupAutoLoad() {
        let scrollTimeout = null;
        
        window.addEventListener('scroll', () => {
            // Debounce scroll events
            if (scrollTimeout) {
                clearTimeout(scrollTimeout);
            }
            
            scrollTimeout = setTimeout(() => {
                // Check if near bottom (within 200px)
                const scrollPosition = window.innerHeight + window.scrollY;
                const documentHeight = document.documentElement.scrollHeight;
                
                if (scrollPosition >= documentHeight - 200 && this.hasNext && !this.loading) {
                    console.log('Auto-loading next page...');
                    this.loadNext();
                }
            }, 100);
        });
    }
    
    /**
     * Update filters and reload
     * 
     * @param {Object} filters - New filter values
     */
    async setFilters(filters) {
        this.filters = { ...this.filters, ...filters };
        return await this.loadFirst(true);
    }
    
    /**
     * Get current state
     * 
     * @returns {Object} Current pagination state
     */
    getState() {
        return {
            totalLoaded: this.allData.length,
            hasNext: this.hasNext,
            hasPrevious: this.hasPrevious,
            loading: this.loading,
            currentCursor: this.currentCursor
        };
    }
}

/**
 * Create pagination controls UI
 * 
 * @param {HTMLElement} container - Container element
 * @param {PaginationHelper} helper - PaginationHelper instance
 * @returns {Object} Control elements
 */
function createPaginationControls(container, helper) {
    const controls = document.createElement('div');
    controls.className = 'pagination-controls';
    controls.innerHTML = `
        <div class="pagination-info">
            <span class="pagination-count">Loaded: <strong>0</strong> items</span>
            <span class="pagination-status"></span>
        </div>
        <div class="pagination-buttons">
            <button class="btn btn-pagination" id="pagination-first" disabled>First Page</button>
            <button class="btn btn-pagination" id="pagination-next" disabled>Next Page</button>
            <button class="btn btn-pagination" id="pagination-load-all" disabled>Load All</button>
        </div>
    `;
    
    container.appendChild(controls);
    
    // Get elements
    const countSpan = controls.querySelector('.pagination-count strong');
    const statusSpan = controls.querySelector('.pagination-status');
    const firstBtn = controls.querySelector('#pagination-first');
    const nextBtn = controls.querySelector('#pagination-next');
    const loadAllBtn = controls.querySelector('#pagination-load-all');
    
    // Update state function
    const updateUI = () => {
        const state = helper.getState();
        
        countSpan.textContent = state.totalLoaded;
        firstBtn.disabled = state.loading || state.totalLoaded === 0;
        nextBtn.disabled = state.loading || !state.hasNext;
        loadAllBtn.disabled = state.loading || !state.hasNext;
        
        if (state.loading) {
            statusSpan.textContent = 'Loading...';
            statusSpan.className = 'pagination-status loading';
        } else if (state.hasNext) {
            statusSpan.textContent = 'More available';
            statusSpan.className = 'pagination-status has-more';
        } else {
            statusSpan.textContent = 'All loaded';
            statusSpan.className = 'pagination-status complete';
        }
    };
    
    // Attach event handlers
    firstBtn.addEventListener('click', async () => {
        await helper.loadFirst(true);
        updateUI();
    });
    
    nextBtn.addEventListener('click', async () => {
        await helper.loadNext();
        updateUI();
    });
    
    loadAllBtn.addEventListener('click', async () => {
        if (confirm('Load all remaining pages? This may take a while for large datasets.')) {
            await helper.loadAll();
            updateUI();
        }
    });
    
    // Update on helper callbacks
    const originalOnData = helper.onData;
    helper.onData = (items, pagination) => {
        originalOnData(items, pagination);
        updateUI();
    };
    
    updateUI();
    
    return {
        controls,
        update: updateUI
    };
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { PaginationHelper, createPaginationControls };
}
