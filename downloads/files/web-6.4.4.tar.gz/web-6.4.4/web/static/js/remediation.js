/**
 * Remediation Panel JavaScript
 *
 * Handles the SuperAdmin-only Remediation Panel functionality for applying
 * security fixes to remote servers via the fix/ folder scripts.
 *
 * Supports: Linux, Windows, Hypervisors (ESXi, Proxmox, KVM, Nutanix, Xen)
 */

// Remediation Panel State
const RemediationState = {
    authenticated: false,
    token: null,
    tokenExpiry: null,
    licenseDenied: false,
    selectedServer: null,
    selectedFixes: new Set(),
    fixes: [],
    history: [],
    loading: false,
    filters: {
        platform: '',
        category: '',
        severity: '',
        search: ''
    }
};

// Severity colors
const SEVERITY_COLORS = {
    critical: '#dc2626',
    high: '#f97316',
    medium: '#eab308',
    low: '#22c55e'
};

const SEVERITY_BADGES = {
    critical: '🔴',
    high: '🟠',
    medium: '🟡',
    low: '🟢'
};

function getRemediationApiKey() {
    return localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
}

async function remediationFetch(url, options = {}) {
    const headers = { ...(options.headers || {}) };
    const apiKey = getRemediationApiKey();
    if (apiKey && !headers['X-API-Key']) {
        headers['X-API-Key'] = apiKey;
    }

    return fetch(url, {
        credentials: 'include',
        ...options,
        headers
    });
}

/**
 * Initialize Remediation Panel
 */
function initRemediationPanel() {
    console.log('[Remediation] Initializing panel...');

    // Set up event listeners
    setupRemediationEventListeners();

    // Load initial status
    loadRemediationStatus();

    // Load servers for dropdown
    loadRemediationServers();
}

/**
 * Set up event listeners for remediation panel
 */
function setupRemediationEventListeners() {
    // Server selection
    const serverSelect = document.getElementById('remediation-server');
    if (serverSelect) {
        serverSelect.addEventListener('change', onRemediationServerChange);
    }

    // Filter controls
    const filterPlatform = document.getElementById('remediation-filter-platform');
    const filterCategory = document.getElementById('remediation-filter-category');
    const filterSeverity = document.getElementById('remediation-filter-severity');
    const filterSearch = document.getElementById('remediation-search');
    const filterButton = document.getElementById('remediation-apply-filter');

    if (filterPlatform) filterPlatform.addEventListener('change', applyRemediationFilters);
    if (filterCategory) filterCategory.addEventListener('change', applyRemediationFilters);
    if (filterSeverity) filterSeverity.addEventListener('change', applyRemediationFilters);
    if (filterSearch) filterSearch.addEventListener('input', debounce(applyRemediationFilters, 300));
    if (filterButton) filterButton.addEventListener('click', applyRemediationFilters);

    // Select all checkbox
    const selectAll = document.getElementById('remediation-select-all');
    if (selectAll) {
        selectAll.addEventListener('change', onRemediationSelectAll);
    }

    // Quick Select radio buttons (CIS Level)
    const cisLevel1Radio = document.getElementById('remediation-cis-level1');
    const cisLevel2Radio = document.getElementById('remediation-cis-level2');

    if (cisLevel1Radio) cisLevel1Radio.addEventListener('change', () => { if (cisLevel1Radio.checked) selectCISLevel(1); });
    if (cisLevel2Radio) cisLevel2Radio.addEventListener('change', () => { if (cisLevel2Radio.checked) selectCISLevel(2); });

    // Execute button
    const executeBtn = document.getElementById('remediation-execute');
    if (executeBtn) executeBtn.addEventListener('click', executeRemediation);

    // Other buttons
    const refreshBtn = document.getElementById('remediation-refresh-fixes');
    const clearOutputBtn = document.getElementById('remediation-clear-output');
    const refreshHistoryBtn = document.getElementById('remediation-refresh-history');
    const unlockBtn = document.getElementById('unlock-remediation-btn');

    if (refreshBtn) refreshBtn.addEventListener('click', loadRemediationFixes);
    if (clearOutputBtn) clearOutputBtn.addEventListener('click', clearRemediationOutput);
    if (refreshHistoryBtn) refreshHistoryBtn.addEventListener('click', loadRemediationHistory);
    if (unlockBtn) unlockBtn.addEventListener('click', showRemediationAuthModal);
}

/**
 * Load remediation feature status
 */
async function loadRemediationStatus() {
    try {
        const response = await remediationFetch('/api/remediation/status', {
            headers: { 'Content-Type': 'application/json' }
        });

        if (!response.ok) {
            if (response.status === 403) {
                const data = await response.json().catch(() => ({}));
                RemediationState.licenseDenied = data.code === 'FEATURE_UNAVAILABLE';
                if (RemediationState.licenseDenied) {
                    showRemediationGateMessage(data);
                }
                return;
            }
            throw new Error('Failed to load status');
        }

        const data = await response.json();
        if (data.success) {
            RemediationState.licenseDenied = false;
            updateRemediationUI(data.data);
        }
    } catch (error) {
        console.error('[Remediation] Failed to load status:', error);
    }
}

function showRemediationGateMessage(status = {}) {
    const authNotice = document.getElementById('remediation-auth-notice');
    const serverSelect = document.getElementById('remediation-server');
    const selectAll = document.getElementById('remediation-select-all');
    const refreshBtn = document.getElementById('remediation-refresh-fixes');
    const historyBtn = document.getElementById('remediation-refresh-history');
    const executeBtn = document.getElementById('remediation-execute');

    if (authNotice) {
        authNotice.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 0.4rem;">
                <span style="color: #f59e0b; font-weight: 600;">🔐 Remediation Requires SuperAdmin + Add-On Access</span>
                <span style="color: var(--text-secondary);">${status.reason || 'This remediation tool is not available on the current license.'}</span>
                ${status.upgrade_tier ? `<span style="color: var(--text-secondary);">Required entitlement: <strong>${status.upgrade_tier}</strong></span>` : ''}
            </div>
        `;
        authNotice.style.background = 'rgba(245, 158, 11, 0.12)';
        authNotice.style.borderColor = '#f59e0b';
    }

    if (serverSelect) serverSelect.disabled = true;
    if (selectAll) selectAll.disabled = true;
    if (refreshBtn) refreshBtn.disabled = true;
    if (historyBtn) historyBtn.disabled = true;
    if (executeBtn) executeBtn.disabled = true;
}

/**
 * Update UI based on status
 */
function updateRemediationUI(status) {
    // Update platform counts
    const linuxCount = document.getElementById('remediation-linux-count');
    const windowsCount = document.getElementById('remediation-windows-count');
    const hypervisorCount = document.getElementById('remediation-hypervisor-count');

    if (linuxCount && status.platforms?.linux) {
        linuxCount.textContent = status.platforms.linux.fix_count + '+';
    }
    if (windowsCount && status.platforms?.windows) {
        windowsCount.textContent = status.platforms.windows.fix_count + '+';
    }
    if (hypervisorCount && status.platforms?.hypervisors) {
        hypervisorCount.textContent = status.platforms.hypervisors.fix_count + '+';
    }
}

/**
 * Load servers for dropdown
 */
async function loadRemediationServers() {
    try {
        const response = await remediationFetch('/api/servers', {
            headers: { 'Content-Type': 'application/json' }
        });

        if (!response.ok) throw new Error('Failed to load servers');

        const data = await response.json();
        const servers = data.servers || data.data || [];

        const select = document.getElementById('remediation-server');
        if (select) {
            select.innerHTML = '<option value="">Select a server...</option>';
            servers.forEach(server => {
                const option = document.createElement('option');
                option.value = server.id;
                option.textContent = `${server.hostname} (${server.os_type || 'Unknown'})`;
                option.dataset.osType = server.os_type || 'linux';
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('[Remediation] Failed to load servers:', error);
    }
}

/**
 * Handle server selection change
 */
function onRemediationServerChange(event) {
    const serverId = event.target.value;
    const select = event.target;
    const selectedOption = select.options[select.selectedIndex];

    if (serverId) {
        RemediationState.selectedServer = {
            id: serverId,
            osType: selectedOption.dataset.osType || 'linux'
        };

        // Update OS type display
        const osTypeEl = document.getElementById('remediation-os-type');
        const statusEl = document.getElementById('remediation-server-status');

        if (osTypeEl) {
            const osText = RemediationState.selectedServer.osType;
            osTypeEl.textContent = osText.charAt(0).toUpperCase() + osText.slice(1);
            osTypeEl.className = 'badge badge-info';
        }
        if (statusEl) {
            statusEl.textContent = '● Selected';
            statusEl.className = 'badge badge-success';
        }

        // Load fixes if authenticated
        if (RemediationState.authenticated) {
            loadRemediationFixes();
        }
    } else {
        RemediationState.selectedServer = null;

        const osTypeEl = document.getElementById('remediation-os-type');
        const statusEl = document.getElementById('remediation-server-status');

        if (osTypeEl) {
            osTypeEl.textContent = '-';
            osTypeEl.className = 'badge badge-info';
        }
        if (statusEl) {
            statusEl.textContent = '● Not Selected';
            statusEl.className = 'badge badge-secondary';
        }
    }

    updateRemediationButtons();
}

/**
 * Show authentication modal
 */
function showRemediationAuthModal() {
    const modalHtml = `
        <div id="remediation-auth-modal" class="modal" style="display: flex;">
            <div class="modal-content" style="max-width: 400px;">
                <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h3 style="margin: 0;">🔓 Unlock Remediation Access</h3>
                    <button type="button" class="btn btn-small btn-secondary" onclick="closeRemediationAuthModal()">✕</button>
                </div>
                <form id="remediation-auth-form" onsubmit="submitRemediationAuth(event)">
                    <div class="form-group">
                        <label for="remediation-auth-password">Enter your password to confirm identity:</label>
                        <input type="password" id="remediation-auth-password" class="text-input" required autofocus>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <div style="padding: 0.75rem; background: rgba(234, 179, 8, 0.1); border: 1px solid #eab308; border-radius: 8px;">
                            <small style="color: #eab308;">⚠️ All remediation actions are logged for audit purposes.</small>
                        </div>
                    </div>
                    <div class="form-actions" style="display: flex; justify-content: flex-end; gap: 0.5rem; margin-top: 1.5rem;">
                        <button type="button" class="btn btn-secondary" onclick="closeRemediationAuthModal()">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="remediation-auth-submit">🔓 Unlock</button>
                    </div>
                </form>
                <div id="remediation-auth-error" class="error-message" style="display: none; margin-top: 1rem;"></div>
            </div>
        </div>
    `;

    // Remove existing modal if present
    const existingModal = document.getElementById('remediation-auth-modal');
    if (existingModal) existingModal.remove();

    // Add modal to DOM
    document.body.insertAdjacentHTML('beforeend', modalHtml);

    // Focus password field
    setTimeout(() => {
        document.getElementById('remediation-auth-password')?.focus();
    }, 100);
}

/**
 * Close authentication modal
 */
function closeRemediationAuthModal() {
    const modal = document.getElementById('remediation-auth-modal');
    if (modal) modal.remove();
}

/**
 * Submit authentication
 */
async function submitRemediationAuth(event) {
    event.preventDefault();

    const password = document.getElementById('remediation-auth-password')?.value;
    const submitBtn = document.getElementById('remediation-auth-submit');
    const errorEl = document.getElementById('remediation-auth-error');

    if (!password) return;

    // Disable button
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = '⏳ Authenticating...';
    }

    try {
        const response = await remediationFetch('/api/remediation/auth/unlock', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password })
        });

        const data = await response.json();

        if (response.ok && data.success) {
            RemediationState.authenticated = true;
            RemediationState.token = data.token;
            RemediationState.tokenExpiry = new Date(data.expires_at);

            // Update UI
            updateRemediationAuthUI(true);
            closeRemediationAuthModal();

            // Load fixes
            if (RemediationState.selectedServer) {
                loadRemediationFixes();
            }

            showNotification('Remediation access unlocked', 'success');
        } else {
            throw new Error(data.error || 'Authentication failed');
        }
    } catch (error) {
        if (errorEl) {
            errorEl.textContent = error.message;
            errorEl.style.display = 'block';
        }

        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = '🔓 Unlock';
        }
    }
}

/**
 * Update UI after authentication state change
 */
function updateRemediationAuthUI(authenticated) {
    const authNotice = document.getElementById('remediation-auth-notice');
    const serverSelect = document.getElementById('remediation-server');
    const selectAll = document.getElementById('remediation-select-all');
    const refreshBtn = document.getElementById('remediation-refresh-fixes');
    const historyBtn = document.getElementById('remediation-refresh-history');

    if (authenticated) {
        if (authNotice) {
            authNotice.innerHTML = `
                <span style="color: #22c55e;">✅ Remediation access unlocked</span>
                <span style="color: var(--text-secondary);">Expires: ${RemediationState.tokenExpiry?.toLocaleTimeString() || 'N/A'}</span>
            `;
            authNotice.style.background = 'rgba(34, 197, 94, 0.1)';
            authNotice.style.borderColor = '#22c55e';
        }

        if (serverSelect) serverSelect.disabled = false;
        if (selectAll) selectAll.disabled = false;
        if (refreshBtn) refreshBtn.disabled = false;
        if (historyBtn) historyBtn.disabled = false;

        // Load history
        loadRemediationHistory();
    } else {
        if (authNotice) {
            authNotice.innerHTML = `
                <span style="color: #dc2626;">🔒 Secondary authentication required</span>
                <button class="btn btn-small btn-primary" onclick="showRemediationAuthModal()" style="background: linear-gradient(135deg, #dc2626, #b91c1c);">🔓 Unlock Remediation Access</button>
            `;
            authNotice.style.background = 'rgba(220, 38, 38, 0.1)';
            authNotice.style.borderColor = '#dc2626';
        }

        if (serverSelect) serverSelect.disabled = true;
        if (selectAll) selectAll.disabled = true;
        if (refreshBtn) refreshBtn.disabled = true;
        if (historyBtn) historyBtn.disabled = true;
    }

    updateRemediationButtons();
}

/**
 * Load available fixes
 */
async function loadRemediationFixes() {
    if (!RemediationState.authenticated) return;

    RemediationState.loading = true;

    try {
        const params = new URLSearchParams();
        if (RemediationState.filters.platform) params.append('os_type', RemediationState.filters.platform);
        if (RemediationState.filters.category) params.append('category', RemediationState.filters.category);
        if (RemediationState.filters.severity) params.append('severity', RemediationState.filters.severity);
        if (RemediationState.filters.search) params.append('search', RemediationState.filters.search);

        const response = await remediationFetch(`/api/remediation/fixes?${params}`, {
            headers: {
                'Content-Type': 'application/json',
                'X-Remediation-Token': RemediationState.token
            }
        });

        if (!response.ok) throw new Error('Failed to load fixes');

        const data = await response.json();
        if (data.success) {
            RemediationState.fixes = data.data.fixes || [];
            renderRemediationFixes();
            updateCategoryFilter();
        }
    } catch (error) {
        console.error('[Remediation] Failed to load fixes:', error);
        showNotification('Failed to load fixes: ' + error.message, 'error');
    } finally {
        RemediationState.loading = false;
    }
}

/**
 * Render fixes table
 */
function renderRemediationFixes() {
    const tbody = document.getElementById('remediation-fix-tbody');
    if (!tbody) return;

    if (RemediationState.fixes.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 2rem; color: var(--text-secondary);">
                    No fixes found matching filters
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = RemediationState.fixes.map(fix => {
        const fixId = String(fix.id);
        const isSelected = RemediationState.selectedFixes.has(fixId);
        return `
        <tr data-fix-id="${fixId}" class="${isSelected ? 'selected' : ''}">
            <td>
                <input type="checkbox" class="fix-checkbox" data-fix-id="${fixId}"
                    ${isSelected ? 'checked' : ''}
                    ${fix.blacklisted ? 'disabled title="This fix is blacklisted"' : ''}
                    onchange="onFixCheckboxChange(this)">
            </td>
            <td>
                <code style="font-size: 0.85rem; ${fix.blacklisted ? 'text-decoration: line-through;' : ''}">${fixId}</code>
            </td>
            <td style="${fix.blacklisted ? 'text-decoration: line-through;' : ''}">${fix.name}</td>
            <td><span class="badge badge-secondary">${fix.category}</span></td>
            <td><code style="font-size: 0.8rem;">${fix.cis || '-'}</code></td>
            <td>
                <span class="badge" style="background: ${SEVERITY_COLORS[fix.severity] || '#666'}; color: white;">
                    ${SEVERITY_BADGES[fix.severity] || ''} ${fix.severity}
                </span>
            </td>
            <td style="text-align: center;">
                ${fix.rollback ? '✅' : '❌'}
            </td>
        </tr>
    `}).join('');
}

/**
 * Handle individual fix checkbox change
 */
function onFixCheckboxChange(checkbox) {
    const fixId = checkbox.dataset.fixId;

    if (checkbox.checked) {
        RemediationState.selectedFixes.add(fixId);
    } else {
        RemediationState.selectedFixes.delete(fixId);
    }

    // Update row styling
    const row = checkbox.closest('tr');
    if (row) {
        row.classList.toggle('selected', checkbox.checked);
    }

    updateRemediationButtons();
}

/**
 * Handle select all checkbox
 */
function onRemediationSelectAll(event) {
    const checked = event.target.checked;
    const checkboxes = document.querySelectorAll('#remediation-fix-tbody .fix-checkbox:not([disabled])');

    checkboxes.forEach(cb => {
        cb.checked = checked;
        const fixId = cb.dataset.fixId;

        if (checked) {
            RemediationState.selectedFixes.add(fixId);
        } else {
            RemediationState.selectedFixes.delete(fixId);
        }

        const row = cb.closest('tr');
        if (row) row.classList.toggle('selected', checked);
    });

    updateRemediationButtons();
}

/**
 * Update action buttons based on state
 */
function updateRemediationButtons() {
    const cisLevel1Radio = document.getElementById('remediation-cis-level1');
    const cisLevel2Radio = document.getElementById('remediation-cis-level2');
    const modePreviewRadio = document.getElementById('remediation-mode-preview');
    const modeApplyRadio = document.getElementById('remediation-mode-apply');
    const executeBtn = document.getElementById('remediation-execute');
    const selectedCount = document.getElementById('remediation-selected-count');

    const hasServer = !!RemediationState.selectedServer;
    const hasSelection = RemediationState.selectedFixes.size > 0;
    const isAuthenticated = RemediationState.authenticated;

    if (RemediationState.licenseDenied) {
        if (cisLevel1Radio) cisLevel1Radio.disabled = true;
        if (cisLevel2Radio) cisLevel2Radio.disabled = true;
        if (modePreviewRadio) modePreviewRadio.disabled = true;
        if (modeApplyRadio) modeApplyRadio.disabled = true;
        if (executeBtn) executeBtn.disabled = true;
        if (selectedCount) {
            selectedCount.textContent = 'Tool locked by license policy';
        }
        return;
    }

    // Enable/disable radio buttons based on auth state
    if (cisLevel1Radio) cisLevel1Radio.disabled = !(hasServer && isAuthenticated);
    if (cisLevel2Radio) cisLevel2Radio.disabled = !(hasServer && isAuthenticated);
    if (modePreviewRadio) modePreviewRadio.disabled = !(hasServer && isAuthenticated);
    if (modeApplyRadio) modeApplyRadio.disabled = !(hasServer && isAuthenticated);

    // Enable execute button only if authenticated, has server, and has selection
    if (executeBtn) executeBtn.disabled = !(hasServer && hasSelection && isAuthenticated);

    if (selectedCount) {
        selectedCount.textContent = `${RemediationState.selectedFixes.size} fixes selected`;
    }
}

/**
 * Execute remediation based on selected mode
 */
async function executeRemediation() {
    const modeApplyRadio = document.getElementById('remediation-mode-apply');
    const isApplyMode = modeApplyRadio && modeApplyRadio.checked;

    if (isApplyMode) {
        await applySelectedFixes();
    } else {
        await previewSelectedFixes();
    }
}

/**
 * Apply filters
 */
function applyRemediationFilters() {
    const platform = document.getElementById('remediation-filter-platform')?.value || '';
    const category = document.getElementById('remediation-filter-category')?.value || '';
    const severity = document.getElementById('remediation-filter-severity')?.value || '';
    const search = document.getElementById('remediation-search')?.value || '';

    RemediationState.filters = { platform, category, severity, search };

    loadRemediationFixes();
}

/**
 * Update category filter based on platform
 */
function updateCategoryFilter() {
    const categories = new Set();
    RemediationState.fixes.forEach(fix => {
        if (fix.category) categories.add(fix.category);
    });

    const select = document.getElementById('remediation-filter-category');
    if (select) {
        const currentValue = select.value;
        select.innerHTML = '<option value="">All Categories</option>';

        Array.from(categories).sort().forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat.charAt(0).toUpperCase() + cat.slice(1).replace(/-/g, ' ');
            select.appendChild(option);
        });

        select.value = currentValue;
    }
}

/**
 * Preview selected fixes
 */
async function previewSelectedFixes() {
    if (!RemediationState.selectedServer || RemediationState.selectedFixes.size === 0) return;

    const fixes = Array.from(RemediationState.selectedFixes);
    appendRemediationOutput(`\n📋 Previewing ${fixes.length} fix(es)...\n`);

    for (const fixId of fixes) {
        await executeFix(fixId, true);
    }

    appendRemediationOutput(`\n✅ Preview complete. Review output before applying.\n`);
}

/**
 * Apply selected fixes
 */
async function applySelectedFixes() {
    if (!RemediationState.selectedServer || RemediationState.selectedFixes.size === 0) return;

    const fixes = Array.from(RemediationState.selectedFixes);

    // Confirm dialog
    const confirmed = confirm(
        `⚠️ WARNING: You are about to apply ${fixes.length} fix(es) to the selected server.\n\n` +
        `This will modify system configurations. This action is logged.\n\n` +
        `Fixes to apply:\n${fixes.join(', ')}\n\n` +
        `Are you sure you want to proceed?`
    );

    if (!confirmed) return;

    appendRemediationOutput(`\n⚡ Applying ${fixes.length} fix(es)...\n`);

    for (const fixId of fixes) {
        await executeFix(fixId, false);
    }

    appendRemediationOutput(`\n✅ Execution complete.\n`);

    // Refresh history
    loadRemediationHistory();
}

/**
 * Execute a single fix
 */
async function executeFix(fixId, dryRun = true) {
    const endpoint = dryRun ? '/api/remediation/preview' : '/api/remediation/execute';
    const mode = dryRun ? 'DRY-RUN' : 'APPLY';

    appendRemediationOutput(`\n[${mode}] ${fixId}...\n`);

    try {
        const response = await remediationFetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Remediation-Token': RemediationState.token
            },
            body: JSON.stringify({
                server_id: RemediationState.selectedServer.id,
                fix_id: fixId,
                confirm: !dryRun
            })
        });

        const data = await response.json();

        if (data.success) {
            appendRemediationOutput(data.data.output || `[PASS] ${fixId} completed\n`);
        } else {
            throw new Error(data.error || 'Execution failed');
        }
    } catch (error) {
        appendRemediationOutput(`[FAIL] ${fixId}: ${error.message}\n`, 'error');
    }
}

/**
 * Select CIS Level fixes
 */
function selectCISLevel(level) {
    // Clear current selection
    RemediationState.selectedFixes.clear();

    // Select fixes that match CIS level benchmarks
    RemediationState.fixes.forEach(fix => {
        // Convert fix.id to string for consistent comparison with data attributes
        const fixId = String(fix.id);

        if (level === 1) {
            // Level 1: Select high/critical fixes that are safe (basic hardening)
            if ((fix.severity === 'high' || fix.severity === 'critical') && !fix.blacklisted) {
                RemediationState.selectedFixes.add(fixId);
            }
        } else if (level === 2) {
            // Level 2: Select all non-blacklisted fixes (comprehensive hardening)
            if (!fix.blacklisted) {
                RemediationState.selectedFixes.add(fixId);
            }
        }
    });

    // Update checkboxes
    document.querySelectorAll('#remediation-fix-tbody .fix-checkbox').forEach(cb => {
        const fixId = cb.dataset.fixId;
        const isSelected = RemediationState.selectedFixes.has(fixId);
        cb.checked = isSelected;
        const row = cb.closest('tr');
        if (row) row.classList.toggle('selected', isSelected);
    });

    updateRemediationButtons();
    showNotification(`Selected ${RemediationState.selectedFixes.size} CIS Level ${level} fixes`, 'info');
}

/**
 * Load execution history
 */
async function loadRemediationHistory() {
    if (!RemediationState.authenticated) return;

    try {
        const response = await remediationFetch('/api/remediation/history?per_page=10', {
            headers: {
                'Content-Type': 'application/json',
                'X-Remediation-Token': RemediationState.token
            }
        });

        if (!response.ok) throw new Error('Failed to load history');

        const data = await response.json();
        if (data.success) {
            RemediationState.history = data.data.executions || [];
            renderRemediationHistory();
        }
    } catch (error) {
        console.error('[Remediation] Failed to load history:', error);
    }
}

/**
 * Render execution history
 */
function renderRemediationHistory() {
    const tbody = document.getElementById('remediation-history-tbody');
    if (!tbody) return;

    if (RemediationState.history.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 1rem; color: var(--text-secondary);">
                    No executions yet
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = RemediationState.history.map(exec => {
        const statusBadge = getStatusBadge(exec.status);
        const time = exec.executed_at ? new Date(exec.executed_at).toLocaleString() : '-';

        return `
            <tr>
                <td>#${exec.id}</td>
                <td><code>${exec.fix_id}</code></td>
                <td>${exec.server_hostname || 'Unknown'}</td>
                <td><span class="badge ${exec.mode === 'apply' ? 'badge-warning' : 'badge-info'}">${exec.mode}</span></td>
                <td>${statusBadge}</td>
                <td style="font-size: 0.85rem;">${time}</td>
                <td>
                    <button class="btn btn-small btn-secondary" onclick="showExecutionDetails(${exec.id})">📋</button>
                    ${exec.rollback_available && exec.status === 'success' ?
                        `<button class="btn btn-small btn-warning" onclick="rollbackExecution(${exec.id})">↩️</button>` : ''}
                </td>
            </tr>
        `;
    }).join('');
}

/**
 * Get status badge HTML
 */
function getStatusBadge(status) {
    const badges = {
        'success': '<span class="badge badge-success">✅ Success</span>',
        'failed': '<span class="badge badge-danger">❌ Failed</span>',
        'running': '<span class="badge badge-info">⏳ Running</span>',
        'pending': '<span class="badge badge-secondary">⏸️ Pending</span>',
        'rolled_back': '<span class="badge badge-warning">↩️ Rolled Back</span>',
    };
    return badges[status] || `<span class="badge badge-secondary">${status}</span>`;
}

/**
 * Show execution details
 */
async function showExecutionDetails(executionId) {
    try {
        const response = await remediationFetch(`/api/remediation/history/${executionId}`, {
            headers: {
                'Content-Type': 'application/json',
                'X-Remediation-Token': RemediationState.token
            }
        });

        if (!response.ok) throw new Error('Failed to load details');

        const data = await response.json();
        if (data.success) {
            const exec = data.data;
            alert(
                `Execution #${exec.id}\n\n` +
                `Fix: ${exec.fix_id} - ${exec.fix_name}\n` +
                `Server: ${exec.server_hostname}\n` +
                `Mode: ${exec.mode}\n` +
                `Status: ${exec.status}\n` +
                `Exit Code: ${exec.exit_code}\n` +
                `Duration: ${exec.duration_seconds}s\n\n` +
                `Command:\n${exec.command_executed}\n\n` +
                `Output:\n${exec.stdout || 'No output'}`
            );
        }
    } catch (error) {
        showNotification('Failed to load details: ' + error.message, 'error');
    }
}

/**
 * Rollback an execution
 */
async function rollbackExecution(executionId) {
    if (!confirm('Are you sure you want to rollback this fix? This will attempt to restore the previous state.')) {
        return;
    }

    try {
        const response = await remediationFetch(`/api/remediation/rollback/${executionId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Remediation-Token': RemediationState.token
            }
        });

        const data = await response.json();

        if (data.success) {
            showNotification('Rollback completed successfully', 'success');
            loadRemediationHistory();
        } else {
            throw new Error(data.error || 'Rollback failed');
        }
    } catch (error) {
        showNotification('Rollback failed: ' + error.message, 'error');
    }
}

/**
 * Append text to output console
 */
function appendRemediationOutput(text, type = 'normal') {
    const output = document.getElementById('remediation-output');
    if (!output) return;

    // Remove placeholder
    const placeholder = output.querySelector('.output-placeholder');
    if (placeholder) placeholder.remove();

    const color = type === 'error' ? '#dc2626' : (type === 'success' ? '#22c55e' : '#d4d4d4');
    const span = document.createElement('span');
    span.style.color = color;
    span.textContent = text;

    output.appendChild(span);
    output.scrollTop = output.scrollHeight;
}

/**
 * Clear output console
 */
function clearRemediationOutput() {
    const output = document.getElementById('remediation-output');
    if (output) {
        output.innerHTML = '<div class="output-placeholder" style="color: #666;">Output will appear here...</div>';
    }
}

/**
 * Debounce helper
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize if we're on the admin tab and user is SuperAdmin
    const adminTab = document.getElementById('admin-tab');
    if (adminTab) {
        // Check if remediation panel exists
        const remediationPanel = document.getElementById('admin-panel-remediation');
        if (remediationPanel) {
            initRemediationPanel();
        }
    }
});

// Export for global access
window.showRemediationAuthModal = showRemediationAuthModal;
window.closeRemediationAuthModal = closeRemediationAuthModal;
window.submitRemediationAuth = submitRemediationAuth;
window.onFixCheckboxChange = onFixCheckboxChange;
window.showExecutionDetails = showExecutionDetails;
window.rollbackExecution = rollbackExecution;
