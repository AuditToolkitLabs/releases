/**
 * Executive Reports JavaScript
 * Handles HTML/PDF executive report generation UI
 */

// XSS prevention helper
function escapeHtml(unsafe) {
    if (unsafe == null) return '';
    const div = document.createElement('div');
    div.textContent = String(unsafe);
    return div.innerHTML;
}

// Global state
const reportState = {
    servers: [],
    selectedServers: new Set(),
    reportData: null,
    capabilities: null,
    isGenerating: false
};

// CSRF Token management
let cachedCsrfToken = null;

function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta && meta.content) {
        return meta.content;
    }
    return cachedCsrfToken || '';
}

async function initCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (!meta || !meta.content) {
        try {
            const response = await fetch('/auth/csrf-token', { credentials: 'include' });
            const data = await response.json();
            cachedCsrfToken = data.csrf_token;
        } catch (error) {
            console.warn('[Reports] Failed to fetch CSRF token:', error);
        }
    }
}

// API configuration - use session auth
const API_BASE = window.location.origin;

/**
 * Make authenticated API request with CSRF protection
 */
async function apiRequest(endpoint, options = {}) {
    options.headers = options.headers || {};
    options.headers['Content-Type'] = 'application/json';
    options.credentials = 'include';

    // Add CSRF token for state-changing requests
    const method = (options.method || 'GET').toUpperCase();
    if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method)) {
        const csrfToken = getCsrfToken();
        if (csrfToken) {
            options.headers['X-CSRFToken'] = csrfToken;
        }
    }

    const response = await fetch(`${API_BASE}${endpoint}`, options);
    if (!response.ok) {
        const error = await response.json().catch(() => ({ error: response.statusText }));
        throw new Error(error.error || response.statusText);
    }
    return response.json();
}

/**
 * Initialize the reports page
 */
document.addEventListener('DOMContentLoaded', async function() {
    console.log('[Reports] Initializing executive reports page...');

    // Setup event listeners FIRST for immediate interactivity
    setupEventListeners();

    // Initialize CSRF token for secure API calls
    await initCsrfToken();

    // Load data in background (non-blocking)
    try {
        await Promise.all([
            loadCapabilities(),
            loadServers()
        ]);
        console.log('[Reports] Data loading complete');
    } catch (error) {
        console.error('[Reports] Error loading initial data:', error);
    }

    console.log('[Reports] Initialization complete');
});

/**
 * Setup event listeners for all buttons
 */
function setupEventListeners() {
    // Server selection
    const selectAllBtn = document.getElementById('select-all-servers');
    if (selectAllBtn) selectAllBtn.addEventListener('click', selectAllServers);

    const clearSelectionBtn = document.getElementById('clear-selection');
    if (clearSelectionBtn) clearSelectionBtn.addEventListener('click', clearSelection);

    // Report generation
    const generateDataBtn = document.getElementById('generate-data-btn');
    if (generateDataBtn) generateDataBtn.addEventListener('click', generateReportData);

    const generateHtmlBtn = document.getElementById('generate-html-btn');
    if (generateHtmlBtn) generateHtmlBtn.addEventListener('click', generateHtmlReport);

    const generatePdfBtn = document.getElementById('generate-pdf-btn');
    if (generatePdfBtn) generatePdfBtn.addEventListener('click', generatePdfReport);

    // Preview
    const previewBtn = document.getElementById('preview-btn');
    if (previewBtn) previewBtn.addEventListener('click', togglePreview);

    // Refresh
    const refreshBtn = document.getElementById('refresh-servers');
    if (refreshBtn) refreshBtn.addEventListener('click', loadServers);
}

/**
 * Load available report capabilities
 */
async function loadCapabilities() {
    try {
        reportState.capabilities = await apiRequest('/api/reports/executive/capabilities');
        console.log('[Reports] Capabilities:', reportState.capabilities);

        // Update UI based on capabilities
        const pdfBtn = document.getElementById('generate-pdf-btn');
        if (pdfBtn) {
            pdfBtn.disabled = !reportState.capabilities.capabilities?.pdf_export;
            if (!reportState.capabilities.capabilities?.pdf_export) {
                pdfBtn.title = 'PDF export requires WeasyPrint. Install with: pip install weasyprint';
            }
        }

        // Show supported frameworks
        const frameworkSelect = document.getElementById('compliance-framework');
        if (frameworkSelect && reportState.capabilities.capabilities?.supported_frameworks) {
            frameworkSelect.innerHTML = '<option value="">No Compliance Mapping</option>';
            reportState.capabilities.capabilities.supported_frameworks.forEach(framework => {
                const option = document.createElement('option');
                option.value = framework;
                option.textContent = framework;
                frameworkSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('[Reports] Failed to load capabilities:', error);
        showError('Failed to load report capabilities. Some features may be unavailable.');
    }
}

/**
 * Load available servers
 */
async function loadServers() {
    try {
        showLoading('servers-list', 'Loading servers...');

        const data = await apiRequest('/api/reports/servers');
        reportState.servers = data.servers || [];

        renderServerList();
        updateStats();
    } catch (error) {
        console.error('[Reports] Failed to load servers:', error);
        showError('Failed to load servers: ' + error.message);
    }
}

/**
 * Render the server list
 */
function renderServerList() {
    const container = document.getElementById('servers-list');
    if (!container) return;

    if (reportState.servers.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <p>No servers configured. Add servers in the Servers section first.</p>
            </div>
        `;
        return;
    }

    container.innerHTML = reportState.servers.map(server => `
        <div class="server-item ${reportState.selectedServers.has(server.id) ? 'selected' : ''}"
             data-server-id="${server.id}"
             onclick="toggleServer(${server.id})">
            <div class="server-checkbox">
                <input type="checkbox" ${reportState.selectedServers.has(server.id) ? 'checked' : ''}
                       onchange="toggleServer(${server.id})">
            </div>
            <div class="server-info">
                <div class="server-name">${escapeHtml(server.name)}</div>
                <div class="server-host">${escapeHtml(server.host)}</div>
            </div>
            <div class="server-status">
                <span class="status-badge ${server.status || 'unknown'}">${escapeHtml(server.status || 'Unknown')}</span>
            </div>
        </div>
    `).join('');
}

/**
 * Toggle server selection
 */
function toggleServer(serverId) {
    if (reportState.selectedServers.has(serverId)) {
        reportState.selectedServers.delete(serverId);
    } else {
        reportState.selectedServers.add(serverId);
    }
    renderServerList();
    updateStats();
    // Clear previous report data when selection changes
    reportState.reportData = null;
    updateActionButtons();
}

/**
 * Select all servers
 */
function selectAllServers() {
    reportState.servers.forEach(s => reportState.selectedServers.add(s.id));
    renderServerList();
    updateStats();
    reportState.reportData = null;
    updateActionButtons();
}

/**
 * Clear server selection
 */
function clearSelection() {
    reportState.selectedServers.clear();
    renderServerList();
    updateStats();
    reportState.reportData = null;
    updateActionButtons();
}

/**
 * Update statistics display
 */
function updateStats() {
    const totalEl = document.getElementById('total-servers');
    const selectedEl = document.getElementById('selected-servers');

    if (totalEl) totalEl.textContent = reportState.servers.length;
    if (selectedEl) selectedEl.textContent = reportState.selectedServers.size;
}

/**
 * Update action buttons state
 */
function updateActionButtons() {
    const generateDataBtn = document.getElementById('generate-data-btn');
    const generateHtmlBtn = document.getElementById('generate-html-btn');
    const generatePdfBtn = document.getElementById('generate-pdf-btn');
    const previewBtn = document.getElementById('preview-btn');

    const hasSelection = reportState.selectedServers.size > 0;
    const hasData = reportState.reportData !== null;

    if (generateDataBtn) generateDataBtn.disabled = !hasSelection || reportState.isGenerating;
    if (generateHtmlBtn) generateHtmlBtn.disabled = !hasData || reportState.isGenerating;
    if (generatePdfBtn) {
        generatePdfBtn.disabled = !hasData || reportState.isGenerating ||
                                  !reportState.capabilities?.capabilities?.pdf_export;
    }
    if (previewBtn) previewBtn.disabled = !hasData;
}

/**
 * Generate report data from selected servers
 */
async function generateReportData() {
    if (reportState.selectedServers.size === 0) {
        showError('Please select at least one server');
        return;
    }

    reportState.isGenerating = true;
    updateActionButtons();
    showLoading('report-preview', 'Fetching audit data from servers...');

    try {
        const serverIds = Array.from(reportState.selectedServers);
        const reportType = document.getElementById('report-type')?.value || 'detailed';

        const data = await apiRequest('/api/reports/generate', {
            method: 'POST',
            body: JSON.stringify({
                server_ids: serverIds,
                report_type: reportType
            })
        });

        if (data.success && data.report) {
            reportState.reportData = data.report;
            showSuccess('Report data generated successfully');
            showReportSummary(data.report);
        } else {
            throw new Error(data.error || 'Failed to generate report data');
        }
    } catch (error) {
        console.error('[Reports] Failed to generate data:', error);
        showError('Failed to generate report data: ' + error.message);
    } finally {
        reportState.isGenerating = false;
        updateActionButtons();
    }
}

/**
 * Show report summary in preview area
 */
function showReportSummary(report) {
    const container = document.getElementById('report-preview');
    if (!container) return;

    const summary = report.summary || {};
    const compliance = summary.compliance_percentage || 0;
    const complianceClass = compliance >= 85 ? 'good' : compliance >= 70 ? 'warning' : 'critical';

    container.innerHTML = `
        <div class="report-summary-card">
            <h3>Report Data Ready</h3>
            <div class="summary-metrics">
                <div class="metric">
                    <span class="metric-value">${summary.total_servers || 0}</span>
                    <span class="metric-label">Servers</span>
                </div>
                <div class="metric">
                    <span class="metric-value">${summary.total_checks || 0}</span>
                    <span class="metric-label">Total Checks</span>
                </div>
                <div class="metric pass">
                    <span class="metric-value">${summary.total_pass || 0}</span>
                    <span class="metric-label">Passed</span>
                </div>
                <div class="metric warn">
                    <span class="metric-value">${summary.total_warn || 0}</span>
                    <span class="metric-label">Warnings</span>
                </div>
                <div class="metric fail">
                    <span class="metric-value">${summary.total_fail || 0}</span>
                    <span class="metric-label">Failed</span>
                </div>
                <div class="metric ${complianceClass}">
                    <span class="metric-value">${compliance.toFixed(1)}%</span>
                    <span class="metric-label">Compliance</span>
                </div>
            </div>
            <p class="hint">Now click "Generate HTML Report" or "Generate PDF Report" to create the executive report.</p>
        </div>
    `;
}

/**
 * Generate HTML executive report
 */
async function generateHtmlReport() {
    if (!reportState.reportData) {
        showError('Please generate report data first');
        return;
    }

    reportState.isGenerating = true;
    updateActionButtons();
    showLoading('report-output', 'Generating HTML executive report...');

    try {
        const options = getReportOptions();

        const data = await apiRequest('/api/reports/executive', {
            method: 'POST',
            body: JSON.stringify({
                report: reportState.reportData,
                ...options
            })
        });

        if (data.success) {
            showSuccess(`HTML report generated: ${data.filename}`);
            offerDownload(data.content, data.filename, data.mime_type);
        } else {
            throw new Error(data.error || 'Failed to generate HTML report');
        }
    } catch (error) {
        console.error('[Reports] Failed to generate HTML:', error);
        showError('Failed to generate HTML report: ' + error.message);
    } finally {
        reportState.isGenerating = false;
        updateActionButtons();
    }
}

/**
 * Generate PDF executive report
 */
async function generatePdfReport() {
    if (!reportState.reportData) {
        showError('Please generate report data first');
        return;
    }

    reportState.isGenerating = true;
    updateActionButtons();
    showLoading('report-output', 'Generating PDF executive report...');

    try {
        const options = getReportOptions();
        const csrfToken = getCsrfToken();
        const headers = {
            'Content-Type': 'application/json'
        };
        if (csrfToken) {
            headers['X-CSRFToken'] = csrfToken;
        }

        const response = await fetch(`${API_BASE}/api/reports/executive/pdf`, {
            method: 'POST',
            headers: headers,
            credentials: 'include',
            body: JSON.stringify({
                report: reportState.reportData,
                ...options
            })
        });

        if (response.ok) {
            const blob = await response.blob();
            const filename = response.headers.get('Content-Disposition')?.match(/filename="(.+)"/)?.[1]
                           || 'executive-report.pdf';

            // Create download link
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            showSuccess(`PDF report downloaded: ${filename}`);
        } else {
            const error = await response.json().catch(() => ({ error: 'Unknown error' }));
            throw new Error(error.error || 'Failed to generate PDF');
        }
    } catch (error) {
        console.error('[Reports] Failed to generate PDF:', error);
        showError('Failed to generate PDF report: ' + error.message);
    } finally {
        reportState.isGenerating = false;
        updateActionButtons();
    }
}

/**
 * Get report options from form inputs
 */
function getReportOptions() {
    return {
        organization: document.getElementById('organization')?.value || undefined,
        compliance_framework: document.getElementById('compliance-framework')?.value || undefined,
        classification: document.getElementById('classification')?.value || 'Confidential',
        include_charts: document.getElementById('include-charts')?.checked ?? true,
        include_executive_summary: document.getElementById('include-summary')?.checked ?? true,
        contact_email: document.getElementById('contact-email')?.value || undefined
    };
}

/**
 * Offer file download
 */
function offerDownload(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    // Also show preview option
    const outputEl = document.getElementById('report-output');
    if (outputEl && mimeType.includes('html')) {
        outputEl.innerHTML = `
            <div class="download-success">
                <p>✓ Report downloaded: <strong>${escapeHtml(filename)}</strong></p>
                <button class="btn btn-secondary" onclick="previewHtml()">Preview in New Tab</button>
            </div>
        `;

        // Store for preview
        window._lastReportContent = content;
    }
}

/**
 * Preview HTML report in new tab
 */
function previewHtml() {
    if (window._lastReportContent) {
        const blob = new Blob([window._lastReportContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        window.open(url, '_blank');
    }
}

/**
 * Toggle preview panel
 */
function togglePreview() {
    const previewEl = document.getElementById('report-preview');
    if (previewEl) {
        previewEl.classList.toggle('expanded');
    }
}

/**
 * UI Helpers
 */
function showLoading(elementId, message) {
    const el = document.getElementById(elementId);
    if (el) {
        el.innerHTML = `<div class="loading"><span class="spinner"></span> ${escapeHtml(message)}</div>`;
    }
}

function showError(message) {
    const toastContainer = document.getElementById('toast-container') || createToastContainer();
    const toast = document.createElement('div');
    toast.className = 'toast toast-error';
    toast.innerHTML = `<span class="toast-icon">✕</span> ${escapeHtml(message)}`;
    toastContainer.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
}

function showSuccess(message) {
    const toastContainer = document.getElementById('toast-container') || createToastContainer();
    const toast = document.createElement('div');
    toast.className = 'toast toast-success';
    toast.innerHTML = `<span class="toast-icon">✓</span> ${escapeHtml(message)}`;
    toastContainer.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
    return container;
}
