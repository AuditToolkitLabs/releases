/**
 * Schedules Page JavaScript
 * Handles scheduled audit management UI
 */

// XSS prevention helper
function escapeHtml(unsafe) {
    if (unsafe == null) return '';
    const div = document.createElement('div');
    div.textContent = String(unsafe);
    return div.innerHTML;
}

// Wrapper for fetch that includes session credentials
async function schedFetch(url, options = {}) {
    const defaultOptions = { credentials: 'include' };
    return fetch(url, { ...defaultOptions, ...options });
}

const API_BASE = '/api/v2';
let currentSchedules = [];
let servers = [];
let hypervisors = [];
let audits = [];

// Load initial data
async function init() {
    await Promise.all([
        loadServers(),
        loadHypervisors(),
        loadAudits(),
        loadCronPresets()
    ]);
    await loadSchedules();
    setupTargetTypeHandler();
}

async function loadServers() {
    try {
        const response = await schedFetch('/api/servers');
        if (!response.ok) {
            console.error('Error loading servers: HTTP', response.status);
            return;
        }
        const data = await response.json();
        servers = data.servers || [];

        // Populate server dropdowns
        const serverSelects = document.querySelectorAll('#serverFilter, #scheduleServer');
        serverSelects.forEach(select => {
            if (select.id === 'scheduleServer') {
                select.innerHTML = '<option value="">Select a server...</option>';
            }
            servers.forEach(server => {
                const option = document.createElement('option');
                option.value = server.id;
                option.textContent = `${server.name} (${server.hostname})`;
                select.appendChild(option);
            });
        });
    } catch (error) {
        console.error('Error loading servers:', error);
    }
}

async function loadHypervisors() {
    try {
        const response = await schedFetch('/api/hypervisors');
        if (!response.ok) {
            console.error('Error loading hypervisors: HTTP', response.status);
            return;
        }
        const data = await response.json();
        hypervisors = data.hypervisors || [];

        // Populate hypervisor dropdown
        const hvSelect = document.getElementById('scheduleHypervisor');
        if (hvSelect) {
            hvSelect.innerHTML = '<option value="">Select a hypervisor...</option>';
            hypervisors.forEach(hv => {
                const option = document.createElement('option');
                option.value = hv.id;
                option.textContent = `${hv.name} (${hv.hostname})`;
                hvSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error loading hypervisors:', error);
    }
}

function setupTargetTypeHandler() {
    const targetTypeSelect = document.getElementById('scheduleTargetType');
    const serverGroup = document.getElementById('serverSelectGroup');
    const hypervisorGroup = document.getElementById('hypervisorSelectGroup');

    if (!targetTypeSelect || !serverGroup || !hypervisorGroup) return;

    targetTypeSelect.addEventListener('change', function() {
        const targetType = this.value;
        if (targetType === 'hypervisor') {
            serverGroup.style.display = 'none';
            hypervisorGroup.style.display = 'block';
            document.getElementById('scheduleServer').required = false;
            document.getElementById('scheduleHypervisor').required = true;
        } else {
            serverGroup.style.display = 'block';
            hypervisorGroup.style.display = 'none';
            document.getElementById('scheduleServer').required = true;
            document.getElementById('scheduleHypervisor').required = false;
        }
    });
}

async function loadAudits() {
    try {
        const response = await schedFetch('/api/audits');
        if (!response.ok) {
            console.error('Error loading audits: HTTP', response.status);
            return;
        }
        const data = await response.json();
        audits = data.audits || [];

        // Populate audit dropdown
        const auditSelect = document.getElementById('scheduleAudit');
        auditSelect.innerHTML = '<option value="">Select an audit...</option>';
        audits.forEach(audit => {
            const option = document.createElement('option');
            // Use 'path' as the unique identifier (audits don't have 'id' field)
            option.value = audit.path || audit.id;
            option.textContent = `${audit.display_name || audit.name} (${audit.domain})`;
            auditSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading audits:', error);
    }
}

async function loadCronPresets() {
    try {
        const response = await schedFetch(`${API_BASE}/schedules/cron-presets`);
        const data = await response.json();
        const presetsContainer = document.getElementById('cronPresets');
        presetsContainer.innerHTML = data.presets.map(preset => `
            <div class="cron-preset" onclick="selectCronPreset('${escapeHtml(preset.pattern).replace(/'/g, "\\'")}')">
                <div class="cron-preset-pattern">${escapeHtml(preset.pattern)}</div>
                <div class="cron-preset-desc">${escapeHtml(preset.description)}</div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading cron presets:', error);
    }
}

function selectCronPreset(pattern) {
    document.getElementById('scheduleCron').value = pattern;
}

async function loadSchedules() {
    const container = document.getElementById('schedulesContainer');
    container.innerHTML = '<div class="loading">Loading schedules...</div>';

    try {
        const serverFilter = document.getElementById('serverFilter').value;
        const activeOnly = document.getElementById('activeOnlyFilter').checked;

        let url = `${API_BASE}/schedules?`;
        if (serverFilter) url += `server_id=${serverFilter}&`;
        if (activeOnly) url += `active_only=true&`;

        // Fetch both regular schedules and agent schedules in parallel
        const [schedulesResponse, agentSchedulesResponse] = await Promise.all([
            schedFetch(url),
            schedFetch('/api/agents/schedules').catch(() => ({ ok: false }))
        ]);

        if (!schedulesResponse.ok) {
            throw new Error(`HTTP ${schedulesResponse.status}: ${schedulesResponse.statusText}`);
        }
        const data = await schedulesResponse.json();

        if (!data.success) {
            showMessage(data.error || 'Unknown error loading schedules', 'error');
            container.innerHTML = `<div class="error">Failed to load schedules: ${escapeHtml(data.error || 'Unknown error')}</div>`;
            return;
        }

        currentSchedules = data.schedules || [];

        // Merge agent schedules if available
        if (agentSchedulesResponse.ok) {
            try {
                const agentData = await agentSchedulesResponse.json();
                if (agentData.success && agentData.schedules) {
                    // Filter by active only if needed
                    let agentSchedules = agentData.schedules;
                    if (activeOnly) {
                        agentSchedules = agentSchedules.filter(s => s.is_active);
                    }
                    currentSchedules = [...currentSchedules, ...agentSchedules];
                }
            } catch (e) {
                console.warn('Could not parse agent schedules:', e);
            }
        }

        // Update stats
        document.getElementById('totalSchedules').textContent = currentSchedules.length;
        document.getElementById('activeSchedules').textContent =
            currentSchedules.filter(s => s.is_active).length;

        // Calculate next execution
        const nextSchedule = currentSchedules
            .filter(s => s.is_active && s.next_run)
            .sort((a, b) => new Date(a.next_run) - new Date(b.next_run))[0];
        document.getElementById('nextExecution').textContent =
            nextSchedule ? new Date(nextSchedule.next_run).toLocaleString() : 'None';

        // Render schedules
        if (currentSchedules.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <h2>No Schedules Yet</h2>
                    <p>Create your first scheduled audit to automate security checks.</p>
                    <button onclick="showCreateModal()" style="margin-top: 20px;">Create Schedule</button>
                </div>
            `;
        } else {
            container.innerHTML = `
            <table class="schedules-table">
                <thead>
                    <tr>
                        <th style="width: 70px;">Status</th>
                        <th>Name</th>
                        <th>Target</th>
                        <th>Audit</th>
                        <th>Schedule</th>
                        <th>Next Run</th>
                        <th>Last Run</th>
                        <th style="width: 180px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
            ` + currentSchedules.map(schedule => {
                // Handle agent schedules differently
                const isAgentSchedule = schedule.schedule_source === 'agent';
                let targetName, targetType, auditName;

                if (isAgentSchedule) {
                    targetName = schedule.agent_name || schedule.agent_id || 'Unknown Agent';
                    targetType = '🤖';
                    auditName = (schedule.audits || []).join(', ') || 'Agent Audits';
                } else {
                    targetName = schedule.hypervisor?.name || schedule.server?.name || 'Unknown';
                    targetType = schedule.hypervisor_id ? '🖥️' : '💻';
                    auditName = schedule.hypervisor_id ? 'Hypervisor Audit' : (schedule.audit?.name || 'Unknown');
                }

                // Get schedule type badge for agent schedules
                const scheduleTypeBadge = isAgentSchedule && schedule.schedule_type ?
                    `<span class="schedule-type-badge ${schedule.schedule_type}">${schedule.schedule_type}</span>` : '';

                return `
                    <tr class="schedule-row ${schedule.is_active ? 'active' : 'inactive'} ${isAgentSchedule ? 'agent-schedule' : ''}">
                        <td>
                            <span class="schedule-status-badge ${schedule.is_active ? 'active' : 'inactive'}">
                                ${schedule.is_active ? 'Active' : 'Inactive'}
                            </span>
                        </td>
                        <td class="schedule-name-cell">
                            <strong>${escapeHtml(schedule.name)}</strong>
                            ${schedule.notification_enabled ? '<span class="notify-icon" title="Notifications enabled">✉️</span>' : ''}
                            ${scheduleTypeBadge}
                        </td>
                        <td>${targetType} ${escapeHtml(targetName)}</td>
                        <td>${escapeHtml(auditName)}</td>
                        <td>
                            <span class="cron-desc">${escapeHtml(schedule.cron_description || '')}</span>
                            <code class="cron-expr">${escapeHtml(schedule.cron_schedule)}</code>
                        </td>
                        <td class="schedule-time">${schedule.next_run ? new Date(schedule.next_run).toLocaleString() : '-'}</td>
                        <td class="schedule-time">
                            ${schedule.last_run ? new Date(schedule.last_run).toLocaleString() : 'Never'}
                            ${schedule.last_status ? `<span class="last-status ${schedule.last_status}">${escapeHtml(schedule.last_status)}</span>` : ''}
                        </td>
                        <td class="schedule-actions">
                            ${isAgentSchedule ? `
                                <button onclick="triggerAgentSchedule('${escapeHtml(schedule.agent_id)}')" class="btn btn-small btn-primary" title="Trigger Now">⚡</button>
                                <button onclick="openAgentConfig('${escapeHtml(schedule.agent_id)}')" class="btn btn-small" title="Configure">⚙️</button>
                            ` : `
                                <button onclick="toggleSchedule(${parseInt(schedule.id, 10)})" class="btn btn-small" title="${schedule.is_active ? 'Disable' : 'Enable'}">
                                    ${schedule.is_active ? '⏸️' : '▶️'}
                                </button>
                                <button onclick="runScheduleNow(${parseInt(schedule.id, 10)})" class="btn btn-small btn-primary" title="Run Now">⚡</button>
                                <button onclick="deleteSchedule(${parseInt(schedule.id, 10)})" class="btn btn-small btn-danger" title="Delete">🗑️</button>
                            `}
                        </td>
                    </tr>
            `}).join('') + '</tbody></table>';
        }
    } catch (error) {
        console.error('Error loading schedules:', error);
        container.innerHTML = `<div class="error">Failed to load schedules: ${escapeHtml(error.message)}</div>`;
    }
}

function showCreateModal() {
    document.getElementById('scheduleModal').classList.add('active');
    document.getElementById('scheduleForm').reset();
}

function closeModal() {
    document.getElementById('scheduleModal').classList.remove('active');
}

async function saveSchedule(event) {
    event.preventDefault();

    const executionModeEl = document.getElementById('scheduleExecutionMode');
    const targetType = document.getElementById('scheduleTargetType')?.value || 'server';

    const formData = {
        name: document.getElementById('scheduleName').value,
        cron_schedule: document.getElementById('scheduleCron').value,
        execution_mode: executionModeEl ? executionModeEl.value : 'stream',
        is_active: document.getElementById('scheduleActive').checked,
        notification_enabled: document.getElementById('notificationEnabled').checked,
        notification_emails: document.getElementById('notificationEmails').value.trim(),
        notification_webhooks: document.getElementById('notificationWebhooks').value.trim(),
        target_type: targetType
    };

    // Set server_id or hypervisor_id based on target type
    if (targetType === 'hypervisor') {
        formData.hypervisor_id = parseInt(document.getElementById('scheduleHypervisor').value);
        formData.server_id = null;
        formData.audit_id = null; // Hypervisor audits use built-in audit
    } else {
        formData.server_id = parseInt(document.getElementById('scheduleServer').value);
        formData.audit_id = parseInt(document.getElementById('scheduleAudit').value);
        formData.hypervisor_id = null;
    }

    try {
        const response = await schedFetch(`${API_BASE}/schedules`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(formData)
        });

        const data = await response.json();

        if (data.success) {
            showMessage('Schedule created successfully!', 'success');
            closeModal();
            await loadSchedules();
        } else {
            showMessage(data.error || 'Failed to create schedule', 'error');
        }
    } catch (error) {
        showMessage('Error creating schedule: ' + error.message, 'error');
    }
}

async function toggleSchedule(id) {
    if (!confirm('Toggle this schedule?')) return;

    try {
        const response = await schedFetch(`${API_BASE}/schedules/${id}/toggle`, {
            method: 'POST'
        });
        const data = await response.json();

        if (data.success) {
            showMessage(data.message, 'success');
            await loadSchedules();
        } else {
            showMessage(data.error, 'error');
        }
    } catch (error) {
        showMessage('Error toggling schedule: ' + error.message, 'error');
    }
}

async function runScheduleNow(id) {
    if (!confirm('Run this audit now (outside normal schedule)?')) return;

    try {
        const response = await schedFetch(`${API_BASE}/schedules/${id}/run-now`, {
            method: 'POST'
        });
        const data = await response.json();

        if (data.success) {
            showMessage(`Audit queued for execution. Task ID: ${data.task_id}`, 'success');
        } else {
            showMessage(data.error, 'error');
        }
    } catch (error) {
        showMessage('Error triggering audit: ' + error.message, 'error');
    }
}

async function deleteSchedule(id) {
    if (!confirm('Delete this schedule permanently?')) return;

    try {
        const response = await schedFetch(`${API_BASE}/schedules/${id}`, {
            method: 'DELETE'
        });
        const data = await response.json();

        if (data.success) {
            showMessage(data.message, 'success');
            await loadSchedules();
        } else {
            showMessage(data.error, 'error');
        }
    } catch (error) {
        showMessage('Error deleting schedule: ' + error.message, 'error');
    }
}

// =============================================================================
// Agent Schedule Functions
// =============================================================================

async function triggerAgentSchedule(agentId) {
    if (!confirm(`Trigger audit now on agent ${agentId}?`)) return;

    try {
        const response = await schedFetch('/api/agents/trigger', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ agents: [agentId] })
        });
        const data = await response.json();

        if (data.success) {
            showMessage(`Audit triggered for agent ${agentId}`, 'success');
        } else {
            showMessage(data.error || 'Failed to trigger audit', 'error');
        }
    } catch (error) {
        showMessage('Error triggering agent audit: ' + error.message, 'error');
    }
}

function openAgentConfig(agentId) {
    // Navigate to hypervisors page and open agent management modal
    if (typeof window.AgentMgmt !== 'undefined' && typeof window.AgentMgmt.open === 'function') {
        // Already on a page with agent management
        window.AgentMgmt.open();
        setTimeout(() => {
            if (typeof window.AgentMgmt.switchTab === 'function') {
                window.AgentMgmt.switchTab('agents-deploy');
            }
        }, 100);
    } else {
        // Navigate to hypervisors page with agent config intent
        window.location.href = '/hypervisors?configAgent=' + encodeURIComponent(agentId);
    }
}

function showMessage(message, type) {
    const container = document.getElementById('messageContainer');
    const div = document.createElement('div');
    div.className = type;
    div.textContent = message;
    container.appendChild(div);
    setTimeout(() => div.remove(), 5000);
}

function showCronHelper() {
    window.open('https://crontab.guru/', '_blank');
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    init();

    // Button event listeners
    var createScheduleBtn = document.getElementById('create-schedule-btn');
    if (createScheduleBtn) createScheduleBtn.addEventListener('click', showCreateModal);

    var refreshSchedulesBtn = document.getElementById('refresh-schedules-btn');
    if (refreshSchedulesBtn) refreshSchedulesBtn.addEventListener('click', loadSchedules);

    var cronHelperBtn = document.getElementById('cron-helper-btn');
    if (cronHelperBtn) cronHelperBtn.addEventListener('click', showCronHelper);

    var cancelModalBtn = document.getElementById('cancel-modal-btn');
    if (cancelModalBtn) cancelModalBtn.addEventListener('click', closeModal);

    // Filter event listeners
    var serverFilter = document.getElementById('serverFilter');
    if (serverFilter) serverFilter.addEventListener('change', loadSchedules);

    var activeOnlyFilter = document.getElementById('activeOnlyFilter');
    if (activeOnlyFilter) activeOnlyFilter.addEventListener('change', loadSchedules);

    // Form submit listener
    var scheduleForm = document.getElementById('scheduleForm');
    if (scheduleForm) scheduleForm.addEventListener('submit', saveSchedule);
});
