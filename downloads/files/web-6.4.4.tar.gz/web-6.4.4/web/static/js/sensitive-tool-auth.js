(function () {
    'use strict';

    function getCsrfToken() {
        return document.querySelector('meta[name="csrf-token"]')?.content || '';
    }

    async function authFetch(url, options = {}) {
        const headers = { ...(options.headers || {}) };
        const csrfToken = getCsrfToken();
        if (options.method && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(options.method.toUpperCase()) && csrfToken) {
            headers['X-CSRFToken'] = csrfToken;
        }
        if (options.body && !headers['Content-Type']) {
            headers['Content-Type'] = 'application/json';
        }

        return fetch(url, {
            ...options,
            credentials: 'same-origin',
            headers,
        });
    }

    let currentResolver = null;
    let currentConfig = null;
    let handlersBound = false;

    function setModalText(config) {
        document.getElementById('sensitive-tool-auth-title').textContent = config.title;
        document.getElementById('sensitive-tool-auth-heading').textContent = config.title;
        document.getElementById('sensitive-tool-auth-notice').textContent = config.notice;
        document.getElementById('sensitive-tool-auth-submit').textContent = config.buttonText || 'Authenticate';
        document.getElementById('sensitive-tool-auth-success-text').textContent = config.successText || 'Access authorized';
    }

    function openModal(config) {
        currentConfig = config;
        setModalText(config);

        const modal = document.getElementById('sensitive-tool-auth-modal');
        const errorEl = document.getElementById('sensitive-tool-auth-error');
        const statusEl = document.getElementById('sensitive-tool-auth-status');
        const passwordInput = document.getElementById('sensitive-tool-auth-password');

        if (errorEl) {
            errorEl.textContent = '';
            errorEl.style.display = 'none';
        }
        if (statusEl) {
            statusEl.style.display = 'none';
        }
        if (passwordInput) {
            passwordInput.value = '';
        }
        if (modal) {
            modal.style.display = 'flex';
        }

        setTimeout(() => passwordInput?.focus(), 0);

        return new Promise((resolve) => {
            currentResolver = resolve;
        });
    }

    function closeModal(result) {
        const modal = document.getElementById('sensitive-tool-auth-modal');
        if (modal) {
            modal.style.display = 'none';
        }
        if (currentResolver) {
            const resolve = currentResolver;
            currentResolver = null;
            resolve(!!result);
        }
        currentConfig = null;
    }

    async function submitAuthentication() {
        if (!currentConfig) return;

        const passwordInput = document.getElementById('sensitive-tool-auth-password');
        const errorEl = document.getElementById('sensitive-tool-auth-error');
        const statusEl = document.getElementById('sensitive-tool-auth-status');
        const submitBtn = document.getElementById('sensitive-tool-auth-submit');
        const expiresEl = document.getElementById('sensitive-tool-auth-expires');
        const password = passwordInput?.value || '';

        if (errorEl) {
            errorEl.textContent = '';
            errorEl.style.display = 'none';
        }
        if (submitBtn) submitBtn.disabled = true;

        try {
            const response = await authFetch(currentConfig.authenticateUrl, {
                method: 'POST',
                body: JSON.stringify({ password }),
            });
            const data = await response.json();
            if (!response.ok || !data.success) {
                throw new Error(data.error || 'Authentication failed');
            }

            if (statusEl) {
                statusEl.style.display = 'block';
            }
            if (expiresEl && data.expires_in) {
                expiresEl.textContent = `Valid for ${Math.floor(data.expires_in / 60)} min`;
            }

            setTimeout(() => closeModal(true), 200);
        } catch (error) {
            if (errorEl) {
                errorEl.textContent = error.message;
                errorEl.style.display = 'block';
            }
        } finally {
            if (submitBtn) submitBtn.disabled = false;
        }
    }

    function bindHandlers() {
        if (handlersBound) return;
        handlersBound = true;

        const form = document.getElementById('sensitive-tool-auth-form');
        const cancelBtn = document.getElementById('cancel-sensitive-tool-auth');
        const closeBtn = document.getElementById('close-sensitive-tool-auth-modal');
        const modal = document.getElementById('sensitive-tool-auth-modal');

        form?.addEventListener('submit', async (event) => {
            event.preventDefault();
            await submitAuthentication();
        });

        cancelBtn?.addEventListener('click', () => closeModal(false));
        closeBtn?.addEventListener('click', () => closeModal(false));

        modal?.addEventListener('click', (event) => {
            if (event.target === modal) {
                closeModal(false);
            }
        });
    }

    async function ensureUnlocked(config) {
        bindHandlers();

        try {
            const response = await authFetch(config.statusUrl, { method: 'GET' });
            const data = await response.json();
            if (response.ok && data.authenticated) {
                return true;
            }
        } catch (error) {
            console.error('Sensitive tool auth status check failed:', error);
        }

        return openModal(config);
    }

    window.SensitiveToolAuth = {
        authFetch,
        ensureUnlocked,
    };
}());