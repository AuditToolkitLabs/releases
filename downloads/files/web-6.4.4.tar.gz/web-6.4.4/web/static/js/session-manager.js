/**
 * Session Timeout Warning Manager
 * 
 * Tracks user activity and shows a warning before session expires.
 * Allows users to extend their session without losing work.
 * 
 * TESTING: In browser console, run:
 *   - window.sessionManager.testWarning()  - Show warning dialog
 *   - window.sessionManager.getStatus()    - Check session status
 */

(function() {
    'use strict';

    // Configuration (in milliseconds)
    // For testing, you can temporarily change these values:
    // const SESSION_TIMEOUT = 60 * 1000;    // 1 minute for testing
    // const WARNING_THRESHOLD = 30 * 1000;  // 30 seconds warning
    const SESSION_TIMEOUT = 30 * 60 * 1000;  // 30 minutes default
    const WARNING_THRESHOLD = 5 * 60 * 1000; // Warn 5 minutes before expiry
    const CHECK_INTERVAL = 30 * 1000;        // Check every 30 seconds
    
    console.log('[SessionManager] Initialized - timeout:', SESSION_TIMEOUT / 1000, 'seconds');

    let lastActivity = Date.now();
    let warningShown = false;
    let checkTimer = null;
    let modalElement = null;

    /**
     * Update last activity timestamp
     */
    function updateActivity() {
        lastActivity = Date.now();
        if (warningShown) {
            hideWarning();
        }
    }

    /**
     * Get time remaining before session expires
     */
    function getTimeRemaining() {
        return SESSION_TIMEOUT - (Date.now() - lastActivity);
    }

    /**
     * Format milliseconds to human readable time
     */
    function formatTime(ms) {
        const minutes = Math.floor(ms / 60000);
        const seconds = Math.floor((ms % 60000) / 1000);
        if (minutes > 0) {
            return `${minutes}m ${seconds}s`;
        }
        return `${seconds}s`;
    }

    /**
     * Create and show the warning modal
     */
    function showWarning() {
        if (warningShown) return;
        warningShown = true;

        // Create modal if it doesn't exist
        if (!modalElement) {
            modalElement = document.createElement('div');
            modalElement.id = 'session-timeout-modal';
            modalElement.className = 'session-modal-overlay';
            modalElement.innerHTML = `
                <div class="session-modal">
                    <div class="session-modal-icon">⏰</div>
                    <h3>Session Expiring Soon</h3>
                    <p>Your session will expire in <span id="session-countdown" class="session-countdown"></span></p>
                    <p class="session-modal-hint">Click anywhere or press any key to stay logged in.</p>
                    <div class="session-modal-buttons">
                        <button id="session-extend-btn" class="btn btn-primary">Stay Logged In</button>
                        <button id="session-logout-btn" class="btn btn-secondary">Logout Now</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modalElement);

            // Event listeners
            document.getElementById('session-extend-btn').addEventListener('click', extendSession);
            document.getElementById('session-logout-btn').addEventListener('click', logout);
        }

        modalElement.classList.add('visible');
        updateCountdown();
    }

    /**
     * Hide the warning modal
     */
    function hideWarning() {
        warningShown = false;
        if (modalElement) {
            modalElement.classList.remove('visible');
        }
    }

    /**
     * Update the countdown timer in the modal
     */
    function updateCountdown() {
        if (!warningShown) return;

        const remaining = getTimeRemaining();
        const countdownEl = document.getElementById('session-countdown');
        
        if (countdownEl) {
            countdownEl.textContent = formatTime(Math.max(0, remaining));
        }

        if (remaining <= 0) {
            // Session expired
            logout();
        } else if (remaining < WARNING_THRESHOLD) {
            // Update every second when showing warning
            setTimeout(updateCountdown, 1000);
        }
    }

    /**
     * Extend the session by updating activity
     */
    function extendSession() {
        updateActivity();
        
        // Call the server to refresh the session
        fetch('/auth/ping', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(response => {
            if (response.ok) {
                console.log('[SessionManager] Session extended successfully');
                if (typeof showToast === 'function') {
                    showToast('Session extended', 'success');
                } else if (typeof showNotification === 'function') {
                    showNotification('Session extended', 'success');
                }
            } else if (response.status === 401) {
                console.warn('[SessionManager] Session expired, redirecting to login');
                logout();
            }
        }).catch(err => {
            console.warn('[SessionManager] Ping failed:', err);
            // Local activity update is still done above
        });
    }

    /**
     * Logout the user
     */
    function logout() {
        window.location.href = '/auth/logout';
    }

    /**
     * Check session status periodically
     */
    function checkSession() {
        const remaining = getTimeRemaining();

        if (remaining <= 0) {
            // Session expired
            logout();
        } else if (remaining <= WARNING_THRESHOLD && !warningShown) {
            // Show warning
            showWarning();
        }
    }

    /**
     * Initialize the session manager
     */
    function init() {
        // Track user activity
        const activityEvents = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart', 'click'];
        
        // Throttle activity updates to prevent excessive calls
        let activityThrottle = null;
        activityEvents.forEach(event => {
            document.addEventListener(event, () => {
                if (!activityThrottle) {
                    updateActivity();
                    activityThrottle = setTimeout(() => {
                        activityThrottle = null;
                    }, 1000);
                }
            }, { passive: true });
        });

        // Start periodic checks
        checkTimer = setInterval(checkSession, CHECK_INTERVAL);

        // Add CSS for the modal
        const style = document.createElement('style');
        style.textContent = `
            .session-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.7);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 10000;
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease, visibility 0.3s ease;
            }
            .session-modal-overlay.visible {
                opacity: 1;
                visibility: visible;
            }
            .session-modal {
                background: var(--card-bg, #fff);
                border-radius: 12px;
                padding: 2rem;
                max-width: 400px;
                text-align: center;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
                animation: sessionModalPulse 2s infinite;
            }
            @keyframes sessionModalPulse {
                0%, 100% { box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3); }
                50% { box-shadow: 0 20px 60px rgba(239, 68, 68, 0.4); }
            }
            .session-modal-icon {
                font-size: 3rem;
                margin-bottom: 1rem;
            }
            .session-modal h3 {
                margin: 0 0 1rem 0;
                color: var(--text-primary, #111);
                font-size: 1.5rem;
            }
            .session-modal p {
                margin: 0.5rem 0;
                color: var(--text-secondary, #666);
            }
            .session-countdown {
                font-weight: 700;
                font-size: 1.25rem;
                color: #ef4444;
            }
            .session-modal-hint {
                font-size: 0.85rem;
                opacity: 0.8;
            }
            .session-modal-buttons {
                margin-top: 1.5rem;
                display: flex;
                gap: 1rem;
                justify-content: center;
            }
            .session-modal-buttons .btn {
                min-width: 120px;
            }
        `;
        document.head.appendChild(style);

        console.log('[SessionManager] Initialized');
    }

    // Expose test functions for debugging
    window.sessionManager = {
        testWarning: function() {
            console.log('[SessionManager] Triggering test warning...');
            showWarning();
        },
        getStatus: function() {
            const elapsed = Date.now() - lastActivity;
            const remaining = SESSION_TIMEOUT - elapsed;
            console.log('[SessionManager] Status:', {
                lastActivity: new Date(lastActivity).toLocaleTimeString(),
                elapsed: Math.round(elapsed / 1000) + ' seconds',
                remaining: Math.round(remaining / 1000) + ' seconds',
                warningShown: warningShown
            });
            return { elapsed, remaining, warningShown };
        }
    };

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
