/**
 * Global Keyboard Shortcuts
 * 
 * Provides navigation and action shortcuts for the Security Audit Toolkit.
 * All shortcuts use Ctrl+ prefix to avoid conflicts with browser shortcuts.
 */

(function() {
    'use strict';

    // Shortcut definitions
    const SHORTCUTS = {
        // Navigation shortcuts (Ctrl+Shift+Key)
        'H': { tab: 'home', description: 'Go to Home' },
        'W': { tab: 'wizard', description: 'Go to Wizard' },
        'A': { tab: 'audits', description: 'Go to Audit Selection' },
        'D': { tab: 'discovery', description: 'Go to Discovery' },
        'E': { tab: 'execution', description: 'Go to Execution' },
        'R': { tab: 'reports', description: 'Go to Reports' },
        'L': { tab: 'logs', description: 'Go to Logs' },
        'S': { tab: 'schedule', description: 'Go to Schedule' },
        'C': { tab: 'connect', description: 'Go to Connect' },
        'P': { tab: 'plans', description: 'Go to Plans' },
        'Y': { tab: 'deploy', description: 'Go to Deploy' },
        'I': { tab: 'history', description: 'Go to History' },
        'M': { tab: 'admin', description: 'Go to Admin' },
        
        // Note: K and / removed from Ctrl+Shift set due to browser conflicts
        // Help is triggered by F1, Search by Ctrl+/ (no shift)
    };

    let helpModalElement = null;
    let isEnabled = true;

    /**
     * Navigate to a specific tab
     */
    function navigateToTab(tabName) {
        const tabButton = document.querySelector(`.tab-button[data-tab="${tabName}"]`);
        if (tabButton) {
            tabButton.click();
            return true;
        }
        return false;
    }

    /**
     * Show keyboard shortcuts help modal
     */
    function showHelp() {
        if (!helpModalElement) {
            helpModalElement = document.createElement('div');
            helpModalElement.id = 'shortcuts-help-modal';
            helpModalElement.className = 'shortcuts-modal-overlay';
            
            let shortcutsHtml = '';
            Object.entries(SHORTCUTS).forEach(([key, config]) => {
                const keyCombo = `Ctrl+Shift+${key}`;
                shortcutsHtml += `
                    <div class="shortcut-row">
                        <kbd class="shortcut-key">${keyCombo}</kbd>
                        <span class="shortcut-desc">${config.description}</span>
                    </div>
                `;
            });
            
            helpModalElement.innerHTML = `
                <div class="shortcuts-modal">
                    <div class="shortcuts-modal-header">
                        <h3>⌨️ Keyboard Shortcuts</h3>
                        <button class="shortcuts-close-btn" title="Close (Esc)">&times;</button>
                    </div>
                    <div class="shortcuts-modal-body">
                        <div class="shortcuts-section">
                            <h4>Navigation (Ctrl+Shift+Key)</h4>
                            ${shortcutsHtml}
                        </div>
                        <div class="shortcuts-section">
                            <h4>General</h4>
                            <div class="shortcut-row">
                                <kbd class="shortcut-key">Esc</kbd>
                                <span class="shortcut-desc">Close modal/dialog</span>
                            </div>
                        </div>
                    </div>
                    <div class="shortcuts-modal-footer">
                        <small>Press <kbd>Esc</kbd> to close | Access via Admin &gt; Keyboard Shortcuts</small>
                    </div>
                </div>
            `;
            
            document.body.appendChild(helpModalElement);
            
            // Close button
            helpModalElement.querySelector('.shortcuts-close-btn').addEventListener('click', hideHelp);
            
            // Click outside to close
            helpModalElement.addEventListener('click', (e) => {
                if (e.target === helpModalElement) {
                    hideHelp();
                }
            });
        }
        
        helpModalElement.classList.add('visible');
    }

    /**
     * Hide the help modal
     */
    function hideHelp() {
        if (helpModalElement) {
            helpModalElement.classList.remove('visible');
        }
    }

    /**
     * Handle keyboard events
     */
    function handleKeydown(e) {
        // Skip if shortcuts are disabled
        if (!isEnabled) return;

        // Skip if user is typing in an input/textarea
        const activeElement = document.activeElement;
        const isTyping = activeElement && (
            activeElement.tagName === 'INPUT' ||
            activeElement.tagName === 'TEXTAREA' ||
            activeElement.isContentEditable
        );

        // Escape key - close modals (works even when typing)
        if (e.key === 'Escape') {
            hideHelp();
            return;
        }

        // Skip other shortcuts if typing
        if (isTyping) return;

        // Only handle Ctrl+Shift shortcuts for tab navigation
        if (!e.ctrlKey || !e.shiftKey) return;

        // Get key
        let key = e.key.toUpperCase();
        
        const shortcut = SHORTCUTS[key];

        if (shortcut) {
            e.preventDefault();
            console.log('[Shortcuts] Executing:', shortcut.description);
            
            if (shortcut.tab) {
                navigateToTab(shortcut.tab);
            }
        }
    }

    /**
     * Enable/disable shortcuts
     */
    function setEnabled(enabled) {
        isEnabled = enabled;
    }

    /**
     * Initialize keyboard shortcuts
     */
    function init() {
        document.addEventListener('keydown', handleKeydown);

        // Add CSS for the help modal
        const style = document.createElement('style');
        style.textContent = `
            .shortcuts-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.6);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 9999;
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.2s ease, visibility 0.2s ease;
            }
            .shortcuts-modal-overlay.visible {
                opacity: 1;
                visibility: visible;
            }
            .shortcuts-modal {
                background: var(--card-bg, #fff);
                border-radius: 12px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
                max-width: 500px;
                width: 90%;
                max-height: 80vh;
                overflow: hidden;
                display: flex;
                flex-direction: column;
            }
            .shortcuts-modal-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 1rem 1.5rem;
                border-bottom: 1px solid var(--border-color, #e5e7eb);
            }
            .shortcuts-modal-header h3 {
                margin: 0;
                font-size: 1.25rem;
                color: var(--text-primary, #111);
            }
            .shortcuts-close-btn {
                background: none;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                color: var(--text-secondary, #666);
                padding: 0.25rem 0.5rem;
                border-radius: 4px;
                transition: background 0.2s;
            }
            .shortcuts-close-btn:hover {
                background: var(--bg-secondary, #f3f4f6);
            }
            .shortcuts-modal-body {
                padding: 1rem 1.5rem;
                overflow-y: auto;
            }
            .shortcuts-section {
                margin-bottom: 1.5rem;
            }
            .shortcuts-section:last-child {
                margin-bottom: 0;
            }
            .shortcuts-section h4 {
                margin: 0 0 0.75rem 0;
                font-size: 0.9rem;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                color: var(--text-secondary, #666);
            }
            .shortcut-row {
                display: flex;
                align-items: center;
                gap: 1rem;
                padding: 0.5rem 0;
                border-bottom: 1px solid var(--border-color, #e5e7eb);
            }
            .shortcut-row:last-child {
                border-bottom: none;
            }
            .shortcut-key {
                display: inline-block;
                min-width: 100px;
                padding: 0.35rem 0.6rem;
                background: var(--bg-secondary, #f3f4f6);
                border: 1px solid var(--border-color, #e5e7eb);
                border-radius: 4px;
                font-family: monospace;
                font-size: 0.85rem;
                text-align: center;
                color: var(--text-primary, #111);
            }
            .shortcut-desc {
                color: var(--text-primary, #111);
                font-size: 0.95rem;
            }
            .shortcuts-modal-footer {
                padding: 0.75rem 1.5rem;
                background: var(--bg-secondary, #f3f4f6);
                text-align: center;
            }
            .shortcuts-modal-footer small {
                color: var(--text-secondary, #666);
            }
            .shortcuts-modal-footer kbd {
                padding: 0.15rem 0.4rem;
                background: var(--card-bg, #fff);
                border: 1px solid var(--border-color, #e5e7eb);
                border-radius: 3px;
                font-family: monospace;
                font-size: 0.8rem;
            }
        `;
        document.head.appendChild(style);

        // Attach listener to admin shortcuts link (CSP-compliant)
        const shortcutsLink = document.getElementById('admin-shortcuts-link');
        if (shortcutsLink) {
            shortcutsLink.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                showHelp();
            });
            console.log('[Shortcuts] Admin link listener attached');
        }

        console.log('[Shortcuts] Initialized - Ctrl+Shift+H for Home, etc.');
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose API for testing
    window.KeyboardShortcuts = {
        show: showHelp,
        hide: hideHelp,
        setEnabled: setEnabled,
        // Test functions
        testNavigate: function(tabId) {
            console.log('[Shortcuts] Testing navigation to:', tabId);
            navigateToTab(tabId);
        },
        listShortcuts: function() {
            console.table(SHORTCUTS);
        }
    };
})();
