/**
 * Server-Sent Events (SSE) Client for Real-Time Audit Progress
 * 
 * Provides utilities for streaming real-time task progress from the backend.
 * Uses native EventSource API for SSE connections.
 * 
 * Author: Security Audit Toolkit Team
 * Date: February 6, 2026
 */

// ============================================
// Debug Configuration
// ============================================
// Set to true to enable verbose SSE console logging (disable in production)
const SSE_DEBUG = false;

// Conditional debug logger - only logs when SSE_DEBUG is true
function sseLog(...args) {
    if (SSE_DEBUG) {
        console.log(...args);
    }
}

/**
 * Escape HTML special characters to prevent XSS attacks
 * @param {string} str - Input string
 * @returns {string} Escaped string safe for innerHTML
 */
function escapeHtmlSSE(str) {
    if (str === null || str === undefined) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
}

class SSEClient {
    /**
     * Create a new SSE client for task streaming
     * 
     * @param {string} taskId - Celery task ID to stream
     * @param {Object} options - Configuration options
     * @param {Function} options.onProgress - Progress callback: (data) => void
     * @param {Function} options.onOutput - Output line callback: (data) => void
     * @param {Function} options.onComplete - Completion callback: (data) => void
     * @param {Function} options.onError - Error callback: (error) => void
     * @param {Function} options.onConnected - Connection callback: () => void
     * @param {Function} options.onClose - Close callback: () => void
     * @param {number} options.timeout - Stream timeout in seconds (default: 3600)
     * @param {string} options.apiKey - API key for authentication (optional)
     */
    constructor(taskId, options = {}) {
        this.taskId = taskId;
        this.options = {
            onProgress: options.onProgress || console.log,
            onOutput: options.onOutput || console.log,
            onComplete: options.onComplete || console.log,
            onError: options.onError || console.error,
            onConnected: options.onConnected || (() => {}),
            onClose: options.onClose || (() => {}),
            timeout: options.timeout || 3600,
            apiKey: options.apiKey || null
        };
        
        this.eventSource = null;
        this.connected = false;
        this.closed = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 3;
        this.reconnectDelay = 2000; // 2 seconds
    }
    
    /**
     * Build SSE endpoint URL
     * 
     * @returns {string} SSE stream URL
     */
    buildUrl() {
        const params = new URLSearchParams();
        params.append('timeout', this.options.timeout);
        
        // Add API key to URL if provided (EventSource doesn't support custom headers)
        if (this.options.apiKey) {
            params.append('api_key', this.options.apiKey);
        }
        
        return `/api/async/tasks/${this.taskId}/stream?${params.toString()}`;
    }
    
    /**
     * Connect to SSE stream
     * 
     * @returns {Promise<void>}
     */
    connect() {
        return new Promise((resolve, reject) => {
            if (this.eventSource) {
                console.warn('SSE: Already connected');
                return resolve();
            }
            
            try {
                const url = this.buildUrl();
                sseLog(`SSE: Connecting to ${url}`);
                
                this.eventSource = new EventSource(url);
                
                // Connection established event
                this.eventSource.addEventListener('connected', (e) => {
                    const data = JSON.parse(e.data);
                    sseLog('SSE: Connected', data);
                    this.connected = true;
                    this.reconnectAttempts = 0;
                    this.options.onConnected();
                    resolve();
                });
                
                // Progress event
                this.eventSource.addEventListener('progress', (e) => {
                    const data = JSON.parse(e.data);
                    sseLog('SSE: Progress', data);
                    this.options.onProgress(data);
                });
                
                // Output event
                this.eventSource.addEventListener('output', (e) => {
                    const data = JSON.parse(e.data);
                    sseLog('SSE: Output', data);
                    this.options.onOutput(data);
                });
                
                // Complete event
                this.eventSource.addEventListener('complete', (e) => {
                    const data = JSON.parse(e.data);
                    sseLog('SSE: Complete', data);
                    this.options.onComplete(data);
                    this.disconnect();
                });
                
                // Error event
                this.eventSource.addEventListener('error', (e) => {
                    let errorData = { error: 'Unknown SSE error' };
                    try {
                        errorData = JSON.parse(e.data);
                    } catch (err) {
                        // Event data might not be JSON
                        errorData = { error: 'Connection error or stream ended' };
                    }
                    console.error('SSE: Error', errorData);
                    this.options.onError(errorData);
                    
                    // Attempt reconnection if not explicitly closed
                    if (!this.closed && this.reconnectAttempts < this.maxReconnectAttempts) {
                        this.reconnectAttempts++;
                        sseLog(`SSE: Attempting reconnect ${this.reconnectAttempts}/${this.maxReconnectAttempts}...`);
                        
                        setTimeout(() => {
                            this.disconnect();
                            this.connect().catch(console.error);
                        }, this.reconnectDelay);
                    } else {
                        this.disconnect();
                    }
                });
                
                // Timeout event
                this.eventSource.addEventListener('timeout', (e) => {
                    const data = JSON.parse(e.data);
                    console.warn('SSE: Timeout', data);
                    this.options.onError({ error: 'Stream timeout' });
                    this.disconnect();
                });
                
                // Close event
                this.eventSource.addEventListener('close', (e) => {
                    const data = JSON.parse(e.data);
                    sseLog('SSE: Close', data);
                    this.options.onClose();
                    this.disconnect();
                });
                
                // Handle native EventSource error event
                this.eventSource.onerror = (e) => {
                    console.error('SSE: Native error event', e);
                    
                    if (!this.connected) {
                        // Connection failed
                        reject(new Error('Failed to establish SSE connection'));
                    }
                };
                
            } catch (error) {
                console.error('SSE: Connection error', error);
                reject(error);
            }
        });
    }
    
    /**
     * Disconnect from SSE stream
     */
    disconnect() {
        if (this.eventSource) {
            sseLog('SSE: Disconnecting');
            this.eventSource.close();
            this.eventSource = null;
        }
        
        this.connected = false;
        this.closed = true;
    }
    
    /**
     * Check if connected
     * 
     * @returns {boolean}
     */
    isConnected() {
        return this.connected && this.eventSource && this.eventSource.readyState === EventSource.OPEN;
    }
    
    /**
     * Get connection state
     * 
     * @returns {Object} Connection state
     */
    getState() {
        return {
            taskId: this.taskId,
            connected: this.connected,
            closed: this.closed,
            reconnectAttempts: this.reconnectAttempts,
            readyState: this.eventSource ? this.eventSource.readyState : null
        };
    }
}

/**
 * Create a progress UI component for SSE streaming
 * 
 * @param {HTMLElement} container - Container element
 * @param {string} taskId - Task ID to stream
 * @param {Object} options - Additional options
 * @returns {Object} UI controller with SSE client
 */
function createProgressUI(container, taskId, options = {}) {
    // Create UI elements
    const progressUI = document.createElement('div');
    progressUI.className = 'sse-progress-container';
    progressUI.innerHTML = `
        <div class="sse-progress-header">
            <h4>Task Progress: <span class="task-id">${escapeHtmlSSE(taskId)}</span></h4>
            <button class="btn btn-sm btn-danger disconnect-btn">Disconnect</button>
        </div>
        <div class="sse-progress-bar-container">
            <div class="sse-progress-bar" style="width: 0%">0%</div>
        </div>
        <div class="sse-status">Connecting...</div>
        <div class="sse-output">
            <pre class="output-text"></pre>
        </div>
    `;
    
    container.appendChild(progressUI);
    
    // Get UI elements
    const progressBar = progressUI.querySelector('.sse-progress-bar');
    const statusDiv = progressUI.querySelector('.sse-status');
    const outputPre = progressUI.querySelector('.output-text');
    const disconnectBtn = progressUI.querySelector('.disconnect-btn');
    
    // Create SSE client
    const sseClient = new SSEClient(taskId, {
        ...options,
        
        onConnected: () => {
            statusDiv.textContent = 'Connected - Waiting for updates...';
            statusDiv.className = 'sse-status connected';
            if (options.onConnected) options.onConnected();
        },
        
        onProgress: (data) => {
            const progress = data.progress || 0;
            const status = data.status || 'Running';
            const message = data.message || '';
            
            // Update progress bar
            progressBar.style.width = `${progress}%`;
            progressBar.textContent = `${progress}%`;
            
            // Update status
            statusDiv.textContent = `${status}${message ? ' - ' + message : ''}`;
            statusDiv.className = 'sse-status running';
            
            if (options.onProgress) options.onProgress(data);
        },
        
        onOutput: (data) => {
            const output = data.output || '';
            const isError = data.is_error || false;
            
            // Append output
            const span = document.createElement('span');
            span.textContent = output + '\n';
            span.className = isError ? 'error-output' : 'normal-output';
            outputPre.appendChild(span);
            
            // Auto-scroll to bottom
            outputPre.scrollTop = outputPre.scrollHeight;
            
            if (options.onOutput) options.onOutput(data);
        },
        
        onComplete: (data) => {
            const status = data.status || 'completed';
            const result = data.result || {};
            
            // Update UI
            progressBar.style.width = '100%';
            progressBar.textContent = '100%';
            statusDiv.textContent = `Completed - ${status}`;
            statusDiv.className = `sse-status ${status}`;
            
            // Show result summary
            if (result.summary) {
                const summaryDiv = document.createElement('div');
                summaryDiv.className = 'sse-summary';
                summaryDiv.innerHTML = `
                    <h5>Summary:</h5>
                    <ul>
                        <li>Pass: ${result.summary.pass || 0}</li>
                        <li>Warn: ${result.summary.warn || 0}</li>
                        <li>Fail: ${result.summary.fail || 0}</li>
                        <li>Skip: ${result.summary.skip || 0}</li>
                        <li>Duration: ${result.duration_seconds || 0}s</li>
                    </ul>
                `;
                progressUI.appendChild(summaryDiv);
            }
            
            // Hide disconnect button
            disconnectBtn.style.display = 'none';
            
            if (options.onComplete) options.onComplete(data);
        },
        
        onError: (error) => {
            statusDiv.textContent = `Error: ${error.error || 'Unknown error'}`;
            statusDiv.className = 'sse-status error';
            disconnectBtn.textContent = 'Close';
            
            if (options.onError) options.onError(error);
        },
        
        onClose: () => {
            statusDiv.textContent = 'Stream closed';
            statusDiv.className = 'sse-status closed';
            disconnectBtn.textContent = 'Close';
            
            if (options.onClose) options.onClose();
        }
    });
    
    // Disconnect button handler
    disconnectBtn.addEventListener('click', () => {
        sseClient.disconnect();
        disconnectBtn.textContent = 'Disconnected';
        disconnectBtn.disabled = true;
    });
    
    // Auto-connect
    sseClient.connect().catch((error) => {
        statusDiv.textContent = `Connection failed: ${error.message}`;
        statusDiv.className = 'sse-status error';
    });
    
    return {
        client: sseClient,
        ui: progressUI,
        destroy: () => {
            sseClient.disconnect();
            progressUI.remove();
        }
    };
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { SSEClient, createProgressUI };
}
