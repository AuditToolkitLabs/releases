/**
 * SSE Demo page JavaScript
 * Handles SSE streaming demo functionality
 */

var currentProgressUI = null;

document.addEventListener('DOMContentLoaded', function() {
    var taskIdInput = document.getElementById('taskIdInput');
    var startStreamBtn = document.getElementById('startStreamBtn');
    var testTaskBtn = document.getElementById('testTaskBtn');
    var progressContainer = document.getElementById('progressContainer');
    
    // Start streaming button
    startStreamBtn.addEventListener('click', function() {
        var taskId = taskIdInput.value.trim();
        
        if (!taskId) {
            alert('Please enter a task ID');
            return;
        }
        
        // Clear previous UI
        if (currentProgressUI) {
            currentProgressUI.destroy();
        }
        
        // Create new progress UI
        currentProgressUI = createProgressUI(progressContainer, taskId, {
            onComplete: function(data) {
                console.log('Task completed:', data);
            },
            onError: function(error) {
                console.error('Task error:', error);
            }
        });
        
        startStreamBtn.disabled = true;
        testTaskBtn.disabled = true;
    });
    
    // Start test task button
    testTaskBtn.addEventListener('click', async function() {
        try {
            testTaskBtn.disabled = true;
            testTaskBtn.textContent = 'Starting task...';
            
            // Start a test audit execution
            var response = await fetch('/api/async/execute', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    mode: 'single',
                    server_id: 1, // Change to valid server ID
                    audit_path: 'audits/platform/baseline/updates.sh' // Example audit
                })
            });
            
            var data = await response.json();
            
            if (data.success) {
                // Populate task ID and start streaming
                taskIdInput.value = data.task_id;
                startStreamBtn.click();
            } else {
                alert('Failed to start task: ' + (data.error || 'Unknown error'));
                testTaskBtn.disabled = false;
                testTaskBtn.textContent = 'Start Test Task';
            }
            
        } catch (error) {
            console.error('Error starting test task:', error);
            alert('Error: ' + error.message);
            testTaskBtn.disabled = false;
            testTaskBtn.textContent = 'Start Test Task';
        }
    });
    
    // Re-enable buttons when stream closes
    progressContainer.addEventListener('DOMNodeRemoved', function() {
        setTimeout(function() {
            startStreamBtn.disabled = false;
            testTaskBtn.disabled = false;
            testTaskBtn.textContent = 'Start Test Task';
        }, 1000);
    });
});
