/**
 * standalone-keys-panel.js
 * Drives the "Standalone Keys" admin panel in the main SPA (index.html).
 * SuperAdmin-only — depends on /api/v1/agents/standalone-keys.
 */

(function () {
    'use strict';

    const STANDALONE_KEYS_AUTH = {
        title: 'Standalone Key Access Authentication',
        notice: 'Re-enter your password to unlock Standalone Key management. Access is logged for audit and tracking.',
        buttonText: 'Authenticate & Access Standalone Keys',
        successText: 'Standalone Key access authorized',
        authenticateUrl: '/api/v1/agents/standalone-keys/authenticate',
        statusUrl: '/api/v1/agents/standalone-keys/authenticate/status',
    };

    /* ------------------------------------------------------------------ *
     * Helpers
     * ------------------------------------------------------------------ */
    function saEsc(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function fmtDate(iso) {
        if (!iso) return '–';
        return new Date(iso).toLocaleDateString(undefined, {
            year: 'numeric', month: 'short', day: 'numeric'
        });
    }

    async function saEnsureUnlocked() {
        if (!window.SensitiveToolAuth) return false;
        return window.SensitiveToolAuth.ensureUnlocked(STANDALONE_KEYS_AUTH);
    }

    async function saFetch(url, options = {}) {
        const doFetch = () => (window.SensitiveToolAuth ? window.SensitiveToolAuth.authFetch(url, options) : fetch(url, { ...options, credentials: 'same-origin' }));

        let response = await doFetch();
        if (response.status !== 403) {
            return response;
        }

        let data = null;
        try {
            data = await response.clone().json();
        } catch (err) {
            return response;
        }

        if (data?.code !== 'STANDALONE_KEYS_AUTH_REQUIRED') {
            return response;
        }

        const unlocked = await saEnsureUnlocked();
        if (!unlocked) {
            return response;
        }

        return doFetch();
    }

    /* ------------------------------------------------------------------ *
     * Load & render
     * ------------------------------------------------------------------ */
    async function saPanelLoadKeys() {
        if (!(await saEnsureUnlocked())) {
            const tbody = document.getElementById('sa-key-table-body');
            if (tbody) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--warning-color,#f59e0b);padding:1.5rem;">Secondary authentication is required before Standalone Keys can be viewed.</td></tr>';
            }
            return;
        }

        const tbody = document.getElementById('sa-key-table-body');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-secondary);padding:1.5rem;">Loading…</td></tr>';
        }

        let d;
        try {
            const r = await saFetch('/api/v1/agents/standalone-keys');
            if (!r.ok) {
                const msg = r.status === 403
                    ? 'SuperAdmin role required.'
                    : `HTTP ${r.status}`;
                if (tbody) {
                    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--danger-color,#ef4444);padding:1.5rem;">${saEsc(msg)}</td></tr>`;
                }
                return;
            }
            d = await r.json();
        } catch (e) {
            console.error('standalone-keys-panel: fetch error', e);
            if (tbody) {
                tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--danger-color,#ef4444);padding:1.5rem;">Failed to load keys.</td></tr>`;
            }
            return;
        }

        /* ---------- stats cards ---------- */
        const tierEl = document.getElementById('sa-key-tier');
        const totalEl = document.getElementById('sa-key-total');
        const usedEl = document.getElementById('sa-key-used');
        const remEl = document.getElementById('sa-key-remaining');

        const tier = d.tier || 'unknown';
        const total = d.slots_total ?? 0;
        const used = d.slots_used ?? 0;
        const rem = d.slots_remaining ?? Math.max(0, total - used);

        if (tierEl) tierEl.textContent = tier.charAt(0).toUpperCase() + tier.slice(1);
        if (totalEl) totalEl.textContent = total === 0 ? 'N/A' : total;
        if (usedEl) usedEl.textContent = used;
        if (remEl) remEl.textContent = total === 0 ? 'N/A' : rem;

        /* ---------- nav badge ---------- */
        const badge = document.getElementById('sa-nav-key-badge');
        if (badge) {
            if (total === 0) {
                badge.textContent = 'N/A';
                badge.style.color = 'var(--text-muted, #6b7280)';
            } else {
                badge.textContent = `${used} / ${total} used`;
                badge.style.color = rem === 0 ? 'var(--danger-color, #ef4444)' : 'var(--text-secondary, #9ca3af)';
            }
        }

        /* ---------- key rows ---------- */
        if (!tbody) return;

        const allKeys = d.keys || [];

        // Merge in revoked/dead keys from a second pass if API only returns active
        // (current API returns only active; we show a note if there may be more)
        if (allKeys.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-secondary);padding:1.5rem;">No active keys issued yet. Use the Full Management Page to generate keys.</td></tr>';
            return;
        }

        tbody.innerHTML = allKeys.map(k => {
            const now = new Date();
            const expired = k.expires_at && new Date(k.expires_at) < now;
            const isDead = k.revoked || expired;

            let statusBadge;
            if (k.revoked) {
                statusBadge = '<span style="display:inline-block;padding:2px 8px;border-radius:12px;font-size:0.75rem;background:rgba(107,114,128,0.15);color:#9ca3af;border:1px solid rgba(107,114,128,0.3);">Revoked</span>';
            } else if (expired) {
                statusBadge = '<span style="display:inline-block;padding:2px 8px;border-radius:12px;font-size:0.75rem;background:rgba(239,68,68,0.15);color:#ef4444;border:1px solid rgba(239,68,68,0.3);">Expired</span>';
            } else if (k.redeemed) {
                statusBadge = '<span style="display:inline-block;padding:2px 8px;border-radius:12px;font-size:0.75rem;background:rgba(34,197,94,0.15);color:#22c55e;border:1px solid rgba(34,197,94,0.3);">Active</span>';
            } else {
                statusBadge = '<span style="display:inline-block;padding:2px 8px;border-radius:12px;font-size:0.75rem;background:rgba(245,158,11,0.15);color:#f59e0b;border:1px solid rgba(245,158,11,0.3);">Pending</span>';
            }

            const mid = k.bound_machine_id || '';
            const machineCell = mid
                ? `<td style="font-family:monospace;font-size:0.78rem;color:var(--text-secondary);" title="${saEsc(mid)}">${saEsc(mid.slice(0, 14))}…</td>`
                : '<td style="color:var(--text-muted,#6b7280);font-size:0.78rem;"><em>Unbound</em></td>';

            let actions = '';
            if (!isDead) {
                actions += `<button class="btn btn-small" style="background:rgba(239,68,68,0.12);color:#ef4444;border:1px solid rgba(239,68,68,0.3);padding:2px 10px;font-size:0.78rem;border-radius:4px;cursor:pointer;" onclick="saPanelRevoke('${saEsc(k.key_id)}','${saEsc(k.label||'')}')">✕ Revoke</button>`;
            } else {
                actions += `<button class="btn btn-small" style="background:rgba(107,114,128,0.1);color:var(--text-secondary);border:1px solid rgba(107,114,128,0.25);padding:2px 10px;font-size:0.78rem;border-radius:4px;cursor:pointer;" onclick="saPanelPurge('${saEsc(k.key_id)}','${saEsc(k.label||'')}')">🗑 Delete</button>`;
            }

            return `<tr style="${isDead ? 'opacity:0.55;' : ''}">
                <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${saEsc(k.label||'')}">${saEsc(k.label || '–')}</td>
                ${machineCell}
                <td style="color:var(--text-secondary);font-size:0.82rem;">${fmtDate(k.issued_at)}</td>
                <td style="color:${expired ? 'var(--danger-color,#ef4444)' : 'var(--text-secondary)'};font-size:0.82rem;">${fmtDate(k.expires_at)}</td>
                <td>${statusBadge}</td>
                <td style="white-space:nowrap;">${actions}</td>
            </tr>`;
        }).join('');
    }

    /* ------------------------------------------------------------------ *
     * Action handlers (called by inline onclick in table rows)
     * ------------------------------------------------------------------ */
    window.saPanelLoadKeys = saPanelLoadKeys;

    window.saPanelRevoke = async function (keyId, label) {
        if (!confirm(`Revoke key "${label}"?\n\nAny standalone agent using this key will fall back to Community tier on next license refresh.`)) return;
        try {
            const r = await saFetch(`/api/v1/agents/standalone-key/${encodeURIComponent(keyId)}`, { method: 'DELETE' });
            const d = await r.json();
            if (d.success) {
                await saPanelLoadKeys();
            } else {
                alert('Revoke failed: ' + (d.error || 'Unknown error'));
            }
        } catch (e) {
            alert('Request failed: ' + e.message);
        }
    };

    window.saPanelPurge = async function (keyId, label) {
        if (!confirm(`Permanently delete the record for "${label}"?\n\nThis only removes the list entry — the key is already inactive. This cannot be undone.`)) return;
        try {
            const r = await saFetch(`/api/v1/agents/standalone-key/${encodeURIComponent(keyId)}/purge`, { method: 'DELETE' });
            const d = await r.json();
            if (d.success) {
                await saPanelLoadKeys();
            } else {
                alert('Delete failed: ' + (d.error || 'Unknown error'));
            }
        } catch (e) {
            alert('Request failed: ' + e.message);
        }
    };

    /* ------------------------------------------------------------------ *
     * Auto-load on panel activation
     * ------------------------------------------------------------------ */
    document.addEventListener('adminPanelChanged', function (e) {
        if (e.detail && e.detail.section === 'standalone-keys') {
            saPanelLoadKeys();
        }
    });

    /* Pre-populate badge on page load (for when the admin section is open) */
    document.addEventListener('DOMContentLoaded', function () {
        // Only fetch if the user is likely a superadmin (badge element present)
        if (document.getElementById('sa-nav-key-badge')) {
            fetch('/api/v1/agents/standalone-keys')
                .then(r => r.ok ? r.json() : null)
                .then(d => {
                    if (!d || !d.success) return;
                    const badge = document.getElementById('sa-nav-key-badge');
                    if (!badge) return;
                    const total = d.slots_total ?? 0;
                    const used = d.slots_used ?? 0;
                    const rem = d.slots_remaining ?? Math.max(0, total - used);
                    if (total === 0) {
                        badge.textContent = 'N/A';
                    } else {
                        badge.textContent = `${used} / ${total} used`;
                        badge.style.color = rem === 0
                            ? 'var(--danger-color, #ef4444)'
                            : 'var(--text-secondary, #9ca3af)';
                    }
                })
                .catch(() => { /* ignore — user may not be superadmin */ });
        }
    });
}());
