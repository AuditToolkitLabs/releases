/**
 * Service Worker Registration
 * Provides offline support for the Security Audit Toolkit
 */
(function() {
    'use strict';
    
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/static/sw.js?v=20260313a', { updateViaCache: 'none' })
                .then(reg => {
                    reg.update();
                    console.log('Service Worker registered:', reg.scope);
                })
                .catch(err => console.log('Service Worker registration failed:', err));
        });
    }
})();
