/**
 * Wizard Tab JavaScript
 * Handles the master panel workflow navigation
 */

// ============================================
// Debug Configuration
// ============================================
// Set to true to enable verbose console logging (disable in production)
const WIZARD_DEBUG = false;

// Conditional debug logger - only logs when WIZARD_DEBUG is true
function wizardLog(...args) {
    if (WIZARD_DEBUG) {
        console.log(...args);
    }
}

// ============================================
// Security Helpers
// ============================================

// CSRF token cache
let wizardCachedCsrfToken = null;

// Get CSRF token from meta tag or cache
function getWizardCsrfToken() {
    // First check meta tag
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta && meta.content) {
        return meta.content;
    }
    // Return cached token if available
    return wizardCachedCsrfToken || '';
}

// Initialize CSRF token
async function initWizardCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (!meta || !meta.content) {
        try {
            const response = await fetch('/auth/csrf-token', { credentials: 'include' });
            const data = await response.json();
            wizardCachedCsrfToken = data.csrf_token;
            // Update meta tag if exists
            if (meta) meta.content = wizardCachedCsrfToken;
        } catch (error) {
            console.warn('Failed to fetch CSRF token:', error);
        }
    }
}

// XSS prevention helper
function escapeHtml(unsafe) {
    if (unsafe == null) return '';
    const div = document.createElement('div');
    div.textContent = String(unsafe);
    return div.innerHTML;
}

// Secure fetch wrapper with CSRF token
async function wizardFetch(url, options = {}) {
    const csrfToken = getWizardCsrfToken();
    const headers = { ...(options.headers || {}) };
    const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
    if (apiKey && !headers['X-API-Key']) {
        headers['X-API-Key'] = apiKey;
    }

    // Add CSRF token for state-changing requests
    if (options.method && ['POST', 'PUT', 'DELETE', 'PATCH'].includes(options.method.toUpperCase())) {
        if (csrfToken) {
            headers['X-CSRFToken'] = csrfToken;
        }
        if (!headers['Content-Type']) {
            headers['Content-Type'] = 'application/json';
        }
    }

    return fetch(url, {
        ...options,
        credentials: 'include',
        headers
    });
}

// Input validation helpers
function isValidHostname(hostname) {
    // Allow IP addresses and hostnames
    const hostnameRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    return hostnameRegex.test(hostname) || ipRegex.test(hostname);
}

function isValidPort(port) {
    const num = parseInt(port);
    return !isNaN(num) && num >= 1 && num <= 65535;
}

function isValidUsername(username) {
    // Alphanumeric, underscore, hyphen, backslash (for domain\user)
    return /^[a-zA-Z0-9_\-\\@.]+$/.test(username);
}

/**
 * Get human-readable label for elevation method
 */
function getElevationLabel(method, osType) {
    const labels = {
        // Linux
        sudo: 'sudo',
        sudo_nopasswd: 'sudo NOPASSWD',
        audit_wrapper: 'Audit Wrapper',
        // Windows
        runas: 'RunAs',
        jea: 'JEA Endpoint',
        admin: 'Administrator',
        // Common
        none: 'None'
    };
    return labels[method] || method || (osType === 'windows' ? 'RunAs' : 'sudo');
}

/**
 * Open configuration for a server from the wizard list
 * Reuses the Connect tab's edit modal
 */
function openWizardServerConfig(serverId) {
    // Check if the Connect tab's openEditServerModal function exists
    if (typeof openEditServerModal === 'function') {
        openEditServerModal(serverId);
    } else {
        // Fallback: switch to Connect tab and open modal there
        const connectTab = document.querySelector('[data-tab="connect"]');
        if (connectTab) {
            connectTab.click();
            // Wait for tab to load, then open modal
            setTimeout(() => {
                if (typeof openEditServerModal === 'function') {
                    openEditServerModal(serverId);
                } else {
                    alert('Please use the Connect tab to configure server settings.');
                }
            }, 100);
        } else {
            alert('Please use the Connect tab to configure server settings.');
        }
    }
}

// ============================================
// Wizard State
// ============================================
const wizardState = {
    mode: 'new', // 'new' or 'existing'
    currentStep: 'connect',
    selectedServers: [],
    selectedAudits: [],
    newServer: null, // Server added via wizard
    filteredAudits: false, // True when showing only recommended audits
    osFilter: 'all', // 'all', 'linux', 'windows', or 'hypervisors'
    serverOS: null, // Detected or selected server OS
    options: {
        parallel: true,
        saveResults: true,
        notify: false,
        executionMode: 'stream' // 'stream', 'deployed', or 'server-default'
    },
    saveAsPlan: false,
    planName: '',
    planDescription: ''
};

/**
 * Get the selected wizard execution mode
 * @returns {string} 'stream', 'deployed', or 'server-default'
 */
function getWizardExecutionMode() {
    const selectedMode = document.querySelector('input[name="wizard-execution-mode"]:checked');
    return selectedMode ? selectedMode.value : 'stream';
}

/**
 * Handle execution mode change in wizard
 */
function handleWizardExecutionModeChange() {
    const selectedMode = getWizardExecutionMode();
    const warningDiv = document.getElementById('wizard-deployed-mode-warning');

    if (warningDiv) {
        warningDiv.style.display = selectedMode === 'deployed' ? 'block' : 'none';
    }
    wizardState.options.executionMode = selectedMode;
}

// ============================================
// Fleet Agent Connection Method
// ============================================

// State for fleet agent registration
let wizardAgentState = {
    token: null,
    serverId: null,
    tokenExpiry: null,
    keyValidityDays: 90,
    pollingInterval: null
};

/**
 * Handle connection method change in wizard
 * Toggles between direct (SSH/WinRM) and fleet agent (API) modes
 */
function handleWizardConnectionMethodChange() {
    const method = document.querySelector('input[name="wizard-connection-method"]:checked')?.value || 'direct';
    const directSection = document.getElementById('wizard-direct-connection-section');
    const agentSection = document.getElementById('wizard-fleet-agent-section');
    const addServerBtn = document.getElementById('wizard-add-server-btn');
    const scriptDeliverySection = document.getElementById('wizard-script-delivery-section');

    wizardLog('Wizard: Connection method changed to ' + method);

    if (method === 'fleet-agent') {
        // Show fleet agent registration flow
        if (directSection) directSection.style.display = 'none';
        if (agentSection) agentSection.style.display = 'block';
        if (addServerBtn) addServerBtn.textContent = 'Continue with Agent →';
        // Hide script delivery mode - fleet agents handle this automatically
        if (scriptDeliverySection) scriptDeliverySection.style.display = 'none';

        // Pre-fill agent name from OS selection
        const osType = document.querySelector('input[name="wizard-os"]:checked')?.value || 'linux';
        const agentNameInput = document.getElementById('wizard-agent-name');
        if (agentNameInput && !agentNameInput.value) {
            agentNameInput.placeholder = `e.g., ${osType}-server-01`;
        }
    } else {
        // Show direct connection form
        if (directSection) directSection.style.display = 'block';
        if (agentSection) agentSection.style.display = 'none';
        if (addServerBtn) addServerBtn.textContent = 'Add Server & Continue →';
        // Show script delivery mode for direct connections
        if (scriptDeliverySection) scriptDeliverySection.style.display = 'block';

        // Stop polling if active
        if (wizardAgentState.pollingInterval) {
            clearInterval(wizardAgentState.pollingInterval);
            wizardAgentState.pollingInterval = null;
        }
    }

    updateWizardScriptExecutionSectionsVisibility(method);
}

/**
 * Show/hide execution-specific configuration sections.
 * These sections apply only when audit scripts are executed over SSH/WinRM.
 */
function updateWizardScriptExecutionSectionsVisibility(method = null) {
    const selectedMethod = method || document.querySelector('input[name="wizard-connection-method"]:checked')?.value || 'direct';
    const executionSection = document.getElementById('wizard-execution-mode-section');
    const elevationSection = document.getElementById('wizard-privilege-elevation-section');

    // Only direct SSH/WinRM execution needs script delivery + privilege elevation.
    const showScriptExecutionSections = selectedMethod === 'direct';

    if (executionSection) {
        executionSection.style.display = showScriptExecutionSections ? '' : 'none';
    }
    if (elevationSection) {
        elevationSection.style.display = showScriptExecutionSections ? '' : 'none';
    }
}

/**
 * Generate registration token for fleet agent
 */
async function generateWizardAgentToken() {
    const agentName = document.getElementById('wizard-agent-name')?.value?.trim();
    const tokenValidity = document.getElementById('wizard-agent-token-validity')?.value || '24h';
    const keyValidity = document.getElementById('wizard-agent-key-validity')?.value || '90';
    const osType = document.querySelector('input[name="wizard-os"]:checked')?.value || 'linux';

    if (!agentName) {
        showToast?.('Please enter an agent name', 'error') || alert('Please enter an agent name');
        return;
    }

    try {
        const response = await wizardFetch('/api/managed-agent/register/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': getWizardCsrfToken()
            },
            body: JSON.stringify({
                agent_name: agentName,
                os_type: osType,
                token_validity: tokenValidity,
                key_validity_days: parseInt(keyValidity)
            })
        });

        const data = await response.json();

        if (data.success) {
            wizardAgentState.token = data.token;
            wizardAgentState.serverId = data.server_id;
            wizardAgentState.tokenExpiry = data.expires_at;
            wizardAgentState.keyValidityDays = parseInt(keyValidity);

            // Update UI with token info
            updateWizardAgentTokenDisplay(data);

            // Show install and verify steps
            document.getElementById('wizard-agent-step-install').style.display = 'block';
            document.getElementById('wizard-agent-step-verify').style.display = 'block';

            // Start polling for agent registration
            startWizardAgentPolling();

            showToast?.('Registration token generated', 'success');
        } else {
            showToast?.(`Error: ${data.error}`, 'error') || alert(`Error: ${data.error}`);
        }
    } catch (error) {
        console.error('Error generating agent token:', error);
        showToast?.('Failed to generate token', 'error') || alert('Failed to generate token');
    }
}

/**
 * Update UI with generated token information
 */
function updateWizardAgentTokenDisplay(data) {
    const serverUrl = window.location.origin;
    const token = data.token;

    // Update token display
    document.getElementById('wizard-agent-token-display').textContent = token;
    document.getElementById('wizard-agent-token-expiry').textContent = data.expires_in || '24 hours';

    // Update key validity display
    const keyValidityDays = wizardAgentState.keyValidityDays;
    const keyValidityText = keyValidityDays === 0 ? 'Never expires' : `${keyValidityDays} days`;
    document.getElementById('wizard-agent-key-validity-info').textContent = keyValidityText;

    // Update Linux install command
    const linuxCmd = document.getElementById('wizard-agent-install-cmd-linux');
    if (linuxCmd) {
        linuxCmd.innerHTML = `curl -fsSL ${serverUrl}/api/managed-agent/install.sh | sudo bash -s -- \\
  --server ${serverUrl} \\
  --token <span class="token-highlight">${token}</span>`;
    }

    // Update Windows install command
    const windowsCmd = document.getElementById('wizard-agent-install-cmd-windows');
    if (windowsCmd) {
        windowsCmd.innerHTML = `irm ${serverUrl}/api/managed-agent/install.ps1 | iex
Install-FleetAgent -Server "${serverUrl}" -Token "<span class="token-highlight">${token}</span>"`;
    }
}

/**
 * Switch between Linux and Windows install commands
 */
function switchWizardAgentPlatform(platform) {
    const linuxCmd = document.getElementById('wizard-agent-cmd-linux');
    const windowsCmd = document.getElementById('wizard-agent-cmd-windows');
    const tabs = document.querySelectorAll('.wizard-deploy-platform-tabs .platform-tab');

    tabs.forEach(tab => {
        tab.classList.toggle('active', tab.getAttribute('data-platform') === platform);
    });

    if (platform === 'linux') {
        if (linuxCmd) linuxCmd.style.display = 'block';
        if (windowsCmd) windowsCmd.style.display = 'none';
    } else {
        if (linuxCmd) linuxCmd.style.display = 'none';
        if (windowsCmd) windowsCmd.style.display = 'block';
    }
}

/**
 * Copy install command to clipboard
 */
function copyWizardAgentCommand(platform) {
    const cmdElement = document.getElementById(`wizard-agent-install-cmd-${platform}`);
    if (cmdElement) {
        const text = cmdElement.textContent || cmdElement.innerText;
        navigator.clipboard.writeText(text).then(() => {
            showToast?.('Command copied to clipboard', 'success');
        }).catch(() => {
            // Fallback for older browsers
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            showToast?.('Command copied to clipboard', 'success');
        });
    }
}

/**
 * Copy registration token to clipboard
 */
function copyWizardAgentToken() {
    if (wizardAgentState.token) {
        navigator.clipboard.writeText(wizardAgentState.token).then(() => {
            showToast?.('Token copied to clipboard', 'success');
        }).catch(() => {
            showToast?.('Failed to copy token', 'error');
        });
    }
}

/**
 * Start polling for agent registration status
 */
function startWizardAgentPolling() {
    // Clear any existing interval
    if (wizardAgentState.pollingInterval) {
        clearInterval(wizardAgentState.pollingInterval);
    }

    // Poll every 5 seconds
    wizardAgentState.pollingInterval = setInterval(checkWizardAgentStatus, 5000);

    // Check immediately
    checkWizardAgentStatus();
}

/**
 * Check if agent has registered
 */
async function checkWizardAgentStatus() {
    if (!wizardAgentState.serverId) return;

    try {
        const response = await wizardFetch(`/api/managed-agent/${wizardAgentState.serverId}/status`, {
            headers: {
                'X-CSRF-Token': getWizardCsrfToken()
            }
        });

        const data = await response.json();

        if (data.success && data.registered) {
            // Agent connected!
            clearInterval(wizardAgentState.pollingInterval);
            wizardAgentState.pollingInterval = null;

            // Update UI to show connected state
            const verifyStatus = document.getElementById('wizard-agent-verify-status');
            const connectedInfo = document.getElementById('wizard-agent-connected-info');

            if (verifyStatus) verifyStatus.style.display = 'none';
            if (connectedInfo) {
                connectedInfo.style.display = 'block';
                document.getElementById('wizard-agent-connected-name').textContent = data.agent_name || 'Unknown';
                document.getElementById('wizard-agent-connected-id').textContent = data.agent_id || wizardAgentState.serverId;
            }

            // Show the direct-API connectivity test button once the agent is registered
            const directCheckBtn = document.getElementById('wizard-agent-direct-check-btn');
            if (directCheckBtn) directCheckBtn.style.display = 'inline-block';

            // Store server info in wizard state for continuation
            wizardState.newServer = {
                id: wizardAgentState.serverId,
                name: data.agent_name,
                connection_method: 'fleet-agent',
                os_type: data.os_type || 'linux'
            };

            showToast?.('Agent connected successfully!', 'success');

            // Update button to allow continuation
            const addBtn = document.getElementById('wizard-add-server-btn');
            if (addBtn) {
                addBtn.textContent = 'Continue to Discovery →';
                addBtn.classList.add('agent-connected');
            }
        }
    } catch (error) {
        console.error('Error checking agent status:', error);
    }
}

async function testWizardAgentDirectApi() {
    if (!wizardAgentState.serverId) return;

    const btn = document.getElementById('wizard-agent-direct-check-btn');
    const resultPanel = document.getElementById('wizard-agent-direct-check-result');
    const healthRow = document.getElementById('wizard-agent-direct-check-health');
    const sysinfoRow = document.getElementById('wizard-agent-direct-check-sysinfo');

    if (btn) { btn.textContent = '⏳ Testing…'; btn.disabled = true; }
    if (resultPanel) resultPanel.style.display = 'none';

    try {
        const response = await wizardFetch(
            `/api/managed-agent/${wizardAgentState.serverId}/direct/check`,
            { headers: { 'X-CSRF-Token': getWizardCsrfToken() } }
        );
        const data = await response.json();
        const checks = data.checks || {};

        function _checkRow(check, label) {
            const ok = (check?.status_code === 200) && check?.result?.success;
            return `<span style="color:${ok ? 'var(--success-color)' : 'var(--error-color)'}">${ok ? '✅' : '❌'} ${label}: ${ok ? 'OK' : (check?.result?.error || 'Failed')} (HTTP ${check?.status_code ?? '?'})</span>`;
        }

        if (healthRow) healthRow.innerHTML = _checkRow(checks.health, 'Health');
        if (sysinfoRow) sysinfoRow.innerHTML = _checkRow(checks.system_info, 'System Info');
        if (resultPanel) resultPanel.style.display = 'block';
    } catch (error) {
        if (healthRow) healthRow.innerHTML = `<span style="color:var(--error-color)">❌ Request failed: ${error.message}</span>`;
        if (sysinfoRow) sysinfoRow.innerHTML = '';
        if (resultPanel) resultPanel.style.display = 'block';
    } finally {
        if (btn) { btn.textContent = '🔌 Test Direct API'; btn.disabled = false; }
    }
}

// ============================================
// Initialization
// ============================================
async function initWizard() {
    wizardLog('Wizard: Initializing...');

    // Initialize CSRF token first
    await initWizardCsrfToken();

    setupWizardModeSelector();
    setupWizardNavigation();
    setupWizardButtons();
    setupWizardConnectForm();
    setupWizardAuditMode();
    setupWizardOSFilter();
    setupWizardPlanToggle();
    setupWizardPlanHandlers();
    setupWizardScheduleStep();
    loadWizardServers();
    loadWizardAudits();
    loadWizardPlans();
    loadWizardAuditPlans();

    // Listen for server updates (e.g., from Connect tab's edit modal)
    window.addEventListener('serverUpdated', () => {
        wizardLog('Wizard: Server updated, reloading server list');
        loadWizardServers();
    });

    wizardLog('Wizard: Initialization complete');
}

// ============================================
// Mode Selection
// ============================================
function setupWizardModeSelector() {
    const modeButtons = document.querySelectorAll('.wizard-mode-btn');

    modeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const mode = btn.getAttribute('data-mode');
            switchWizardMode(mode);
        });
    });
}

function switchWizardMode(mode) {
    wizardState.mode = mode;
    wizardLog('Wizard: Switching to mode ' + mode);

    // Update mode button states
    document.querySelectorAll('.wizard-mode-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-mode') === mode);
    });

    // Update nav items visibility
    const connectNav = document.querySelector('.wizard-nav-item[data-step="connect"]');
    const serversNav = document.querySelector('.wizard-nav-item[data-step="servers"]');

    if (mode === 'new') {
        if (connectNav) connectNav.style.display = '';
        if (serversNav) serversNav.style.display = 'none';
        wizardState.currentStep = 'connect';
        goToWizardStep('connect');
    } else {
        if (connectNav) connectNav.style.display = 'none';
        if (serversNav) serversNav.style.display = '';
        wizardState.currentStep = 'servers';
        goToWizardStep('servers');
    }

    // Update discovery back button
    const discoveryBack = document.getElementById('wizard-discovery-back');
    if (discoveryBack) {
        discoveryBack.setAttribute('data-prev', mode === 'new' ? 'connect' : 'servers');
    }

    // Update recommendations back button
    const recommendationsBack = document.getElementById('wizard-recommendations-back');
    if (recommendationsBack) {
        // In existing mode, if skipping discovery, back goes to servers
        recommendationsBack.setAttribute('data-prev', 'discovery');
    }

    // Show/hide skip buttons (only for existing mode)
    const skipButtons = ['wizard-servers-skip', 'wizard-discovery-skip', 'wizard-recommendations-skip'];
    skipButtons.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.style.display = mode === 'existing' ? 'inline-flex' : 'none';
        }
    });

    // Show/hide optional labels in nav
    document.querySelectorAll('.wizard-nav-optional').forEach(el => {
        el.style.display = mode === 'existing' ? 'inline' : 'none';
    });

    // Show/hide plan load section (only for existing mode)
    const planLoadSection = document.getElementById('wizard-plan-load-section');
    if (planLoadSection) {
        planLoadSection.style.display = mode === 'existing' ? 'block' : 'none';
    }

    // Show/hide audit mode selection (only for existing mode)
    const auditMode = document.getElementById('wizard-audit-mode');
    const auditManual = document.getElementById('wizard-audit-manual');
    if (auditMode && auditManual) {
        if (mode === 'existing') {
            auditMode.style.display = 'block';
            // Reset to plan mode
            const planRadio = document.querySelector('input[name="wizard-audit-mode"][value="plan"]');
            if (planRadio) planRadio.checked = true;
            toggleAuditMode('plan');
        } else {
            auditMode.style.display = 'none';
            auditManual.style.display = 'block';
        }
    }

    // Update audits back button
    const auditsBack = document.getElementById('wizard-audits-back');
    if (auditsBack) {
        // If skipped discovery/recommendations, go back to servers
        auditsBack.setAttribute('data-prev', mode === 'existing' ? 'servers' : 'recommendations');
    }
}

// ============================================
// Connect to Server Form
// ============================================
function setupWizardConnectForm() {
    updateWizardScriptExecutionSectionsVisibility();

    // OS selection handler
    const osRadios = document.querySelectorAll('input[name="wizard-os"]');
    osRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            // If hypervisor is selected, navigate to the embedded hypervisors tab
            if (radio.value === 'hypervisors') {
                // Navigate to the hypervisors tab within the console (not the standalone page)
                const tabButton = document.querySelector('.tab-button[data-tab="hypervisors"]');
                if (tabButton) {
                    tabButton.click();
                } else {
                    // Fallback: use hash navigation
                    window.location.hash = 'hypervisors';
                }
                // Reset to Linux for next time wizard is opened
                const linuxRadio = document.querySelector('input[name="wizard-os"][value="linux"]');
                if (linuxRadio) linuxRadio.checked = true;
                return;
            }
            updateConnectionFormForOS(radio.value);
            updateWizardElevationOptions();
        });
    });

    // Port change handler - update protocol info
    const portInput = document.getElementById('wizard-server-port');
    if (portInput) {
        portInput.addEventListener('input', () => {
            const os = document.querySelector('input[name="wizard-os"]:checked')?.value || 'linux';
            const port = parseInt(portInput.value) || (os === 'windows' ? 5986 : 22);
            const connProtocol = document.getElementById('wizard-connection-protocol')?.value || 'auto';
            updateProtocolInfo(os, port, connProtocol);
        });
    }

    // Connection protocol change handler (for Windows)
    const connProtocolSelect = document.getElementById('wizard-connection-protocol');
    if (connProtocolSelect) {
        connProtocolSelect.addEventListener('change', () => {
            const os = document.querySelector('input[name="wizard-os"]:checked')?.value || 'linux';
            const portInput = document.getElementById('wizard-server-port');
            const connProtocol = connProtocolSelect.value;

            // Update port and hints based on protocol selection
            if (os === 'windows') {
                updateWindowsPortForProtocol(connProtocol, portInput);
            }
            updateProtocolInfo(os, parseInt(portInput?.value) || 5986, connProtocol);
        });
    }

    // Auth method toggle
    const authMethodSelect = document.getElementById('wizard-auth-method');
    if (authMethodSelect) {
        authMethodSelect.addEventListener('change', () => {
            updateAuthFields();
        });
    }

    // New server execution mode toggle
    const newServerExecMode = document.getElementById('wizard-new-server-execution-mode');
    if (newServerExecMode) {
        newServerExecMode.addEventListener('change', () => {
            const warning = document.getElementById('wizard-new-server-deployed-warning');
            if (warning) {
                warning.style.display = newServerExecMode.value === 'deployed' ? 'block' : 'none';
            }
        });
    }

    // Elevation method change handler
    const elevationMethodSelect = document.getElementById('wizard-new-server-elevation-method');
    if (elevationMethodSelect) {
        elevationMethodSelect.addEventListener('change', () => {
            toggleWizardJeaEndpoint();
        });
    }

    // Test connection button
    const testBtn = document.getElementById('wizard-test-connection');
    if (testBtn) {
        testBtn.addEventListener('click', testWizardConnection);
    }

    // Add server button
    const addServerBtn = document.getElementById('wizard-add-server-btn');
    if (addServerBtn) {
        addServerBtn.addEventListener('click', addWizardServer);
    }
}

function updateWindowsPortForProtocol(connProtocol, portInput) {
    const portLabel = document.getElementById('wizard-port-label');
    const portHint = document.getElementById('wizard-port-hint');
    const protocolHint = document.getElementById('wizard-protocol-hint');

    if (connProtocol === 'ssh') {
        if (portInput) portInput.value = 22;
        if (portLabel) portLabel.textContent = 'SSH Port';
        if (portHint) portHint.textContent = 'Default: 22 (OpenSSH). Requires OpenSSH Server feature.';
        if (protocolHint) protocolHint.textContent = 'OpenSSH Server must be enabled on the Windows host';
    } else {
        // winrm or auto - use WinRM defaults
        if (portInput) portInput.value = 5986;
        if (portLabel) portLabel.textContent = 'WinRM Port';
        if (portHint) portHint.textContent = 'Default: 5986 (HTTPS). Use 5985 for HTTP (not recommended).';
        if (protocolHint) protocolHint.textContent = connProtocol === 'auto'
            ? 'Auto tries WinRM first, falls back to SSH if connection fails'
            : 'WinRM is enabled by default on Windows Server editions';
    }
}

function updateProtocolInfo(os, port, connProtocol = 'auto') {
    const protocolInfo = document.getElementById('wizard-protocol-info');
    if (!protocolInfo) return;

    if (os === 'windows') {
        // Handle based on connection protocol selection
        if (connProtocol === 'ssh') {
            protocolInfo.innerHTML = `
                <span class="wizard-protocol-badge windows">🪟 OpenSSH</span>
                <span class="wizard-protocol-desc">Port ${port} - Windows OpenSSH Server</span>
                <span class="wizard-protocol-secure">🔒 Encrypted</span>
            `;
        } else {
            // WinRM or Auto
            const isHTTPS = port === 5986;
            const isHTTP = port === 5985;

            let badge, desc, secure;
            if (isHTTPS) {
                badge = connProtocol === 'auto' ? '🪟 Auto (WinRM/HTTPS)' : '🪟 WinRM/HTTPS';
                desc = `Port ${port} - Secure (TLS encrypted)`;
                secure = '🔒 Encrypted';
            } else if (isHTTP) {
                badge = connProtocol === 'auto' ? '🪟 Auto (WinRM/HTTP)' : '🪟 WinRM/HTTP';
                desc = `Port ${port} - ⚠️ Not encrypted (use HTTPS)`;
                secure = '⚠️ Insecure';
            } else {
                badge = connProtocol === 'auto' ? '🪟 Auto (WinRM Custom)' : '🪟 WinRM (Custom)';
                desc = `Port ${port} - Ensure TLS is configured`;
                secure = '🔒 Encrypted';
            }

            if (connProtocol === 'auto') {
                desc += ' • SSH fallback';
            }

            protocolInfo.innerHTML = `
                <span class="wizard-protocol-badge windows">${badge}</span>
                <span class="wizard-protocol-desc">${desc}</span>
                <span class="wizard-protocol-secure ${isHTTP ? 'warning' : ''}">${secure}</span>
            `;
        }
    } else if (os === 'hypervisor') {
        // Show generic info for hypervisors, could be extended per type
        protocolInfo.innerHTML = `
            <span class="wizard-protocol-badge hypervisor">🖥️ Hypervisor</span>
            <span class="wizard-protocol-desc">API/SSH/HTTPS - See below for details</span>
            <span class="wizard-protocol-secure">🔒/⚠️ Depends on configuration</span>
        `;
    } else {
        const isDefault = port === 22;
        protocolInfo.innerHTML = `
            <span class="wizard-protocol-badge linux">🐧 SSH Protocol</span>
            <span class="wizard-protocol-desc">Port ${port}${isDefault ? '' : ' (custom)'} - Encrypted</span>
            <span class="wizard-protocol-secure">🔒 Encrypted</span>
        `;
    }
}

function updateConnectionFormForOS(os) {
    const portInput = document.getElementById('wizard-server-port');
    const portLabel = document.getElementById('wizard-port-label');
    const portHint = document.getElementById('wizard-port-hint');
    const authMethodSelect = document.getElementById('wizard-auth-method');
    const keyLabel = document.getElementById('wizard-key-label');
    const keyInput = document.getElementById('wizard-server-key');
    const protocolInfo = document.getElementById('wizard-protocol-info');
    const protocolGroup = document.getElementById('wizard-protocol-group');
    const connProtocolSelect = document.getElementById('wizard-connection-protocol');

    if (os === 'windows') {
        // Windows: Show protocol selector (WinRM/SSH/Auto)
        if (protocolGroup) protocolGroup.style.display = '';
        if (connProtocolSelect) connProtocolSelect.value = 'auto';

        // WinRM over HTTPS (secure) - allow custom ports
        if (portInput) portInput.value = 5986;
        if (portLabel) portLabel.textContent = 'WinRM Port';
        if (portHint) portHint.textContent = 'Default: 5986 (HTTPS). Custom ports supported.';

        // Update auth options for Windows
        if (authMethodSelect) {
            authMethodSelect.innerHTML = `
                <option value="password">Password (NTLM over TLS)</option>
                <option value="kerberos">Kerberos</option>
                <option value="certificate">Client Certificate</option>
            `;
        }

        if (keyLabel) keyLabel.textContent = 'Certificate Path';
        if (keyInput) keyInput.placeholder = 'C:\\certs\\client.pfx';

        updateProtocolInfo('windows', 5986, 'auto');
    } else if (os === 'hypervisor') {
        // Hide protocol selector for non-Windows
        if (protocolGroup) protocolGroup.style.display = 'none';

        // Hypervisor: Show generic fields, could be extended for type
        if (portInput) portInput.value = '';
        if (portLabel) portLabel.textContent = 'API/SSH Port';
        if (portHint) portHint.textContent = 'Depends on hypervisor type (e.g., 22 for KVM, 443 for ESXi)';
        if (authMethodSelect) {
            authMethodSelect.innerHTML = `
                <option value="password">Password</option>
                <option value="key">SSH Key</option>
                <option value="certificate">API Certificate</option>
            `;
        }
        if (keyLabel) keyLabel.textContent = 'Key/Certificate Path';
        if (keyInput) keyInput.placeholder = '/path/to/key-or-cert';
        updateProtocolInfo('hypervisor', portInput && portInput.value ? parseInt(portInput.value) : 22);
    } else {
        // Hide protocol selector for non-Windows
        if (protocolGroup) protocolGroup.style.display = 'none';

        // Linux: SSH (inherently encrypted) - allow custom ports
        if (portInput) portInput.value = 22;
        if (portLabel) portLabel.textContent = 'SSH Port';
        if (portHint) portHint.textContent = 'Default: 22 (SSH). Custom ports supported.';

        // Update auth options for Linux
        if (authMethodSelect) {
            authMethodSelect.innerHTML = `
                <option value="password">Password (over SSH)</option>
                <option value="key">SSH Key (recommended)</option>
            `;
        }

        if (keyLabel) keyLabel.textContent = 'SSH Key Path';
        if (keyInput) keyInput.placeholder = '~/.ssh/id_rsa';

        updateProtocolInfo('linux', 22);
    }

    // Reset to password auth when switching OS
    if (authMethodSelect) {
        authMethodSelect.value = 'password';
        updateAuthFields();
    }
}

function updateAuthFields() {
    const authMethodSelect = document.getElementById('wizard-auth-method');
    if (!authMethodSelect) return;

    const method = authMethodSelect.value;
    const isPasswordAuth = (method === 'password');
    const isKeyOrCertAuth = (method === 'key' || method === 'certificate');

    document.querySelectorAll('.wizard-auth-password').forEach(el => {
        el.style.display = isPasswordAuth ? '' : 'none';
    });
    document.querySelectorAll('.wizard-auth-key').forEach(el => {
        el.style.display = isKeyOrCertAuth ? '' : 'none';
    });
}

/**
 * Linux elevation options for the wizard
 */
const wizardLinuxElevationOptions = [
    { value: 'sudo', label: 'sudo (standard) - Requires sudo password' },
    { value: 'sudo_nopasswd', label: 'sudo NOPASSWD (automation) - Passwordless sudo' },
    { value: 'audit_wrapper', label: 'Audit Wrapper (least-privilege) - Restricted commands only' },
    { value: 'none', label: 'None - Run as connected user (limited audits)' }
];

/**
 * Windows elevation options for the wizard
 */
const wizardWindowsElevationOptions = [
    { value: 'runas', label: 'RunAs (standard) - Windows elevation prompt' },
    { value: 'jea', label: 'JEA Endpoint (least-privilege) - Constrained PowerShell' },
    { value: 'admin', label: 'Administrator (direct) - Run as admin user' },
    { value: 'none', label: 'None - Run as connected user (limited audits)' }
];

/**
 * Update wizard elevation method dropdown options based on selected OS
 */
function updateWizardElevationOptions() {
    const os = document.querySelector('input[name="wizard-os"]:checked')?.value || 'linux';
    const select = document.getElementById('wizard-new-server-elevation-method');
    if (!select) return;

    const options = os === 'windows' ? wizardWindowsElevationOptions : wizardLinuxElevationOptions;
    const currentValue = select.value;

    // Clear and rebuild options
    select.innerHTML = '';
    options.forEach(opt => {
        const option = document.createElement('option');
        option.value = opt.value;
        option.textContent = opt.label;
        select.appendChild(option);
    });

    // Try to restore previous value if still valid
    const validValues = options.map(o => o.value);
    if (validValues.includes(currentValue)) {
        select.value = currentValue;
    } else {
        // Set default based on OS
        select.value = os === 'windows' ? 'runas' : 'sudo';
    }

    // Update JEA endpoint visibility
    toggleWizardJeaEndpoint();

    // Update recommendation info
    updateWizardElevationInfo(os);
}

/**
 * Toggle JEA endpoint field visibility in wizard based on elevation method
 */
function toggleWizardJeaEndpoint() {
    const elevationSelect = document.getElementById('wizard-new-server-elevation-method');
    const jeaGroup = document.getElementById('wizard-jea-endpoint-group');

    if (!elevationSelect || !jeaGroup) return;

    if (elevationSelect.value === 'jea') {
        jeaGroup.style.display = 'block';
    } else {
        jeaGroup.style.display = 'none';
    }
}

/**
 * Update elevation recommendation info in wizard
 */
function updateWizardElevationInfo(os) {
    const infoEl = document.getElementById('wizard-elevation-info');
    if (!infoEl) return;

    if (os === 'windows') {
        infoEl.innerHTML = '<strong>💡 Recommendation:</strong> For production Windows servers, use <code>JEA Endpoint</code> for least-privilege access. Deploy with <code>.\\Deploy-SecurityAuditJEA.ps1</code>';
    } else {
        infoEl.innerHTML = '<strong>💡 Recommendation:</strong> For production servers, use <code>audit_wrapper</code> for least-privilege access. Deploy with <code>sudo ./deploy-least-privilege.sh</code>';
    }
}

// Expose elevation functions globally for HTML handlers
window.updateWizardElevationOptions = updateWizardElevationOptions;
window.toggleWizardJeaEndpoint = toggleWizardJeaEndpoint;

async function testWizardConnection() {
    const statusEl = document.getElementById('wizard-test-status');
    const testBtn = document.getElementById('wizard-test-connection');

    const serverData = getWizardServerFormData();
    if (!serverData) return;

    testBtn.disabled = true;
    statusEl.textContent = '⏳ Testing...';
    statusEl.className = 'wizard-test-status testing';

    try {
        const response = await wizardFetch('/api/servers/test', {
            method: 'POST',
            body: JSON.stringify(serverData)
        });

        const data = await response.json();

        if (data.success) {
            statusEl.textContent = '✅ Connection successful!';
            statusEl.className = 'wizard-test-status success';
        } else {
            statusEl.textContent = '❌ ' + (data.error || 'Connection failed');
            statusEl.className = 'wizard-test-status error';
        }
    } catch (error) {
        statusEl.textContent = '❌ ' + error.message;
        statusEl.className = 'wizard-test-status error';
    }

    testBtn.disabled = false;
}

async function addWizardServer() {
    const serverData = getWizardServerFormData();
    if (!serverData) return;

    const addBtn = document.getElementById('wizard-add-server-btn');
    addBtn.disabled = true;
    addBtn.textContent = '⏳ Adding...';

    try {
        const response = await wizardFetch('/api/servers/add', {
            method: 'POST',
            body: JSON.stringify(serverData)
        });

        const data = await response.json();

        if (data.success) {
            // Store new server in state
            wizardState.newServer = serverData;
            wizardState.selectedServers = [serverData.name];

            // Proceed to discovery
            goToWizardStep('discovery');
        } else {
            alert('Failed to add server: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Error adding server: ' + error.message);
    }

    addBtn.disabled = false;
    addBtn.textContent = 'Add Server & Continue →';
}

function getWizardServerFormData() {
    const name = document.getElementById('wizard-server-name')?.value.trim();
    const host = document.getElementById('wizard-server-host')?.value.trim();
    const port = document.getElementById('wizard-server-port')?.value || 22;
    const user = document.getElementById('wizard-server-user')?.value.trim();
    const authMethod = document.getElementById('wizard-auth-method')?.value || 'password';
    const password = document.getElementById('wizard-server-password')?.value;
    const keyPath = document.getElementById('wizard-server-key')?.value;
    const description = document.getElementById('wizard-server-desc')?.value.trim();
    const os = document.querySelector('input[name="wizard-os"]:checked')?.value || 'linux';
    const connectionProtocol = document.getElementById('wizard-connection-protocol')?.value || 'auto';
    const connectionMethod = document.querySelector('input[name="wizard-connection-method"]:checked')?.value || 'direct';

    // Validate required fields
    if (!name) {
        alert('Please enter a server name');
        return null;
    }
    if (!host) {
        alert('Please enter a hostname or IP address');
        return null;
    }
    if (!user) {
        alert('Please enter a username');
        return null;
    }

    // Validate hostname format
    if (!isValidHostname(host)) {
        alert('Invalid hostname or IP address format');
        return null;
    }

    // Validate port
    if (!isValidPort(port)) {
        alert('Invalid port number (must be 1-65535)');
        return null;
    }

    // Validate username format
    if (!isValidUsername(user)) {
        alert('Invalid username format');
        return null;
    }

    // Determine protocol based on OS and connection protocol selection
    let protocol = 'ssh';
    if (os === 'windows') {
        // For Windows, use the selected connection protocol
        // 'auto' maps to 'winrm' on the backend (with SSH fallback)
        protocol = connectionProtocol === 'ssh' ? 'ssh' : 'winrm';
    } else if (os === 'hypervisor') {
        protocol = 'hypervisor';
    }

    // Both SSH and WinRM (HTTPS) use encrypted transport
    const portNum = parseInt(port);
    const useSSL = (os === 'windows' && protocol === 'winrm' && (portNum === 5986 || portNum !== 5985)) || os === 'hypervisor';

    // Build auth data based on method
    const authData = {
        auth_method: authMethod
    };

    if (authMethod === 'password') {
        authData.password = password;
    } else if (authMethod === 'key') {
        authData.key_path = keyPath;
    } else if (authMethod === 'certificate') {
        authData.certificate_path = keyPath;
    } else if (authMethod === 'kerberos') {
        // Kerberos uses current Windows credentials
        authData.use_kerberos = true;
    }

    // Get execution/elevation only for script-based direct SSH/WinRM execution.
    const includeExecutionConfig = connectionMethod === 'direct';
    const newServerExecMode = includeExecutionConfig
        ? (document.getElementById('wizard-new-server-execution-mode')?.value || 'stream')
        : null;
    const elevationMethod = includeExecutionConfig
        ? (document.getElementById('wizard-new-server-elevation-method')?.value || 'sudo')
        : null;
    const jeaEndpoint = includeExecutionConfig
        ? (document.getElementById('wizard-new-server-jea-endpoint')?.value?.trim() || null)
        : null;

    const payload = {
        name,
        hostname: host,
        port: portNum,
        username: user,
        protocol,
        connection_protocol: os === 'windows' ? connectionProtocol : undefined,  // Only for Windows
        use_ssl: useSSL,  // Always use TLS/SSL for WinRM
        verify_ssl: true,  // Verify SSL certificates
        ...authData,
        description,
        os_type: os
    };

    if (includeExecutionConfig) {
        payload.execution_mode = newServerExecMode;
        payload.elevation_method = elevationMethod;
        payload.jea_endpoint = jeaEndpoint;
    }

    return payload;
}

// ============================================
// Audit Mode Selection (Plan vs Manual)
// ============================================
function setupWizardAuditMode() {
    const modeRadios = document.querySelectorAll('input[name="wizard-audit-mode"]');

    modeRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            toggleAuditMode(radio.value);
        });
    });

    // Plan selection dropdown
    const planSelect = document.getElementById('wizard-audit-plan-select');
    if (planSelect) {
        planSelect.addEventListener('change', () => {
            showPlanPreview(planSelect.value);
        });
    }
}

function toggleAuditMode(mode) {
    const planSelection = document.getElementById('wizard-plan-selection');
    const manualList = document.getElementById('wizard-audit-manual');

    if (mode === 'plan') {
        if (planSelection) planSelection.style.display = 'block';
        if (manualList) manualList.style.display = 'none';
    } else {
        if (planSelection) planSelection.style.display = 'none';
        if (manualList) manualList.style.display = 'block';
    }
}

async function loadWizardAuditPlans() {
    const planSelect = document.getElementById('wizard-audit-plan-select');
    if (!planSelect) return;

    try {
        const response = await wizardFetch('/api/plans');
        if (!response.ok) throw new Error('Failed to load plans');

        const data = await response.json();
        const plans = data.plans || [];

        planSelect.innerHTML = '<option value="">-- Choose a plan --</option>';
        plans.forEach(plan => {
            const option = document.createElement('option');
            option.value = plan.path || plan.name;
            option.textContent = `${plan.name} (${plan.audits ? plan.audits.length : 0} audits)`;
            option.dataset.plan = JSON.stringify(plan);
            planSelect.appendChild(option);
        });

    } catch (error) {
        console.error('Error loading audit plans:', error);
    }
}

function showPlanPreview(planPath) {
    const planSelect = document.getElementById('wizard-audit-plan-select');
    const previewContainer = document.getElementById('wizard-plan-preview');
    const previewName = document.getElementById('wizard-plan-preview-name');
    const previewCount = document.getElementById('wizard-plan-preview-count');
    const previewAudits = document.getElementById('wizard-plan-preview-audits');

    if (!planPath || !planSelect) {
        if (previewContainer) previewContainer.style.display = 'none';
        return;
    }

    const selectedOption = planSelect.options[planSelect.selectedIndex];
    if (!selectedOption || !selectedOption.dataset.plan) {
        if (previewContainer) previewContainer.style.display = 'none';
        return;
    }

    try {
        const plan = JSON.parse(selectedOption.dataset.plan);

        previewName.textContent = plan.name;
        previewCount.textContent = `${plan.audits ? plan.audits.length : 0} audits`;

        if (plan.audits && plan.audits.length > 0) {
            previewAudits.innerHTML = plan.audits.slice(0, 10).map(audit =>
                `<span class="wizard-plan-preview-audit">✓ ${escapeHtml(audit)}</span>`
            ).join('') + (plan.audits.length > 10 ? `<span class="wizard-plan-preview-more">+${plan.audits.length - 10} more...</span>` : '');
        } else {
            previewAudits.innerHTML = '<span class="wizard-plan-preview-empty">No audits in this plan</span>';
        }

        previewContainer.style.display = 'block';

        // Store selected audits from plan
        wizardState.selectedAudits = plan.audits || [];
        updateAuditSelection();

    } catch (error) {
        console.error('Error parsing plan:', error);
        previewContainer.style.display = 'none';
    }
}

// ============================================
// OS Filter for Audits
// ============================================
function setupWizardOSFilter() {
    const filterButtons = document.querySelectorAll('.wizard-os-filter-btn');

    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const os = btn.getAttribute('data-os');

            // Update button states
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Apply filter
            wizardState.osFilter = os;
            filterAuditsByOS(os);

            // Hide auto-filter message when manually changing
            const autoMsg = document.getElementById('wizard-audit-filter-auto');
            if (autoMsg) autoMsg.style.display = 'none';
        });
    });
}

function filterAuditsByOS(os) {
    wizardLog('Wizard: Filtering audits by OS:', os);

    const auditList = document.getElementById('wizard-audit-list');
    if (!auditList) return;

    // Show/hide audit items based on platform
    auditList.querySelectorAll('.wizard-audit-item').forEach(item => {
        const platform = item.getAttribute('data-platform');
        if (os === 'all' || platform === os) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
            // Deselect hidden items
            const checkbox = item.querySelector('input[type="checkbox"]');
            if (checkbox && checkbox.checked) {
                checkbox.checked = false;
                item.classList.remove('selected');
            }
        }
    });

    // Update group visibility and counts
    auditList.querySelectorAll('.wizard-audit-group').forEach(group => {
        const visibleItems = group.querySelectorAll('.wizard-audit-item:not([style*="display: none"])');

        if (visibleItems.length === 0) {
            group.style.display = 'none';
        } else {
            group.style.display = '';
            const countBadge = group.querySelector('.wizard-audit-group-count');
            if (countBadge) countBadge.textContent = visibleItems.length;
        }
    });

    // Update selection count
    updateAuditSelection();
}

function autoFilterByServerOS() {
    // Determine OS from connected server or selected servers
    let detectedOS = null;

    if (wizardState.mode === 'new') {
        // Get OS from connect form
        const osRadio = document.querySelector('input[name="wizard-os"]:checked');
        if (osRadio) {
            detectedOS = osRadio.value;
        }
    } else if (wizardState.selectedServers.length > 0) {
        // For existing servers, check if all are same OS
        // This would require server data to include OS info
        // For now, detect from server list if available
        const firstServer = document.querySelector(`#wizard-server-list .wizard-server-item[data-server-id="${wizardState.selectedServers[0]}"]`);
        if (firstServer) {
            const osAttr = firstServer.getAttribute('data-os');
            if (osAttr) detectedOS = osAttr;
        }
    }

    if (detectedOS && (detectedOS === 'linux' || detectedOS === 'windows')) {
        wizardState.serverOS = detectedOS;
        wizardState.osFilter = detectedOS;

        // Update filter button state
        document.querySelectorAll('.wizard-os-filter-btn').forEach(btn => {
            btn.classList.toggle('active', btn.getAttribute('data-os') === detectedOS);
        });

        // Apply filter
        filterAuditsByOS(detectedOS);

        // Show auto-filter message
        const autoMsg = document.getElementById('wizard-audit-filter-auto');
        if (autoMsg) autoMsg.style.display = 'inline';

        wizardLog('Wizard: Auto-filtered to', detectedOS);
    }
}

// ============================================
// Plan Toggle (Optional Save)
// ============================================
function setupWizardPlanToggle() {
    const saveAsPlanCheckbox = document.getElementById('wizard-save-as-plan');
    const planForm = document.getElementById('wizard-plan-form');

    if (saveAsPlanCheckbox && planForm) {
        saveAsPlanCheckbox.addEventListener('change', () => {
            planForm.style.display = saveAsPlanCheckbox.checked ? 'block' : 'none';
            wizardState.saveAsPlan = saveAsPlanCheckbox.checked;
        });
    }
}

// ============================================
// Navigation
// ============================================
function setupWizardNavigation() {
    const navItems = document.querySelectorAll('.wizard-nav-item');
    wizardLog('Wizard: Found ' + navItems.length + ' nav items');

    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const step = this.getAttribute('data-step');
            wizardLog('Wizard: Nav clicked, step=' + step);
            if (step) {
                goToWizardStep(step);
            }
        });
    });
}

function goToWizardStep(stepName) {
    wizardLog('Wizard: Going to step ' + stepName);

    // Update navigation - remove active from all
    const navItems = document.querySelectorAll('.wizard-nav-item');
    navItems.forEach(item => {
        item.classList.remove('active');
    });

    // Add active to matching nav item
    const activeNav = document.querySelector('.wizard-nav-item[data-step="' + stepName + '"]');
    if (activeNav) {
        activeNav.classList.add('active');
        wizardLog('Wizard: Activated nav for ' + stepName);
    } else {
        wizardLog('Wizard: No nav item found for ' + stepName);
    }

    // Update content panels - hide all
    const steps = document.querySelectorAll('.wizard-step');
    steps.forEach(step => {
        step.classList.remove('active');
        step.style.display = 'none';
    });

    // Show target step
    const targetStep = document.getElementById('wizard-step-' + stepName);
    if (targetStep) {
        targetStep.classList.add('active');
        targetStep.style.display = 'flex';
        wizardLog('Wizard: Activated step panel wizard-step-' + stepName);
    } else {
        wizardLog('Wizard: No step panel found for wizard-step-' + stepName);
    }

    wizardState.currentStep = stepName;

    // Update run summary when reaching run step
    if (stepName === 'run') {
        updateRunSummary();
    }

    // Auto-filter audits by server OS when entering audits step
    if (stepName === 'audits' && !wizardState.filteredAudits) {
        autoFilterByServerOS();
    }
}

// ============================================
// Button Handlers
// ============================================
function setupWizardButtons() {
    // Next buttons
    document.querySelectorAll('.wizard-next').forEach(btn => {
        btn.addEventListener('click', async () => {
            const nextStep = btn.getAttribute('data-next');
            if (nextStep) {
                // Special handling when going to recommendations step
                if (nextStep === 'recommendations') {
                    await populateWizardRecommendations();
                }
                goToWizardStep(nextStep);
            }
        });
    });

    // Previous buttons
    document.querySelectorAll('.wizard-prev').forEach(btn => {
        btn.addEventListener('click', () => {
            const prevStep = btn.getAttribute('data-prev');
            if (prevStep) {
                goToWizardStep(prevStep);
            }
        });
    });

    // Skip buttons (for existing server mode)
    document.querySelectorAll('.wizard-skip').forEach(btn => {
        btn.addEventListener('click', () => {
            const nextStep = btn.getAttribute('data-next');
            if (nextStep) {
                goToWizardStep(nextStep);
            }
        });
    });

    // Execute button
    const executeBtn = document.getElementById('wizard-execute-btn');
    if (executeBtn) {
        executeBtn.addEventListener('click', executeWizardAudit);
    }

    // Discovery button
    const discoveryBtn = document.getElementById('wizard-run-discovery');
    if (discoveryBtn) {
        discoveryBtn.addEventListener('click', runWizardDiscovery);
    }

    // Apply Recommendations button
    const applyRecsBtn = document.getElementById('wizard-apply-recommendations');
    if (applyRecsBtn) {
        applyRecsBtn.addEventListener('click', applyRecommendationsAndContinue);
    }

    // Skip to Manual Selection button
    const skipToManualBtn = document.getElementById('wizard-skip-to-manual');
    if (skipToManualBtn) {
        skipToManualBtn.addEventListener('click', skipToManualAuditSelection);
    }

    // Restart button
    document.querySelectorAll('.wizard-restart').forEach(btn => {
        btn.addEventListener('click', restartWizard);
    });

    // Execution mode change handlers
    document.querySelectorAll('input[name="wizard-execution-mode"]').forEach(input => {
        input.addEventListener('change', function() {
            // Update selected class on rows
            document.querySelectorAll('.wizard-mode-row').forEach(row => {
                row.classList.remove('selected');
            });
            const parentRow = this.closest('.wizard-mode-row');
            if (parentRow) {
                parentRow.classList.add('selected');
            }
            handleWizardExecutionModeChange();
        });
    });

    // Table row click handlers for execution mode
    document.querySelectorAll('.wizard-mode-row').forEach(row => {
        row.addEventListener('click', function(e) {
            if (e.target.type === 'radio') return; // Let radio handle itself
            const radio = this.querySelector('input[type="radio"]');
            if (radio) {
                radio.checked = true;
                radio.dispatchEvent(new Event('change', { bubbles: true }));
            }
        });
    });
}

// ============================================
// Load Servers
// ============================================
let cachedWizardServers = [];  // Cache servers for filtering
let wizardServerSearchFilter = '';

async function loadWizardServers() {
    const container = document.getElementById('wizard-server-list');
    if (!container) return;

    try {
        const response = await wizardFetch('/api/servers');
        if (!response.ok) throw new Error('Failed to load servers');

        const data = await response.json();
        const servers = data.servers || data || [];
        cachedWizardServers = servers;

        renderWizardServers(servers);
    } catch (error) {
        console.error('Error loading servers:', error);
        container.innerHTML = `
            <div class="wizard-results-empty">
                <p>Error loading servers. Please try again.</p>
            </div>
        `;
    }
}

function renderWizardServers(servers) {
    const container = document.getElementById('wizard-server-list');
    if (!container) return;

    // Apply search filter
    let filteredServers = servers;
    if (wizardServerSearchFilter) {
        const search = wizardServerSearchFilter.toLowerCase();
        filteredServers = servers.filter(s =>
            (s.name || '').toLowerCase().includes(search) ||
            (s.hostname || s.host || '').toLowerCase().includes(search) ||
            (s.os_type || s.os || '').toLowerCase().includes(search)
        );
    }

    if (filteredServers.length === 0) {
        if (wizardServerSearchFilter) {
            container.innerHTML = `
                <div class="wizard-results-empty">
                    <p>No servers match your search.</p>
                </div>
            `;
        } else {
            container.innerHTML = `
                <div class="wizard-results-empty">
                    <p>No servers configured. Go to the Connect tab to add servers.</p>
                </div>
            `;
        }
        return;
    }

    // Build list header
    const headerRow = `
        <div class="wizard-server-list-header">
            <span></span>
            <span>Name</span>
            <span>Host</span>
            <span>Status</span>
            <span></span>
        </div>
    `;

    const rows = filteredServers.map(server => {
        const serverOS = server.os_type || server.os || (server.port === 5985 || server.port === 5986 ? 'windows' : 'linux');
        const osIcon = serverOS === 'windows' ? '🪟' : (serverOS === 'hypervisor' ? '🖥️' : '🐧');
        const status = server.last_test_success === true ? 'online' :
                      server.last_test_success === false ? 'offline' : 'untested';
        const statusLabel = status === 'online' ? 'Online' :
                           status === 'offline' ? 'Offline' : 'Untested';
        const isSelected = wizardState.selectedServers.includes(String(server.id || server.name));
        return `
        <div class="wizard-server-row${isSelected ? ' selected' : ''}" data-server-id="${escapeHtml(server.id || server.name)}" data-os="${escapeHtml(serverOS)}">
            <div class="wizard-server-checkbox">
                <input type="checkbox" id="wizard-server-${escapeHtml(server.id || server.name)}"${isSelected ? ' checked' : ''}>
            </div>
            <div class="wizard-server-name-col">
                <span class="wizard-server-icon">${osIcon}</span>
                <span class="wizard-server-name">${escapeHtml(server.name || server.hostname)}</span>
            </div>
            <div class="wizard-server-host">${escapeHtml(server.hostname || server.host)}:${server.port || 22}</div>
            <div class="wizard-server-status">
                <span class="status-dot ${status}"></span>
                <span>${statusLabel}</span>
            </div>
            <div class="wizard-server-actions">
                <button class="btn-icon" onclick="openWizardServerConfig('${escapeHtml(server.id || server.name)}')" title="Configure">⚙️</button>
            </div>
        </div>
    `}).join('');

    container.innerHTML = headerRow + rows;

    // Add click handlers
    container.querySelectorAll('.wizard-server-row').forEach(item => {
        item.addEventListener('click', (e) => {
            // Don't toggle checkbox when clicking on buttons or checkbox itself
            if (e.target.type === 'checkbox' || e.target.tagName === 'BUTTON' || e.target.closest('button')) return;
            const checkbox = item.querySelector('input[type="checkbox"]');
            checkbox.checked = !checkbox.checked;
            item.classList.toggle('selected', checkbox.checked);
            updateServerSelection();
        });

        const checkbox = item.querySelector('input[type="checkbox"]');
        checkbox.addEventListener('change', () => {
            item.classList.toggle('selected', checkbox.checked);
            updateServerSelection();
        });
    });
}

function filterWizardServers(searchTerm) {
    wizardServerSearchFilter = searchTerm;
    renderWizardServers(cachedWizardServers);
}

// Expose globally
window.filterWizardServers = filterWizardServers;

function updateServerSelection() {
    const checkboxes = document.querySelectorAll('#wizard-server-list input[type="checkbox"]:checked');
    wizardState.selectedServers = Array.from(checkboxes).map(cb => {
        return cb.closest('.wizard-server-row').getAttribute('data-server-id');
    });

    const countEl = document.getElementById('wizard-servers-selected');
    if (countEl) {
        countEl.textContent = `${wizardState.selectedServers.length} server${wizardState.selectedServers.length !== 1 ? 's' : ''} selected`;
    }
}

// ============================================
// Load Audits
// ============================================
async function loadWizardAudits() {
    const container = document.getElementById('wizard-audit-list');
    if (!container) return;

    try {
        const response = await wizardFetch('/api/audits');
        if (!response.ok) throw new Error('Failed to load audits');

        const data = await response.json();
        const audits = data.audits || data || [];

        if (audits.length === 0) {
            container.innerHTML = `
                <div class="wizard-results-empty">
                    <p>No audits available.</p>
                </div>
            `;
            return;
        }

        // Group audits by domain
        const groupedAudits = {};
        audits.forEach(audit => {
            const domain = audit.domain || 'general';
            if (!groupedAudits[domain]) groupedAudits[domain] = [];
            groupedAudits[domain].push(audit);
        });

        // Render grouped list with collapsible headers (collapsed by default)
        container.innerHTML = Object.entries(groupedAudits).map(([domain, domainAudits]) => `
            <div class="wizard-audit-group" data-domain="${escapeHtml(domain)}">
                <div class="wizard-audit-group-header" data-collapsed="true">
                    <span class="wizard-audit-group-collapse-icon">▶</span>
                    <span class="wizard-audit-group-icon">${getDomainIcon(domain)}</span>
                    <span class="wizard-audit-group-title">${escapeHtml(domain.charAt(0).toUpperCase() + domain.slice(1))}</span>
                    <span class="wizard-audit-group-count">${domainAudits.length}</span>
                    <button class="wizard-audit-select-all btn btn-small btn-secondary" data-domain="${escapeHtml(domain)}">Select All</button>
                </div>
                <ul class="wizard-audit-items" style="display: none;">
                    ${domainAudits.map(audit => `
                        <li class="wizard-audit-item" data-audit-id="${escapeHtml(audit.path || audit.id || audit.name)}" data-audit-name="${escapeHtml(audit.name)}" data-platform="${escapeHtml(audit.platform || 'linux')}" data-search-text="${escapeHtml((audit.display_name || audit.name || '').toLowerCase() + ' ' + (audit.description || '').toLowerCase())}">
                            <input type="checkbox" id="wizard-audit-${escapeHtml(audit.name || audit.id)}">
                            <span class="wizard-audit-os-badge ${audit.platform === 'windows' ? 'windows' : 'linux'}">${audit.platform === 'windows' ? '🪟' : '🐧'}</span>
                            <div class="wizard-audit-content">
                                <span class="wizard-audit-name">${escapeHtml(audit.display_name || audit.name || audit.id)}</span>
                                <span class="wizard-audit-desc">${escapeHtml(audit.description || audit.path || '')}</span>
                            </div>
                        </li>
                    `).join('')}
                </ul>
            </div>
        `).join('');

        // Add select all handlers
        container.querySelectorAll('.wizard-audit-select-all').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const domain = btn.getAttribute('data-domain');
                const group = btn.closest('.wizard-audit-group');
                const checkboxes = group.querySelectorAll('.wizard-audit-item:not([style*="display: none"]) input[type="checkbox"]');
                const allChecked = Array.from(checkboxes).every(cb => cb.checked);
                checkboxes.forEach(cb => {
                    cb.checked = !allChecked;
                    cb.closest('.wizard-audit-item').classList.toggle('selected', !allChecked);
                });
                btn.textContent = allChecked ? 'Select All' : 'Deselect All';
                updateAuditSelection();
            });
        });

        // Add collapsible group header handlers
        container.querySelectorAll('.wizard-audit-group-header').forEach(header => {
            header.addEventListener('click', (e) => {
                // Don't collapse if clicking the select all button
                if (e.target.closest('.wizard-audit-select-all')) return;

                const isCollapsed = header.getAttribute('data-collapsed') === 'true';
                const group = header.closest('.wizard-audit-group');
                const items = group.querySelector('.wizard-audit-items');
                const icon = header.querySelector('.wizard-audit-group-collapse-icon');

                if (isCollapsed) {
                    items.style.display = '';
                    icon.textContent = '▼';
                    header.setAttribute('data-collapsed', 'false');
                } else {
                    items.style.display = 'none';
                    icon.textContent = '▶';
                    header.setAttribute('data-collapsed', 'true');
                }
            });
        });

        // Add click handlers
        container.querySelectorAll('.wizard-audit-item').forEach(item => {
            item.addEventListener('click', (e) => {
                if (e.target.type === 'checkbox') return;
                const checkbox = item.querySelector('input[type="checkbox"]');
                checkbox.checked = !checkbox.checked;
                item.classList.toggle('selected', checkbox.checked);
                updateAuditSelection();
            });

            const checkbox = item.querySelector('input[type="checkbox"]');
            checkbox.addEventListener('change', () => {
                item.classList.toggle('selected', checkbox.checked);
                updateAuditSelection();
            });
        });

        // Setup search and collapse controls
        setupWizardAuditSearch();

    } catch (error) {
        console.error('Error loading audits:', error);
        container.innerHTML = `
            <div class="wizard-results-empty">
                <p>Error loading audits. Please try again.</p>
            </div>
        `;
    }
}

// Wizard audit search and collapse control functions
function setupWizardAuditSearch() {
    const searchInput = document.getElementById('wizard-audit-search');
    const expandAllBtn = document.getElementById('wizard-expand-all-audits');
    const collapseAllBtn = document.getElementById('wizard-collapse-all-audits');

    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            filterWizardAudits(e.target.value);
        });
    }

    if (expandAllBtn) {
        expandAllBtn.addEventListener('click', () => {
            document.querySelectorAll('#wizard-audit-list .wizard-audit-group-header').forEach(header => {
                const group = header.closest('.wizard-audit-group');
                const items = group.querySelector('.wizard-audit-items');
                const icon = header.querySelector('.wizard-audit-group-collapse-icon');
                items.style.display = '';
                icon.textContent = '▼';
                header.setAttribute('data-collapsed', 'false');
            });
        });
    }

    if (collapseAllBtn) {
        collapseAllBtn.addEventListener('click', () => {
            document.querySelectorAll('#wizard-audit-list .wizard-audit-group-header').forEach(header => {
                const group = header.closest('.wizard-audit-group');
                const items = group.querySelector('.wizard-audit-items');
                const icon = header.querySelector('.wizard-audit-group-collapse-icon');
                items.style.display = 'none';
                icon.textContent = '▶';
                header.setAttribute('data-collapsed', 'true');
            });
        });
    }
}

function filterWizardAudits(searchTerm) {
    const container = document.getElementById('wizard-audit-list');
    if (!container) return;

    const term = searchTerm.toLowerCase().trim();

    container.querySelectorAll('.wizard-audit-group').forEach(group => {
        const items = group.querySelectorAll('.wizard-audit-item');
        let visibleCount = 0;

        items.forEach(item => {
            const searchText = item.getAttribute('data-search-text') || '';
            const auditName = item.getAttribute('data-audit-name') || '';
            const auditId = item.getAttribute('data-audit-id') || '';

            const matches = !term ||
                searchText.includes(term) ||
                auditName.toLowerCase().includes(term) ||
                auditId.toLowerCase().includes(term);

            item.style.display = matches ? '' : 'none';
            if (matches) visibleCount++;
        });

        // Show/hide group based on whether it has visible items
        group.style.display = visibleCount > 0 ? '' : 'none';

        // Update count badge
        const countBadge = group.querySelector('.wizard-audit-group-count');
        if (countBadge) {
            countBadge.textContent = visibleCount;
        }

        // Auto-expand groups with matches when searching
        if (term && visibleCount > 0) {
            const header = group.querySelector('.wizard-audit-group-header');
            const itemsList = group.querySelector('.wizard-audit-items');
            const icon = header.querySelector('.wizard-audit-group-collapse-icon');
            itemsList.style.display = '';
            icon.textContent = '▼';
            header.setAttribute('data-collapsed', 'false');
        }
    });
}

function updateAuditSelection() {
    const checkboxes = document.querySelectorAll('#wizard-audit-list input[type="checkbox"]:checked');
    wizardState.selectedAudits = Array.from(checkboxes).map(cb => {
        return cb.closest('.wizard-audit-item').getAttribute('data-audit-id');
    });

    const countEl = document.getElementById('wizard-audits-selected');
    if (countEl) {
        countEl.textContent = `${wizardState.selectedAudits.length} audit${wizardState.selectedAudits.length !== 1 ? 's' : ''} selected`;
    }
}

// ============================================
// Apply Recommendations
// ============================================
function applyRecommendationsAndContinue() {
    // Get all checked recommendations with audit_id and path
    const checkedRecs = document.querySelectorAll('#wizard-recommendations-list input[type="checkbox"]:checked');
    const recommendedAudits = Array.from(checkedRecs).map(cb => ({
        audit_id: cb.getAttribute('data-audit'),
        path: cb.getAttribute('data-path'),
        platform: cb.getAttribute('data-platform')
    }));

    wizardLog('Wizard: Applying recommendations:', recommendedAudits);

    // First, hide all audits and deselect them
    document.querySelectorAll('#wizard-audit-list .wizard-audit-item').forEach(item => {
        item.style.display = 'none';
        const checkbox = item.querySelector('input[type="checkbox"]');
        if (checkbox) {
            checkbox.checked = false;
        }
        item.classList.remove('selected');
    });

    // Track matched audits by group for group visibility
    const groupMatches = new Map();

    // Match recommendations to audits - show and select them
    let matchCount = 0;
    recommendedAudits.forEach(rec => {
        const recAudit = rec.audit_id;
        const recPath = rec.path;
        if (!recAudit) return;

        let auditItem = null;

        // Try path-based match first (most accurate)
        if (recPath) {
            auditItem = document.querySelector(`#wizard-audit-list .wizard-audit-item[data-audit-id="${recPath}"]`);
        }

        // Try exact match on audit_id (script name)
        if (!auditItem) {
            auditItem = document.querySelector(`#wizard-audit-list .wizard-audit-item[data-audit-name="${recAudit}"]`);
        }

        // Try exact match on audit_id in data-audit-id
        if (!auditItem) {
            auditItem = document.querySelector(`#wizard-audit-list .wizard-audit-item[data-audit-id="${recAudit}"]`);
        }

        // If no exact match, try partial match (recommendation ID contained in audit ID or name)
        if (!auditItem) {
            const allAuditItems = document.querySelectorAll('#wizard-audit-list .wizard-audit-item');
            for (const item of allAuditItems) {
                const auditId = (item.getAttribute('data-audit-id') || '').toLowerCase();
                const auditName = (item.getAttribute('data-audit-name') || '').toLowerCase();
                const recId = recAudit.toLowerCase();
                // Match by audit name (script name without extension)
                if (auditName === recId || auditId.includes(recId) || auditName.includes(recId) ||
                    auditId.endsWith('/' + recId + '.sh') || auditId.endsWith('/' + recId + '.ps1') ||
                    auditId.endsWith('\\' + recId + '.sh') || auditId.endsWith('\\' + recId + '.ps1')) {
                    auditItem = item;
                    break;
                }
            }
        }

        if (auditItem) {
            // Show and select this audit
            auditItem.style.display = '';
            const checkbox = auditItem.querySelector('input[type="checkbox"]');
            if (checkbox) {
                checkbox.checked = true;
                auditItem.classList.add('selected');
                matchCount++;
            }

            // Track group
            const group = auditItem.closest('.wizard-audit-group');
            if (group) {
                groupMatches.set(group, (groupMatches.get(group) || 0) + 1);
            }
        } else {
            wizardLog('Wizard: No match found for recommendation:', recAudit, recPath);
        }
    });

    // Hide groups with no matches, show groups with matches
    document.querySelectorAll('#wizard-audit-list .wizard-audit-group').forEach(group => {
        if (groupMatches.has(group)) {
            group.style.display = '';
            // Update count badge
            const countBadge = group.querySelector('.wizard-audit-group-count');
            if (countBadge) {
                countBadge.textContent = groupMatches.get(group);
            }
            // Hide select all button since we're showing filtered list
            const selectAllBtn = group.querySelector('.wizard-audit-select-all');
            if (selectAllBtn) selectAllBtn.style.display = 'none';
        } else {
            group.style.display = 'none';
        }
    });

    wizardLog('Wizard: Applied', matchCount, 'of', recommendedAudits.length, 'recommendations');

    // Store that we're in filtered mode
    wizardState.filteredAudits = true;

    // Update audit selection state
    updateAuditSelection();

    // In existing server mode, switch to manual mode since we're applying recommendations
    if (wizardState.mode === 'existing') {
        const manualRadio = document.querySelector('input[name="wizard-audit-mode"][value="manual"]');
        if (manualRadio) {
            manualRadio.checked = true;
            toggleAuditMode('manual');
        }
    }

    // Navigate to audits step
    goToWizardStep('audits');
}

function skipToManualAuditSelection() {
    // Reset filtered mode - show all audits and groups
    wizardState.filteredAudits = false;

    // Show all audit groups
    document.querySelectorAll('#wizard-audit-list .wizard-audit-group').forEach(group => {
        group.style.display = '';

        // Show select all button
        const selectAllBtn = group.querySelector('.wizard-audit-select-all');
        if (selectAllBtn) selectAllBtn.style.display = '';

        // Restore original count
        const items = group.querySelectorAll('.wizard-audit-item');
        const countBadge = group.querySelector('.wizard-audit-group-count');
        if (countBadge) countBadge.textContent = items.length;
    });

    // Show all audit items but deselect them
    document.querySelectorAll('#wizard-audit-list .wizard-audit-item').forEach(item => {
        item.style.display = '';
        const checkbox = item.querySelector('input[type="checkbox"]');
        if (checkbox) {
            checkbox.checked = false;
        }
        item.classList.remove('selected');
    });

    // Reset select all button text
    document.querySelectorAll('#wizard-audit-list .wizard-audit-select-all').forEach(btn => {
        btn.textContent = 'Select All';
    });

    // Update selection count
    updateAuditSelection();

    // In existing server mode, switch to manual mode
    if (wizardState.mode === 'existing') {
        const manualRadio = document.querySelector('input[name="wizard-audit-mode"][value="manual"]');
        if (manualRadio) {
            manualRadio.checked = true;
            toggleAuditMode('manual');
        }
    }

    // Navigate to audits step
    goToWizardStep('audits');
}

// ============================================
// Server Discovery
// ============================================
async function runWizardDiscovery() {
    const discoveryBtn = document.getElementById('wizard-run-discovery');
    const resultsContainer = document.getElementById('wizard-discovery-results');
    const resultsGrid = document.getElementById('wizard-discovery-grid');
    const continueBtn = document.getElementById('wizard-discovery-continue');

    if (wizardState.selectedServers.length === 0) {
        alert('Please select at least one server first');
        goToWizardStep('servers');
        return;
    }

    // Get discovery options from wizard UI
    const discoverPackages = document.getElementById('wizard-discover-packages')?.checked ?? true;
    const discoverServices = document.getElementById('wizard-discover-services')?.checked ?? true;
    const discoverUpdates = document.getElementById('wizard-discover-updates')?.checked ?? true;
    const discoverSecurity = document.getElementById('wizard-discover-security')?.checked ?? false;
    const lightweight = document.getElementById('wizard-discover-lightweight')?.checked ?? false;
    const throttle = document.getElementById('wizard-discover-throttle')?.checked ?? false;
    const limit = parseInt(document.getElementById('wizard-discover-limit')?.value || 100);

    // Update UI
    discoveryBtn.disabled = true;
    discoveryBtn.textContent = '⏳ Scanning...';

    try {
        const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
        const headers = { 'Content-Type': 'application/json' };
        if (apiKey) headers['X-API-Key'] = apiKey;

        // Run discovery on first selected server (can extend to multiple)
        const serverId = wizardState.selectedServers[0];

        const response = await wizardFetch('/api/discovery/run', {
            method: 'POST',
            headers,
            body: JSON.stringify({
                server_id: serverId,
                format: 'json',
                options: {
                    packages: discoverPackages,
                    services: discoverServices,
                    updates: discoverUpdates,
                    security: discoverSecurity,
                    lightweight: lightweight,
                    throttle: throttle,
                    limit: limit > 0 ? limit : null
                }
            })
        });

        const result = await response.json();

        if (result.success && result.data) {
            // Store discovery result for recommendations
            wizardState.discoveryResult = result.data;

            // Build results HTML from actual discovery data
            const data = result.data;
            const system = data.system || {};
            const osName = system.os_pretty_name || data.os_info?.distro || 'Unknown OS';
            const packagesCount = data.packages?.length || data.software?.length || 0;
            const servicesCount = data.services?.length || 0;
            const updatesCount = data.updates?.length || data.pending_updates?.length || 0;

            // Detect key software
            const webServer = detectSoftware(data, ['nginx', 'apache', 'httpd', 'lighttpd']);
            const database = detectSoftware(data, ['mysql', 'mariadb', 'postgresql', 'postgres', 'mongodb', 'redis']);
            const container = detectSoftware(data, ['docker', 'podman', 'containerd']);
            const security = system.security_stack || detectSoftware(data, ['selinux', 'apparmor', 'firewalld', 'ufw']);

            resultsGrid.innerHTML = `
                <div class="wizard-discovery-item">
                    <div class="wizard-discovery-item-icon">🐧</div>
                    <div class="wizard-discovery-item-label">Operating System</div>
                    <div class="wizard-discovery-item-value">${escapeHtml(osName)}</div>
                </div>
                <div class="wizard-discovery-item">
                    <div class="wizard-discovery-item-icon">🌐</div>
                    <div class="wizard-discovery-item-label">Web Server</div>
                    <div class="wizard-discovery-item-value">${escapeHtml(webServer || 'Not detected')}</div>
                </div>
                <div class="wizard-discovery-item">
                    <div class="wizard-discovery-item-icon">🗄️</div>
                    <div class="wizard-discovery-item-label">Database</div>
                    <div class="wizard-discovery-item-value">${escapeHtml(database || 'Not detected')}</div>
                </div>
                <div class="wizard-discovery-item">
                    <div class="wizard-discovery-item-icon">🐳</div>
                    <div class="wizard-discovery-item-label">Containers</div>
                    <div class="wizard-discovery-item-value">${escapeHtml(container || 'Not detected')}</div>
                </div>
                <div class="wizard-discovery-item">
                    <div class="wizard-discovery-item-icon">🔒</div>
                    <div class="wizard-discovery-item-label">Security</div>
                    <div class="wizard-discovery-item-value">${escapeHtml(security || 'Not detected')}</div>
                </div>
                <div class="wizard-discovery-item">
                    <div class="wizard-discovery-item-icon">📦</div>
                    <div class="wizard-discovery-item-label">Packages</div>
                    <div class="wizard-discovery-item-value">${packagesCount} installed, ${updatesCount} updates</div>
                </div>
            `;
        } else {
            // Show error
            resultsGrid.innerHTML = `
                <div class="wizard-discovery-error">
                    <p>⚠️ Discovery failed: ${escapeHtml(result.error || 'Unknown error')}</p>
                    <p>You can skip discovery and select audits manually.</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Discovery error:', error);
        resultsGrid.innerHTML = `
            <div class="wizard-discovery-error">
                <p>⚠️ Discovery failed: ${escapeHtml(error.message)}</p>
                <p>You can skip discovery and select audits manually.</p>
            </div>
        `;
    }

    resultsContainer.style.display = 'block';
    discoveryBtn.style.display = 'none';
    continueBtn.style.display = 'inline-flex';

    // Show skip button if discovery failed
    const skipBtn = document.getElementById('wizard-discovery-skip');
    if (skipBtn && !wizardState.discoveryResult) {
        skipBtn.style.display = 'inline-flex';
    }
}

// Helper to detect software from discovery data
function detectSoftware(data, keywords) {
    const packages = data.packages || data.software || [];
    const services = data.services || [];

    for (const keyword of keywords) {
        // Check packages
        const pkg = packages.find(p =>
            (p.name || p).toLowerCase().includes(keyword.toLowerCase())
        );
        if (pkg) return pkg.name || pkg;

        // Check services
        const svc = services.find(s =>
            (s.name || s).toLowerCase().includes(keyword.toLowerCase())
        );
        if (svc) return svc.name || svc;
    }
    return null;
}

// ============================================
// Populate Recommendations from Discovery
// ============================================
async function populateWizardRecommendations() {
    const recsList = document.getElementById('wizard-recommendations-list');
    const recsCount = document.getElementById('wizard-recommendations-count');

    if (!recsList) {
        wizardLog('Wizard: No recommendations list element');
        return;
    }

    // If no discovery result, show platform-based recommendations or message
    if (!wizardState.discoveryResult) {
        wizardLog('Wizard: No discovery result, loading platform-based recommendations');
        await loadPlatformBasedRecommendations(recsList, recsCount);
        return;
    }

    try {
        // Get packages and services from discovery
        const data = wizardState.discoveryResult;
        const packages = data.packages || data.software || [];
        const services = data.services || [];

        // Detect platform from discovery
        const osInfo = data.system || data.os_info || {};
        const platform = detectPlatformFromOS(osInfo);

        // Call API to get recommendations
        const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
        const headers = { 'Content-Type': 'application/json' };
        if (apiKey) headers['X-API-Key'] = apiKey;

        const response = await wizardFetch('/api/discovery/recommendations', {
            method: 'POST',
            headers,
            body: JSON.stringify({
                packages: packages,
                services: services,
                platform: platform
            })
        });

        const result = await response.json();

        if (result.success && result.recommendations) {
            renderWizardRecommendations(result.recommendations, data);
            if (recsCount) {
                recsCount.textContent = `${result.recommendations.length} audits recommended`;
            }
        } else {
            // Show error or default recommendations
            recsList.innerHTML = `
                <div class="wizard-recommendation-error">
                    <p>⚠️ Could not load recommendations. Please select audits manually.</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Recommendations error:', error);
        recsList.innerHTML = `
            <div class="wizard-recommendation-error">
                <p>⚠️ Error loading recommendations: ${escapeHtml(error.message)}</p>
            </div>
        `;
    }
}

// Load recommendations based on platform when no discovery was run
async function loadPlatformBasedRecommendations(recsList, recsCount) {
    try {
        // Determine platform from wizard state (new server flow) or selected servers (existing flow)
        let platform = 'linux';

        // Check wizard new server OS selection
        const osRadio = document.querySelector('input[name="wizard-os"]:checked');
        if (osRadio) {
            platform = osRadio.value || 'linux';
        }

        // For existing servers, try to get platform from selected servers
        if (wizardState.selectedServers && wizardState.selectedServers.length > 0) {
            // Try to fetch server info to determine platform
            try {
                const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
                const headers = { 'Content-Type': 'application/json' };
                if (apiKey) headers['X-API-Key'] = apiKey;

                const response = await wizardFetch(`/api/servers/${wizardState.selectedServers[0]}`, {
                    headers,
                    credentials: 'include'
                });
                const serverData = await response.json();
                if (serverData && serverData.os_type) {
                    platform = serverData.os_type.toLowerCase().includes('windows') ? 'windows' : 'linux';
                }
            } catch (e) {
                console.warn('Could not fetch server info for platform detection:', e);
            }
        }

        // Call API to get platform-based recommendations
        const apiKey = localStorage.getItem('apiKey') || localStorage.getItem('api_key') || '';
        const headers = { 'Content-Type': 'application/json' };
        if (apiKey) headers['X-API-Key'] = apiKey;

        const response = await wizardFetch('/api/discovery/recommendations', {
            method: 'POST',
            headers,
            body: JSON.stringify({
                packages: [],
                services: [],
                platform: platform
            })
        });

        const result = await response.json();

        if (result.success && result.recommendations && result.recommendations.length > 0) {
            // Create a minimal discovery data object for rendering
            const minimalData = {
                system: { os_pretty_name: platform === 'windows' ? 'Windows' : 'Linux' }
            };
            renderWizardRecommendations(result.recommendations, minimalData);
            if (recsCount) {
                recsCount.textContent = `${result.recommendations.length} audits recommended`;
            }
        } else {
            // Show message that discovery wasn't run
            recsList.innerHTML = `
                <div class="wizard-recommendation-info">
                    <p>ℹ️ Discovery was not run. Showing general ${platform === 'windows' ? 'Windows' : 'Linux'} audit recommendations.</p>
                    <p class="wizard-recommendation-hint">Run discovery for more targeted recommendations, or skip to manual audit selection.</p>
                </div>
            `;
            if (recsCount) {
                recsCount.textContent = '0 audits recommended';
            }
        }
    } catch (error) {
        console.error('Platform recommendations error:', error);
        recsList.innerHTML = `
            <div class="wizard-recommendation-info">
                <p>ℹ️ Discovery was not run. You can:</p>
                <ul style="margin: 0.5rem 0; padding-left: 1.5rem;">
                    <li>Go back and run discovery for targeted recommendations</li>
                    <li>Skip to manual audit selection</li>
                </ul>
            </div>
        `;
        if (recsCount) {
            recsCount.textContent = '0 audits recommended';
        }
    }
}

// Detect platform from OS info
function detectPlatformFromOS(osInfo) {
    const osName = (osInfo.os_pretty_name || osInfo.distro || osInfo.name || '').toLowerCase();
    if (osName.includes('windows')) return 'windows';
    return 'linux';
}

// Render recommendations in the wizard with collapsible groups
function renderWizardRecommendations(recommendations, discoveryData) {
    const recsList = document.getElementById('wizard-recommendations-list');
    if (!recsList) return;

    // Populate discovery summary first
    populateDiscoverySummary(discoveryData);

    // Group recommendations by category
    const groups = {};
    recommendations.forEach(rec => {
        // Determine group based on path or platform
        let category = 'Platform';
        const path = rec.path || '';
        if (path.includes('/web/') || path.includes('\\web\\') || rec.name.toLowerCase().includes('web') || rec.name.toLowerCase().includes('iis') || rec.name.toLowerCase().includes('nginx') || rec.name.toLowerCase().includes('apache')) {
            category = 'Web Server';
        } else if (path.includes('/data/') || path.includes('\\data\\') || path.includes('/database/') || rec.name.toLowerCase().includes('database') || rec.name.toLowerCase().includes('sql') || rec.name.toLowerCase().includes('mongo') || rec.name.toLowerCase().includes('redis')) {
            category = 'Database';
        } else if (path.includes('/containers/') || rec.name.toLowerCase().includes('docker') || rec.name.toLowerCase().includes('container') || rec.name.toLowerCase().includes('podman')) {
            category = 'Containers';
        } else if (path.includes('/security/') || path.includes('\\security\\') || rec.name.toLowerCase().includes('security') || rec.name.toLowerCase().includes('firewall') || rec.name.toLowerCase().includes('edr') || rec.name.toLowerCase().includes('siem')) {
            category = 'Security';
        } else if (path.includes('/network/') || path.includes('\\network\\') || rec.name.toLowerCase().includes('network') || rec.name.toLowerCase().includes('ssh') || rec.name.toLowerCase().includes('vpn')) {
            category = 'Network';
        } else if (path.includes('/hypervisors/') || path.includes('\\server\\') || rec.name.toLowerCase().includes('hyper') || rec.name.toLowerCase().includes('active directory') || rec.name.toLowerCase().includes('kvm')) {
            category = 'Infrastructure';
        } else if (path.includes('/automation/') || rec.name.toLowerCase().includes('jenkins') || rec.name.toLowerCase().includes('ansible') || rec.name.toLowerCase().includes('terraform')) {
            category = 'Automation';
        } else if (path.includes('/cloud/') || rec.name.toLowerCase().includes('aws') || rec.name.toLowerCase().includes('azure') || rec.name.toLowerCase().includes('gcp')) {
            category = 'Cloud';
        }

        if (!groups[category]) groups[category] = [];
        groups[category].push(rec);
    });

    // Get icons for categories
    const icons = {
        'Platform': '🐧',
        'Web Server': '🌐',
        'Database': '🗄️',
        'Containers': '🐳',
        'Security': '🔒',
        'Network': '🌍',
        'Infrastructure': '🖥️',
        'Automation': '⚙️',
        'Cloud': '☁️'
    };

    // Generate HTML for each group (collapsed by default)
    let html = '';
    for (const [category, recs] of Object.entries(groups)) {
        const detectedInfo = getDetectedInfo(category, discoveryData);
        html += `
            <div class="wizard-recommendation-group" data-category="${escapeHtml(category)}">
                <div class="wizard-recommendation-category" data-collapsed="true">
                    <span class="wizard-recommendation-collapse-icon">▶</span>
                    <span class="wizard-recommendation-icon">${icons[category] || '📋'}</span>
                    <span class="wizard-recommendation-title">${escapeHtml(category)} Audits</span>
                    <span class="wizard-recommendation-count">${recs.length}</span>
                    ${detectedInfo ? `<span class="wizard-recommendation-badge">${escapeHtml(detectedInfo)}</span>` : ''}
                </div>
                <div class="wizard-recommendation-items" style="display: none;">
                    ${recs.map(rec => `
                        <label class="wizard-recommendation-item">
                            <input type="checkbox" checked data-audit="${escapeHtml(rec.audit_id)}" data-path="${escapeHtml(rec.path || '')}" data-platform="${escapeHtml(rec.platform || 'linux')}">
                            <span class="wizard-recommendation-name">${escapeHtml(rec.name)}</span>
                            <span class="wizard-recommendation-desc">${escapeHtml(rec.description || rec.reason || '')}</span>
                        </label>
                    `).join('')}
                </div>
            </div>
        `;
    }

    recsList.innerHTML = html || '<div class="wizard-recommendation-empty">No specific recommendations based on discovery. You can select audits manually.</div>';

    // Add click handlers for collapsible groups
    recsList.querySelectorAll('.wizard-recommendation-category').forEach(header => {
        header.addEventListener('click', (e) => {
            // Don't collapse if clicking a checkbox
            if (e.target.type === 'checkbox') return;

            const isCollapsed = header.getAttribute('data-collapsed') === 'true';
            const group = header.closest('.wizard-recommendation-group');
            const items = group.querySelector('.wizard-recommendation-items');
            const icon = header.querySelector('.wizard-recommendation-collapse-icon');

            if (isCollapsed) {
                items.style.display = '';
                icon.textContent = '▼';
                header.setAttribute('data-collapsed', 'false');
            } else {
                items.style.display = 'none';
                icon.textContent = '▶';
                header.setAttribute('data-collapsed', 'true');
            }
        });
    });
}

// Populate discovery summary in the recommendations step
function populateDiscoverySummary(discoveryData) {
    const summaryList = document.getElementById('wizard-discovery-summary-list');
    const summaryCount = document.getElementById('wizard-discovery-summary-count');
    const summaryToggle = document.getElementById('wizard-discovery-summary-toggle');
    const summaryContent = document.getElementById('wizard-discovery-summary-content');

    if (!summaryList || !discoveryData) return;

    const data = discoveryData;
    const system = data.system || {};
    const osName = system.os_pretty_name || data.os_info?.distro || 'Unknown OS';
    const packagesCount = data.packages?.length || data.software?.length || 0;
    const servicesCount = data.services?.length || 0;
    const updatesCount = data.updates?.length || data.pending_updates?.length || 0;

    // Detect key software
    const webServer = detectSoftware(data, ['nginx', 'apache', 'httpd', 'lighttpd', 'iis']);
    const database = detectSoftware(data, ['mysql', 'mariadb', 'postgresql', 'postgres', 'mongodb', 'redis', 'mssql']);
    const container = detectSoftware(data, ['docker', 'podman', 'containerd']);
    const security = system.security_stack || detectSoftware(data, ['selinux', 'apparmor', 'firewalld', 'ufw', 'defender']);

    // Build summary items
    const summaryItems = [
        { icon: '🐧', label: 'Operating System', value: osName },
        { icon: '📦', label: 'Packages', value: `${packagesCount} installed${updatesCount > 0 ? `, ${updatesCount} updates available` : ''}` },
        { icon: '⚙️', label: 'Services', value: `${servicesCount} running` }
    ];

    if (webServer) summaryItems.push({ icon: '🌐', label: 'Web Server', value: webServer });
    if (database) summaryItems.push({ icon: '🗄️', label: 'Database', value: database });
    if (container) summaryItems.push({ icon: '🐳', label: 'Containers', value: container });
    if (security) summaryItems.push({ icon: '🔒', label: 'Security', value: security });

    // Render summary list
    summaryList.innerHTML = summaryItems.map(item => `
        <div class="wizard-discovery-summary-item">
            <span class="wizard-discovery-summary-item-icon">${item.icon}</span>
            <span class="wizard-discovery-summary-item-label">${escapeHtml(item.label)}</span>
            <span class="wizard-discovery-summary-item-value">${escapeHtml(item.value)}</span>
        </div>
    `).join('');

    // Update count
    if (summaryCount) {
        summaryCount.textContent = `${summaryItems.length} items detected`;
    }

    // Add toggle handler (remove old listener first)
    if (summaryToggle && !summaryToggle.hasAttribute('data-listener-attached')) {
        summaryToggle.setAttribute('data-listener-attached', 'true');
        summaryToggle.addEventListener('click', () => {
            const isCollapsed = summaryToggle.getAttribute('data-collapsed') === 'true';
            const icon = summaryToggle.querySelector('.wizard-discovery-summary-collapse-icon');

            if (isCollapsed) {
                summaryContent.style.display = '';
                icon.textContent = '▼';
                summaryToggle.setAttribute('data-collapsed', 'false');
            } else {
                summaryContent.style.display = 'none';
                icon.textContent = '▶';
                summaryToggle.setAttribute('data-collapsed', 'true');
            }
        });
    }
}

// Get detected software info for category badge
function getDetectedInfo(category, discoveryData) {
    if (!discoveryData) return null;

    const data = discoveryData;
    switch (category) {
        case 'Platform':
            return data.system?.os_pretty_name || data.os_info?.distro || null;
        case 'Web Server':
            return detectSoftware(data, ['nginx', 'apache', 'httpd', 'iis']) ? `Detected: ${detectSoftware(data, ['nginx', 'apache', 'httpd', 'iis'])}` : null;
        case 'Database':
            return detectSoftware(data, ['mysql', 'postgresql', 'mongodb', 'redis', 'mssql']) ? `Detected: ${detectSoftware(data, ['mysql', 'postgresql', 'mongodb', 'redis', 'mssql'])}` : null;
        case 'Containers':
            return detectSoftware(data, ['docker', 'podman', 'containerd']) ? `Detected: ${detectSoftware(data, ['docker', 'podman', 'containerd'])}` : null;
        case 'Infrastructure':
            return detectSoftware(data, ['hyper-v', 'vmms', 'libvirtd', 'ntds']) ? `Detected: ${detectSoftware(data, ['hyper-v', 'vmms', 'libvirtd', 'ntds'])}` : null;
        default:
            return null;
    }
}

// ============================================
// Run Summary
// ============================================
function updateRunSummary() {
    const serversEl = document.getElementById('wizard-summary-servers');
    const auditsEl = document.getElementById('wizard-summary-audits');

    if (serversEl) serversEl.textContent = wizardState.selectedServers.length;
    if (auditsEl) auditsEl.textContent = wizardState.selectedAudits.length;
}

// ============================================
// Execute Audit
// ============================================
async function executeWizardAudit() {
    const executeBtn = document.getElementById('wizard-execute-btn');
    const progressContainer = document.getElementById('wizard-progress-container');
    const progressFill = document.getElementById('wizard-progress-fill');
    const progressText = document.getElementById('wizard-progress-text');
    const statusEl = document.getElementById('wizard-summary-status');

    if (wizardState.selectedServers.length === 0) {
        alert('Please select at least one server');
        return;
    }

    if (wizardState.selectedAudits.length === 0) {
        alert('Please select at least one audit');
        return;
    }

    // Save as plan if checkbox is checked
    const saveAsPlanCheckbox = document.getElementById('wizard-save-as-plan');
    if (saveAsPlanCheckbox && saveAsPlanCheckbox.checked) {
        const planName = document.getElementById('wizard-inline-plan-name')?.value.trim();
        if (planName) {
            const planDesc = document.getElementById('wizard-inline-plan-desc')?.value.trim() || '';
            await saveWizardPlanQuiet(planName, planDesc);
        }
    }

    // Update UI
    executeBtn.disabled = true;
    executeBtn.textContent = '⏳ Running...';
    progressContainer.style.display = 'block';
    statusEl.textContent = 'Running';

    // Simulate progress (in real implementation, poll the execution status)
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);

            // Complete
            executeBtn.disabled = false;
            executeBtn.textContent = '✅ Complete';
            statusEl.textContent = 'Complete';

            // Mark steps as completed
            document.querySelector('.wizard-nav-item[data-step="run"]').classList.add('completed');

            // Auto-advance to results
            setTimeout(() => {
                goToWizardStep('review');
            }, 1000);
        }

        progressFill.style.width = progress + '%';
        progressText.textContent = Math.round(progress) + '%';
    }, 300);
}

// Silent plan save (no alerts)
async function saveWizardPlanQuiet(name, description) {
    const planData = {
        name: name,
        description: description,
        paths: wizardState.selectedAudits,
        servers: wizardState.selectedServers,
        options: {
            parallel: document.getElementById('wizard-parallel')?.checked ?? true,
            saveResults: document.getElementById('wizard-save-results')?.checked ?? true,
            notify: document.getElementById('wizard-notify')?.checked ?? false,
            executionMode: getWizardExecutionMode()
        }
    };

    try {
        await wizardFetch('/api/plans/save', {
            method: 'POST',
            body: JSON.stringify(planData)
        });
        wizardLog('Wizard: Plan saved as "' + name + '"');
    } catch (error) {
        console.error('Wizard: Error saving plan:', error);
    }
}

// ============================================
// Restart Wizard
// ============================================
function restartWizard() {
    // Reset state
    wizardState.selectedServers = [];
    wizardState.selectedAudits = [];
    wizardState.newServer = null;
    wizardState.saveAsPlan = false;

    // Reset UI
    document.querySelectorAll('.wizard-server-item, .wizard-audit-item').forEach(item => {
        item.classList.remove('selected');
        const checkbox = item.querySelector('input[type="checkbox"]');
        if (checkbox) checkbox.checked = false;
    });

    document.querySelectorAll('.wizard-nav-item').forEach(item => {
        item.classList.remove('completed');
    });

    // Reset connect form
    const connectFields = ['wizard-server-name', 'wizard-server-host', 'wizard-server-desc',
                           'wizard-server-user', 'wizard-server-password', 'wizard-server-key'];
    connectFields.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    const portEl = document.getElementById('wizard-server-port');
    if (portEl) portEl.value = '22';
    const testStatus = document.getElementById('wizard-test-status');
    if (testStatus) testStatus.textContent = '';

    // Reset plan toggle
    const saveAsPlanCheckbox = document.getElementById('wizard-save-as-plan');
    if (saveAsPlanCheckbox) saveAsPlanCheckbox.checked = false;
    const planForm = document.getElementById('wizard-plan-form');
    if (planForm) planForm.style.display = 'none';
    const inlinePlanName = document.getElementById('wizard-inline-plan-name');
    if (inlinePlanName) inlinePlanName.value = '';
    const inlinePlanDesc = document.getElementById('wizard-inline-plan-desc');
    if (inlinePlanDesc) inlinePlanDesc.value = '';

    updateServerSelection();
    updateAuditSelection();

    const executeBtn = document.getElementById('wizard-execute-btn');
    if (executeBtn) {
        executeBtn.disabled = false;
        executeBtn.textContent = '▶️ Execute Audit';
    }

    const progressContainer = document.getElementById('wizard-progress-container');
    if (progressContainer) {
        progressContainer.style.display = 'none';
    }

    const statusEl = document.getElementById('wizard-summary-status');
    if (statusEl) statusEl.textContent = 'Ready';

    // Go to first step based on mode
    const firstStep = wizardState.mode === 'new' ? 'connect' : 'servers';
    wizardState.currentStep = firstStep;
    goToWizardStep(firstStep);
}

// ============================================
// Plan Management
// ============================================
async function loadWizardPlans() {
    const planSelect = document.getElementById('wizard-plan-select');
    if (!planSelect) return;

    try {
        const response = await wizardFetch('/api/plans');
        if (!response.ok) throw new Error('Failed to load plans');

        const data = await response.json();
        const plans = data.plans || [];

        // Clear and populate dropdown
        planSelect.innerHTML = '<option value="">-- Select a plan --</option>';
        plans.forEach(plan => {
            const option = document.createElement('option');
            option.value = plan.path || plan.name;
            option.textContent = `${plan.name} (${plan.audits ? plan.audits.length : 0} audits)`;
            option.dataset.plan = JSON.stringify(plan);
            planSelect.appendChild(option);
        });

        // Enable/disable load button based on selection
        planSelect.addEventListener('change', () => {
            const loadBtn = document.getElementById('wizard-load-plan-btn');
            if (loadBtn) {
                loadBtn.disabled = !planSelect.value;
            }
        });

    } catch (error) {
        console.error('Error loading plans:', error);
    }
}

function setupWizardPlanHandlers() {
    // Load plan button
    const loadBtn = document.getElementById('wizard-load-plan-btn');
    if (loadBtn) {
        loadBtn.addEventListener('click', loadWizardPlan);
    }

    // Save plan button - opens modal
    const saveBtn = document.getElementById('wizard-save-plan-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', showWizardSavePlanModal);
    }

    // Modal confirm save
    const confirmBtn = document.getElementById('wizard-confirm-save-plan');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', saveWizardPlan);
    }

    // Modal cancel/close
    const cancelBtn = document.getElementById('wizard-cancel-save-plan');
    const closeBtn = document.getElementById('wizard-save-plan-close');
    if (cancelBtn) cancelBtn.addEventListener('click', hideWizardSavePlanModal);
    if (closeBtn) closeBtn.addEventListener('click', hideWizardSavePlanModal);

    // Close modal on backdrop click
    const modal = document.getElementById('wizard-save-plan-modal');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) hideWizardSavePlanModal();
        });
    }
}

async function loadWizardPlan() {
    const planSelect = document.getElementById('wizard-plan-select');
    const selectedOption = planSelect.options[planSelect.selectedIndex];

    if (!selectedOption || !selectedOption.dataset.plan) {
        alert('Please select a plan to load');
        return;
    }

    try {
        const plan = JSON.parse(selectedOption.dataset.plan);

        // Apply audits from plan
        if (plan.audits && plan.audits.length > 0) {
            // Clear current selections
            document.querySelectorAll('#wizard-audit-list .wizard-audit-item').forEach(item => {
                item.classList.remove('selected');
                const checkbox = item.querySelector('input[type="checkbox"]');
                if (checkbox) checkbox.checked = false;
            });

            // Select matching audits
            plan.audits.forEach(auditPath => {
                const auditItem = document.querySelector(`#wizard-audit-list .wizard-audit-item[data-audit-id="${auditPath}"]`);
                if (auditItem) {
                    auditItem.classList.add('selected');
                    const checkbox = auditItem.querySelector('input[type="checkbox"]');
                    if (checkbox) checkbox.checked = true;
                }
            });

            updateAuditSelection();
        }

        // Apply options if stored in plan
        if (plan.options) {
            if (plan.options.parallel !== undefined) {
                document.getElementById('wizard-parallel').checked = plan.options.parallel;
            }
            if (plan.options.saveResults !== undefined) {
                document.getElementById('wizard-save-results').checked = plan.options.saveResults;
            }
            if (plan.options.notify !== undefined) {
                document.getElementById('wizard-notify').checked = plan.options.notify;
            }
        }

        alert(`Plan "${plan.name}" loaded successfully!`);

    } catch (error) {
        console.error('Error loading plan:', error);
        alert('Error loading plan: ' + error.message);
    }
}

function showWizardSavePlanModal() {
    const modal = document.getElementById('wizard-save-plan-modal');
    if (!modal) return;

    // Update summary counts
    document.getElementById('wizard-modal-servers').textContent = wizardState.selectedServers.length;
    document.getElementById('wizard-modal-audits').textContent = wizardState.selectedAudits.length;
    document.getElementById('wizard-modal-parallel').textContent =
        document.getElementById('wizard-parallel')?.checked ? 'Yes' : 'No';
    document.getElementById('wizard-modal-notify').textContent =
        document.getElementById('wizard-notify')?.checked ? 'Yes' : 'No';

    // Clear previous input
    document.getElementById('wizard-plan-name').value = '';
    document.getElementById('wizard-plan-description').value = '';

    modal.classList.add('active');
    document.getElementById('wizard-plan-name').focus();
}

function hideWizardSavePlanModal() {
    const modal = document.getElementById('wizard-save-plan-modal');
    if (modal) modal.classList.remove('active');
}

async function saveWizardPlan() {
    const name = document.getElementById('wizard-plan-name').value.trim();
    const description = document.getElementById('wizard-plan-description').value.trim();

    if (!name) {
        alert('Please enter a plan name');
        document.getElementById('wizard-plan-name').focus();
        return;
    }

    if (wizardState.selectedAudits.length === 0) {
        alert('Please select at least one audit before saving');
        return;
    }

    const planData = {
        name: name,
        description: description,
        paths: wizardState.selectedAudits,
        servers: wizardState.selectedServers,
        options: {
            parallel: document.getElementById('wizard-parallel')?.checked ?? true,
            saveResults: document.getElementById('wizard-save-results')?.checked ?? true,
            notify: document.getElementById('wizard-notify')?.checked ?? false,
            executionMode: getWizardExecutionMode()
        }
    };

    try {
        const response = await wizardFetch('/api/plans/save', {
            method: 'POST',
            body: JSON.stringify(planData)
        });

        const data = await response.json();

        if (data.success) {
            alert(`Plan "${name}" saved successfully!`);
            hideWizardSavePlanModal();
            loadWizardPlans(); // Refresh the dropdown
        } else {
            alert('Failed to save plan: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error saving plan:', error);
        alert('Error saving plan: ' + error.message);
    }
}

// ============================================
// Utility
// ============================================
// Note: escapeHtml is defined at top of file in Security Helpers section

function getDomainIcon(domain) {
    const icons = {
        'platform': '🖥️',
        'linux': '🐧',
        'windows': '🪟',
        'web': '🌐',
        'network': '📡',
        'database': '🗄️',
        'data': '💾',
        'storage': '📦',
        'apps': '📱',
        'automation': '⚙️',
        'container': '🐳',
        'security': '🔒',
        'general': '📋'
    };
    return icons[domain.toLowerCase()] || '📋';
}

// ============================================
// Schedule Step Functions
// ============================================

function setupWizardScheduleStep() {
    // Mode selector (Run Now vs Schedule)
    const modeInputs = document.querySelectorAll('input[name="wizard-schedule-mode"]');
    modeInputs.forEach(input => {
        input.addEventListener('change', () => {
            const config = document.getElementById('wizard-schedule-config');
            if (input.value === 'schedule') {
                config.style.display = 'block';
                populateScheduleServerList();
                updateSchedulePreview();
            } else {
                config.style.display = 'none';
            }
            updateScheduleActionButton();
        });
    });

    // Frequency change handler
    const frequencySelect = document.getElementById('wizard-schedule-frequency');
    if (frequencySelect) {
        frequencySelect.addEventListener('change', () => {
            updateScheduleFormFields();
            updateSchedulePreview();
        });
    }

    // Time change handler
    const timeInput = document.getElementById('wizard-schedule-time');
    if (timeInput) {
        timeInput.addEventListener('change', updateSchedulePreview);
    }

    // Day change handler
    const daySelect = document.getElementById('wizard-schedule-day');
    if (daySelect) {
        daySelect.addEventListener('change', updateSchedulePreview);
    }

    // Month day change handler
    const monthDaySelect = document.getElementById('wizard-schedule-monthday');
    if (monthDaySelect) {
        monthDaySelect.addEventListener('change', updateSchedulePreview);
    }

    // Cron input handler
    const cronInput = document.getElementById('wizard-schedule-cron');
    if (cronInput) {
        cronInput.addEventListener('input', updateSchedulePreview);
    }

    // Email notification toggle
    const emailCheckbox = document.getElementById('wizard-schedule-notify-email');
    if (emailCheckbox) {
        emailCheckbox.addEventListener('change', () => {
            const emailGroup = document.getElementById('wizard-schedule-email-group');
            emailGroup.style.display = emailCheckbox.checked ? 'block' : 'none';
        });
    }

    // Server selection controls
    const selectAllBtn = document.getElementById('wizard-schedule-select-all');
    if (selectAllBtn) {
        selectAllBtn.addEventListener('click', () => selectAllScheduleServers(true));
    }

    const deselectAllBtn = document.getElementById('wizard-schedule-deselect-all');
    if (deselectAllBtn) {
        deselectAllBtn.addEventListener('click', () => selectAllScheduleServers(false));
    }

    // Action button handler
    const actionBtn = document.getElementById('wizard-schedule-action-btn');
    if (actionBtn) {
        actionBtn.addEventListener('click', handleScheduleAction);
    }

    // Skip schedule button handler - allows running audits manually without scheduling
    const skipBtn = document.getElementById('wizard-skip-schedule-btn');
    if (skipBtn) {
        skipBtn.addEventListener('click', () => {
            // Ensure "Run Now" mode is selected (no schedule will be created)
            const runNowRadio = document.getElementById('wizard-mode-run-now');
            if (runNowRadio) {
                runNowRadio.checked = true;
            }
            // Navigate directly to the run step
            navigateWizardStep('run');
        });
    }

    // Set default start date to today
    const startDateInput = document.getElementById('wizard-schedule-start-date');
    if (startDateInput) {
        startDateInput.value = new Date().toISOString().split('T')[0];
    }
}

function populateScheduleServerList() {
    const container = document.getElementById('wizard-schedule-server-list');
    if (!container) return;

    // Get servers from wizard state or fetch from API
    const servers = wizardState.selectedServers || [];

    if (servers.length === 0) {
        // Try to get all connected servers
        wizardFetch('/api/servers')
            .then(response => response.json())
            .then(data => {
                const allServers = data.servers || [];
                renderScheduleServers(container, allServers);
            })
            .catch(() => {
                container.innerHTML = '<div class="wizard-empty">No servers available</div>';
            });
    } else {
        // Use already selected servers
        renderScheduleServers(container, servers);
    }
}

function renderScheduleServers(container, servers) {
    if (servers.length === 0) {
        container.innerHTML = '<div class="wizard-empty">No servers available</div>';
        return;
    }

    container.innerHTML = servers.map(server => {
        const id = server.id || server.name;
        const name = server.name || server.hostname || id;
        const os = server.os || 'linux';
        const osIcon = os.toLowerCase() === 'windows' ? '🪟' : '🐧';

        return `
            <div class="wizard-schedule-server-item" data-server-id="${escapeHtml(id)}">
                <input type="checkbox" id="schedule-server-${escapeHtml(id)}" checked>
                <label for="schedule-server-${escapeHtml(id)}" class="wizard-schedule-server-name">${escapeHtml(name)}</label>
                <span class="wizard-schedule-server-os">${osIcon}</span>
            </div>
        `;
    }).join('');

    // Add click handlers for selection
    container.querySelectorAll('.wizard-schedule-server-item').forEach(item => {
        item.addEventListener('click', (e) => {
            if (e.target.tagName !== 'INPUT') {
                const checkbox = item.querySelector('input[type="checkbox"]');
                checkbox.checked = !checkbox.checked;
            }
            item.classList.toggle('selected', item.querySelector('input').checked);
            updateSchedulePreview();
        });

        // Initialize selected state
        if (item.querySelector('input').checked) {
            item.classList.add('selected');
        }
    });

    updateSchedulePreview();
}

function selectAllScheduleServers(select) {
    const container = document.getElementById('wizard-schedule-server-list');
    container.querySelectorAll('.wizard-schedule-server-item').forEach(item => {
        const checkbox = item.querySelector('input[type="checkbox"]');
        checkbox.checked = select;
        item.classList.toggle('selected', select);
    });
    updateSchedulePreview();
}

function updateScheduleFormFields() {
    const frequency = document.getElementById('wizard-schedule-frequency').value;

    const timeGroup = document.getElementById('wizard-schedule-time-group');
    const dayGroup = document.getElementById('wizard-schedule-day-group');
    const monthDayGroup = document.getElementById('wizard-schedule-monthday-group');
    const cronGroup = document.getElementById('wizard-schedule-cron-group');

    // Hide all optional groups first
    dayGroup.style.display = 'none';
    monthDayGroup.style.display = 'none';
    cronGroup.style.display = 'none';
    timeGroup.style.display = 'block';

    switch (frequency) {
        case 'hourly':
            timeGroup.style.display = 'none';
            break;
        case 'daily':
            // Just time, already shown
            break;
        case 'weekly':
            dayGroup.style.display = 'block';
            break;
        case 'monthly':
            monthDayGroup.style.display = 'block';
            break;
        case 'custom':
            timeGroup.style.display = 'none';
            cronGroup.style.display = 'block';
            break;
    }
}

function updateSchedulePreview() {
    // Update servers count
    const serverItems = document.querySelectorAll('#wizard-schedule-server-list .wizard-schedule-server-item input:checked');
    document.getElementById('wizard-preview-servers').textContent = `${serverItems.length} selected`;

    // Update audits count
    const auditCount = wizardState.selectedAudits?.length || 0;
    document.getElementById('wizard-preview-audits').textContent = `${auditCount} selected`;

    // Update frequency description
    const frequency = document.getElementById('wizard-schedule-frequency').value;
    const time = document.getElementById('wizard-schedule-time').value || '02:00';
    const day = document.getElementById('wizard-schedule-day');
    const monthDay = document.getElementById('wizard-schedule-monthday');
    const cron = document.getElementById('wizard-schedule-cron').value;

    let freqDesc = '';
    switch (frequency) {
        case 'hourly':
            freqDesc = 'Every hour';
            break;
        case 'daily':
            freqDesc = `Daily at ${time}`;
            break;
        case 'weekly':
            const dayName = day.options[day.selectedIndex].text;
            freqDesc = `Weekly on ${dayName} at ${time}`;
            break;
        case 'monthly':
            const monthDayText = monthDay.options[monthDay.selectedIndex].text;
            freqDesc = `Monthly on the ${monthDayText} at ${time}`;
            break;
        case 'custom':
            freqDesc = cron ? `Cron: ${cron}` : 'Custom schedule';
            break;
    }
    document.getElementById('wizard-preview-frequency').textContent = freqDesc;

    // Calculate next run
    const nextRun = calculateNextRun(frequency, time, day?.value, monthDay?.value);
    document.getElementById('wizard-preview-next-run').textContent = nextRun;
}

function calculateNextRun(frequency, time, day, monthDay) {
    const now = new Date();
    const [hours, minutes] = time.split(':').map(Number);
    let next = new Date();

    switch (frequency) {
        case 'hourly':
            next.setHours(next.getHours() + 1, 0, 0, 0);
            break;
        case 'daily':
            next.setHours(hours, minutes, 0, 0);
            if (next <= now) next.setDate(next.getDate() + 1);
            break;
        case 'weekly':
            const targetDay = parseInt(day);
            const currentDay = next.getDay();
            let daysUntil = targetDay - currentDay;
            if (daysUntil < 0) daysUntil += 7;
            if (daysUntil === 0) {
                next.setHours(hours, minutes, 0, 0);
                if (next <= now) daysUntil = 7;
            }
            if (daysUntil > 0) {
                next.setDate(next.getDate() + daysUntil);
            }
            next.setHours(hours, minutes, 0, 0);
            break;
        case 'monthly':
            if (monthDay === 'L') {
                next = new Date(next.getFullYear(), next.getMonth() + 1, 0);
            } else {
                next.setDate(parseInt(monthDay));
            }
            next.setHours(hours, minutes, 0, 0);
            if (next <= now) {
                next.setMonth(next.getMonth() + 1);
            }
            break;
        case 'custom':
            return 'Calculated from cron';
    }

    return next.toLocaleString();
}

function updateScheduleActionButton() {
    const btn = document.getElementById('wizard-schedule-action-btn');
    const mode = document.querySelector('input[name="wizard-schedule-mode"]:checked')?.value;

    if (mode === 'schedule') {
        btn.textContent = '📅 Create Schedule';
        btn.className = 'btn btn-primary';
    } else {
        btn.textContent = 'Continue to Run →';
        btn.className = 'btn btn-primary';
    }
}

async function handleScheduleAction() {
    const mode = document.querySelector('input[name="wizard-schedule-mode"]:checked')?.value;

    if (mode === 'schedule') {
        await createWizardSchedule();
    } else {
        // Navigate to run step
        navigateWizardStep('run');
    }
}

async function createWizardSchedule() {
    const name = document.getElementById('wizard-schedule-name').value.trim();

    if (!name) {
        alert('Please enter a schedule name');
        return;
    }

    // Get selected servers
    const selectedServers = [];
    document.querySelectorAll('#wizard-schedule-server-list .wizard-schedule-server-item input:checked').forEach(checkbox => {
        selectedServers.push(checkbox.closest('.wizard-schedule-server-item').dataset.serverId);
    });

    if (selectedServers.length === 0) {
        alert('Please select at least one server');
        return;
    }

    // Get selected audits
    const selectedAudits = wizardState.selectedAudits || [];
    if (selectedAudits.length === 0) {
        alert('No audits selected. Please go back and select audits.');
        return;
    }

    // Build cron expression
    const cronExpression = buildCronExpression();

    // Build schedule data
    const scheduleData = {
        name: name,
        server_ids: selectedServers,
        audit_paths: selectedAudits,
        cron_schedule: cronExpression,
        is_active: true,
        notification_enabled: document.getElementById('wizard-schedule-notify-email')?.checked || false,
        notification_emails: document.getElementById('wizard-schedule-emails')?.value || '',
        start_date: document.getElementById('wizard-schedule-start-date')?.value || null,
        execution_mode: getWizardExecutionMode()  // Include execution mode from Step 5
    };

    try {
        const response = await wizardFetch('/api/v2/schedules', {
            method: 'POST',
            body: JSON.stringify(scheduleData)
        });

        const data = await response.json();

        if (data.success) {
            alert(`Schedule "${name}" created successfully!\n\nNext run: ${data.next_run || 'Pending'}`);

            // Option to view schedules or continue
            if (confirm('Would you like to view the Schedule tab?')) {
                // Navigate to schedule tab
                const scheduleTab = document.querySelector('.tab-button[data-tab="schedule"]');
                if (scheduleTab) scheduleTab.click();
            }
        } else {
            alert('Failed to create schedule: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error creating schedule:', error);
        alert('Error creating schedule: ' + error.message);
    }
}

function buildCronExpression() {
    const frequency = document.getElementById('wizard-schedule-frequency').value;
    const time = document.getElementById('wizard-schedule-time').value || '02:00';
    const [hours, minutes] = time.split(':').map(Number);

    switch (frequency) {
        case 'hourly':
            return '0 * * * *';
        case 'daily':
            return `${minutes} ${hours} * * *`;
        case 'weekly':
            const day = document.getElementById('wizard-schedule-day').value;
            return `${minutes} ${hours} * * ${day}`;
        case 'monthly':
            const monthDay = document.getElementById('wizard-schedule-monthday').value;
            if (monthDay === 'L') {
                return `${minutes} ${hours} L * *`;
            }
            return `${minutes} ${hours} ${monthDay} * *`;
        case 'custom':
            return document.getElementById('wizard-schedule-cron').value || '0 2 * * *';
        default:
            return '0 2 * * *';
    }
}

function navigateWizardStep(stepName) {
    // Activate the step nav item
    document.querySelectorAll('.wizard-nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.step === stepName) {
            item.classList.add('active');
        }
    });

    // Show the step content
    document.querySelectorAll('.wizard-step').forEach(step => {
        step.classList.remove('active');
        step.style.display = 'none';
    });

    const targetStep = document.getElementById('wizard-step-' + stepName);
    if (targetStep) {
        targetStep.classList.add('active');
        targetStep.style.display = 'flex';
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', initWizard);
