// Security Audit Toolkit - Web UI JavaScript

const API_BASE = '';

// ============================================================================
// POLLING CONFIGURATION
// Adjust these values to balance responsiveness vs. API rate limit usage
// Lower values = more responsive but higher API usage
// Higher values = less responsive but lower API usage
// ============================================================================
const POLLING_CONFIG = {
    // Background monitoring status poll (ms) - checks if monitoring is running
    MONITORING_STATUS: 15000,  // 15 seconds (was 5s)

    // Execution status poll during audit runs (ms) - updates output display
    EXECUTION_STATUS: 3000,    // 3 seconds (was 1s)

    // Deployment status poll during server deployments (ms)
    DEPLOYMENT_STATUS: 3000,   // 3 seconds (was 1s)
};

let allAudits = [];
let selectedAudits = new Set();
let executionPolling = null;
let deploymentPolling = null;
let selectedServers = new Set();
let discoveryRecommendations = [];
let currentTheme = localStorage.getItem('theme') || 'light';
let cachedDeployServers = [];  // Cache servers for filtering
let deployServerSearchFilter = '';

/**
 * Wrapper for fetch that includes session credentials by default
 * This ensures the Flask session cookie is sent with all API requests
 * @param {string} url - URL to fetch
 * @param {object} options - Fetch options (optional)
 * @returns {Promise<Response>} Fetch response
 */
async function apiFetch(url, options = {}) {
    // Always include credentials for session cookie support
    const defaultOptions = {
        credentials: 'include'
    };
    return fetch(url, { ...defaultOptions, ...options });
}

/**
 * Escape HTML special characters to prevent XSS attacks
 * @param {string} str - Input string
 * @returns {string} Escaped string safe for innerHTML
 */
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
}

/**
 * Debounce function to limit how often a function can be called
 * @param {Function} func - Function to debounce
 * @param {number} wait - Milliseconds to wait
 * @returns {Function} Debounced function
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initTabs();
    initButtons();
    loadAudits();
    loadPresets();
    loadPlans();
    loadLogs();
    loadServers();
    loadSettings();
    initDeployTypeSelector();
    initDeployModeSelector();

    // Initialize JRE agent config
    const jreAgentModeSelector = document.getElementById('deploy-jre-agent-mode');
    if (jreAgentModeSelector) {
        jreAgentModeSelector.addEventListener('change', (e) => updateJREAgentConfig(e.target.value));
        // Set initial state
        updateJREAgentConfig(jreAgentModeSelector.value);
    }

    // Handle schedule checkbox visibility
    const scheduleCheckbox = document.getElementById('deploy-agent-setup-schedule');
    if (scheduleCheckbox) {
        scheduleCheckbox.addEventListener('change', function() {
            const scheduleTimeGroup = document.querySelector('.schedule-time-group');
            if (scheduleTimeGroup) {
                scheduleTimeGroup.style.display = this.checked ? 'block' : 'none';
            }
        });
    }
});

// Tab Management
function initTabs() {
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabName = button.dataset.tab;
            switchTab(tabName);
        });
    });
}

function switchTab(tabName) {
    // Update buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabName);
    });

    // Update content - must set inline style because index-tabs.js uses inline styles
    document.querySelectorAll('.tab-content').forEach(content => {
        const isActive = content.id === `${tabName}-tab`;
        content.classList.toggle('active', isActive);
        content.style.display = isActive ? 'block' : 'none';
    });

    // Refresh data when switching tabs
    if (tabName === 'logs') loadLogs();
    if (tabName === 'plans') loadPlans();
    if (tabName === 'execution') checkExecutionStatus();
    if (tabName === 'deploy') loadServers();
    if (tabName === 'reports') { loadReportServers(); loadHealthReport(); loadReportingBackfillHistory(); }
    if (tabName === 'history') loadHistory();
    if (tabName === 'schedule') loadSchedules();
}

// Safe event listener helper - prevents errors if element doesn't exist
// Silently skips missing elements (they may be optional/page-specific)
function safeAddListener(id, event, handler) {
    const el = document.getElementById(id);
    if (el) {
        el.addEventListener(event, handler);
        return true;
    }
    return false;
}

// Button Handlers
function initButtons() {
        // Execution export buttons
        safeAddListener('export-exec-html', 'click', () => exportExec('html'));
        safeAddListener('export-exec-csv', 'click', () => exportExec('csv'));
        safeAddListener('export-exec-json', 'click', () => exportExec('json'));
        // History export buttons
        safeAddListener('export-history-html', 'click', () => exportHistory('html'));
        safeAddListener('export-history-csv', 'click', () => exportHistory('csv'));
        safeAddListener('export-history-json', 'click', () => exportHistory('json'));
            // Monitoring controls
            const monitoringToggle = document.getElementById('monitoring-toggle');
            const monitoringInterval = document.getElementById('monitoring-interval');
            const monitoringConfig = document.getElementById('monitoring-config');
            const monitoringStatus = document.getElementById('monitoring-status');
            if (monitoringToggle) {
                monitoringToggle.addEventListener('click', () => {
                    if (monitoringToggle.textContent === 'Start Monitoring') {
                        apiFetch(`${API_BASE}/api/monitoring/start`, { method: 'POST' })
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    monitoringToggle.textContent = 'Stop Monitoring';
                                    monitoringStatus.textContent = 'Running';
                                }
                            });
                    } else {
                        apiFetch(`${API_BASE}/api/monitoring/stop`, { method: 'POST' })
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    monitoringToggle.textContent = 'Start Monitoring';
                                    monitoringStatus.textContent = 'Stopped';
                                }
                            });
                    }
                });
                monitoringInterval.addEventListener('change', () => {
                    apiFetch(`${API_BASE}/api/monitoring/config`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ interval: monitoringInterval.value, config: monitoringConfig.value })
                    });
                });
                monitoringConfig.addEventListener('change', () => {
                    apiFetch(`${API_BASE}/api/monitoring/config`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ interval: monitoringInterval.value, config: monitoringConfig.value })
                    });
                });
                // Poll status
                setInterval(() => {
                    apiFetch(`${API_BASE}/api/monitoring/status`)
                        .then(res => res.json())
                        .then(data => {
                            monitoringStatus.textContent = data.enabled ? 'Running' : 'Stopped';
                            monitoringToggle.textContent = data.enabled ? 'Stop Monitoring' : 'Start Monitoring';
                            monitoringInterval.value = data.interval;
                        });
                }, POLLING_CONFIG.MONITORING_STATUS);
            }
    // Export Execution Output
    function exportExec(format) {
        const output = document.getElementById('output-display').textContent;
        apiFetch(`${API_BASE}/api/reports/export`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-API-Key': window.API_KEY || '' },
            body: JSON.stringify({ report: { output }, format })
        })
        .then(res => res.blob())
        .then(blob => {
            const filename = `execution-output.${format}`;
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            link.click();
        });
    }

    // Export History Output
    function exportHistory(format) {
        apiFetch(`${API_BASE}/api/history`, {
            method: 'GET',
            headers: { 'X-API-Key': window.API_KEY || '' }
        })
        .then(res => res.json())
        .then(data => {
            let blob, filename;
            if (format === 'html') {
                blob = new Blob([`<pre>${JSON.stringify(data, null, 2)}</pre>`], {type: 'text/html'});
                filename = 'audit-history.html';
            } else if (format === 'csv') {
                // Convert JSON to CSV
                let csv = 'ID,Timestamp,Plan,Status,Audit Count,Pass,Warn,Fail\n';
                data.forEach(item => {
                    csv += `${item.id},${item.timestamp},${item.plan_name},${item.status},${item.audit_count},${item.pass_count},${item.warn_count},${item.fail_count}\n`;
                });
                blob = new Blob([csv], {type: 'text/csv'});
                filename = 'audit-history.csv';
            } else {
                blob = new Blob([JSON.stringify(data)], {type: 'application/json'});
                filename = 'audit-history.json';
            }
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            link.click();
        });
    }
    safeAddListener('select-all', 'click', selectAllAudits);
    safeAddListener('deselect-all', 'click', deselectAllAudits);
    safeAddListener('apply-preset', 'click', applyPreset);
    safeAddListener('os-filter', 'change', filterAudits);
    safeAddListener('domain-filter', 'change', filterAudits);
    safeAddListener('search-input', 'input', debounce(filterAudits, 300));
    safeAddListener('audits-list-search', 'input', debounce(filterAudits, 300));
    safeAddListener('run-selected', 'click', runSelectedAudits);
    safeAddListener('save-plan', 'click', showSavePlanModal);
    safeAddListener('confirm-save-plan', 'click', savePlan);
    safeAddListener('cancel-save-plan', 'click', hideSavePlanModal);
    safeAddListener('clear-output', 'click', clearOutput);
    safeAddListener('refresh-audits', 'click', loadAudits);
    safeAddListener('refresh-plans', 'click', loadPlans);
    safeAddListener('plans-search', 'input', debounce(filterPlans, 300));
    safeAddListener('refresh-schedules', 'click', loadSchedules);
    safeAddListener('schedules-list-search', 'input', debounce(filterSchedulesList, 300));
    // Schedule filter dropdowns
    safeAddListener('schedule-filter-source', 'change', filterSchedulesList);
    safeAddListener('schedule-filter-frequency', 'change', filterSchedulesList);
    safeAddListener('schedule-filter-status', 'change', filterSchedulesList);
    safeAddListener('schedule-filter-target', 'change', filterSchedulesList);
    safeAddListener('schedule-filter-clear', 'click', clearScheduleFilters);
    safeAddListener('schedule-select-all', 'change', (event) => setAllScheduleSelection(event.target.checked));
    safeAddListener('schedule-delete-selected', 'click', deleteSelectedSchedules);
    safeAddListener('schedule-clear-selection', 'click', clearAllScheduleSelection);

    // Git update buttons
    safeAddListener('check-git-updates', 'click', checkGitUpdates);
    safeAddListener('pull-git-updates', 'click', pullGitUpdates);

    // Discovery tab buttons
    safeAddListener('run-discovery', 'click', runDiscovery);
    safeAddListener('clear-discovery-output', 'click', clearDiscoveryOutput);
    safeAddListener('apply-discovery-recommendations', 'click', applyDiscoveryRecommendations);
    safeAddListener('update-audit-scripts', 'click', updateAuditScripts);
    // Update Audit Scripts Handler
    async function updateAuditScripts() {
        const btn = document.getElementById('update-audit-scripts');
        btn.disabled = true;
        btn.textContent = '⏫ Updating...';
        try {
            const response = await apiFetch(`${API_BASE}/api/audits/update`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-Key': window.API_KEY || ''
                }
            });
            const result = await response.json();
            if (result.success) {
                showDiscoveryStatus('success', result.message);
                showDiscoveryOutput(result.output || 'Audit scripts updated successfully.');
            } else {
                showDiscoveryStatus('error', result.error || 'Update failed.');
                showDiscoveryOutput(result.output || result.error || 'Update failed.');
            }
        } catch (err) {
            showDiscoveryStatus('error', 'Update failed: ' + err);
            showDiscoveryOutput('Update failed: ' + err);
        }
        btn.disabled = false;
        btn.textContent = '⏫ Update Audit Scripts';
    }

    function showDiscoveryStatus(type, message) {
        const statusDiv = document.getElementById('discovery-status');
        const badge = document.getElementById('discovery-status-badge');
        statusDiv.style.display = 'block';
        badge.textContent = message;
        badge.className = 'status-badge status-' + type;
    }

    function showDiscoveryOutput(output) {
        const outputDisplay = document.getElementById('discovery-output-display');
        outputDisplay.textContent = output;
    }

    // ========================================================================
    // Git-Based Audit Update Functions
    // ========================================================================

    /**
     * Check for available audit script updates from Git
     */
    async function checkGitUpdates() {
        const checkBtn = document.getElementById('check-git-updates');
        const pullBtn = document.getElementById('pull-git-updates');
        const statusBadge = document.getElementById('git-update-status');

        checkBtn.disabled = true;
        checkBtn.textContent = '🔄 Checking...';
        statusBadge.classList.add('d-none');
        pullBtn.classList.add('d-none');

        try {
            const response = await apiFetch(`${API_BASE}/api/audits/git/check`, {
                headers: { 'X-API-Key': window.API_KEY || '' }
            });
            const result = await response.json();

            if (result.success) {
                if (result.has_updates) {
                    // Show update available badge
                    statusBadge.textContent = `${result.total_changes} updates available`;
                    statusBadge.className = 'badge badge-warning';
                    statusBadge.classList.remove('d-none');

                    // Show pull button
                    pullBtn.classList.remove('d-none');
                    pullBtn.textContent = `⬇️ Pull ${result.total_changes} Updates`;

                    // Store update info for display
                    window.pendingGitUpdates = result;

                    // Log details
                    console.log('Git updates available:', result);
                    if (result.bash_scripts?.length) {
                        console.log('Bash scripts:', result.bash_scripts);
                    }
                    if (result.powershell_scripts?.length) {
                        console.log('PowerShell scripts:', result.powershell_scripts);
                    }
                } else {
                    statusBadge.textContent = '✓ Up to date';
                    statusBadge.className = 'badge badge-success';
                    statusBadge.classList.remove('d-none');

                    // Auto-hide after 3 seconds
                    setTimeout(() => {
                        statusBadge.classList.add('d-none');
                    }, 3000);
                }
            } else {
                statusBadge.textContent = result.error || 'Check failed';
                statusBadge.className = 'badge badge-error';
                statusBadge.classList.remove('d-none');
            }
        } catch (err) {
            console.error('Git check error:', err);
            statusBadge.textContent = 'Error checking updates';
            statusBadge.className = 'badge badge-error';
            statusBadge.classList.remove('d-none');
        }

        checkBtn.disabled = false;
        checkBtn.textContent = '📥 Check Updates';
    }

    /**
     * Pull audit script updates from Git repository
     */
    async function pullGitUpdates() {
        const pullBtn = document.getElementById('pull-git-updates');
        const statusBadge = document.getElementById('git-update-status');

        if (!confirm('Pull latest audit scripts from Git repository?\n\nThis will update Bash and PowerShell audit scripts.')) {
            return;
        }

        pullBtn.disabled = true;
        pullBtn.textContent = '⏳ Pulling...';

        try {
            const response = await apiFetch(`${API_BASE}/api/audits/git/pull`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-Key': window.API_KEY || ''
                },
                body: JSON.stringify({ force: false })
            });
            const result = await response.json();

            if (result.success) {
                statusBadge.textContent = result.message || 'Updated successfully';
                statusBadge.className = 'badge badge-success';

                // Show details if available
                if (result.updated_files?.length) {
                    console.log('Updated files:', result.updated_files);
                    alert(`✅ ${result.message}\n\nBash scripts: ${result.bash_scripts_updated || 0}\nPowerShell scripts: ${result.powershell_scripts_updated || 0}`);
                }

                // Hide pull button
                pullBtn.classList.add('d-none');

                // Refresh audit list
                await loadAudits();

                // Auto-hide status after 5 seconds
                setTimeout(() => {
                    statusBadge.classList.add('d-none');
                }, 5000);
            } else {
                statusBadge.textContent = result.message || 'Pull failed';
                statusBadge.className = 'badge badge-error';

                if (result.local_changes) {
                    alert('Local changes detected in audit scripts.\n\nCommit or discard local changes before pulling updates.');
                }
            }
        } catch (err) {
            console.error('Git pull error:', err);
            statusBadge.textContent = 'Pull failed';
            statusBadge.className = 'badge badge-error';
            alert('Failed to pull updates: ' + err.message);
        }

        pullBtn.disabled = false;
        pullBtn.textContent = '⬇️ Pull Updates';
    }

    // Deploy tab buttons
    document.getElementById('add-server-btn').addEventListener('click', showAddServerModal);
    document.getElementById('deploy-btn').addEventListener('click', deployToServers);
    document.getElementById('cleanup-btn').addEventListener('click', showCleanupConfirmModal);
    document.getElementById('cancel-add-server').addEventListener('click', hideAddServerModal);
    document.getElementById('server-form').addEventListener('submit', addServer);
    document.getElementById('server-auth').addEventListener('change', toggleAuthFields);
    document.getElementById('server-connection-method').addEventListener('change', toggleConnectionMethodFields);

    // Deploy tab additional buttons
    safeAddListener('select-all-deploy', 'click', () => {
        document.querySelectorAll('.deploy-server-row').forEach(row => {
            const serverId = parseInt(row.dataset.serverId, 10);
            selectedServers.add(serverId);
            row.classList.add('selected');
            const checkbox = row.querySelector('.deploy-server-checkbox');
            if (checkbox) checkbox.checked = true;
        });
        updateServerSelectionCount();
    });
    safeAddListener('deselect-all-deploy', 'click', () => {
        document.querySelectorAll('.deploy-server-row').forEach(row => {
            const serverId = parseInt(row.dataset.serverId, 10);
            selectedServers.delete(serverId);
            row.classList.remove('selected');
            const checkbox = row.querySelector('.deploy-server-checkbox');
            if (checkbox) checkbox.checked = false;
        });
        updateServerSelectionCount();
    });
    safeAddListener('refresh-deploy-servers', 'click', loadServers);
    safeAddListener('toggle-deploy-progress', 'click', () => {
        const body = document.getElementById('deploy-progress-body');
        if (body) body.classList.toggle('expanded');
    });

    // Cleanup confirmation modal
    document.getElementById('confirm-cleanup').addEventListener('click', cleanupServers);
    document.getElementById('cancel-cleanup').addEventListener('click', hideCleanupConfirmModal);

    // Reporting tab buttons
    document.getElementById('generate-report-btn').addEventListener('click', generateReport);
    document.getElementById('export-html-btn').addEventListener('click', () => exportReport('html'));
    document.getElementById('export-csv-btn').addEventListener('click', () => exportReport('csv'));
    document.getElementById('export-json-btn').addEventListener('click', () => exportReport('json'));
    document.getElementById('print-report-btn').addEventListener('click', printReport);
    document.getElementById('close-report-btn').addEventListener('click', closeReport);
    safeAddListener('refresh-reports', 'click', () => { loadReportServers(); loadHealthReport(); loadReportingBackfillHistory(); });
    safeAddListener('refresh-health-report', 'click', loadHealthReport);
    safeAddListener('refresh-reporting-backfill', 'click', loadReportingBackfillHistory);
    safeAddListener('reporting-backfill-success-filter', 'change', loadReportingBackfillHistory);
    safeAddListener('run-reporting-backfill', 'click', runReportingBackfill);

    // Theme and settings buttons
    document.getElementById('theme-toggle').addEventListener('click', toggleTheme);
    document.getElementById('settings-btn').addEventListener('click', showSettingsModal);
    document.getElementById('save-settings').addEventListener('click', saveSettings);
    document.getElementById('cancel-settings').addEventListener('click', hideSettingsModal);
    document.getElementById('email-enabled').addEventListener('change', toggleEmailConfig);
    document.getElementById('test-email').addEventListener('click', testEmail);
    document.getElementById('show-api-key').addEventListener('click', toggleApiKeyVisibility);
    document.getElementById('regenerate-api-key').addEventListener('click', regenerateApiKey);

    // History tab buttons
    document.getElementById('history-filter').addEventListener('change', filterHistory);
    document.getElementById('clear-history').addEventListener('click', clearAllHistory);
    safeAddListener('refresh-history', 'click', loadHistory);
    safeAddListener('history-search', 'input', debounce(loadHistory, 300));
    safeAddListener('history-list-search', 'input', debounce(loadHistory, 300));
    safeAddListener('history-date-from', 'change', loadHistory);
    safeAddListener('history-date-to', 'change', loadHistory);
    safeAddListener('history-source-filter', 'change', loadHistory);

    // Logs tab buttons
    safeAddListener('refresh-logs', 'click', loadLogs);
    safeAddListener('logs-search', 'input', debounce(loadLogs, 300));
    safeAddListener('logs-list-search', 'input', debounce(loadLogs, 300));
    safeAddListener('logs-sort', 'change', loadLogs);
    safeAddListener('logs-select-all', 'change', (event) => setAllLogSelection(event.target.checked));
    safeAddListener('logs-delete-selected', 'click', deleteSelectedLogs);
    safeAddListener('logs-deselect-all', 'click', clearAllLogSelection);
    safeAddListener('close-log', 'click', closeLogViewer);
    safeAddListener('download-log', 'click', () => { if (currentLogName) downloadLog(currentLogName); });
    safeAddListener('log-content-search', 'input', debounce(searchInLog, 300));
    safeAddListener('log-scroll-top', 'click', () => {
        const content = document.querySelector('.logs-viewer-content');
        if (content) content.scrollTop = 0;
    });
    safeAddListener('log-scroll-bottom', 'click', () => {
        const content = document.querySelector('.logs-viewer-content');
        if (content) content.scrollTop = content.scrollHeight;
    });

    // Schedule tab buttons
    document.getElementById('schedule-frequency').addEventListener('change', toggleCronField);
    document.getElementById('create-schedule').addEventListener('click', createSchedule);
}

// Load Audits
async function loadAudits() {
    try {
        const grid = document.getElementById('audits-grid');
        grid.innerHTML = `
            <div class="audits-loading">
                <div class="audits-loading-spinner"></div>
                <p>Loading audits...</p>
            </div>
        `;

        const response = await apiFetch(`${API_BASE}/api/audits`);

        // Handle authentication errors
        if (response.status === 401 || response.status === 403) {
            showAuthError();
            return;
        }

        const data = await response.json();

        if (data.success) {
            allAudits = data.audits;
            renderAudits(allAudits);
            populateDomainFilter(data.domains);
            updateAuditStats(data.audits, data.domains);
        } else {
            showError('Failed to load audits: ' + data.error);
        }
    } catch (error) {
        showError('Error loading audits: ' + error.message);
        const grid = document.getElementById('audits-grid');
        grid.innerHTML = `
            <div class="audits-empty-state">
                <div class="audits-empty-icon">⚠️</div>
                <h3>Error Loading Audits</h3>
                <p>${error.message}</p>
            </div>
        `;
    }
}

function updateAuditStats(audits, domains) {
    const totalEl = document.getElementById('audits-total-count');
    const domainEl = document.getElementById('audits-domain-count');
    const selectedEl = document.getElementById('audits-selected-count');

    if (totalEl) totalEl.textContent = audits.length;
    if (domainEl) domainEl.textContent = Object.keys(domains || {}).length;
    if (selectedEl) selectedEl.textContent = selectedAudits.size;
}

function renderAudits(audits) {
    const grid = document.getElementById('audits-grid');

    if (audits.length === 0) {
        grid.innerHTML = `
            <div class="audits-empty-state">
                <div class="audits-empty-icon">📭</div>
                <h3>No Audits Found</h3>
                <p>No audits match your current filter criteria</p>
            </div>
        `;
        updateVisibleCount(0);
        return;
    }

    grid.innerHTML = audits.map(audit => {
        const osIcon = audit.platform === 'windows' ? '🪟' : '🐧';
        return `
        <div class="audit-card ${selectedAudits.has(audit.path) ? 'selected' : ''}" data-path="${escapeHtml(audit.path)}" data-platform="${escapeHtml(audit.platform || 'linux')}">
            <input type="checkbox" class="audit-card-checkbox" ${selectedAudits.has(audit.path) ? 'checked' : ''}>
            <span class="audit-card-os" title="${audit.platform === 'windows' ? 'Windows' : 'Linux'}">${osIcon}</span>
            <span class="audit-card-domain ${escapeHtml(audit.domain.toLowerCase())}">${escapeHtml(audit.domain)}</span>
            <span class="audit-card-name">${escapeHtml(audit.display_name)}</span>
            <span class="audit-card-category">${escapeHtml(audit.category)}</span>
            <span class="audit-card-path" title="${escapeHtml(audit.path)}">${escapeHtml(audit.path.split('/').pop())}</span>
        </div>
    `}).join('');

    // Add click handlers
    grid.querySelectorAll('.audit-card').forEach(card => {
        card.addEventListener('click', (e) => {
            const path = card.dataset.path;
            const checkbox = card.querySelector('input[type="checkbox"]');

            if (e.target.type !== 'checkbox') {
                checkbox.checked = !checkbox.checked;
            }

            if (checkbox.checked) {
                selectedAudits.add(path);
                card.classList.add('selected');
            } else {
                selectedAudits.delete(path);
                card.classList.remove('selected');
            }

            updateSelectionCount();
        });
    });

    updateSelectionCount();
    updateVisibleCount(audits.length);
}

function updateVisibleCount(count) {
    const el = document.getElementById('audits-visible-count');
    if (el) el.textContent = `Showing ${count} audits`;
}

function populateDomainFilter(domains, osFilter = '') {
    const select = document.getElementById('domain-filter');
    const currentValue = select.value;

    // Filter domains based on OS selection
    let filteredDomains = domains;
    if (osFilter) {
        filteredDomains = {};
        allAudits.filter(a => a.platform === osFilter).forEach(audit => {
            if (!filteredDomains[audit.domain]) {
                filteredDomains[audit.domain] = [];
            }
            filteredDomains[audit.domain].push(audit);
        });
    }

    select.innerHTML = '<option value="">All Types</option>';
    Object.keys(filteredDomains).sort().forEach(domain => {
        const option = document.createElement('option');
        option.value = domain;
        option.textContent = `${domain} (${filteredDomains[domain].length})`;
        select.appendChild(option);
    });

    // Restore selection if still valid, otherwise reset
    if (filteredDomains[currentValue]) {
        select.value = currentValue;
    } else {
        select.value = '';
    }
}

function filterAudits() {
    const domain = document.getElementById('domain-filter').value;
    // Support both search inputs (filter bar and inline header)
    const filterSearch = document.getElementById('search-input')?.value?.toLowerCase() || '';
    const inlineSearch = document.getElementById('audits-list-search')?.value?.toLowerCase() || '';
    const search = inlineSearch || filterSearch;
    const osFilter = document.getElementById('os-filter')?.value || '';

    // Update Type dropdown to show only types for the selected OS
    const domains = {};
    allAudits.forEach(audit => {
        if (!domains[audit.domain]) domains[audit.domain] = [];
        domains[audit.domain].push(audit);
    });
    populateDomainFilter(domains, osFilter);

    const filtered = allAudits.filter(audit => {
        const matchesDomain = !domain || audit.domain === domain;
        const matchesSearch = !search ||
            audit.name.toLowerCase().includes(search) ||
            audit.display_name.toLowerCase().includes(search) ||
            audit.category.toLowerCase().includes(search);
        const matchesOS = !osFilter || audit.platform === osFilter;
        return matchesDomain && matchesSearch && matchesOS;
    });

    renderAudits(filtered);
}

function selectAllAudits() {
    const visibleCards = document.querySelectorAll('.audit-card');
    visibleCards.forEach(card => {
        const path = card.dataset.path;
        selectedAudits.add(path);
        card.classList.add('selected');
        card.querySelector('input[type="checkbox"]').checked = true;
    });
    updateSelectionCount();
}

function deselectAllAudits() {
    selectedAudits.clear();
    document.querySelectorAll('.audit-card').forEach(card => {
        card.classList.remove('selected');
        card.querySelector('input[type="checkbox"]').checked = false;
    });
    updateSelectionCount();
}

function updateSelectionCount() {
    const actionCount = document.getElementById('selection-count');
    const statCount = document.getElementById('audits-selected-count');

    if (actionCount) actionCount.textContent = `${selectedAudits.size} audits selected`;
    if (statCount) statCount.textContent = selectedAudits.size;
}

// Presets
async function loadPresets() {
    try {
        const response = await apiFetch(`${API_BASE}/api/presets`);
        const data = await response.json();

        if (data.success) {
            const select = document.getElementById('preset-select');
            let presetCount = 0;
            Object.entries(data.presets).forEach(([key, preset]) => {
                const option = document.createElement('option');
                option.value = key;
                option.textContent = `${preset.name} - ${preset.description}`;
                select.appendChild(option);
                presetCount++;
            });

            // Update preset count stat
            const presetCountEl = document.getElementById('audits-preset-count');
            if (presetCountEl) presetCountEl.textContent = presetCount;
        }
    } catch (error) {
        console.error('Error loading presets:', error);
    }
}

async function applyPreset() {
    const preset = document.getElementById('preset-select').value;
    if (!preset) {
        alert('Please select a preset');
        return;
    }

    // Define preset mappings to audit types/domains
    const presetMappings = {
        'all': null,  // Select all
        'platform': ['platform', 'common', 'server', 'desktop'],
        'web': ['web', 'apps'],
        'security': ['security', 'advanced-controls', 'network'],
        'minimal': ['platform', 'security', 'common']
    };

    const osFilter = document.getElementById('os-filter')?.value || '';
    const targetDomains = presetMappings[preset];

    // Clear current selection
    selectedAudits.clear();

    // Select audits matching the preset
    allAudits.forEach(audit => {
        // Match OS if filter is set
        if (osFilter && audit.platform !== osFilter) return;

        // Match domain/type if preset has specific targets
        if (targetDomains === null || targetDomains.includes(audit.domain)) {
            selectedAudits.add(audit.path);
        }
    });

    // Update UI to show selections
    document.querySelectorAll('.audit-card').forEach(card => {
        const path = card.dataset.path;
        const isSelected = selectedAudits.has(path);
        card.classList.toggle('selected', isSelected);
        const checkbox = card.querySelector('input[type="checkbox"]');
        if (checkbox) checkbox.checked = isSelected;
    });

    updateSelectionCount();

    // Show feedback
    const count = selectedAudits.size;
    const osText = osFilter ? ` ${osFilter}` : '';
    alert(`Selected ${count}${osText} audits for "${preset}" preset.\nClick "Run Selected" to execute.`);
}

// Execution
async function runSelectedAudits() {
    if (selectedAudits.size === 0) {
        alert('Please select at least one audit to run');
        return;
    }

    if (confirm(`Run ${selectedAudits.size} selected audits?`)) {
        runAudits('selection', { paths: Array.from(selectedAudits) });
    }
}

async function runAudits(mode, options) {
    try {
        switchTab('execution');
        clearOutput();

        const response = await apiFetch(`${API_BASE}/api/execute`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mode, ...options })
        });

        const data = await response.json();

        if (data.success) {
            updateExecutionStatus('running');
            startExecutionPolling();
        } else {
            showError('Failed to start execution: ' + data.error);
        }
    } catch (error) {
        showError('Error starting execution: ' + error.message);
    }
}

function startExecutionPolling() {
    if (executionPolling) clearInterval(executionPolling);

    executionPolling = setInterval(async () => {
        await checkExecutionStatus();
    }, POLLING_CONFIG.EXECUTION_STATUS);
}

function stopExecutionPolling() {
    if (executionPolling) {
        clearInterval(executionPolling);
        executionPolling = null;
    }
}

async function checkExecutionStatus() {
    try {
        const response = await apiFetch(`${API_BASE}/api/status`);
        const data = await response.json();

        if (data.success) {
            updateExecutionDisplay(data);

            if (!data.running && executionPolling) {
                stopExecutionPolling();
                updateExecutionStatus(data.summary ? 'complete' : 'idle');
            }
        }
    } catch (error) {
        console.error('Error checking status:', error);
    }
}

function updateExecutionDisplay(data) {
    // Update output
    const outputDisplay = document.getElementById('output-display');
    if (outputDisplay && data.output && data.output.length > 0) {
        const lines = data.output.map(o => o.line).join('\n');
        outputDisplay.textContent = lines;
        outputDisplay.scrollTop = outputDisplay.scrollHeight;
    }

    // Update summary (using live-* IDs from index.html)
    if (data.summary) {
        const summaryEl = document.getElementById('live-exec-summary');
        if (summaryEl) summaryEl.style.display = 'block';

        const passEl = document.getElementById('live-stat-pass');
        const warnEl = document.getElementById('live-stat-warn');
        const failEl = document.getElementById('live-stat-fail');
        const skipEl = document.getElementById('live-stat-skip');

        if (passEl) passEl.textContent = data.summary.pass || 0;
        if (warnEl) warnEl.textContent = data.summary.warn || 0;
        if (failEl) failEl.textContent = data.summary.fail || 0;
        if (skipEl) skipEl.textContent = data.summary.skip || 0;
    }

    // Update time (element may not exist on all pages)
    if (data.start_time) {
        const start = new Date(data.start_time);
        const now = new Date();
        const elapsed = Math.floor((now - start) / 1000);
        const minutes = Math.floor(elapsed / 60);
        const seconds = elapsed % 60;
        const timeEl = document.getElementById('exec-time');
        if (timeEl) {
            timeEl.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }
    }
}

function updateExecutionStatus(status) {
    // Try both possible element IDs (live-output-status in index.html)
    const badge = document.getElementById('live-output-status') || document.getElementById('exec-status');
    if (badge) {
        badge.className = `status-badge status-${status}`;
        badge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
    }
}

function clearOutput() {
    const outputEl = document.getElementById('output-display');
    if (outputEl) outputEl.textContent = '';

    const summaryEl = document.getElementById('live-exec-summary');
    if (summaryEl) summaryEl.style.display = 'none';

    const timeEl = document.getElementById('exec-time');
    if (timeEl) timeEl.textContent = '';
}

// Plans
async function loadPlans() {
    try {
        const plansList = document.getElementById('plans-list');
        plansList.innerHTML = `
            <div class="plans-loading">
                <div class="plans-loading-spinner"></div>
                <p>Loading plans...</p>
            </div>
        `;

        const response = await apiFetch(`${API_BASE}/api/plans`);
        const data = await response.json();

        if (data.success && data.plans.length > 0) {
            // Calculate stats
            const today = new Date().toDateString();
            let totalAudits = 0;
            let recentCount = 0;

            data.plans.forEach(plan => {
                totalAudits += (plan.audits ? plan.audits.length : 0);
                if (new Date(plan.modified).toDateString() === today) {
                    recentCount++;
                }
            });

            // Update stats
            updatePlansStats(data.plans.length, totalAudits, recentCount);

            // Render plans as list view
            const headerRow = `
                <div class="plans-list-header">
                    <span>Plan Name</span>
                    <span>Audits</span>
                    <span>Last Modified</span>
                    <span>Actions</span>
                </div>
            `;

            const rows = data.plans.map(plan => {
                const auditCount = plan.audits ? plan.audits.length : 0;
                const modifiedDate = new Date(plan.modified).toLocaleDateString();
                const planPathSafe = escapeHtml(plan.path).replace(/'/g, "\\'");

                return `
                    <div class="plan-list-row" data-path="${escapeHtml(plan.path)}">
                        <div class="plan-list-info">
                            <div class="plan-list-name">${escapeHtml(plan.name)}</div>
                            <div class="plan-list-path" title="${escapeHtml(plan.path)}">${escapeHtml(plan.path)}</div>
                        </div>
                        <div class="plan-list-audits">
                            <span class="icon">📝</span> ${auditCount}
                        </div>
                        <div class="plan-list-modified">${modifiedDate}</div>
                        <div class="plan-list-actions">
                            <button class="btn btn-small btn-secondary" onclick="viewPlanAudits('${planPathSafe}')" title="View audits">👁️</button>
                            <button class="btn btn-small btn-primary" onclick="runPlan('${planPathSafe}')" title="Run plan">▶️</button>
                            <button class="btn btn-small btn-secondary" onclick="deletePlan('${planPathSafe}')" title="Delete">🗑️</button>
                        </div>
                    </div>
                `;
            }).join('');

            plansList.className = 'plans-list-view';
            plansList.innerHTML = headerRow + rows;

        } else {
            plansList.className = 'plans-list';
            plansList.innerHTML = `
                <div class="plans-empty-state">
                    <div class="plans-empty-icon">📁</div>
                    <h3>No Saved Plans</h3>
                    <p>Create plans by selecting audits and clicking "Save as Plan" in the Audit Selection tab</p>
                    <button class="btn btn-primary" onclick="switchTab('audits')">Go to Audit Selection</button>
                </div>
            `;
            updatePlansStats(0, 0, 0);
        }
    } catch (error) {
        console.error('Error loading plans:', error);
        const plansList = document.getElementById('plans-list');
        plansList.innerHTML = `
            <div class="plans-empty-state">
                <div class="plans-empty-icon">⚠️</div>
                <h3>Error Loading Plans</h3>
                <p>${error.message}</p>
            </div>
        `;
    }
}

function updatePlansStats(total, audits, recent) {
    const totalEl = document.getElementById('plans-total-count');
    const auditsEl = document.getElementById('plans-total-audits');
    const recentEl = document.getElementById('plans-recent-count');

    if (totalEl) totalEl.textContent = total;
    if (auditsEl) auditsEl.textContent = audits;
    if (recentEl) recentEl.textContent = recent;
}

function viewPlanAudits(planPath) {
    // Toggle view of audits in the plan card
    const planCard = document.querySelector(`.plan-card[data-path="${planPath.replace(/\\/g, '\\\\')}"]`);
    if (!planCard) return;

    let auditsDiv = planCard.querySelector('.plan-card-audits');
    if (auditsDiv) {
        auditsDiv.classList.toggle('active');
    } else {
        // Fetch plan details and show audits
        apiFetch(`${API_BASE}/api/plans`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    const plan = data.plans.find(p => p.path === planPath);
                    if (plan && plan.audits) {
                        auditsDiv = document.createElement('div');
                        auditsDiv.className = 'plan-card-audits active';
                        auditsDiv.innerHTML = plan.audits.map(a =>
                            `<div class="plan-audit-item">${escapeHtml(a)}</div>`
                        ).join('');
                        planCard.insertBefore(auditsDiv, planCard.querySelector('.plan-card-actions'));
                    }
                }
            });
    }
}

async function deletePlan(planPath) {
    if (!confirm(`Delete plan: ${planPath}?`)) return;

    try {
        const response = await apiFetch(`${API_BASE}/api/plans/delete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: planPath })
        });

        const data = await response.json();
        if (data.success) {
            loadPlans();
        } else {
            alert('Failed to delete plan: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Error deleting plan: ' + error.message);
    }
}

async function runPlan(planPath) {
    if (confirm(`Run plan: ${planPath}?`)) {
        // Increment runs counter
        const runsEl = document.getElementById('plans-runs-count');
        if (runsEl) runsEl.textContent = parseInt(runsEl.textContent || '0', 10) + 1;

        runAudits('plan', { plan_path: planPath });
    }
}

function filterPlans() {
    const searchInput = document.getElementById('plans-search');
    if (!searchInput) return;

    const query = searchInput.value.toLowerCase().trim();
    // Support both card view (.plan-card) and list view (.plan-list-row)
    const planItems = document.querySelectorAll('.plan-card, .plan-list-row');

    planItems.forEach(item => {
        // Support both class name patterns
        const name = (item.querySelector('.plan-card-name') || item.querySelector('.plan-list-name'))?.textContent.toLowerCase() || '';
        const path = (item.querySelector('.plan-card-path') || item.querySelector('.plan-list-path'))?.textContent.toLowerCase() || '';

        if (!query || name.includes(query) || path.includes(query)) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

function showSavePlanModal() {
    if (selectedAudits.size === 0) {
        alert('Please select at least one audit to save');
        return;
    }

    document.getElementById('save-plan-modal').classList.add('active');
    document.getElementById('plan-name-input').value = '';
    document.getElementById('plan-name-input').focus();
}

function hideSavePlanModal() {
    document.getElementById('save-plan-modal').classList.remove('active');
}

async function savePlan() {
    const name = document.getElementById('plan-name-input').value.trim();

    if (!name) {
        alert('Please enter a plan name');
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/plans/save`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: name,
                paths: Array.from(selectedAudits)
            })
        });

        const data = await response.json();

        if (data.success) {
            alert(data.message);
            hideSavePlanModal();
            loadPlans();
        } else {
            alert('Failed to save plan: ' + data.error);
        }
    } catch (error) {
        alert('Error saving plan: ' + error.message);
    }
}

// Logs
let currentLogContent = '';
let currentLogName = '';
let selectedLogs = new Set();
let currentVisibleLogNames = [];

async function loadLogs() {
    try {
        const response = await apiFetch(`${API_BASE}/api/logs`);
        const data = await response.json();

        const logsList = document.getElementById('logs-list');
        // Support both search inputs (filter section and inline header)
        const filterSearch = document.getElementById('logs-search')?.value?.toLowerCase() || '';
        const inlineSearch = document.getElementById('logs-list-search')?.value?.toLowerCase() || '';
        const searchValue = inlineSearch || filterSearch;
        const sortValue = document.getElementById('logs-sort')?.value || 'modified';

        if (data.success && data.logs.length > 0) {
            let logs = [...data.logs];

            const availableLogs = new Set(data.logs.map(log => log.name));
            selectedLogs = new Set([...selectedLogs].filter(name => availableLogs.has(name)));

            // Apply search filter
            if (searchValue) {
                logs = logs.filter(log => log.name.toLowerCase().includes(searchValue));
            }

            // Apply sorting
            logs.sort((a, b) => {
                if (sortValue === 'name') return a.name.localeCompare(b.name);
                if (sortValue === 'size') return b.size - a.size;
                return new Date(b.modified) - new Date(a.modified);
            });

            // Calculate stats
            const totalSize = data.logs.reduce((sum, log) => sum + log.size, 0);
            const today = new Date().toDateString();
            const recentCount = data.logs.filter(log => new Date(log.modified).toDateString() === today).length;
            const errorLogs = data.logs.filter(log => log.name.toLowerCase().includes('error')).length;

            // Update stats
            const updateEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
            updateEl('logs-file-count', data.logs.length);
            updateEl('logs-total-size', formatFileSize(totalSize));
            updateEl('logs-recent-count', recentCount);
            updateEl('logs-error-count', errorLogs);
            updateEl('logs-showing-count', `${logs.length} files`);

            currentVisibleLogNames = logs.map(log => log.name);

            logsList.innerHTML = logs.map(log => {
                const fileIcon = getLogIcon(log.name);
                const modDate = new Date(log.modified);
                const dateStr = modDate.toLocaleDateString();
                const timeStr = modDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                const logNameSafeHtml = escapeHtml(log.name);
                const logNameSafeJs = String(log.name).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                const checked = selectedLogs.has(log.name) ? 'checked' : '';

                return `
                <div class="logs-compact-item" onclick="viewLog('${logNameSafeJs}')">
                    <input type="checkbox" class="log-select-cb" ${checked} onclick="event.stopPropagation(); toggleLogSelection('${logNameSafeJs}', this.checked)">
                    <span class="logs-compact-icon">${fileIcon}</span>
                    <div class="logs-compact-info">
                        <div class="logs-compact-name">${logNameSafeHtml}</div>
                        <div class="logs-compact-meta">
                            <span>\uD83D\uDCBE ${formatFileSize(log.size)}</span>
                            <span>\uD83D\uDCC5 ${escapeHtml(dateStr)}</span>
                            <span>\u23F0 ${escapeHtml(timeStr)}</span>
                        </div>
                    </div>
                    <div class="logs-compact-actions" onclick="event.stopPropagation();">
                        <button class="btn btn-small btn-primary" onclick="viewLog('${logNameSafeJs}')" title="View">\uD83D\uDC41\uFE0F</button>
                        <button class="btn btn-small btn-secondary" onclick="downloadLog('${logNameSafeJs}')" title="Download">\u2B07\uFE0F</button>
                        <button class="btn btn-small btn-danger" onclick="deleteLog('${logNameSafeJs}')" title="Delete">\uD83D\uDDD1\uFE0F</button>
                    </div>
                </div>
                `;
            }).join('');
            updateLogSelectionUI();
        } else {
            const updateEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
            updateEl('logs-file-count', '0');
            updateEl('logs-total-size', '0 KB');
            updateEl('logs-recent-count', '0');
            updateEl('logs-error-count', '0');
            updateEl('logs-showing-count', '0 files');

            currentVisibleLogNames = [];
            selectedLogs.clear();
            updateLogSelectionUI();

            logsList.innerHTML = `
                <div class="logs-empty-state">
                    <span class="logs-empty-icon">\uD83D\uDCC4</span>
                    <h3>No Log Files</h3>
                    <p>No log files found in the logs directory</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading logs:', error);
    }
}

function toggleLogSelection(logName, isChecked) {
    if (isChecked) {
        selectedLogs.add(logName);
    } else {
        selectedLogs.delete(logName);
    }
    updateLogSelectionUI();
}

function setAllLogSelection(shouldSelect) {
    if (shouldSelect) {
        currentVisibleLogNames.forEach(name => selectedLogs.add(name));
    } else {
        currentVisibleLogNames.forEach(name => selectedLogs.delete(name));
    }

    const checkboxes = document.querySelectorAll('#logs-list .log-select-cb');
    checkboxes.forEach(checkbox => {
        checkbox.checked = shouldSelect;
    });

    updateLogSelectionUI();
}

function clearAllLogSelection() {
    selectedLogs.clear();
    const checkboxes = document.querySelectorAll('#logs-list .log-select-cb');
    checkboxes.forEach(checkbox => {
        checkbox.checked = false;
    });
    updateLogSelectionUI();
}

function updateLogSelectionUI() {
    const bulkBar = document.getElementById('logs-bulk-bar');
    const selectedCount = document.getElementById('logs-selected-count');
    const selectAll = document.getElementById('logs-select-all');

    if (selectedCount) {
        selectedCount.textContent = `${selectedLogs.size} selected`;
    }

    if (bulkBar) {
        bulkBar.style.display = selectedLogs.size > 0 ? 'flex' : 'none';
    }

    if (selectAll) {
        if (currentVisibleLogNames.length === 0) {
            selectAll.checked = false;
            selectAll.indeterminate = false;
            return;
        }

        const selectedVisibleCount = currentVisibleLogNames.filter(name => selectedLogs.has(name)).length;
        selectAll.checked = selectedVisibleCount === currentVisibleLogNames.length;
        selectAll.indeterminate = selectedVisibleCount > 0 && selectedVisibleCount < currentVisibleLogNames.length;
    }
}

async function deleteLog(logName) {
    if (!confirm(`Delete log '${logName}'?`)) {
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/logs/${encodeURIComponent(logName)}`, {
            method: 'DELETE'
        });

        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.error || `HTTP ${response.status}`);
        }

        selectedLogs.delete(logName);
        if (currentLogName === logName) {
            closeLogViewer();
        }
        await loadLogs();
    } catch (error) {
        alert(`Failed to delete log: ${error.message}`);
    }
}

async function deleteSelectedLogs() {
    if (selectedLogs.size === 0) {
        return;
    }

    const names = Array.from(selectedLogs);
    if (!confirm(`Delete ${names.length} selected log(s)?`)) {
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/logs/delete-batch`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ names })
        });

        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.error || `HTTP ${response.status}`);
        }

        (result.deleted || []).forEach(name => {
            selectedLogs.delete(name);
            if (currentLogName === name) {
                closeLogViewer();
            }
        });

        if ((result.errors || []).length > 0) {
            alert(`Deleted ${result.deleted_count || 0} log(s). ${result.error_count || 0} failed.`);
        }

        await loadLogs();
    } catch (error) {
        alert(`Failed to delete selected logs: ${error.message}`);
    }
}

function getLogIcon(filename) {
    const lower = filename.toLowerCase();
    if (lower.includes('error')) return '\uD83D\uDED1';
    if (lower.includes('warn')) return '\u26A0\uFE0F';
    if (lower.includes('audit')) return '\uD83D\uDD12';
    if (lower.includes('access')) return '\uD83D\uDC64';
    if (lower.includes('deploy')) return '\uD83D\uDE80';
    return '\uD83D\uDCC4';
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

async function viewLog(logName) {
    try {
        const response = await apiFetch(`${API_BASE}/api/logs/${logName}`);
        const data = await response.json();

        if (data.success) {
            currentLogName = logName;
            currentLogContent = data.content;

            document.getElementById('log-title').textContent = logName;

            // Format log content with line highlighting
            const lines = data.content.split('\n');
            const formattedLines = lines.map(line => {
                let levelClass = '';
                const lowerLine = line.toLowerCase();
                if (lowerLine.includes('error') || lowerLine.includes('[fail]')) levelClass = 'level-error';
                else if (lowerLine.includes('warn') || lowerLine.includes('[warn]')) levelClass = 'level-warn';
                else if (lowerLine.includes('info') || lowerLine.includes('[info]')) levelClass = 'level-info';
                else if (lowerLine.includes('debug')) levelClass = 'level-debug';
                else if (lowerLine.includes('[pass]') || lowerLine.includes('success')) levelClass = 'level-success';

                return `<span class="logs-content-line ${levelClass}">${escapeHtml(line)}</span>`;
            }).join('');

            document.getElementById('log-content').innerHTML = formattedLines;
            document.getElementById('log-line-count').textContent = `\uD83D\uDCC3 ${lines.length} lines`;
            document.getElementById('log-file-size').textContent = `\uD83D\uDCBE ${formatFileSize(data.content.length)}`;

            // Show viewer, hide browser
            document.getElementById('log-viewer').classList.add('active');
            document.getElementById('logs-browser').style.display = 'none';

        } else {
            alert('Failed to load log: ' + data.error);
        }
    } catch (error) {
        alert('Error loading log: ' + error.message);
    }
}

function closeLogViewer() {
    document.getElementById('log-viewer').classList.remove('active');
    document.getElementById('logs-browser').style.display = 'block';
    currentLogContent = '';
    currentLogName = '';
}

function downloadLog(logName) {
    window.open(`${API_BASE}/api/logs/${logName}/download`, '_blank');
}

function searchInLog() {
    const searchInput = document.getElementById('log-content-search');
    const searchValue = searchInput?.value?.toLowerCase() || '';
    const contentEl = document.getElementById('log-content');

    // Remove previous highlights
    const lines = contentEl.querySelectorAll('.logs-content-line');
    lines.forEach(line => line.classList.remove('highlight'));

    if (!searchValue) {
        document.getElementById('log-search-count').textContent = '';
        return;
    }

    let matchCount = 0;
    lines.forEach(line => {
        if (line.textContent.toLowerCase().includes(searchValue)) {
            line.classList.add('highlight');
            matchCount++;
        }
    });

    document.getElementById('log-search-count').textContent = `${matchCount} matches`;

    // Scroll to first match
    const firstMatch = contentEl.querySelector('.highlight');
    if (firstMatch) {
        firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

// Utility
function showError(message) {
    console.error(message);
    alert(message);
}

function showAuthError() {
    const message = `⚠️ Authentication Required

This appears to be a remote connection. For security, API authentication is required.

Solutions:
1. Access via localhost (http://127.0.0.1:5000) for auto-authentication
2. Set environment variable: REQUIRE_STRICT_AUTH=false (development only)
3. Use API key authentication (see server console for API key)

For help, see the Security Considerations section in web/README.md`;

    console.error('Authentication error - API returned 401/403');
    alert(message);

    // Show error in audits grid
    const grid = document.getElementById('audits-grid');
    grid.innerHTML = '<p class="loading" style="color: #ef4444;">❌ Authentication required. See alert message or reconnect via localhost.</p>';
}

// ============================================================================
// Server Management & Deployment
// ============================================================================

async function loadServers() {
    try {
        const response = await apiFetch(`${API_BASE}/api/servers`);
        const data = await response.json();

        const serversList = document.getElementById('servers-list');

        // Update stats
        const totalEl = document.getElementById('deploy-total-servers');
        const deployedEl = document.getElementById('deploy-deployed-count');
        const pendingEl = document.getElementById('deploy-pending-count');
        const failedEl = document.getElementById('deploy-failed-count');

        if (data.success && data.servers.length > 0) {
            // Cache servers for filtering
            cachedDeployServers = data.servers;

            // Count stats
            let deployed = 0, pending = 0, failed = 0;
            data.servers.forEach(s => {
                if (s.deploy_status === 'deployed') deployed++;
                else if (s.deploy_status === 'failed') failed++;
                else pending++;
            });

            if (totalEl) totalEl.textContent = data.servers.length;
            if (deployedEl) deployedEl.textContent = deployed;
            if (pendingEl) pendingEl.textContent = pending;
            if (failedEl) failedEl.textContent = failed;

            renderDeployServerList();
        } else {
            cachedDeployServers = [];
            if (totalEl) totalEl.textContent = '0';
            if (deployedEl) deployedEl.textContent = '0';
            if (pendingEl) pendingEl.textContent = '0';
            if (failedEl) failedEl.textContent = '0';

            serversList.innerHTML = `
                <div class="deploy-empty-state">
                    <span class="deploy-empty-icon">\uD83D\uDDA5\uFE0F</span>
                    <p>No servers configured</p>
                    <p class="deploy-empty-hint">Click "Add Server" or go to Connect tab to add servers</p>
                </div>
            `;
        }

        updateServerSelectionCount();
    } catch (error) {
        console.error('Error loading servers:', error);
    }
}

function renderDeployServerList() {
    const serversList = document.getElementById('servers-list');
    if (!serversList) return;

    // Apply search filter
    let filteredServers = cachedDeployServers;
    if (deployServerSearchFilter) {
        const search = deployServerSearchFilter.toLowerCase();
        filteredServers = cachedDeployServers.filter(s =>
            (s.name || '').toLowerCase().includes(search) ||
            (s.host || s.hostname || '').toLowerCase().includes(search) ||
            (s.user || s.username || '').toLowerCase().includes(search) ||
            (s.os_type || '').toLowerCase().includes(search)
        );
    }

    if (filteredServers.length === 0) {
        if (deployServerSearchFilter) {
            serversList.innerHTML = '<p class="info-text">No servers match your search.</p>';
        } else {
            serversList.innerHTML = `
                <div class="deploy-empty-state">
                    <span class="deploy-empty-icon">\uD83D\uDDA5\uFE0F</span>
                    <p>No servers configured</p>
                    <p class="deploy-empty-hint">Click "Add Server" or go to Connect tab to add servers</p>
                </div>
            `;
        }
        return;
    }

    // Build compact list header
    const headerRow = `
        <div class="deploy-server-list-header">
            <span class="deploy-col-checkbox"><input type="checkbox" id="deploy-select-all" title="Select All"></span>
            <span>Name</span>
            <span>Host</span>
            <span>User</span>
            <span>Method</span>
            <span>Status</span>
            <span>Actions</span>
        </div>
    `;

    const rows = filteredServers.map(server => {
        const osIcon = server.os_type === 'windows' ? '\uD83E\uDE9F' : (server.os_type === 'hypervisor' ? '\uD83D\uDDA5\uFE0F' : '\uD83D\uDC27');
        const deployStatus = server.deploy_status || 'pending';
        const statusLabel = deployStatus === 'deployed' ? 'Deployed' :
                           deployStatus === 'failed' ? 'Failed' : 'Pending';
        const connMethod = server.connection_method || 'ssh';
        const connLabel = connMethod === 'agent' ? 'Agent' : connMethod === 'winrm' ? 'WinRM' : 'SSH';
        const isSelected = selectedServers.has(server.id);

        return `
            <div class="deploy-server-row ${isSelected ? 'selected' : ''} ${deployStatus}" data-server-id="${escapeHtml(server.id)}">
                <div class="deploy-col-checkbox">
                    <input type="checkbox" class="deploy-server-checkbox" ${isSelected ? 'checked' : ''}>
                </div>
                <div class="deploy-server-name-col">
                    <span class="deploy-server-icon">${osIcon}</span>
                    <span class="deploy-server-name">${escapeHtml(server.name)}</span>
                </div>
                <div class="deploy-server-host">${escapeHtml(server.host || server.hostname)}:${escapeHtml(server.port || 22)}</div>
                <div class="deploy-server-user">${escapeHtml(server.user || server.username || 'N/A')}</div>
                <div class="deploy-server-method"><span class="deploy-method-badge ${connMethod}">${connLabel}</span></div>
                <div class="deploy-server-status"><span class="deploy-status-badge ${deployStatus}">${statusLabel}</span></div>
                <div class="deploy-server-actions">
                    <button class="btn-icon" onclick="event.stopPropagation(); testServer(${parseInt(server.id) || 0})" title="Test">\uD83D\uDD0C</button>
                    <button class="btn-icon btn-icon-danger" onclick="event.stopPropagation(); removeServer(${parseInt(server.id) || 0})" title="Remove">\u2717</button>
                </div>
            </div>
        `;
    }).join('');

    serversList.innerHTML = headerRow + rows;

    // Add select-all handler
    const selectAllCheckbox = serversList.querySelector('#deploy-select-all');
    if (selectAllCheckbox) {
        // Reflect current state
        const visibleIds = filteredServers.map(s => s.id);
        const allVisibleSelected = visibleIds.every(id => selectedServers.has(id));
        selectAllCheckbox.checked = allVisibleSelected && visibleIds.length > 0;

        selectAllCheckbox.addEventListener('change', (e) => {
            const allRows = serversList.querySelectorAll('.deploy-server-row');
            allRows.forEach(row => {
                const serverId = parseInt(row.dataset.serverId, 10);
                const checkbox = row.querySelector('.deploy-server-checkbox');
                checkbox.checked = e.target.checked;
                if (e.target.checked) {
                    selectedServers.add(serverId);
                    row.classList.add('selected');
                } else {
                    selectedServers.delete(serverId);
                    row.classList.remove('selected');
                }
            });
            updateServerSelectionCount();
        });
    }

    // Add row click handlers
    serversList.querySelectorAll('.deploy-server-row').forEach(row => {
        row.addEventListener('click', (e) => {
            // Skip if clicking on buttons or checkbox
            if (e.target.tagName === 'BUTTON' || e.target.type === 'checkbox' || e.target.closest('button')) return;

            const serverId = parseInt(row.dataset.serverId, 10);
            const checkbox = row.querySelector('.deploy-server-checkbox');
            checkbox.checked = !checkbox.checked;

            if (checkbox.checked) {
                selectedServers.add(serverId);
                row.classList.add('selected');
            } else {
                selectedServers.delete(serverId);
                row.classList.remove('selected');
            }

            updateServerSelectionCount();
        });
    });
}

function filterDeployServers(searchTerm) {
    deployServerSearchFilter = searchTerm;
    renderDeployServerList();
}

function updateServerSelectionCount() {
    document.getElementById('server-selection-count').textContent = `${selectedServers.size} servers selected`;
}

function showAddServerModal() {
    document.getElementById('add-server-modal').classList.add('active');
    document.getElementById('server-form').reset();
    toggleAuthFields();
}

function hideAddServerModal() {
    document.getElementById('add-server-modal').classList.remove('active');
}

function toggleAuthFields() {
    const authType = document.getElementById('server-auth').value;
    document.getElementById('password-group').style.display = authType === 'password' ? 'block' : 'none';
    document.getElementById('key-group').style.display = authType === 'key' ? 'block' : 'none';
}

function toggleConnectionMethodFields() {
    const connectionMethod = document.getElementById('server-connection-method').value;
    const agentIdGroup = document.getElementById('agent-id-group');
    const authGroup = document.querySelector('.form-group:has(#server-auth)');
    const passwordGroup = document.getElementById('password-group');
    const keyGroup = document.getElementById('key-group');

    if (connectionMethod === 'agent') {
        // Show agent ID field, hide SSH/WinRM auth fields
        agentIdGroup.classList.remove('d-none');
        if (authGroup) authGroup.classList.add('d-none');
        passwordGroup.style.display = 'none';
        keyGroup.classList.add('d-none');
    } else {
        // Hide agent ID field, show SSH/WinRM auth fields
        agentIdGroup.classList.add('d-none');
        if (authGroup) authGroup.classList.remove('d-none');
        // Restore auth field visibility based on auth type
        toggleAuthFields();
    }
}

async function addServer(e) {
    e.preventDefault();

    const connectionMethod = document.getElementById('server-connection-method').value;
    const executionModeEl = document.getElementById('server-execution-mode');
    const elevationMethodEl = document.getElementById('server-elevation-method');
    const jeaEndpointEl = document.getElementById('server-jea-endpoint');
    const serverData = {
        name: document.getElementById('server-name').value.trim(),
        host: document.getElementById('server-host').value.trim(),
        port: parseInt(document.getElementById('server-port').value, 10),
        user: document.getElementById('server-user').value.trim(),
        os_type: document.getElementById('server-os').value,
        connection_method: connectionMethod,
        execution_mode: executionModeEl ? executionModeEl.value : 'stream',
        elevation_method: elevationMethodEl ? elevationMethodEl.value : 'sudo',
        jea_endpoint: jeaEndpointEl && jeaEndpointEl.value ? jeaEndpointEl.value.trim() : null,
        agent_id: connectionMethod === 'agent' ? document.getElementById('server-agent-id').value.trim() : null,
        auth_type: document.getElementById('server-auth').value,
        password: document.getElementById('server-password').value,
        key_path: document.getElementById('server-key').value.trim(),
        remote_path: document.getElementById('server-path').value.trim()
    };

    try {
        const response = await apiFetch(`${API_BASE}/api/servers/add`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(serverData)
        });

        const data = await response.json();

        if (data.success) {
            alert('Server added successfully!');
            hideAddServerModal();
            loadServers();
        } else {
            alert('Failed to add server: ' + data.error);
        }
    } catch (error) {
        alert('Error adding server: ' + error.message);
    }
}

function showCleanupConfirmModal() {
    if (selectedServers.size === 0) {
        alert('Please select at least one server to clean up.');
        return;
    }

    // Get server details
    const servers = [];
    apiFetch(`${API_BASE}/api/servers/list`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const serverDetails = data.servers.filter(s => selectedServers.has(s.id));

                const listHtml = serverDetails.map(server => `
                    <div style="margin: 8px 0; padding: 8px; background: white; border-radius: 4px; border-left: 4px solid #ef4444;">
                        <strong>${escapeHtml(server.name)}</strong><br>
                        <span style="color: #666; font-size: 13px;">${escapeHtml(server.host)} - ${escapeHtml(server.remote_path)}</span>
                    </div>
                `).join('');

                document.getElementById('cleanup-server-list').innerHTML = listHtml;
                document.getElementById('cleanup-confirm-modal').classList.add('active');
            }
        })
        .catch(error => {
            console.error('Error loading server details:', error);
            alert('Failed to load server details');
        });
}

function hideCleanupConfirmModal() {
    document.getElementById('cleanup-confirm-modal').classList.remove('active');
}

async function cleanupServers() {
    hideCleanupConfirmModal();

    const verify = document.getElementById('verify-cleanup-checkbox').checked;
    const fullCleanup = document.getElementById('full-cleanup-checkbox').checked;
    const serverIds = Array.from(selectedServers);

    // Show cleanup output panel
    document.getElementById('cleanup-output').style.display = 'block';
    document.getElementById('cleanup-status').className = 'status-badge status-running';
    document.getElementById('cleanup-status').textContent = 'Running';
    const cleanupType = fullCleanup ? 'full cleanup' : 'cleanup';
    document.getElementById('cleanup-progress').textContent = `Starting ${cleanupType} operation...\n`;

    try {
        const response = await apiFetch(`${API_BASE}/api/cleanup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                server_ids: serverIds,
                verify: verify,
                full_cleanup: fullCleanup
            })
        });

        const data = await response.json();

        let output = document.getElementById('cleanup-progress').textContent;

        if (data.success) {
            output += `\n${'='.repeat(70)}\n`;
            output += `Cleanup Summary:\n`;
            output += `  Total: ${data.summary.total}\n`;
            output += `  Successful: ${data.summary.successful}\n`;
            output += `  Failed: ${data.summary.failed}\n`;
            output += `${'='.repeat(70)}\n\n`;

            // Display results for each server
            for (const [serverId, result] of Object.entries(data.results)) {
                output += `\n[${result.server_name}] (${result.server_host})\n`;

                if (result.success) {
                    if (result.skipped) {
                        output += `  ⏭️  SKIPPED: ${result.message}\n`;
                    } else {
                        output += `  ✅ SUCCESS: ${result.message}\n`;
                        if (result.disk_freed) {
                            output += `     Disk space freed: ${result.disk_freed}\n`;
                        }
                        output += `     Path removed: ${result.remote_path}\n`;
                        if (result.extra_cleaned && result.extra_cleaned.length > 0) {
                            output += `     Also removed: ${result.extra_cleaned.join(', ')}\n`;
                        }
                    }
                } else {
                    output += `  ❌ FAILED: ${result.error}\n`;
                    if (result.stderr) {
                        output += `     Error details: ${result.stderr.substring(0, 200)}\n`;
                    }
                }
            }

            output += `\n${'='.repeat(70)}\n`;
            output += `Cleanup operation completed.\n`;

            document.getElementById('cleanup-status').className =
                data.summary.failed === 0 ? 'status-badge status-success' : 'status-badge status-error';
            document.getElementById('cleanup-status').textContent =
                data.summary.failed === 0 ? 'Complete' : 'Completed with errors';

            // Clear selection and reload server list
            selectedServers.clear();
            updateServerSelectionCount();
            loadServers();

        } else {
            output += `\n❌ Cleanup operation failed: ${data.error}\n`;
            document.getElementById('cleanup-status').className = 'status-badge status-error';
            document.getElementById('cleanup-status').textContent = 'Failed';
        }

        document.getElementById('cleanup-progress').textContent = output;

    } catch (error) {
        let output = document.getElementById('cleanup-progress').textContent;
        output += `\n❌ Error: ${error.message}\n`;
        document.getElementById('cleanup-progress').textContent = output;

        document.getElementById('cleanup-status').className = 'status-badge status-error';
        document.getElementById('cleanup-status').textContent = 'Error';
    }
}

async function removeServer(serverId) {
    if (!confirm('Are you sure you want to remove this server?')) return;

    try {
        const response = await apiFetch(`${API_BASE}/api/servers/remove/${serverId}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            selectedServers.delete(serverId);
            loadServers();
        } else {
            alert('Failed to remove server: ' + data.error);
        }
    } catch (error) {
        alert('Error removing server: ' + error.message);
    }
}

async function testServer(event, serverId) {
    try {
        const btn = event.target;
        btn.disabled = true;
        btn.textContent = 'Testing...';

        const response = await apiFetch(`${API_BASE}/api/servers/test/${serverId}`, {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            alert('✓ Connection successful!');
        } else {
            alert('✗ Connection failed: ' + data.error);
        }
    } catch (error) {
        alert('Error testing connection: ' + error.message);
    } finally {
        setTimeout(() => {
            btn.disabled = false;
            btn.textContent = '🔌 Test';
        }, 1000);
    }
}

function getSelectedDeployType() {
    const selected = document.querySelector('input[name="deploy-type"]:checked');
    return selected ? selected.value : 'full';
}

function updateDeployTypeBadge() {
    const badge = document.getElementById('deploy-type-badge');
    const type = getSelectedDeployType();
    if (badge) {
        const labels = {
            'full': 'Full Toolkit',
            'lightweight': 'Lightweight HTML',
            'jre-agent': 'Unified Host Agent Runtime',
            'hypervisor-agent': 'Hypervisor Agent'
        };
        badge.textContent = labels[type] || 'Full Toolkit';
        badge.className = 'deploy-type-badge' + (type !== 'full' ? ' ' + type : '');
    }
}

function toggleAgentConfigPanel() {
    const type = getSelectedDeployType();
    const jreAgentPanel = document.getElementById('jre-agent-config-panel');
    const hypervisorAgentPanel = document.getElementById('hypervisor-agent-config-panel');

    if (jreAgentPanel) {
        jreAgentPanel.classList.toggle('d-none', type !== 'jre-agent');
    }
    if (hypervisorAgentPanel) {
        hypervisorAgentPanel.classList.toggle('d-none', type !== 'hypervisor-agent');
    }

    // Toggle schedule time visibility based on checkbox (standalone mode)
    const scheduleCheckbox = document.getElementById('deploy-agent-setup-schedule');
    const scheduleTimeGroup = document.querySelector('.schedule-time-group');
    if (scheduleCheckbox && scheduleTimeGroup) {
        scheduleTimeGroup.style.display = scheduleCheckbox.checked ? 'block' : 'none';
    }
}

function initDeployTypeSelector() {
    // Support both old card-based selector and new table-based selector
    const options = document.querySelectorAll('.deploy-type-option');
    const rows = document.querySelectorAll('.deploy-type-row');

    // Card-based selector (legacy)
    options.forEach(option => {
        option.addEventListener('click', function() {
            options.forEach(o => o.classList.remove('selected'));
            this.classList.add('selected');
            this.querySelector('input[type="radio"]').checked = true;
            updateDeployTypeBadge();
            toggleAgentConfigPanel();
        });
    });

    // Table-based selector (new)
    rows.forEach(row => {
        row.addEventListener('click', function(e) {
            // Don't prevent radio button default behavior
            rows.forEach(r => r.classList.remove('selected'));
            this.classList.add('selected');
            const radio = this.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
            updateDeployTypeBadge();
            toggleAgentConfigPanel();
        });
    });

    // Setup agent config event listeners
    const scheduleCheckbox = document.getElementById('agent-setup-schedule');
    if (scheduleCheckbox) {
        scheduleCheckbox.addEventListener('change', toggleAgentConfigPanel);
    }

    document.querySelectorAll('input[name="deploy-type"]').forEach(radio => {
        radio.addEventListener('change', () => {
            rows.forEach(r => r.classList.toggle('selected', r.contains(radio) && radio.checked));
            updateDeployTypeBadge();
            toggleAgentConfigPanel();
        });
    });

    updateDeployTypeBadge();
    toggleAgentConfigPanel();
}

function updateJREAgentConfig(mode) {
    const standaloneConfig = document.getElementById('jre-standalone-config');
    const managedConfig = document.getElementById('jre-managed-config');

    if (standaloneConfig && managedConfig) {
        if (mode === 'standalone') {
            standaloneConfig.classList.remove('d-none');
            managedConfig.classList.add('d-none');
        } else {
            standaloneConfig.classList.add('d-none');
            managedConfig.classList.remove('d-none');
        }
    }
}

function initDeployModeSelector() {
    const modeRadios = document.querySelectorAll('input[name="deploy-mode"]');
    if (!modeRadios.length) return;

    const remoteSection = document.getElementById('deploy-remote-section');
    const downloadSection = document.getElementById('deploy-download-section');

    const syncMode = () => {
        const selectedMode = document.querySelector('input[name="deploy-mode"]:checked')?.value || 'remote';
        if (remoteSection) remoteSection.classList.toggle('d-none', selectedMode !== 'remote');
        if (downloadSection) downloadSection.classList.toggle('d-none', selectedMode !== 'download');

        document.querySelectorAll('.deploy-mode-option').forEach(option => {
            const radio = option.querySelector('input[name="deploy-mode"]');
            option.classList.toggle('active', !!radio && radio.checked);
        });
    };

    modeRadios.forEach(radio => {
        radio.addEventListener('change', syncMode);
    });

    syncMode();
}

function getAgentConfig() {
    return {
        server_url: document.getElementById('deploy-agent-server-url')?.value || '',
        api_key: document.getElementById('deploy-agent-api-key')?.value || '',
        setup_scheduled_task: document.getElementById('deploy-agent-setup-schedule')?.checked || false,
        schedule_time: document.getElementById('deploy-agent-schedule-time')?.value || '02:00'
    };
}

function getJREAgentConfig() {
    const mode = document.getElementById('deploy-jre-agent-mode')?.value || 'managed';

    if (mode === 'standalone') {
        return {
            mode: 'standalone',
            server_url: document.getElementById('deploy-agent-server-url')?.value || '',
            api_key: document.getElementById('deploy-agent-api-key')?.value || '',
            setup_scheduled_task: document.getElementById('deploy-agent-setup-schedule')?.checked || false,
            schedule_time: document.getElementById('deploy-agent-schedule-time')?.value || '02:00'
        };
    } else {
        // Managed mode
        const connectionMethodRadio = document.querySelector('input[name="deploy-managed-connection"]:checked');
        return {
            mode: 'managed',
            server_url: document.getElementById('deploy-managed-server-url')?.value?.trim() || '',
            api_key: document.getElementById('deploy-managed-api-key')?.value || '',
            poll_interval: parseInt(document.getElementById('deploy-managed-poll-interval')?.value) || 60,
            auto_sync: document.getElementById('deploy-managed-auto-sync')?.checked ?? true,
            connection_method: connectionMethodRadio?.value || 'ssh'
        };
    }
}

function getFleetAgentConfig() {
    // Try download section inputs first, fall back to remote section
    const downloadServerUrl = document.getElementById('download-fleet-agent-server-url')?.value;
    const downloadApiKey = document.getElementById('download-fleet-agent-api-key')?.value;
    const remoteServerUrl = document.getElementById('fleet-agent-server-url')?.value;
    const remoteApiKey = document.getElementById('fleet-agent-api-key')?.value;

    // Get selected connection method
    const connectionMethodRadio = document.querySelector('input[name="fleet-agent-connection"]:checked');
    const connectionMethod = connectionMethodRadio?.value || 'auto';

    return {
        server_url: (downloadServerUrl || remoteServerUrl || '').trim(),
        api_key: downloadApiKey || remoteApiKey || '',
        poll_interval: parseInt(document.getElementById('fleet-agent-poll-interval')?.value) || 60,
        auto_sync: document.getElementById('fleet-agent-auto-sync')?.checked ?? true,
        connection_method: connectionMethod
    };
}

/**
 * Get the selected connection method for fleet agent deployment
 * @returns {string} 'ssh', 'winrm', or 'api'
 */
function getFleetAgentConnectionMethod() {
    const connectionMethodRadio = document.querySelector('input[name="fleet-agent-connection"]:checked');
    return connectionMethodRadio?.value || 'auto';
}

/**
 * Toggle the download help panel visibility
 * @param {Event} event - Click event
 */
function toggleDownloadHelp(event) {
    if (event) event.preventDefault();
    const helpPanel = document.getElementById('download-help-panel');
    if (helpPanel) {
        helpPanel.style.display = helpPanel.style.display === 'none' ? 'block' : 'none';
    }
}

/**
 * Help content for download options
 */
const downloadHelpContent = {
    'windows-script': {
        title: '🪟 Windows Script Download',
        sections: [
            {
                heading: 'What You Get',
                content: 'Just the <code>fleet-agent.ps1</code> PowerShell script file. This is the core agent that communicates with the audit server.'
            },
            {
                heading: 'When to Use',
                list: [
                    'Quick testing or evaluation',
                    'You have your own deployment pipeline that handles installation',
                    'You want to integrate into an existing PowerShell framework',
                    'Manual one-off deployments'
                ]
            },
            {
                heading: 'Requirements',
                list: [
                    'PowerShell 5.1 or later',
                    'Network access to this audit server',
                    'Appropriate permissions based on audit scope'
                ]
            },
            {
                heading: 'Usage',
                code: '.\\fleet-agent.ps1 -ServerUrl "https://your-server:5000" -ApiKey "YOUR_KEY"'
            }
        ],
        tip: 'For enterprise or automated deployments, use the <strong>Windows Package</strong> instead—it includes multi-mode installers and JEA configuration.'
    },
    'linux-script': {
        title: '🐧 Linux Script Download',
        sections: [
            {
                heading: 'What You Get',
                content: 'Just the <code>fleet-agent.sh</code> Bash script file. This is the core agent that communicates with the audit server.'
            },
            {
                heading: 'When to Use',
                list: [
                    'Quick testing or evaluation',
                    'You have your own deployment pipeline (e.g., existing Ansible roles)',
                    'You want to wrap it in your own service management',
                    'Manual one-off deployments'
                ]
            },
            {
                heading: 'Requirements',
                list: [
                    'Bash 4.0 or later',
                    'curl or wget',
                    'Network access to this audit server',
                    'Appropriate permissions based on audit scope'
                ]
            },
            {
                heading: 'Usage',
                code: './fleet-agent.sh --server-url "https://your-server:5000" --api-key "YOUR_KEY"'
            }
        ],
        tip: 'For automated deployments or non-root operation, use the <strong>Linux Package</strong>—it includes both root and user-mode installers.'
    },
    'windows-package': {
        title: '📦 Windows Package (Recommended)',
        sections: [
            {
                heading: 'What You Get',
                content: 'A ZIP archive containing everything needed for enterprise deployment:',
                list: [
                    '<code>fleet-agent.ps1</code> — The core agent script',
                    '<code>install-windows.ps1</code> — Multi-mode installer (User/Service/JEA)',
                    '<code>jea/</code> folder — JEA role capabilities and session config',
                    '<code>config.json</code> — Pre-filled configuration',
                    '<code>README.md</code> — Deployment documentation'
                ]
            },
            {
                heading: 'Installation Modes',
                list: [
                    '<strong>User Mode:</strong> <code>install-windows.ps1 -Mode User</code> — No admin needed, runs as current user',
                    '<strong>Service Mode:</strong> <code>install-windows.ps1 -Mode Service</code> — Runs as Windows service (requires admin)',
                    '<strong>JEA Mode:</strong> <code>install-windows.ps1 -Mode Full -EnableJEA</code> — Full install with Just Enough Administration'
                ]
            },
            {
                heading: 'Best For',
                list: [
                    'Microsoft Intune deployment',
                    'SCCM/MECM deployment',
                    'Group Policy deployment',
                    'Enterprise environments with AD/Entra'
                ]
            }
        ],
        tip: 'JEA (Just Enough Administration) allows the agent to run with minimal privileges. Configure JEA first with <code>jea\\setup-jea.ps1</code> before running the installer with <code>-EnableJEA</code>.'
    },
    'linux-package': {
        title: '📦 Linux Package (Recommended)',
        sections: [
            {
                heading: 'What You Get',
                content: 'A tar.gz archive containing everything needed for Linux deployment:',
                list: [
                    '<code>fleet-agent.sh</code> — The core agent script',
                    '<code>install-linux.sh</code> — Root/systemd installer',
                    '<code>install-user.sh</code> — Non-root user installer',
                    '<code>config.json</code> — Pre-filled configuration',
                    '<code>README.md</code> — Deployment documentation'
                ]
            },
            {
                heading: 'Installation Modes',
                list: [
                    '<strong>Root/Service Mode:</strong> <code>sudo ./install-linux.sh</code> — Installs as systemd service',
                    '<strong>User Mode:</strong> <code>./install-user.sh</code> — No root needed, runs as current user with cron'
                ]
            },
            {
                heading: 'Best For',
                list: [
                    'Ansible playbook deployment',
                    'Puppet/Chef configuration management',
                    'Terraform provisioning',
                    'Environments where root access is restricted'
                ]
            }
        ],
        tip: 'Use <code>install-user.sh</code> for cloud instances or containers where you don\'t have root access. It uses cron for scheduling instead of systemd.'
    },
    // Standalone Scripts
    'jea-setup': {
        title: '🔐 JEA Setup Script',
        sections: [
            {
                heading: 'What You Get',
                content: 'The <code>setup-jea.ps1</code> PowerShell script that configures a Just Enough Administration (JEA) endpoint for the audit agent.'
            },
            {
                heading: 'What is JEA?',
                content: 'JEA (Just Enough Administration) is a PowerShell security feature that restricts what commands users can run. This allows the audit agent to run with minimal privileges—only the specific cmdlets needed for security auditing.'
            },
            {
                heading: 'When to Use',
                list: [
                    'Enterprise environments with Active Directory',
                    'Azure/Entra ID environments',
                    'Zero-trust security requirements',
                    'When you need agent isolation from other processes',
                    'Compliance requirements (SOC2, ISO 27001, etc.)'
                ]
            },
            {
                heading: 'Requirements',
                list: [
                    'Windows Server 2016+ or Windows 10+',
                    'PowerShell 5.1 or later',
                    'Domain Admin (for AD) or local admin (for local JEA)',
                    'AD group or Entra ID group for authorized agents'
                ]
            },
            {
                heading: 'Usage',
                code: '# For Active Directory:\n.\\setup-jea.ps1 -GroupName "Audit-Agents"\n\n# For Entra ID:\n.\\setup-jea.ps1 -GroupName "Audit-Agents" -EntraIDGroup "group-object-id"'
            }
        ],
        tip: 'Run this script <strong>once</strong> on each target machine before deploying the agent with <code>-EnableJEA</code> flag. JEA endpoints persist across reboots.'
    },
    'install-user': {
        title: '👤 Linux User-Mode Installer',
        sections: [
            {
                heading: 'What You Get',
                content: 'The <code>install-user.sh</code> Bash script that installs the audit agent without requiring root/sudo access.'
            },
            {
                heading: 'How It Works',
                list: [
                    'Installs to <code>~/.local/audit-agent/</code>',
                    'Uses user crontab for scheduling (no systemd)',
                    'Runs with current user permissions',
                    'Stores logs in user home directory'
                ]
            },
            {
                heading: 'When to Use',
                list: [
                    'Shared hosting environments',
                    'Docker containers (non-root)',
                    'Cloud instances where you lack root access',
                    'Development/testing machines',
                    'When IT policy restricts sudo access'
                ]
            },
            {
                heading: 'Requirements',
                list: [
                    'Bash 4.0 or later',
                    'cron (usually pre-installed)',
                    'curl or wget',
                    'Write access to home directory'
                ]
            },
            {
                heading: 'Usage',
                code: './install-user.sh --server-url "https://your-server:5000" --api-key "YOUR_KEY"'
            }
        ],
        tip: 'Some audits may return limited results without root access. For full system auditing, use the root installer or configure sudoers for specific commands.'
    },
    'install-windows': {
        title: '🪟 Windows Multi-Mode Installer',
        sections: [
            {
                heading: 'What You Get',
                content: 'The <code>install-windows.ps1</code> PowerShell script that supports multiple installation modes: User, Service, and Full (with JEA).'
            },
            {
                heading: 'Installation Modes',
                list: [
                    '<strong>User Mode:</strong> No admin needed, runs as scheduled task',
                    '<strong>Service Mode:</strong> Runs as Windows Service (SYSTEM)',
                    '<strong>Full Mode:</strong> Service + JEA for minimal privileges'
                ]
            },
            {
                heading: 'When to Use',
                list: [
                    'You already have the agent script from elsewhere',
                    'You want to customize the installation process',
                    'Deploying via scripts to existing machines',
                    'Testing different installation modes'
                ]
            },
            {
                heading: 'Usage Examples',
                code: '# User mode (no admin):\n.\\install-windows.ps1 -Mode User -ServerUrl "https://server" -ApiKey "key"\n\n# Service mode (admin required):\n.\\install-windows.ps1 -Mode Service -ServerUrl "https://server" -ApiKey "key"\n\n# Full + JEA (after running setup-jea.ps1):\n.\\install-windows.ps1 -Mode Full -UseJEA -ServerUrl "https://server" -ApiKey "key"'
            }
        ],
        tip: 'For most deployments, download the <strong>Windows Package</strong> which includes this installer along with the agent script and JEA files.'
    },
    'install-linux': {
        title: '🐧 Linux Systemd Installer',
        sections: [
            {
                heading: 'What You Get',
                content: 'The <code>install-linux.sh</code> Bash script that installs the audit agent as a systemd service (requires root/sudo).'
            },
            {
                heading: 'How It Works',
                list: [
                    'Installs to <code>/opt/audit-agent/</code>',
                    'Creates systemd service unit',
                    'Runs as dedicated system user',
                    'Logs to system journal'
                ]
            },
            {
                heading: 'When to Use',
                list: [
                    'Production servers with root access',
                    'VMs provisioned with cloud-init',
                    'Containers running as root',
                    'Ansible/Puppet/Chef deployments'
                ]
            },
            {
                heading: 'Requirements',
                list: [
                    'Root/sudo access',
                    'systemd init system',
                    'Bash 4.0+',
                    'curl or wget'
                ]
            },
            {
                heading: 'Usage',
                code: 'sudo ./install-linux.sh "https://your-server:5000" "YOUR_API_KEY" "agent-id"'
            }
        ],
        tip: 'For environments without root access or systemd (containers, shared hosting), use the <strong>Linux User Install</strong> script instead.'
    },
    // Hypervisor Agent Downloads
    'hypervisor-linux-package': {
        title: '🐧 Linux/ESXi Hypervisor Agent Package',
        sections: [
            {
                heading: 'What You Get',
                content: 'A tar.gz archive containing the hypervisor agent with platform-specific modules:',
                list: [
                    '<code>hypervisor-agent.sh</code> — Main agent script',
                    '<code>install.sh</code> — Installation script (systemd)',
                    '<code>config.json</code> — Pre-configured for selected platform',
                    '<code>platforms/</code> — Platform-specific audit modules (ESXi, Proxmox, XCP-ng, KVM, Nutanix)',
                    '<code>README.md</code> — Installation and usage guide'
                ]
            },
            {
                heading: 'Supported Platforms',
                list: [
                    '<strong>VMware ESXi:</strong> Uses esxcli, vim-cmd for VM/host auditing',
                    '<strong>Proxmox VE:</strong> Uses pvesh, qm, pct for cluster auditing',
                    '<strong>XCP-ng/Xen:</strong> Uses xe CLI for pool management',
                    '<strong>KVM/libvirt:</strong> Uses virsh for VM auditing',
                    '<strong>Nutanix AHV:</strong> Uses acli, ncli for cluster auditing'
                ]
            },
            {
                heading: 'Installation',
                code: '# Extract package\ntar -xzf hypervisor-agent-linux.tar.gz\ncd hypervisor-agent\n\n# Edit config.json with your server URL\nnano config.json\n\n# Install as service\nsudo ./install.sh'
            }
        ],
        tip: 'After installation, register the agent using a token from the Hypervisors tab: <code>./hypervisor-agent.sh register --token YOUR_TOKEN</code>'
    },
    'hypervisor-windows-package': {
        title: '🪟 Windows/Hyper-V Agent Package',
        sections: [
            {
                heading: 'What You Get',
                content: 'A ZIP archive containing the Hyper-V specific agent:',
                list: [
                    '<code>hypervisor-agent.ps1</code> — Main agent script',
                    '<code>install.ps1</code> — Installation script (scheduled task or service)',
                    '<code>config.json</code> — Pre-configured for Hyper-V',
                    '<code>platforms/</code> — Hyper-V specific audit modules',
                    '<code>README.md</code> — Installation and usage guide'
                ]
            },
            {
                heading: 'Hyper-V Features',
                list: [
                    'VM inventory and state monitoring',
                    'Virtual switch configuration auditing',
                    'Hyper-V Replica status checks',
                    'Cluster Shared Volumes auditing',
                    'BitLocker integration verification',
                    'RBAC permission auditing'
                ]
            },
            {
                heading: 'Installation',
                code: '# Extract package\nExpand-Archive hypervisor-agent-windows.zip\ncd hypervisor-agent\n\n# Edit config.json with your server URL\nnotepad config.json\n\n# Install as scheduled task (run as admin)\n.\\install.ps1'
            }
        ],
        tip: 'Run PowerShell as Administrator for installation. The agent will be installed as a scheduled task running as SYSTEM.'
    },
    'hypervisor-linux-script': {
        title: '📄 Linux Hypervisor Agent Script',
        sections: [
            {
                heading: 'What You Get',
                content: 'Just the <code>hypervisor-agent.sh</code> Bash script. Use this if you have your own deployment method or want to test manually.'
            },
            {
                heading: 'When to Use',
                list: [
                    'Quick testing or evaluation',
                    'You have existing infrastructure automation',
                    'Manual one-off deployments',
                    'Custom installation requirements'
                ]
            },
            {
                heading: 'Requirements',
                list: [
                    'Bash 4.0+',
                    'Python 3.6+ (for platform modules)',
                    'curl or wget',
                    'Platform-specific CLI tools (esxcli, pvesh, xe, virsh)'
                ]
            },
            {
                heading: 'Usage',
                code: './hypervisor-agent.sh --server-url "https://server:5000" --api-key "KEY" --platform esxi'
            }
        ],
        tip: 'For production deployments, use the <strong>Linux/ESXi Package</strong> which includes install scripts and platform modules.'
    },
    'hypervisor-windows-script': {
        title: '📄 Windows Hypervisor Agent Script',
        sections: [
            {
                heading: 'What You Get',
                content: 'Just the <code>hypervisor-agent.ps1</code> PowerShell script. Use this if you have your own deployment method or want to test manually.'
            },
            {
                heading: 'When to Use',
                list: [
                    'Quick testing or evaluation',
                    'Integration with existing deployment tools',
                    'Manual one-off deployments',
                    'Custom installation requirements'
                ]
            },
            {
                heading: 'Requirements',
                list: [
                    'PowerShell 5.1+',
                    'Hyper-V PowerShell module',
                    'Administrator privileges',
                    'Network access to audit server'
                ]
            },
            {
                heading: 'Usage',
                code: '.\\hypervisor-agent.ps1 -ServerUrl "https://server:5000" -ApiKey "KEY" -Action run'
            }
        ],
        tip: 'For production deployments, use the <strong>Windows/Hyper-V Package</strong> which includes install scripts and service configuration.'
    }
};

/**
 * Help content for deployment types (Full Toolkit, Lightweight, etc.)
 */
const deployTypeHelpContent = {
    'full': {
        title: '🔧 Full Toolkit Deployment',
        sections: [
            {
                heading: 'What It Includes',
                content: 'The complete security audit framework deployed to target servers:',
                list: [
                    '<strong>All Audit Scripts</strong> — 125+ security checks across 7 domains',
                    '<strong>Orchestrator</strong> — Meta-runner for batch execution',
                    '<strong>Complete Libraries</strong> — All compatibility shims (distro, pkg, svc, firewall)',
                    '<strong>Documentation</strong> — Audit authoring guides and API reference'
                ]
            },
            {
                heading: 'How It Deploys',
                list: [
                    'Connects via SSH (Linux) or WinRM (Windows)',
                    'Copies entire toolkit to <code>/opt/audit-toolkit</code> or <code>C:\Program Files\SecurityAuditToolkit</code>',
                    'Sets up shell aliases for easy execution',
                    'Optionally configures scheduled runs'
                ]
            },
            {
                heading: 'Best For',
                list: [
                    'Full security assessments',
                    'Servers where you need all audit categories',
                    'Development/test environments',
                    'When you want orchestrator for multi-domain scans'
                ]
            },
            {
                heading: 'Package Size',
                content: 'Approximately <strong>5-10 MB</strong> including all scripts, libraries, and documentation.'
            }
        ],
        tip: 'The orchestrator allows filtering by domain (<code>--domain platform</code>) or pattern (<code>--match nginx</code>), so deploying full toolkit gives maximum flexibility.'
    },
    'lightweight': {
        title: '⚡ Standalone Agent Deployment',
        sections: [
            {
                heading: 'What It Includes',
                content: 'A minimal, self-contained scanner optimized for headless servers:',
                list: [
                    '<strong>Web UI</strong> — Browser-based configuration and results',
                    '<strong>Setup Wizard</strong> — Guided first-run configuration',
                    '<strong>Cron Scheduling</strong> — Automatic periodic scans',
                    '<strong>Silent Mode</strong> — Invisible background execution',
                    '<strong>Docker Support</strong> — Pre-built container images'
                ]
            },
            {
                heading: 'How It Deploys',
                list: [
                    'Copies standalone agent to target',
                    'Installs as systemd service (Linux) or Windows Service',
                    'Optional: Configures cron/scheduled task',
                    'Optional: Sets up Docker container'
                ]
            },
            {
                heading: 'Best For',
                list: [
                    'Headless servers without interactive access',
                    'Scheduled/automated security scans',
                    'Environments with limited disk space',
                    'Docker/container deployments'
                ]
            },
            {
                heading: 'Package Size',
                content: 'Approximately <strong>1-2 MB</strong> — significantly smaller than full toolkit.'
            }
        ],
        tip: 'Lightweight agent includes a web UI on port 8080 for configuration. Access via <code>http://hostname:8080</code> after deployment.'
    },
    'agent': {
        title: '🤖 Standalone Agent Deployment',
        sections: [
            {
                heading: 'What It Does',
                content: 'A self-contained agent for secure environments where remote access must be disabled after deployment:',
                list: [
                    '<strong>One-time Remote Deploy</strong> — Deploys via SSH/WinRM, then works independently',
                    '<strong>Scheduled Execution</strong> — Runs audits on a schedule without external triggers',
                    '<strong>API Result Upload</strong> — Pushes results to central server via HTTPS',
                    '<strong>Local Storage</strong> — Can store results locally if offline'
                ]
            },
            {
                heading: 'How It Works',
                list: [
                    '1. Deploy agent via SSH/WinRM (one-time)',
                    '2. Agent installs as service with scheduled task',
                    '3. Disable SSH/WinRM for security',
                    '4. Agent continues to run audits and upload results via API'
                ]
            },
            {
                heading: 'Best For',
                list: [
                    'Air-gapped or highly secured networks',
                    'PCI-DSS environments requiring disabled remote access',
                    'Hosts behind restrictive firewalls',
                    'Security-sensitive production systems'
                ]
            },
            {
                heading: 'Configuration',
                content: 'Configure server URL and API key during deployment. Results upload automatically on schedule.'
            }
        ],
        tip: 'The standalone agent is ideal for compliance scenarios (PCI-DSS, HIPAA) where SSH/WinRM must be disabled on production hosts.'
    },
    'fleet-agent': {
        title: '🔗 Fleet Agent Deployment',
        sections: [
            {
                heading: 'What It Does',
                content: 'A two-way API agent designed for enterprise deployment tools:',
                list: [
                    '<strong>Two-Way API Communication</strong> — Receives commands AND sends results',
                    '<strong>Multi-Mode Installer</strong> — User mode, Service mode, or JEA mode',
                    '<strong>Enterprise Ready</strong> — Designed for Intune, SCCM, Ansible, GPO',
                    '<strong>JEA Support</strong> — Run with minimal privileges on Windows'
                ]
            },
            {
                heading: 'Installation Modes',
                list: [
                    '<strong>User Mode:</strong> No admin required, runs as current user (task scheduler)',
                    '<strong>Service Mode:</strong> Runs as Windows Service or systemd service',
                    '<strong>JEA Mode:</strong> Windows-only, uses Just Enough Administration for minimal privileges'
                ]
            },
            {
                heading: 'Best For',
                list: [
                    'Microsoft Intune / SCCM deployments',
                    'Ansible / Puppet / Terraform automation',
                    'Environments where users lack admin rights',
                    'Enterprise zero-trust security policies'
                ]
            },
            {
                heading: 'Deployment Options',
                content: 'Download pre-configured packages from the Fleet Agent Configuration section below. Choose Windows or Linux packages with multi-mode installers included.'
            }
        ],
        tip: 'Use the download section below to get agent packages. The Windows Package includes JEA setup scripts for enterprise deployments.'
    },
    'hypervisor-agent': {
        title: '🖥️ Hypervisor Agent Deployment',
        sections: [
            {
                heading: 'What It Does',
                content: 'A purpose-built agent specifically designed for hypervisor platforms:',
                list: [
                    '<strong>Platform-Specific Modules</strong> — Specialized audit modules for ESXi, Proxmox, XCP-ng, Hyper-V, KVM, Nutanix',
                    '<strong>VM Discovery</strong> — Automatic discovery and inventory of virtual machines',
                    '<strong>Host Metrics</strong> — CPU, memory, storage utilization from hypervisor level',
                    '<strong>Security Auditing</strong> — Hypervisor-specific security configuration checks'
                ]
            },
            {
                heading: 'Supported Platforms',
                list: [
                    '<strong>VMware:</strong> ESXi hosts and vCenter Server',
                    '<strong>Proxmox:</strong> Proxmox VE clusters',
                    '<strong>XCP-ng / Xen:</strong> XenServer and XCP-ng pools',
                    '<strong>Microsoft:</strong> Hyper-V hosts and clusters',
                    '<strong>KVM:</strong> libvirt-based KVM hosts',
                    '<strong>Nutanix:</strong> Nutanix AHV clusters'
                ]
            },
            {
                heading: 'Best For',
                list: [
                    'Hypervisor infrastructure auditing',
                    'VM inventory and compliance tracking',
                    'Datacenter security assessments',
                    'Multi-platform hypervisor environments'
                ]
            },
            {
                heading: 'Key Differences from Fleet Agent',
                content: '<strong>This is NOT the standard fleet agent.</strong> The Hypervisor Agent includes specialized modules for hypervisor APIs and does not run on regular Linux/Windows hosts.'
            }
        ],
        tip: 'Use the Hypervisors tab for full registration workflow. Download packages include platform-specific audit modules for your selected hypervisor type.'
    }
};

/**
 * Help content for deployment scripts (Intune, SCCM, etc.)
 */
const deploymentHelpContent = {
    'intune': {
        title: '📱 Microsoft Intune Deployment',
        sections: [
            {
                heading: 'Overview',
                content: 'Deploy the audit agent to Windows devices managed by Microsoft Intune (Endpoint Manager). The agent can be deployed as a Win32 app or PowerShell script.'
            },
            {
                heading: 'Prerequisites',
                list: [
                    'Microsoft Intune license (part of Microsoft 365)',
                    'Windows 10/11 devices enrolled in Intune',
                    'Admin access to Microsoft Endpoint Manager',
                    'Download the <strong>Windows Package</strong> (ZIP)'
                ]
            },
            {
                heading: 'Deployment Steps',
                list: [
                    '1. Download the Windows Package (ZIP)',
                    '2. Click "Intune" button to get the deployment script',
                    '3. In Endpoint Manager: Devices → Scripts → Add',
                    '4. Upload the PowerShell script',
                    '5. Assign to device groups',
                    '6. Monitor deployment status in Intune'
                ]
            },
            {
                heading: 'Recommended Settings',
                list: [
                    'Run script in 64-bit PowerShell: <strong>Yes</strong>',
                    'Run as logged-on user: <strong>No</strong> (for Service mode)',
                    'Enforce script signature check: <strong>No</strong> (or sign the script)'
                ]
            }
        ],
        tip: 'For JEA deployment via Intune, deploy the JEA setup script first as a separate staged deployment, then deploy the agent.'
    },
    'sccm': {
        title: '🖥️ SCCM/MECM Deployment',
        sections: [
            {
                heading: 'Overview',
                content: 'Deploy using Microsoft System Center Configuration Manager (SCCM) or Microsoft Endpoint Configuration Manager (MECM) for on-premises Windows management.'
            },
            {
                heading: 'Prerequisites',
                list: [
                    'SCCM/MECM infrastructure with client agents',
                    'Windows devices managed by Configuration Manager',
                    'Application packaging rights',
                    'Download the <strong>Windows Package</strong> (ZIP)'
                ]
            },
            {
                heading: 'Deployment Steps',
                list: [
                    '1. Download the Windows Package (ZIP)',
                    '2. Click "SCCM" button to get deployment script templates',
                    '3. Create a new Application in SCCM console',
                    '4. Package the ZIP with the install script',
                    '5. Set detection method (check for installed files)',
                    '6. Create deployment to target collection'
                ]
            },
            {
                heading: 'Detection Method',
                content: 'Configure detection to check for:',
                code: 'C:\\ProgramData\\AuditAgent\\fleet-agent.ps1'
            }
        ],
        tip: 'Use a Task Sequence for complex deployments that require JEA configuration before agent installation.'
    },
    'ansible': {
        title: '📜 Ansible Deployment',
        sections: [
            {
                heading: 'Overview',
                content: 'Deploy using Ansible playbooks for agentless, push-based configuration management across Linux and Windows servers.'
            },
            {
                heading: 'Prerequisites',
                list: [
                    'Ansible control node (Linux recommended)',
                    'SSH access to Linux targets / WinRM access to Windows targets',
                    'Inventory file with target hosts',
                    'Download the <strong>Linux Package</strong> or <strong>Windows Package</strong>'
                ]
            },
            {
                heading: 'Deployment Steps',
                list: [
                    '1. Click "Ansible" button to get the playbook templates',
                    '2. Customize variables (server_url, api_key)',
                    '3. Update your inventory file',
                    '4. Run: <code>ansible-playbook -i inventory audit-agent.yml</code>'
                ]
            },
            {
                heading: 'Playbook Features',
                list: [
                    'Copies agent files to target',
                    'Configures server connection settings',
                    'Installs as systemd service (Linux) or Windows Service',
                    'Supports check mode for dry runs'
                ]
            }
        ],
        tip: 'Use Ansible Vault to encrypt the API key: <code>ansible-vault encrypt_string \'your-api-key\' --name \'audit_api_key\'</code>'
    },
    'puppet': {
        title: '🎭 Puppet Deployment',
        sections: [
            {
                heading: 'Overview',
                content: 'Deploy using Puppet for declarative, model-driven configuration management with enforcement of desired state.'
            },
            {
                heading: 'Prerequisites',
                list: [
                    'Puppet master/server infrastructure',
                    'Puppet agent running on target nodes',
                    'Module development environment (PDK recommended)',
                    'Download the <strong>Linux Package</strong> or <strong>Windows Package</strong>'
                ]
            },
            {
                heading: 'Deployment Steps',
                list: [
                    '1. Click "Puppet" button to get the module template',
                    '2. Create module: <code>pdk new module audit_agent</code>',
                    '3. Add the provided manifest to init.pp',
                    '4. Configure Hiera data for server_url and api_key',
                    '5. Classify nodes that should receive the agent',
                    '6. Run Puppet agent: <code>puppet agent -t</code>'
                ]
            },
            {
                heading: 'Module Features',
                list: [
                    'Manages agent files with File resources',
                    'Configures service with Service resource',
                    'Supports Hiera data lookups for configuration',
                    'Works on both Linux and Windows'
                ]
            }
        ],
        tip: 'Store sensitive data like API keys in Hiera with eyaml encryption.'
    },
    'terraform': {
        title: '🏗️ Terraform Deployment',
        sections: [
            {
                heading: 'Overview',
                content: 'Deploy the audit agent during infrastructure provisioning with Terraform. Ideal for cloud environments and immutable infrastructure.'
            },
            {
                heading: 'Prerequisites',
                list: [
                    'Terraform installed (v1.0+)',
                    'Cloud provider credentials configured',
                    'Download the <strong>Linux Package</strong> or <strong>Windows Package</strong>'
                ]
            },
            {
                heading: 'Deployment Methods',
                list: [
                    '<strong>User Data:</strong> Include agent installation in EC2/VM user data script',
                    '<strong>Provisioner:</strong> Use remote-exec or local-exec provisioners',
                    '<strong>Cloud-Init:</strong> Add to cloud-init configuration for Linux VMs'
                ]
            },
            {
                heading: 'Example: AWS EC2 with User Data',
                code: `resource "aws_instance" "server" {
  user_data = <<-EOF
    #!/bin/bash
    curl -o agent.tar.gz "https://your-server/api/agent/download/linux?format=package"
    tar -xzf agent.tar.gz
    cd audit-agent && ./install-linux.sh
  EOF
}`
            }
        ],
        tip: 'Use Terraform variables or secrets management (Vault, AWS Secrets Manager) for API keys—never hardcode in .tf files.'
    }
};

/**
 * Show help modal for a download option
 * @param {string} type - 'windows-script', 'linux-script', 'windows-package', 'linux-package'
 */
function showDownloadHelp(type) {
    const content = downloadHelpContent[type];
    if (!content) {
        console.error(`Unknown download help type: ${type}`);
        return;
    }
    showInlineHelpModal(content);
}

/**
 * Show help modal for a deployment type
 * @param {string} type - 'intune', 'sccm', 'ansible', 'puppet', 'terraform'
 */
function showDeploymentHelp(type) {
    const content = deploymentHelpContent[type];
    if (!content) {
        console.error(`Unknown deployment help type: ${type}`);
        return;
    }
    showInlineHelpModal(content);
}

/**
 * Show help modal for a deployment type (Full Toolkit, Lightweight, etc.)
 * @param {string} type - 'full', 'lightweight', 'scripts', 'agent', 'fleet-agent'
 */
function showDeployTypeHelp(type) {
    const content = deployTypeHelpContent[type];
    if (!content) {
        console.error(`Unknown deploy type help: ${type}`);
        return;
    }
    showInlineHelpModal(content);
}

/**
 * Generic inline help modal display function (for download/deployment help)
 * @param {Object} content - Help content object with title, sections, and tip
 */
function showInlineHelpModal(content) {
    // Build sections HTML
    let sectionsHtml = '';
    for (const section of content.sections) {
        sectionsHtml += '<div class="help-modal-section">';
        sectionsHtml += `<h4>${section.heading}</h4>`;

        if (section.content) {
            sectionsHtml += `<p>${section.content}</p>`;
        }

        if (section.list) {
            sectionsHtml += '<ul>';
            for (const item of section.list) {
                sectionsHtml += `<li>${item}</li>`;
            }
            sectionsHtml += '</ul>';
        }

        if (section.code) {
            sectionsHtml += `<pre>${escapeHtml(section.code)}</pre>`;
        }

        sectionsHtml += '</div>';
    }

    // Add tip if present
    let tipHtml = '';
    if (content.tip) {
        tipHtml = `<div class="help-tip">💡 <strong>Tip:</strong> ${content.tip}</div>`;
    }

    // Create modal
    const overlay = document.createElement('div');
    overlay.className = 'help-modal-overlay';
    overlay.innerHTML = `
        <div class="help-modal">
            <div class="help-modal-header">
                <h3>${content.title}</h3>
                <button class="help-modal-close" onclick="this.closest('.help-modal-overlay').remove()">×</button>
            </div>
            <div class="help-modal-content">
                ${sectionsHtml}
                ${tipHtml}
            </div>
        </div>
    `;

    // Close on overlay click
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) overlay.remove();
    });

    // Close on Escape key
    const escHandler = (e) => {
        if (e.key === 'Escape') {
            overlay.remove();
            document.removeEventListener('keydown', escHandler);
        }
    };
    document.addEventListener('keydown', escHandler);

    document.body.appendChild(overlay);
}

/**
 * Download fleet agent script or package
 * @param {string} osType - 'windows' or 'linux'
 * @param {string} format - 'raw' or 'package'
 */
function downloadFleetAgent(osType, format) {
    const config = getFleetAgentConfig();
    let url = `${API_BASE}/api/agent/download/${osType}?format=${format}`;

    if (config.server_url) {
        url += `&server_url=${encodeURIComponent(config.server_url)}`;
    }

    // Use apiFetch to ensure credentials (session cookie) are always sent
    apiFetch(url)
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || `HTTP ${response.status}: ${response.statusText}`);
                }).catch(e => {
                    throw new Error(`Download failed with status ${response.status}`);
                });
            }
            const contentDisposition = response.headers.get('content-disposition') || '';
            const filenameMatch = contentDisposition.match(/filename="?([^";]+)"?/i);
            const headerFilename = filenameMatch ? filenameMatch[1] : null;
            return response.blob().then(blob => ({ blob, headerFilename }));
        })
        .then(({ blob, headerFilename }) => {
            let filename = headerFilename;
            if (!filename) {
                if (format === 'package') {
                    filename = osType === 'windows' ? 'fleet-agent-windows.zip' : 'fleet-agent-linux.tar.gz';
                } else {
                    filename = osType === 'windows' ? 'fleet-agent.ps1' : 'fleet-agent.sh';
                }
            }
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        })
        .catch(error => {
            console.error('Managed agent download failed:', error);
            alert(`❌ Download Failed: ${error.message}`);
        });
}

function downloadToolkitPackage(deployType, platform, packageFormat = null) {
    const link = document.createElement('a');
    let url = `${API_BASE}/api/deploy/package/${encodeURIComponent(deployType)}?platform=${encodeURIComponent(platform)}`;
    if (packageFormat) {
        url += `&package_format=${encodeURIComponent(packageFormat)}`;
    }
    link.href = url;
    link.download = '';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

/**
 * Download unified host agent runtime package (managed API or standalone scheduled mode)
 * @param {string} platform - 'linux' or 'windows'
 */
function downloadJREConsolidatedAgent(platform) {
    const modeSelect = document.getElementById('jre-agent-mode');
    const mode = modeSelect ? modeSelect.value : 'standalone';

    const config = getFleetAgentConfig();
    let url = `${API_BASE}/api/agent/jre/download/${platform}?mode=${encodeURIComponent(mode)}`;

    if (config.server_url && mode === 'managed') {
        url += `&server_url=${encodeURIComponent(config.server_url)}`;
    }
    if (config.api_key && mode === 'managed') {
        url += `&api_key=${encodeURIComponent(config.api_key)}`;
    }

    // Use apiFetch to ensure credentials (session cookie) are always sent
    apiFetch(url)
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || `HTTP ${response.status}: ${response.statusText}`);
                }).catch(e => {
                    throw new Error(`Download failed with status ${response.status}`);
                });
            }
            return response.blob();
        })
        .then(blob => {
            const filename = platform === 'windows' ? `unified-jre-agent-${mode}-windows.zip` : `unified-jre-agent-${mode}-linux.tar.gz`;
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        })
        .catch(error => {
            console.error('JRE consolidated agent download failed:', error);
            alert(`❌ Download Failed: ${error.message}`);
        });
}

function downloadStandaloneAgentPackage(platform) {
    const link = document.createElement('a');
    link.href = `${API_BASE}/api/deploy/agent/download/${encodeURIComponent(platform)}`;
    link.download = '';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

/**
 * Download pre-configured installer for fleet agent
 * @param {string} osType - 'windows' or 'linux'
 */
function downloadFleetAgentInstaller(osType) {
    const config = getFleetAgentConfig();
    let url = `${API_BASE}/api/agent/download/installer/${osType}?`;

    const params = new URLSearchParams();
    if (config.server_url) params.set('server_url', config.server_url);
    if (config.api_key) params.set('api_key', config.api_key);
    params.set('auto_start', 'true');

    url += params.toString();

    // Use apiFetch to ensure credentials (session cookie) are always sent
    apiFetch(url)
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || `HTTP ${response.status}: ${response.statusText}`);
                }).catch(e => {
                    throw new Error(`Download failed with status ${response.status}`);
                });
            }
            return response.blob();
        })
        .then(blob => {
            const filename = osType === 'windows' ? 'audit-agent-installer.zip' : 'audit-agent-installer.tar.gz';
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        })
        .catch(error => {
            console.error('Managed agent installer download failed:', error);
            alert(`❌ Download Failed: ${error.message}`);
        });
}

/**
 * Download standalone script (JEA setup, user installer, etc.)
 * @param {string} scriptType - standalone helper or bundle identifier from /api/agent/download/standalone/<script_type>
 */
function downloadStandaloneScript(scriptType) {
    const filenames = {
        'jea-setup': 'setup-jea.ps1',
        'jea-session-config': 'AuditAgent.pssc',
        'jea-role-full': 'AuditAgent.Full.psrc',
        'jea-role-readonly': 'AuditAgent.ReadOnly.psrc',
        'setup-sudoers-linux': 'setup-sudoers.sh',
        'install-user': 'install-user.sh',
        'install-windows': 'install-windows.ps1',
        'install-linux': 'install-linux.sh',
        'run-audit-wrapper': 'run-audit-wrapper.sh',
        'run-audit-jer': 'run-audit-jer.ps1',
        'invoke-security-audit-jea': 'Invoke-SecurityAuditJEA.ps1',
        'winrm-jea-wrapper-bundle': 'windows-jea-winrm-wrapper-bundle.zip',
        'ssh-sudo-wrapper-bundle': 'linux-ssh-sudo-wrapper-bundle.tar.gz',
        'rebuild-vm-appliance': 'rebuild-vm-appliance.ps1',
        'split-artifact-for-git': 'split-artifact-for-git.ps1',
        'precheck-winrm-target': 'precheck-winrm-target.ps1',
        'precheck-ssh-target': 'precheck-ssh-target.ps1',
        'prep-linux-target-expected-state': 'prep-linux-target-expected-state.sh',
        'setup-linux-ssh-key-access': 'setup-linux-ssh-key-access.sh',
        'direct-api-linux-host-setup': 'setup-direct-api-linux-host.sh',
        'direct-api-windows-host-setup': 'setup-direct-api-windows-host.ps1'
    };

    const url = `${API_BASE}/api/agent/download/standalone/${scriptType}`;

    // Use apiFetch to ensure credentials (session cookie) are always sent
    apiFetch(url)
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || `HTTP ${response.status}: ${response.statusText}`);
                }).catch(e => {
                    throw new Error(`Download failed with status ${response.status}`);
                });
            }
            return response.blob();
        })
        .then(blob => {
            const filename = filenames[scriptType] || `${scriptType}.sh`;
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        })
        .catch(error => {
            console.error('Standalone script download failed:', error);
            alert(`❌ Download Failed: ${error.message}`);
        });
}

/**
 * Download hypervisor agent package or script
 * This is specifically for hypervisor platforms (ESXi, Proxmox, XCP-ng, Hyper-V)
 * NOT to be confused with the standard fleet agent for hosts.
 *
 * @param {string} osType - 'linux' or 'windows'
 * @param {string} format - 'package' (full package) or 'script' (agent script only)
 */
function downloadHypervisorAgent(osType, format) {
    // Get platform from the config panel if available
    const platformSelect = document.getElementById('hypervisor-agent-platform') ||
                          document.getElementById('new-agent-platform');
    const platform = platformSelect ? platformSelect.value : 'generic';

    const keyValiditySelect = document.getElementById('hypervisor-agent-key-validity') ||
                             document.getElementById('new-agent-key-validity');
    const keyValidity = keyValiditySelect ? keyValiditySelect.value : '90';

    let url = `${API_BASE}/api/hypervisor-agent/download/${osType}?format=${format}`;
    url += `&platform=${encodeURIComponent(platform)}`;
    url += `&key_validity=${encodeURIComponent(keyValidity)}`;

    // Determine filename based on format and OS
    let filename;
    if (format === 'package') {
        filename = osType === 'windows' ? 'hypervisor-agent-windows.zip' : 'hypervisor-agent-linux.tar.gz';
    } else {
        filename = osType === 'windows' ? 'hypervisor-agent.ps1' : 'hypervisor-agent.sh';
    }

    // Use apiFetch to ensure credentials (session cookie) are always sent
    apiFetch(url)
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    // Check for specific license error message
                    if (data.code === 'ENTERPRISE_LICENSE_REQUIRED') {
                        throw new Error(`Enterprise License Required: ${data.message || 'Hypervisor agent requires an enterprise license.'}`);
                    }
                    throw new Error(data.error || data.message || `HTTP ${response.status}: ${response.statusText}`);
                }).catch(e => {
                    if (e.message.startsWith('Enterprise License')) {
                        throw e;
                    }
                    throw new Error(`Download failed with status ${response.status}`);
                });
            }
            return response.blob();
        })
        .then(blob => {
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        })
        .catch(error => {
            console.error('Hypervisor agent download failed:', error);
            alert(`❌ Download Failed: ${error.message}`);
        });
}

/**
 * Show deployment script for specific platform
 * @param {string} platform - 'intune', 'sccm', 'ansible', 'puppet', 'terraform'
 */
async function showDeploymentScript(platform) {
    const config = getFleetAgentConfig();
    const osType = platform === 'intune' || platform === 'sccm' ? 'windows' : 'linux';

    try {
        const response = await apiFetch(
            `${API_BASE}/api/agent/download/deployment-scripts?platform=${platform}&os_type=${osType}`
        );
        const data = await response.json();

        if (data.error) {
            alert(`Error: ${data.error}`);
            return;
        }

        // Show scripts in a modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:10000;display:flex;align-items:center;justify-content:center;';

        let scriptsHtml = '';
        for (const [name, content] of Object.entries(data.scripts)) {
            scriptsHtml += `
                <div style="margin-bottom:20px;">
                    <h4 style="color:var(--accent-color);margin-bottom:10px;">${name}</h4>
                    <pre style="background:var(--bg-primary);padding:15px;border-radius:6px;overflow-x:auto;max-height:300px;font-size:12px;">${escapeHtml(content)}</pre>
                    <button class="btn btn-small" onclick="copyToClipboard(this.previousElementSibling.textContent)">📋 Copy</button>
                </div>
            `;
        }

        modal.innerHTML = `
            <div style="background:var(--bg-card);padding:25px;border-radius:12px;max-width:800px;max-height:90vh;overflow-y:auto;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                    <h3>${platform.toUpperCase()} Deployment Scripts</h3>
                    <button class="btn btn-small" onclick="this.closest('.modal').remove()">✕ Close</button>
                </div>
                <p style="color:var(--text-secondary);margin-bottom:20px;">
                    Replace placeholder values (your-server, YOUR_KEY, etc.) with your actual configuration.
                </p>
                ${scriptsHtml}
            </div>
        `;

        document.body.appendChild(modal);
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });

    } catch (error) {
        alert(`Failed to load deployment scripts: ${error.message}`);
    }
}

/**
 * Copy text to clipboard
 */
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        // Brief visual feedback could be added here
        console.log('Copied to clipboard');
    }).catch(err => {
        console.error('Failed to copy:', err);
    });
}

// Helper function for escaping HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function deployToServers() {
    if (selectedServers.size === 0) {
        alert('Please select at least one server');
        return;
    }

    const deployType = getSelectedDeployType();
    const typeLabels = {
        'full': 'full toolkit',
        'lightweight': 'lightweight html package',
        'jre-agent': 'unified host agent runtime',
        'hypervisor-agent': 'hypervisor agent'
    };

    if (deployType === 'hypervisor-agent') {
        alert('Hypervisor agent remote deployment is not available in this panel. Use Download Packages for hypervisor artifacts.');
        return;
    }

    const typeLabel = typeLabels[deployType] || 'toolkit';

    if (!confirm(`Deploy ${typeLabel} to ${selectedServers.size} selected server(s)?`)) {
        return;
    }

    try {
        // Use different endpoint for agent deployment types
        let endpoint;
        if (deployType === 'jre-agent') {
            endpoint = `${API_BASE}/api/deploy/jre-agent`;
        } else {
            endpoint = `${API_BASE}/api/deploy`;
        }

        const body = {
            server_ids: Array.from(selectedServers),
            deploy_type: deployType
        };

        // Include JRE agent config if deploying JRE agent
        if (deployType === 'jre-agent') {
            body.config = getJREAgentConfig();
        }

        const response = await apiFetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        const data = await response.json();

        if (data.success) {
            document.getElementById('deployment-output').style.display = 'block';
            document.getElementById('deployment-output').classList.remove('d-none');
            document.getElementById('deploy-progress').textContent = '';
            updateDeployStatus('running');
            startDeploymentPolling();
        } else {
            alert('Failed to start deployment: ' + data.error);
        }
    } catch (error) {
        alert('Error starting deployment: ' + error.message);
    }
}

function startDeploymentPolling() {
    if (deploymentPolling) clearInterval(deploymentPolling);

    deploymentPolling = setInterval(async () => {
        await checkDeploymentStatus();
    }, POLLING_CONFIG.DEPLOYMENT_STATUS);
}

function stopDeploymentPolling() {
    if (deploymentPolling) {
        clearInterval(deploymentPolling);
        deploymentPolling = null;
    }
}

async function checkDeploymentStatus() {
    try {
        const response = await apiFetch(`${API_BASE}/api/deploy/status`);
        const data = await response.json();

        if (data.success) {
            // Update progress display
            const progress = data.progress.map(p => `[${new Date(p.timestamp).toLocaleTimeString()}] ${p.message}`).join('\n');
            const progressDisplay = document.getElementById('deploy-progress');
            progressDisplay.textContent = progress;
            progressDisplay.scrollTop = progressDisplay.scrollHeight;

            if (!data.deploying && deploymentPolling) {
                stopDeploymentPolling();
                updateDeployStatus('complete');
            }
        }
    } catch (error) {
        console.error('Error checking deployment status:', error);
    }
}

function updateDeployStatus(status) {
    const badge = document.getElementById('deploy-status');
    badge.className = `status-badge status-${status}`;
    badge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
}

// ============================================================================
// Reporting & Log Analysis
// ============================================================================

let currentReport = null;
let selectedReportServers = new Set();
let reportsGeneratedToday = 0;
let cachedReportServers = [];  // Cache servers for filtering
let reportServerSearchFilter = '';
let reportingBackfillHistory = [];

/**
 * Load and display the System Health Report
 */
async function loadHealthReport() {
    const grid = document.getElementById('health-components-grid');
    const overallStatus = document.getElementById('health-overall-status');
    const timestamp = document.getElementById('health-report-time');
    const auditCount = document.getElementById('health-audit-count');

    if (!grid) return; // Element not present

    grid.innerHTML = '<div class="reports-health-loading">Loading health status...</div>';

    try {
        // Fetch health status
        const healthResponse = await apiFetch(`${API_BASE}/health`);
        const healthData = await healthResponse.json();

        // Update timestamp
        if (timestamp) {
            timestamp.textContent = new Date().toLocaleString();
        }

        // Update overall status
        if (overallStatus) {
            const isHealthy = healthData.status === 'healthy';
            overallStatus.innerHTML = `
                <span class="health-status-icon ${isHealthy ? 'healthy' : 'unhealthy'}">${isHealthy ? '✅' : '⚠️'}</span>
                <span class="health-status-text">${isHealthy ? 'All Systems Operational' : 'Issues Detected'}</span>
            `;
        }

        // Build component cards
        const components = healthData.checks || healthData.dependencies || {};
        let html = '';

        for (const [name, info] of Object.entries(components)) {
            const status = info.status === 'healthy' || info.available;
            const statusClass = status ? 'healthy' : 'unhealthy';
            const icon = getComponentIcon(name);
            const displayName = name.charAt(0).toUpperCase() + name.slice(1);
            const detail = info.latency_ms ? `${info.latency_ms}ms` : (info.message || info.status || 'OK');

            html += `
                <div class="reports-health-card ${statusClass}">
                    <div class="health-card-icon">${icon}</div>
                    <div class="health-card-content">
                        <div class="health-card-name">${displayName}</div>
                        <div class="health-card-status">${status ? '✅ Healthy' : '❌ Unhealthy'}</div>
                        <div class="health-card-detail">${escapeHtml(detail)}</div>
                    </div>
                </div>
            `;
        }

        grid.innerHTML = html || '<div class="reports-health-empty">No components to display</div>';

        // Try to get audit count
        try {
            const auditsResponse = await apiFetch(`${API_BASE}/api/audits`);
            const auditsData = await auditsResponse.json();
            if (auditCount && auditsData.audits) {
                auditCount.textContent = `${auditsData.audits.length} available`;
            }
        } catch (e) {
            if (auditCount) auditCount.textContent = 'Unable to retrieve';
        }

    } catch (error) {
        console.error('Error loading health report:', error);
        grid.innerHTML = `
            <div class="reports-health-error">
                <div class="health-error-icon">⚠️</div>
                <div class="health-error-text">Failed to load health status</div>
                <div class="health-error-detail">${escapeHtml(error.message)}</div>
            </div>
        `;
    }
}

async function loadReportingBackfillHistory() {
    const historyContainer = document.getElementById('reporting-backfill-history');
    const statusEl = document.getElementById('reporting-backfill-status');
    const successFilterEl = document.getElementById('reporting-backfill-success-filter');

    if (!historyContainer) return;

    historyContainer.innerHTML = '<div class="reports-health-loading">Loading reporting backfill history...</div>';

    try {
        const params = new URLSearchParams({ limit: '10' });
        if (successFilterEl && successFilterEl.value) {
            params.set('success', successFilterEl.value);
        }

        const response = await apiFetch(`${API_BASE}/api/reporting/backfill/history?${params.toString()}`);
        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.error || 'Failed to load reporting backfill history');
        }

        reportingBackfillHistory = Array.isArray(data.history) ? data.history : [];

        if (statusEl) {
            statusEl.textContent = reportingBackfillHistory.length
                ? `Showing ${reportingBackfillHistory.length} recent manual run${reportingBackfillHistory.length === 1 ? '' : 's'}.`
                : 'No manual reporting backfill runs found for the current filter.';
        }

        if (!reportingBackfillHistory.length) {
            historyContainer.innerHTML = `
                <div class="reports-empty-state">
                    <div class="reports-empty-icon">🧱</div>
                    <h3>No Matching Backfill Runs</h3>
                    <p>Adjust the filter or trigger a manual backfill to populate this list.</p>
                </div>
            `;
            return;
        }

        historyContainer.innerHTML = reportingBackfillHistory.map(entry => {
            const details = entry.details || {};
            const audits = details.audit_executions || { processed: 0, commits: 0 };
            const assessments = details.compliance_assessments || { processed: 0, commits: 0 };
            const timestamp = entry.timestamp ? new Date(entry.timestamp).toLocaleString() : 'Unknown time';
            const stateClass = entry.success ? 'success' : 'failure';
            const stateLabel = entry.success ? 'Success' : 'Failed';

            return `
                <div class="reports-backfill-history-card ${stateClass}">
                    <div class="reports-backfill-history-main">
                        <div class="reports-backfill-history-title-row">
                            <span class="reports-backfill-history-state ${stateClass}">${stateLabel}</span>
                            <span class="reports-backfill-history-time">${escapeHtml(timestamp)}</span>
                        </div>
                        <div class="reports-backfill-history-metrics">
                            <span>Audits: ${escapeHtml(audits.processed || 0)} processed</span>
                            <span>Assessments: ${escapeHtml(assessments.processed || 0)} processed</span>
                            <span>Commit every: ${escapeHtml(details.commit_every || 'n/a')}</span>
                        </div>
                        <div class="reports-backfill-history-meta">
                            <span>User ID: ${escapeHtml(entry.user_id || 'system')}</span>
                            <span>Audit limit: ${escapeHtml(details.audit_limit || 'all')}</span>
                            <span>Assessment limit: ${escapeHtml(details.assessment_limit || 'all')}</span>
                        </div>
                        ${entry.error ? `<div class="reports-backfill-history-error">${escapeHtml(entry.error)}</div>` : ''}
                    </div>
                </div>
            `;
        }).join('');
    } catch (error) {
        console.error('Error loading reporting backfill history:', error);
        if (statusEl) {
            statusEl.textContent = `Unable to load reporting backfill history: ${error.message}`;
        }
        showToast(`Unable to load reporting backfill history: ${error.message}`, 'error');
        historyContainer.innerHTML = `
            <div class="reports-empty-state">
                <div class="reports-empty-icon">⚠️</div>
                <h3>History Unavailable</h3>
                <p>${escapeHtml(error.message)}</p>
            </div>
        `;
    }
}

async function runReportingBackfill() {
    const statusEl = document.getElementById('reporting-backfill-status');
    const button = document.getElementById('run-reporting-backfill');
    const commitEveryEl = document.getElementById('reporting-backfill-commit-every');
    const auditLimitEl = document.getElementById('reporting-backfill-audit-limit');
    const assessmentLimitEl = document.getElementById('reporting-backfill-assessment-limit');
    const skipAuditsEl = document.getElementById('reporting-backfill-skip-audits');
    const skipAssessmentsEl = document.getElementById('reporting-backfill-skip-assessments');

    if (!button || !commitEveryEl) return;

    const payload = {
        commit_every: Number(commitEveryEl.value || 100),
        skip_audits: Boolean(skipAuditsEl && skipAuditsEl.checked),
        skip_assessments: Boolean(skipAssessmentsEl && skipAssessmentsEl.checked),
    };

    if (auditLimitEl && auditLimitEl.value) {
        payload.audit_limit = Number(auditLimitEl.value);
    }
    if (assessmentLimitEl && assessmentLimitEl.value) {
        payload.assessment_limit = Number(assessmentLimitEl.value);
    }

    if (!Number.isInteger(payload.commit_every) || payload.commit_every < 1) {
        if (statusEl) {
            statusEl.textContent = 'Commit Every must be a whole number greater than or equal to 1.';
        }
        showToast('Commit Every must be a whole number greater than or equal to 1.', 'error');
        return;
    }

    if (payload.audit_limit !== undefined && (!Number.isInteger(payload.audit_limit) || payload.audit_limit < 1)) {
        if (statusEl) {
            statusEl.textContent = 'Audit Limit must be a whole number greater than or equal to 1.';
        }
        showToast('Audit Limit must be a whole number greater than or equal to 1.', 'error');
        return;
    }

    if (payload.assessment_limit !== undefined && (!Number.isInteger(payload.assessment_limit) || payload.assessment_limit < 1)) {
        if (statusEl) {
            statusEl.textContent = 'Assessment Limit must be a whole number greater than or equal to 1.';
        }
        showToast('Assessment Limit must be a whole number greater than or equal to 1.', 'error');
        return;
    }

    if (payload.skip_audits && payload.skip_assessments) {
        if (statusEl) {
            statusEl.textContent = 'At least one source type must remain enabled.';
        }
        showToast('At least one source type must remain enabled.', 'error');
        return;
    }

    const confirmationLines = [
        'Run reporting backfill with these settings?',
        `Commit every: ${payload.commit_every}`,
        `Audit limit: ${payload.audit_limit ?? 'all'}`,
        `Assessment limit: ${payload.assessment_limit ?? 'all'}`,
        `Skip audits: ${payload.skip_audits ? 'yes' : 'no'}`,
        `Skip assessments: ${payload.skip_assessments ? 'yes' : 'no'}`,
    ];

    if (!window.confirm(confirmationLines.join('\n'))) {
        if (statusEl) {
            statusEl.textContent = 'Reporting backfill cancelled.';
        }
        showToast('Reporting backfill cancelled.', 'info');
        return;
    }

    button.disabled = true;
    if (statusEl) {
        statusEl.textContent = 'Running reporting backfill...';
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/reporting/backfill`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.error || 'Reporting backfill failed');
        }

        const audits = data.backfill?.audit_executions?.processed ?? 0;
        const assessments = data.backfill?.compliance_assessments?.processed ?? 0;
        if (statusEl) {
            statusEl.textContent = `Backfill complete. Audits processed: ${audits}. Assessments processed: ${assessments}.`;
        }
        showToast(`Reporting backfill complete. Audits: ${audits}. Assessments: ${assessments}.`, 'success');
        await loadReportingBackfillHistory();
    } catch (error) {
        console.error('Error running reporting backfill:', error);
        if (statusEl) {
            statusEl.textContent = `Reporting backfill failed: ${error.message}`;
        }
        showToast(`Reporting backfill failed: ${error.message}`, 'error');
    } finally {
        button.disabled = false;
    }
}

/**
 * Get icon for health component
 */
function getComponentIcon(name) {
    const icons = {
        'database': '🗄️',
        'redis': '💾',
        'celery': '⚙️',
        'disk': '💿',
        'memory': '🧠',
        'cpu': '🖥️',
        'network': '🌐',
        'api': '🔌'
    };
    return icons[name.toLowerCase()] || '🔧';
}

async function loadReportServers() {
    try {
        const response = await apiFetch(`${API_BASE}/api/reports/servers`);
        const data = await response.json();

        const serversList = document.getElementById('report-servers-list');

        if (data.success && data.servers.length > 0) {
            // Cache servers for filtering
            cachedReportServers = data.servers;

            // Update server count stat
            const serversCountEl = document.getElementById('reports-servers-count');
            if (serversCountEl) serversCountEl.textContent = data.servers.length;

            renderReportServerList();
        } else {
            cachedReportServers = [];
            serversList.innerHTML = `
                <div class="reports-empty-state">
                    <div class="reports-empty-icon">🖥️</div>
                    <h3>No Servers Configured</h3>
                    <p>Add servers in the Connect tab to generate reports</p>
                </div>
            `;
        }

        // Initialize report type cards
        initReportTypeCards();

    } catch (error) {
        console.error('Error loading report servers:', error);
        const serversList = document.getElementById('report-servers-list');
        if (serversList) {
            serversList.innerHTML = `
                <div class="reports-empty-state">
                    <div class="reports-empty-icon">⚠️</div>
                    <h3>Error Loading Servers</h3>
                    <p>${error.message}</p>
                </div>
            `;
        }
    }
}

function renderReportServerList() {
    const serversList = document.getElementById('report-servers-list');
    if (!serversList) return;

    // Apply search filter
    let filteredServers = cachedReportServers;
    if (reportServerSearchFilter) {
        const search = reportServerSearchFilter.toLowerCase();
        filteredServers = cachedReportServers.filter(s =>
            (s.name || '').toLowerCase().includes(search) ||
            (s.host || s.hostname || '').toLowerCase().includes(search) ||
            (s.os_type || '').toLowerCase().includes(search)
        );
    }

    if (filteredServers.length === 0) {
        if (reportServerSearchFilter) {
            serversList.innerHTML = '<p class="info-text">No servers match your search.</p>';
        } else {
            serversList.innerHTML = `
                <div class="reports-empty-state">
                    <div class="reports-empty-icon">🖥️</div>
                    <h3>No Servers Configured</h3>
                    <p>Add servers in the Connect tab to generate reports</p>
                </div>
            `;
        }
        return;
    }

    // Build compact list header
    const headerRow = `
        <div class="reports-server-list-header">
            <span class="reports-col-checkbox"><input type="checkbox" id="reports-select-all" title="Select All"></span>
            <span>Name</span>
            <span>Host</span>
            <span>Status</span>
        </div>
    `;

    const rows = filteredServers.map(server => {
        const osIcon = server.os_type === 'windows' ? '🪟' : (server.os_type === 'hypervisor' ? '🖥️' : '🐧');
        const status = server.last_test_success === true ? 'online' :
                      server.last_test_success === false ? 'offline' : 'untested';
        const statusLabel = status === 'online' ? 'Online' :
                           status === 'offline' ? 'Offline' : 'Untested';
        const isSelected = selectedReportServers.has(server.id);

        return `
            <div class="reports-server-row ${isSelected ? 'selected' : ''}" data-server-id="${escapeHtml(server.id)}">
                <div class="reports-col-checkbox">
                    <input type="checkbox" class="reports-server-checkbox" data-server-id="${escapeHtml(server.id)}" ${isSelected ? 'checked' : ''}>
                </div>
                <div class="reports-server-name-col">
                    <span class="reports-server-icon">${osIcon}</span>
                    <span class="reports-server-name">${escapeHtml(server.name)}</span>
                </div>
                <div class="reports-server-host">${escapeHtml(server.host || server.hostname || 'N/A')}</div>
                <div class="reports-server-status">
                    <span class="status-dot ${status}"></span>
                    <span>${statusLabel}</span>
                </div>
            </div>
        `;
    }).join('');

    serversList.innerHTML = headerRow + rows;

    // Add select-all handler
    const selectAllCheckbox = serversList.querySelector('#reports-select-all');
    if (selectAllCheckbox) {
        // Reflect current state
        const visibleIds = filteredServers.map(s => s.id);
        const allVisibleSelected = visibleIds.every(id => selectedReportServers.has(id));
        selectAllCheckbox.checked = allVisibleSelected && visibleIds.length > 0;

        selectAllCheckbox.addEventListener('change', (e) => {
            const allRows = serversList.querySelectorAll('.reports-server-row');
            allRows.forEach(row => {
                const serverId = parseInt(row.dataset.serverId, 10);
                const checkbox = row.querySelector('.reports-server-checkbox');
                checkbox.checked = e.target.checked;
                if (e.target.checked) {
                    selectedReportServers.add(serverId);
                    row.classList.add('selected');
                } else {
                    selectedReportServers.delete(serverId);
                    row.classList.remove('selected');
                }
            });
            updateReportsSelectionCount();
        });
    }

    // Add row click handlers
    serversList.querySelectorAll('.reports-server-row').forEach(row => {
        row.addEventListener('click', (e) => {
            if (e.target.type === 'checkbox') return;
            const checkbox = row.querySelector('input[type="checkbox"]');
            checkbox.checked = !checkbox.checked;
            const serverId = parseInt(row.dataset.serverId, 10);
            if (checkbox.checked) {
                selectedReportServers.add(serverId);
                row.classList.add('selected');
            } else {
                selectedReportServers.delete(serverId);
                row.classList.remove('selected');
            }
            updateReportsSelectionCount();
        });
    });

    // Add change listeners to checkboxes
    serversList.querySelectorAll('.reports-server-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', (e) => {
            const serverId = parseInt(e.target.dataset.serverId, 10);
            const row = e.target.closest('.reports-server-row');
            if (e.target.checked) {
                selectedReportServers.add(serverId);
                row.classList.add('selected');
            } else {
                selectedReportServers.delete(serverId);
                row.classList.remove('selected');
            }
            updateReportsSelectionCount();
        });
    });

    updateReportsSelectionCount();
}

function filterReportServers(searchTerm) {
    reportServerSearchFilter = searchTerm;
    renderReportServerList();
}

function updateReportsSelectionCount() {
    const countBadge = document.getElementById('reports-selected-count');
    if (countBadge) {
        countBadge.textContent = `${selectedReportServers.size} selected`;
    }
}

function initReportTypeCards() {
    const typeCards = document.querySelectorAll('.reports-type-card');
    const reportTypeInput = document.getElementById('report-type');

    typeCards.forEach(card => {
        card.addEventListener('click', () => {
            typeCards.forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            if (reportTypeInput) {
                reportTypeInput.value = card.dataset.type;
            }
        });
    });
}

async function generateReport() {
    if (selectedReportServers.size === 0) {
        alert('Please select at least one server');
        return;
    }

    try {
        const reportType = document.getElementById('report-type').value;

        // Show loading state
        const reportOutput = document.getElementById('report-output');
        reportOutput.classList.add('active');
        document.getElementById('report-content').innerHTML = `
            <div class="reports-empty-state">
                <div class="reports-empty-icon">⏳</div>
                <h3>Generating Report...</h3>
                <p>Please wait while we compile the audit data</p>
            </div>
        `;

        const response = await apiFetch(`${API_BASE}/api/reports/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                server_ids: Array.from(selectedReportServers),
                report_type: reportType
            })
        });

        const data = await response.json();

        if (data.success) {
            currentReport = data.report;
            renderReport(data.report);

            // Update stats
            reportsGeneratedToday++;
            const todayEl = document.getElementById('reports-generated-today');
            if (todayEl) todayEl.textContent = reportsGeneratedToday;

            const totalEl = document.getElementById('reports-total-reports');
            if (totalEl) totalEl.textContent = parseInt(totalEl.textContent || '0', 10) + 1;

            // Update average compliance
            if (data.report.summary && data.report.summary.compliance_percentage !== undefined) {
                const compEl = document.getElementById('reports-avg-compliance');
                if (compEl) compEl.textContent = data.report.summary.compliance_percentage + '%';
            }
        } else {
            alert('Failed to generate report: ' + data.error);
            reportOutput.classList.remove('active');
        }
    } catch (error) {
        alert('Error generating report: ' + error.message);
        document.getElementById('report-output').classList.remove('active');
    }
}

function renderReport(report) {
    const html = generateReportHTML(report);
    document.getElementById('report-content').innerHTML = html;
    document.getElementById('report-output').classList.add('active');
}

function generateReportHTML(report) {
    const summary = report.summary;
    const servers = report.servers || [];

    let html = `
        <div class="report-content-header">
            <h1>${escapeHtml(report.title || 'Security Audit Report')}</h1>
            <div class="timestamp">Generated: ${new Date(report.generated).toLocaleString()}</div>
        </div>

        <div class="report-summary-grid">
            <div class="report-summary-card compliance">
                <div class="report-summary-value">${summary.compliance_percentage || 0}%</div>
                <div class="report-summary-label">Compliance Rate</div>
            </div>
            <div class="report-summary-card pass">
                <div class="report-summary-value">${summary.total_pass || 0}</div>
                <div class="report-summary-label">Passed</div>
            </div>
            <div class="report-summary-card warn">
                <div class="report-summary-value">${summary.total_warn || 0}</div>
                <div class="report-summary-label">Warnings</div>
            </div>
            <div class="report-summary-card fail">
                <div class="report-summary-value">${summary.total_fail || 0}</div>
                <div class="report-summary-label">Failed</div>
            </div>
            <div class="report-summary-card skip">
                <div class="report-summary-value">${summary.total_skip || 0}</div>
                <div class="report-summary-label">Skipped</div>
            </div>
        </div>
    `;

    servers.forEach(server => {
        if (server.status === 'success') {
            const metrics = server.metrics || {};
            const passPercentage = server.pass_percentage || 0;
            const complianceScore = server.compliance_score !== undefined ? server.compliance_score : passPercentage;
            html += `
                <div class="report-server-block">
                    <div class="report-server-block-header">
                        <div class="report-server-block-title">
                            <span class="report-server-block-icon">🖥️</span>
                            <div>
                                <div class="report-server-block-name">${escapeHtml(server.name)}</div>
                                <div class="report-server-block-host">${escapeHtml(server.host)}</div>
                            </div>
                        </div>
                        <span class="report-status-badge success">✓ SUCCESS</span>
                    </div>
                    <table class="report-metrics-table">
                        <thead>
                            <tr>
                                <th>Metric</th>
                                <th style="text-align: right;">Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Total Checks</td>
                                <td style="text-align: right; font-weight: bold;">${metrics.total || 0}</td>
                            </tr>
                            <tr>
                                <td class="metric-pass">✓ Passed</td>
                                <td style="text-align: right;" class="metric-pass">${metrics.pass || 0}</td>
                            </tr>
                            <tr>
                                <td class="metric-warn">⚠ Warnings</td>
                                <td style="text-align: right;" class="metric-warn">${metrics.warn || 0}</td>
                            </tr>
                            <tr>
                                <td class="metric-fail">✗ Failed</td>
                                <td style="text-align: right;" class="metric-fail">${metrics.fail || 0}</td>
                            </tr>
                            <tr>
                                <td class="metric-skip">⊘ Skipped</td>
                                <td style="text-align: right;" class="metric-skip">${metrics.skip || 0}</td>
                            </tr>
                            <tr style="font-weight: bold;">
                                <td>Compliance Score</td>
                                <td style="text-align: right; color: #3b82f6;">${complianceScore}%</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            `;
        } else {
            html += `
                <div class="report-server-block">
                    <div class="report-server-block-header">
                        <div class="report-server-block-title">
                            <span class="report-server-block-icon">🖥️</span>
                            <div>
                                <div class="report-server-block-name">${escapeHtml(server.name)}</div>
                                <div class="report-server-block-host">${escapeHtml(server.host)}</div>
                            </div>
                        </div>
                        <span class="report-status-badge fail">✗ ERROR</span>
                    </div>
                    <div style="padding: 1rem; color: #ef4444;">
                        <strong>Error:</strong> ${escapeHtml(server.error || 'Unknown error')}
                    </div>
                </div>
            `;
        }
    });

    return html;
}

async function exportReport(format) {
    if (!currentReport) {
        alert('No report available to export');
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/reports/export`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                report: currentReport,
                format: format
            })
        });

        const data = await response.json();

        if (data.success) {
            // Create download link
            const blob = new Blob([data.content], { type: data.mime_type });
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = data.filename;
            document.body.appendChild(link);
            link.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(link);
        } else {
            alert('Failed to export report: ' + data.error);
        }
    } catch (error) {
        alert('Error exporting report: ' + error.message);
    }
}

function printReport() {
    window.print();
}

function closeReport() {
    document.getElementById('report-output').classList.remove('active');
    currentReport = null;
}

// ============================================================================
// Discovery Tool Functions
// ============================================================================

async function runDiscovery() {
    const format = document.getElementById('discovery-format').value;
    const output = document.getElementById('discovery-output-display');
    const status = document.getElementById('discovery-status');
    const statusBadge = document.getElementById('discovery-status-badge');
    const runButton = document.getElementById('run-discovery');
    const recommendationsSection = document.getElementById('discovery-recommendations');
    const applyButton = document.getElementById('apply-discovery-recommendations');

    try {
        // Update UI
        runButton.disabled = true;
        status.style.display = 'flex';
        statusBadge.className = 'status-badge status-running';
        statusBadge.textContent = 'Running Discovery...';
        output.textContent = 'Analyzing system...\nThis may take 30-90 seconds depending on system size...\n';
        recommendationsSection.style.display = 'none';
        applyButton.style.display = 'none';

        // Run discovery
        const response = await apiFetch(`${API_BASE}/api/discovery/run`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ format: format })
        });

        const data = await response.json();

        if (data.success) {
            statusBadge.className = 'status-badge status-pass';
            statusBadge.textContent = 'Discovery Complete';

            if (format === 'json' && data.data) {
                // Display formatted JSON
                output.textContent = JSON.stringify(data.data, null, 2);

                // Extract recommendations
                if (data.data.recommended_audits) {
                    discoveryRecommendations = data.data.recommended_audits;
                    displayRecommendations(discoveryRecommendations);
                }
            } else {
                // Display text output
                output.textContent = data.output;

                // Try to extract recommendations from text output
                parseTextRecommendations(data.output);
            }

            setTimeout(() => {
                status.style.display = 'none';
            }, 3000);
        } else {
            statusBadge.className = 'status-badge status-fail';
            statusBadge.textContent = 'Discovery Failed';
            output.textContent = `Error: ${data.error}\n\n${data.output || ''}`;
        }
    } catch (error) {
        statusBadge.className = 'status-badge status-fail';
        statusBadge.textContent = 'Discovery Failed';
        output.textContent = `Error: ${error.message}`;
    } finally {
        runButton.disabled = false;
    }
}

function displayRecommendations(recommendations) {
    if (!recommendations || recommendations.length === 0) {
        return;
    }

    const recommendationsSection = document.getElementById('discovery-recommendations');
    const recommendationsList = document.getElementById('recommendations-list');
    const applyButton = document.getElementById('apply-discovery-recommendations');

    // Build recommendations HTML
    let html = '';
    recommendations.forEach((rec, index) => {
        const audit = allAudits.find(a => a.path === rec.path);
        if (audit) {
            html += `
                <div class="audit-card" data-path="${escapeHtml(audit.path)}">
                    <span class="audit-domain">${escapeHtml(audit.domain)}</span>
                    <div class="audit-name">${escapeHtml(audit.display_name)}</div>
                    <div class="audit-category">${escapeHtml(audit.category)}</div>
                    <div class="audit-path" style="font-size: 0.75rem; color: #666;">${escapeHtml(rec.reason)}</div>
                </div>
            `;
        }
    });

    recommendationsList.innerHTML = html || '<p>No matching audits found for recommendations.</p>';
    recommendationsSection.style.display = 'block';
    applyButton.style.display = 'inline-block';
}

function parseTextRecommendations(text) {
    // Try to extract audit paths from text output
    const auditPathPattern = /audits\/[a-z-]+\/[a-z-]+\/[a-z-]+-audit\.sh/g;
    const matches = text.match(auditPathPattern);

    if (matches && matches.length > 0) {
        discoveryRecommendations = matches.map(path => ({ path: path }));
        displayRecommendations(discoveryRecommendations);
    }
}

function applyDiscoveryRecommendations() {
    if (!discoveryRecommendations || discoveryRecommendations.length === 0) {
        alert('No recommendations to apply');
        return;
    }

    // Clear current selection
    selectedAudits.clear();

    // Add all recommended audits
    discoveryRecommendations.forEach(rec => {
        selectedAudits.add(rec.path);
    });

    // Switch to audits tab and update UI
    switchTab('audits');
    renderAudits(allAudits);
    updateSelectionCount();

    alert(`Selected ${selectedAudits.size} recommended audits. You can now run them from the Audit Selection tab.`);
}

function clearDiscoveryOutput() {
    document.getElementById('discovery-output-display').textContent =
        'Click "Run System Discovery" to analyze the target system...';
    document.getElementById('discovery-recommendations').style.display = 'none';
    document.getElementById('apply-discovery-recommendations').style.display = 'none';
    discoveryRecommendations = [];
}

// ====================
// Dark Mode Functions
// ====================

function initTheme() {
    if (currentTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
    } else {
        document.documentElement.removeAttribute('data-theme');
    }
    updateThemeButton();
}

function toggleTheme() {
    currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('theme', currentTheme);
    if (currentTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
    } else {
        document.documentElement.removeAttribute('data-theme');
    }
    updateThemeButton();
}

function updateThemeButton() {
    const themeBtn = document.querySelector('#theme-toggle .theme-icon');
    if (themeBtn) {
        themeBtn.textContent = currentTheme === 'dark' ? '☀️' : '🌙';
    }
}

// ====================
// History Functions
// ====================

async function loadHistory() {
    const historyList = document.getElementById('history-list');
    const filterValue = document.getElementById('history-filter').value;
    // Support both search inputs (filter section and inline header)
    const filterSearch = document.getElementById('history-search')?.value?.toLowerCase() || '';
    const inlineSearch = document.getElementById('history-list-search')?.value?.toLowerCase() || '';
    const searchValue = inlineSearch || filterSearch;
    // Source type filter (servers, hypervisors, or all)
    const sourceType = document.getElementById('history-source-filter')?.value || '';

    historyList.innerHTML = '<p class="loading">Loading history...</p>';

    try {
        // Use unified API when source filter is set, otherwise use legacy API
        let history = [];
        if (sourceType) {
            const response = await apiFetch(`${API_BASE}/api/history/unified?source_type=${sourceType}&status=${filterValue}`);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const data = await response.json();
            // Map unified format to legacy format for display
            history = (data.executions || []).map(item => ({
                id: item.id,
                plan_name: item.audit_name || 'Audit',
                target_name: item.source_name,
                source_type: item.source_type,
                status: item.status === 'success' ? 'success' : (item.status === 'running' ? 'running' : 'error'),
                timestamp: item.executed_at,
                audits: item.checks_passed !== null ? item.checks_passed + item.checks_warned + item.checks_failed : 0,
                duration: item.duration_seconds,
                pass_count: item.checks_passed || 0,
                warn_count: item.checks_warned || 0,
                fail_count: item.checks_failed || 0
            }));
        } else {
            const response = await apiFetch(`${API_BASE}/api/history?filter=${filterValue}`);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            history = await response.json();
        }

        // Apply search filter
        if (searchValue) {
            history = history.filter(item =>
                (item.plan_name || '').toLowerCase().includes(searchValue) ||
                (item.target_name || '').toLowerCase().includes(searchValue) ||
                (item.status || '').toLowerCase().includes(searchValue)
            );
        }

        // Apply date filter
        const dateFrom = document.getElementById('history-date-from')?.value;
        const dateTo = document.getElementById('history-date-to')?.value;
        if (dateFrom) {
            const fromDate = new Date(dateFrom);
            history = history.filter(item => new Date(item.timestamp) >= fromDate);
        }
        if (dateTo) {
            const toDate = new Date(dateTo);
            toDate.setHours(23, 59, 59, 999);
            history = history.filter(item => new Date(item.timestamp) <= toDate);
        }

        // Calculate stats
        const total = history.length;
        const successCount = history.filter(h => h.status === 'success').length;
        const warningCount = history.filter(h => h.status === 'warning').length;
        const errorCount = history.filter(h => h.status === 'error').length;
        const successRate = total > 0 ? Math.round((successCount / total) * 100) : 0;

        // Update stats UI
        const updateEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
        updateEl('history-total-count', total);
        updateEl('history-success-count', successCount);
        updateEl('history-warning-count', warningCount);
        updateEl('history-error-count', errorCount);
        updateEl('history-success-rate', successRate + '%');
        updateEl('history-showing-count', `Showing ${history.length} results`);

        if (history.length === 0) {
            historyList.innerHTML = `
                <div class="history-empty-state">
                    <span class="history-empty-icon">\uD83D\uDCDC</span>
                    <h3>No History Found</h3>
                    <p>No audit executions match your current filters</p>
                </div>
            `;
            return;
        }

        let html = '<div class="history-compact-list">';
        history.forEach(item => {
            const status = item.status || 'error';
            const date = new Date(item.timestamp);
            const dateStr = date.toLocaleDateString();
            const timeStr = date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

            const passCount = parseInt(item.pass_count) || 0;
            const warnCount = parseInt(item.warn_count) || 0;
            const failCount = parseInt(item.fail_count) || 0;
            const skipCount = parseInt(item.skip_count) || 0;
            const auditCount = parseInt(item.audit_count) || 0;

            html += `
                <div class="history-compact-item">
                    <div class="history-compact-status ${status}"></div>
                    <div class="history-compact-info">
                        <div class="history-compact-name">${escapeHtml(item.plan_name || 'Unnamed Execution')}</div>
                        <div class="history-compact-meta">
                            <span>\uD83D\uDCC5 ${escapeHtml(dateStr)}</span>
                            <span>\u23F0 ${escapeHtml(timeStr)}</span>
                            <span>\uD83D\uDCCB ${auditCount} audits</span>
                        </div>
                    </div>
                    <div class="history-compact-results">
                        <span class="result-badge pass">\u2713 ${passCount}</span>
                        ${warnCount > 0 ? `<span class="result-badge warn">\u26A0 ${warnCount}</span>` : ''}
                        ${failCount > 0 ? `<span class="result-badge fail">\u2717 ${failCount}</span>` : ''}
                        ${skipCount > 0 ? `<span class="result-badge skip">\u2212 ${skipCount}</span>` : ''}
                    </div>
                    <div class="history-compact-actions">
                        <button class="btn btn-small btn-primary" onclick="viewHistoryDetails('${escapeHtml(item.id).replace(/'/g, "\\'")}')" title="View Details">\uD83D\uDC41\uFE0F</button>
                        <button class="btn btn-small btn-danger" onclick="deleteHistoryItem('${escapeHtml(item.id).replace(/'/g, "\\'")}')" title="Delete">\uD83D\uDDD1\uFE0F</button>
                    </div>
                </div>
            `;
        });
        html += '</div>';

        historyList.innerHTML = html;
    } catch (error) {
        historyList.innerHTML = `
            <div class="history-empty-state">
                <span class="history-empty-icon">\u26A0\uFE0F</span>
                <h3>Error Loading History</h3>
                <p>${escapeHtml(error.message)}</p>
            </div>
        `;
    }
}

function filterHistory() {
    loadHistory();
}

async function clearAllHistory() {
    if (!confirm('Are you sure you want to clear all audit history? This cannot be undone.')) {
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/history`, {
            method: 'DELETE'
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        alert('History cleared successfully');
        loadHistory();
    } catch (error) {
        alert(`Failed to clear history: ${error.message}`);
    }
}

async function viewHistoryDetails(historyId) {
    try {
        const response = await apiFetch(`${API_BASE}/api/history/${historyId}`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const details = await response.json();

        // Display in a modal or switch to execution/results view
        alert(`History details for ${historyId}:\n\n${JSON.stringify(details, null, 2)}`);
    } catch (error) {
        alert(`Failed to load history details: ${error.message}`);
    }
}

async function deleteHistoryItem(historyId) {
    if (!confirm('Delete this history item?')) {
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/history/${historyId}`, {
            method: 'DELETE'
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        loadHistory();
    } catch (error) {
        alert(`Failed to delete history: ${error.message}`);
    }
}

// ====================
// Schedule Functions
// ====================

let selectedScheduleIds = new Set();

async function loadSchedules() {
    const schedulesList = document.getElementById('schedules-list');
    const schedulePlanSelect = document.getElementById('schedule-plan');

    schedulesList.innerHTML = `
        <div class="schedule-loading">
            <div class="schedule-loading-spinner"></div>
            <p>Loading schedules...</p>
        </div>
    `;

    try {
        // Load regular schedules and agent schedules in parallel
        const [schedResponse, agentSchedResponse] = await Promise.all([
            apiFetch(`${API_BASE}/api/schedules`),
            apiFetch(`${API_BASE}/api/agents/schedules`).catch(() => null) // Don't fail if agent API unavailable
        ]);

        if (!schedResponse.ok) throw new Error(`HTTP ${schedResponse.status}`);

        const schedData = await schedResponse.json();

        // Handle both array format (v1) and object format with schedules property
        // API might return: [] (array) or {success: true, schedules: []} or {success: false, error: "..."}
        let schedules;
        if (Array.isArray(schedData)) {
            schedules = schedData;
        } else if (schedData && Array.isArray(schedData.schedules)) {
            schedules = schedData.schedules;
        } else if (schedData && schedData.success === false) {
            throw new Error(schedData.error || 'Failed to load schedules');
        } else {
            schedules = [];
        }

        // Merge agent schedules if available
        if (agentSchedResponse && agentSchedResponse.ok) {
            try {
                const agentData = await agentSchedResponse.json();
                if (agentData.success && Array.isArray(agentData.schedules)) {
                    // Mark agent schedules and add to list
                    agentData.schedules.forEach(s => {
                        s.schedule_source = 'agent';
                        schedules.push(s);
                    });
                }
            } catch (e) {
                console.warn('Failed to parse agent schedules:', e);
            }
        }

        const currentRegularScheduleIds = new Set(
            schedules
                .filter(s => s.schedule_source !== 'agent')
                .map(s => String(s.id))
        );
        selectedScheduleIds = new Set(
            [...selectedScheduleIds].filter(id => currentRegularScheduleIds.has(id))
        );

        // Load plans for the dropdown
        const plansResponse = await apiFetch(`${API_BASE}/api/plans`);
        if (plansResponse.ok) {
            const plansData = await plansResponse.json();
            const plans = plansData.plans || plansData;
            if (Array.isArray(plans)) {
                schedulePlanSelect.innerHTML = '<option value="">-- Select Plan --</option>' +
                    plans.map(p => `<option value="${escapeHtml(p.name)}">${escapeHtml(p.name)}</option>`).join('');
            }
        }

        // Calculate stats
        const today = new Date().toDateString();
        let activeCount = 0;
        let upcomingToday = 0;
        let executedToday = 0;

        schedules.forEach(sched => {
            if (sched.enabled) activeCount++;
            if (sched.next_run && new Date(sched.next_run).toDateString() === today) upcomingToday++;
            if (sched.last_run && new Date(sched.last_run).toDateString() === today) executedToday++;
        });

        updateScheduleStats(schedules.length, activeCount, upcomingToday, executedToday);

        // Update badge
        const countBadge = document.getElementById('schedules-count');
        if (countBadge) countBadge.textContent = schedules.length;

        if (schedules.length === 0) {
            selectedScheduleIds.clear();
            updateScheduleSelectionUI();
            schedulesList.innerHTML = `
                <div class="schedule-empty-state">
                    <div class="schedule-empty-icon">📅</div>
                    <h3>No Schedules Configured</h3>
                    <p>Create a schedule using the form to automate audit execution</p>
                </div>
            `;
            return;
        }

        // Render schedules as list view
        const headerRow = `
            <div class="schedule-list-view-header">
                <span>Select</span>
                <span>Schedule</span>
                <span>Frequency</span>
                <span>Next Run</span>
                <span>Last Run</span>
                <span>Status</span>
                <span>Actions</span>
            </div>
        `;

        let rowsHtml = '';
        schedules.forEach(sched => {
            const isActive = sched.enabled;
            const statusClass = isActive ? 'active' : 'disabled';
            const nextRun = sched.next_run ? new Date(sched.next_run).toLocaleString('en-US', {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'}) : '--';
            const lastRun = sched.last_run ? new Date(sched.last_run).toLocaleString('en-US', {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'}) : 'Never';
            const scheduleId = String(sched.id ?? '');
            const schedIdSafe = escapeHtml(scheduleId).replace(/'/g, "\\'");
            const frequency = (sched.frequency || 'daily').toLowerCase();
            const frequencyDisplay = frequency.charAt(0).toUpperCase() + frequency.slice(1);
            const time = sched.time || '02:00';
            const isAgentSchedule = sched.schedule_source === 'agent';
            const rowClass = isAgentSchedule ? 'schedule-list-row agent-schedule ' + statusClass : 'schedule-list-row ' + statusClass;
            const icon = isAgentSchedule ? '🤖' : '📋';
            const agentBadge = isAgentSchedule ? '<span class="schedule-type-badge agent">Agent</span>' : '';

            // Determine source and target type for filtering
            const sourceType = isAgentSchedule ? 'agent' : 'server';
            const targetType = sched.target_type || (isAgentSchedule ? 'hypervisor' : 'server');
            const statusType = isActive ? 'active' : 'disabled';
            // Normalize frequency for filtering (daily, weekly, monthly, custom)
            const freqNorm = ['daily', 'weekly', 'monthly'].includes(frequency) ? frequency : 'custom';

            if (isAgentSchedule) {
                // Agent schedule row
                rowsHtml += `
                    <div class="${rowClass}" data-source="${sourceType}" data-frequency="${freqNorm}" data-status="${statusType}" data-target="${targetType}" data-deletable="false">
                        <div class="schedule-list-select">—</div>
                        <div class="schedule-list-info">
                            <div class="schedule-list-name">${icon} ${escapeHtml(sched.name)} ${agentBadge}</div>
                            <div class="schedule-list-plan">${escapeHtml(sched.plan_name || sched.target_name || 'No plan')}</div>
                        </div>
                        <div class="schedule-list-frequency">${escapeHtml(frequencyDisplay)} @ ${escapeHtml(time)}</div>
                        <div class="schedule-list-next">${escapeHtml(nextRun)}</div>
                        <div class="schedule-list-time">${escapeHtml(lastRun)}</div>
                        <div class="schedule-list-status">
                            <span class="status-dot ${statusClass}" title="${isActive ? 'Active' : 'Disabled'}"></span>
                        </div>
                        <div class="schedule-list-actions">
                            <button class="btn btn-small btn-primary" onclick="triggerAgentSchedule('${schedIdSafe}')" title="Run Now">▶️</button>
                            <button class="btn btn-small btn-secondary" onclick="openAgentConfig('${schedIdSafe}')" title="Configure">⚙️</button>
                        </div>
                    </div>
                `;
            } else {
                // Regular schedule row
                const isSelected = selectedScheduleIds.has(scheduleId);
                rowsHtml += `
                    <div class="${rowClass}" data-source="${sourceType}" data-frequency="${freqNorm}" data-status="${statusType}" data-target="${targetType}" data-schedule-id="${escapeHtml(scheduleId)}" data-deletable="true">
                        <div class="schedule-list-select">
                            <input type="checkbox" class="schedule-select-checkbox" data-schedule-id="${escapeHtml(scheduleId)}" onchange="toggleScheduleSelection('${schedIdSafe}', this.checked)" ${isSelected ? 'checked' : ''} title="Select schedule">
                        </div>
                        <div class="schedule-list-info">
                            <div class="schedule-list-name">${escapeHtml(sched.name)}</div>
                            <div class="schedule-list-plan">${icon} ${escapeHtml(sched.plan_name || 'No plan')}</div>
                        </div>
                        <div class="schedule-list-frequency">${escapeHtml(frequencyDisplay)} @ ${escapeHtml(time)}</div>
                        <div class="schedule-list-next">${escapeHtml(nextRun)}</div>
                        <div class="schedule-list-time">${escapeHtml(lastRun)}</div>
                        <div class="schedule-list-status">
                            <span class="status-dot ${statusClass}" title="${isActive ? 'Active' : 'Disabled'}"></span>
                        </div>
                        <div class="schedule-list-actions">
                            <button class="btn btn-small ${isActive ? 'btn-secondary' : 'btn-primary'}" onclick="toggleSchedule('${schedIdSafe}', ${!isActive})" title="${isActive ? 'Disable' : 'Enable'}">
                                ${isActive ? '⏸️' : '▶️'}
                            </button>
                            <button class="btn btn-small btn-secondary" onclick="editSchedule('${schedIdSafe}')" title="Edit">✏️</button>
                            <button class="btn btn-small btn-secondary" onclick="deleteSchedule('${schedIdSafe}')" title="Delete">🗑️</button>
                        </div>
                    </div>
                `;
            }
        });

        schedulesList.className = 'schedule-list-view';
        schedulesList.innerHTML = headerRow + rowsHtml;
        updateScheduleSelectionUI();
    } catch (error) {
        selectedScheduleIds.clear();
        updateScheduleSelectionUI();
        schedulesList.className = 'schedule-list-content';
        schedulesList.innerHTML = `
            <div class="schedule-empty-state">
                <div class="schedule-empty-icon">⚠️</div>
                <h3>Error Loading Schedules</h3>
                <p>${escapeHtml(error.message)}</p>
            </div>
        `;
    }
}

function updateScheduleStats(total, active, upcoming, executed) {
    const totalEl = document.getElementById('schedule-total-count');
    const activeEl = document.getElementById('schedule-active-count');
    const upcomingEl = document.getElementById('schedule-upcoming-count');
    const executedEl = document.getElementById('schedule-executed-count');

    if (totalEl) totalEl.textContent = total;
    if (activeEl) activeEl.textContent = active;
    if (upcomingEl) upcomingEl.textContent = upcoming;
    if (executedEl) executedEl.textContent = executed;
}

function filterSchedulesList() {
    const searchInput = document.getElementById('schedules-list-search');
    const sourceFilter = document.getElementById('schedule-filter-source');
    const frequencyFilter = document.getElementById('schedule-filter-frequency');
    const statusFilter = document.getElementById('schedule-filter-status');
    const targetFilter = document.getElementById('schedule-filter-target');

    const query = searchInput?.value.toLowerCase().trim() || '';
    const sourceValue = sourceFilter?.value || 'all';
    const frequencyValue = frequencyFilter?.value || 'all';
    const statusValue = statusFilter?.value || 'all';
    const targetValue = targetFilter?.value || 'all';

    const scheduleRows = document.querySelectorAll('.schedule-list-row');
    let visibleCount = 0;
    let totalCount = scheduleRows.length;

    scheduleRows.forEach(row => {
        const name = row.querySelector('.schedule-list-name')?.textContent.toLowerCase() || '';
        const plan = row.querySelector('.schedule-list-plan')?.textContent.toLowerCase() || '';
        const freqText = row.querySelector('.schedule-list-frequency')?.textContent.toLowerCase() || '';

        // Get data attributes for filtering
        const rowSource = row.dataset.source || 'server';
        const rowFrequency = row.dataset.frequency || 'daily';
        const rowStatus = row.dataset.status || 'active';
        const rowTarget = row.dataset.target || 'server';

        // Check all filter conditions
        const matchesSearch = !query || name.includes(query) || plan.includes(query) || freqText.includes(query);
        const matchesSource = sourceValue === 'all' || rowSource === sourceValue;
        const matchesFrequency = frequencyValue === 'all' || rowFrequency === frequencyValue;
        const matchesStatus = statusValue === 'all' || rowStatus === statusValue;
        const matchesTarget = targetValue === 'all' || rowTarget === targetValue;

        if (matchesSearch && matchesSource && matchesFrequency && matchesStatus && matchesTarget) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });

    // Update active filters display
    updateScheduleActiveFilters(query, sourceValue, frequencyValue, statusValue, targetValue, visibleCount, totalCount);
    updateScheduleSelectionUI();
}

function updateScheduleActiveFilters(query, source, frequency, status, target, visible, total) {
    const activeFiltersEl = document.getElementById('schedule-active-filters');
    const filterTagsEl = document.getElementById('schedule-filter-tags');

    if (!activeFiltersEl || !filterTagsEl) return;

    const hasFilters = query || source !== 'all' || frequency !== 'all' || status !== 'all' || target !== 'all';

    if (!hasFilters) {
        activeFiltersEl.style.display = 'none';
        return;
    }

    activeFiltersEl.style.display = 'flex';

    let tagsHtml = '';

    if (query) {
        tagsHtml += `<span class="schedule-filter-tag">🔍 "${escapeHtml(query)}" <span class="schedule-filter-tag-remove" onclick="clearScheduleFilter('search')">✕</span></span>`;
    }
    if (source !== 'all') {
        const sourceLabel = source === 'agent' ? 'Agent' : 'Server';
        tagsHtml += `<span class="schedule-filter-tag">Source: ${sourceLabel} <span class="schedule-filter-tag-remove" onclick="clearScheduleFilter('source')">✕</span></span>`;
    }
    if (frequency !== 'all') {
        const freqLabel = frequency.charAt(0).toUpperCase() + frequency.slice(1);
        tagsHtml += `<span class="schedule-filter-tag">Frequency: ${freqLabel} <span class="schedule-filter-tag-remove" onclick="clearScheduleFilter('frequency')">✕</span></span>`;
    }
    if (status !== 'all') {
        const statusLabel = status === 'active' ? 'Active' : 'Disabled';
        tagsHtml += `<span class="schedule-filter-tag">Status: ${statusLabel} <span class="schedule-filter-tag-remove" onclick="clearScheduleFilter('status')">✕</span></span>`;
    }
    if (target !== 'all') {
        const targetLabel = target === 'hypervisor' ? 'Hypervisor' : 'Server';
        tagsHtml += `<span class="schedule-filter-tag">Target: ${targetLabel} <span class="schedule-filter-tag-remove" onclick="clearScheduleFilter('target')">✕</span></span>`;
    }

    // Add result count
    tagsHtml += `<span class="schedule-filter-results-count">(${visible} of ${total})</span>`;

    filterTagsEl.innerHTML = tagsHtml;
}

function clearScheduleFilter(filterType) {
    switch (filterType) {
        case 'search':
            const searchInput = document.getElementById('schedules-list-search');
            if (searchInput) searchInput.value = '';
            break;
        case 'source':
            const sourceFilter = document.getElementById('schedule-filter-source');
            if (sourceFilter) sourceFilter.value = 'all';
            break;
        case 'frequency':
            const frequencyFilter = document.getElementById('schedule-filter-frequency');
            if (frequencyFilter) frequencyFilter.value = 'all';
            break;
        case 'status':
            const statusFilter = document.getElementById('schedule-filter-status');
            if (statusFilter) statusFilter.value = 'all';
            break;
        case 'target':
            const targetFilter = document.getElementById('schedule-filter-target');
            if (targetFilter) targetFilter.value = 'all';
            break;
    }
    filterSchedulesList();
}

function clearScheduleFilters() {
    // Reset all filter inputs
    const searchInput = document.getElementById('schedules-list-search');
    const sourceFilter = document.getElementById('schedule-filter-source');
    const frequencyFilter = document.getElementById('schedule-filter-frequency');
    const statusFilter = document.getElementById('schedule-filter-status');
    const targetFilter = document.getElementById('schedule-filter-target');

    if (searchInput) searchInput.value = '';
    if (sourceFilter) sourceFilter.value = 'all';
    if (frequencyFilter) frequencyFilter.value = 'all';
    if (statusFilter) statusFilter.value = 'all';
    if (targetFilter) targetFilter.value = 'all';

    // Re-apply (which will show all)
    filterSchedulesList();
}

function getVisibleDeletableScheduleRows() {
    return Array.from(document.querySelectorAll('.schedule-list-row[data-deletable="true"]')).filter(row => row.style.display !== 'none');
}

function getVisibleDeletableScheduleCheckboxes() {
    return getVisibleDeletableScheduleRows()
        .map(row => row.querySelector('.schedule-select-checkbox'))
        .filter(Boolean);
}

function toggleScheduleSelection(scheduleId, isChecked) {
    const normalizedId = String(scheduleId);
    if (isChecked) {
        selectedScheduleIds.add(normalizedId);
    } else {
        selectedScheduleIds.delete(normalizedId);
    }
    updateScheduleSelectionUI();
}

function setAllScheduleSelection(shouldSelect) {
    const visibleCheckboxes = getVisibleDeletableScheduleCheckboxes();

    visibleCheckboxes.forEach(checkbox => {
        const scheduleId = checkbox.dataset.scheduleId;
        if (!scheduleId) return;

        checkbox.checked = shouldSelect;
        if (shouldSelect) {
            selectedScheduleIds.add(String(scheduleId));
        } else {
            selectedScheduleIds.delete(String(scheduleId));
        }
    });

    updateScheduleSelectionUI();
}

function clearAllScheduleSelection() {
    selectedScheduleIds.clear();
    const checkboxes = document.querySelectorAll('.schedule-select-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = false;
    });
    updateScheduleSelectionUI();
}

function updateScheduleSelectionUI() {
    const rows = Array.from(document.querySelectorAll('.schedule-list-row[data-deletable="true"]'));
    const availableIds = new Set(rows.map(row => String(row.dataset.scheduleId || '')).filter(Boolean));
    selectedScheduleIds = new Set([...selectedScheduleIds].filter(id => availableIds.has(id)));

    const selectedCountEl = document.getElementById('schedule-selected-count');
    const bulkActionsEl = document.getElementById('schedule-bulk-actions');
    const selectAllEl = document.getElementById('schedule-select-all');
    const deleteSelectedBtn = document.getElementById('schedule-delete-selected');

    if (selectedCountEl) {
        selectedCountEl.textContent = `${selectedScheduleIds.size} selected`;
    }

    if (bulkActionsEl) {
        bulkActionsEl.style.display = selectedScheduleIds.size > 0 ? 'flex' : 'none';
    }

    if (deleteSelectedBtn) {
        deleteSelectedBtn.disabled = selectedScheduleIds.size === 0;
    }

    if (!selectAllEl) {
        return;
    }

    const visibleRows = getVisibleDeletableScheduleRows();
    if (visibleRows.length === 0) {
        selectAllEl.checked = false;
        selectAllEl.indeterminate = false;
        return;
    }

    const selectedVisibleCount = visibleRows.filter(row => {
        const scheduleId = String(row.dataset.scheduleId || '');
        return scheduleId && selectedScheduleIds.has(scheduleId);
    }).length;

    selectAllEl.checked = selectedVisibleCount === visibleRows.length;
    selectAllEl.indeterminate = selectedVisibleCount > 0 && selectedVisibleCount < visibleRows.length;
}

async function deleteSelectedSchedules() {
    const scheduleIds = Array.from(selectedScheduleIds);
    if (scheduleIds.length === 0) {
        return;
    }

    const label = scheduleIds.length === 1
        ? 'Delete the selected schedule?'
        : `Delete ${scheduleIds.length} selected schedules?`;

    if (!confirm(label)) {
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/schedules/delete-batch`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: scheduleIds })
        });

        let data = null;
        try {
            data = await response.json();
        } catch (parseError) {
            data = null;
        }

        if (!response.ok || !data || !data.success) {
            const errorMessage = data?.error || `HTTP ${response.status}`;
            throw new Error(errorMessage);
        }

        const deleted = Array.isArray(data.deleted) ? data.deleted : [];
        const errors = Array.isArray(data.errors) ? data.errors : [];

        deleted.forEach(scheduleId => selectedScheduleIds.delete(String(scheduleId)));

        if (errors.length === 0) {
            alert(`Deleted ${deleted.length} schedule${deleted.length === 1 ? '' : 's'}.`);
        } else {
            alert(`Deleted ${deleted.length} schedule${deleted.length === 1 ? '' : 's'}. Failed to delete ${errors.length}.`);
            console.error('Schedule batch delete errors:', errors);
        }

        await loadSchedules();
    } catch (error) {
        alert(`Failed to delete selected schedules: ${error.message}`);
    }
}

// Agent schedule helper functions
async function triggerAgentSchedule(agentId) {
    if (!confirm('Trigger an immediate audit run on this agent?')) return;

    try {
        const response = await apiFetch(`${API_BASE}/api/agents/trigger`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ agent_ids: [agentId] })
        });

        const data = await response.json();
        if (data.success) {
            alert(`Audit triggered successfully on agent ${agentId}`);
        } else {
            alert(`Failed to trigger: ${data.error || 'Unknown error'}`);
        }
    } catch (err) {
        alert(`Error triggering audit: ${err.message}`);
    }
}

function openAgentConfig(agentId) {
    // Navigate to hypervisors tab and open agent management modal
    setActiveTab('hypervisors', true);
    // Try to open agent management modal after a brief delay for tab to load
    setTimeout(() => {
        if (typeof openAgentManagement === 'function') {
            openAgentManagement();
        }
    }, 300);
}

function toggleCronField() {
    const frequency = document.getElementById('schedule-frequency').value;
    const timeGroup = document.getElementById('schedule-time-group');
    const cronGroup = document.getElementById('schedule-cron-group');

    if (frequency === 'custom') {
        timeGroup.style.display = 'none';
        cronGroup.style.display = 'block';
    } else {
        timeGroup.style.display = 'block';
        cronGroup.style.display = 'none';
    }
}

async function createSchedule() {
    const name = document.getElementById('schedule-name').value.trim();
    const plan = document.getElementById('schedule-plan').value;
    const frequency = document.getElementById('schedule-frequency').value;
    const time = document.getElementById('schedule-time').value;
    const cron = document.getElementById('schedule-cron').value.trim();
    const enabled = document.getElementById('schedule-enabled').checked;

    if (!name || !plan || !frequency) {
        alert('Please fill in all required fields (marked with *)');
        return;
    }

    if (frequency === 'custom' && !cron) {
        alert('Please provide a cron expression');
        return;
    }

    const scheduleData = {
        name,
        plan_name: plan,
        frequency,
        time: frequency !== 'custom' ? time : undefined,
        cron: frequency === 'custom' ? cron : undefined,
        enabled
    };

    try {
        const response = await apiFetch(`${API_BASE}/api/schedules`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(scheduleData)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || `HTTP ${response.status}`);
        }

        alert('Schedule created successfully');

        // Reset form
        document.getElementById('schedule-name').value = '';
        document.getElementById('schedule-plan').value = '';
        document.getElementById('schedule-frequency').value = 'daily';
        document.getElementById('schedule-time').value = '02:00';
        document.getElementById('schedule-enabled').checked = true;
        toggleCronField();

        loadSchedules();
    } catch (error) {
        alert(`Failed to create schedule: ${error.message}`);
    }
}

async function toggleSchedule(scheduleId, enable) {
    try {
        const response = await apiFetch(`${API_BASE}/api/schedules/${scheduleId}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled: enable })
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        loadSchedules();
    } catch (error) {
        alert(`Failed to update schedule: ${error.message}`);
    }
}

async function editSchedule(scheduleId) {
    const modal = document.getElementById('edit-schedule-modal');
    if (!modal) {
        alert('Edit schedule modal not found');
        return;
    }

    try {
        // Fetch the schedule data
        const response = await apiFetch(`${API_BASE}/api/schedules/${scheduleId}`);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const data = await response.json();

        if (!data.success || !data.schedule) {
            throw new Error(data.error || 'Schedule not found');
        }

        const schedule = data.schedule;

        // Populate the form
        document.getElementById('edit-schedule-id').value = schedule.id;
        document.getElementById('edit-schedule-name').value = schedule.name || '';
        document.getElementById('edit-schedule-frequency').value = schedule.frequency || 'daily';
        document.getElementById('edit-schedule-time').value = schedule.time || '02:00';
        document.getElementById('edit-schedule-cron').value = schedule.cron || '';
        document.getElementById('edit-schedule-execution-mode').value = schedule.execution_mode || 'stream';
        document.getElementById('edit-schedule-enabled').checked = schedule.enabled !== false;

        // Handle frequency-dependent visibility
        const frequency = schedule.frequency || 'daily';
        const timeGroup = document.getElementById('edit-schedule-time-group');
        const cronGroup = document.getElementById('edit-schedule-cron-group');
        if (frequency === 'custom') {
            timeGroup.classList.add('d-none');
            cronGroup.classList.remove('d-none');
        } else {
            timeGroup.classList.remove('d-none');
            cronGroup.classList.add('d-none');
        }

        // Load plans into dropdown
        const planSelect = document.getElementById('edit-schedule-plan');
        try {
            const plansResponse = await apiFetch(`${API_BASE}/api/plans`);
            if (plansResponse.ok) {
                const plansData = await plansResponse.json();
                const plans = plansData.plans || plansData;
                if (Array.isArray(plans)) {
                    planSelect.innerHTML = '<option value="">-- Select Plan --</option>' +
                        plans.map(p => `<option value="${escapeHtml(p.name)}"${p.name === schedule.plan_name ? ' selected' : ''}>${escapeHtml(p.name)}</option>`).join('');
                }
            }
        } catch (e) {
            console.error('Failed to load plans:', e);
        }

        // Show the modal
        modal.style.display = 'flex';

    } catch (error) {
        alert(`Failed to load schedule: ${error.message}`);
    }
}

function closeEditScheduleModal() {
    const modal = document.getElementById('edit-schedule-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function handleEditSchedule(e) {
    e.preventDefault();

    const scheduleId = document.getElementById('edit-schedule-id').value;
    const name = document.getElementById('edit-schedule-name').value.trim();
    const planName = document.getElementById('edit-schedule-plan').value;
    const frequency = document.getElementById('edit-schedule-frequency').value;
    const time = document.getElementById('edit-schedule-time').value;
    const cron = document.getElementById('edit-schedule-cron').value.trim();
    const executionMode = document.getElementById('edit-schedule-execution-mode').value;
    const enabled = document.getElementById('edit-schedule-enabled').checked;

    if (!name || !planName) {
        alert('Please fill in all required fields');
        return;
    }

    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '⏳ Saving...';
    submitBtn.disabled = true;

    try {
        const response = await apiFetch(`${API_BASE}/api/schedules/${scheduleId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                name: name,
                plan_name: planName,
                frequency: frequency,
                time: time,
                cron: frequency === 'custom' ? cron : null,
                execution_mode: executionMode,
                enabled: enabled
            })
        });

        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || `HTTP ${response.status}`);
        }

        closeEditScheduleModal();
        loadSchedules(); // Refresh the list
    } catch (error) {
        alert(`Failed to update schedule: ${error.message}`);
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

// Setup edit schedule modal event listeners
function setupEditScheduleModal() {
    const form = document.getElementById('edit-schedule-form');
    if (form) {
        form.addEventListener('submit', handleEditSchedule);
    }

    const cancelBtn = document.getElementById('cancel-edit-schedule');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', closeEditScheduleModal);
    }

    const closeBtn = document.getElementById('close-edit-schedule-modal');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeEditScheduleModal);
    }

    const frequencySelect = document.getElementById('edit-schedule-frequency');
    if (frequencySelect) {
        frequencySelect.addEventListener('change', function() {
            const timeGroup = document.getElementById('edit-schedule-time-group');
            const cronGroup = document.getElementById('edit-schedule-cron-group');
            if (this.value === 'custom') {
                timeGroup.classList.add('d-none');
                cronGroup.classList.remove('d-none');
            } else {
                timeGroup.classList.remove('d-none');
                cronGroup.classList.add('d-none');
            }
        });
    }

    // Close on outside click
    const modal = document.getElementById('edit-schedule-modal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeEditScheduleModal();
            }
        });
    }
}

// Initialize when DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupEditScheduleModal);
} else {
    setupEditScheduleModal();
}

// Toggle credential fields in Edit Server modal based on auth type selection
function toggleEditServerCredFields() {
    const authType = document.getElementById('edit-server-auth-type').value;
    const passwordGroup = document.getElementById('edit-server-password-group');
    const keyGroup = document.getElementById('edit-server-key-group');
    const passphraseGroup = document.getElementById('edit-server-passphrase-group');

    // Hide all credential fields first
    if (passwordGroup) passwordGroup.style.display = 'none';
    if (keyGroup) keyGroup.style.display = 'none';
    if (passphraseGroup) passphraseGroup.style.display = 'none';

    // Show appropriate fields based on auth type
    if (authType === 'password') {
        if (passwordGroup) passwordGroup.style.display = 'block';
    } else if (authType === 'public_key') {
        if (keyGroup) keyGroup.style.display = 'block';
        if (passphraseGroup) passphraseGroup.style.display = 'block';
    }
}

async function deleteSchedule(scheduleId) {
    if (!confirm('Delete this schedule?')) {
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/schedules/${scheduleId}`, {
            method: 'DELETE'
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        selectedScheduleIds.delete(String(scheduleId));

        loadSchedules();
    } catch (error) {
        alert(`Failed to delete schedule: ${error.message}`);
    }
}

// ====================
// Settings Functions
// ====================

function showSettingsModal() {
    document.getElementById('settings-modal').style.display = 'flex';
}

function hideSettingsModal() {
    document.getElementById('settings-modal').style.display = 'none';
}

async function loadSettings() {
    try {
        const response = await apiFetch(`${API_BASE}/api/settings`);
        if (!response.ok) return; // Settings may not exist yet

        const settings = await response.json();

        // Email settings
        if (settings.email) {
            document.getElementById('email-enabled').checked = settings.email.enabled || false;
            document.getElementById('smtp-host').value = settings.email.smtp_host || '';
            document.getElementById('smtp-port').value = settings.email.smtp_port || 587;
            document.getElementById('smtp-user').value = settings.email.smtp_user || '';
            document.getElementById('smtp-from').value = settings.email.smtp_from || '';
            document.getElementById('smtp-to').value = settings.email.smtp_to || '';
            document.getElementById('notify-failures').checked = settings.email.notify_failures !== false;
            document.getElementById('notify-warnings').checked = settings.email.notify_warnings || false;
            document.getElementById('notify-completion').checked = settings.email.notify_completion || false;
            toggleEmailConfig();
        }

        // Auth settings
        if (settings.auth) {
            document.getElementById('require-strict-auth').checked = settings.auth.strict || false;
        }

        // WebSocket settings
        if (settings.websocket !== undefined) {
            document.getElementById('enable-websocket').checked = settings.websocket;
        }
    } catch (error) {
        console.error('Failed to load settings:', error);
    }
}

function toggleEmailConfig() {
    const enabled = document.getElementById('email-enabled').checked;
    document.getElementById('email-config').style.display = enabled ? 'block' : 'none';
}

async function saveSettings() {
    const settings = {
        email: {
            enabled: document.getElementById('email-enabled').checked,
            smtp_host: document.getElementById('smtp-host').value,
            smtp_port: parseInt(document.getElementById('smtp-port').value, 10),
            smtp_user: document.getElementById('smtp-user').value,
            smtp_password: document.getElementById('smtp-password').value || undefined,
            smtp_from: document.getElementById('smtp-from').value,
            smtp_to: document.getElementById('smtp-to').value,
            notify_failures: document.getElementById('notify-failures').checked,
            notify_warnings: document.getElementById('notify-warnings').checked,
            notify_completion: document.getElementById('notify-completion').checked
        },
        auth: {
            strict: document.getElementById('require-strict-auth').checked
        },
        websocket: document.getElementById('enable-websocket').checked
    };

    try {
        const response = await apiFetch(`${API_BASE}/api/settings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(settings)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || `HTTP ${response.status}`);
        }

        alert('Settings saved successfully');
        hideSettingsModal();
    } catch (error) {
        alert(`Failed to save settings: ${error.message}`);
    }
}

async function testEmail() {
    const smtp = {
        host: document.getElementById('smtp-host').value,
        port: parseInt(document.getElementById('smtp-port').value, 10),
        user: document.getElementById('smtp-user').value,
        password: document.getElementById('smtp-password').value,
        from: document.getElementById('smtp-from').value,
        to: document.getElementById('smtp-to').value
    };

    if (!smtp.host || !smtp.user || !smtp.from || !smtp.to) {
        alert('Please fill in all SMTP fields before testing');
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/settings/test-email`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(smtp)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || `HTTP ${response.status}`);
        }

        alert('Test email sent successfully! Check your inbox.');
    } catch (error) {
        alert(`Failed to send test email: ${error.message}`);
    }
}

function toggleApiKeyVisibility() {
    const keyElement = document.getElementById('current-api-key');
    const button = document.getElementById('show-api-key');

    if (keyElement.textContent === '••••••••') {
        // Load and show the actual key
        apiFetch(`${API_BASE}/api/settings/api-key`)
            .then(res => res.json())
            .then(data => {
                keyElement.textContent = data.api_key;
                button.textContent = '🔒 Hide';
            })
            .catch(err => alert('Failed to load API key'));
    } else {
        keyElement.textContent = '••••••••';
        button.textContent = '👁️ Show';
    }
}

async function regenerateApiKey() {
    if (!confirm('Regenerate API key? This will invalidate the current key and require updating all remote clients.')) {
        return;
    }

    try {
        const response = await apiFetch(`${API_BASE}/api/settings/api-key`, {
            method: 'POST'
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();

        alert(`New API key generated:\n\n${data.api_key}\n\nPlease save this key securely.`);
        document.getElementById('current-api-key').textContent = data.api_key;
        document.getElementById('show-api-key').textContent = '🔒 Hide';
    } catch (error) {
        alert(`Failed to regenerate API key: ${error.message}`);
    }
}

// ============================================
// Update Management Functions
// ============================================

/**
 * Load deployment information and populate update management UI
 */
async function loadUpdateInfo() {
    try {
        const response = await apiFetch(`${API_BASE}/api/updates/deployment-info`);
        if (!response.ok) {
            console.warn('Failed to load deployment info');
            return;
        }

        const data = await response.json();
        if (!data.success) return;

        // Update version display
        const versionEl = document.getElementById('update-current-version');
        if (versionEl) versionEl.textContent = data.version || 'Unknown';

        // Update deployment type badge
        const deploymentEl = document.getElementById('update-deployment-type');
        if (deploymentEl && data.deployment) {
            const badgeClass = data.deployment.can_update ? 'badge-success' : 'badge-warning';
            deploymentEl.innerHTML = `<span class="badge ${badgeClass}">${data.deployment.description || data.deployment.type}</span>`;
        }

        // Update platform info
        const platformEl = document.getElementById('update-platform');
        if (platformEl && data.platform) {
            platformEl.textContent = `${data.platform.system} ${data.platform.release}`;
        }

        // Update last backup info
        const backupEl = document.getElementById('update-last-backup');
        if (backupEl) {
            if (data.last_backup) {
                backupEl.textContent = `v${data.last_backup.version} (${data.last_backup.created_at || data.last_backup.id})`;
            } else {
                backupEl.textContent = 'None';
            }
        }

        // Set current channel in dropdown
        const channelSelect = document.getElementById('update-channel-select');
        if (channelSelect && data.channel) {
            channelSelect.value = data.channel;
            updateChannelDescription(data.channel);
        }

        // Load available backups for rollback dropdown
        await loadBackupsList();

    } catch (error) {
        console.error('Failed to load update info:', error);
    }
}

/**
 * Update the channel description text
 */
function updateChannelDescription(channel) {
    const descEl = document.getElementById('channel-description');
    if (!descEl) return;

    const descriptions = {
        'stable': 'Production-ready releases',
        'beta': 'Pre-release testing builds',
        'nightly': 'Latest development builds (may be unstable)'
    };
    descEl.textContent = descriptions[channel] || '';
}

/**
 * Save the selected update channel
 */
async function saveUpdateChannel() {
    const channelSelect = document.getElementById('update-channel-select');
    const channel = channelSelect.value;

    try {
        const response = await apiFetch(`${API_BASE}/api/updates/channel`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ channel })
        });

        const data = await response.json();
        if (data.success) {
            updateChannelDescription(channel);
            showToast(`Update channel set to: ${channel}`, 'success');
        } else {
            showToast(data.error || 'Failed to save channel', 'error');
        }
    } catch (error) {
        console.error('Failed to save update channel:', error);
        showToast('Failed to save update channel', 'error');
    }
}

/**
 * Check for available updates (both audits and application)
 */
async function checkAllUpdates() {
    const checkBtn = document.getElementById('check-all-updates');
    const statusEl = document.getElementById('update-check-status');
    const statusPanel = document.getElementById('update-status-panel');

    // Update sections (show/hide based on availability)
    const auditSection = document.getElementById('audit-update-section');
    const fullSection = document.getElementById('full-update-section');
    const noUpdatesMsg = document.getElementById('no-updates-message');
    const auditBtn = document.getElementById('apply-audit-update');
    const fullBtn = document.getElementById('apply-full-update');
    const auditVersionInfo = document.getElementById('audit-version-info');
    const appVersionInfo = document.getElementById('app-version-info');

    checkBtn.disabled = true;
    checkBtn.textContent = '🔄 Checking...';
    statusEl.textContent = '';

    // Hide all update sections while checking
    if (auditSection) auditSection.style.display = 'none';
    if (fullSection) fullSection.style.display = 'none';
    if (noUpdatesMsg) noUpdatesMsg.style.display = 'none';

    try {
        const response = await apiFetch(`${API_BASE}/api/updates/check`);
        const data = await response.json();

        if (!data.success) {
            statusEl.textContent = data.error || 'Check failed';
            statusEl.className = 'status-text update-error';
            return;
        }

        // Show status panel
        statusPanel.style.display = 'block';

        // Build status message
        const statusText = document.getElementById('update-status-text');
        const detailsEl = document.getElementById('update-details');

        let hasAuditUpdate = false;
        let hasAppUpdate = false;
        let details = [];

        // Check application updates
        if (data.application && data.application.update_available) {
            hasAppUpdate = true;
            fullSection.style.display = 'block';
            fullBtn.disabled = false;
            fullBtn.textContent = `🚀 Update to v${data.application.latest_version}`;
            appVersionInfo.innerHTML = `<span class="version-badge current">v${data.current_version}</span> → <span class="version-badge new">v${data.application.latest_version}</span>`;
            details.push(`Application: v${data.current_version} → v${data.application.latest_version}`);
        } else {
            fullSection.style.display = 'none';
            details.push('Application: Up to date');
        }

        // Check audit updates
        if (data.audits && data.audits.update_available) {
            hasAuditUpdate = true;
            auditSection.style.display = 'block';
            auditBtn.disabled = false;
            auditBtn.textContent = `📜 Update to v${data.audits.latest_version}`;
            auditVersionInfo.innerHTML = `<span class="version-badge current">v${data.current_version}</span> → <span class="version-badge new">v${data.audits.latest_version}</span>`;
            details.push(`Audits: v${data.current_version} → v${data.audits.latest_version}`);
        } else {
            auditSection.style.display = 'none';
            details.push('Audits: Up to date');
        }

        const hasUpdates = hasAuditUpdate || hasAppUpdate;

        if (hasUpdates) {
            statusText.textContent = 'Updates Available';
            statusText.className = 'update-status-text update-available';
            statusEl.textContent = '✓ Updates found';
            statusEl.className = 'status-text update-available';
            noUpdatesMsg.style.display = 'none';
        } else {
            statusText.textContent = 'All Up to Date';
            statusText.className = 'update-status-text update-current';
            statusEl.textContent = '✓ Current';
            statusEl.className = 'status-text update-current';
            // Show "no updates" message
            noUpdatesMsg.style.display = 'block';
        }

        detailsEl.innerHTML = details.map(d => `<div>${d}</div>`).join('');

        // Store update data for apply functions
        window.pendingUpdates = data;

    } catch (error) {
        console.error('Failed to check updates:', error);
        statusEl.textContent = 'Error checking updates';
        statusEl.className = 'status-text update-error';
    } finally {
        checkBtn.disabled = false;
        checkBtn.textContent = '🔍 Check for Updates';
    }
}

/**
 * Apply audit-only update
 */
async function applyAuditUpdate() {
    if (!confirm('Update audit scripts?\n\nThis will download and install the latest security audit scripts. A backup will be created automatically.')) {
        return;
    }

    const btn = document.getElementById('apply-audit-update');
    const statusEl = document.getElementById('audit-update-status');
    const auditSection = document.getElementById('audit-update-section');

    btn.disabled = true;
    btn.textContent = '⏳ Updating...';
    statusEl.textContent = '';

    try {
        const response = await apiFetch(`${API_BASE}/api/updates/apply`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                type: 'audits',
                create_backup: true
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('Audit scripts updated successfully!', 'success');

            // Hide the audit update section after successful update
            auditSection.style.display = 'none';

            // Check if any other updates are still pending
            const fullSection = document.getElementById('full-update-section');
            const noUpdatesMsg = document.getElementById('no-updates-message');
            if (fullSection && fullSection.style.display === 'none') {
                // No other updates pending, show "all up to date"
                noUpdatesMsg.style.display = 'block';
                document.getElementById('update-status-text').textContent = 'All Up to Date';
                document.getElementById('update-status-text').className = 'update-status-text update-current';
            }

            // Refresh the audit list if on audits tab
            if (typeof loadAudits === 'function') {
                loadAudits();
            }

            // Refresh backup list
            await loadBackupsList();
        } else {
            statusEl.textContent = data.error || 'Update failed';
            statusEl.className = 'status-text update-error';
            showToast(data.error || 'Audit update failed', 'error');
            btn.disabled = false;
            btn.textContent = '📜 Apply Audit Update';
        }

    } catch (error) {
        console.error('Audit update error:', error);
        statusEl.textContent = 'Update failed';
        statusEl.className = 'status-text update-error';
        showToast('Failed to apply audit update', 'error');
        btn.disabled = false;
        btn.textContent = '📜 Apply Audit Update';
    }
}

/**
 * Apply full application update
 */
async function applyFullUpdate() {
    if (!confirm('Update the full application?\n\nThis will download the latest version. For safety, the actual update will be applied via the command-line updater script.')) {
        return;
    }

    const btn = document.getElementById('apply-full-update');
    const statusEl = document.getElementById('full-update-status');
    const fullSection = document.getElementById('full-update-section');

    btn.disabled = true;
    btn.textContent = '⏳ Preparing...';
    statusEl.textContent = '';

    try {
        const response = await apiFetch(`${API_BASE}/api/updates/apply`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                type: 'application',
                create_backup: true,
                restart_services: true
            })
        });

        const data = await response.json();

        if (data.success) {
            if (data.action_required) {
                // Full updates require manual intervention for safety
                const instructions = data.instructions ? data.instructions.join('\n') : 'See documentation for update instructions.';
                alert(`Full Application Update\n\n${instructions}`);
                showToast('Follow the instructions to complete the update', 'info');

                // Hide section since user has the instructions
                fullSection.style.display = 'none';

                // Check if any other updates are still pending
                const auditSection = document.getElementById('audit-update-section');
                const noUpdatesMsg = document.getElementById('no-updates-message');
                if (auditSection && auditSection.style.display === 'none') {
                    noUpdatesMsg.style.display = 'block';
                    document.getElementById('update-status-text').textContent = 'All Up to Date';
                    document.getElementById('update-status-text').className = 'update-status-text update-current';
                }
            } else {
                statusEl.textContent = data.message || 'Update initiated';
                statusEl.className = 'status-text update-current';
                showToast('Application update initiated!', 'success');

                // Hide section on success
                fullSection.style.display = 'none';
            }
        } else {
            statusEl.textContent = data.error || 'Update failed';
            statusEl.className = 'status-text update-error';
            showToast(data.error || 'Application update failed', 'error');
            btn.disabled = false;
            btn.textContent = '🚀 Apply Full Update';
        }

    } catch (error) {
        console.error('Full update error:', error);
        statusEl.textContent = 'Update failed';
        statusEl.className = 'status-text update-error';
        showToast('Failed to apply application update', 'error');
        btn.disabled = false;
        btn.textContent = '🚀 Apply Full Update';
    }
}

/**
 * Load available backups for rollback dropdown
 */
async function loadBackupsList() {
    const select = document.getElementById('rollback-select');
    const rollbackBtn = document.getElementById('perform-rollback');

    if (!select) return;

    try {
        const response = await apiFetch(`${API_BASE}/api/updates/backups`);
        const data = await response.json();

        // Clear existing options
        select.innerHTML = '';

        if (data.success && data.backups && data.backups.length > 0) {
            data.backups.forEach(backup => {
                const option = document.createElement('option');
                option.value = backup.id;
                option.textContent = `v${backup.version} - ${backup.created_at || backup.id}`;
                if (backup.type) {
                    option.textContent += ` (${backup.type})`;
                }
                select.appendChild(option);
            });
            rollbackBtn.disabled = false;
        } else {
            const option = document.createElement('option');
            option.value = '';
            option.textContent = '-- No backups available --';
            select.appendChild(option);
            rollbackBtn.disabled = true;
        }

    } catch (error) {
        console.error('Failed to load backups:', error);
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '-- Error loading backups --';
        select.innerHTML = '';
        select.appendChild(option);
        rollbackBtn.disabled = true;
    }
}

/**
 * Perform rollback to selected backup
 */
async function performRollback() {
    const select = document.getElementById('rollback-select');
    const backupId = select.value;

    if (!backupId) {
        alert('Please select a backup to restore');
        return;
    }

    const selectedText = select.options[select.selectedIndex].text;
    if (!confirm(`Rollback to: ${selectedText}?\n\nThis will restore the toolkit to the selected backup version. A pre-rollback backup will be created first.`)) {
        return;
    }

    const btn = document.getElementById('perform-rollback');
    btn.disabled = true;
    btn.textContent = '⏳ Rolling back...';

    try {
        const response = await apiFetch(`${API_BASE}/api/updates/rollback`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ backup_id: backupId })
        });

        const data = await response.json();

        if (data.success) {
            if (data.action_required) {
                // Full rollbacks require manual intervention
                const instructions = data.instructions ? data.instructions.join('\n') : 'See documentation for rollback instructions.';
                alert(`Rollback Instructions\n\n${instructions}`);
            } else {
                showToast(data.message || 'Rollback completed!', 'success');

                // Refresh audit list if applicable
                if (typeof loadAudits === 'function') {
                    loadAudits();
                }

                // Refresh backups list
                await loadBackupsList();

                // Refresh deployment info
                await loadUpdateInfo();
            }
        } else {
            showToast(data.error || 'Rollback failed', 'error');
        }

    } catch (error) {
        console.error('Rollback error:', error);
        showToast('Rollback failed', 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = '↩️ Rollback';
    }
}

/**
 * Simple toast notification helper
 */
function showToast(message, type = 'info') {
    if (window.__showToastForwarding === true) {
        return;
    }

    if (document.body) {
        document.body.dataset.lastToastMessage = message;
        document.body.dataset.lastToastType = type;
        document.body.dataset.lastToastTimestamp = String(Date.now());
    }

    const containerClass = 'toast-container';
    let container = document.querySelector(`.${containerClass}`);
    if (!container) {
        container = document.createElement('div');
        container.className = containerClass;
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', type === 'error' ? 'assertive' : 'polite');

    const icon = document.createElement('span');
    icon.className = 'toast-icon';
    icon.textContent = type === 'success' ? '✓' : (type === 'error' ? '!' : 'i');

    const content = document.createElement('span');
    content.className = 'toast-message';
    content.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(content);
    container.appendChild(toast);

    window.setTimeout(() => {
        toast.remove();
        if (container && !container.children.length) {
            container.remove();
        }
    }, 4000);

    const logFn = type === 'error' ? console.error : console.log;
    logFn(`[${type.toUpperCase()}] ${message}`);

    if (typeof showNotification === 'function' && showNotification !== showToast) {
        try {
            window.__showToastForwarding = true;
            showNotification(message, type);
        } finally {
            window.__showToastForwarding = false;
        }
    }
}

// Initialize update management event listeners
function initUpdateManagement() {
    // Channel selector
    const channelSelect = document.getElementById('update-channel-select');
    if (channelSelect) {
        channelSelect.addEventListener('change', () => updateChannelDescription(channelSelect.value));
    }

    // Save channel button
    const saveChannelBtn = document.getElementById('save-update-channel');
    if (saveChannelBtn) {
        saveChannelBtn.addEventListener('click', saveUpdateChannel);
    }

    // Check updates button
    const checkBtn = document.getElementById('check-all-updates');
    if (checkBtn) {
        checkBtn.addEventListener('click', checkAllUpdates);
    }

    // Apply audit update button
    const auditBtn = document.getElementById('apply-audit-update');
    if (auditBtn) {
        auditBtn.addEventListener('click', applyAuditUpdate);
    }

    // Apply full update button
    const fullBtn = document.getElementById('apply-full-update');
    if (fullBtn) {
        fullBtn.addEventListener('click', applyFullUpdate);
    }

    // Rollback button
    const rollbackBtn = document.getElementById('perform-rollback');
    if (rollbackBtn) {
        rollbackBtn.addEventListener('click', performRollback);
    }

    // Load update info when settings modal is opened
    const settingsBtn = document.getElementById('settings-btn');
    if (settingsBtn) {
        settingsBtn.addEventListener('click', () => {
            // Load update info after a short delay to ensure modal is visible
            setTimeout(loadUpdateInfo, 100);
        });
    }
}

// Call init when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initUpdateManagement);
} else {
    initUpdateManagement();
}

// Make functions available globally
window.testServer = testServer;
window.removeServer = removeServer;
window.runPlan = runPlan;
window.viewPlanAudits = viewPlanAudits;
window.deletePlan = deletePlan;
window.viewHistoryDetails = viewHistoryDetails;
window.deleteHistoryItem = deleteHistoryItem;
window.toggleSchedule = toggleSchedule;
window.editSchedule = editSchedule;
window.deleteSchedule = deleteSchedule;

// ============================================
// Help Modal Functionality
// ============================================

/**
 * Initialize help icon click handlers using event delegation
 * This allows dynamically added help icons to work without page refresh
 */
function initHelpModal() {
    // Get modal elements
    const modal = document.getElementById('help-modal');
    const closeBtn = document.getElementById('close-help-modal');
    const closeFooterBtn = document.getElementById('close-help-modal-btn');

    if (!modal) {
        console.warn('Help modal not found');
        return;
    }

    // Event delegation: handle clicks on any .help-icon, even dynamically added ones
    document.addEventListener('click', async (e) => {
        const helpIcon = e.target.closest('.help-icon');
        if (helpIcon) {
            e.preventDefault();
            const panelId = helpIcon.getAttribute('data-help');
            if (panelId) {
                await showHelpModal(panelId);
            }
        }
    });

    // Close modal handlers
    if (closeBtn) {
        closeBtn.addEventListener('click', () => hideHelpModal());
    }
    if (closeFooterBtn) {
        closeFooterBtn.addEventListener('click', () => hideHelpModal());
    }

    // Close on backdrop click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            hideHelpModal();
        }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.style.display !== 'none') {
            hideHelpModal();
        }
    });
}

/**
 * Show the help modal with documentation for the specified panel
 * @param {string} panelId - The panel identifier (e.g., 'deploy', 'audits')
 */
async function showHelpModal(panelId) {
    const modal = document.getElementById('help-modal');
    const modalTitle = document.getElementById('help-modal-title');
    const modalContent = document.getElementById('help-modal-content');
    const modalSource = document.getElementById('help-source-file');

    // Show modal with loading state
    modal.style.display = 'flex';
    modalTitle.textContent = '📖 Loading...';
    modalContent.innerHTML = `
        <div class="help-loading">
            <span class="spinner"></span>
            <span>Loading documentation...</span>
        </div>
    `;
    modalSource.textContent = '';

    try {
        const response = await apiFetch(`${API_BASE}/api/help/${panelId}`);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();

        // Update modal content
        modalTitle.textContent = `📖 ${data.title}`;
        modalContent.innerHTML = data.content;
        modalSource.textContent = `Source: ${data.source}`;

    } catch (error) {
        console.error('Failed to load help:', error);
        modalTitle.textContent = '📖 Help';
        modalContent.innerHTML = `
            <div style="text-align: center; padding: 40px; color: var(--text-secondary);">
                <p style="font-size: 2rem; margin-bottom: 16px;">📚</p>
                <p>Could not load documentation for <strong>${panelId}</strong>.</p>
                <p style="margin-top: 8px; font-size: 0.9rem;">
                    Error: ${error.message}
                </p>
            </div>
        `;
        modalSource.textContent = '';
    }
}

/**
 * Hide the help modal
 */
function hideHelpModal() {
    const modal = document.getElementById('help-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Initialize help modal when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initHelpModal);
} else {
    // DOM already loaded, initialize immediately
    initHelpModal();
}

// Export for global access
window.showHelpModal = showHelpModal;
window.hideHelpModal = hideHelpModal;
