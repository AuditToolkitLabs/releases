/**
 * Service Worker for Offline Mode
 *
 * Caches key resources to allow viewing cached reports when disconnected.
 * Uses cache-first strategy for static assets and network-first for API calls.
 */

const SW_VERSION = '20260313a';
const CACHE_NAME = `audit-toolkit-${SW_VERSION}`;
const STATIC_CACHE_NAME = `audit-toolkit-static-${SW_VERSION}`;
const REPORTS_CACHE_NAME = `audit-toolkit-reports-${SW_VERSION}`;

// Static assets to cache immediately
const STATIC_ASSETS = [
    '/',
    '/static/style.css',
    '/static/css/home.css',
    '/static/css/connect.css',
    '/static/css/discovery.css',
    '/static/css/operations.css',
    '/static/css/deploy.css',
    '/static/css/history.css',
    '/static/css/logs.css',
    '/static/css/reports.css',
    '/static/css/audits.css',
    '/static/css/plans.css',
    '/static/css/schedule.css',
    '/static/css/admin.css',
    '/static/css/wizard.css',
    '/static/script.js',
    '/static/dashboard.js',
    '/static/js/home.js',
    '/static/js/connect.js',
    '/static/js/discovery.js',
    '/static/js/operations.js',
    '/static/js/admin.js',
    '/static/js/remediation.js',
    '/static/js/wizard.js',
    '/static/js/index-tabs.js',
    '/static/js/session-manager.js',
    '/static/js/shortcuts.js',
];

// API endpoints to cache for offline access
const CACHEABLE_API_PATTERNS = [
    /\/api\/reports\//,
    /\/api\/history\//,
    /\/api\/audits\/list/,
    /\/api\/servers\//,
];

/**
 * Install event - cache static assets
 */
self.addEventListener('install', (event) => {
    console.log('[SW] Installing service worker...');

    event.waitUntil(
        caches.open(STATIC_CACHE_NAME)
            .then((cache) => {
                console.log('[SW] Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => {
                // Skip waiting to activate immediately
                return self.skipWaiting();
            })
            .catch((error) => {
                console.error('[SW] Error caching static assets:', error);
            })
    );
});

/**
 * Activate event - clean up old caches
 */
self.addEventListener('activate', (event) => {
    console.log('[SW] Activating service worker...');

    event.waitUntil(
        caches.keys()
            .then((cacheNames) => {
                return Promise.all(
                    cacheNames
                        .filter((name) => {
                            // Delete old versions of our caches
                            return name.startsWith('audit-toolkit-') &&
                                   name !== STATIC_CACHE_NAME &&
                                   name !== REPORTS_CACHE_NAME;
                        })
                        .map((name) => {
                            console.log('[SW] Deleting old cache:', name);
                            return caches.delete(name);
                        })
                );
            })
            .then(() => {
                // Take control of all clients immediately
                return self.clients.claim();
            })
    );
});

/**
 * Fetch event - serve from cache or network
 */
self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    // Skip non-GET requests
    if (event.request.method !== 'GET') {
        return;
    }

    // Skip cross-origin requests (CDN scripts, etc.)
    if (url.origin !== location.origin) {
        return;
    }

    // Determine cache strategy based on request type
    if (isStaticAsset(url.pathname)) {
        // Network-first for JS/CSS to avoid stale UI; cache-first for other static assets
        if (isFreshnessCriticalStaticAsset(url.pathname)) {
            event.respondWith(networkFirstWithCache(event.request, STATIC_CACHE_NAME));
        } else {
            event.respondWith(cacheFirst(event.request, STATIC_CACHE_NAME));
        }
    } else if (isCacheableAPI(url.pathname)) {
        // Network-first for API calls (cache for offline)
        event.respondWith(networkFirstWithCache(event.request, REPORTS_CACHE_NAME));
    } else if (url.pathname === '/' || url.pathname.endsWith('.html')) {
        // Network-first for HTML pages
        event.respondWith(networkFirstWithCache(event.request, STATIC_CACHE_NAME));
    }
});

/**
 * Check if URL is a static asset
 */
function isStaticAsset(pathname) {
    return pathname.startsWith('/static/') ||
           pathname.endsWith('.css') ||
           pathname.endsWith('.js') ||
           pathname.endsWith('.png') ||
           pathname.endsWith('.ico') ||
           pathname.endsWith('.svg');
}

function isFreshnessCriticalStaticAsset(pathname) {
    return pathname.endsWith('.js') || pathname.endsWith('.css');
}

/**
 * Check if URL is a cacheable API endpoint
 */
function isCacheableAPI(pathname) {
    return CACHEABLE_API_PATTERNS.some(pattern => pattern.test(pathname));
}

/**
 * Cache-first strategy
 * Try cache first, fall back to network
 */
async function cacheFirst(request, cacheName) {
    const cache = await caches.open(cacheName);
    const cachedResponse = await cache.match(request);

    if (cachedResponse) {
        // Return from cache, but also update cache in background
        fetchAndCache(request, cache);
        return cachedResponse;
    }

    // Not in cache, try network
    try {
        const networkResponse = await fetch(request);
        if (networkResponse.ok) {
            cache.put(request, networkResponse.clone());
        }
        return networkResponse;
    } catch (error) {
        console.error('[SW] Network request failed:', error);
        return new Response('Offline - Resource not cached', { status: 503 });
    }
}

/**
 * Network-first strategy with cache fallback
 * Try network first, fall back to cache if offline
 */
async function networkFirstWithCache(request, cacheName) {
    const cache = await caches.open(cacheName);

    try {
        const networkResponse = await fetch(request);

        if (networkResponse.ok) {
            // Cache successful responses
            cache.put(request, networkResponse.clone());
        }

        return networkResponse;
    } catch (error) {
        // Network failed, try cache
        console.log('[SW] Network failed, trying cache for:', request.url);
        const cachedResponse = await cache.match(request);

        if (cachedResponse) {
            // Add offline header to indicate cached content
            const headers = new Headers(cachedResponse.headers);
            headers.set('X-Served-From', 'cache');

            return new Response(cachedResponse.body, {
                status: cachedResponse.status,
                statusText: cachedResponse.statusText,
                headers: headers
            });
        }

        // Return offline page for HTML requests
        if (request.headers.get('Accept')?.includes('text/html')) {
            return generateOfflinePage();
        }

        // Return error for API requests
        return new Response(JSON.stringify({
            error: 'Offline',
            message: 'You are currently offline. This data is not available in cache.',
            cached: false
        }), {
            status: 503,
            headers: { 'Content-Type': 'application/json' }
        });
    }
}

/**
 * Fetch and cache in background (stale-while-revalidate)
 */
async function fetchAndCache(request, cache) {
    try {
        const networkResponse = await fetch(request);
        if (networkResponse.ok) {
            cache.put(request, networkResponse);
        }
    } catch (error) {
        // Silently fail - we already served from cache
    }
}

/**
 * Generate offline page
 */
function generateOfflinePage() {
    const html = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Offline - Security Audit Toolkit</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: linear-gradient(135deg, #1f2937, #111827);
                    color: #f9fafb;
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 2rem;
                }
                .offline-container {
                    text-align: center;
                    max-width: 500px;
                }
                .offline-icon {
                    font-size: 4rem;
                    margin-bottom: 1.5rem;
                    animation: pulse 2s infinite;
                }
                @keyframes pulse {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.5; }
                }
                h1 { font-size: 2rem; margin-bottom: 1rem; }
                p { color: #9ca3af; margin-bottom: 1.5rem; line-height: 1.6; }
                .btn {
                    display: inline-block;
                    padding: 0.75rem 1.5rem;
                    background: #3b82f6;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-weight: 600;
                    transition: background 0.2s;
                }
                .btn:hover { background: #2563eb; }
                .cached-reports {
                    margin-top: 2rem;
                    padding-top: 2rem;
                    border-top: 1px solid #374151;
                }
                .cached-reports h2 {
                    font-size: 1rem;
                    color: #9ca3af;
                    margin-bottom: 1rem;
                }
            </style>
        </head>
        <body>
            <div class="offline-container">
                <div class="offline-icon">📡</div>
                <h1>You're Offline</h1>
                <p>
                    The Security Audit Toolkit requires an internet connection to function.
                    Some cached reports may still be available.
                </p>
                <button class="btn" onclick="location.reload()">Try Again</button>
                <div class="cached-reports">
                    <h2>Previously viewed reports may be available offline</h2>
                </div>
            </div>
        </body>
        </html>
    `;

    return new Response(html, {
        status: 200,
        headers: { 'Content-Type': 'text/html' }
    });
}

/**
 * Message handler for cache management
 */
self.addEventListener('message', (event) => {
    if (event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    } else if (event.data.type === 'CLEAR_CACHE') {
        event.waitUntil(
            caches.keys().then((cacheNames) => {
                return Promise.all(
                    cacheNames.map((name) => caches.delete(name))
                );
            })
        );
    } else if (event.data.type === 'CACHE_REPORT') {
        // Manually cache a specific report
        event.waitUntil(
            caches.open(REPORTS_CACHE_NAME).then((cache) => {
                return cache.add(event.data.url);
            })
        );
    }
});
