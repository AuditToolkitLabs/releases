"""
Storage Abstraction Layer for Security Audit Toolkit

Provides a unified interface for storing audit data, reports, and artifacts
across multiple storage backends:
- Local filesystem (default)
- NFS/SMB (mounted as local filesystem)
- Amazon S3 / S3-compatible (MinIO, Ceph, etc.)

Usage:
    from storage import storage_manager

    # Store a file
    storage_manager.put('reports/audit-2024-01.pdf', pdf_content)

    # Read a file
    content = storage_manager.get('reports/audit-2024-01.pdf')

    # List files
    files = storage_manager.list_files('reports/')

    # Delete a file
    storage_manager.delete('reports/audit-2024-01.pdf')

Configuration (via environment variables):
    STORAGE_BACKEND: "local" | "s3" | "nfs" | "smb" (default: "local")
    STORAGE_PATH: Base path for local/NFS/SMB storage (default: app root)

    # S3 Configuration
    S3_ENDPOINT_URL: S3 endpoint (for MinIO/Ceph, default: AWS S3)
    S3_ACCESS_KEY: Access key ID
    S3_SECRET_KEY: Secret access key
    S3_BUCKET: Bucket name
    S3_REGION: AWS region (default: us-east-1)
    S3_USE_SSL: Enable SSL (default: true)

    # Optional
    STORAGE_ENCRYPTION_KEY: AES-256 key for client-side encryption
    STORAGE_COMPRESSION: Enable compression (gzip) (default: false)
"""

from .backends.base import StorageBackend, StorageError, StorageNotFoundError
from .backends.local import LocalStorageBackend
from .backends.s3 import S3StorageBackend
from .manager import StorageManager, storage_manager
from .migration import StorageMigrator, MigrationStats, create_backend_from_config

__all__ = [
    'StorageBackend',
    'StorageError',
    'StorageNotFoundError',
    'LocalStorageBackend',
    'S3StorageBackend',
    'StorageManager',
    'storage_manager',
    'StorageMigrator',
    'MigrationStats',
    'create_backend_from_config',
]
