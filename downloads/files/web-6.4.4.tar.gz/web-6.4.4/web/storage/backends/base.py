"""
Storage Backend Base Class

Provides the abstract interface that all storage backends must implement.
Includes common exceptions and utilities.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import BinaryIO, Optional, List, Dict, Any, Union
import hashlib
import gzip
import io


class StorageError(Exception):
    """Base exception for storage operations."""
    pass


class StorageNotFoundError(StorageError):
    """Raised when a requested file/path is not found."""
    pass


class StoragePermissionError(StorageError):
    """Raised when permission is denied for a storage operation."""
    pass


class StorageQuotaExceededError(StorageError):
    """Raised when storage quota is exceeded."""
    pass


class StorageConnectionError(StorageError):
    """Raised when connection to storage backend fails."""
    pass


@dataclass
class StorageMetadata:
    """Metadata about a stored file."""
    path: str
    size: int
    content_type: Optional[str]
    last_modified: datetime
    etag: Optional[str] = None
    checksum_md5: Optional[str] = None
    checksum_sha256: Optional[str] = None
    custom_metadata: Optional[Dict[str, str]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert metadata to dictionary."""
        return {
            'path': self.path,
            'size': self.size,
            'content_type': self.content_type,
            'last_modified': self.last_modified.isoformat() if self.last_modified else None,
            'etag': self.etag,
            'checksum_md5': self.checksum_md5,
            'checksum_sha256': self.checksum_sha256,
            'custom_metadata': self.custom_metadata or {},
        }


class StorageBackend(ABC):
    """
    Abstract base class for storage backends.

    All storage backends must implement these methods to provide
    a consistent interface for file operations.

    Path handling:
    - All paths are relative to the storage root
    - Paths use forward slashes (/) regardless of OS
    - Paths should not start with /
    - Directory paths end with /
    """

    def __init__(
        self,
        compression_enabled: bool = False,
        encryption_key: Optional[bytes] = None,
    ):
        """
        Initialize the storage backend.

        Args:
            compression_enabled: Enable gzip compression for stored data
            encryption_key: AES-256 key for client-side encryption (32 bytes)
        """
        self.compression_enabled = compression_enabled
        self.encryption_key = encryption_key
        if encryption_key and len(encryption_key) != 32:
            raise ValueError("Encryption key must be 32 bytes (AES-256)")

    @abstractmethod
    def put(
        self,
        path: str,
        data: Union[bytes, BinaryIO],
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> StorageMetadata:
        """
        Store data at the given path.

        Args:
            path: Relative path to store the data
            data: Binary data or file-like object to store
            content_type: MIME type of the content
            metadata: Custom metadata to store with the file

        Returns:
            StorageMetadata for the stored file

        Raises:
            StorageError: If the operation fails
            StoragePermissionError: If write permission is denied
            StorageQuotaExceededError: If storage quota is exceeded
        """
        pass

    @abstractmethod
    def get(self, path: str) -> bytes:
        """
        Retrieve data from the given path.

        Args:
            path: Relative path to retrieve

        Returns:
            Binary content of the file

        Raises:
            StorageNotFoundError: If the path doesn't exist
            StorageError: If the operation fails
        """
        pass

    @abstractmethod
    def get_stream(self, path: str) -> BinaryIO:
        """
        Get a streaming reader for the file.

        Args:
            path: Relative path to retrieve

        Returns:
            File-like object for reading

        Raises:
            StorageNotFoundError: If the path doesn't exist
            StorageError: If the operation fails
        """
        pass

    @abstractmethod
    def delete(self, path: str) -> bool:
        """
        Delete the file at the given path.

        Args:
            path: Relative path to delete

        Returns:
            True if deleted, False if didn't exist

        Raises:
            StorageError: If the operation fails
            StoragePermissionError: If delete permission is denied
        """
        pass

    @abstractmethod
    def exists(self, path: str) -> bool:
        """
        Check if a path exists.

        Args:
            path: Relative path to check

        Returns:
            True if exists, False otherwise
        """
        pass

    @abstractmethod
    def list_files(
        self,
        prefix: str = '',
        recursive: bool = True,
    ) -> List[StorageMetadata]:
        """
        List files with the given prefix.

        Args:
            prefix: Path prefix to filter by
            recursive: Whether to list subdirectories

        Returns:
            List of StorageMetadata for matching files
        """
        pass

    @abstractmethod
    def get_metadata(self, path: str) -> StorageMetadata:
        """
        Get metadata for a file.

        Args:
            path: Relative path to get metadata for

        Returns:
            StorageMetadata for the file

        Raises:
            StorageNotFoundError: If the path doesn't exist
        """
        pass

    @abstractmethod
    def copy(self, source: str, destination: str) -> StorageMetadata:
        """
        Copy a file within the storage backend.

        Args:
            source: Source path
            destination: Destination path

        Returns:
            StorageMetadata for the copied file

        Raises:
            StorageNotFoundError: If source doesn't exist
            StorageError: If the operation fails
        """
        pass

    @abstractmethod
    def move(self, source: str, destination: str) -> StorageMetadata:
        """
        Move a file within the storage backend.

        Args:
            source: Source path
            destination: Destination path

        Returns:
            StorageMetadata for the moved file

        Raises:
            StorageNotFoundError: If source doesn't exist
            StorageError: If the operation fails
        """
        pass

    @abstractmethod
    def get_signed_url(
        self,
        path: str,
        expires_in: int = 3600,
        method: str = 'GET',
    ) -> Optional[str]:
        """
        Generate a signed/pre-signed URL for direct access.

        Args:
            path: Path to generate URL for
            expires_in: URL expiration time in seconds
            method: HTTP method (GET for download, PUT for upload)

        Returns:
            Signed URL string, or None if not supported

        Raises:
            StorageNotFoundError: If path doesn't exist (for GET)
        """
        pass

    @abstractmethod
    def get_stats(self) -> Dict[str, Any]:
        """
        Get storage backend statistics.

        Returns:
            Dictionary with backend info and stats
        """
        pass

    # ==================== Helper Methods ====================

    def _normalize_path(self, path: str) -> str:
        """Normalize a path for consistent handling."""
        # Convert backslashes to forward slashes
        path = path.replace('\\', '/')
        # Remove leading slash
        path = path.lstrip('/')
        # Remove duplicate slashes
        while '//' in path:
            path = path.replace('//', '/')
        return path

    def _compute_checksums(self, data: bytes) -> tuple:
        """Compute MD5 and SHA256 checksums.

        Note: MD5 is used for legacy compatibility/ETag generation only.
        SHA256 is used for security-critical integrity verification.
        """
        # MD5 used for non-security purposes (ETags, legacy systems)
        md5_hash = hashlib.md5(data, usedforsecurity=False).hexdigest()  # nosec B324
        sha256_hash = hashlib.sha256(data).hexdigest()
        return md5_hash, sha256_hash

    def _compress(self, data: bytes) -> bytes:
        """Compress data using gzip."""
        if not self.compression_enabled:
            return data
        buf = io.BytesIO()
        with gzip.GzipFile(fileobj=buf, mode='wb') as f:
            f.write(data)
        return buf.getvalue()

    def _decompress(self, data: bytes) -> bytes:
        """Decompress gzip data."""
        if not self.compression_enabled:
            return data
        try:
            buf = io.BytesIO(data)
            with gzip.GzipFile(fileobj=buf, mode='rb') as f:
                return f.read()
        except (gzip.BadGzipFile, OSError):
            # Data wasn't compressed
            return data

    def _encrypt(self, data: bytes) -> bytes:
        """Encrypt data using AES-256-GCM."""
        if not self.encryption_key:
            return data
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            import secrets
            nonce = secrets.token_bytes(12)
            aesgcm = AESGCM(self.encryption_key)
            ciphertext = aesgcm.encrypt(nonce, data, None)
            return nonce + ciphertext
        except ImportError:
            raise StorageError(
                "cryptography package required for encryption: pip install cryptography"
            )

    def _decrypt(self, data: bytes) -> bytes:
        """Decrypt AES-256-GCM encrypted data."""
        if not self.encryption_key:
            return data
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            nonce = data[:12]
            ciphertext = data[12:]
            aesgcm = AESGCM(self.encryption_key)
            return aesgcm.decrypt(nonce, ciphertext, None)
        except ImportError:
            raise StorageError(
                "cryptography package required for encryption: pip install cryptography"
            )

    def _prepare_data_for_storage(self, data: Union[bytes, BinaryIO]) -> bytes:
        """Prepare data for storage (read stream, compress, encrypt)."""
        # Read if stream
        if hasattr(data, 'read'):
            raw_data: bytes = data.read()  # type: ignore[union-attr]
        else:
            raw_data = data  # type: ignore[assignment]
        # Compress first, then encrypt
        raw_data = self._compress(raw_data)
        raw_data = self._encrypt(raw_data)
        return raw_data

    def _prepare_data_from_storage(self, data: bytes) -> bytes:
        """Prepare data from storage (decrypt, decompress)."""
        # Decrypt first, then decompress (reverse of storage)
        data = self._decrypt(data)
        data = self._decompress(data)
        return data

    def _guess_content_type(self, path: str) -> str:
        """Guess content type from file extension."""
        import mimetypes
        content_type, _ = mimetypes.guess_type(path)
        return content_type or 'application/octet-stream'
