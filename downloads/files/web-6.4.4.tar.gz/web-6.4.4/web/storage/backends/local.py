"""
Local Filesystem Storage Backend

Provides storage using the local filesystem. This backend also works
seamlessly with NFS/SMB/CIFS mounts - simply point STORAGE_PATH to
the mounted directory.

For NFS:
    mount -t nfs server:/export/audit /mnt/audit-storage
    export STORAGE_PATH=/mnt/audit-storage

For SMB/CIFS:
    mount -t cifs //server/share /mnt/audit-storage -o credentials=/etc/smbcreds
    export STORAGE_PATH=/mnt/audit-storage
"""

import io
import os
import shutil
import errno
from datetime import datetime

# fcntl is only available on Unix
try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    fcntl = None  # type: ignore[assignment]
    HAS_FCNTL = False
from pathlib import Path
from typing import BinaryIO, Optional, List, Dict, Any, Union

from .base import (
    StorageBackend,
    StorageMetadata,
    StorageError,
    StorageNotFoundError,
    StoragePermissionError,
    StorageQuotaExceededError,
)


class LocalStorageBackend(StorageBackend):
    """
    Local filesystem storage backend.

    Also works with NFS/SMB mounts by pointing base_path to
    the mount point.
    """

    def __init__(
        self,
        base_path: str,
        compression_enabled: bool = False,
        encryption_key: Optional[bytes] = None,
        create_dirs: bool = True,
        file_permissions: int = 0o644,
        dir_permissions: int = 0o755,
    ):
        """
        Initialize local storage backend.

        Args:
            base_path: Base directory for all storage operations
            compression_enabled: Enable gzip compression
            encryption_key: AES-256 key for encryption
            create_dirs: Auto-create directories as needed
            file_permissions: Default file permissions (octal)
            dir_permissions: Default directory permissions (octal)
        """
        super().__init__(compression_enabled, encryption_key)
        self.base_path = Path(base_path).resolve()
        self.create_dirs = create_dirs
        self.file_permissions = file_permissions
        self.dir_permissions = dir_permissions

        # Ensure base path exists
        if create_dirs:
            self.base_path.mkdir(parents=True, exist_ok=True)
        elif not self.base_path.exists():
            raise StorageError(f"Base path does not exist: {base_path}")

    def _get_full_path(self, path: str) -> Path:
        """Convert relative path to absolute path with security checks."""
        path = self._normalize_path(path)
        full_path = (self.base_path / path).resolve()

        # Security: Prevent path traversal attacks
        try:
            full_path.relative_to(self.base_path)
        except ValueError:
            raise StoragePermissionError(
                f"Path traversal attempt detected: {path}"
            )

        return full_path

    def _ensure_parent_dir(self, path: Path) -> None:
        """Ensure parent directory exists."""
        if self.create_dirs:
            path.parent.mkdir(parents=True, exist_ok=True)
            # Set directory permissions on Unix
            if hasattr(os, 'chmod'):
                try:
                    os.chmod(path.parent, self.dir_permissions)
                except OSError:
                    pass  # Best effort

    def put(
        self,
        path: str,
        data: Union[bytes, BinaryIO],
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> StorageMetadata:
        """Store data at the given path."""
        full_path = self._get_full_path(path)
        self._ensure_parent_dir(full_path)

        # Prepare data (compress/encrypt if enabled)
        prepared_data = self._prepare_data_for_storage(data)

        # Compute checksums on original data
        original_data: bytes
        if hasattr(data, 'read'):
            data.seek(0)  # type: ignore[union-attr]
            original_data = data.read()  # type: ignore[union-attr]
        else:
            original_data = data  # type: ignore[assignment]
        md5_sum, sha256_sum = self._compute_checksums(original_data)

        try:
            # Write with atomic operation using temp file
            temp_path = full_path.with_suffix('.tmp')
            with open(temp_path, 'wb') as f:
                # Try to get an exclusive lock (non-blocking, Unix only)
                if HAS_FCNTL and fcntl is not None:
                    try:
                        fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)  # type: ignore[attr-defined]
                    except OSError:
                        pass  # Lock not available
                f.write(prepared_data)
                f.flush()
                os.fsync(f.fileno())

            # Atomic rename
            temp_path.replace(full_path)

            # Set permissions
            if hasattr(os, 'chmod'):
                try:
                    os.chmod(full_path, self.file_permissions)
                except OSError:
                    pass

            # Store metadata in sidecar file if provided
            if metadata:
                self._write_metadata_file(full_path, metadata)

            # Get file stats
            stat = full_path.stat()

            return StorageMetadata(
                path=path,
                size=len(original_data),
                content_type=content_type or self._guess_content_type(path),
                last_modified=datetime.fromtimestamp(stat.st_mtime),
                checksum_md5=md5_sum,
                checksum_sha256=sha256_sum,
                custom_metadata=metadata,
            )

        except PermissionError as e:
            raise StoragePermissionError(f"Permission denied: {path}") from e
        except OSError as e:
            if e.errno == errno.ENOSPC:
                raise StorageQuotaExceededError("No space left on device") from e
            if e.errno == errno.EDQUOT:
                raise StorageQuotaExceededError("Disk quota exceeded") from e
            raise StorageError(f"Failed to write file: {e}") from e

    def get(self, path: str) -> bytes:
        """Retrieve data from the given path."""
        full_path = self._get_full_path(path)

        if not full_path.exists():
            raise StorageNotFoundError(f"File not found: {path}")

        try:
            with open(full_path, 'rb') as f:
                data = f.read()
            return self._prepare_data_from_storage(data)
        except PermissionError as e:
            raise StoragePermissionError(f"Permission denied: {path}") from e
        except OSError as e:
            raise StorageError(f"Failed to read file: {e}") from e

    def get_stream(self, path: str) -> BinaryIO:
        """Get a streaming reader for the file."""
        full_path = self._get_full_path(path)

        if not full_path.exists():
            raise StorageNotFoundError(f"File not found: {path}")

        try:
            # For encrypted/compressed files, we need to read all data
            if self.compression_enabled or self.encryption_key:
                data = self.get(path)
                return io.BytesIO(data)
            else:
                return open(full_path, 'rb')
        except PermissionError as e:
            raise StoragePermissionError(f"Permission denied: {path}") from e
        except OSError as e:
            raise StorageError(f"Failed to open file: {e}") from e

    def delete(self, path: str) -> bool:
        """Delete the file at the given path."""
        full_path = self._get_full_path(path)

        if not full_path.exists():
            return False

        try:
            if full_path.is_dir():
                shutil.rmtree(full_path)
            else:
                full_path.unlink()

            # Also remove metadata sidecar if exists
            meta_path = full_path.with_suffix(full_path.suffix + '.meta')
            if meta_path.exists():
                meta_path.unlink()

            return True
        except PermissionError as e:
            raise StoragePermissionError(f"Permission denied: {path}") from e
        except OSError as e:
            raise StorageError(f"Failed to delete: {e}") from e

    def exists(self, path: str) -> bool:
        """Check if a path exists."""
        full_path = self._get_full_path(path)
        return full_path.exists()

    def list_files(
        self,
        prefix: str = '',
        recursive: bool = True,
    ) -> List[StorageMetadata]:
        """List files with the given prefix."""
        prefix = self._normalize_path(prefix)
        search_path = self.base_path / prefix if prefix else self.base_path

        if not search_path.exists():
            return []

        results = []

        if recursive:
            iterator = search_path.rglob('*')
        else:
            iterator = search_path.glob('*')

        for item in iterator:
            # Skip directories and metadata files
            if item.is_dir() or item.suffix == '.meta':
                continue

            try:
                rel_path = str(item.relative_to(self.base_path))
                rel_path = rel_path.replace('\\', '/')  # Normalize for Windows
                results.append(self.get_metadata(rel_path))
            except (OSError, StorageError):
                continue  # Skip files we can't access

        return results

    def get_metadata(self, path: str) -> StorageMetadata:
        """Get metadata for a file."""
        full_path = self._get_full_path(path)

        if not full_path.exists():
            raise StorageNotFoundError(f"File not found: {path}")

        try:
            stat = full_path.stat()

            # Read custom metadata if available
            custom_metadata = self._read_metadata_file(full_path)

            return StorageMetadata(
                path=path,
                size=stat.st_size,
                content_type=self._guess_content_type(path),
                last_modified=datetime.fromtimestamp(stat.st_mtime),
                custom_metadata=custom_metadata,
            )
        except OSError as e:
            raise StorageError(f"Failed to get metadata: {e}") from e

    def copy(self, source: str, destination: str) -> StorageMetadata:
        """Copy a file within the storage backend."""
        src_path = self._get_full_path(source)
        dst_path = self._get_full_path(destination)

        if not src_path.exists():
            raise StorageNotFoundError(f"Source not found: {source}")

        self._ensure_parent_dir(dst_path)

        try:
            shutil.copy2(src_path, dst_path)

            # Copy metadata sidecar if exists
            src_meta = src_path.with_suffix(src_path.suffix + '.meta')
            if src_meta.exists():
                dst_meta = dst_path.with_suffix(dst_path.suffix + '.meta')
                shutil.copy2(src_meta, dst_meta)

            return self.get_metadata(destination)
        except PermissionError as e:
            raise StoragePermissionError("Permission denied for copy operation") from e
        except OSError as e:
            raise StorageError(f"Failed to copy: {e}") from e

    def move(self, source: str, destination: str) -> StorageMetadata:
        """Move a file within the storage backend."""
        src_path = self._get_full_path(source)
        dst_path = self._get_full_path(destination)

        if not src_path.exists():
            raise StorageNotFoundError(f"Source not found: {source}")

        self._ensure_parent_dir(dst_path)

        try:
            shutil.move(str(src_path), str(dst_path))

            # Move metadata sidecar if exists
            src_meta = src_path.with_suffix(src_path.suffix + '.meta')
            if src_meta.exists():
                dst_meta = dst_path.with_suffix(dst_path.suffix + '.meta')
                shutil.move(str(src_meta), str(dst_meta))

            return self.get_metadata(destination)
        except PermissionError as e:
            raise StoragePermissionError("Permission denied for move operation") from e
        except OSError as e:
            raise StorageError(f"Failed to move: {e}") from e

    def get_signed_url(
        self,
        path: str,
        expires_in: int = 3600,
        method: str = 'GET',
    ) -> Optional[str]:
        """
        Generate a URL for the file.

        For local storage, this returns a file:// URL.
        For network mounts, you might want to configure a web server
        to serve the files and return HTTP URLs instead.
        """
        full_path = self._get_full_path(path)

        if method == 'GET' and not full_path.exists():
            raise StorageNotFoundError(f"File not found: {path}")

        # Return file:// URL for local access
        return full_path.as_uri()

    def get_stats(self) -> Dict[str, Any]:
        """Get storage backend statistics."""
        try:
            # Get disk usage stats
            total, used, free = shutil.disk_usage(self.base_path)

            # Count files
            file_count = sum(1 for _ in self.base_path.rglob('*') if _.is_file())

            return {
                'backend': 'local',
                'base_path': str(self.base_path),
                'compression_enabled': self.compression_enabled,
                'encryption_enabled': self.encryption_key is not None,
                'disk_total_bytes': total,
                'disk_used_bytes': used,
                'disk_free_bytes': free,
                'disk_usage_percent': round(used / total * 100, 2) if total > 0 else 0,
                'file_count': file_count,
            }
        except OSError as e:
            return {
                'backend': 'local',
                'base_path': str(self.base_path),
                'error': str(e),
            }

    def _write_metadata_file(self, file_path: Path, metadata: Dict[str, str]) -> None:
        """Write metadata to a sidecar .meta file."""
        import json
        meta_path = file_path.with_suffix(file_path.suffix + '.meta')
        with open(meta_path, 'w') as f:
            json.dump(metadata, f)

    def _read_metadata_file(self, file_path: Path) -> Optional[Dict[str, str]]:
        """Read metadata from a sidecar .meta file."""
        import json
        meta_path = file_path.with_suffix(file_path.suffix + '.meta')
        if meta_path.exists():
            try:
                with open(meta_path, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                pass
        return None
