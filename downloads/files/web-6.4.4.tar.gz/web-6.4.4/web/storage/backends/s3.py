"""
S3 Storage Backend

Provides storage using Amazon S3 or any S3-compatible service:
- Amazon S3
- MinIO (self-hosted)
- Ceph Object Gateway
- DigitalOcean Spaces
- Backblaze B2
- Wasabi

Configuration via environment variables:
    S3_ENDPOINT_URL: Custom endpoint (for non-AWS S3-compatible services)
    S3_ACCESS_KEY: Access key ID
    S3_SECRET_KEY: Secret access key
    S3_BUCKET: Bucket name
    S3_REGION: AWS region (default: us-east-1)
    S3_USE_SSL: Enable SSL/TLS (default: true)
    S3_PATH_STYLE: Use path-style URLs (default: false, required for MinIO)
"""

import io
from datetime import datetime
from typing import BinaryIO, Optional, List, Dict, Any, Union
import logging

from .base import (
    StorageBackend,
    StorageMetadata,
    StorageError,
    StorageNotFoundError,
    StoragePermissionError,
    StorageConnectionError,
)

logger = logging.getLogger(__name__)

# Lazy import boto3 to avoid import error if not installed
boto3 = None
botocore = None


def _ensure_boto3():
    """Ensure boto3 is available."""
    global boto3, botocore
    if boto3 is None:
        try:
            import boto3 as _boto3
            import botocore as _botocore
            boto3 = _boto3
            botocore = _botocore
        except ImportError:
            raise StorageError(
                "boto3 package required for S3 storage: pip install boto3"
            )


class S3StorageBackend(StorageBackend):
    """
    Amazon S3 and S3-compatible storage backend.

    Supports any S3-compatible object storage service.
    """

    def __init__(
        self,
        bucket: str,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        endpoint_url: Optional[str] = None,
        region: str = 'us-east-1',
        use_ssl: bool = True,
        path_style: bool = False,
        prefix: str = '',
        compression_enabled: bool = False,
        encryption_key: Optional[bytes] = None,
    ):
        """
        Initialize S3 storage backend.

        Args:
            bucket: S3 bucket name
            access_key: AWS access key ID (or use env/IAM)
            secret_key: AWS secret access key (or use env/IAM)
            endpoint_url: Custom endpoint for S3-compatible services
            region: AWS region
            use_ssl: Enable SSL/TLS
            path_style: Use path-style URLs (required for MinIO)
            prefix: Path prefix for all objects
            compression_enabled: Enable gzip compression
            encryption_key: AES-256 key for client-side encryption
        """
        super().__init__(compression_enabled, encryption_key)
        _ensure_boto3()

        self.bucket = bucket
        self.region = region
        self.endpoint_url = endpoint_url
        self.prefix = self._normalize_path(prefix).rstrip('/') + '/' if prefix else ''
        self.use_ssl = use_ssl

        # Build client config
        config_kwargs: Dict[str, Any] = {}
        if path_style:
            from botocore.config import Config  # type: ignore[import]
            config_kwargs['config'] = Config(s3={'addressing_style': 'path'})

        # Build session kwargs
        session_kwargs: Dict[str, Any] = {'region_name': region}
        if access_key and secret_key:
            session_kwargs['aws_access_key_id'] = access_key
            session_kwargs['aws_secret_access_key'] = secret_key

        # Create client
        try:
            session = boto3.Session(**session_kwargs)  # type: ignore[union-attr]
            self._client = session.client(
                's3',
                endpoint_url=endpoint_url,
                use_ssl=use_ssl,
                **config_kwargs,
            )

            # Test connection by checking bucket exists
            self._client.head_bucket(Bucket=bucket)
            logger.info(f"S3 storage connected to bucket: {bucket}")

        except boto3.Session.exceptions if hasattr(boto3.Session, 'exceptions') else Exception as e:  # type: ignore
            raise StorageConnectionError(
                f"Failed to connect to S3: {e}"
            ) from e

    def _get_s3_key(self, path: str) -> str:
        """Convert relative path to S3 key."""
        path = self._normalize_path(path)
        return f"{self.prefix}{path}" if self.prefix else path

    def _get_relative_path(self, s3_key: str) -> str:
        """Convert S3 key back to relative path."""
        if self.prefix and s3_key.startswith(self.prefix):
            return s3_key[len(self.prefix):]
        return s3_key

    def put(
        self,
        path: str,
        data: Union[bytes, BinaryIO],
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> StorageMetadata:
        """Store data at the given path."""
        s3_key = self._get_s3_key(path)

        # Prepare data
        prepared_data = self._prepare_data_for_storage(data)

        # Compute checksums on original data
        original_data: bytes
        if hasattr(data, 'read'):
            data.seek(0)  # type: ignore[union-attr]
            original_data = data.read()  # type: ignore[union-attr]
        else:
            original_data = data  # type: ignore[assignment]
        md5_sum, sha256_sum = self._compute_checksums(original_data)

        # Prepare upload kwargs
        upload_kwargs: Dict[str, Any] = {
            'Bucket': self.bucket,
            'Key': s3_key,
            'Body': prepared_data,
            'ContentType': content_type or self._guess_content_type(path),
        }

        # Add custom metadata
        if metadata:
            # S3 metadata keys must start with x-amz-meta-
            upload_kwargs['Metadata'] = metadata

        # Add checksums for integrity
        upload_kwargs['ChecksumSHA256'] = sha256_sum

        try:
            response = self._client.put_object(**upload_kwargs)

            return StorageMetadata(
                path=path,
                size=len(original_data),
                content_type=upload_kwargs['ContentType'],
                last_modified=datetime.now(),
                etag=response.get('ETag', '').strip('"'),
                checksum_md5=md5_sum,
                checksum_sha256=sha256_sum,
                custom_metadata=metadata,
            )

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code == 'AccessDenied':
                raise StoragePermissionError(f"Access denied: {path}") from e
            raise StorageError(f"Failed to upload to S3: {e}") from e
        except Exception as e:
            raise StorageError(f"S3 put failed: {e}") from e

    def get(self, path: str) -> bytes:
        """Retrieve data from the given path."""
        s3_key = self._get_s3_key(path)

        try:
            response = self._client.get_object(
                Bucket=self.bucket,
                Key=s3_key,
            )
            data = response['Body'].read()
            return self._prepare_data_from_storage(data)

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code == 'NoSuchKey':
                raise StorageNotFoundError(f"File not found: {path}") from e
            if error_code == 'AccessDenied':
                raise StoragePermissionError(f"Access denied: {path}") from e
            raise StorageError(f"Failed to download from S3: {e}") from e
        except Exception as e:
            raise StorageError(f"S3 get failed: {e}") from e

    def get_stream(self, path: str) -> BinaryIO:
        """Get a streaming reader for the file."""
        s3_key = self._get_s3_key(path)

        try:
            response = self._client.get_object(
                Bucket=self.bucket,
                Key=s3_key,
            )

            # For encrypted/compressed files, read all and wrap
            if self.compression_enabled or self.encryption_key:
                data = self._prepare_data_from_storage(response['Body'].read())
                return io.BytesIO(data)

            # Return streaming body wrapped as BinaryIO
            return response['Body']

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code == 'NoSuchKey':
                raise StorageNotFoundError(f"File not found: {path}") from e
            raise StorageError(f"Failed to stream from S3: {e}") from e
        except Exception as e:
            raise StorageError(f"S3 stream failed: {e}") from e

    def delete(self, path: str) -> bool:
        """Delete the file at the given path."""
        s3_key = self._get_s3_key(path)

        # Check if exists first
        if not self.exists(path):
            return False

        try:
            self._client.delete_object(
                Bucket=self.bucket,
                Key=s3_key,
            )
            return True

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code == 'AccessDenied':
                raise StoragePermissionError(f"Access denied: {path}") from e
            raise StorageError(f"Failed to delete from S3: {e}") from e  # nosec B608 - error message, not SQL
        except Exception as e:
            raise StorageError(f"S3 delete failed: {e}") from e

    def exists(self, path: str) -> bool:
        """Check if a path exists."""
        s3_key = self._get_s3_key(path)

        try:
            self._client.head_object(
                Bucket=self.bucket,
                Key=s3_key,
            )
            return True
        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code in ('404', 'NoSuchKey'):
                return False
            raise StorageError(f"Failed to check existence: {e}") from e
        except Exception:
            return False

    def list_files(
        self,
        prefix: str = '',
        recursive: bool = True,
    ) -> List[StorageMetadata]:
        """List files with the given prefix."""
        search_prefix = self._get_s3_key(prefix)
        results: List[StorageMetadata] = []

        try:
            paginator = self._client.get_paginator('list_objects_v2')
            page_kwargs: Dict[str, Any] = {
                'Bucket': self.bucket,
                'Prefix': search_prefix,
            }

            if not recursive:
                page_kwargs['Delimiter'] = '/'

            for page in paginator.paginate(**page_kwargs):
                for obj in page.get('Contents', []):
                    rel_path = self._get_relative_path(obj['Key'])
                    results.append(StorageMetadata(
                        path=rel_path,
                        size=obj['Size'],
                        content_type=self._guess_content_type(rel_path),
                        last_modified=obj['LastModified'],
                        etag=obj.get('ETag', '').strip('"'),
                    ))

            return results

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            raise StorageError(f"Failed to list S3 objects: {e}") from e
        except Exception as e:
            raise StorageError(f"S3 list failed: {e}") from e

    def get_metadata(self, path: str) -> StorageMetadata:
        """Get metadata for a file."""
        s3_key = self._get_s3_key(path)

        try:
            response = self._client.head_object(
                Bucket=self.bucket,
                Key=s3_key,
            )

            return StorageMetadata(
                path=path,
                size=response['ContentLength'],
                content_type=response.get('ContentType'),
                last_modified=response['LastModified'],
                etag=response.get('ETag', '').strip('"'),
                checksum_sha256=response.get('ChecksumSHA256'),
                custom_metadata=response.get('Metadata'),
            )

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code in ('404', 'NoSuchKey'):
                raise StorageNotFoundError(f"File not found: {path}") from e
            raise StorageError(f"Failed to get S3 metadata: {e}") from e
        except Exception as e:
            raise StorageError(f"S3 metadata failed: {e}") from e

    def copy(self, source: str, destination: str) -> StorageMetadata:
        """Copy a file within the storage backend."""
        src_key = self._get_s3_key(source)
        dst_key = self._get_s3_key(destination)

        # Check source exists
        if not self.exists(source):
            raise StorageNotFoundError(f"Source not found: {source}")

        try:
            self._client.copy_object(
                Bucket=self.bucket,
                Key=dst_key,
                CopySource={'Bucket': self.bucket, 'Key': src_key},
            )
            return self.get_metadata(destination)

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code == 'AccessDenied':
                raise StoragePermissionError("Access denied for copy") from e
            raise StorageError(f"Failed to copy S3 object: {e}") from e
        except Exception as e:
            raise StorageError(f"S3 copy failed: {e}") from e

    def move(self, source: str, destination: str) -> StorageMetadata:
        """Move a file within the storage backend."""
        # S3 doesn't have native move, so copy then delete
        metadata = self.copy(source, destination)
        self.delete(source)
        return metadata

    def get_signed_url(
        self,
        path: str,
        expires_in: int = 3600,
        method: str = 'GET',
    ) -> Optional[str]:
        """Generate a pre-signed URL for direct S3 access."""
        s3_key = self._get_s3_key(path)

        # Check existence for GET requests
        if method.upper() == 'GET' and not self.exists(path):
            raise StorageNotFoundError(f"File not found: {path}")

        operation = 'get_object' if method.upper() == 'GET' else 'put_object'

        try:
            url = self._client.generate_presigned_url(
                ClientMethod=operation,
                Params={
                    'Bucket': self.bucket,
                    'Key': s3_key,
                },
                ExpiresIn=expires_in,
            )
            return url

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            raise StorageError(f"Failed to generate presigned URL: {e}") from e
        except Exception as e:
            raise StorageError(f"S3 presigned URL failed: {e}") from e

    def get_stats(self) -> Dict[str, Any]:
        """Get storage backend statistics."""
        try:
            # Count objects and total size
            total_size = 0
            file_count = 0

            paginator = self._client.get_paginator('list_objects_v2')
            for page in paginator.paginate(Bucket=self.bucket, Prefix=self.prefix):
                for obj in page.get('Contents', []):
                    file_count += 1
                    total_size += obj['Size']

            return {
                'backend': 's3',
                'bucket': self.bucket,
                'region': self.region,
                'endpoint_url': self.endpoint_url,
                'prefix': self.prefix,
                'compression_enabled': self.compression_enabled,
                'encryption_enabled': self.encryption_key is not None,
                'file_count': file_count,
                'total_size_bytes': total_size,
            }

        except Exception as e:
            return {
                'backend': 's3',
                'bucket': self.bucket,
                'error': str(e),
            }

    def create_multipart_upload(self, path: str, content_type: Optional[str] = None) -> str:
        """
        Initiate a multipart upload for large files.

        Args:
            path: Destination path
            content_type: MIME type

        Returns:
            Upload ID for subsequent part uploads
        """
        s3_key = self._get_s3_key(path)

        try:
            response = self._client.create_multipart_upload(
                Bucket=self.bucket,
                Key=s3_key,
                ContentType=content_type or self._guess_content_type(path),
            )
            return response['UploadId']

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            raise StorageError(f"Failed to initiate multipart upload: {e}") from e

    def upload_part(
        self,
        path: str,
        upload_id: str,
        part_number: int,
        data: bytes,
    ) -> Dict[str, Any]:
        """
        Upload a part in a multipart upload.

        Args:
            path: Destination path
            upload_id: Upload ID from create_multipart_upload
            part_number: Part number (1-10000)
            data: Part data

        Returns:
            Dict with ETag for the part
        """
        s3_key = self._get_s3_key(path)

        try:
            response = self._client.upload_part(
                Bucket=self.bucket,
                Key=s3_key,
                UploadId=upload_id,
                PartNumber=part_number,
                Body=data,
            )
            return {
                'PartNumber': part_number,
                'ETag': response['ETag'],
            }

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            raise StorageError(f"Failed to upload part: {e}") from e

    def complete_multipart_upload(
        self,
        path: str,
        upload_id: str,
        parts: List[Dict[str, Any]],
    ) -> StorageMetadata:
        """
        Complete a multipart upload.

        Args:
            path: Destination path
            upload_id: Upload ID from create_multipart_upload
            parts: List of dicts with PartNumber and ETag

        Returns:
            StorageMetadata for the completed upload
        """
        s3_key = self._get_s3_key(path)

        try:
            self._client.complete_multipart_upload(
                Bucket=self.bucket,
                Key=s3_key,
                UploadId=upload_id,
                MultipartUpload={'Parts': parts},
            )
            return self.get_metadata(path)

        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            raise StorageError(f"Failed to complete multipart upload: {e}") from e

    def abort_multipart_upload(self, path: str, upload_id: str) -> None:
        """
        Abort a multipart upload.

        Args:
            path: Destination path
            upload_id: Upload ID from create_multipart_upload
        """
        s3_key = self._get_s3_key(path)

        try:
            self._client.abort_multipart_upload(
                Bucket=self.bucket,
                Key=s3_key,
                UploadId=upload_id,
            )
        except botocore.exceptions.ClientError as e:  # type: ignore[union-attr]
            raise StorageError(f"Failed to abort multipart upload: {e}") from e
