"""
Storage Manager

Singleton manager that provides a unified interface to the configured
storage backend. Handles backend selection, initialization, and
provides convenience methods for common storage patterns.

Usage:
    from storage import storage_manager

    # Store audit report
    storage_manager.put_report('audit-2024-01-15.pdf', pdf_bytes)

    # Get report
    report = storage_manager.get_report('audit-2024-01-15.pdf')

    # Store audit data
    storage_manager.put_audit_data('server-001/system-info.json', json_bytes)

Configuration (environment variables):
    STORAGE_BACKEND: "local" | "s3" (default: "local")
    STORAGE_PATH: Base path for local storage
    STORAGE_COMPRESSION: "true" | "false" (default: "false")
    STORAGE_ENCRYPTION_KEY: Base64-encoded AES-256 key

    For S3:
    S3_ENDPOINT_URL, S3_ACCESS_KEY, S3_SECRET_KEY, S3_BUCKET, S3_REGION
"""

import os
import logging
import base64
from datetime import datetime, timedelta
from typing import BinaryIO, Optional, List, Dict, Any, Union
from pathlib import Path

from .backends.base import (
    StorageBackend,
    StorageMetadata,
    StorageError,
    StorageNotFoundError,
)
from .backends.local import LocalStorageBackend
from .backends.s3 import S3StorageBackend

logger = logging.getLogger(__name__)


# Standard storage paths for organization
class StoragePaths:
    """Standard paths for different data types."""
    REPORTS = 'reports/'
    AUDIT_DATA = 'audit-data/'
    SCRIPTS = 'scripts/'
    TEMPLATES = 'templates/'
    ARTIFACTS = 'artifacts/'
    BACKUPS = 'backups/'
    TEMP = 'temp/'
    LOGS = 'logs/'


class StorageManager:
    """
    Singleton manager for storage operations.

    Provides high-level methods for storing and retrieving
    audit data, reports, and other artifacts.
    """

    _instance: Optional['StorageManager'] = None
    _backend: Optional[StorageBackend] = None

    def __new__(cls) -> 'StorageManager':
        """Ensure singleton instance."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """Initialize the storage manager (only runs once due to singleton)."""
        if self._backend is not None:
            return  # Already initialized

        self._initialize_backend()

    def _initialize_backend(self) -> None:
        """Initialize the storage backend based on configuration."""
        backend_type = os.environ.get('STORAGE_BACKEND', 'local').lower()
        compression = os.environ.get('STORAGE_COMPRESSION', 'false').lower() == 'true'

        # Parse encryption key if provided
        encryption_key: Optional[bytes] = None
        key_b64 = os.environ.get('STORAGE_ENCRYPTION_KEY')
        if key_b64:
            try:
                encryption_key = base64.b64decode(key_b64)
                if len(encryption_key) != 32:
                    logger.warning("STORAGE_ENCRYPTION_KEY must be 32 bytes (AES-256)")
                    encryption_key = None
            except Exception as e:
                logger.warning(f"Invalid STORAGE_ENCRYPTION_KEY: {e}")

        logger.info(f"Initializing storage backend: {backend_type}")

        if backend_type == 's3':
            self._backend = self._create_s3_backend(compression, encryption_key)
        else:
            # Default to local (also works for NFS/SMB mounts)
            self._backend = self._create_local_backend(compression, encryption_key)

        logger.info(f"Storage backend initialized: {backend_type}")

    def _create_local_backend(
        self,
        compression: bool,
        encryption_key: Optional[bytes],
    ) -> LocalStorageBackend:
        """Create a local filesystem backend."""
        # Default storage path is app root/storage
        base_path = os.environ.get('STORAGE_PATH')
        if not base_path:
            # Try to find the app root
            app_root = Path(__file__).parent.parent.parent  # web/storage -> root
            base_path = str(app_root / 'storage-data')

        return LocalStorageBackend(
            base_path=base_path,
            compression_enabled=compression,
            encryption_key=encryption_key,
            create_dirs=True,
        )

    def _create_s3_backend(
        self,
        compression: bool,
        encryption_key: Optional[bytes],
    ) -> S3StorageBackend:
        """Create an S3 storage backend."""
        bucket = os.environ.get('S3_BUCKET')
        if not bucket:
            raise StorageError("S3_BUCKET environment variable required for S3 backend")

        return S3StorageBackend(
            bucket=bucket,
            access_key=os.environ.get('S3_ACCESS_KEY'),
            secret_key=os.environ.get('S3_SECRET_KEY'),
            endpoint_url=os.environ.get('S3_ENDPOINT_URL'),
            region=os.environ.get('S3_REGION', 'us-east-1'),
            use_ssl=os.environ.get('S3_USE_SSL', 'true').lower() == 'true',
            path_style=os.environ.get('S3_PATH_STYLE', 'false').lower() == 'true',
            prefix=os.environ.get('S3_PREFIX', ''),
            compression_enabled=compression,
            encryption_key=encryption_key,
        )

    @property
    def backend(self) -> StorageBackend:
        """Get the current storage backend."""
        if self._backend is None:
            raise StorageError("Storage backend not initialized")
        return self._backend

    # ==================== Core Operations ====================

    def put(
        self,
        path: str,
        data: Union[bytes, BinaryIO],
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> StorageMetadata:
        """Store data at the given path."""
        return self.backend.put(path, data, content_type, metadata)

    def get(self, path: str) -> bytes:
        """Retrieve data from the given path."""
        return self.backend.get(path)

    def get_stream(self, path: str) -> BinaryIO:
        """Get a streaming reader for the file."""
        return self.backend.get_stream(path)

    def delete(self, path: str) -> bool:
        """Delete the file at the given path."""
        return self.backend.delete(path)

    def exists(self, path: str) -> bool:
        """Check if a path exists."""
        return self.backend.exists(path)

    def list_files(
        self,
        prefix: str = '',
        recursive: bool = True,
    ) -> List[StorageMetadata]:
        """List files with the given prefix."""
        return self.backend.list_files(prefix, recursive)

    def get_metadata(self, path: str) -> StorageMetadata:
        """Get metadata for a file."""
        return self.backend.get_metadata(path)

    def copy(self, source: str, destination: str) -> StorageMetadata:
        """Copy a file within storage."""
        return self.backend.copy(source, destination)

    def move(self, source: str, destination: str) -> StorageMetadata:
        """Move a file within storage."""
        return self.backend.move(source, destination)

    def get_signed_url(
        self,
        path: str,
        expires_in: int = 3600,
        method: str = 'GET',
    ) -> Optional[str]:
        """Generate a signed URL for direct access."""
        return self.backend.get_signed_url(path, expires_in, method)

    def get_stats(self) -> Dict[str, Any]:
        """Get storage statistics."""
        return self.backend.get_stats()

    def get_backend_info(self) -> Dict[str, Any]:
        """
        Get information about the current storage backend.

        Returns:
            Dict with backend type, configuration, and status
        """
        backend_type = type(self.backend).__name__
        info = {
            'backend_type': backend_type,
            'compression_enabled': self.backend.compression_enabled,
            'encryption_enabled': self.backend.encryption_key is not None,
        }

        # Add backend-specific info
        if hasattr(self.backend, 'base_path'):
            info['base_path'] = str(self.backend.base_path)
        if hasattr(self.backend, 'bucket'):
            info['bucket'] = self.backend.bucket
        if hasattr(self.backend, 'endpoint_url'):
            info['endpoint_url'] = self.backend.endpoint_url
        if hasattr(self.backend, 'region'):
            info['region'] = self.backend.region

        return info

    def _resolve_report_artifact_retention_policy(self) -> tuple[int, int]:
        """Resolve report/artifact retention policy from security settings."""
        try:
            from security_settings import get_security_setting
            retention_days = int(get_security_setting('report_artifact_retention_days', 90))
            max_files = int(get_security_setting('report_artifact_max_files', 10000))
        except Exception:
            retention_days = int(os.environ.get('REPORT_ARTIFACT_RETENTION_DAYS', '90'))
            max_files = int(os.environ.get('REPORT_ARTIFACT_MAX_FILES', '10000'))

        retention_days = max(7, retention_days)
        if max_files < 0:
            max_files = 10000

        return retention_days, max_files

    def _enforce_prefix_retention(self, prefix: str, retention_days: int, max_files: int) -> Dict[str, int]:
        """Prune files under a storage prefix by age and count."""
        deleted_by_age = 0
        deleted_by_count = 0

        try:
            files = self.list_files(prefix)
        except Exception as exc:
            logger.warning(f"Unable to list storage files for {prefix}: {exc}")
            return {'deleted_by_age': 0, 'deleted_by_count': 0}

        if not files:
            return {'deleted_by_age': 0, 'deleted_by_count': 0}

        cutoff = datetime.now() - timedelta(days=retention_days)
        surviving: List[StorageMetadata] = []

        for item in files:
            if item.last_modified and item.last_modified < cutoff:
                try:
                    if self.delete(item.path):
                        deleted_by_age += 1
                except Exception as exc:
                    logger.warning(f"Failed deleting aged file {item.path}: {exc}")
            else:
                surviving.append(item)

        surviving.sort(key=lambda meta: meta.last_modified, reverse=True)
        if max_files > 0 and len(surviving) > max_files:
            overflow = surviving[max_files:]
            for item in overflow:
                try:
                    if self.delete(item.path):
                        deleted_by_count += 1
                except Exception as exc:
                    logger.warning(f"Failed deleting overflow file {item.path}: {exc}")

        return {'deleted_by_age': deleted_by_age, 'deleted_by_count': deleted_by_count}

    # ==================== High-Level Operations ====================

    def put_report(
        self,
        filename: str,
        data: Union[bytes, BinaryIO],
        server_id: Optional[str] = None,
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> StorageMetadata:
        """
        Store an audit report.

        Args:
            filename: Report filename
            data: Report content
            server_id: Optional server identifier for organization
            content_type: MIME type (auto-detected if not provided)
            metadata: Custom metadata

        Returns:
            StorageMetadata for the stored report
        """
        # Organize by date and optional server
        date_prefix = datetime.now().strftime('%Y/%m')
        if server_id:
            path = f"{StoragePaths.REPORTS}{date_prefix}/{server_id}/{filename}"
        else:
            path = f"{StoragePaths.REPORTS}{date_prefix}/{filename}"

        # Add report-specific metadata
        report_metadata = metadata or {}
        report_metadata['report_date'] = datetime.now().isoformat()
        if server_id:
            report_metadata['server_id'] = server_id

        stored = self.put(path, data, content_type, report_metadata)
        retention_days, max_files = self._resolve_report_artifact_retention_policy()
        cleanup = self._enforce_prefix_retention(StoragePaths.REPORTS, retention_days, max_files)
        if cleanup['deleted_by_age'] or cleanup['deleted_by_count']:
            logger.info(
                "Applied report retention policy (days=%s, max_files=%s): deleted_by_age=%s, deleted_by_count=%s",
                retention_days,
                max_files,
                cleanup['deleted_by_age'],
                cleanup['deleted_by_count'],
            )
        return stored

    def get_report(self, path: str) -> bytes:
        """
        Retrieve a report.

        Args:
            path: Full path or just filename to search for

        Returns:
            Report content
        """
        # If full path provided, use it directly
        if path.startswith(StoragePaths.REPORTS):
            return self.get(path)

        # Search for the report in the reports directory
        reports = self.list_reports()
        for report in reports:
            if report.path.endswith(path):
                return self.get(report.path)

        raise StorageNotFoundError(f"Report not found: {path}")

    def list_reports(
        self,
        server_id: Optional[str] = None,
        year: Optional[int] = None,
        month: Optional[int] = None,
    ) -> List[StorageMetadata]:
        """
        List available reports.

        Args:
            server_id: Filter by server
            year: Filter by year
            month: Filter by month

        Returns:
            List of report metadata
        """
        prefix = StoragePaths.REPORTS
        if year:
            prefix += f"{year:04d}/"
            if month:
                prefix += f"{month:02d}/"

        reports = self.list_files(prefix)

        if server_id:
            reports = [r for r in reports if server_id in r.path]

        return reports

    def put_audit_data(
        self,
        path: str,
        data: Union[bytes, BinaryIO],
        metadata: Optional[Dict[str, str]] = None,
    ) -> StorageMetadata:
        """
        Store audit data (JSON, logs, etc.).

        Args:
            path: Relative path within audit-data/
            data: Data content
            metadata: Custom metadata

        Returns:
            StorageMetadata for the stored data
        """
        full_path = f"{StoragePaths.AUDIT_DATA}{path}"
        return self.put(full_path, data, metadata=metadata)

    def get_audit_data(self, path: str) -> bytes:
        """
        Retrieve audit data.

        Args:
            path: Relative path within audit-data/

        Returns:
            Data content
        """
        full_path = f"{StoragePaths.AUDIT_DATA}{path}"
        return self.get(full_path)

    def put_script(
        self,
        filename: str,
        content: Union[bytes, str],
        category: str = 'custom',
        metadata: Optional[Dict[str, str]] = None,
    ) -> StorageMetadata:
        """
        Store a script file.

        Args:
            filename: Script filename
            content: Script content (bytes or string)
            category: Script category (custom, baseline, etc.)
            metadata: Custom metadata

        Returns:
            StorageMetadata for the stored script
        """
        if isinstance(content, str):
            content = content.encode('utf-8')

        path = f"{StoragePaths.SCRIPTS}{category}/{filename}"
        script_metadata = metadata or {}
        script_metadata['category'] = category
        script_metadata['uploaded_at'] = datetime.now().isoformat()

        return self.put(path, content, 'text/x-shellscript', script_metadata)

    def get_script(self, category: str, filename: str) -> str:
        """
        Retrieve a script file.

        Args:
            category: Script category
            filename: Script filename

        Returns:
            Script content as string
        """
        path = f"{StoragePaths.SCRIPTS}{category}/{filename}"
        return self.get(path).decode('utf-8')

    def list_scripts(self, category: Optional[str] = None) -> List[StorageMetadata]:
        """
        List available scripts.

        Args:
            category: Filter by category

        Returns:
            List of script metadata
        """
        prefix = StoragePaths.SCRIPTS
        if category:
            prefix += f"{category}/"

        return self.list_files(prefix)

    def put_artifact(
        self,
        path: str,
        data: Union[bytes, BinaryIO],
        metadata: Optional[Dict[str, str]] = None,
    ) -> StorageMetadata:
        """Store a general artifact."""
        full_path = f"{StoragePaths.ARTIFACTS}{path}"
        stored = self.put(full_path, data, metadata=metadata)
        retention_days, max_files = self._resolve_report_artifact_retention_policy()
        cleanup = self._enforce_prefix_retention(StoragePaths.ARTIFACTS, retention_days, max_files)
        if cleanup['deleted_by_age'] or cleanup['deleted_by_count']:
            logger.info(
                "Applied artifact retention policy (days=%s, max_files=%s): deleted_by_age=%s, deleted_by_count=%s",
                retention_days,
                max_files,
                cleanup['deleted_by_age'],
                cleanup['deleted_by_count'],
            )
        return stored

    def get_artifact(self, path: str) -> bytes:
        """Retrieve a general artifact."""
        full_path = f"{StoragePaths.ARTIFACTS}{path}"
        return self.get(full_path)

    def create_backup(
        self,
        name: str,
        data: Union[bytes, BinaryIO],
        metadata: Optional[Dict[str, str]] = None,
    ) -> StorageMetadata:
        """
        Create a backup file.

        Args:
            name: Backup name (without timestamp)
            data: Backup data
            metadata: Custom metadata

        Returns:
            StorageMetadata for the backup
        """
        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        path = f"{StoragePaths.BACKUPS}{timestamp}-{name}"

        backup_metadata = metadata or {}
        backup_metadata['backup_timestamp'] = datetime.now().isoformat()
        backup_metadata['backup_name'] = name

        return self.put(path, data, metadata=backup_metadata)

    def list_backups(self, name_filter: Optional[str] = None) -> List[StorageMetadata]:
        """
        List available backups.

        Args:
            name_filter: Filter by backup name

        Returns:
            List of backup metadata, newest first
        """
        backups = self.list_files(StoragePaths.BACKUPS)

        if name_filter:
            backups = [b for b in backups if name_filter in b.path]

        # Sort by date descending
        backups.sort(key=lambda b: b.last_modified, reverse=True)

        return backups

    def cleanup_temp(self, max_age_hours: int = 24) -> int:
        """
        Clean up old temporary files.

        Args:
            max_age_hours: Delete files older than this

        Returns:
            Number of files deleted
        """
        from datetime import timedelta

        cutoff = datetime.now() - timedelta(hours=max_age_hours)
        deleted = 0

        temp_files = self.list_files(StoragePaths.TEMP)
        for file in temp_files:
            if file.last_modified < cutoff:
                if self.delete(file.path):
                    deleted += 1

        logger.info(f"Cleaned up {deleted} temporary files")
        return deleted

    def health_check(self) -> Dict[str, Any]:
        """
        Check storage health and connectivity.

        Returns:
            Health status dictionary
        """
        result: Dict[str, Any] = {
            'healthy': True,
            'backend': type(self.backend).__name__,
            'checks': {},
        }

        # Test write
        test_path = f"{StoragePaths.TEMP}health-check-{datetime.now().timestamp()}"
        test_data = b'health-check'

        try:
            self.put(test_path, test_data)
            result['checks']['write'] = 'ok'
        except Exception as e:
            result['checks']['write'] = str(e)
            result['healthy'] = False

        # Test read
        try:
            read_data = self.get(test_path)
            if read_data == test_data:
                result['checks']['read'] = 'ok'
            else:
                result['checks']['read'] = 'data mismatch'
                result['healthy'] = False
        except Exception as e:
            result['checks']['read'] = str(e)
            result['healthy'] = False

        # Test delete
        try:
            self.delete(test_path)
            result['checks']['delete'] = 'ok'
        except Exception as e:
            result['checks']['delete'] = str(e)
            result['healthy'] = False

        # Test list
        try:
            self.list_files(StoragePaths.TEMP, recursive=False)
            result['checks']['list'] = 'ok'
        except Exception as e:
            result['checks']['list'] = str(e)
            result['healthy'] = False

        # Add stats
        try:
            result['stats'] = self.get_stats()
        except Exception as e:
            result['stats'] = {'error': str(e)}

        return result


# Singleton instance
storage_manager = StorageManager()
