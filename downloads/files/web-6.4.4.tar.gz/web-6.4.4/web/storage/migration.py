"""
Storage Migration Utility

Provides tools to migrate data between storage backends (Local <-> S3).
Supports incremental migration, verification, and rollback.

Usage:
    # CLI
    python -m storage.migration --source local --dest s3 --verify

    # Programmatic
    from storage.migration import StorageMigrator
    migrator = StorageMigrator(source_backend, dest_backend)
    migrator.migrate_all(verify=True)
"""

import os
import sys
import logging
import hashlib
import argparse
from datetime import datetime
from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed

from .backends.base import (
    StorageBackend,
    StorageMetadata,
    StorageNotFoundError,
)
from .backends.local import LocalStorageBackend
from .backends.s3 import S3StorageBackend

logger = logging.getLogger(__name__)


@dataclass
class MigrationStats:
    """Statistics for a migration operation."""
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    total_files: int = 0
    migrated_files: int = 0
    skipped_files: int = 0
    failed_files: int = 0
    total_bytes: int = 0
    migrated_bytes: int = 0
    errors: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert stats to dictionary."""
        return {
            'started_at': self.started_at.isoformat(),
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'duration_seconds': (
                (self.completed_at or datetime.now()) - self.started_at
            ).total_seconds(),
            'total_files': self.total_files,
            'migrated_files': self.migrated_files,
            'skipped_files': self.skipped_files,
            'failed_files': self.failed_files,
            'total_bytes': self.total_bytes,
            'migrated_bytes': self.migrated_bytes,
            'success_rate': (
                self.migrated_files / self.total_files * 100
                if self.total_files > 0 else 0
            ),
            'errors': self.errors[:100],  # Limit errors in output
        }


@dataclass
class MigrationResult:
    """Result of migrating a single file."""
    path: str
    success: bool
    source_checksum: Optional[str] = None
    dest_checksum: Optional[str] = None
    verified: bool = False
    error: Optional[str] = None
    bytes_migrated: int = 0


class StorageMigrator:
    """
    Migrates data between storage backends.

    Supports:
    - Full migration (all files)
    - Incremental migration (new/changed files only)
    - Verification (checksum comparison)
    - Parallel migration for performance
    - Progress callbacks
    - Dry run mode
    """

    def __init__(
        self,
        source: StorageBackend,
        destination: StorageBackend,
        parallel_workers: int = 4,
    ):
        """
        Initialize the migrator.

        Args:
            source: Source storage backend
            destination: Destination storage backend
            parallel_workers: Number of parallel migration threads
        """
        self.source = source
        self.destination = destination
        self.parallel_workers = parallel_workers
        self._progress_callback: Optional[Callable[[str, int, int], None]] = None

    def set_progress_callback(
        self,
        callback: Callable[[str, int, int], None]
    ) -> None:
        """
        Set a callback for progress updates.

        Args:
            callback: Function(path, current, total) called for each file
        """
        self._progress_callback = callback

    def _compute_checksum(self, data: bytes) -> str:
        """Compute SHA-256 checksum of data."""
        return hashlib.sha256(data).hexdigest()

    def _migrate_file(
        self,
        path: str,
        verify: bool = True,
        overwrite: bool = True,
    ) -> MigrationResult:
        """
        Migrate a single file.

        Args:
            path: File path to migrate
            verify: Verify checksum after migration
            overwrite: Overwrite if destination exists

        Returns:
            MigrationResult with status
        """
        try:
            # Check if destination exists
            if not overwrite and self.destination.exists(path):
                return MigrationResult(
                    path=path,
                    success=True,
                    verified=False,
                    error="Skipped: destination exists",
                )

            # Read from source
            data = self.source.get(path)
            source_checksum = self._compute_checksum(data)

            # Get source metadata
            try:
                source_meta = self.source.get_metadata(path)
                content_type = source_meta.content_type
                custom_metadata = source_meta.custom_metadata
            except Exception:
                content_type = None
                custom_metadata = None

            # Write to destination
            self.destination.put(
                path=path,
                data=data,
                content_type=content_type,
                metadata=custom_metadata,
            )

            # Verify if requested
            dest_checksum = None
            verified = False
            if verify:
                dest_data = self.destination.get(path)
                dest_checksum = self._compute_checksum(dest_data)
                verified = source_checksum == dest_checksum

                if not verified:
                    return MigrationResult(
                        path=path,
                        success=False,
                        source_checksum=source_checksum,
                        dest_checksum=dest_checksum,
                        verified=False,
                        error="Checksum mismatch after migration",
                        bytes_migrated=len(data),
                    )

            return MigrationResult(
                path=path,
                success=True,
                source_checksum=source_checksum,
                dest_checksum=dest_checksum,
                verified=verified,
                bytes_migrated=len(data),
            )

        except StorageNotFoundError:
            return MigrationResult(
                path=path,
                success=False,
                error="Source file not found",
            )
        except Exception as e:
            return MigrationResult(
                path=path,
                success=False,
                error=str(e),
            )

    def migrate_all(
        self,
        prefix: str = '',
        verify: bool = True,
        overwrite: bool = True,
        dry_run: bool = False,
        incremental: bool = False,
    ) -> MigrationStats:
        """
        Migrate all files from source to destination.

        Args:
            prefix: Only migrate files with this prefix
            verify: Verify checksums after migration
            overwrite: Overwrite existing files in destination
            dry_run: Don't actually migrate, just report what would happen
            incremental: Only migrate new/changed files

        Returns:
            MigrationStats with results
        """
        stats = MigrationStats()

        # List all files in source
        logger.info(f"Listing files in source with prefix: '{prefix}'")
        source_files = self.source.list_files(prefix, recursive=True)
        stats.total_files = len(source_files)
        stats.total_bytes = sum(f.size for f in source_files)

        logger.info(f"Found {stats.total_files} files ({stats.total_bytes:,} bytes)")

        if dry_run:
            logger.info("DRY RUN - no files will be migrated")
            for meta in source_files:
                logger.info(f"  Would migrate: {meta.path} ({meta.size:,} bytes)")
            stats.completed_at = datetime.now()
            return stats

        # Build list of files to migrate
        files_to_migrate: List[StorageMetadata] = []

        if incremental:
            logger.info("Incremental mode: checking for new/changed files")
            for meta in source_files:
                try:
                    dest_meta = self.destination.get_metadata(meta.path)
                    # Skip if same size and modification time
                    if (dest_meta.size == meta.size and
                            dest_meta.last_modified >= meta.last_modified):
                        stats.skipped_files += 1
                        continue
                except StorageNotFoundError:
                    pass  # File doesn't exist in destination
                files_to_migrate.append(meta)
            logger.info(
                f"Will migrate {len(files_to_migrate)} files "
                f"(skipping {stats.skipped_files} unchanged)"
            )
        else:
            files_to_migrate = source_files

        # Migrate files in parallel
        with ThreadPoolExecutor(max_workers=self.parallel_workers) as executor:
            futures = {
                executor.submit(
                    self._migrate_file,
                    meta.path,
                    verify,
                    overwrite,
                ): meta
                for meta in files_to_migrate
            }

            for i, future in enumerate(as_completed(futures)):
                meta = futures[future]
                result = future.result()

                if self._progress_callback:
                    self._progress_callback(
                        result.path,
                        i + 1,
                        len(files_to_migrate),
                    )

                if result.success:
                    stats.migrated_files += 1
                    stats.migrated_bytes += result.bytes_migrated
                    logger.debug(f"Migrated: {result.path}")
                else:
                    stats.failed_files += 1
                    stats.errors.append({
                        'path': result.path,
                        'error': result.error,
                    })
                    logger.error(f"Failed: {result.path} - {result.error}")

        stats.completed_at = datetime.now()
        logger.info(
            f"Migration complete: {stats.migrated_files} migrated, "
            f"{stats.skipped_files} skipped, {stats.failed_files} failed"
        )
        return stats

    def verify_migration(self, prefix: str = '') -> MigrationStats:
        """
        Verify all migrated files match source.

        Args:
            prefix: Only verify files with this prefix

        Returns:
            MigrationStats with verification results
        """
        stats = MigrationStats()

        source_files = self.source.list_files(prefix, recursive=True)
        stats.total_files = len(source_files)

        logger.info(f"Verifying {stats.total_files} files")

        for meta in source_files:
            try:
                source_data = self.source.get(meta.path)
                source_checksum = self._compute_checksum(source_data)

                dest_data = self.destination.get(meta.path)
                dest_checksum = self._compute_checksum(dest_data)

                if source_checksum == dest_checksum:
                    stats.migrated_files += 1
                    logger.debug(f"Verified: {meta.path}")
                else:
                    stats.failed_files += 1
                    stats.errors.append({
                        'path': meta.path,
                        'error': 'Checksum mismatch',
                        'source_checksum': source_checksum,
                        'dest_checksum': dest_checksum,
                    })
                    logger.error(f"Checksum mismatch: {meta.path}")

            except StorageNotFoundError:
                stats.failed_files += 1
                stats.errors.append({
                    'path': meta.path,
                    'error': 'Not found in destination',
                })
                logger.error(f"Not found in destination: {meta.path}")

            except Exception as e:
                stats.failed_files += 1
                stats.errors.append({
                    'path': meta.path,
                    'error': str(e),
                })
                logger.error(f"Verification failed: {meta.path} - {e}")

        stats.completed_at = datetime.now()
        return stats


def create_backend_from_config(
    backend_type: str,
    **kwargs
) -> StorageBackend:
    """
    Create a storage backend from configuration.

    Args:
        backend_type: 'local' or 's3'
        **kwargs: Backend-specific configuration

    Returns:
        Configured StorageBackend instance
    """
    if backend_type == 'local':
        base_path = kwargs.get('path') or os.environ.get('STORAGE_PATH', './storage-data')
        return LocalStorageBackend(
            base_path=base_path,
            compression_enabled=kwargs.get('compression', False),
        )
    elif backend_type == 's3':
        return S3StorageBackend(
            bucket=kwargs.get('bucket') or os.environ.get('S3_BUCKET', ''),
            access_key=kwargs.get('access_key') or os.environ.get('S3_ACCESS_KEY'),
            secret_key=kwargs.get('secret_key') or os.environ.get('S3_SECRET_KEY'),
            endpoint_url=kwargs.get('endpoint_url') or os.environ.get('S3_ENDPOINT_URL'),
            region=kwargs.get('region') or os.environ.get('S3_REGION', 'us-east-1'),
            use_ssl=kwargs.get('use_ssl', True),
            path_style=kwargs.get('path_style', False),
            compression_enabled=kwargs.get('compression', False),
        )
    else:
        raise ValueError(f"Unknown backend type: {backend_type}")


def main():
    """CLI entry point for storage migration."""
    parser = argparse.ArgumentParser(
        description='Migrate data between storage backends'
    )
    parser.add_argument(
        '--source', '-s',
        choices=['local', 's3'],
        required=True,
        help='Source storage backend'
    )
    parser.add_argument(
        '--dest', '-d',
        choices=['local', 's3'],
        required=True,
        help='Destination storage backend'
    )
    parser.add_argument(
        '--prefix', '-p',
        default='',
        help='Only migrate files with this prefix'
    )
    parser.add_argument(
        '--source-path',
        help='Source path (for local backend)'
    )
    parser.add_argument(
        '--dest-path',
        help='Destination path (for local backend)'
    )
    parser.add_argument(
        '--source-bucket',
        help='Source S3 bucket'
    )
    parser.add_argument(
        '--dest-bucket',
        help='Destination S3 bucket'
    )
    parser.add_argument(
        '--verify',
        action='store_true',
        help='Verify checksums after migration'
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Show what would be migrated without doing it'
    )
    parser.add_argument(
        '--incremental',
        action='store_true',
        help='Only migrate new/changed files'
    )
    parser.add_argument(
        '--no-overwrite',
        action='store_true',
        help='Skip files that exist in destination'
    )
    parser.add_argument(
        '--workers', '-w',
        type=int,
        default=4,
        help='Number of parallel workers'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Verbose output'
    )

    args = parser.parse_args()

    # Configure logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s | %(levelname)-8s | %(message)s'
    )

    # Create source backend
    source_kwargs = {}
    if args.source == 'local':
        source_kwargs['path'] = args.source_path
    elif args.source == 's3':
        source_kwargs['bucket'] = args.source_bucket

    source = create_backend_from_config(args.source, **source_kwargs)

    # Create destination backend
    dest_kwargs = {}
    if args.dest == 'local':
        dest_kwargs['path'] = args.dest_path
    elif args.dest == 's3':
        dest_kwargs['bucket'] = args.dest_bucket

    destination = create_backend_from_config(args.dest, **dest_kwargs)

    # Create migrator
    migrator = StorageMigrator(
        source=source,
        destination=destination,
        parallel_workers=args.workers,
    )

    # Progress callback
    def show_progress(path: str, current: int, total: int):
        pct = current / total * 100 if total > 0 else 0
        print(f"\r[{pct:5.1f}%] {current}/{total}: {path[:60]:<60}", end='')

    migrator.set_progress_callback(show_progress)

    # Run migration
    print(f"\n{'='*70}")
    print(f"Storage Migration: {args.source} -> {args.dest}")
    print(f"{'='*70}\n")

    stats = migrator.migrate_all(
        prefix=args.prefix,
        verify=args.verify,
        overwrite=not args.no_overwrite,
        dry_run=args.dry_run,
        incremental=args.incremental,
    )

    # Print results
    print(f"\n\n{'='*70}")
    print("Migration Results")
    print(f"{'='*70}")
    print(f"Duration:       {stats.to_dict()['duration_seconds']:.1f} seconds")
    print(f"Total files:    {stats.total_files}")
    print(f"Migrated:       {stats.migrated_files}")
    print(f"Skipped:        {stats.skipped_files}")
    print(f"Failed:         {stats.failed_files}")
    print(f"Total bytes:    {stats.total_bytes:,}")
    print(f"Migrated bytes: {stats.migrated_bytes:,}")
    print(f"Success rate:   {stats.to_dict()['success_rate']:.1f}%")

    if stats.errors:
        print(f"\nErrors ({len(stats.errors)}):")
        for err in stats.errors[:10]:
            print(f"  - {err['path']}: {err['error']}")
        if len(stats.errors) > 10:
            print(f"  ... and {len(stats.errors) - 10} more")

    # Exit code
    sys.exit(0 if stats.failed_files == 0 else 1)


if __name__ == '__main__':
    main()
