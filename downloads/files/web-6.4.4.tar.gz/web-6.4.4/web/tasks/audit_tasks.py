#!/usr/bin/env python3
"""
Celery Tasks for Audit Execution

Async tasks for:
- Single audit execution
- Audit plan execution (multiple audits)
- Audit result cleanup
- Task status tracking

All tasks store results in PostgreSQL/SQLite via AuditExecution model.

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import sys
import json
import base64
import shlex
import subprocess  # nosec B404
import traceback
from datetime import datetime, timedelta
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from celery_app import audit_task, celery_app
from celery.exceptions import SoftTimeLimitExceeded, MaxRetriesExceededError
from config import logger
from config import SessionLocal, ORCHESTRATOR_PATH, ROOT_DIR, LOGS_DIR
from models.database import Server, Audit, AuditExecution, HypervisorAuditExecution
from models.dead_letter import DeadLetterTask, TaskFailureLog
from models.server import ServerManager
from sse import get_sse_manager
from circuit_breaker import get_circuit_breaker_registry, CircuitBreakerError
from error_notifier import get_error_notifier

try:
    from services_pkg.services.reporting_persistence_service import ReportingPersistenceService
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = True
except ImportError:
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = False


reporting_persistence_service = ReportingPersistenceService() if _REPORTING_PERSISTENCE_SERVICE_AVAILABLE else None


def _persist_reporting_audit_execution(db_session, execution):
    """Persist canonical reporting rows for a terminal audit execution when available."""
    if reporting_persistence_service is None:
        return None
    return reporting_persistence_service.persist_audit_execution(db_session, execution)


def _normalize_connection_method(method: str) -> str:
    """Normalize connection method aliases to canonical values."""
    if not method:
        return 'ssh'

    normalized = str(method).strip().lower()
    if normalized in ['agent', 'fleet-agent', 'fleet_agent']:
        return 'fleet-agent'
    if normalized in ['ssh', 'winrm', 'hypervisor']:
        return normalized
    return 'ssh'


def calculate_exponential_backoff(retry_number: int, base_delay: int = 60, max_delay: int = 3600) -> int:
    """
    Calculate exponential backoff delay

    Args:
        retry_number: Current retry attempt (0-based)
        base_delay: Base delay in seconds (default 60s = 1 minute)
        max_delay: Maximum delay in seconds (default 3600s = 1 hour)

    Returns:
        int: Delay in seconds

    Examples:
        Retry 0: 60s (1 minute)
        Retry 1: 120s (2 minutes)
        Retry 2: 240s (4 minutes)
        Retry 3: 480s (8 minutes)
        Retry 4: 960s (16 minutes)
        Retry 5+: 3600s (1 hour, capped)
    """
    delay = base_delay * (2 ** retry_number)
    return min(delay, max_delay)


def log_task_failure(
    db,
    task_id: str,
    task_name: str,
    retry_number: int,
    error_message: str,
    exception_type: str,
    full_traceback: str,
    server_id: int = None,
    audit_id: int = None,
    next_retry_at: datetime = None,
    circuit_breaker_state: str = None,
    circuit_breaker_name: str = None
):
    """
    Log task failure to database

    Args:
        db: Database session
        task_id: Celery task ID
        task_name: Task name
        retry_number: Current retry number
        error_message: Error message
        exception_type: Exception class name
        full_traceback: Full traceback string
        server_id: Server ID (optional)
        audit_id: Audit ID (optional)
        next_retry_at: Next retry time (optional)
        circuit_breaker_state: Circuit breaker state (optional)
        circuit_breaker_name: Circuit breaker name (optional)
    """
    try:
        failure_log = TaskFailureLog(
            task_id=task_id,
            task_name=task_name,
            server_id=server_id,
            audit_id=audit_id,
            retry_number=retry_number,
            error_message=error_message[:1000],  # Limit length
            exception_type=exception_type,
            traceback=full_traceback[:5000],  # Limit length
            circuit_breaker_state=circuit_breaker_state,
            circuit_breaker_name=circuit_breaker_name,
            failed_at=datetime.utcnow(),
            next_retry_at=next_retry_at
        )
        db.add(failure_log)
        db.commit()
        logger.info(f"Logged task failure: {task_id} retry {retry_number}")
    except Exception as e:
        logger.error(f"Failed to log task failure: {e}")
        db.rollback()


def add_to_dead_letter_queue(
    db,
    task_id: str,
    task_name: str,
    retry_count: int,
    max_retries: int,
    error_message: str,
    exception_type: str,
    full_traceback: str,
    server_id: int = None,
    audit_id: int = None,
    args: tuple = None,
    kwargs: dict = None
):
    """
    Add failed task to dead letter queue

    Args:
        db: Database session
        task_id: Celery task ID
        task_name: Task name
        retry_count: Number of retries attempted
        max_retries: Maximum retries allowed
        error_message: Error message
        exception_type: Exception class name
        full_traceback: Full traceback string
        server_id: Server ID (optional)
        audit_id: Audit ID (optional)
        args: Task args (optional)
        kwargs: Task kwargs (optional)
    """
    try:
        # Check if already in DLQ
        existing = db.query(DeadLetterTask).filter(
            DeadLetterTask.task_id == task_id
        ).first()

        if existing:
            # Update existing entry
            existing.retry_count = retry_count
            existing.last_error = error_message[:1000]
            existing.last_exception_type = exception_type
            existing.last_traceback = full_traceback[:5000]
            existing.last_attempt_at = datetime.utcnow()
            logger.info(f"Updated existing DLQ entry: {task_id}")
        else:
            # Create new entry
            dlq_task = DeadLetterTask(
                task_id=task_id,
                task_name=task_name,
                server_id=server_id,
                audit_id=audit_id,
                args=list(args) if args else None,
                kwargs=kwargs,
                retry_count=retry_count,
                max_retries=max_retries,
                last_error=error_message[:1000],
                last_exception_type=exception_type,
                last_traceback=full_traceback[:5000],
                first_failure_at=datetime.utcnow(),
                last_attempt_at=datetime.utcnow(),
                added_to_dlq_at=datetime.utcnow(),
                resolved=False
            )
            db.add(dlq_task)
            logger.warning(f"Added task to dead letter queue: {task_id} ({task_name})")

        db.commit()

        # Send notification
        try:
            notifier = get_error_notifier()

            # Get server and audit names
            server_name = None
            audit_name = None
            if server_id:
                server = db.query(Server).filter(Server.id == server_id).first()
                if server:
                    server_name = server.name
            if audit_id:
                audit = db.query(Audit).filter(Audit.id == audit_id).first()
                if audit:
                    audit_name = audit.name

            notifier.notify_task_failure(
                task_id=task_id,
                task_name=task_name,
                error_message=error_message,
                retry_count=retry_count,
                max_retries=max_retries,
                server_name=server_name,
                audit_name=audit_name,
                added_to_dlq=True
            )
        except Exception as e:
            logger.error(f"Failed to send DLQ notification: {e}")

    except Exception as e:
        logger.error(f"Failed to add task to dead letter queue: {e}")
        db.rollback()


def _execute_via_fleet_agent(task, db, server, audit, execution, audit_path, options, task_id, start_time, sse_manager):
    """
    Execute audit via fleet agent API (for agent-based connections)

    Instead of running locally via subprocess, queues a command to the agent.
    The agent will execute locally and push results back via API.

    Args:
        task: Celery task instance
        db: Database session
        server: Server model instance
        audit: Audit model instance
        execution: AuditExecution record
        audit_path: Path to audit script
        options: Execution options
        task_id: Celery task ID
        start_time: Execution start time
        sse_manager: SSE manager for real-time updates

    Returns:
        dict: Execution result
    """
    from api.agent_routes import queue_command_for_agent
    _ = start_time

    logger.info(f"Routing audit to fleet agent: {server.agent_id}")

    # Update execution to show it's queued for agent
    execution.status = 'queued'
    execution.executed_by = f'agent:{server.agent_id}'
    db.commit()

    # Emit SSE event
    if sse_manager:
        sse_manager.publish_task_progress(
            task_id,
            f'Queued for fleet agent on {server.name}',
            30,
            f'Agent will execute: {audit_path}'
        )

    # Queue command for the agent
    command = queue_command_for_agent(
        agent_id=server.agent_id,
        command_type='run_audit',
        command_data={
            'audit_path': audit_path,
            'audit_name': audit.name,
            'execution_id': execution.id,
            'celery_task_id': task_id,
            'options': options or {},
            'schedule_id': options.get('schedule_id') if options else None,
            'schedule_name': options.get('schedule_name') if options else None
        },
        requested_by=options.get('requested_by', 'scheduler') if options else 'scheduler',
        priority=3,  # Higher priority for scheduled audits
        expires_hours=24
    )

    logger.info(f"Queued audit command {command['id']} for agent {server.agent_id}")

    # Update task state
    task.update_state(
        state='PENDING_AGENT',
        meta={
            'status': 'Queued for agent execution',
            'progress': 35,
            'execution_id': execution.id,
            'agent_id': server.agent_id,
            'command_id': command['id']
        }
    )

    # Emit SSE event
    if sse_manager:
        sse_manager.publish_task_progress(
            task_id,
            f'Waiting for agent {server.agent_id}',
            35,
            'Command queued, agent will pick up on next poll'
        )

    # Return queued status - the agent will push results back to the server
    # via the /api/agent/managed/results endpoint
    return {
        'status': 'queued',
        'message': 'Audit queued for fleet agent execution',
        'execution_id': execution.id,
        'agent_id': server.agent_id,
        'command_id': command['id'],
        'server_name': server.name,
        'audit_name': audit.name,
        'audit_path': audit_path,
        'queued_at': datetime.utcnow().isoformat()
    }


def _parse_audit_output(output: str) -> tuple:
    """
    Parse audit output for summary counts and determine status

    Args:
        output: Raw audit output string

    Returns:
        tuple: (pass_count, warn_count, fail_count, skip_count, summary_json, status)
    """
    pass_count = output.count('[PASS]')
    warn_count = output.count('[WARN]')
    fail_count = output.count('[FAIL]')
    skip_count = output.count('[SKIP]')

    summary = json.dumps({
        'pass': pass_count,
        'warn': warn_count,
        'fail': fail_count,
        'skip': skip_count,
        'total': pass_count + warn_count + fail_count + skip_count
    })

    # Determine status based on results
    if fail_count > 0:
        status = 'failure'
    elif warn_count > 0:
        status = 'warning'
    else:
        status = 'success'

    return pass_count, warn_count, fail_count, skip_count, summary, status


def _should_retry_non_elevated(exit_code: int, output: str, elevation_method: str) -> bool:
    """
    Determine whether execution should retry without elevation.

    Retries only when the elevated transport/wrapper mechanism fails, not when
    audit checks themselves report PASS/WARN/FAIL/SKIP markers.
    """
    method = (elevation_method or '').strip().lower()
    if exit_code == 0 or method in ('', 'none'):
        return False

    out = (output or '')
    lower = out.lower()

    # If audit markers are present, the audit executed and produced results.
    if any(marker in lower for marker in ('[pass]', '[warn]', '[fail]', '[skip]')):
        return False

    patterns = (
        'sudo:',
        'a password is required',
        'no tty present',
        'terminal is required',
        'the command line is too long',
        'command line is too long',
        'run-audit-jer',
        'is not recognized as the name of a cmdlet',
        'not recognized as the name of a cmdlet',
        'jea endpoint',
        'endpoint',
        'access is denied',
        'permission denied',
        'requested endpoint',
    )
    return any(pattern in lower for pattern in patterns)


def _normalize_ssh_result(result) -> tuple:
    if hasattr(result, 'returncode'):
        output = (result.stdout or '') + (result.stderr or '')
        exit_code = result.returncode
    elif isinstance(result, dict):
        output = result.get('stdout', '') + result.get('stderr', '')
        exit_code = result.get('return_code', 1)
    else:
        output = str(result)
        exit_code = 0
    return output, exit_code


def _normalize_winrm_result(result: dict) -> tuple:
    output = result.get('stdout', '') + result.get('stderr', '')
    exit_code = result.get('return_code', 1 if not result.get('success') else 0)
    return output, exit_code


def _winrm_readiness_preflight(
    server_dict: dict,
    timeout: int,
    task_logger,
    require_jea_endpoint: bool = False,
    jea_endpoint: str = 'SecurityAudit'
) -> tuple:
    """
    Validate legacy WinRM readiness before attempting audit execution.

    Returns:
        tuple: (ready: bool, message: str)
    """
    from winrm_manager import winrm_manager

    host = server_dict.get('host') or server_dict.get('hostname')
    port = int(server_dict.get('port', 5985) or 5985)
    user = server_dict.get('user') or server_dict.get('username')
    password = server_dict.get('password')

    conn_test = winrm_manager.test_connection(
        hostname=host,
        port=port,
        username=user,
        password=password,
        use_ssl=(port == 5986),
        transport='ntlm',
        timeout=min(timeout, 30)
    )

    if not conn_test.get('success'):
        message = conn_test.get('error') or conn_test.get('message') or 'WinRM connectivity/auth failed'
        details = conn_test.get('details')
        return False, f"Preflight connection failed: {message}\n{details or ''}".strip()

    escaped_endpoint = (jea_endpoint or 'SecurityAudit').replace("'", "''")
    readiness_script = f"""
$ErrorActionPreference = 'Stop'
$svc = Get-Service WinRM -ErrorAction Stop
$listeners = (winrm enumerate winrm/config/listener | Out-String)
$auth = Get-ChildItem WSMan:\\localhost\\Service\\Auth -ErrorAction Stop
$neg = ($auth | Where-Object Name -eq 'Negotiate').Value
$kerb = ($auth | Where-Object Name -eq 'Kerberos').Value
$wrapper = Test-Path 'C:\\Program Files\\SecurityAuditToolkit\\scripts\\run-audit-jer.ps1'
$jea = $true
if ({'$true' if require_jea_endpoint else '$false'}) {{
    $jea = [bool](Get-PSSessionConfiguration -Name '{escaped_endpoint}' -ErrorAction SilentlyContinue)
}}
$http = $listeners -match 'Transport = HTTP'
$https = $listeners -match 'Transport = HTTPS'
$ok = ($svc.Status -eq 'Running') -and $neg -and $kerb -and $wrapper -and $http -and $jea
$obj = [ordered]@{{
    ok = [bool]$ok
    service = [string]$svc.Status
    auth_negotiate = [bool]$neg
    auth_kerberos = [bool]$kerb
    listener_http = [bool]$http
    listener_https = [bool]$https
    wrapper_present = [bool]$wrapper
    jea_endpoint_required = {'$true' if require_jea_endpoint else '$false'}
    jea_endpoint_present = [bool]$jea
    jea_endpoint_name = '{escaped_endpoint}'
}}
$obj | ConvertTo-Json -Compress
if (-not $ok) {{ exit 3 }}
exit 0
""".strip()

    check_result = winrm_manager.execute_command(
        server=server_dict,
        command=readiness_script,
        powershell=True,
        timeout=min(timeout, 45)
    )
    output, exit_code = _normalize_winrm_result(check_result)

    if exit_code != 0:
        task_logger.warning(
            "WinRM readiness preflight failed for %s: %s",
            server_dict.get('name', 'unknown'),
            output.strip()[:500]
        )
        return False, f"Preflight readiness failed (exit={exit_code}):\n{output}".strip()

    return True, output.strip() or 'WinRM readiness preflight passed'


def _execute_via_ssh_linux(server_dict: dict, audit_path: str, audit_full_path, timeout: int, logger) -> tuple:
    """
    Execute Linux audit via SSH

    Streams the audit script to the remote server and executes it with bash.
    Uses the SSH manager with circuit breaker protection.

    Args:
        server_dict: Server configuration dict
        audit_path: Relative audit path
        audit_full_path: Full local path to audit script
        timeout: Execution timeout in seconds
        logger: Logger instance

    Returns:
        tuple: (output, exit_code, status, summary_json)
    """
    from ssh_manager import SSHManager
    from encryption import ssh_host_key_manager, password_manager
    from config import SSH_DIR

    ssh_mgr = SSHManager(
        ssh_dir=SSH_DIR,
        ssh_host_key_manager=ssh_host_key_manager,
        password_manager=password_manager
    )

    try:
        # Read audit script content
        with open(audit_full_path, 'r', encoding='utf-8', errors='ignore') as f:
            script_content = f.read()
        script_content = script_content.replace('\r\n', '\n').replace('\r', '\n')

        # Determine execution mode
        execution_mode = server_dict.get('execution_mode', 'stream')
        elevation_method = (server_dict.get('elevation_method') or 'sudo').strip().lower()

        fallback_command = None

        if elevation_method == 'audit_wrapper':
            # Wrapper mode requires deployed script path on target host.
            audit_rel = audit_path[7:] if audit_path.startswith('audits/') else audit_path
            command = (
                'if [ -x /opt/security-audit-toolkit/bin/audit-wrapper ]; then '
                'AUDIT_TOOLKIT_ROOT=/opt/security-audit-toolkit '
                'sudo -n /opt/security-audit-toolkit/bin/audit-wrapper '
                f'{shlex.quote(audit_rel)}; '
                'elif [ -x /usr/local/bin/audit-wrapper ]; then '
                'AUDIT_TOOLKIT_ROOT=/opt/security-audit-toolkit '
                'sudo -n /usr/local/bin/audit-wrapper '
                f'{shlex.quote(audit_rel)}; '
                'else '
                'sudo -n bash /opt/security-audit-toolkit/deployment/linux/least-privilege/audit-wrapper.sh '
                f'{shlex.quote(audit_rel)}; '
                'fi'
            )
            remote_path = f"/opt/audit-toolkit/{audit_path}"
            fallback_command = f'bash "{remote_path}"'
        elif execution_mode == 'deployed':
            # Run pre-installed script on remote host
            remote_path = f"/opt/audit-toolkit/{audit_path}"
            if elevation_method == 'sudo_nopasswd':
                command = f'sudo -n bash "{remote_path}"'
                fallback_command = f'bash "{remote_path}"'
            elif elevation_method == 'none':
                command = f'bash "{remote_path}"'
            else:
                command = f'sudo bash "{remote_path}"'
                fallback_command = f'bash "{remote_path}"'
        else:
            # Stream mode: base64 encode to avoid quoting/escaping issues.
            encoded = base64.b64encode(script_content.encode('utf-8')).decode('ascii')
            if elevation_method == 'sudo_nopasswd':
                command = f"echo {shlex.quote(encoded)} | base64 -d | sudo -n bash"
                fallback_command = f"echo {shlex.quote(encoded)} | base64 -d | bash"
            elif elevation_method == 'none':
                command = f"echo {shlex.quote(encoded)} | base64 -d | bash"
            else:
                command = f"echo {shlex.quote(encoded)} | base64 -d | sudo bash"
                fallback_command = f"echo {shlex.quote(encoded)} | base64 -d | bash"

        # Execute via SSH
        result = ssh_mgr.execute_command(server_dict, command, timeout=timeout)
        output, exit_code = _normalize_ssh_result(result)

        if fallback_command and _should_retry_non_elevated(exit_code, output, elevation_method):
            logger.warning(
                "Elevated Linux execution failed on %s; retrying non-elevated",
                server_dict.get('name', 'unknown')
            )
            retry_result = ssh_mgr.execute_command(server_dict, fallback_command, timeout=timeout)
            retry_output, retry_exit = _normalize_ssh_result(retry_result)
            output = (
                "NOTICE: Elevated execution failed; retried non-elevated.\n"
                f"--- elevated output ---\n{output}\n"
                f"--- non-elevated output ---\n{retry_output}"
            )
            exit_code = retry_exit

        # Parse output for summary
        _, _, _, _, summary, status = _parse_audit_output(output)

        if exit_code != 0 and status == 'success':
            status = 'failure'

        return output, exit_code, status, summary

    except subprocess.TimeoutExpired:
        output = f"SSH audit execution timeout after {timeout} seconds"
        logger.warning(f"SSH timeout on {server_dict['name']}")
        return output, 124, 'timeout', json.dumps({'timeout': True})

    except Exception as e:
        output = f"SSH execution error: {str(e)}"
        logger.error(f"SSH execution failed on {server_dict['name']}: {e}")
        return output, 1, 'failure', json.dumps({'error': str(e)})


def _execute_via_ssh_windows(server_dict: dict, audit_path: str, audit_full_path, timeout: int, logger) -> tuple:
    """
    Execute Windows audit via SSH (PowerShell)

    Connects via SSH and runs PowerShell audit scripts.
    Windows Server with OpenSSH or similar SSH server required.

    Args:
        server_dict: Server configuration dict
        audit_path: Relative audit path
        audit_full_path: Full local path to audit script
        timeout: Execution timeout in seconds
        logger: Logger instance

    Returns:
        tuple: (output, exit_code, status, summary_json)
    """
    from ssh_manager import SSHManager
    from encryption import ssh_host_key_manager, password_manager
    from config import SSH_DIR

    ssh_mgr = SSHManager(
        ssh_dir=SSH_DIR,
        ssh_host_key_manager=ssh_host_key_manager,
        password_manager=password_manager
    )

    server_dict = dict(server_dict)
    current_port = int(server_dict.get('port', 22) or 22)
    if current_port in (5985, 5986):
        logger.info(
            "Using SSH port 22 for Windows host %s (was %s)",
            server_dict.get('host'),
            current_port
        )
        server_dict['port'] = 22

    try:
        # Determine execution mode
        execution_mode = server_dict.get('execution_mode', 'stream')
        elevation_method = (server_dict.get('elevation_method') or 'runas').strip().lower()
        jea_endpoint = (server_dict.get('jea_endpoint') or 'SecurityAudit').strip()
        remote_wrapper = r'C:\Program Files\SecurityAuditToolkit\scripts\run-audit-jer.ps1'

        fallback_command = None
        if execution_mode == 'deployed':
            # Run pre-installed script on remote Windows host
            windows_audit_path = audit_path.replace('/', '\\')
            remote_path = f"C:\\Program Files\\SecurityAuditToolkit\\{windows_audit_path}"
            if elevation_method == 'jea':
                command = (
                    'powershell -NoProfile -ExecutionPolicy Bypass '
                    f'-File "{remote_wrapper}" -ScriptPath "{remote_path}" '
                    f'-Mode jea -JeaEndpoint "{jea_endpoint}"'
                )
                fallback_command = f'powershell -NoProfile -ExecutionPolicy Bypass -File "{remote_path}"'
            elif elevation_method in ('runas', 'admin'):
                command = (
                    'powershell -NoProfile -ExecutionPolicy Bypass '
                    f'-File "{remote_wrapper}" -ScriptPath "{remote_path}" -Mode runas'
                )
                fallback_command = f'powershell -NoProfile -ExecutionPolicy Bypass -File "{remote_path}"'
            else:
                command = f'powershell -NoProfile -ExecutionPolicy Bypass -File "{remote_path}"'
        else:
            # Stream mode: read script and execute via stdin
            with open(audit_full_path, 'r') as f:
                script_content = f.read()
            if elevation_method in ('jea', 'runas', 'admin'):
                script_utf16 = base64.b64encode(script_content.encode('utf-16-le')).decode('ascii')
                mode = 'jea' if elevation_method == 'jea' else 'runas'
                wrapper_script = f"""
$tmp = Join-Path $env:TEMP ('audit-stream-' + [guid]::NewGuid().ToString() + '.ps1')
[IO.File]::WriteAllText($tmp, [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('{script_utf16}')))
try {{
  & '{remote_wrapper}' -ScriptPath $tmp -Mode {mode} -JeaEndpoint '{jea_endpoint}'
  exit $LASTEXITCODE
}}
finally {{
  Remove-Item $tmp -Force -ErrorAction SilentlyContinue
}}
""".strip()
                encoded = base64.b64encode(wrapper_script.encode('utf-16-le')).decode('ascii')
                command = f'powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand {encoded}'
                fallback_encoded = base64.b64encode(script_content.encode('utf-16-le')).decode('ascii')
                fallback_command = f'powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand {fallback_encoded}'
            else:
                encoded = base64.b64encode(script_content.encode('utf-16-le')).decode('ascii')
                command = f'powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand {encoded}'

        # Execute via SSH
        result = ssh_mgr.execute_command(server_dict, command, timeout=timeout)
        output, exit_code = _normalize_ssh_result(result)

        if fallback_command and _should_retry_non_elevated(exit_code, output, elevation_method):
            logger.warning(
                "Elevated Windows SSH execution failed on %s; retrying non-elevated",
                server_dict.get('name', 'unknown')
            )
            retry_result = ssh_mgr.execute_command(server_dict, fallback_command, timeout=timeout)
            retry_output, retry_exit = _normalize_ssh_result(retry_result)
            output = (
                "NOTICE: Elevated execution failed; retried non-elevated.\n"
                f"--- elevated output ---\n{output}\n"
                f"--- non-elevated output ---\n{retry_output}"
            )
            exit_code = retry_exit

        # Parse output for summary
        _, _, _, _, summary, status = _parse_audit_output(output)

        if exit_code != 0 and status == 'success':
            status = 'failure'

        return output, exit_code, status, summary

    except subprocess.TimeoutExpired:
        output = f"SSH/PowerShell audit execution timeout after {timeout} seconds"
        logger.warning(f"SSH Windows timeout on {server_dict['name']}")
        return output, 124, 'timeout', json.dumps({'timeout': True})

    except Exception as e:
        output = f"SSH/PowerShell execution error: {str(e)}"
        logger.error(f"SSH Windows execution failed on {server_dict['name']}: {e}")
        return output, 1, 'failure', json.dumps({'error': str(e)})


def _execute_via_winrm(
    server_dict: dict,
    audit_path: str,
    audit_full_path,
    timeout: int,
    logger,
    strict_elevation: bool = False,
    enable_readiness_gate: bool = True,
    require_jea_endpoint: bool = False
) -> tuple:
    """
    Execute Windows audit via WinRM

    Connects via WinRM (Windows Remote Management) and runs PowerShell audit scripts.
    Target must have WinRM enabled (Enable-PSRemoting -Force).

    Args:
        server_dict: Server configuration dict
        audit_path: Relative audit path
        audit_full_path: Full local path to audit script
        timeout: Execution timeout in seconds
        logger: Logger instance

    Returns:
        tuple: (output, exit_code, status, summary_json)
    """
    from winrm_manager import winrm_manager, WINRM_AVAILABLE

    if not WINRM_AVAILABLE:
        return (
            "WinRM not available - pywinrm not installed",
            1,
            'failure',
            json.dumps({'error': 'pywinrm not installed'})
        )

    remote_temp_path = None

    try:
        # Determine execution mode
        execution_mode = server_dict.get('execution_mode', 'stream')
        elevation_method = (server_dict.get('elevation_method') or 'runas').strip().lower()
        jea_endpoint = (server_dict.get('jea_endpoint') or 'SecurityAudit').strip()
        remote_wrapper = r'C:\Program Files\SecurityAuditToolkit\scripts\run-audit-jer.ps1'

        if enable_readiness_gate:
            need_jea = require_jea_endpoint or elevation_method == 'jea'
            ready, readiness_message = _winrm_readiness_preflight(
                server_dict=server_dict,
                timeout=timeout,
                task_logger=logger,
                require_jea_endpoint=need_jea,
                jea_endpoint=jea_endpoint
            )
            if not ready:
                return (
                    f"WinRM readiness gate blocked legacy execution.\n{readiness_message}",
                    1,
                    'failure',
                    json.dumps({'error': 'winrm_readiness_failed', 'details': readiness_message})
                )

        fallback_script = None
        if execution_mode == 'deployed':
            # Run pre-installed script on remote Windows host
            windows_audit_path = audit_path.replace('/', '\\')
            remote_path = f"C:\\Program Files\\SecurityAuditToolkit\\{windows_audit_path}"
            if elevation_method == 'jea':
                script = (
                    f'& "{remote_wrapper}" -ScriptPath "{remote_path}" '
                    f'-Mode jea -JeaEndpoint "{jea_endpoint}"'
                )
                fallback_script = f'& "{remote_path}"'
            elif elevation_method in ('runas', 'admin'):
                script = f'& "{remote_wrapper}" -ScriptPath "{remote_path}" -Mode runas'
                fallback_script = f'& "{remote_path}"'
            else:
                script = f'& "{remote_path}"'
        else:
            # Stream mode: read script and execute inline
            with open(audit_full_path, 'r') as f:
                script_content = f.read()

            # WinRM/PowerShell can fail with "The command line is too long" for larger inline payloads.
            # Stage large scripts remotely in chunks and execute from file.
            if len(script_content) > 1400:
                from uuid import uuid4

                remote_temp_path = fr"C:\Windows\Temp\audit-stream-{uuid4().hex}.ps1"

                init_script = (
                    f"Remove-Item -Path '{remote_temp_path}' -Force -ErrorAction SilentlyContinue; "
                    f"New-Item -Path '{remote_temp_path}' -ItemType File -Force | Out-Null"
                )
                winrm_manager.execute_command(
                    server=server_dict,
                    command=init_script,
                    powershell=True,
                    timeout=timeout
                )

                chunk_size = 900
                for start in range(0, len(script_content), chunk_size):
                    chunk = script_content[start:start + chunk_size]
                    chunk_b64 = base64.b64encode(chunk.encode('utf-8')).decode('ascii')
                    append_script = (
                        f"$chunk = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{chunk_b64}')); "
                        f"[IO.File]::AppendAllText('{remote_temp_path}', $chunk, [Text.Encoding]::UTF8)"
                    )
                    winrm_manager.execute_command(
                        server=server_dict,
                        command=append_script,
                        powershell=True,
                        timeout=timeout
                    )

                if elevation_method == 'jea':
                    script = (
                        f'& "{remote_wrapper}" -ScriptPath "{remote_temp_path}" '
                        f'-Mode jea -JeaEndpoint "{jea_endpoint}"'
                    )
                    fallback_script = f'& "{remote_temp_path}"'
                elif elevation_method in ('runas', 'admin'):
                    script = f'& "{remote_wrapper}" -ScriptPath "{remote_temp_path}" -Mode runas'
                    fallback_script = f'& "{remote_temp_path}"'
                else:
                    script = f'& "{remote_temp_path}"'
                    fallback_script = None

            elif elevation_method in ('jea', 'runas', 'admin'):
                encoded = base64.b64encode(script_content.encode('utf-16-le')).decode('ascii')
                mode = 'jea' if elevation_method == 'jea' else 'runas'
                script = f"""
$tmp = Join-Path $env:TEMP ('audit-stream-' + [guid]::NewGuid().ToString() + '.ps1')
[IO.File]::WriteAllText($tmp, [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('{encoded}')))
try {{
  & '{remote_wrapper}' -ScriptPath $tmp -Mode {mode} -JeaEndpoint '{jea_endpoint}'
  exit $LASTEXITCODE
}}
finally {{
  Remove-Item $tmp -Force -ErrorAction SilentlyContinue
}}
""".strip()
                fallback_script = script_content
            else:
                script = script_content

        # Execute via WinRM
        result = winrm_manager.execute_command(
            server=server_dict,
            command=script,
            powershell=True,
            timeout=timeout
        )
        output, exit_code = _normalize_winrm_result(result)

        if (not strict_elevation) and fallback_script and _should_retry_non_elevated(exit_code, output, elevation_method):
            logger.warning(
                "Elevated WinRM execution failed on %s; retrying non-elevated",
                server_dict.get('name', 'unknown')
            )
            retry_result = winrm_manager.execute_command(
                server=server_dict,
                command=fallback_script,
                powershell=True,
                timeout=timeout
            )
            retry_output, retry_exit = _normalize_winrm_result(retry_result)
            output = (
                "NOTICE: Elevated execution failed; retried non-elevated.\n"
                f"--- elevated output ---\n{output}\n"
                f"--- non-elevated output ---\n{retry_output}"
            )
            exit_code = retry_exit
        elif strict_elevation and fallback_script and _should_retry_non_elevated(exit_code, output, elevation_method):
            logger.warning(
                "Strict elevation mode enabled on %s; non-elevated fallback disabled",
                server_dict.get('name', 'unknown')
            )

        # Parse output for summary
        _, _, _, _, summary, status = _parse_audit_output(output)

        if exit_code != 0 and status == 'success':
            status = 'failure'

        return output, exit_code, status, summary

    except Exception as e:
        output = f"WinRM execution error: {str(e)}"
        logger.error(f"WinRM execution failed on {server_dict['name']}: {e}")
        return output, 1, 'failure', json.dumps({'error': str(e)})
    finally:
        if remote_temp_path:
            try:
                winrm_manager.execute_command(
                    server=server_dict,
                    command=f"Remove-Item -Path '{remote_temp_path}' -Force -ErrorAction SilentlyContinue",
                    powershell=True,
                    timeout=min(timeout, 30)
                )
            except Exception as cleanup_error:
                logger.debug(f"Remote temp cleanup skipped for {server_dict.get('name', 'unknown')}: {cleanup_error}")


@audit_task(
    name='tasks.audit_tasks.execute_audit',
    bind=True,
    max_retries=5,  # Maximum retry attempts
    autoretry_for=(Exception,),  # Retry on any exception
    retry_backoff=True,  # Enable exponential backoff
    retry_backoff_max=3600,  # Max backoff: 1 hour
    retry_jitter=True,  # Add random jitter to prevent thundering herd
    acks_late=True,  # Acknowledge after completion
    reject_on_worker_lost=True  # Requeue if worker crashes
)
def execute_audit(self, server_id: int, audit_path: str, options: dict = None):
    """
    Execute single audit on remote server asynchronously

    Args:
        self: Celery task instance (bound)
        server_id: Database ID of server
        audit_path: Relative path to audit script
        options: Optional execution options (timeout, etc.)

    Returns:
        dict: Execution result with status, output, summary
    """
    db = SessionLocal()
    task_id = self.request.id
    start_time = datetime.utcnow()

    try:
        # Get SSE manager for real-time updates
        sse_manager = get_sse_manager()

        # Update task state to STARTED
        self.update_state(
            state='STARTED',
            meta={'status': 'Initializing...', 'progress': 0}
        )

        # Emit SSE event
        if sse_manager:
            sse_manager.publish_task_progress(
                task_id, 'Initializing...', 0
            )

        # Get server from database
        server = db.query(Server).filter(Server.id == server_id).first()
        if not server:
            raise ValueError(f"Server {server_id} not found")

        # Get or create audit record
        audit = db.query(Audit).filter(Audit.file_path == audit_path).first()
        if not audit:
            # Create audit record from file path
            audit = Audit(
                name=Path(audit_path).name,
                domain=Path(audit_path).parts[1] if len(Path(audit_path).parts) > 1 else 'unknown',
                category=Path(audit_path).parts[2] if len(Path(audit_path).parts) > 2 else 'unknown',
                file_path=audit_path,
                created_at=datetime.utcnow()
            )
            db.add(audit)
            db.commit()
            db.refresh(audit)

        # Create execution record
        execution = AuditExecution(
            server_id=server.id,
            audit_id=audit.id,
            status='running',
            executed_by='celery',
            executed_at=start_time
        )
        db.add(execution)
        db.commit()
        db.refresh(execution)

        logger.info(f"Starting audit execution: {audit.name} on {server.name} (task {task_id})")

        # Update state to RUNNING
        self.update_state(
            state='RUNNING',
            meta={
                'status': f'Executing {audit.name} on {server.name}...',
                'progress': 25,
                'execution_id': execution.id
            }
        )

        # Emit SSE event
        if sse_manager:
            sse_manager.publish_task_progress(
                task_id,
                f'Executing {audit.name} on {server.name}',
                25,
                f'Running audit: {audit_path}'
            )

        # Check if server uses fleet agent (API-based execution)
        server_connection_method = _normalize_connection_method(server.connection_method)
        if server_connection_method == 'fleet-agent' and server.agent_id:
            # Queue command to fleet agent instead of running locally
            return _execute_via_fleet_agent(
                self, db, server, audit, execution, audit_path, options, task_id, start_time, sse_manager
            )
        elif server_connection_method == 'fleet-agent' and not server.agent_id:
            raise ValueError(
                f"Server {server.name} is configured for fleet-agent but has no agent_id. "
                "Update server configuration or re-register the agent."
            )

        # Build SSH command (for direct SSH/WinRM connections)
        # Convert server model to dict for compatibility
        inferred_os_type = (getattr(server, 'os_type', None) or '').lower()
        if not inferred_os_type:
            server_elevation_method = (getattr(server, 'elevation_method', '') or '').lower()
            if server_connection_method == 'winrm' or server_elevation_method in ('runas', 'jea', 'admin'):
                inferred_os_type = 'windows'
            else:
                inferred_os_type = 'linux'

        server_dict = {
            'id': server.id,
            'name': server.name,
            'host': server.hostname,
            'port': server.port,
            'user': server.username,
            'password': server.password,
            'key_path': server.ssh_key_path,
            'auth_type': 'password' if server.password else 'public_key',
            'os_type': inferred_os_type,
            'connection_method': server_connection_method,
            'execution_mode': server.execution_mode or 'stream',
            'elevation_method': getattr(server, 'elevation_method', None) or ('sudo' if inferred_os_type == 'linux' else 'runas'),
            'jea_endpoint': getattr(server, 'jea_endpoint', None),
        }

        # Execute audit via SSH - Get timeout from security settings
        # Options can override security settings if provided
        try:
            from security_settings import get_audit_execution_settings
            audit_settings = get_audit_execution_settings()
            default_timeout = audit_settings['audit_timeout']
        except ImportError:
            default_timeout = 300

        timeout = options.get('timeout', default_timeout) if options else default_timeout
        audit_full_path = ROOT_DIR / audit_path

        # Route execution based on connection method and OS type
        connection_method = _normalize_connection_method(server_dict['connection_method'])
        os_type = server_dict['os_type'].lower()

        try:
            if connection_method == 'winrm':
                # Windows via WinRM
                strict_elevation = bool(options.get('strict_elevation')) if options else False
                enable_readiness_gate = True if not options else bool(options.get('enable_readiness_gate', True))
                require_jea_endpoint = False if not options else bool(options.get('require_jea_endpoint', False))
                output, exit_code, status, summary = _execute_via_winrm(
                    server_dict,
                    audit_path,
                    audit_full_path,
                    timeout,
                    logger,
                    strict_elevation=strict_elevation,
                    enable_readiness_gate=enable_readiness_gate,
                    require_jea_endpoint=require_jea_endpoint
                )
            elif os_type == 'windows' and connection_method == 'ssh':
                # Windows via SSH (PowerShell)
                output, exit_code, status, summary = _execute_via_ssh_windows(
                    server_dict, audit_path, audit_full_path, timeout, logger
                )
            else:
                # Linux via SSH (default)
                output, exit_code, status, summary = _execute_via_ssh_linux(
                    server_dict, audit_path, audit_full_path, timeout, logger
                )

        except Exception as e:
            output = f"Audit execution error: {str(e)}"
            exit_code = 1
            status = 'failure'
            summary = json.dumps({'error': str(e)})
            logger.error(f"Audit execution failed: {e}")

        # Calculate duration
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()

        # Update execution record
        execution.status = status
        execution.exit_code = exit_code
        execution.output = output
        execution.summary = summary
        execution.duration_seconds = duration
        execution.completed_at = end_time
        _persist_reporting_audit_execution(db, execution)
        db.commit()

        # Update server last_audit_at
        server.last_audit_at = end_time
        db.commit()

        logger.info(f"Audit completed: {audit.name} on {server.name} - {status} (duration: {duration:.2f}s)")

        # Send notifications if this was a scheduled audit
        if options and 'schedule_id' in options:
            try:
                from models.schedule import ScheduledAudit
                from notifications import notification_manager

                schedule_id = options['schedule_id']
                schedule = db.query(ScheduledAudit).filter(ScheduledAudit.id == schedule_id).first()

                if schedule and schedule.notification_enabled:
                    # Parse summary for notification
                    summary_dict = json.loads(summary)

                    # Update schedule status
                    schedule.last_status = status
                    db.commit()

                    # Send notifications
                    emails = [e.strip() for e in schedule.notification_emails.split(',') if e.strip()] if schedule.notification_emails else []
                    webhooks = [w.strip() for w in schedule.notification_webhooks.split(',') if w.strip()] if schedule.notification_webhooks else []

                    if emails or webhooks:
                        notification_result = notification_manager.notify_schedule_execution(
                            schedule_name=schedule.name,
                            server_name=server.name,
                            audit_name=audit.name,
                            status=status,
                            execution_summary={
                                'total_checks': summary_dict.get('total_checks', 0),
                                'passed_checks': summary_dict.get('passed', 0),
                                'failed_checks': summary_dict.get('failed', 0),
                                'warned_checks': summary_dict.get('warned', 0),
                                'skipped_checks': summary_dict.get('skipped', 0),
                                'duration_seconds': duration
                            },
                            email_recipients=emails,
                            webhook_urls=webhooks
                        )
                        logger.info(f"Sent notifications for schedule {schedule.name}: {notification_result}")
            except Exception as e:
                logger.error(f"Failed to send notifications for scheduled audit: {e}")

        # Emit SSE completion event
        if sse_manager:
            sse_manager.publish_task_complete(
                task_id,
                status,
                {
                    'execution_id': execution.id,
                    'audit_name': audit.name,
                    'server_name': server.name,
                    'summary': json.loads(summary),
                    'duration_seconds': duration
                }
            )

        # Return result
        return {
            'execution_id': execution.id,
            'server_id': server.id,
            'server_name': server.name,
            'audit_id': audit.id,
            'audit_name': audit.name,
            'status': status,
            'exit_code': exit_code,
            'summary': json.loads(summary),
            'duration_seconds': duration,
            'executed_at': start_time.isoformat(),
            'completed_at': end_time.isoformat()
        }

    except SoftTimeLimitExceeded:
        # Task hit soft time limit (1 hour)
        logger.warning(f"Task {task_id} hit soft time limit")
        if 'execution' in locals():
            execution.status = 'timeout'
            execution.output = 'Task exceeded soft time limit (1 hour)'
            execution.completed_at = datetime.utcnow()
            _persist_reporting_audit_execution(db, execution)
            db.commit()

        # Log failure
        if 'server' in locals() and 'audit' in locals():
            log_task_failure(
                db, task_id, 'execute_audit', self.request.retries,
                'Soft time limit exceeded', 'SoftTimeLimitExceeded', '',
                server_id=server.id if server else None,
                audit_id=audit.id if audit else None
            )

        # Don't retry timeouts
        raise

    except CircuitBreakerError as e:
        # Circuit breaker is open - don't retry immediately
        logger.error(f"Task {task_id} blocked by circuit breaker: {e.service_name}")
        if 'execution' in locals():
            execution.status = 'failure'
            execution.output = f"Circuit breaker open: {str(e)}"
            execution.completed_at = datetime.utcnow()
            _persist_reporting_audit_execution(db, execution)
            db.commit()

        # Log failure with circuit breaker info
        if 'server' in locals() and 'audit' in locals():
            log_task_failure(
                db, task_id, 'execute_audit', self.request.retries,
                str(e), 'CircuitBreakerError', traceback.format_exc(),
                server_id=server.id if server else None,
                audit_id=audit.id if audit else None,
                circuit_breaker_state='OPEN',
                circuit_breaker_name=e.service_name
            )

        # Calculate when to retry (after circuit breaker resets)
        retry_eta = e.reset_time if hasattr(e, 'reset_time') else datetime.utcnow() + timedelta(seconds=60)

        # Retry with exponential backoff
        try:
            raise self.retry(exc=e, countdown=None, eta=retry_eta)
        except MaxRetriesExceededError:
            # Max retries exceeded - add to dead letter queue
            if 'server' in locals() and 'audit' in locals():
                add_to_dead_letter_queue(
                    db, task_id, 'execute_audit',
                    self.request.retries, self.max_retries,
                    str(e), 'CircuitBreakerError', traceback.format_exc(),
                    server_id=server.id if server else None,
                    audit_id=audit.id if audit else None,
                    args=(server_id, audit_path),
                    kwargs=options or {}
                )
            raise

    except Exception as e:
        logger.error(f"Task {task_id} failed: {e}")
        full_traceback = traceback.format_exc()

        if 'execution' in locals():
            execution.status = 'failure'
            execution.output = f"Task error: {str(e)}\n\n{full_traceback[:1000]}"
            execution.completed_at = datetime.utcnow()
            _persist_reporting_audit_execution(db, execution)
            db.commit()

        # Log failure
        if 'server' in locals() and 'audit' in locals():
            # Calculate next retry time with exponential backoff
            retry_number = self.request.retries
            backoff_delay = calculate_exponential_backoff(retry_number)
            next_retry_at = datetime.utcnow() + timedelta(seconds=backoff_delay)

            log_task_failure(
                db, task_id, 'execute_audit', retry_number,
                str(e), e.__class__.__name__, full_traceback,
                server_id=server.id if server else None,
                audit_id=audit.id if audit else None,
                next_retry_at=next_retry_at
            )

            # Send non-DLQ notification (still retrying)
            try:
                notifier = get_error_notifier()
                notifier.notify_task_failure(
                    task_id=task_id,
                    task_name='execute_audit',
                    error_message=str(e),
                    retry_count=retry_number,
                    max_retries=self.max_retries,
                    server_name=server.name if server else None,
                    audit_name=audit.name if audit else None,
                    added_to_dlq=False
                )
            except Exception as notify_error:
                logger.error(f"Failed to send error notification: {notify_error}")

        # Retry with exponential backoff
        try:
            retry_delay = calculate_exponential_backoff(self.request.retries)
            logger.info(f"Retrying task {task_id} in {retry_delay}s (attempt {self.request.retries + 1}/{self.max_retries})")
            raise self.retry(exc=e, countdown=retry_delay)
        except MaxRetriesExceededError:
            # Max retries exceeded - add to dead letter queue
            logger.error(f"Task {task_id} exceeded max retries ({self.max_retries})")
            if 'server' in locals() and 'audit' in locals():
                add_to_dead_letter_queue(
                    db, task_id, 'execute_audit',
                    self.request.retries, self.max_retries,
                    str(e), e.__class__.__name__, full_traceback,
                    server_id=server.id if server else None,
                    audit_id=audit.id if audit else None,
                    args=(server_id, audit_path),
                    kwargs=options or {}
                )
            raise

    finally:
        db.close()


# Backward-compatibility alias for legacy task references
run_audit = execute_audit


@audit_task(name='tasks.audit_tasks.execute_audit_plan')
def execute_audit_plan(self, server_id: int, audit_paths: list, plan_name: str = None):
    """
    Execute multiple audits on server (audit plan)

    Args:
        self: Celery task instance
        server_id: Database ID of server
        audit_paths: List of audit script paths
        plan_name: Optional name for the plan

    Returns:
        dict: Plan execution results with individual audit results
    """
    task_id = self.request.id
    start_time = datetime.utcnow()
    results = []

    logger.info(f"Starting audit plan execution: {len(audit_paths)} audits on server {server_id} (task {task_id})")

    try:
        for i, audit_path in enumerate(audit_paths):
            progress = int((i / len(audit_paths)) * 100)
            self.update_state(
                state='RUNNING',
                meta={
                    'status': f'Executing audit {i+1}/{len(audit_paths)}: {Path(audit_path).name}',
                    'progress': progress,
                    'completed': i,
                    'total': len(audit_paths)
                }
            )

            # Execute audit synchronously (we're already async)
            try:
                result = execute_audit(self, server_id, audit_path)
                results.append(result)
            except Exception as e:
                logger.error(f"Audit {audit_path} failed: {e}")
                results.append({
                    'audit_path': audit_path,
                    'status': 'failure',
                    'error': str(e)
                })

        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()

        # Calculate summary
        success_count = sum(1 for r in results if r.get('status') == 'success')
        failure_count = sum(1 for r in results if r.get('status') in ['failure', 'timeout'])

        return {
            'plan_name': plan_name or 'Unnamed Plan',
            'server_id': server_id,
            'total_audits': len(audit_paths),
            'successful': success_count,
            'failed': failure_count,
            'duration_seconds': duration,
            'results': results,
            'executed_at': start_time.isoformat(),
            'completed_at': end_time.isoformat()
        }

    except Exception as e:
        logger.error(f"Audit plan execution failed: {e}")
        raise


@celery_app.task(name='tasks.audit_tasks.cleanup_old_results')
def cleanup_old_results(days=None, max_records=None, hypervisor_days=None, hypervisor_max_records=None):
    """
    Cleanup old execution results (older than specified days)

    Args:
          days: Delete results older than this many days.
              If not provided, reads from security settings.
          max_records: Maximum number of standard audit execution records to keep after age-based cleanup.
              If not provided, reads from security settings. 0 disables count-based pruning.
          hypervisor_days: Delete hypervisor execution results older than this many days.
              If not provided, reads from security settings.
          hypervisor_max_records: Maximum number of hypervisor execution records to keep after age-based cleanup.
              If not provided, reads from security settings. 0 disables count-based pruning.

    Returns:
        dict: Cleanup stats
    """
    # Get days from security settings if not provided
    if days is None or max_records is None or hypervisor_days is None or hypervisor_max_records is None:
        try:
            from security_settings import get_audit_execution_settings
            settings = get_audit_execution_settings()
            if days is None:
                days = settings.get('retention_days', 90)
            if max_records is None:
                max_records = settings.get('max_records', 100000)
            if hypervisor_days is None:
                hypervisor_days = settings.get('hypervisor_retention_days', days)
            if hypervisor_max_records is None:
                hypervisor_max_records = settings.get('hypervisor_max_records', max_records)
        except ImportError:
            if days is None:
                days = 90
            if max_records is None:
                max_records = 100000
            if hypervisor_days is None:
                hypervisor_days = days
            if hypervisor_max_records is None:
                hypervisor_max_records = max_records

    import os as _os

    from pathlib import Path as _Path
    try:
        log_dir = LOGS_DIR
    except NameError:
        log_dir = _Path('./logs')

    db = SessionLocal()

    try:
        execution_log_retention_days = int(_os.environ.get('RETENTION_EXECUTION_LOG_DAYS', '14'))
    except ValueError:
        execution_log_retention_days = 14

    try:
        max_execution_log_files = int(_os.environ.get('RETENTION_EXECUTION_LOG_MAX_FILES', '14'))
    except ValueError:
        max_execution_log_files = 14

    # Security settings (admin panel) override env vars if explicitly saved
    try:
        _ss_file = _Path(__file__).parent.parent / 'settings' / 'security_settings.json'
        if _ss_file.exists():
            import json as _json_at
            _raw_at = _json_at.loads(_ss_file.read_text(encoding='utf-8'))
            if 'execution_log_retention_days' in _raw_at:
                execution_log_retention_days = int(_raw_at['execution_log_retention_days'])
            if 'execution_log_max_files' in _raw_at:
                max_execution_log_files = int(_raw_at['execution_log_max_files'])
    except Exception as settings_error:
        logger.debug(
            "Unable to apply execution log retention overrides from security settings: %s",
            settings_error,
        )

    execution_log_retention_days = max(1, execution_log_retention_days)
    max_execution_log_files = max(0, max_execution_log_files)

    def _cleanup_execution_log_files(retention_days: int, max_files: int) -> dict:
        cutoff = datetime.utcnow() - timedelta(days=max(1, int(retention_days)))
        deleted_by_age = 0
        deleted_by_count = 0
        failed = 0
        tracked_logs = []

        for log_file in log_dir.glob('execution-*.log'):
            try:
                modified_at = datetime.utcfromtimestamp(log_file.stat().st_mtime)
                tracked_logs.append((log_file, modified_at))
            except OSError as log_error:
                failed += 1
                logger.warning(f"Skipping execution log metadata read for {log_file}: {log_error}")

        for log_file, modified_at in tracked_logs:
            if modified_at >= cutoff:
                continue

            try:
                log_file.unlink()
                deleted_by_age += 1
            except OSError as log_error:
                failed += 1
                logger.warning(f"Failed deleting old execution log {log_file}: {log_error}")

        retained_logs = []
        for log_file, modified_at in tracked_logs:
            if log_file.exists():
                retained_logs.append((log_file, modified_at))

        retained_logs.sort(key=lambda entry: entry[1], reverse=True)

        if max_files > 0 and len(retained_logs) > max_files:
            for log_file, _ in retained_logs[max_files:]:
                try:
                    log_file.unlink()
                    deleted_by_count += 1
                except OSError as log_error:
                    failed += 1
                    logger.warning(f"Failed deleting surplus execution log {log_file}: {log_error}")

        remaining = sum(1 for _ in log_dir.glob('execution-*.log'))

        return {
            'deleted_by_age': deleted_by_age,
            'deleted_by_count': deleted_by_count,
            'remaining': remaining,
            'max_files': max_files,
            'retention_days': retention_days,
            'failed': failed,
        }

    try:
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        hypervisor_cutoff_date = datetime.utcnow() - timedelta(days=hypervisor_days)

        def _prune_model(model, time_column, model_cutoff_date, model_max_records):
            deleted_by_age = db.query(model).filter(
                time_column < model_cutoff_date
            ).delete(synchronize_session=False)

            deleted_by_count = 0
            records_after_age_cleanup = db.query(model).count()

            if model_max_records and model_max_records > 0 and records_after_age_cleanup > model_max_records:
                overflow = records_after_age_cleanup - model_max_records
                oldest_ids = [
                    row[0]
                    for row in db.query(model.id)
                    .order_by(time_column.asc(), model.id.asc())
                    .limit(overflow)
                    .all()
                ]

                if oldest_ids:
                    deleted_by_count = db.query(model).filter(
                        model.id.in_(oldest_ids)
                    ).delete(synchronize_session=False)

            return {
                'deleted_by_age': deleted_by_age,
                'deleted_by_count': deleted_by_count,
                'remaining': db.query(model).count(),
            }

        audit_stats = _prune_model(AuditExecution, AuditExecution.executed_at, cutoff_date, max_records)
        hypervisor_stats = _prune_model(
            HypervisorAuditExecution,
            HypervisorAuditExecution.started_at,
            hypervisor_cutoff_date,
            hypervisor_max_records,
        )

        db.commit()

        execution_log_stats = _cleanup_execution_log_files(execution_log_retention_days, max_execution_log_files)

        total_deleted = (
            audit_stats['deleted_by_age']
            + audit_stats['deleted_by_count']
            + hypervisor_stats['deleted_by_age']
            + hypervisor_stats['deleted_by_count']
            + execution_log_stats['deleted_by_age']
            + execution_log_stats['deleted_by_count']
        )
        logger.info(
            f"Cleaned up {total_deleted} records "
            f"(audit: age={audit_stats['deleted_by_age']}, count={audit_stats['deleted_by_count']}; "
            f"hypervisor: age={hypervisor_stats['deleted_by_age']}, count={hypervisor_stats['deleted_by_count']}; "
            f"execution_logs: age={execution_log_stats['deleted_by_age']}, count={execution_log_stats['deleted_by_count']}, failed={execution_log_stats['failed']}; "
            f"audit_retention_days={days}, audit_max_records={max_records}, execution_log_retention_days={execution_log_retention_days}, execution_log_max_files={max_execution_log_files}, "
            f"hypervisor_retention_days={hypervisor_days}, hypervisor_max_records={hypervisor_max_records})"
        )

        return {
            'deleted_count': total_deleted,
            'deleted_by_age': (
                audit_stats['deleted_by_age']
                + hypervisor_stats['deleted_by_age']
                + execution_log_stats['deleted_by_age']
            ),
            'deleted_by_count': (
                audit_stats['deleted_by_count']
                + hypervisor_stats['deleted_by_count']
                + execution_log_stats['deleted_by_count']
            ),
            'audit_executions': audit_stats,
            'hypervisor_audit_executions': hypervisor_stats,
            'execution_logs': execution_log_stats,
            'cutoff_date': cutoff_date.isoformat(),
            'hypervisor_cutoff_date': hypervisor_cutoff_date.isoformat(),
            'days': days,
            'max_records': max_records,
            'execution_log_days': execution_log_retention_days,
            'execution_log_max_files': max_execution_log_files,
            'hypervisor_days': hypervisor_days,
            'hypervisor_max_records': hypervisor_max_records,
        }

    except Exception as e:
        logger.error(f"Cleanup failed: {e}")
        db.rollback()
        raise

    finally:
        db.close()


@celery_app.task(name='tasks.audit_tasks.get_task_status')
def get_task_status(task_id: str):
    """
    Get status of a Celery task

    Args:
        task_id: Celery task ID

    Returns:
        dict: Task status and metadata
    """
    task = celery_app.AsyncResult(task_id)

    return {
        'task_id': task_id,
        'state': task.state,
        'info': task.info,
        'ready': task.ready(),
        'successful': task.successful() if task.ready() else None,
        'failed': task.failed() if task.ready() else None
    }


__all__ = [
    'execute_audit',
    'execute_audit_plan',
    'cleanup_old_results',
    'get_task_status',
]
