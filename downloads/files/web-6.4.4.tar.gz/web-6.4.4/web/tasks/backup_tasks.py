#!/usr/bin/env python3
"""
Celery Tasks for Automated Database Backups

Provides scheduled backup tasks with:
- Automatic daily/weekly backups
- Retention policy enforcement
- Backup verification
- Email notifications on failure
- Health monitoring

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import logging
from datetime import datetime, timedelta
from celery import Task
from celery.schedules import crontab
from typing import Dict, Optional

logger = logging.getLogger(__name__)


def _backup_encryption_default() -> bool:
    """Resolve default backup encryption behavior from security settings."""
    try:
        from security_settings import get_security_setting
        return bool(get_security_setting('backup_encrypt', False))
    except Exception:
        return os.getenv('BACKUP_ENCRYPTION_ENABLED', 'false').lower() == 'true'


# Import Celery app (will be created in celery_config.py)
try:
    from celery_app import celery_app
except ImportError:
    # Fallback for standalone testing
    from celery import Celery
    celery_app = Celery('backup_tasks')


class BackupTask(Task):
    """
    Base task class for backup operations with error handling
    """
    autoretry_for = (Exception,)
    retry_kwargs = {'max_retries': 3, 'countdown': 300}  # Retry after 5 minutes
    retry_backoff = True

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        """Send notification on backup failure"""
        try:
            from error_notifier import get_error_notifier
            notifier = get_error_notifier()

            notifier.notify_task_failure(
                task_name=self.name,
                task_id=task_id,
                error=str(exc),
                retry_count=self.request.retries,
                context={'args': args, 'kwargs': kwargs}
            )
        except Exception as e:
            logger.error(f"Failed to send backup failure notification: {e}")


@celery_app.task(base=BackupTask, name='backup.create_scheduled_backup')
def create_scheduled_backup(
    backup_type: str = 'full',
    compress: bool = True,
    encrypt: Optional[bool] = None,
    notify_on_success: bool = False
) -> Dict:
    """
    Create a scheduled database backup

    Args:
        backup_type: 'full' or 'incremental'
        compress: Compress backup with gzip
        encrypt: Encrypt backup
        notify_on_success: Send notification on successful backup

    Returns:
        Dict with backup details
    """
    from backup_manager import BackupManager

    logger.info(f"Starting scheduled {backup_type} backup")

    try:
        manager = BackupManager()
        effective_encrypt = _backup_encryption_default() if encrypt is None else bool(encrypt)

        # Create backup
        backup_info = manager.create_backup(
            backup_type=backup_type,
            compress=compress,
            encrypt=effective_encrypt,
            include_metadata=True
        )

        # Log success
        logger.info(f"Scheduled backup completed: {backup_info['filename']}")
        logger.info(f"Size: {backup_info['size_bytes'] / (1024**2):.2f} MB")

        # Send success notification if requested
        if notify_on_success:
            try:
                from error_notifier import get_error_notifier
                notifier = get_error_notifier()

                notifier._send_email(
                    subject="Backup Completed Successfully",
                    body="""
Backup Details:
- File: {backup_info['filename']}
- Type: {backup_info['backup_type']}
- Size: {backup_info['size_bytes'] / (1024**2):.2f} MB
- Timestamp: {backup_info['timestamp']}
- Checksum: {backup_info['checksum']}

The backup has been stored securely and is ready for restore if needed.
                    """.strip()
                )
            except Exception as e:
                logger.warning(f"Failed to send success notification: {e}")

        return backup_info

    except Exception as e:
        logger.error(f"Scheduled backup failed: {e}", exc_info=True)
        raise


@celery_app.task(base=BackupTask, name='backup.cleanup_old_backups')
def cleanup_old_backups(
    retention_days: int = None,
    keep_count: int = None
) -> Dict:
    """
    Clean up old backups based on retention policy

    Args:
        retention_days: Keep backups newer than this many days (default: from settings)
        keep_count: Always keep at least this many recent backups (default: from settings)

    Returns:
        Dict with cleanup statistics
    """
    from backup_manager import BackupManager

    # Get retention settings: parameter > security_settings > env > defaults
    if retention_days is None:
        try:
            from security_settings import get_security_setting
            retention_days = get_security_setting('backup_retention_days')
        except ImportError:
            pass
    if retention_days is None:
        retention_days = int(os.getenv('BACKUP_RETENTION_DAYS', '30'))

    if keep_count is None:
        try:
            from security_settings import get_security_setting
            keep_count = get_security_setting('backup_keep_count')
        except ImportError:
            pass
    if keep_count is None:
        keep_count = int(os.getenv('BACKUP_KEEP_COUNT', '10'))

    logger.info(f"Starting backup cleanup (retention: {retention_days} days, keep: {keep_count})")

    try:
        manager = BackupManager()
        result = manager.cleanup_old_backups(
            retention_days=retention_days,
            keep_count=keep_count
        )

        logger.info(f"Cleanup complete: removed {result['removed']}, kept {result['kept']}")

        return result

    except Exception as e:
        logger.error(f"Backup cleanup failed: {e}", exc_info=True)
        raise


@celery_app.task(base=BackupTask, name='backup.verify_recent_backups')
def verify_recent_backups(limit: int = 5) -> Dict:
    """
    Verify integrity of recent backups

    Args:
        limit: Number of recent backups to verify

    Returns:
        Dict with verification results
    """
    from backup_manager import BackupManager

    logger.info(f"Starting verification of {limit} recent backups")

    try:
        manager = BackupManager()
        backups = manager.list_backups(limit=limit)

        results = {
            'total': len(backups),
            'valid': 0,
            'invalid': 0,
            'errors': []
        }

        for backup in backups:
            verification = manager.verify_backup(backup['filepath'])

            if verification['valid']:
                results['valid'] += 1
                logger.info(f"✓ Backup valid: {backup['filename']}")
            else:
                results['invalid'] += 1
                error_msg = f"✗ Backup invalid: {backup['filename']} - {verification.get('error', 'Unknown error')}"
                logger.error(error_msg)
                results['errors'].append(error_msg)

        # Send notification if any backups are invalid
        if results['invalid'] > 0:
            try:
                from error_notifier import get_error_notifier
                notifier = get_error_notifier()

                notifier.notify_task_failure(
                    task_name='backup.verify_recent_backups',
                    task_id='manual',
                    error=f"{results['invalid']} invalid backups found",
                    retry_count=0,
                    context={'invalid_backups': results['errors']}
                )
            except Exception as e:
                logger.warning(f"Failed to send verification failure notification: {e}")

        logger.info(f"Verification complete: {results['valid']}/{results['total']} valid")

        return results

    except Exception as e:
        logger.error(f"Backup verification failed: {e}", exc_info=True)
        raise


@celery_app.task(name='backup.health_check')
def backup_health_check() -> Dict:
    """
    Check backup system health

    Returns:
        Dict with health status
    """
    from backup_manager import BackupManager
    from pathlib import Path

    try:
        manager = BackupManager()

        health = {
            'status': 'healthy',
            'backup_dir_exists': manager.backup_dir.exists(),
            'backup_dir_writable': os.access(manager.backup_dir, os.W_OK),
            'recent_backups': 0,
            'total_size_mb': 0,
            'oldest_backup_age_days': None,
            'shared_data_backup': manager.get_shared_data_backup_status(),
            'issues': []
        }

        # Check backup directory
        if not health['backup_dir_exists']:
            health['status'] = 'unhealthy'
            health['issues'].append('Backup directory does not exist')
            return health

        if not health['backup_dir_writable']:
            health['status'] = 'unhealthy'
            health['issues'].append('Backup directory is not writable')

        # Check recent backups
        backups = manager.list_backups(limit=100)
        health['recent_backups'] = len(backups)

        if len(backups) == 0:
            health['status'] = 'warning'
            health['issues'].append('No backups found')

        # Calculate total size
        total_size = sum(b.get('size_bytes', 0) for b in backups)
        health['total_size_mb'] = round(total_size / (1024**2), 2)

        # Check oldest backup age
        if backups:
            oldest_backup = backups[-1]
            oldest_time = datetime.fromisoformat(oldest_backup.get('timestamp', datetime.utcnow().isoformat()))
            age_days = (datetime.utcnow() - oldest_time).days
            health['oldest_backup_age_days'] = age_days

            # Warn if no backups in last 2 days
            newest_backup = backups[0]
            newest_time = datetime.fromisoformat(newest_backup.get('timestamp', datetime.utcnow().isoformat()))
            hours_since_last = (datetime.utcnow() - newest_time).total_seconds() / 3600

            if hours_since_last > 48:
                health['status'] = 'warning'
                health['issues'].append(f'No backup in {hours_since_last:.1f} hours')

        # Check database tools availability
        if manager.is_postgresql:
            import shutil
            if not shutil.which('pg_dump'):
                health['status'] = 'warning'
                health['issues'].append('pg_dump not found (PostgreSQL backups unavailable)')
            if not shutil.which('psql'):
                health['status'] = 'warning'
                health['issues'].append('psql not found (PostgreSQL restores unavailable)')

        shared_data = health.get('shared_data_backup', {})
        if shared_data.get('enabled') and not shared_data.get('existing_paths'):
            health['status'] = 'warning'
            health['issues'].append('Shared data backup enabled but no configured shared paths are mounted')

        logger.info(f"Backup health check: {health['status']}")

        return health

    except Exception as e:
        logger.error(f"Backup health check failed: {e}", exc_info=True)
        return {
            'status': 'error',
            'error': str(e)
        }


# Celery Beat Schedule Configuration
# Add this to your celery configuration:
"""
CELERY_BEAT_SCHEDULE = {
    'daily-backup': {
        'task': 'backup.create_scheduled_backup',
        'schedule': crontab(hour=2, minute=0),  # 2 AM daily
        'kwargs': {
            'backup_type': 'full',
            'compress': True,
            'encrypt': False,
            'notify_on_success': False
        }
    },
    'weekly-encrypted-backup': {
        'task': 'backup.create_scheduled_backup',
        'schedule': crontab(day_of_week=0, hour=3, minute=0),  # Sunday 3 AM
        'kwargs': {
            'backup_type': 'full',
            'compress': True,
            'encrypt': True,
            'notify_on_success': True
        }
    },
    'cleanup-old-backups': {
        'task': 'backup.cleanup_old_backups',
        'schedule': crontab(hour=4, minute=0),  # 4 AM daily
        'kwargs': {}
    },
    'verify-backups': {
        'task': 'backup.verify_recent_backups',
        'schedule': crontab(hour=5, minute=0),  # 5 AM daily
        'kwargs': {'limit': 5}
    },
    'backup-health-check': {
        'task': 'backup.health_check',
        'schedule': crontab(minute='*/30'),  # Every 30 minutes
        'kwargs': {}
    }
}
"""


def configure_backup_schedule(celery_app_instance):
    """
    Configure Celery Beat schedule for automated backups

    Call this in your Celery app initialization:
        from tasks.backup_tasks import configure_backup_schedule
        configure_backup_schedule(celery_app)
    """
    celery_app_instance.conf.beat_schedule = {
        'daily-backup': {
            'task': 'backup.create_scheduled_backup',
            'schedule': crontab(hour=2, minute=0),  # 2 AM daily
            'kwargs': {
                'backup_type': 'full',
                'compress': True,
                'encrypt': _backup_encryption_default(),
                'notify_on_success': False
            }
        },
        'weekly-encrypted-backup': {
            'task': 'backup.create_scheduled_backup',
            'schedule': crontab(day_of_week=0, hour=3, minute=0),  # Sunday 3 AM
            'kwargs': {
                'backup_type': 'full',
                'compress': True,
                'encrypt': True,
                'notify_on_success': True
            }
        },
        'cleanup-old-backups': {
            'task': 'backup.cleanup_old_backups',
            'schedule': crontab(hour=4, minute=0),  # 4 AM daily
            'kwargs': {}
        },
        'verify-backups': {
            'task': 'backup.verify_recent_backups',
            'schedule': crontab(hour=5, minute=0),  # 5 AM daily
            'kwargs': {'limit': 5}
        },
        'backup-health-check': {
            'task': 'backup.health_check',
            'schedule': crontab(minute='*/30'),  # Every 30 minutes
            'kwargs': {}
        }
    }

    logger.info("Backup schedule configured: daily backups at 2 AM, weekly encrypted at 3 AM")


__all__ = [
    'create_scheduled_backup',
    'cleanup_old_backups',
    'verify_recent_backups',
    'backup_health_check',
    'configure_backup_schedule'
]
