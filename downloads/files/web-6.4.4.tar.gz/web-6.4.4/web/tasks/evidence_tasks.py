#!/usr/bin/env python3
"""
Celery Tasks for Evidence Export Retention

Provides scheduled cleanup of evidence export artifacts:
- Policy-driven daily retention enforcement (default: 30-day keep window)
- Dry-run mode available via security settings for audit visibility
- Integrates with the evidence registry for consistent state management

Author: Security Audit Toolkit Team
Date: May 4, 2026
"""

import logging
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from celery_app import celery_app

logger = logging.getLogger(__name__)

# Policy key names in security_settings
_RETENTION_ENABLED_KEY = 'evidence_retention_enabled'
_RETENTION_DAYS_KEY = 'evidence_retention_days'
_RETENTION_DEFAULT_DAYS = 30

# Throttle: track last successful run (in-process guard against rapid re-fires)
_last_run_at: datetime | None = None


def _get_retention_policy() -> tuple[bool, int]:
    """Return (enabled, days_to_keep) from security settings, with safe defaults."""
    try:
        from security_settings import get_security_setting
        enabled = bool(get_security_setting(_RETENTION_ENABLED_KEY, True))
        days = int(get_security_setting(_RETENTION_DAYS_KEY, _RETENTION_DEFAULT_DAYS) or _RETENTION_DEFAULT_DAYS)
    except Exception:
        enabled = True
        days = _RETENTION_DEFAULT_DAYS
    return enabled, max(1, days)


@celery_app.task(name='tasks.evidence_tasks.run_evidence_retention_cleanup', bind=True,
                 max_retries=2, default_retry_delay=300)
def run_evidence_retention_cleanup(self):
    """
    Enforce the evidence export retention policy.

    Reads `evidence_retention_enabled` and `evidence_retention_days` from
    security settings, then removes export ZIPs, manifests, and registry entries
    older than the configured window.

    Runs daily via Celery Beat.  A minimum 23-hour inter-run guard prevents
    accidental back-to-back executions if the beat schedule fires early.

    Returns a result dict with fields:
        enabled, days_to_keep, cutoff, candidates, deleted_paths, skipped_reason
    """
    global _last_run_at

    now = datetime.utcnow()

    # Inter-run guard: skip if last run was < 23 hours ago
    if _last_run_at is not None:
        elapsed = now - _last_run_at
        if elapsed < timedelta(hours=23):
            skipped_msg = (
                f"Skipped — last ran {elapsed.total_seconds() / 3600:.1f}h ago "
                f"(threshold 23h)"
            )
            logger.debug(f"[evidence_retention] {skipped_msg}")
            return {'enabled': True, 'skipped_reason': skipped_msg}

    enabled, days_to_keep = _get_retention_policy()

    if not enabled:
        logger.info("[evidence_retention] Retention cleanup disabled by policy.")
        return {'enabled': False, 'skipped_reason': 'disabled_by_policy'}

    cutoff = now - timedelta(days=days_to_keep)
    logger.info(
        f"[evidence_retention] Starting cleanup: keep={days_to_keep}d, "
        f"cutoff={cutoff.isoformat()}"
    )

    try:
        from api.evidence_routes import (
            _evidence_registry,
            _evidence_packages,
            _save_registry,
        )
    except ImportError as exc:
        logger.error(f"[evidence_retention] Failed to import evidence_routes: {exc}")
        raise self.retry(exc=exc)

    to_remove: list[str] = []
    for package_id, record in list(_evidence_registry.items()):
        exported_at_raw = record.get('exported_at')
        if not exported_at_raw:
            continue
        try:
            exported_at = datetime.fromisoformat(
                str(exported_at_raw).replace('Z', '+00:00').replace('+00:00', '')
            )
        except ValueError:
            continue
        if exported_at < cutoff:
            to_remove.append(package_id)

    deleted_paths: list[str] = []
    for package_id in to_remove:
        record = _evidence_registry.get(package_id, {})
        for key in ('zip_path', 'manifest_path'):
            file_path = record.get(key)
            if file_path and Path(file_path).exists():
                try:
                    Path(file_path).unlink(missing_ok=True)
                    deleted_paths.append(file_path)
                except OSError as e:
                    logger.warning(
                        f"[evidence_retention] Could not delete {file_path}: {e}"
                    )
        _evidence_registry.pop(package_id, None)
        _evidence_packages.pop(package_id, None)

    if to_remove:
        _save_registry()

    _last_run_at = now

    logger.info(
        f"[evidence_retention] Complete: removed {len(to_remove)} package(s), "
        f"deleted {len(deleted_paths)} file(s)."
    )

    return {
        'enabled': True,
        'days_to_keep': days_to_keep,
        'cutoff': cutoff.isoformat(),
        'candidates': len(to_remove),
        'deleted_paths': deleted_paths,
    }
