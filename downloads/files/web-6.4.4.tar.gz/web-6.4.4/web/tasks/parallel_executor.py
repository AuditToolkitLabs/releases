#!/usr/bin/env python3
"""
Parallel Audit Executor

Celery tasks for executing audits on multiple servers simultaneously:
- Batch audit execution with progress tracking
- Async SSH for 100+ concurrent connections
- Aggregated results and error handling
- Real-time progress updates via SSE

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import sys
import json
import asyncio
from datetime import datetime
from pathlib import Path
from typing import List, Dict
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from celery_app import audit_task, celery_app
from config import logger
from config import SessionLocal, ROOT_DIR
from models.database import Server, Audit, AuditExecution
from ssh_async import AsyncSSHManager, SSHResult
from sse import get_sse_manager
from execution_paths import LINUX_DEPLOY_PATH, get_deployed_command
from encryption import password_manager

try:
    from services_pkg.services.reporting_persistence_service import ReportingPersistenceService
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = True
except ImportError:
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = False


reporting_persistence_service = ReportingPersistenceService() if _REPORTING_PERSISTENCE_SERVICE_AVAILABLE else None


def _persist_reporting_audit_execution(db_session, execution):
    """Persist canonical reporting rows for a completed parallel audit execution when available."""
    if reporting_persistence_service is None:
        return None
    return reporting_persistence_service.persist_audit_execution(db_session, execution)


@contextmanager
def get_db_context():
    """
    Context manager for database sessions - prevents session leaks
    """
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


async def async_execute_on_servers(server_configs: List[Dict], command: str,
                                    timeout: int, max_concurrent: int) -> List:
    """
    Async helper to execute SSH commands on multiple servers

    This function runs in a dedicated thread with its own event loop
    to avoid blocking the Celery worker.
    """
    manager = AsyncSSHManager(max_concurrent=max_concurrent)
    try:
        results = await manager.execute_on_servers(server_configs, command, timeout)
        return results
    finally:
        await manager.cleanup()


@audit_task(name='tasks.parallel_executor.execute_parallel_audits')
def execute_parallel_audits(self, server_ids: List[int], audit_path: str,
                            options: Dict = None):
    """
    Execute audit on multiple servers in parallel

    Args:
        self: Celery task instance (bound)
        server_ids: List of server database IDs
        audit_path: Path to audit script
        options: Optional execution options (max_concurrent, timeout, etc.)

    Returns:
        dict: Aggregated execution results
    """
    db = SessionLocal()
    task_id = self.request.id
    start_time = datetime.utcnow()

    try:
        # Parse options
        if options is None:
            options = {}

        max_concurrent = options.get('max_concurrent', 50)
        timeout = options.get('timeout', 600)

        # Get SSE manager
        sse_manager = get_sse_manager()

        # Update task state
        self.update_state(
            state='STARTED',
            meta={
                'status': 'Initializing parallel execution',
                'progress': 0,
                'servers_total': len(server_ids)
            }
        )

        if sse_manager:
            sse_manager.publish_task_progress(task_id, 'Initializing...', 0)

        # Fetch servers from database
        servers = db.query(Server).filter(Server.id.in_(server_ids)).all()
        if not servers:
            raise ValueError("No servers found")

        logger.info(f"Starting parallel audit execution on {len(servers)} servers")

        # Get or create audit record
        audit = db.query(Audit).filter(Audit.file_path == audit_path).first()
        if not audit:
            audit = Audit(
                name=Path(audit_path).name,
                domain=Path(audit_path).parts[1] if len(Path(audit_path).parts) > 1 else 'unknown',
                category=Path(audit_path).parts[2] if len(Path(audit_path).parts) > 2 else 'unknown',
                file_path=audit_path,
                created_at=datetime.utcnow()
            )
            db.add(audit)
            db.commit()
            db.refresh(audit)

        # Prepare server configurations for async SSH
        server_configs = []
        for server in servers:
            decrypted_password = None
            if getattr(server, 'password', None):
                decrypted_password = password_manager.decrypt_password(server.password)

            server_configs.append({
                'id': server.id,
                'name': server.name,
                'hostname': server.hostname,
                'port': server.port,
                'username': server.username,
                'password': decrypted_password,
                'key_path': server.ssh_key_path,
                'execution_mode': getattr(server, 'execution_mode', 'stream') or 'stream'
            })

        # Determine execution mode:
        # 1. If stream_mode is explicitly set in options, use it for all servers
        # 2. Otherwise, check if all servers have the same execution_mode
        # 3. For mixed-mode fleets, use the majority mode (with warning)
        if 'stream_mode' in options:
            # Explicit override from API
            global_stream_mode = options['stream_mode']
            logger.info(f"Execution mode override from API: {'stream' if global_stream_mode else 'deployed'}")
        else:
            # Use per-server execution_mode settings
            stream_count = sum(1 for s in server_configs if s.get('execution_mode') == 'stream')
            deployed_count = len(server_configs) - stream_count

            if stream_count == len(server_configs):
                global_stream_mode = True
                logger.info("All servers configured for stream mode (agentless)")
            elif deployed_count == len(server_configs):
                global_stream_mode = False
                logger.info("All servers configured for deployed mode (local package)")
            else:
                # Mixed mode - use majority with warning
                global_stream_mode = stream_count > deployed_count
                logger.warning(
                    f"Mixed execution modes detected: {stream_count} stream, {deployed_count} deployed. "
                    f"Using {'stream' if global_stream_mode else 'deployed'} mode for all servers."
                )

        if global_stream_mode:
            # STREAM MODE: Read script content and send via SSH stdin
            # No deployment required - scripts run directly from central host
            script_path = ROOT_DIR / audit_path
            if not script_path.exists():
                raise FileNotFoundError(f"Audit script not found: {script_path}")

            with open(script_path, 'r', encoding='utf-8') as f:
                script_content = f.read()

            lib_dir = ROOT_DIR / 'lib'
            import re

            def _extract_lib_dependency(line: str) -> str | None:
                lib_match = re.search(r'lib/([A-Za-z0-9_.-]+\.sh)', line)
                if lib_match:
                    return lib_match.group(1)

                local_match = re.search(r'\$\(dirname "\$\{BASH_SOURCE\[0\]\}"\)/([A-Za-z0-9_.-]+\.sh)', line)
                if local_match:
                    return local_match.group(1)

                return None

            def _inline_lib(lib_name: str, seen: set[str]) -> str:
                if lib_name in seen:
                    return ""

                lib_path = lib_dir / lib_name
                if not lib_path.exists():
                    return ""

                seen.add(lib_name)

                with open(lib_path, 'r', encoding='utf-8') as lib_file:
                    lib_lines = lib_file.readlines()

                sections: List[str] = [f"\n# === Begin injected lib/{lib_name} ===\n"]

                for lib_line in lib_lines:
                    dep = _extract_lib_dependency(lib_line)
                    if dep and (lib_dir / dep).exists():
                        sections.append(_inline_lib(dep, seen))
                        continue

                    if lib_line.startswith('#!'):
                        continue

                    sections.append(lib_line)

                sections.append(f"\n# === End injected lib/{lib_name} ===\n")
                return ''.join(sections)

            required_libs = {'common.sh'}
            for script_line in script_content.splitlines():
                dep = _extract_lib_dependency(script_line)
                if dep and (lib_dir / dep).exists():
                    required_libs.add(dep)

            seen_libs: set[str] = set()
            ordered_required_libs = ['common.sh'] + sorted(lib for lib in required_libs if lib != 'common.sh')
            lib_bundle = ''.join(_inline_lib(lib_name, seen_libs) for lib_name in ordered_required_libs)

            stripped_script_lines = []
            for script_line in script_content.splitlines():
                dep = _extract_lib_dependency(script_line)
                if dep and (lib_dir / dep).exists():
                    continue
                stripped_script_lines.append(script_line)

            stripped_script = '\n'.join(stripped_script_lines)
            lines = stripped_script.split('\n', 1)
            if lines and lines[0].startswith('#!'):
                script_content = f"{lines[0]}\n{lib_bundle}\n{lines[1] if len(lines) > 1 else ''}"
            else:
                script_content = f"#!/usr/bin/env bash\n{lib_bundle}\n{stripped_script}"

            logger.info(f"Stream mode: Sending {len(script_content)} bytes to {len(servers)} servers")
        else:
            # DEPLOYED MODE: Expect scripts at standard install path on remote hosts
            # Linux: /opt/audit-toolkit, Windows: C:\Program Files\SecurityAuditToolkit
            command = get_deployed_command(audit_path, os_type="linux")

        # Update progress
        self.update_state(
            state='RUNNING',
            meta={
                'status': f'Executing on {len(servers)} servers',
                'progress': 10,
                'servers_total': len(servers),
                'servers_completed': 0
            }
        )

        if sse_manager:
            sse_manager.publish_task_progress(
                task_id,
                f'Executing on {len(servers)} servers...',
                10
            )

        # Execute in parallel using asyncio (in dedicated thread to avoid blocking Celery)
        def run_async_ssh():
            """Run async SSH operations in dedicated event loop"""
            if global_stream_mode:
                # Stream script content - NO DEPLOYMENT REQUIRED
                async def stream_execute():
                    manager = AsyncSSHManager(max_concurrent=max_concurrent)
                    try:
                        return await manager.execute_scripts_on_servers(
                            server_configs, script_content, timeout, interpreter="bash"
                        )
                    finally:
                        await manager.cleanup()
                return asyncio.run(stream_execute())
            else:
                # Execute deployed scripts
                return asyncio.run(
                    async_execute_on_servers(server_configs, command, timeout, max_concurrent)
                )

        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(run_async_ssh)
            ssh_results = future.result(timeout=timeout + 120)  # Extra buffer for overhead

        # Process results and store in database (BATCH COMMIT for performance)
        execution_ids = []
        results_by_server = {}
        executions_to_add = []

        for ssh_result in ssh_results:
            # Parse audit output
            output = ssh_result.stdout
            summary_data = parse_audit_output(output)

            # Determine status (align with audit EXIT_CODE semantics)
            # 0 = PASS, 1 = WARN, 2+ = FAIL
            if summary_data['failed'] > 0:
                status = 'failure'
            elif ssh_result.exit_code == 0:
                status = 'success'
            elif ssh_result.exit_code == 1:
                status = 'warning'
            else:
                status = 'failure'

            # Create execution record (defer commit)
            execution = AuditExecution(
                server_id=ssh_result.server_id,
                audit_id=audit.id,
                status=status,
                exit_code=ssh_result.exit_code,
                output=output if ssh_result.success else ssh_result.stderr,
                summary=json.dumps(summary_data),
                duration_seconds=ssh_result.duration_seconds,
                executed_by='celery:parallel',
                executed_at=start_time,
                completed_at=datetime.utcnow()
            )
            db.add(execution)
            executions_to_add.append((execution, ssh_result, status, summary_data))

        # Flush first so canonical reporting rows can be persisted in the same transaction.
        db.flush()

        for execution, ssh_result, status, summary_data in executions_to_add:
            _persist_reporting_audit_execution(db, execution)

        # Single batch commit for execution and reporting rows.
        db.commit()

        # Refresh all and build results
        for execution, ssh_result, status, summary_data in executions_to_add:
            db.refresh(execution)
            execution_ids.append(execution.id)
            results_by_server[ssh_result.server_name] = {
                'execution_id': execution.id,
                'status': status,
                'exit_code': ssh_result.exit_code,
                'summary': summary_data,
                'duration_seconds': ssh_result.duration_seconds,
                'error': ssh_result.error
            }

        # Calculate aggregated summary
        total_duration = (datetime.utcnow() - start_time).total_seconds()
        successful_servers = sum(1 for _, _, status, _ in executions_to_add if status in ('success', 'warning'))
        warning_servers = sum(1 for _, _, status, _ in executions_to_add if status == 'warning')
        failed_servers = sum(1 for _, _, status, _ in executions_to_add if status == 'failure')

        # Calculate average duration from results
        durations = [r.duration_seconds for r in ssh_results if r.duration_seconds]
        avg_duration = sum(durations) / len(durations) if durations else 0

        aggregated_summary = {
            'total_servers': len(servers),
            'successful_servers': successful_servers,
            'warning_servers': warning_servers,
            'failed_servers': failed_servers,
            'success_rate': (successful_servers / len(servers)) * 100,
            'total_duration_seconds': total_duration,
            'average_duration_seconds': avg_duration,
            'audit_name': audit.name,
            'audit_path': audit_path,
            'max_concurrent': max_concurrent
        }

        logger.info(f"Parallel execution complete: {successful_servers}/{len(servers)} successful")

        # Emit SSE completion event
        if sse_manager:
            sse_manager.publish_task_complete(
                task_id,
                'success' if failed_servers == 0 else 'partial',
                {
                    'execution_ids': execution_ids,
                    'summary': aggregated_summary,
                    'results_by_server': results_by_server
                }
            )

        return {
            'success': True,
            'task_id': task_id,
            'execution_ids': execution_ids,
            'summary': aggregated_summary,
            'results_by_server': results_by_server
        }

    except Exception as e:
        logger.error(f"Parallel execution failed: {e}")

        if sse_manager:
            sse_manager.publish_task_error(task_id, str(e))

        raise

    finally:
        db.close()


def parse_audit_output(output: str) -> Dict:
    """
    Parse audit output to extract summary statistics

    Args:
        output: Audit script stdout

    Returns:
        dict: Summary with passed, failed, warned, skipped counts
    """
    import re

    summary = {
        'total_checks': 0,
        'passed': 0,
        'failed': 0,
        'warned': 0,
        'skipped': 0
    }

    # Count markers
    summary['passed'] = len(re.findall(r'\[PASS\]', output))
    summary['failed'] = len(re.findall(r'\[FAIL\]', output))
    summary['warned'] = len(re.findall(r'\[WARN\]', output))
    summary['skipped'] = len(re.findall(r'\[SKIP\]', output))
    summary['total_checks'] = sum([
        summary['passed'],
        summary['failed'],
        summary['warned'],
        summary['skipped']
    ])

    return summary


@audit_task(name='tasks.parallel_executor.execute_audit_plan_parallel')
def execute_audit_plan_parallel(self, server_ids: List[int], audit_paths: List[str],
                                plan_name: str = None, options: Dict = None):
    """
    Execute multiple audits on multiple servers (matrix execution)

    Args:
        self: Celery task instance
        server_ids: List of server IDs
        audit_paths: List of audit paths
        plan_name: Optional plan name
        options: Execution options

    Returns:
        dict: Matrix execution results
    """
    task_id = self.request.id
    start_time = datetime.utcnow()

    logger.info(f"Starting matrix execution: {len(server_ids)} servers × {len(audit_paths)} audits")

    try:
        sse_manager = get_sse_manager()

        # Execute each audit in sequence (across all servers in parallel)
        all_results = []
        total_audits = len(audit_paths)

        for idx, audit_path in enumerate(audit_paths):
            progress = int((idx / total_audits) * 100)

            self.update_state(
                state='RUNNING',
                meta={
                    'status': f'Executing audit {idx + 1}/{total_audits}',
                    'progress': progress,
                    'current_audit': Path(audit_path).name
                }
            )

            if sse_manager:
                sse_manager.publish_task_progress(
                    task_id,
                    f'Executing {Path(audit_path).name} on {len(server_ids)} servers',
                    progress
                )

            # Execute this audit on all servers
            result = execute_parallel_audits.apply(
                args=(server_ids, audit_path),
                kwargs={'options': options}
            ).get()

            all_results.append(result)

        # Aggregate results
        total_executions = sum(r['summary']['total_servers'] for r in all_results)
        total_successful = sum(r['summary']['successful_servers'] for r in all_results)
        total_duration = (datetime.utcnow() - start_time).total_seconds()

        matrix_summary = {
            'total_servers': len(server_ids),
            'total_audits': len(audit_paths),
            'total_executions': total_executions,
            'successful_executions': total_successful,
            'failed_executions': total_executions - total_successful,
            'success_rate': (total_successful / total_executions) * 100 if total_executions > 0 else 0,
            'total_duration_seconds': total_duration,
            'plan_name': plan_name
        }

        logger.info(f"Matrix execution complete: {total_successful}/{total_executions} successful")

        if sse_manager:
            sse_manager.publish_task_complete(
                task_id,
                'success',
                {
                    'summary': matrix_summary,
                    'audit_results': all_results
                }
            )

        return {
            'success': True,
            'task_id': task_id,
            'summary': matrix_summary,
            'audit_results': all_results
        }

    except Exception as e:
        logger.error(f"Matrix execution failed: {e}")
        raise
