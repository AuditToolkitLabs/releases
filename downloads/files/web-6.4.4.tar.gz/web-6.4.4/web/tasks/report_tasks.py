#!/usr/bin/env python3
"""
Celery Tasks for PDF Report Generation

Async tasks for:
- Scheduled PDF report generation
- Report delivery via email
- Periodic report execution check

Author: Security Audit Toolkit Team
Date: February 11, 2026
"""

import sys
from datetime import datetime, timedelta
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from celery_app import celery_app
from config import logger
from config import SessionLocal
from models.scheduled_report import ScheduledReport
from models.database import Server


@celery_app.task(
    name='tasks.report_tasks.generate_scheduled_report',
    bind=True,
    max_retries=2,
    soft_time_limit=300,  # 5 minutes soft limit
    time_limit=360        # 6 minutes hard limit
)
def generate_scheduled_report(self, report_id: int):
    """
    Generate and deliver a scheduled PDF report

    This task:
    1. Fetches report configuration
    2. Gathers audit data for targeted servers
    3. Generates PDF with compliance mapping
    4. Sends email with PDF attachment
    5. Updates report status

    Args:
        report_id: ID of the ScheduledReport to generate

    Returns:
        dict: Generation result with delivery status
    """
    db = SessionLocal()

    try:
        # Get the scheduled report
        report = db.query(ScheduledReport).filter(ScheduledReport.id == report_id).first()

        if not report:
            logger.error(f"Scheduled report {report_id} not found")
            return {'success': False, 'error': 'Report not found'}

        logger.info(f"Starting scheduled report generation: {report.name} (ID: {report_id})")

        # Import required modules
        try:
            from reports.pdf_generator import PDFReportGenerator, is_pdf_available
            from reports.compliance_templates import ComplianceTemplates
            from reports.executive_summary import ExecutiveSummaryGenerator
            from notifications import notification_manager
        except ImportError as e:
            logger.error(f"Failed to import report modules: {e}")
            report.last_status = 'error'
            report.last_error = f"Import error: {e}"
            db.commit()
            raise

        if not is_pdf_available():
            error_msg = "PDF generation not available. WeasyPrint not installed."
            logger.error(error_msg)
            report.last_status = 'error'
            report.last_error = error_msg
            db.commit()
            return {'success': False, 'error': error_msg}

        # Gather servers based on targeting configuration
        server_query = db.query(Server).filter(Server.tags.contains('active'))

        if not report.include_all_servers:
            if report.server_ids:
                server_query = server_query.filter(Server.id.in_(report.server_ids))
            if report.server_tags:
                # Filter by any of the specified tags
                for tag in report.server_tags:
                    server_query = server_query.filter(Server.tags.contains(tag))

        servers = server_query.all()

        if not servers:
            logger.warning(f"No active servers found for report {report.name}")

        # Fetch audit data for each server
        report_data = _build_report_data(report, servers, db)

        # Generate compliance mapping if framework specified
        compliance_mapping = None
        recommendations = None

        if report.compliance_framework and report.compliance_framework != 'none':
            try:
                templates = ComplianceTemplates()
                compliance_mapping = templates.map_audit_results(
                    report.compliance_framework.upper().replace('-', '_'),
                    report_data
                )
            except Exception as e:
                logger.warning(f"Failed to generate compliance mapping: {e}")

        # Generate recommendations if enabled
        if report.include_recommendations:
            try:
                summary_gen = ExecutiveSummaryGenerator(
                    organization=report.organization
                )
                exec_summary = summary_gen.generate_summary(report_data)
                recommendations = exec_summary.get('recommendations', [])
            except Exception as e:
                logger.warning(f"Failed to generate recommendations: {e}")

        # Generate executive summary text if enabled
        executive_summary = None
        if report.include_executive_summary:
            try:
                summary_gen = ExecutiveSummaryGenerator(organization=report.organization)
                exec_data = summary_gen.generate_summary(report_data)
                executive_summary = exec_data.get('narrative', {}).get('overview', None)
            except Exception as e:
                logger.warning(f"Failed to generate executive summary: {e}")

        # Generate PDF
        generator = PDFReportGenerator()
        framework_name = None
        if report.compliance_framework and report.compliance_framework != 'none':
            framework_name = report.compliance_framework.upper().replace('-', ' ')

        pdf_data = generator.generate_pdf(
            report_data=report_data,
            compliance_framework=framework_name,
            compliance_mapping=compliance_mapping,
            recommendations=recommendations,
            organization=report.organization,
            classification=report.classification,
            executive_summary=executive_summary
        )

        logger.info(f"Generated PDF for report {report.name} ({len(pdf_data)} bytes)")

        # Send email with PDF attachment
        delivery_result = notification_manager.notify_scheduled_report(
            report_name=report.name,
            pdf_data=pdf_data,
            report_summary=report_data['summary'],
            email_recipients=report.get_email_list(),
            organization=report.organization,
            compliance_framework=framework_name,
            webhook_urls=report.get_webhook_list()
        )

        # Update report status
        report.last_run = datetime.utcnow()
        report.run_count = (report.run_count or 0) + 1
        report.next_run = report.calculate_next_run()

        if delivery_result.get('email_sent'):
            report.last_status = 'success'
            report.last_error = None
            logger.info(f"Report {report.name} delivered successfully to {len(report.get_email_list())} recipients")
        else:
            report.last_status = 'failure'
            report.last_error = delivery_result.get('error', 'Email delivery failed')
            logger.error(f"Report {report.name} delivery failed: {report.last_error}")

        db.commit()

        return {
            'success': True,
            'report_id': report_id,
            'report_name': report.name,
            'email_sent': delivery_result.get('email_sent', False),
            'webhooks_sent': delivery_result.get('webhooks_sent', 0),
            'pdf_size': len(pdf_data),
            'servers_included': len(servers)
        }

    except Exception as e:
        logger.error(f"Failed to generate scheduled report {report_id}: {e}")

        # Update report with error status
        try:
            report = db.query(ScheduledReport).filter(ScheduledReport.id == report_id).first()
            if report:
                report.last_status = 'error'
                report.last_error = str(e)
                report.last_run = datetime.utcnow()
                db.commit()
        except Exception as db_err:
            logger.debug(f"Failed to update report error status: {db_err}")

        # Retry if attempts remaining
        if self.request.retries < self.max_retries:
            raise self.retry(exc=e, countdown=60 * (self.request.retries + 1))

        return {'success': False, 'error': str(e)}

    finally:
        db.close()


@celery_app.task(name='tasks.report_tasks.run_scheduled_reports')
def run_scheduled_reports():
    """
    Periodic task to check and execute scheduled reports due for generation

    This task is called by Celery Beat every minute to check which scheduled
    reports are due and queue them for generation.

    Returns:
        dict: Summary of queued reports
    """
    db = SessionLocal()
    results = {'total_due': 0, 'queued': 0, 'errors': []}

    try:
        now = datetime.utcnow()

        # Find all active reports that are due
        due_reports = db.query(ScheduledReport).filter(
            ScheduledReport.is_active.is_(True),
            ScheduledReport.next_run <= now
        ).all()

        results['total_due'] = len(due_reports)

        if due_reports:
            logger.info(f"Found {len(due_reports)} scheduled reports due for generation")

        for report in due_reports:
            try:
                # Queue the report generation task
                generate_scheduled_report.delay(report.id)
                results['queued'] += 1
                logger.info(f"Queued scheduled report: {report.name} (ID: {report.id})")

                # Update next_run to prevent re-queueing
                report.next_run = report.calculate_next_run()
                db.commit()

            except Exception as e:
                logger.error(f"Failed to queue report {report.id}: {e}")
                results['errors'].append({
                    'report_id': report.id,
                    'report_name': report.name,
                    'error': str(e)
                })

        return results

    except Exception as e:
        logger.error(f"Error running scheduled reports check: {e}")
        raise

    finally:
        db.close()


@celery_app.task(name='tasks.report_tasks.generate_report')
def generate_report(*args, **kwargs):
    """Backward-compatible report task placeholder for legacy workflow chaining."""
    return {
        'success': True,
        'status': 'queued',
        'task': 'generate_report',
        'args': list(args),
        'kwargs': kwargs,
    }


@celery_app.task(name='tasks.report_tasks.generate_batch_report')
def generate_batch_report(*args, **kwargs):
    """Backward-compatible batch report task placeholder for legacy workflow chaining."""
    return {
        'success': True,
        'status': 'queued',
        'task': 'generate_batch_report',
        'args': list(args),
        'kwargs': kwargs,
    }


def _build_report_data(report: ScheduledReport, servers: list, db) -> dict:
    """
    Build the report data structure from servers and their audit results

    Args:
        report: ScheduledReport configuration
        servers: List of Server objects to include
        db: Database session

    Returns:
        dict: Report data structure for PDF generator
    """
    from models.database import AuditExecution

    report_data = {
        'title': report.name,
        'subtitle': 'Scheduled Security Audit Report',
        'summary': {
            'total_servers': len(servers),
            'total_checks': 0,
            'total_pass': 0,  # nosec B105
            'total_warn': 0,
            'total_fail': 0,
            'total_skip': 0,
            'compliance_percentage': 0
        },
        'servers': []
    }

    total_checks = 0
    total_pass = 0
    total_warn = 0
    total_fail = 0
    total_skip = 0

    for server in servers:
        # Get the most recent successful audit execution for this server
        latest_execution = db.query(AuditExecution).filter(
            AuditExecution.server_id == server.id,
            AuditExecution.status == 'completed'
        ).order_by(AuditExecution.completed_at.desc()).first()

        server_data = {
            'name': server.name,
            'host': server.hostname,
            'status': 'success' if latest_execution else 'no_data',
            'metrics': {
                'pass': 0,  # nosec B105
                'warn': 0,
                'fail': 0,
                'skip': 0,
                'total': 0
            },
            'pass_percentage': 0,  # nosec B105
        }

        if latest_execution and latest_execution.result:
            try:
                result = latest_execution.result
                if isinstance(result, str):
                    import json
                    result = json.loads(result)

                metrics = result.get('metrics', {})
                server_data['metrics'] = {
                    'pass': metrics.get('pass', 0),
                    'warn': metrics.get('warn', 0),
                    'fail': metrics.get('fail', 0),
                    'skip': metrics.get('skip', 0),
                    'total': metrics.get('total', 0)
                }

                total = server_data['metrics']['total'] or 1
                server_data['pass_percentage'] = round(
                    server_data['metrics']['pass'] / total * 100, 1
                )

                # Aggregate totals
                total_checks += server_data['metrics']['total']
                total_pass += server_data['metrics']['pass']
                total_warn += server_data['metrics']['warn']
                total_fail += server_data['metrics']['fail']
                total_skip += server_data['metrics']['skip']

            except Exception as e:
                logger.warning(f"Failed to parse execution result for server {server.name}: {e}")
                server_data['status'] = 'error'
                server_data['error'] = str(e)

        report_data['servers'].append(server_data)

    # Calculate overall summary
    report_data['summary']['total_checks'] = total_checks
    report_data['summary']['total_pass'] = total_pass
    report_data['summary']['total_warn'] = total_warn
    report_data['summary']['total_fail'] = total_fail
    report_data['summary']['total_skip'] = total_skip

    if total_checks > 0:
        report_data['summary']['compliance_percentage'] = round(
            total_pass / total_checks * 100, 1
        )

    return report_data
