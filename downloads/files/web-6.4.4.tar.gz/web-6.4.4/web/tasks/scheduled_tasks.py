#!/usr/bin/env python3
"""
Celery Scheduled Tasks

Periodic tasks that run on a schedule via Celery Beat:
- Health checks for all servers
- Scheduled audit execution (defined in ScheduledAudit table)
- System maintenance tasks

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from pathlib import Path
from sqlalchemy import text

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from celery_app import celery_app
from config import logger
from config import SessionLocal, SSH_DIR
from models.database import Server
from models.schedule import ScheduledAudit
from tasks.audit_tasks import execute_audit, cleanup_old_results
from ssh_manager import SSHManager
from encryption import ssh_host_key_manager, password_manager

try:
    from models.maintenance_window import is_in_maintenance_window, ScheduleExecutionLog
    MAINTENANCE_WINDOW_AVAILABLE = True
except ImportError:
    is_in_maintenance_window = None
    ScheduleExecutionLog = None
    MAINTENANCE_WINDOW_AVAILABLE = False

# Initialize shared SSH manager for health checks
_ssh_manager = None

# HIGH-06 fix: Parallel health check settings
HEALTH_CHECK_MAX_WORKERS = 20  # Concurrent health checks
HEALTH_CHECK_TIMEOUT = 15  # Per-server timeout
_POLICY_LAST_RUN_AT = {}


def _policy_schedule_state(task_key: str, enabled_key: str, interval_key: str, default_interval_minutes: int):
    """Evaluate whether a policy-controlled scheduled task should run now."""
    now = datetime.utcnow()

    try:
        from security_settings import get_security_setting
        enabled = bool(get_security_setting(enabled_key, True))
        interval_minutes = int(get_security_setting(interval_key, default_interval_minutes) or default_interval_minutes)
    except Exception:
        enabled = True
        interval_minutes = default_interval_minutes

    interval_minutes = max(5, interval_minutes)

    state = {
        'enabled': enabled,
        'interval_minutes': interval_minutes,
        'last_run_at': None,
        'next_eligible_at': None,
    }

    last_run_at = _POLICY_LAST_RUN_AT.get(task_key)
    if last_run_at is not None:
        state['last_run_at'] = last_run_at.isoformat()
        state['next_eligible_at'] = (last_run_at + timedelta(minutes=interval_minutes)).isoformat()

    if not enabled:
        state['reason'] = 'disabled_by_policy'
        return False, state

    if last_run_at is not None:
        elapsed = now - last_run_at
        if elapsed < timedelta(minutes=interval_minutes):
            state['reason'] = 'interval_not_elapsed'
            state['remaining_seconds'] = int((timedelta(minutes=interval_minutes) - elapsed).total_seconds())
            return False, state

    _POLICY_LAST_RUN_AT[task_key] = now
    state['last_run_at'] = now.isoformat()
    state['next_eligible_at'] = (now + timedelta(minutes=interval_minutes)).isoformat()
    state['reason'] = 'eligible'
    return True, state

def get_ssh_manager():
    """Get or create shared SSH manager instance"""
    global _ssh_manager
    if _ssh_manager is None:
        _ssh_manager = SSHManager(
            ssh_dir=SSH_DIR,
            ssh_host_key_manager=ssh_host_key_manager,
            password_manager=password_manager
        )
    return _ssh_manager


@celery_app.task(name='tasks.scheduled_tasks.health_check_all_servers')
def health_check_all_servers():
    """
    Periodic health check for all servers

    Tests SSH connectivity and updates server status.
    Runs every 5 minutes (configured in celery_app beat_schedule).

    HIGH-06 fix: Uses ThreadPoolExecutor for parallel health checks.

    Returns:
        dict: Health check results
    """
    db = SessionLocal()
    results = {'total': 0, 'online': 0, 'offline': 0, 'errors': []}

    def check_single_server(server_data):
        """Check a single server's health (runs in thread pool)"""
        server_id, server_name, server_config = server_data
        try:
            ssh_mgr = get_ssh_manager()
            is_connected, error_message = ssh_mgr.test_connection(server_config, timeout=HEALTH_CHECK_TIMEOUT)
            return {
                'server_id': server_id,
                'server_name': server_name,
                'online': is_connected,
                'error': error_message if not is_connected else None
            }
        except Exception as e:
            return {
                'server_id': server_id,
                'server_name': server_name,
                'online': False,
                'error': str(e)
            }

    try:
        servers = db.query(Server).filter(Server.tags.contains('active')).all()
        results['total'] = len(servers)

        logger.info(f"Starting parallel health check for {len(servers)} servers")

        # Prepare server data for parallel execution
        server_data_list = []
        for server in servers:
            server_config = {
                'name': server.name,
                'host': server.hostname,
                'port': server.port,
                'user': server.username,
                'password': server.password,
                'key_path': server.ssh_key_path
            }
            server_data_list.append((server.id, server.name, server_config))

        # Build mapping for status updates
        server_map = {s.id: s for s in servers}

        # HIGH-06 fix: Run health checks in parallel
        with ThreadPoolExecutor(max_workers=HEALTH_CHECK_MAX_WORKERS) as executor:
            futures = {executor.submit(check_single_server, data): data for data in server_data_list}

            for future in as_completed(futures):
                try:
                    check_result = future.result(timeout=HEALTH_CHECK_TIMEOUT + 5)
                    server_id = check_result['server_id']
                    server = server_map.get(server_id)

                    if server is None:
                        continue

                    if check_result['online']:
                        results['online'] += 1
                        server.tags = server.tags.replace('offline', '').strip()
                        if 'online' not in server.tags:
                            server.tags = f"{server.tags} online".strip()
                        logger.debug(f"Server {check_result['server_name']} is online")
                    else:
                        results['offline'] += 1
                        server.tags = server.tags.replace('online', '').strip()
                        if 'offline' not in server.tags:
                            server.tags = f"{server.tags} offline".strip()
                        results['errors'].append({
                            'server_id': server_id,
                            'server_name': check_result['server_name'],
                            'error': check_result['error']
                        })
                        logger.warning(f"Server {check_result['server_name']} is offline: {check_result['error']}")

                except Exception as e:
                    data = futures[future]
                    results['offline'] += 1
                    results['errors'].append({
                        'server_id': data[0],
                        'server_name': data[1],
                        'error': str(e)
                    })
                    logger.error(f"Health check failed for {data[1]}: {e}")

        # Batch commit all status updates
        db.commit()

        logger.info(f"Health check complete: {results['online']}/{results['total']} servers online")
        return results

    except Exception as e:
        logger.error(f"Health check task failed: {e}")
        raise

    finally:
        db.close()


@celery_app.task(name='tasks.scheduled_tasks.run_scheduled_audits')
def run_scheduled_audits():
    """
    Execute scheduled audits based on ScheduledAudit table

    Uses croniter for proper cron expression parsing and sends notifications.
    Respects maintenance windows - skips audits if server is in maintenance.

    Returns:
        dict: Scheduled audit execution results
    """
    db = SessionLocal()
    results = {'total': 0, 'executed': 0, 'skipped': 0, 'maintenance_blocked': 0, 'errors': []}

    try:
        now = datetime.utcnow()
        # ScheduledAudit already imported at module level
        from notifications import notification_manager

        maintenance_enabled = MAINTENANCE_WINDOW_AVAILABLE
        if not maintenance_enabled:
            logger.warning("Maintenance window model not available, bypassing window checks")

        # Get all active scheduled audits that are due
        scheduled_audits = db.query(ScheduledAudit).filter(
            ScheduledAudit.is_active.is_(True),
            ScheduledAudit.next_run <= now
        ).all()

        results['total'] = len(scheduled_audits)
        logger.info(f"Found {len(scheduled_audits)} scheduled audits to run")

        for scheduled in scheduled_audits:
            try:
                # Check if server and audit still exist
                if not scheduled.server or not scheduled.audit:
                    logger.warning(f"Scheduled audit {scheduled.id} references missing server or audit")
                    scheduled.is_active = False
                    db.commit()
                    results['skipped'] += 1
                    continue

                # Check maintenance window
                if maintenance_enabled:
                    in_window, window_name, window_id = is_in_maintenance_window(scheduled.server_id)
                    if in_window:
                        logger.info(f"Skipping {scheduled.name}: server in maintenance window '{window_name}' (ID: {window_id})")

                        # Log the skip with window reference
                        log_entry = ScheduleExecutionLog(
                            schedule_id=scheduled.id,
                            scheduled_time=scheduled.next_run,
                            status='skipped',
                            skip_reason=f'maintenance_window: {window_name}',
                            maintenance_window_id=window_id
                        )
                        db.add(log_entry)

                        # Calculate next run time
                        from croniter import croniter
                        cron = croniter(scheduled.cron_schedule, now)
                        scheduled.next_run = cron.get_next(datetime)
                        scheduled.last_status = 'skipped'
                        db.commit()

                        results['maintenance_blocked'] += 1
                        results['skipped'] += 1
                        continue

                # Execute audit asynchronously
                logger.info(f"Executing scheduled audit: {scheduled.audit.name} on {scheduled.server.name}")
                task = execute_audit.delay(
                    server_id=scheduled.server_id,
                    audit_path=scheduled.audit.file_path,
                    options={
                        'timeout': 600,
                        'schedule_id': scheduled.id,
                        'schedule_name': scheduled.name
                    }
                )

                # Update last_run
                scheduled.last_run = now

                # Calculate next run using croniter
                try:
                    from croniter import croniter
                    cron = croniter(scheduled.cron_schedule, now)
                    scheduled.next_run = cron.get_next(datetime)
                except Exception as e:
                    logger.error(f"Failed to calculate next run for schedule {scheduled.id}: {e}")
                    # Fallback: disable schedule if cron is invalid
                    scheduled.is_active = False

                scheduled.last_status = 'running'
                db.commit()
                results['executed'] += 1

                # Note: Notification will be sent when the audit task completes
                # (handled in the audit task itself using schedule_id from options)

            except Exception as e:
                logger.error(f"Failed to execute scheduled audit {scheduled.id}: {e}")
                scheduled.last_status = 'error'
                db.commit()
                results['errors'].append({
                    'scheduled_id': scheduled.id,
                    'server_name': scheduled.server.name if scheduled.server else 'Unknown',
                    'audit_name': scheduled.audit.name if scheduled.audit else 'Unknown',
                    'error': str(e)
                })

        logger.info(f"Scheduled audits complete: {results['executed']}/{results['total']} executed")
        return results

    except Exception as e:
        logger.error(f"Scheduled audits task failed: {e}")
        raise

    finally:
        db.close()


@celery_app.task(name='tasks.scheduled_tasks.cleanup_old_executions')
def cleanup_old_executions():
    """
    Wrapper for cleanup task that runs on schedule

    Runs daily at 2 AM (configured in celery_app beat_schedule).
    Uses security settings for retention days and max record count.

    Returns:
        dict: Cleanup results
    """
    should_run, schedule_state = _policy_schedule_state(
        task_key='cleanup_old_executions',
        enabled_key='cleanup_old_executions_enabled',
        interval_key='cleanup_old_executions_interval_minutes',
        default_interval_minutes=1440,
    )
    if not should_run:
        logger.info("Skipping cleanup_old_executions: %s", schedule_state.get('reason'))
        return {
            'status': 'skipped',
            **schedule_state,
            'deleted_count': 0,
        }

    logger.info("Starting scheduled cleanup of old execution records")
    result = cleanup_old_results()
    result['status'] = 'completed'
    result.update(schedule_state)
    logger.info(f"Cleanup complete: {result['deleted_count']} records deleted")
    return result


@celery_app.task(name='tasks.scheduled_tasks.cleanup_analytics_history')
def cleanup_analytics_history():
    """Cleanup analytics history tables to prevent unbounded growth."""
    should_run, schedule_state = _policy_schedule_state(
        task_key='cleanup_analytics_history',
        enabled_key='cleanup_analytics_history_enabled',
        interval_key='cleanup_analytics_history_interval_minutes',
        default_interval_minutes=1440,
    )
    if not should_run:
        logger.info("Skipping cleanup_analytics_history: %s", schedule_state.get('reason'))
        return {
            'status': 'skipped',
            **schedule_state,
            'deleted_count': 0,
            'deleted_history_summaries': 0,
            'deleted_compliance_history': 0,
        }

    db = SessionLocal()

    try:
        try:
            from security_settings import get_security_setting
            summary_days = int(get_security_setting('history_summary_retention_days', 365))
            compliance_days = int(get_security_setting('compliance_history_retention_days', 365))
        except Exception:
            summary_days = 365
            compliance_days = 365

        summary_days = max(30, summary_days)
        compliance_days = max(30, compliance_days)

        from models.audit_history import AuditHistorySummary, ServerComplianceHistory

        summary_cutoff = datetime.utcnow() - timedelta(days=summary_days)
        compliance_cutoff = datetime.utcnow() - timedelta(days=compliance_days)

        deleted_summaries = db.query(AuditHistorySummary).filter(
            AuditHistorySummary.date < summary_cutoff
        ).delete(synchronize_session=False)

        deleted_compliance = db.query(ServerComplianceHistory).filter(
            ServerComplianceHistory.date < compliance_cutoff
        ).delete(synchronize_session=False)

        db.commit()

        result = {
            'status': 'completed',
            **schedule_state,
            'deleted_count': int(deleted_summaries + deleted_compliance),
            'deleted_history_summaries': int(deleted_summaries),
            'deleted_compliance_history': int(deleted_compliance),
            'history_summary_retention_days': summary_days,
            'compliance_history_retention_days': compliance_days,
        }
        logger.info(
            "Analytics history cleanup complete: summaries=%s, compliance=%s",
            deleted_summaries,
            deleted_compliance,
        )
        return result
    except Exception as e:
        logger.error(f"Analytics history cleanup failed: {e}")
        db.rollback()
        raise
    finally:
        db.close()


@celery_app.task(name='tasks.scheduled_tasks.run_postgresql_maintenance')
def run_postgresql_maintenance():
    """Run PostgreSQL maintenance (VACUUM ANALYZE) and emit size-based alerts."""
    db = SessionLocal()
    result = {
        'status': 'skipped',
        'reason': None,
        'vacuum_analyze_ran': False,
        'database_size_mb': None,
        'largest_tables': [],
        'alerts': [],
    }

    try:
        should_run, schedule_state = _policy_schedule_state(
            task_key='run_postgresql_maintenance',
            enabled_key='postgres_maintenance_enabled',
            interval_key='postgres_maintenance_interval_minutes',
            default_interval_minutes=360,
        )
        if not should_run:
            result['reason'] = schedule_state.get('reason')
            result.update(schedule_state)
            return result

        bind = db.get_bind()
        if bind is None:
            result['reason'] = 'no_database_bind'
            result.update(schedule_state)
            return result

        if str(bind.dialect.name or '').lower() != 'postgresql':
            result['reason'] = 'not_postgresql'
            result.update(schedule_state)
            return result

        try:
            from security_settings import get_security_setting
            vacuum_enabled = bool(get_security_setting('postgres_maintenance_vacuum_analyze_enabled', True))
            db_warn_mb = int(get_security_setting('postgres_database_size_warn_mb', 10240))
            db_critical_mb = int(get_security_setting('postgres_database_size_critical_mb', 20480))
            table_warn_mb = int(get_security_setting('postgres_table_size_warn_mb', 2048))
        except Exception:
            vacuum_enabled = True
            db_warn_mb = 10240
            db_critical_mb = 20480
            table_warn_mb = 2048

        if vacuum_enabled:
            target_tables = (
                'audit_executions',
                'hypervisor_audit_executions',
                'audit_history_summaries',
                'server_compliance_history',
            )
            with bind.connect().execution_options(isolation_level='AUTOCOMMIT') as conn:
                for table in target_tables:
                    conn.execute(text(f'VACUUM (ANALYZE) {table}'))
            result['vacuum_analyze_ran'] = True

        size_row = db.execute(text('SELECT pg_database_size(current_database())::bigint')).fetchone()
        db_size_bytes = int(size_row[0] or 0) if size_row is not None else 0
        db_size_mb = round(db_size_bytes / (1024 * 1024), 2)
        result['database_size_mb'] = db_size_mb

        largest_rows = db.execute(text("""
            SELECT
                c.relname AS table_name,
                pg_total_relation_size(c.oid)::bigint AS size_bytes
            FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE c.relkind = 'r'
              AND n.nspname NOT IN ('pg_catalog', 'information_schema')
            ORDER BY pg_total_relation_size(c.oid) DESC
            LIMIT 10
        """)).fetchall()

        largest_tables = []
        for row in largest_rows:
            table_name = str(row[0])
            size_mb = round(int(row[1] or 0) / (1024 * 1024), 2)
            largest_tables.append({'table_name': table_name, 'size_mb': size_mb})

            if size_mb >= table_warn_mb:
                alert = f"PostgreSQL table size warning: {table_name}={size_mb}MB (threshold={table_warn_mb}MB)"
                result['alerts'].append(alert)
                logger.warning(alert)

        result['largest_tables'] = largest_tables

        if db_size_mb >= db_critical_mb:
            alert = f"PostgreSQL database size CRITICAL: {db_size_mb}MB (critical={db_critical_mb}MB)"
            result['alerts'].append(alert)
            logger.error(alert)
        elif db_size_mb >= db_warn_mb:
            alert = f"PostgreSQL database size warning: {db_size_mb}MB (warning={db_warn_mb}MB)"
            result['alerts'].append(alert)
            logger.warning(alert)

        result['status'] = 'completed'
        result.update(schedule_state)
        return result
    except Exception as e:
        logger.error(f"PostgreSQL maintenance task failed: {e}")
        result['status'] = 'error'
        result['reason'] = str(e)
        return result
    finally:
        db.close()


@celery_app.task(name='tasks.scheduled_tasks.update_audit_metadata')
def update_audit_metadata():
    """
    Update audit metadata cache from filesystem

    Scans audits directory and updates Audit table with:
    - Description (from comments)
    - Estimated duration
    - Last file modification time

    Runs daily at 3 AM.

    Returns:
        dict: Update statistics
    """
    from pathlib import Path
    import re

    db = SessionLocal()
    results = {'total': 0, 'updated': 0, 'created': 0, 'errors': []}

    try:
        from config import ROOT_DIR
        audits_dir = ROOT_DIR / 'audits'

        # Scan all .sh files recursively
        for audit_file in audits_dir.rglob('*.sh'):
            # Skip _lib directory
            if '_lib' in audit_file.parts:
                continue

            results['total'] += 1

            try:
                # Get relative path
                rel_path = audit_file.relative_to(ROOT_DIR)

                # Read file content for metadata
                with open(audit_file, 'r') as f:
                    content = f.read()

                # Extract description from comments
                desc_match = re.search(r'#\s*Description:\s*(.+)', content)
                description = desc_match.group(1).strip() if desc_match else None

                # Get file modification time
                mtime = datetime.fromtimestamp(audit_file.stat().st_mtime)

                # Find or create audit record
                from models.database import Audit
                audit = db.query(Audit).filter(Audit.file_path == str(rel_path)).first()

                if audit:
                    # Update existing
                    if description:
                        audit.description = description
                    audit.last_modified_at = mtime
                    results['updated'] += 1
                else:
                    # Create new
                    audit = Audit(
                        name=audit_file.name,
                        domain=rel_path.parts[1] if len(rel_path.parts) > 1 else 'unknown',
                        category=rel_path.parts[2] if len(rel_path.parts) > 2 else 'unknown',
                        file_path=str(rel_path),
                        description=description,
                        last_modified_at=mtime,
                        created_at=datetime.utcnow()
                    )
                    db.add(audit)
                    results['created'] += 1

                db.commit()

            except Exception as e:
                logger.error(f"Failed to update metadata for {audit_file}: {e}")
                results['errors'].append({
                    'file': str(audit_file),
                    'error': str(e)
                })

        logger.info(f"Metadata update complete: {results['updated']} updated, {results['created']} created")
        return results

    except Exception as e:
        logger.error(f"Metadata update task failed: {e}")
        raise

    finally:
        db.close()


@celery_app.task(name='tasks.scheduled_tasks.check_maintenance_window_events')
def check_maintenance_window_events():
    """
    Check for maintenance window start/end events and send notifications.

    This task runs periodically (every 5 minutes) to detect:
    - Windows that just started (within last 5 minutes)
    - Windows that just ended (within last 5 minutes)

    Sends email/webhook notifications to configured admins.
    """
    from models.maintenance_window import MaintenanceWindow, ScheduleExecutionLog
    from notifications import notification_manager
    import os

    db = SessionLocal()
    results = {
        'windows_started': 0,
        'windows_ended': 0,
        'notifications_sent': 0
    }

    try:
        now = datetime.utcnow()
        check_window = timedelta(minutes=6)  # Check past 6 minutes

        # Get admin notification settings from environment
        admin_emails = os.getenv('MAINTENANCE_NOTIFY_EMAILS', '').split(',')
        admin_emails = [e.strip() for e in admin_emails if e.strip()]

        webhook_urls = os.getenv('MAINTENANCE_NOTIFY_WEBHOOKS', '').split(',')
        webhook_urls = [w.strip() for w in webhook_urls if w.strip()]

        if not admin_emails and not webhook_urls:
            logger.debug("No notification recipients configured for maintenance windows")
            return results

        # Check for one-time windows that just started
        started_windows = db.query(MaintenanceWindow).filter(
            MaintenanceWindow.is_active.is_(True),
            MaintenanceWindow.window_type == 'one_time',
            MaintenanceWindow.start_time >= now - check_window,
            MaintenanceWindow.start_time <= now
        ).all()

        for window in started_windows:
            # Only notify once - check if we already logged this event
            server_scope = 'All Servers' if not window.server_id else f'Server #{window.server_id}'

            logger.info(f"Maintenance window started: {window.name}")

            result = notification_manager.notify_maintenance_window_start(
                window_name=window.name,
                window_type=window.window_type,
                server_scope=server_scope,
                start_time=window.start_time,
                end_time=window.end_time,
                reason=window.reason,
                email_recipients=admin_emails,
                webhook_urls=webhook_urls
            )

            results['windows_started'] += 1
            if result.get('email_sent') or result.get('webhooks_sent', 0) > 0:
                results['notifications_sent'] += 1

        # Check for one-time windows that just ended
        ended_windows = db.query(MaintenanceWindow).filter(
            MaintenanceWindow.window_type == 'one_time',
            MaintenanceWindow.end_time >= now - check_window,
            MaintenanceWindow.end_time <= now
        ).all()

        for window in ended_windows:
            server_scope = 'All Servers' if not window.server_id else f'Server #{window.server_id}'

            # Count skipped audits during this window
            skipped_count = db.query(ScheduleExecutionLog).filter(
                ScheduleExecutionLog.maintenance_window_id == window.id,
                ScheduleExecutionLog.status == 'skipped'
            ).count()

            logger.info(f"Maintenance window ended: {window.name} ({skipped_count} audits skipped)")

            result = notification_manager.notify_maintenance_window_end(
                window_name=window.name,
                window_type=window.window_type,
                server_scope=server_scope,
                start_time=window.start_time,
                end_time=window.end_time,
                skipped_audits=skipped_count,
                email_recipients=admin_emails,
                webhook_urls=webhook_urls
            )

            results['windows_ended'] += 1
            if result.get('email_sent') or result.get('webhooks_sent', 0) > 0:
                results['notifications_sent'] += 1

        logger.info(f"Maintenance window check: {results['windows_started']} started, {results['windows_ended']} ended")
        return results

    except Exception as e:
        logger.error(f"Maintenance window event check failed: {e}")
        raise

    finally:
        db.close()


__all__ = [
    'health_check_all_servers',
    'run_scheduled_audits',
    'cleanup_old_executions',
    'cleanup_analytics_history',
    'run_postgresql_maintenance',
    'update_audit_metadata',
    'check_maintenance_window_events',
]
