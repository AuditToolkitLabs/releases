#!/usr/bin/env python3
"""
Test Database Integration

Validates that the database storage backend works correctly for server CRUD operations.
Tests both database and file storage modes.

Usage:
    python3 web/test_database_integration.py
"""

import os
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.resolve()))

def test_database_storage():
    """Test database storage mode"""
    print("\n" + "="*70)
    print("  Testing Database Storage (PostgreSQL/SQLite)")
    print("="*70 + "\n")

    from models.server import ServerManager
    from config import SessionLocal

    # Initialize manager with database
    manager = ServerManager(use_database=True)

    print(f"✓ ServerManager initialized (database mode: {manager.use_database})")

    # Test 1: List servers (should be empty initially)
    servers = manager.load_servers()
    print(f"✓ Loaded {len(servers)} servers from database")

    # Test 2: Add server
    test_server = {
        "name": "test-db-server",
        "host": "192.168.1.100",
        "port": 22,
        "user": "admin",
        "auth_type": "password",
        "password": "encrypted-password-here",  # nosec B105
        "description": "Test server for database integration",
        "tags": "test,database"
    }

    try:
        new_server = manager.add_server(test_server)
        print(f"✓ Added server: {new_server['name']} (ID: {new_server['id']})")
        server_id = new_server['id']
    except ValueError as e:
        # Server might already exist
        print("⚠️  Server already exists (OK for repeated tests)")
        servers = manager.load_servers()
        server_id = next((s['id'] for s in servers if s['name'] == 'test-db-server'), None)

    # Test 3: Get server by ID
    if server_id:
        server = manager.get_server_by_id(server_id)
        if server:
            print(f"✓ Retrieved server by ID: {server['name']}")
        else:
            print("✗ Failed to retrieve server by ID")

    # Test 4: Update server
    if server_id:
        success = manager.update_server(server_id, {"description": "Updated description"})
        if success:
            print(f"✓ Updated server {server_id}")
        else:
            print(f"✗ Failed to update server {server_id}")

    # Test 5: Sanitize server data
    if server_id:
        server = manager.get_server_by_id(server_id)
        sanitized = manager.sanitize_server_for_api(server)
        if sanitized and sanitized.get('password') == '***hidden***':
            print("✓ Server data sanitized correctly")
        else:
            print("✗ Server data sanitization failed")

    # Test 6: List all servers
    servers = manager.load_servers()
    print(f"✓ Total servers in database: {len(servers)}")

    # Test 7: Remove server (cleanup)
    if server_id:
        success = manager.remove_server(server_id)
        if success:
            print(f"✓ Removed test server {server_id}")
        else:
            print(f"✗ Failed to remove server {server_id}")

    print("\n" + "="*70)
    print("  Database Storage Test: COMPLETE")
    print("="*70 + "\n")


def test_file_storage():
    """Test file storage mode (fallback)"""
    print("\n" + "="*70)
    print("  Testing File Storage (Legacy Fallback)")
    print("="*70 + "\n")

    from models.server import ServerManager

    # Initialize manager with file storage
    test_dir = Path("test_servers")
    test_dir.mkdir(exist_ok=True)

    manager = ServerManager(servers_dir=test_dir, use_database=False)

    print(f"✓ ServerManager initialized (database mode: {manager.use_database})")

    # Test 1: List servers (should be empty initially)
    servers = manager.load_servers()
    print(f"✓ Loaded {len(servers)} servers from file")

    # Test 2: Add server
    test_server = {
        "name": "test-file-server",
        "host": "192.168.1.101",
        "port": 22,
        "user": "admin",
        "auth_type": "public_key",
        "key_path": "/home/user/.ssh/id_rsa",
        "description": "Test server for file storage",
        "tags": "test,file"
    }

    try:
        new_server = manager.add_server(test_server)
        print(f"✓ Added server: {new_server['name']} (ID: {new_server['id']})")
        server_id = new_server['id']
    except Exception as e:
        print(f"✗ Failed to add server: {e}")
        server_id = None

    # Test 3: Get server by ID
    if server_id is not None:
        server = manager.get_server_by_id(server_id)
        if server:
            print(f"✓ Retrieved server by ID: {server['name']}")
        else:
            print("✗ Failed to retrieve server by ID")

    # Test 4: Update server
    if server_id is not None:
        success = manager.update_server(server_id, {"description": "Updated file description"})
        if success:
            print(f"✓ Updated server {server_id}")
        else:
            print(f"✗ Failed to update server {server_id}")

    # Test 5: Remove server (cleanup)
    if server_id is not None:
        success = manager.remove_server(server_id)
        if success:
            print(f"✓ Removed test server {server_id}")
        else:
            print(f"✗ Failed to remove server {server_id}")

    # Cleanup test directory
    import shutil
    shutil.rmtree(test_dir, ignore_errors=True)
    print("✓ Cleaned up test directory")

    print("\n" + "="*70)
    print("  File Storage Test: COMPLETE")
    print("="*70 + "\n")


def main():
    print("\n╔════════════════════════════════════════════════════════════════════╗")
    print("║     Security Audit Toolkit - Database Integration Test            ║")
    print("╚════════════════════════════════════════════════════════════════════╝")

    try:
        # Test database storage
        test_database_storage()
    except Exception as e:
        print(f"\n✗ Database storage test failed: {e}")
        import traceback
        traceback.print_exc()

    try:
        # Test file storage
        test_file_storage()
    except Exception as e:
        print(f"\n✗ File storage test failed: {e}")
        import traceback
        traceback.print_exc()

    print("\n✅ All tests completed!\n")
    print("Next steps:")
    print("  1. Run 'alembic upgrade head' to apply migrations")
    print("  2. Start Flask app: python3 web/app.py")
    print("  3. Test API endpoints with database storage\n")


if __name__ == '__main__':
    main()
