"""Shared test doubles for hypervisor route tests."""

from datetime import datetime


class _FakeExecutionModel:
    id = "id"


class _FakeHypervisorModel:
    id = "id"
    name = "name"


class _FakeExecution:
    id = "id"

    def __init__(self, **kwargs):
        self.id = kwargs.get("id", 101)
        self.hypervisor_id = kwargs.get("hypervisor_id")
        self.audit_type = kwargs.get("audit_type", "security")
        self.audit_script = kwargs.get("audit_script")
        self.started_at = kwargs.get("started_at", datetime.utcnow())
        self.completed_at = kwargs.get("completed_at")
        self.status = kwargs.get("status", "running")
        self.exit_code = kwargs.get("exit_code")
        self.output = kwargs.get("output")
        self.summary = kwargs.get("summary")
        self.checks_total = kwargs.get("checks_total", 0)
        self.checks_passed = kwargs.get("checks_passed", 0)
        self.checks_warned = kwargs.get("checks_warned", 0)
        self.checks_failed = kwargs.get("checks_failed", 0)
        self.checks_skipped = kwargs.get("checks_skipped", 0)
        self.duration_seconds = kwargs.get("duration_seconds")

    def to_dict(self):
        return {
            "id": self.id,
            "status": self.status,
            "exit_code": self.exit_code,
        }


class _FakeHypervisor:
    id = "id"
    name = "name"

    def __init__(self, **kwargs):
        self.id = kwargs.get("id", 42)
        self.name = kwargs.get("name", "hv-direct")
        self.hostname = kwargs.get("hostname", "hv-direct-01")
        self.port = kwargs.get("port", 8006)
        self.hypervisor_type = kwargs.get("hypervisor_type", "proxmox")
        self.connection_method = kwargs.get("connection_method", "api")
        self.username = kwargs.get("username")
        self.password = kwargs.get("password")
        self.api_token = kwargs.get("api_token")
        self.verify_ssl = kwargs.get("verify_ssl", True)
        self.api_endpoint = kwargs.get("api_endpoint")
        self.description = kwargs.get("description")
        self.tags = kwargs.get("tags")
        self.datacenter = kwargs.get("datacenter")
        self.cluster = kwargs.get("cluster")
        self.status = kwargs.get("status", "unknown")
        self.last_connection_check = kwargs.get("last_connection_check")
        self.last_connection_error = kwargs.get("last_connection_error")
        self.last_audit_at = kwargs.get("last_audit_at")
        self.updated_at = kwargs.get("updated_at")

    def to_dict(self, include_sensitive=False):
        payload = {
            "id": self.id,
            "name": self.name,
            "hostname": self.hostname,
            "hypervisor_type": self.hypervisor_type,
            "status": self.status,
        }
        if include_sensitive:
            payload["username"] = self.username
        return payload


class _FakeQuery:
    def __init__(self, item):
        self.item = item

    def filter(self, *args, **kwargs):
        return self

    def first(self):
        return self.item


class _FakeSession:
    def __init__(self, execution, hypervisor):
        self.execution = execution
        self.hypervisor = hypervisor
        self.committed = False
        self.closed = False
        self.rolled_back = False

    def query(self, model):
        if model is _FakeExecutionModel:
            return _FakeQuery(self.execution)
        if model is _FakeHypervisorModel:
            return _FakeQuery(self.hypervisor)
        return _FakeQuery(None)

    def commit(self):
        self.committed = True

    def rollback(self):
        self.rolled_back = True

    def close(self):
        self.closed = True


class _FakeCrudQuery:
    def __init__(self, item):
        self.item = item

    def filter(self, *args, **kwargs):
        return self

    def first(self):
        return self.item


class _FakeCrudSession:
    def __init__(self, hypervisor=None, duplicate_name_result=None):
        self.hypervisor = hypervisor
        self.duplicate_name_result = duplicate_name_result
        self.added = []
        self.deleted = []
        self.committed = False
        self.closed = False
        self.rolled_back = False
        self.refreshed = []
        self.query_count = 0

    def query(self, model):
        self.query_count += 1
        if self.query_count == 1:
            return _FakeCrudQuery(self.hypervisor)
        return _FakeCrudQuery(self.duplicate_name_result)

    def add(self, obj):
        self.added.append(obj)
        self.hypervisor = obj

    def delete(self, obj):
        self.deleted.append(obj)
        if self.hypervisor is obj:
            self.hypervisor = None

    def commit(self):
        self.committed = True

    def rollback(self):
        self.rolled_back = True

    def close(self):
        self.closed = True

    def refresh(self, obj):
        self.refreshed.append(obj)


class _FakeAuditSession:
    def __init__(self, hypervisor=None, execution=None):
        self.hypervisor = hypervisor
        self.execution = execution
        self.added = []
        self.committed = False
        self.closed = False
        self.rolled_back = False
        self.refreshed = []

    def query(self, model):
        model_name = getattr(model, "__name__", "")
        if model is _FakeHypervisorModel or model_name == "Hypervisor":
            return _FakeQuery(self.hypervisor)
        if model is _FakeExecutionModel or model is _FakeExecution or model_name in ("HypervisorAuditExecution", "_FakeExecution"):
            return _FakeQuery(self.execution)
        return _FakeQuery(None)

    def add(self, obj):
        self.added.append(obj)
        if isinstance(obj, _FakeExecution):
            self.execution = obj

    def commit(self):
        self.committed = True

    def rollback(self):
        self.rolled_back = True

    def close(self):
        self.closed = True

    def refresh(self, obj):
        self.refreshed.append(obj)


class _FakeFleetAgentModel:
    agent_id = "agent_id"


class _FakeFleetAgentRow:
    def __init__(self):
        self.is_active = True


class _FakeUnifiedDb:
    def __init__(self, row=None):
        self.row = row
        self.committed = False

    def query(self, model):
        return _FakeQuery(self.row)

    def commit(self):
        self.committed = True


class _FakeThread:
    def __init__(self, target=None, daemon=None):
        self.target = target
        self.daemon = daemon
        self.started = False

    def start(self):
        self.started = True


class _FakeListQuery:
    """Chainable query double supporting filter/order_by/count/offset/limit/all."""

    def __init__(self, items):
        self._items = list(items)

    def filter(self, *args, **kwargs):
        return self

    def order_by(self, *args, **kwargs):
        return self

    def count(self):
        return len(self._items)

    def offset(self, n):
        self._items = self._items[n:]
        return self

    def limit(self, n):
        self._items = self._items[:n]
        return self

    def all(self):
        return self._items

    def first(self):
        return self._items[0] if self._items else None


class _FakeListSession:
    """Session double that returns a _FakeListQuery for any model."""

    def __init__(self, items):
        self._items = items
        self.closed = False

    def query(self, model):
        return _FakeListQuery(self._items)

    def close(self):
        self.closed = True
