from pathlib import Path


def test_direct_api_hardening_nav_is_superadmin_only() -> None:
    index_html = (Path(__file__).resolve().parents[1] / "index.html").read_text(encoding="utf-8")

    assert '<li class="admin-nav-item superadmin-only" data-external="/admin/destination-policy">' in index_html
    assert '<li class="admin-nav-item" data-external="/admin/destination-policy">' not in index_html
    assert 'href="/admin/destination-policy" class="home-nav-link"' not in index_html
