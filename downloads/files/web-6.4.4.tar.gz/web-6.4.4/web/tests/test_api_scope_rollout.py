#!/usr/bin/env python3
"""
API Scope Rollout Tests

Validates endpoint-level API key scope classification coverage.
"""

import sys
import unittest
from pathlib import Path

from flask import Flask

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import auth_core


class TestAPIScopeRollout(unittest.TestCase):
    """Test expanded endpoint scope classification logic."""

    def setUp(self):
        self.app = Flask(__name__)

    def _check(self, path, method, scopes):
        with self.app.test_request_context(path=path, method=method):
            return auth_core._scope_allows_request({'scope': scopes})

    def test_fleet_agent_requires_agent_scope(self):
        allowed, message = self._check('/api/managed-agent/poll', 'POST', ['agent'])
        self.assertTrue(allowed)
        self.assertEqual(message, '')

    def test_fleet_agent_denied_without_agent_scope(self):
        allowed, message = self._check('/api/managed-agent/poll', 'POST', ['read'])
        self.assertFalse(allowed)
        self.assertIn('Agent scope required', message)

    def test_discovery_endpoint_classified_execute(self):
        allowed, message = self._check('/api/discovery/run', 'POST', ['read'])
        self.assertFalse(allowed)
        self.assertIn('Execute scope required', message)

    def test_settings_post_requires_write(self):
        allowed, message = self._check('/api/settings/security', 'POST', ['read'])
        self.assertFalse(allowed)
        self.assertIn('Write scope required', message)

    def test_read_prefix_allows_read_scope(self):
        allowed, message = self._check('/api/cve/latest', 'GET', ['read'])
        self.assertTrue(allowed)
        self.assertEqual(message, '')


if __name__ == '__main__':
    unittest.main()
