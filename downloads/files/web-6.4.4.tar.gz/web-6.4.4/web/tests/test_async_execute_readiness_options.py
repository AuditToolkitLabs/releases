#!/usr/bin/env python3
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from flask import Flask


sys.path.insert(0, str(Path(__file__).parent.parent))

from api.audit_async_routes import async_audit_bp
import api.audit_async_routes as routes
from auth_core import get_api_key_manager


class _FakeQuery:
    def filter(self, *args, **kwargs):
        return self

    def first(self):
        return types.SimpleNamespace(id=4, name='WinServer-20')


class _FakeSession:
    def query(self, model):
        return _FakeQuery()

    def close(self):
        return None


class _FakeServerModel:
    class _IdField:
        def __eq__(self, other):
            return other

    id = _IdField()


class _CaptureTask:
    calls = []

    @classmethod
    def apply_async(cls, args=None, kwargs=None, queue=None):
        cls.calls.append({'args': args, 'kwargs': kwargs, 'queue': queue})
        return types.SimpleNamespace(id='task-readiness-123')


class TestAsyncExecuteReadinessOptions(unittest.TestCase):
    def setUp(self):
        self.app = Flask(__name__)
        self.app.register_blueprint(async_audit_bp)
        self.client = self.app.test_client()
        self.api_key = get_api_key_manager().api_key
        _CaptureTask.calls = []

    def _headers(self):
        return {
            'X-API-Key': self.api_key,
            'Content-Type': 'application/json',
        }

    def test_execute_async_forwards_readiness_gate_enabled(self):
        payload = {
            'mode': 'single',
            'server_id': 4,
            'audit_path': 'deployment/agents/_build/lightweight-windows/audit-agent/audits/platform/baseline/os_version.ps1',
            'options': {
                'timeout': 180,
                'enable_readiness_gate': True,
                'require_jea_endpoint': True,
                'strict_elevation': True,
            },
        }

        with patch.object(routes, 'SessionLocal', return_value=_FakeSession()), \
             patch.object(routes, 'Server', _FakeServerModel), \
             patch.object(routes, 'validate_path', return_value=True), \
             patch.object(routes, 'execute_audit', _CaptureTask):
            response = self.client.post('/api/async/execute', json=payload, headers=self._headers())

        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        self.assertTrue(body['success'])
        self.assertEqual(len(_CaptureTask.calls), 1)
        options = _CaptureTask.calls[0]['kwargs']['options']
        self.assertTrue(options['enable_readiness_gate'])
        self.assertTrue(options['require_jea_endpoint'])
        self.assertTrue(options['strict_elevation'])

    def test_execute_async_forwards_readiness_gate_disabled(self):
        payload = {
            'mode': 'single',
            'server_id': 4,
            'audit_path': 'deployment/agents/_build/lightweight-windows/audit-agent/audits/platform/baseline/os_version.ps1',
            'options': {
                'timeout': 180,
                'enable_readiness_gate': False,
            },
        }

        with patch.object(routes, 'SessionLocal', return_value=_FakeSession()), \
             patch.object(routes, 'Server', _FakeServerModel), \
             patch.object(routes, 'validate_path', return_value=True), \
             patch.object(routes, 'execute_audit', _CaptureTask):
            response = self.client.post('/api/async/execute', json=payload, headers=self._headers())

        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        self.assertTrue(body['success'])
        self.assertEqual(len(_CaptureTask.calls), 1)
        options = _CaptureTask.calls[0]['kwargs']['options']
        self.assertFalse(options['enable_readiness_gate'])


if __name__ == '__main__':
    unittest.main()
