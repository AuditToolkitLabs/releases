"""
Authentication Provider Tests

Comprehensive tests for all authentication providers:
- Local authentication
- LDAP/Active Directory
- Microsoft Entra ID
- Okta OIDC
- Multi-Factor Authentication (TOTP)

Author: Security Audit Toolkit Team
Date: March 2026
"""

import os
import sys
import unittest
from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch, PropertyMock

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestMFAManager(unittest.TestCase):
    """Tests for MFA (TOTP) authentication"""

    def setUp(self):
        """Set up test fixtures"""
        # Set encryption key for testing
        os.environ["MFA_ENCRYPTION_KEY"] = (
            "dGVzdC1lbmNyeXB0aW9uLWtleS1mb3ItdW5pdC10ZXN0cw=="
        )  # Base64 encoded test key

    def test_mfa_import(self):
        """Test MFA module can be imported"""
        try:
            from auth.mfa import MFAManager, MFAConfig, mfa_available
            self.assertTrue(True)
        except ImportError as e:
            self.skipTest(f"MFA dependencies not installed: {e}")

    def test_mfa_config_from_env(self):
        """Test MFA configuration loading from environment"""
        try:
            from auth.mfa import MFAConfig

            os.environ["MFA_ISSUER"] = "TestIssuer"
            os.environ["MFA_VALID_WINDOW"] = "2"

            config = MFAConfig.from_env()
            self.assertEqual(config.issuer, "TestIssuer")
            self.assertEqual(config.valid_window, 2)
        except ImportError:
            self.skipTest("MFA dependencies not installed")
        finally:
            os.environ.pop("MFA_ISSUER", None)
            os.environ.pop("MFA_VALID_WINDOW", None)

    def test_generate_secret(self):
        """Test TOTP secret generation"""
        try:
            from auth.mfa import get_mfa_manager

            mfa = get_mfa_manager()
            if not mfa:
                self.skipTest("MFA not available")

            secret = mfa.generate_secret()
            self.assertIsInstance(secret, str)
            self.assertGreater(len(secret), 10)
        except ImportError:
            self.skipTest("MFA dependencies not installed")

    def test_generate_backup_codes(self):
        """Test backup code generation"""
        try:
            from auth.mfa import get_mfa_manager

            mfa = get_mfa_manager()
            if not mfa:
                self.skipTest("MFA not available")

            codes = mfa.generate_backup_codes(count=10)
            self.assertEqual(len(codes), 10)

            # Each code should match format XXXX-XXXX
            for code in codes:
                self.assertRegex(code, r'^[A-Z0-9]{4}-[A-Z0-9]{4}$')
        except ImportError:
            self.skipTest("MFA dependencies not installed")

    def test_verify_code_valid(self):
        """Test TOTP code verification with valid code"""
        try:
            import pyotp
            from auth.mfa import get_mfa_manager

            mfa = get_mfa_manager()
            if not mfa:
                self.skipTest("MFA not available")

            secret = mfa.generate_secret()
            totp = pyotp.TOTP(secret)
            valid_code = totp.now()

            self.assertTrue(mfa.verify_code(secret, valid_code))
        except ImportError:
            self.skipTest("MFA dependencies not installed")

    def test_verify_code_invalid(self):
        """Test TOTP code verification with invalid code"""
        try:
            from auth.mfa import get_mfa_manager

            mfa = get_mfa_manager()
            if not mfa:
                self.skipTest("MFA not available")

            secret = mfa.generate_secret()
            invalid_code = "000000"

            self.assertFalse(mfa.verify_code(secret, invalid_code))
        except ImportError:
            self.skipTest("MFA dependencies not installed")

    def test_encrypt_decrypt_secret(self):
        """Test secret encryption round-trip"""
        try:
            from cryptography.fernet import Fernet
            from auth.mfa import MFAManager

            # Generate a valid Fernet key for testing
            test_key = Fernet.generate_key()
            mfa = MFAManager(encryption_key=test_key)

            original_secret = mfa.generate_secret()
            encrypted = mfa.encrypt_secret(original_secret)
            decrypted = mfa.decrypt_secret(encrypted)

            self.assertEqual(original_secret, decrypted)
            self.assertNotEqual(original_secret, encrypted)
        except ImportError:
            self.skipTest("MFA dependencies not installed")


class TestLDAPAuth(unittest.TestCase):
    """Tests for LDAP authentication"""

    def test_ldap_import(self):
        """Test LDAP module can be imported"""
        try:
            from auth.ldap_auth import LDAPAuth, LDAPConfig
            self.assertTrue(True)
        except ImportError as e:
            self.skipTest(f"LDAP dependencies not installed: {e}")

    def test_ldap_config_validation_missing_fields(self):
        """Test LDAP config validation with missing required fields"""
        try:
            from auth.ldap_auth import LDAPConfig

            config = LDAPConfig(enabled=True)  # Missing required fields
            is_valid, errors = config.validate()

            self.assertFalse(is_valid)
            self.assertGreater(len(errors), 0)
        except ImportError:
            self.skipTest("LDAP dependencies not installed")

    def test_ldap_config_validation_disabled(self):
        """Test LDAP config validation when disabled - still validates required fields"""
        try:
            from auth.ldap_auth import LDAPConfig

            # When disabled but missing required fields, validation fails
            config = LDAPConfig(enabled=False)
            is_valid, errors = config.validate()

            # The implementation validates required fields even when disabled
            # So this test verifies that behavior
            self.assertFalse(is_valid)  # Missing required fields
            self.assertGreater(len(errors), 0)
        except ImportError:
            self.skipTest("LDAP dependencies not installed")

    def test_ldap_role_mapping(self):
        """Test LDAP group to role mapping"""
        try:
            from auth.ldap_auth import LDAPAuth, LDAPConfig, LDAPUser

            config = LDAPConfig(
                enabled=True,
                server="ldap://test.local",
                bind_dn="cn=admin,dc=test,dc=local",
                bind_password="password",  # nosec B106
                user_search_base="ou=users,dc=test,dc=local",
                role_mapping={
                    "CN=Admins,OU=Groups,DC=test,DC=local": "Admin",
                    "CN=Analysts,OU=Groups,DC=test,DC=local": "Analyst",
                },
                default_role="Viewer",
            )

            ldap = LDAPAuth(config)

            # Test admin group mapping using get_role_for_user()
            admin_user = LDAPUser(
                username="testadmin",
                dn="cn=testadmin,ou=users,dc=test,dc=local",
                groups=["CN=Admins,OU=Groups,DC=test,DC=local"]
            )
            role = ldap.get_role_for_user(admin_user)
            self.assertEqual(role, "Admin")

            # Test default role for unmapped groups
            other_user = LDAPUser(
                username="testuser",
                dn="cn=testuser,ou=users,dc=test,dc=local",
                groups=["CN=Other,OU=Groups,DC=test,DC=local"]
            )
            role = ldap.get_role_for_user(other_user)
            self.assertEqual(role, "Viewer")
        except ImportError:
            self.skipTest("LDAP dependencies not installed")


class TestEntraAuth(unittest.TestCase):
    """Tests for Microsoft Entra ID authentication"""

    def test_entra_import(self):
        """Test Entra module can be imported"""
        try:
            from auth.entra_auth import EntraAuth, EntraConfig
            self.assertTrue(True)
        except ImportError as e:
            self.skipTest(f"Entra dependencies not installed: {e}")

    def test_entra_config_validation_missing_fields(self):
        """Test Entra config validation with missing required fields"""
        try:
            from auth.entra_auth import EntraConfig

            config = EntraConfig(enabled=True)  # Missing required fields
            is_valid, errors = config.validate()

            self.assertFalse(is_valid)
            self.assertGreater(len(errors), 0)
        except ImportError:
            self.skipTest("Entra dependencies not installed")

    def test_entra_config_from_env(self):
        """Test Entra config loading from environment"""
        try:
            from auth.entra_auth import EntraConfig

            os.environ["ENTRA_ENABLED"] = "true"
            os.environ["ENTRA_TENANT_ID"] = "test-tenant-id"
            os.environ["ENTRA_CLIENT_ID"] = "test-client-id"
            os.environ["ENTRA_CLIENT_SECRET"] = "test-secret"  # nosec B105
            os.environ["ENTRA_REDIRECT_URI"] = "https://test.com/callback"

            config = EntraConfig.from_env()

            self.assertTrue(config.enabled)
            self.assertEqual(config.tenant_id, "test-tenant-id")
            self.assertEqual(config.client_id, "test-client-id")
        except ImportError:
            self.skipTest("Entra dependencies not installed")
        finally:
            for key in ["ENTRA_ENABLED", "ENTRA_TENANT_ID", "ENTRA_CLIENT_ID",
                        "ENTRA_CLIENT_SECRET", "ENTRA_REDIRECT_URI"]:
                os.environ.pop(key, None)

    def test_entra_role_priority(self):
        """Test Entra group to role mapping with priority"""
        try:
            from auth.entra_auth import EntraAuth, EntraConfig

            config = EntraConfig(
                enabled=True,
                tenant_id="test-tenant",
                client_id="test-client",
                client_secret="test-secret",  # nosec B106
                redirect_uri="https://test.com/callback",
                role_mapping={
                    "group-admin": "Admin",
                    "group-analyst": "Analyst",
                    "group-superadmin": "SuperAdmin",
                },
                default_role="Viewer",
            )

            entra = EntraAuth(config)

            # Test that SuperAdmin takes priority
            groups = ["group-admin", "group-superadmin", "group-analyst"]
            role = entra._map_groups_to_role(groups)
            self.assertEqual(role, "SuperAdmin")
        except ImportError:
            self.skipTest("Entra dependencies not installed")


class TestOktaAuth(unittest.TestCase):
    """Tests for Okta OIDC authentication"""

    def test_okta_import(self):
        """Test Okta module can be imported"""
        try:
            from auth.okta import OktaAuth, OktaConfig
            self.assertTrue(True)
        except ImportError as e:
            self.skipTest(f"Okta dependencies not installed: {e}")

    def test_okta_config_validation_missing_fields(self):
        """Test Okta config validation with missing required fields"""
        try:
            from auth.okta import OktaConfig

            config = OktaConfig(enabled=True)  # Missing required fields
            is_valid, errors = config.validate()

            self.assertFalse(is_valid)
            self.assertGreater(len(errors), 0)
            self.assertIn("OKTA_DOMAIN is required", errors)
        except ImportError:
            self.skipTest("Okta dependencies not installed")

    def test_okta_config_from_env(self):
        """Test Okta config loading from environment"""
        try:
            from auth.okta import OktaConfig

            os.environ["OKTA_ENABLED"] = "true"
            os.environ["OKTA_DOMAIN"] = "dev-12345.okta.com"
            os.environ["OKTA_CLIENT_ID"] = "test-client-id"
            os.environ["OKTA_CLIENT_SECRET"] = "test-secret"  # nosec B105
            os.environ["OKTA_REDIRECT_URI"] = "https://test.com/callback"

            config = OktaConfig.from_env()

            self.assertTrue(config.enabled)
            self.assertEqual(config.domain, "dev-12345.okta.com")
            self.assertEqual(config.client_id, "test-client-id")
        except ImportError:
            self.skipTest("Okta dependencies not installed")
        finally:
            for key in ["OKTA_ENABLED", "OKTA_DOMAIN", "OKTA_CLIENT_ID",
                        "OKTA_CLIENT_SECRET", "OKTA_REDIRECT_URI"]:
                os.environ.pop(key, None)

    def test_okta_issuer_url(self):
        """Test Okta issuer URL construction"""
        try:
            from auth.okta import OktaAuth, OktaConfig

            config = OktaConfig(
                enabled=True,
                domain="dev-12345.okta.com",
                client_id="test-client",
                client_secret="test-secret",  # nosec B106
                redirect_uri="https://test.com/callback",
                auth_server_id="default",
            )

            okta = OktaAuth(config)
            self.assertEqual(okta.issuer, "https://dev-12345.okta.com/oauth2/default")

            # Test with custom auth server
            config.auth_server_id = "custom-server"
            okta = OktaAuth(config)
            self.assertEqual(okta.issuer, "https://dev-12345.okta.com/oauth2/custom-server")
        except ImportError:
            self.skipTest("Okta dependencies not installed")

    def test_okta_role_mapping(self):
        """Test Okta group to role mapping"""
        try:
            from auth.okta import OktaAuth, OktaConfig

            config = OktaConfig(
                enabled=True,
                domain="dev-12345.okta.com",
                client_id="test-client",
                client_secret="test-secret",  # nosec B106
                redirect_uri="https://test.com/callback",
                role_mapping={
                    "AuditToolkit-Admin": "Admin",
                    "AuditToolkit-Analyst": "Analyst",
                },
                default_role="Viewer",
            )

            okta = OktaAuth(config)

            # Test admin group mapping
            role = okta._map_groups_to_role(["AuditToolkit-Admin"])
            self.assertEqual(role, "Admin")

            # Test analyst group mapping
            role = okta._map_groups_to_role(["AuditToolkit-Analyst"])
            self.assertEqual(role, "Analyst")

            # Test default role for unmapped groups
            role = okta._map_groups_to_role(["SomeOtherGroup"])
            self.assertEqual(role, "Viewer")

            # Test empty groups
            role = okta._map_groups_to_role([])
            self.assertEqual(role, "Viewer")
        except ImportError:
            self.skipTest("Okta dependencies not installed")

    def test_okta_decode_id_token(self):
        """Test ID token decoding with explicit verification flow"""
        try:
            from auth.okta import OktaAuth, OktaConfig
            import base64
            import json

            config = OktaConfig(
                enabled=True,
                domain="dev-12345.okta.com",
                client_id="test-client",
                client_secret="test-secret",  # nosec B106
                redirect_uri="https://test.com/callback",
            )

            okta = OktaAuth(config)

            # Create a mock JWT token (header.payload.signature)
            header = base64.urlsafe_b64encode(json.dumps({"alg": "RS256"}).encode()).decode().rstrip("=")
            payload = {
                "sub": "test-user-id",
                "email": "test@example.com",
                "name": "Test User",
            }
            payload_b64 = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
            signature = "signed-token"

            mock_token = f"{header}.{payload_b64}.{signature}"

            class _Claims(dict):
                def validate(self, leeway=0):
                    return None

            with patch.object(okta, "_get_jwks", return_value={"keys": []}), patch(
                "auth.okta.jwt.decode", return_value=_Claims(payload)
            ) as mock_decode:
                decoded = okta.decode_id_token(mock_token)

            self.assertEqual(decoded["sub"], "test-user-id")
            self.assertEqual(decoded["email"], "test@example.com")
            mock_decode.assert_called_once()
        except ImportError:
            self.skipTest("Okta dependencies not installed")

    def test_okta_decode_id_token_rejects_alg_none(self):
        """Test ID token decoding rejects alg=none tokens"""
        try:
            from auth.okta import OktaAuth, OktaConfig, OktaTokenError
            import base64
            import json

            config = OktaConfig(
                enabled=True,
                domain="dev-12345.okta.com",
                client_id="test-client",
                client_secret="test-secret",  # nosec B106
                redirect_uri="https://test.com/callback",
            )

            okta = OktaAuth(config)

            header = base64.urlsafe_b64encode(
                json.dumps({"alg": "none", "typ": "JWT"}).encode()
            ).decode().rstrip("=")
            payload = base64.urlsafe_b64encode(json.dumps({"sub": "user"}).encode()).decode().rstrip("=")
            malicious_token = f"{header}.{payload}."

            with patch.object(okta, "_get_jwks") as mock_get_jwks:
                with self.assertRaises(OktaTokenError) as context:
                    okta.decode_id_token(malicious_token)

            self.assertIn("alg=none", str(context.exception))
            mock_get_jwks.assert_not_called()
        except ImportError:
            self.skipTest("Okta dependencies not installed")

    def test_okta_decode_id_token_rejects_empty_signature(self):
        """Test ID token decoding rejects empty signature even with secure alg"""
        try:
            from auth.okta import OktaAuth, OktaConfig, OktaTokenError
            import base64
            import json

            config = OktaConfig(
                enabled=True,
                domain="dev-12345.okta.com",
                client_id="test-client",
                client_secret="test-secret",  # nosec B106
                redirect_uri="https://test.com/callback",
            )

            okta = OktaAuth(config)

            header = base64.urlsafe_b64encode(
                json.dumps({"alg": "RS256", "typ": "JWT"}).encode()
            ).decode().rstrip("=")
            payload = base64.urlsafe_b64encode(json.dumps({"sub": "user"}).encode()).decode().rstrip("=")
            malformed_token = f"{header}.{payload}."

            with patch.object(okta, "_get_jwks") as mock_get_jwks:
                with self.assertRaises(OktaTokenError) as context:
                    okta.decode_id_token(malformed_token)

            self.assertIn("signature is missing", str(context.exception))
            mock_get_jwks.assert_not_called()
        except ImportError:
            self.skipTest("Okta dependencies not installed")


class TestAuthProviderIntegration(unittest.TestCase):
    """Integration tests for auth provider detection and status"""

    def test_sso_providers_list(self):
        """Test that SSO providers list is returned correctly"""
        try:
            from api.auth_routes import get_available_sso_providers

            providers = get_available_sso_providers()
            self.assertIsInstance(providers, list)

            # Each provider should have required fields
            for provider in providers:
                self.assertIn("name", provider)
                self.assertIn("slug", provider)
                self.assertIn("login_url", provider)
        except ImportError as e:
            self.skipTest(f"Import error: {e}")

    def test_auth_provider_status_functions(self):
        """Test auth provider status helper functions exist"""
        try:
            from api.auth_admin_routes import (
                _get_ldap_status,
                _get_entra_status,
                _get_okta_status,
                _get_mfa_status,
            )

            # Each should return a dict with expected keys
            ldap_status = _get_ldap_status()
            self.assertIn("available", ldap_status)
            self.assertIn("name", ldap_status)

            entra_status = _get_entra_status()
            self.assertIn("available", entra_status)
            self.assertIn("name", entra_status)

            okta_status = _get_okta_status()
            self.assertIn("available", okta_status)
            self.assertIn("name", okta_status)

            mfa_status = _get_mfa_status()
            self.assertIn("available", mfa_status)
            self.assertIn("name", mfa_status)
        except ImportError as e:
            self.skipTest(f"Import error: {e}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
