#!/usr/bin/env python3
"""
Backup Encryption Policy Tests

Validates encryption-at-rest enforcement for backup creation paths.
"""

import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch, MagicMock

from cryptography.fernet import Fernet

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import backup_manager
from tasks import backup_tasks


class TestBackupEncryptionPolicy(unittest.TestCase):
    """Test backup encryption-at-rest policy enforcement."""

    def test_policy_forces_encryption_when_requested_false(self):
        """backup_encrypt policy forces encryption even when request says encrypt=False."""
        with TemporaryDirectory() as temp_dir:
            key = Fernet.generate_key().decode()
            manager = backup_manager.BackupManager(backup_dir=temp_dir, encryption_key=key)
            manager.is_postgresql = False

            plaintext_file = Path(temp_dir) / 'backup_full_test.db.gz'
            plaintext_file.write_bytes(b'test-backup-data')

            mock_backup_info = {
                'filename': plaintext_file.name,
                'filepath': str(plaintext_file),
                'backup_type': 'full',
                'database_type': 'sqlite',
                'database_name': 'test.db',
                'timestamp': '2026-02-20T00:00:00',
                'size_bytes': plaintext_file.stat().st_size,
                'compressed': True,
                'encrypted': False,
                'checksum': manager._calculate_checksum(plaintext_file)
            }

            with patch.object(manager, '_backup_sqlite', return_value=mock_backup_info), \
                 patch('security_settings.get_security_setting', return_value=True):
                result = manager.create_backup(
                    backup_type='full',
                    compress=True,
                    encrypt=False,
                    include_metadata=False
                )

            self.assertTrue(result['encrypted'])
            self.assertTrue(result['filename'].endswith('.enc'))
            self.assertFalse(plaintext_file.exists())
            self.assertTrue(Path(result['filepath']).exists())

    def test_policy_fails_closed_without_encryption_key(self):
        """backup creation is blocked before dump/copy when encryption is required but key is missing."""
        with TemporaryDirectory() as temp_dir:
            manager = backup_manager.BackupManager(backup_dir=temp_dir)
            manager.is_postgresql = False

            with patch.object(manager, '_backup_sqlite') as mock_backup_sqlite, \
                 patch('security_settings.get_security_setting', return_value=True):
                with self.assertRaises(ValueError):
                    manager.create_backup(
                        backup_type='full',
                        compress=True,
                        encrypt=False,
                        include_metadata=False
                    )

            mock_backup_sqlite.assert_not_called()

    def test_scheduled_backup_uses_policy_default_when_encrypt_unspecified(self):
        """Scheduled task uses security policy when encrypt argument is omitted."""
        mock_manager = MagicMock()
        mock_manager.create_backup.return_value = {
            'filename': 'x',
            'encrypted': True,
            'size_bytes': 1024,
            'backup_type': 'full',
            'timestamp': '2026-02-20T00:00:00',
            'checksum': 'abc'
        }

        with patch('backup_manager.BackupManager', return_value=mock_manager), \
             patch('security_settings.get_security_setting', return_value=True):
            backup_tasks.create_scheduled_backup(
                backup_type='full',
                compress=True,
                encrypt=None,
                notify_on_success=False
            )

        kwargs = mock_manager.create_backup.call_args.kwargs
        self.assertTrue(kwargs['encrypt'])

    def test_backup_max_size_policy_blocks_and_cleans_up_oversize_backup(self):
        """Oversize backups are rejected and removed when backup_max_size policy is exceeded."""
        with TemporaryDirectory() as temp_dir:
            manager = backup_manager.BackupManager(backup_dir=temp_dir)
            manager.is_postgresql = False

            large_backup = Path(temp_dir) / 'backup_full_large.db.gz'
            with open(large_backup, 'wb') as f:
                f.truncate(60 * 1024 * 1024)  # 60MB sparse file

            mock_backup_info = {
                'filename': large_backup.name,
                'filepath': str(large_backup),
                'backup_type': 'full',
                'database_type': 'sqlite',
                'database_name': 'test.db',
                'timestamp': '2026-02-20T00:00:00',
                'size_bytes': large_backup.stat().st_size,
                'compressed': True,
                'encrypted': False,
                'checksum': manager._calculate_checksum(large_backup)
            }

            def _mock_security_setting(key, default=None):
                if key == 'backup_max_size':
                    return 50
                if key == 'backup_encrypt':
                    return False
                return default

            with patch.object(manager, '_backup_sqlite', return_value=mock_backup_info), \
                 patch('security_settings.get_security_setting', side_effect=_mock_security_setting):
                with self.assertRaises(ValueError):
                    manager.create_backup(
                        backup_type='full',
                        compress=True,
                        encrypt=False,
                        include_metadata=False
                    )

            self.assertFalse(large_backup.exists())


if __name__ == '__main__':
    unittest.main()
