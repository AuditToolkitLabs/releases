#!/usr/bin/env python3
"""Tests for shared data backup coverage (asset-discovery/agents volumes)."""

import sys
import unittest
import hashlib
import importlib.util
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

backup_manager_spec = importlib.util.spec_from_file_location(
    'backup_manager',
    Path(__file__).parent.parent / 'backup_manager.py',
)
backup_manager = importlib.util.module_from_spec(backup_manager_spec)
assert backup_manager_spec and backup_manager_spec.loader  # nosec B101
backup_manager_spec.loader.exec_module(backup_manager)


def _sha256(filepath: Path) -> str:
    digest = hashlib.sha256()
    with open(filepath, 'rb') as handle:
        for chunk in iter(lambda: handle.read(8192), b''):
            digest.update(chunk)
    return digest.hexdigest()


class TestBackupSharedDataPolicy(unittest.TestCase):
    """Validate shared-data companion archive creation and verification."""

    def test_create_backup_includes_shared_data_archive_when_enabled(self):
        with TemporaryDirectory() as temp_dir:
            manager = backup_manager.BackupManager(backup_dir=temp_dir)
            manager.is_postgresql = False

            db_backup = Path(temp_dir) / 'backup_full_test.db.gz'
            db_backup.write_bytes(b'test-backup-data')

            shared_dir = Path(temp_dir) / 'shared-data'
            shared_dir.mkdir(parents=True, exist_ok=True)
            (shared_dir / 'asset.json').write_text('{"ok":true}', encoding='utf-8')

            mock_backup_info = {
                'filename': db_backup.name,
                'filepath': str(db_backup),
                'backup_type': 'full',
                'database_type': 'sqlite',
                'database_name': 'test.db',
                'timestamp': '2026-03-02T00:00:00',
                'size_bytes': db_backup.stat().st_size,
                'compressed': True,
                'encrypted': False,
                'checksum': _sha256(db_backup),
            }

            def _mock_security_setting(key, default=None):
                if key == 'backup_encrypt':
                    return False
                if key == 'backup_include_shared_data':
                    return True
                if key == 'backup_shared_data_paths':
                    return str(shared_dir)
                return default

            with patch.object(manager, '_backup_sqlite', return_value=mock_backup_info), \
                 patch('security_settings.get_security_setting', side_effect=_mock_security_setting):
                result = manager.create_backup(
                    backup_type='full',
                    compress=True,
                    encrypt=False,
                    include_metadata=False,
                )

            shared = result.get('shared_data_backup') or {}
            self.assertTrue(shared.get('included'))
            self.assertTrue(Path(shared.get('archive_filepath', '')).exists())
            self.assertIn(str(shared_dir), shared.get('existing_paths', []))

    def test_verify_backup_checks_shared_data_archive_integrity(self):
        with TemporaryDirectory() as temp_dir:
            manager = backup_manager.BackupManager(backup_dir=temp_dir)
            manager.is_postgresql = False

            db_backup = Path(temp_dir) / 'backup_full_test.db.gz'
            db_backup.write_bytes(b'test-backup-data')

            shared_dir = Path(temp_dir) / 'shared-data'
            shared_dir.mkdir(parents=True, exist_ok=True)
            (shared_dir / 'asset.json').write_text('{"ok":true}', encoding='utf-8')

            mock_backup_info = {
                'filename': db_backup.name,
                'filepath': str(db_backup),
                'backup_type': 'full',
                'database_type': 'sqlite',
                'database_name': 'test.db',
                'timestamp': '2026-03-02T00:00:00',
                'size_bytes': db_backup.stat().st_size,
                'compressed': True,
                'encrypted': False,
                'checksum': _sha256(db_backup),
            }

            def _mock_security_setting(key, default=None):
                if key == 'backup_encrypt':
                    return False
                if key == 'backup_include_shared_data':
                    return True
                if key == 'backup_shared_data_paths':
                    return str(shared_dir)
                return default

            with patch.object(manager, '_backup_sqlite', return_value=mock_backup_info), \
                 patch('security_settings.get_security_setting', side_effect=_mock_security_setting):
                result = manager.create_backup(
                    backup_type='full',
                    compress=True,
                    encrypt=False,
                    include_metadata=True,
                )

            verification = manager.verify_backup(result['filepath'])
            self.assertTrue(verification['valid'])
            self.assertTrue(verification['shared_data_valid'])

            shared_archive_path = Path(result['shared_data_backup']['archive_filepath'])
            with open(shared_archive_path, 'ab') as archive_file:
                archive_file.write(b'corruption')

            verification_after_corruption = manager.verify_backup(result['filepath'])
            self.assertFalse(verification_after_corruption['valid'])
            self.assertFalse(verification_after_corruption['shared_data_valid'])


if __name__ == '__main__':
    unittest.main()
