#!/usr/bin/env python3
"""Regression tests for database encryption-at-rest column coverage."""

import sys
import unittest
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.database import Hypervisor, FleetAgent, Server
from models.encrypted_field import EncryptedField


class TestDatabaseEncryptionColumns(unittest.TestCase):
    def test_server_password_uses_encrypted_field(self):
        self.assertIsInstance(Server.__table__.c.password.type, EncryptedField)

    def test_hypervisor_credentials_use_encrypted_field(self):
        self.assertIsInstance(Hypervisor.__table__.c.password.type, EncryptedField)
        self.assertIsInstance(Hypervisor.__table__.c.api_token.type, EncryptedField)

    def test_fleet_agent_sensitive_fields_use_encrypted_field(self):
        self.assertIsInstance(FleetAgent.__table__.c.registration_token.type, EncryptedField)
        self.assertIsInstance(FleetAgent.__table__.c.connection_config.type, EncryptedField)


if __name__ == '__main__':
    unittest.main()
