#!/usr/bin/env python3
"""Functional tests for database cleanup retention logic."""

import ast
import copy
import sys
import types
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

from sqlalchemy import Column, DateTime, Integer, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker


class _Logger:
    @staticmethod
    def info(*_args, **_kwargs):
        return None

    @staticmethod
    def debug(*_args, **_kwargs):
        return None

    @staticmethod
    def warning(*_args, **_kwargs):
        return None

    @staticmethod
    def error(*_args, **_kwargs):
        return None


class TestDbCleanupFunctional(unittest.TestCase):
    """Exercise cleanup_old_results against an in-memory SQLite database."""

    @classmethod
    def setUpClass(cls):
        source_path = Path(__file__).resolve().parents[1] / 'tasks' / 'audit_tasks.py'
        source = source_path.read_text(encoding='utf-8')
        tree = ast.parse(source)

        target_fn = None
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name == 'cleanup_old_results':
                target_fn = copy.deepcopy(node)
                break

        if target_fn is None:
            raise RuntimeError('cleanup_old_results function not found in tasks/audit_tasks.py')

        target_fn.decorator_list = []
        module = ast.Module(body=[target_fn], type_ignores=[])
        ast.fix_missing_locations(module)

        cls.compiled_module = compile(module, str(source_path), 'exec')

    def _build_runtime(self):
        Base = declarative_base()

        class AuditExecution(Base):
            __tablename__ = 'audit_executions'
            id = Column(Integer, primary_key=True, autoincrement=True)
            executed_at = Column(DateTime, nullable=False, index=True)

        class HypervisorAuditExecution(Base):
            __tablename__ = 'hypervisor_audit_executions'
            id = Column(Integer, primary_key=True, autoincrement=True)
            started_at = Column(DateTime, nullable=False, index=True)

        engine = create_engine('sqlite:///:memory:')
        Base.metadata.create_all(engine)
        SessionLocal = sessionmaker(bind=engine)

        namespace = {
            'datetime': datetime,
            'timedelta': timedelta,
            'SessionLocal': SessionLocal,
            'AuditExecution': AuditExecution,
            'HypervisorAuditExecution': HypervisorAuditExecution,
            'logger': _Logger(),
        }
        exec(self.compiled_module, namespace)  # nosec B102 - controlled test harness executes precompiled in-repo AST
        return namespace, SessionLocal, AuditExecution, HypervisorAuditExecution

    def test_cleanup_applies_independent_audit_and_hypervisor_retention(self):
        namespace, SessionLocal, AuditExecution, HypervisorAuditExecution = self._build_runtime()
        db = SessionLocal()
        now = datetime.utcnow()

        db.add_all([
            AuditExecution(executed_at=now - timedelta(days=100)),
            AuditExecution(executed_at=now - timedelta(days=8)),
            AuditExecution(executed_at=now - timedelta(days=6)),
            AuditExecution(executed_at=now - timedelta(days=4)),
            AuditExecution(executed_at=now - timedelta(days=2)),
        ])

        db.add_all([
            HypervisorAuditExecution(started_at=now - timedelta(days=60)),
            HypervisorAuditExecution(started_at=now - timedelta(days=9)),
            HypervisorAuditExecution(started_at=now - timedelta(days=7)),
            HypervisorAuditExecution(started_at=now - timedelta(days=5)),
            HypervisorAuditExecution(started_at=now - timedelta(days=3)),
            HypervisorAuditExecution(started_at=now - timedelta(days=1)),
        ])
        db.commit()
        db.close()

        result = namespace['cleanup_old_results'](
            days=30,
            max_records=2,
            hypervisor_days=10,
            hypervisor_max_records=3,
        )

        self.assertEqual(result['audit_executions']['deleted_by_age'], 1)
        self.assertEqual(result['audit_executions']['deleted_by_count'], 2)
        self.assertEqual(result['audit_executions']['remaining'], 2)

        self.assertEqual(result['hypervisor_audit_executions']['deleted_by_age'], 1)
        self.assertEqual(result['hypervisor_audit_executions']['deleted_by_count'], 2)
        self.assertEqual(result['hypervisor_audit_executions']['remaining'], 3)

        self.assertEqual(result['deleted_count'], 6)

        check_db = SessionLocal()
        self.assertEqual(check_db.query(AuditExecution).count(), 2)
        self.assertEqual(check_db.query(HypervisorAuditExecution).count(), 3)
        check_db.close()

    def test_hypervisor_limits_default_to_audit_limits_when_unspecified(self):
        namespace, SessionLocal, AuditExecution, HypervisorAuditExecution = self._build_runtime()
        db = SessionLocal()
        now = datetime.utcnow()

        db.add_all([
            AuditExecution(executed_at=now - timedelta(days=50)),
            AuditExecution(executed_at=now - timedelta(days=2)),
            AuditExecution(executed_at=now - timedelta(days=1)),
        ])
        db.add_all([
            HypervisorAuditExecution(started_at=now - timedelta(days=50)),
            HypervisorAuditExecution(started_at=now - timedelta(days=2)),
            HypervisorAuditExecution(started_at=now - timedelta(days=1)),
        ])
        db.commit()
        db.close()

        stub_module = types.ModuleType('security_settings')
        stub_module.get_audit_execution_settings = lambda: {
            'retention_days': 30,
            'max_records': 1,
        }

        with patch.dict(sys.modules, {'security_settings': stub_module}):
            result = namespace['cleanup_old_results'](
                days=30,
                max_records=1,
                hypervisor_days=None,
                hypervisor_max_records=None,
            )

        self.assertEqual(result['hypervisor_days'], 30)
        self.assertEqual(result['hypervisor_max_records'], 1)

        check_db = SessionLocal()
        self.assertEqual(check_db.query(AuditExecution).count(), 1)
        self.assertEqual(check_db.query(HypervisorAuditExecution).count(), 1)
        check_db.close()


if __name__ == '__main__':
    unittest.main()
