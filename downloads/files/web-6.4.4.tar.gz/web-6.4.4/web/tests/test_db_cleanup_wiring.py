#!/usr/bin/env python3
"""Validate database cleanup wiring for execution history growth controls."""

import ast
import unittest
from pathlib import Path


class TestDatabaseCleanupWiring(unittest.TestCase):
    """Ensure cleanup and telemetry include both standard and hypervisor execution tables."""

    ROOT = Path(__file__).resolve().parents[1]

    def _parse_module(self, relative_path: str) -> ast.Module:
        module_path = self.ROOT / relative_path
        source = module_path.read_text(encoding='utf-8')
        return ast.parse(source)

    def _get_function_node(self, tree: ast.Module, function_name: str) -> ast.FunctionDef:
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name == function_name:
                return node
        self.fail(f"Function {function_name} not found")

    def _function_contains_name(self, fn: ast.FunctionDef, target_name: str) -> bool:
        for node in ast.walk(fn):
            if isinstance(node, ast.Name) and node.id == target_name:
                return True
        return False

    def _function_contains_constant(self, fn: ast.FunctionDef, target_constant: str) -> bool:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value == target_constant:
                return True
        return False

    def test_cleanup_old_results_includes_hypervisor_execution_model(self):
        tree = self._parse_module('tasks/audit_tasks.py')
        fn = self._get_function_node(tree, 'cleanup_old_results')
        self.assertTrue(
            self._function_contains_name(fn, 'HypervisorAuditExecution'),
            'cleanup_old_results must include HypervisorAuditExecution pruning',
        )

    def test_cleanup_old_results_reads_hypervisor_retention_settings(self):
        tree = self._parse_module('tasks/audit_tasks.py')
        fn = self._get_function_node(tree, 'cleanup_old_results')
        self.assertTrue(
            self._function_contains_constant(fn, 'hypervisor_retention_days'),
            'cleanup_old_results must read hypervisor_retention_days from settings',
        )
        self.assertTrue(
            self._function_contains_constant(fn, 'hypervisor_max_records'),
            'cleanup_old_results must read hypervisor_max_records from settings',
        )

    def test_storage_pressure_includes_hypervisor_execution_count(self):
        tree = self._parse_module('api/dashboard_routes.py')
        fn = self._get_function_node(tree, 'get_storage_pressure')
        self.assertTrue(
            self._function_contains_name(fn, 'HypervisorAuditExecution'),
            'get_storage_pressure must include HypervisorAuditExecution telemetry',
        )

    def test_storage_pressure_includes_db_size_fields(self):
        tree = self._parse_module('api/dashboard_routes.py')
        fn = self._get_function_node(tree, 'get_storage_pressure')
        self.assertTrue(
            self._function_contains_constant(fn, 'physical_size_bytes'),
            'get_storage_pressure must include physical_size_bytes in database payload',
        )
        self.assertTrue(
            self._function_contains_constant(fn, 'db_engine'),
            'get_storage_pressure must include db_engine in database payload',
        )


if __name__ == '__main__':
    unittest.main()
