#!/usr/bin/env python3
"""Regression coverage for deployment center link wiring."""

import unittest
from pathlib import Path


class TestDeployPageLinkWiring(unittest.TestCase):
    ROOT = Path(__file__).resolve().parents[1]

    def test_deploy_template_exposes_new_standalone_helpers_and_vmdk(self):
        source = (self.ROOT / 'templates' / 'deploy.html').read_text(encoding='utf-8')

        # VM appliance images (OVA/OVF/VMDK) are now served via GitHub Releases
        # and the Customer Release Portal, not directly from the deploy page.
        self.assertIn("downloadStandaloneScript('jea-session-config')", source)
        self.assertIn("downloadStandaloneScript('jea-role-full')", source)
        self.assertIn("downloadStandaloneScript('jea-role-readonly')", source)
        self.assertIn("downloadStandaloneScript('run-audit-wrapper')", source)
        self.assertIn("downloadStandaloneScript('run-audit-jer')", source)
        self.assertIn("downloadStandaloneScript('invoke-security-audit-jea')", source)
        self.assertIn("downloadStandaloneScript('winrm-jea-wrapper-bundle')", source)
        self.assertIn("downloadStandaloneScript('ssh-sudo-wrapper-bundle')", source)

    def test_shared_script_uses_current_windows_install_path_and_helper_map(self):
        source = (self.ROOT / 'static' / 'script.js').read_text(encoding='utf-8')

        self.assertIn(r'C:\Program Files\SecurityAuditToolkit', source)
        self.assertIn("'winrm-jea-wrapper-bundle': 'windows-jea-winrm-wrapper-bundle.zip'", source)
        self.assertIn("'ssh-sudo-wrapper-bundle': 'linux-ssh-sudo-wrapper-bundle.tar.gz'", source)
        self.assertIn("'invoke-security-audit-jea': 'Invoke-SecurityAuditJEA.ps1'", source)


if __name__ == '__main__':
    unittest.main()
