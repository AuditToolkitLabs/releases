#!/usr/bin/env python3
"""Regression tests for VM split artifact detection/reassembly."""

import json
import hashlib
import sys
import tempfile
import unittest
from pathlib import Path
from flask import Flask

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from api import deploy_routes


class TestDeployVMSplitArtifact(unittest.TestCase):
    """Ensure split-part handling excludes manifest files and reassembles correctly."""

    def test_find_split_parts_ignores_manifest_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            output_dir = root / 'deployment' / 'vm-appliance' / 'output'
            output_dir.mkdir(parents=True, exist_ok=True)

            version = '9.9.9-test'
            base_name = f'security-audit-toolkit-{version}.ova'
            target = output_dir / base_name

            payload = b'A' * 128 + b'B' * 128 + b'C' * 128
            parts = [payload[:128], payload[128:256], payload[256:]]
            for index, part in enumerate(parts, start=1):
                (output_dir / f'{base_name}.part{index:03d}').write_bytes(part)

            manifest = {
                'source_file': base_name,
                'source_size_bytes': len(payload),
                'source_sha256': hashlib.sha256(payload).hexdigest(),
                'total_parts': len(parts),
            }
            (output_dir / f'{base_name}.parts.json').write_text(
                json.dumps(manifest), encoding='utf-8'
            )

            original_root = deploy_routes.ROOT_DIR
            original_version = deploy_routes._get_toolkit_version
            try:
                deploy_routes.ROOT_DIR = str(root)
                deploy_routes._get_toolkit_version = lambda: version

                split_target, split_parts, split_manifest = deploy_routes._find_vm_split_artifact_parts('ova')

                self.assertEqual(split_target, target)
                self.assertEqual(len(split_parts), 3)
                self.assertTrue(all(part.name.endswith(('part001', 'part002', 'part003')) for part in split_parts))
                self.assertIsNotNone(split_manifest)
                self.assertEqual(split_manifest.name, f'{base_name}.parts.json')
            finally:
                deploy_routes.ROOT_DIR = original_root
                deploy_routes._get_toolkit_version = original_version

    def test_package_status_reports_split_source_and_part_counts(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            output_dir = root / 'deployment' / 'vm-appliance' / 'output'
            output_dir.mkdir(parents=True, exist_ok=True)

            version = '9.9.9-test'
            split_specs = {
                'ova': 2,
                'ovf': 3,
                'vmdk': 4,
            }

            for ext, part_count in split_specs.items():
                base_name = f'security-audit-toolkit-{version}.{ext}'
                payload = (f'{ext}-PAYLOAD-'.encode('utf-8') * 120)
                chunk_size = max(1, len(payload) // part_count)
                parts = [payload[i:i + chunk_size] for i in range(0, len(payload), chunk_size)]
                parts = parts[:part_count - 1] + [b''.join(parts[part_count - 1:])]

                for index, part in enumerate(parts, start=1):
                    (output_dir / f'{base_name}.part{index:03d}').write_bytes(part)

                manifest = {
                    'source_file': base_name,
                    'source_size_bytes': len(payload),
                    'source_sha256': hashlib.sha256(payload).hexdigest(),
                    'total_parts': len(parts),
                }
                (output_dir / f'{base_name}.parts.json').write_text(
                    json.dumps(manifest), encoding='utf-8'
                )

            original_root = deploy_routes.ROOT_DIR
            original_version = deploy_routes._get_toolkit_version
            try:
                deploy_routes.ROOT_DIR = str(root)
                deploy_routes._get_toolkit_version = lambda: version

                status_fn = deploy_routes.get_deploy_package_status
                while hasattr(status_fn, '__wrapped__'):
                    status_fn = status_fn.__wrapped__

                app = Flask(__name__)
                with app.test_request_context('/api/deploy/package-status'):
                    payload = status_fn().get_json()

                vm = payload['vm_appliance']
                self.assertTrue(vm['ova']['available'])
                self.assertEqual(vm['ova']['source'], 'split')
                self.assertEqual(vm['ova']['split_parts'], 2)

                self.assertTrue(vm['ovf']['available'])
                self.assertEqual(vm['ovf']['source'], 'split')
                self.assertEqual(vm['ovf']['split_parts'], 3)

                self.assertTrue(vm['vmdk']['available'])
                self.assertEqual(vm['vmdk']['source'], 'split')
                self.assertEqual(vm['vmdk']['split_parts'], 4)
            finally:
                deploy_routes.ROOT_DIR = original_root
                deploy_routes._get_toolkit_version = original_version

    def test_resolve_prefers_full_artifact_over_split_parts(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            output_dir = root / 'deployment' / 'vm-appliance' / 'output'
            output_dir.mkdir(parents=True, exist_ok=True)

            version = '9.9.9-test'
            base_name = f'security-audit-toolkit-{version}.ova'
            target = output_dir / base_name

            full_payload = b'FULL-ARTIFACT-CONTENT'
            target.write_bytes(full_payload)

            split_payload = b'SPLIT-ONE' + b'SPLIT-TWO' + b'SPLIT-THREE'
            parts = [split_payload[:9], split_payload[9:18], split_payload[18:]]
            for index, part in enumerate(parts, start=1):
                (output_dir / f'{base_name}.part{index:03d}').write_bytes(part)

            manifest = {
                'source_file': base_name,
                'source_size_bytes': len(split_payload),
                'source_sha256': hashlib.sha256(split_payload).hexdigest(),
                'total_parts': len(parts),
            }
            (output_dir / f'{base_name}.parts.json').write_text(
                json.dumps(manifest), encoding='utf-8'
            )

            original_root = deploy_routes.ROOT_DIR
            original_version = deploy_routes._get_toolkit_version
            try:
                deploy_routes.ROOT_DIR = str(root)
                deploy_routes._get_toolkit_version = lambda: version

                resolved_path, info = deploy_routes._resolve_vm_appliance_artifact('ova', allow_reassemble=False)

                self.assertEqual(resolved_path, target)
                self.assertEqual(info.get('source'), 'local')
                self.assertEqual(info.get('split_parts'), 0)
                self.assertFalse(info.get('reassembled'))
                self.assertEqual(target.read_bytes(), full_payload)
            finally:
                deploy_routes.ROOT_DIR = original_root
                deploy_routes._get_toolkit_version = original_version

    def test_resolve_split_artifact_reassembles_successfully(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            output_dir = root / 'deployment' / 'vm-appliance' / 'output'
            output_dir.mkdir(parents=True, exist_ok=True)

            version = '9.9.9-test'
            base_name = f'security-audit-toolkit-{version}.ovf'
            target = output_dir / base_name

            payload = b'OVF-CONTENT-' * 200
            boundaries = [0, len(payload) // 3, (2 * len(payload)) // 3, len(payload)]
            parts = [payload[boundaries[i]:boundaries[i + 1]] for i in range(3)]
            for index, part in enumerate(parts, start=1):
                (output_dir / f'{base_name}.part{index:03d}').write_bytes(part)

            manifest = {
                'source_file': base_name,
                'source_size_bytes': len(payload),
                'source_sha256': hashlib.sha256(payload).hexdigest(),
                'total_parts': len(parts),
            }
            (output_dir / f'{base_name}.parts.json').write_text(
                json.dumps(manifest), encoding='utf-8'
            )

            original_root = deploy_routes.ROOT_DIR
            original_version = deploy_routes._get_toolkit_version
            try:
                deploy_routes.ROOT_DIR = str(root)
                deploy_routes._get_toolkit_version = lambda: version

                resolved_path, info = deploy_routes._resolve_vm_appliance_artifact('ovf', allow_reassemble=True)

                self.assertEqual(info.get('source'), 'split')
                self.assertEqual(info.get('split_parts'), 3)
                self.assertTrue(info.get('reassembled'))
                self.assertEqual(resolved_path, target)
                self.assertTrue(target.exists())
                self.assertEqual(target.read_bytes(), payload)
            finally:
                deploy_routes.ROOT_DIR = original_root
                deploy_routes._get_toolkit_version = original_version


if __name__ == '__main__':
    unittest.main()
