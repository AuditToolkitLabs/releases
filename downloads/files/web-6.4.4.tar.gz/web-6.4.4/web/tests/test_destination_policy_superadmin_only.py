from pathlib import Path


def test_destination_policy_routes_are_superadmin_only() -> None:
    source = (Path(__file__).resolve().parents[1] / "api" / "admin_routes.py").read_text(encoding="utf-8")

    assert "@admin_bp.route('/destination-policy-page', methods=['GET'])\n@login_required\n@require_role('SuperAdmin')" in source
    assert "@admin_bp.route('/settings/destination-policy', methods=['GET'])\n@login_required\n@require_role('SuperAdmin')" in source
    assert "@admin_bp.route('/settings/destination-policy', methods=['POST', 'PUT'])\n@login_required\n@require_role('SuperAdmin')" in source
    assert "@admin_bp.route('/settings/destination-policy/logs', methods=['GET'])\n@login_required\n@require_role('SuperAdmin')" in source
