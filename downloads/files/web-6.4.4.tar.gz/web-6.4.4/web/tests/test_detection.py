"""
Unit tests for detection.py - OS Detection Module

Tests cover:
- Linux detection via SSH
- Windows detection via WinRM
- Automatic fallback (SSH -> WinRM)
- OS release file parsing
- Windows version mapping
- Error handling and edge cases
- OSDetectionError scenarios
"""

import pytest
from unittest.mock import Mock, MagicMock, patch, mock_open
import sys
import os
import json

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from detection import (
    detect_server_os,
    OSDetectionError,
    _detect_via_ssh,
    _detect_via_winrm,
    _parse_os_release,
    _get_windows_edition,
    get_os_version_friendly
)


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def sample_ubuntu_os_release():
    """Sample /etc/os-release from Ubuntu 22.04"""
    return """
NAME="Ubuntu"
VERSION="22.04.1 LTS (Jammy Jellyfish)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 22.04.1 LTS"
VERSION_ID="22.04"
VERSION_CODENAME=jammy
"""


@pytest.fixture
def sample_rhel_os_release():
    """Sample /etc/os-release from RHEL 8"""
    return """
NAME="Red Hat Enterprise Linux"
VERSION="8.5 (Ootpa)"
ID="rhel"
ID_LIKE="fedora"
VERSION_ID="8.5"
PRETTY_NAME="Red Hat Enterprise Linux 8.5 (Ootpa)"
"""


@pytest.fixture
def sample_windows_os_info():
    """Sample Windows OS information from WMI"""
    return {
        'Caption': 'Microsoft Windows Server 2019 Datacenter',
        'Version': '10.0.17763',
        'BuildNumber': '17763',
        'Architecture': '64-bit',
        'ServicePackMajor': 0,
        'ServicePackMinor': 0,
        'ProductType': 3,
        'Domain': 'WORKGROUP',
        'PartOfDomain': False,
        'Manufacturer': 'Dell Inc.',
        'Model': 'PowerEdge R640'
    }


@pytest.fixture
def sample_windows_domain_info():
    """Sample Windows domain member information"""
    return {
        'Caption': 'Microsoft Windows Server 2019 Standard',
        'Version': '10.0.17763',
        'BuildNumber': '17763',
        'Architecture': '64-bit',
        'ServicePackMajor': 0,
        'ServicePackMinor': 0,
        'ProductType': 3,
        'Domain': 'EXAMPLE.COM',
        'PartOfDomain': True,
        'Manufacturer': 'VMware, Inc.',
        'Model': 'VMware7,1'
    }


# ============================================================================
# OS Release Parsing Tests
# ============================================================================

class TestOSReleaseParsing:
    """Test /etc/os-release file parsing"""
    
    def test_parse_ubuntu_os_release(self, sample_ubuntu_os_release):
        """Test parsing Ubuntu os-release"""
        result = _parse_os_release(sample_ubuntu_os_release)
        
        assert result['NAME'] == 'Ubuntu'
        assert result['VERSION_ID'] == '22.04'
        assert result['ID'] == 'ubuntu'
        assert result['PRETTY_NAME'] == 'Ubuntu 22.04.1 LTS'
        assert result['VERSION_CODENAME'] == 'jammy'
    
    def test_parse_rhel_os_release(self, sample_rhel_os_release):
        """Test parsing RHEL os-release"""
        result = _parse_os_release(sample_rhel_os_release)
        
        assert result['NAME'] == 'Red Hat Enterprise Linux'
        assert result['VERSION_ID'] == '8.5'
        assert result['ID'] == 'rhel'
    
    def test_parse_empty_os_release(self):
        """Test parsing empty os-release file"""
        result = _parse_os_release('')
        
        assert isinstance(result, dict)
        assert len(result) == 0
    
    def test_parse_os_release_with_comments(self):
        """Test parsing os-release with comments"""
        content = """
# This is a comment
NAME="Test OS"
# Another comment
VERSION="1.0"
"""
        result = _parse_os_release(content)
        
        assert result['NAME'] == 'Test OS'
        assert result['VERSION'] == '1.0'
        assert len(result) == 2
    
    def test_parse_os_release_with_single_quotes(self):
        """Test parsing values with single quotes"""
        content = "NAME='Debian'\nVERSION='11'"
        result = _parse_os_release(content)
        
        assert result['NAME'] == 'Debian'
        assert result['VERSION'] == '11'
    
    def test_parse_os_release_without_quotes(self):
        """Test parsing values without quotes"""
        content = "ID=debian\nVERSION_ID=11"
        result = _parse_os_release(content)
        
        assert result['ID'] == 'debian'
        assert result['VERSION_ID'] == '11'


# ============================================================================
# Windows Edition Detection Tests
# ============================================================================

class TestWindowsEditionDetection:
    """Test Windows edition detection from product type"""
    
    def test_workstation_windows_10(self):
        """Test Windows 10 workstation detection"""
        edition = _get_windows_edition(1, 'Microsoft Windows 10 Professional')
        assert 'Windows 10' in edition
        assert 'Workstation' in edition
    
    def test_workstation_windows_11(self):
        """Test Windows 11 workstation detection"""
        edition = _get_windows_edition(1, 'Microsoft Windows 11 Pro')
        assert 'Windows 11' in edition
        assert 'Workstation' in edition
    
    def test_domain_controller(self):
        """Test Domain Controller detection"""
        edition = _get_windows_edition(2, 'Windows Server 2019 Datacenter')
        assert edition == 'Domain Controller'
    
    def test_server_datacenter(self):
        """Test Server Datacenter edition"""
        edition = _get_windows_edition(3, 'Windows Server 2019 Datacenter')
        assert 'Datacenter' in edition
    
    def test_server_standard(self):
        """Test Server Standard edition"""
        edition = _get_windows_edition(3, 'Windows Server 2022 Standard')
        assert 'Standard' in edition
    
    def test_server_essentials(self):
        """Test Server Essentials edition"""
        edition = _get_windows_edition(3, 'Windows Server 2016 Essentials')
        assert 'Essentials' in edition
    
    def test_generic_server(self):
        """Test generic server without specific edition"""
        edition = _get_windows_edition(3, 'Windows Server')
        assert edition == 'Windows Server'


# ============================================================================
# SSH Detection Tests
# ============================================================================

class TestSSHDetection:
    """Test Linux/Unix detection via SSH"""
    
    @patch('detection.paramiko.SSHClient')
    def test_detect_via_ssh_ubuntu(self, mock_ssh_client, sample_ubuntu_os_release):
        """Test detecting Ubuntu via SSH"""
        mock_ssh = MagicMock()
        mock_ssh_client.return_value = mock_ssh
        
        # Mock command execution
        mock_os_release = MagicMock()
        mock_os_release.read.return_value = sample_ubuntu_os_release.encode('utf-8')
        
        mock_arch = MagicMock()
        mock_arch.read.return_value = b'x86_64\n'
        
        mock_kernel = MagicMock()
        mock_kernel.read.return_value = b'5.15.0-58-generic\n'
        
        mock_ssh.exec_command.side_effect = [
            (None, mock_os_release, None),
            (None, mock_arch, None),
            (None, mock_kernel, None)
        ]
        
        result = _detect_via_ssh('test.local', 22, 'user', 'password', 10)
        
        assert result['type'] == 'linux'
        assert 'Ubuntu' in result['name']
        assert result['version'] == '22.04'
        assert result['architecture'] == 'x86_64'
        assert result['protocol'] == 'ssh'
        assert result['port'] == 22
        assert result['distro_id'] == 'ubuntu'
    
    @patch('detection.paramiko.SSHClient')
    def test_detect_via_ssh_with_key_auth(self, mock_ssh_client, sample_ubuntu_os_release):
        """Test SSH detection with SSH key authentication"""
        mock_ssh = MagicMock()
        mock_ssh_client.return_value = mock_ssh
        
        mock_os_release = MagicMock()
        mock_os_release.read.return_value = sample_ubuntu_os_release.encode('utf-8')
        mock_arch = MagicMock()
        mock_arch.read.return_value = b'x86_64\n'
        mock_kernel = MagicMock()
        mock_kernel.read.return_value = b'5.15.0\n'
        
        mock_ssh.exec_command.side_effect = [
            (None, mock_os_release, None),
            (None, mock_arch, None),
            (None, mock_kernel, None)
        ]
        
        result = _detect_via_ssh('test.local', 22, 'user', '/path/to/key.pem', 10)
        
        # Verify key authentication was used
        call_kwargs = mock_ssh.connect.call_args[1]
        assert call_kwargs['key_filename'] == '/path/to/key.pem'
        assert result['type'] == 'linux'
    
    @patch('detection.paramiko.SSHClient')
    def test_detect_via_ssh_connection_failure(self, mock_ssh_client):
        """Test SSH detection with connection failure"""
        mock_ssh = MagicMock()
        mock_ssh.connect.side_effect = Exception("Connection refused")
        mock_ssh_client.return_value = mock_ssh
        
        with pytest.raises(Exception, match="Connection refused"):
            _detect_via_ssh('test.local', 22, 'user', 'password', 10)
    
    @patch('detection.paramiko.SSHClient')
    def test_detect_via_ssh_timeout(self, mock_ssh_client):
        """Test SSH detection timeout"""
        mock_ssh = MagicMock()
        mock_ssh.connect.side_effect = TimeoutError("Connection timeout")
        mock_ssh_client.return_value = mock_ssh
        
        with pytest.raises(TimeoutError):
            _detect_via_ssh('test.local', 22, 'user', 'password', 10)


# ============================================================================
# WinRM Detection Tests
# ============================================================================

class TestWinRMDetection:
    """Test Windows detection via WinRM"""
    
    @patch('detection.Client')
    def test_detect_via_winrm_server_2019(self, mock_client, sample_windows_os_info):
        """Test detecting Windows Server 2019 via WinRM"""
        mock_client_instance = MagicMock()
        mock_client_instance.execute_ps.return_value = (
            json.dumps(sample_windows_os_info),
            MagicMock(error=[]),
            False
        )
        mock_client.return_value = mock_client_instance
        
        result = _detect_via_winrm('test.local', 5985, 'Administrator', 'password', False, 10)
        
        assert result['type'] == 'windows'
        assert 'Windows Server 2019' in result['name']
        assert result['version'] == '10.0.17763'
        assert result['build'] == '17763'
        assert result['architecture'] == '64'
        assert result['protocol'] == 'winrm'
        assert result['port'] == 5985
        assert result['ssl'] is False
    
    @patch('detection.Client')
    def test_detect_via_winrm_domain_member(self, mock_client, sample_windows_domain_info):
        """Test detecting domain-joined Windows server"""
        mock_client_instance = MagicMock()
        mock_client_instance.execute_ps.return_value = (
            json.dumps(sample_windows_domain_info),
            MagicMock(error=[]),
            False
        )
        mock_client.return_value = mock_client_instance
        
        result = _detect_via_winrm('test.local', 5985, 'admin', 'password', False, 10)
        
        assert result['type'] == 'windows'
        assert result['domain'] == 'EXAMPLE.COM'
        assert result['edition'] == 'Windows Server Standard'
    
    @patch('detection.Client')
    def test_detect_via_winrm_https(self, mock_client, sample_windows_os_info):
        """Test WinRM detection with HTTPS"""
        mock_client_instance = MagicMock()
        mock_client_instance.execute_ps.return_value = (
            json.dumps(sample_windows_os_info),
            MagicMock(error=[]),
            False
        )
        mock_client.return_value = mock_client_instance
        
        result = _detect_via_winrm('test.local', 5986, 'admin', 'password', True, 10)
        
        assert result['port'] == 5986
        assert result['ssl'] is True
    
    @patch('detection.Client')
    def test_detect_via_winrm_auth_methods(self, mock_client, sample_windows_os_info):
        """Test WinRM tries multiple auth methods"""
        # First auth method fails, second succeeds
        mock_client_instance_fail = MagicMock()
        mock_client_instance_fail.execute_ps.side_effect = Exception("Auth failed")
        
        mock_client_instance_success = MagicMock()
        mock_client_instance_success.execute_ps.return_value = (
            json.dumps(sample_windows_os_info),
            MagicMock(error=[]),
            False
        )
        
        mock_client.side_effect = [mock_client_instance_fail, mock_client_instance_success]
        
        result = _detect_via_winrm('test.local', 5985, 'admin', 'password', False, 10)
        
        assert result['type'] == 'windows'
        # Verify multiple auth attempts were made
        assert mock_client.call_count == 2
    
    @patch('detection.Client')
    def test_detect_via_winrm_all_auth_fail(self, mock_client):
        """Test WinRM detection when all auth methods fail"""
        mock_client_instance = MagicMock()
        mock_client_instance.execute_ps.side_effect = Exception("Auth failed")
        mock_client.return_value = mock_client_instance
        
        with pytest.raises(Exception, match="WinRM detection failed"):
            _detect_via_winrm('test.local', 5985, 'admin', 'wrong_password', False, 10)


# ============================================================================
# Automatic Detection Tests (SSH -> WinRM Fallback)
# ============================================================================

class TestAutomaticDetection:
    """Test automatic OS detection with fallback"""
    
    @patch('detection._detect_via_ssh')
    def test_detect_linux_via_ssh(self, mock_ssh_detect):
        """Test successful Linux detection via SSH"""
        mock_ssh_detect.return_value = {
            'type': 'linux',
            'name': 'Ubuntu 22.04 LTS',
            'version': '22.04',
            'architecture': 'x86_64',
            'protocol': 'ssh',
            'port': 22
        }
        
        result = detect_server_os('test.local', username='user', credential='password')
        
        assert result['type'] == 'linux'
        assert result['protocol'] == 'ssh'
        mock_ssh_detect.assert_called_once()
    
    @patch('detection._detect_via_winrm')
    @patch('detection._detect_via_ssh')
    def test_fallback_to_winrm_after_ssh_fail(self, mock_ssh_detect, mock_winrm_detect):
        """Test fallback to WinRM when SSH fails"""
        # SSH fails
        mock_ssh_detect.side_effect = Exception("SSH connection refused")
        
        # WinRM succeeds
        mock_winrm_detect.return_value = {
            'type': 'windows',
            'name': 'Windows Server 2019',
            'version': '10.0.17763',
            'protocol': 'winrm',
            'port': 5985
        }
        
        result = detect_server_os('test.local', username='admin', credential='password')
        
        assert result['type'] == 'windows'
        assert result['protocol'] == 'winrm'
        mock_ssh_detect.assert_called_once()
        mock_winrm_detect.assert_called()
    
    @patch('detection._detect_via_winrm')
    @patch('detection._detect_via_ssh')
    def test_all_detection_methods_fail(self, mock_ssh_detect, mock_winrm_detect):
        """Test OSDetectionError when all methods fail"""
        mock_ssh_detect.side_effect = Exception("SSH failed")
        mock_winrm_detect.side_effect = Exception("WinRM failed")
        
        with pytest.raises(OSDetectionError) as exc_info:
            detect_server_os('unreachable.local', username='user', credential='password')
        
        error_message = str(exc_info.value)
        assert 'Unable to connect' in error_message
        assert 'SSH' in error_message or 'WinRM' in error_message
    
    @patch('detection._detect_via_ssh')
    def test_explicit_ssh_port(self, mock_ssh_detect):
        """Test detection with explicit SSH port"""
        mock_ssh_detect.return_value = {
            'type': 'linux',
            'name': 'Ubuntu',
            'protocol': 'ssh',
            'port': 22
        }
        
        result = detect_server_os('test.local', port=22, username='user', credential='pass')
        
        # Verify SSH was called with port 22
        call_kwargs = mock_ssh_detect.call_args[1]
        assert call_kwargs['port'] == 22
    
    @patch('detection._detect_via_winrm')
    def test_explicit_winrm_port(self, mock_winrm_detect):
        """Test detection with explicit WinRM port"""
        mock_winrm_detect.return_value = {
            'type': 'windows',
            'name': 'Windows Server',
            'protocol': 'winrm',
            'port': 5986
        }
        
        result = detect_server_os('test.local', port=5986, username='admin', credential='pass')
        
        # Verify WinRM was called with port 5986 (HTTPS)
        call_kwargs = mock_winrm_detect.call_args[1]
        assert call_kwargs['port'] == 5986
        assert call_kwargs['use_ssl'] == True


# ============================================================================
# Friendly Version String Tests
# ============================================================================

class TestFriendlyVersionString:
    """Test human-friendly OS version strings"""
    
    def test_windows_server_2019_friendly(self):
        """Test friendly version for Windows Server 2019"""
        os_info = {
            'type': 'windows',
            'name': 'Microsoft Windows Server 2019 Datacenter',
            'build': '17763'
        }
        
        friendly = get_os_version_friendly(os_info)
        assert 'Windows' in friendly
        assert 'Server 2019' in friendly
    
    def test_windows_server_2022_friendly(self):
        """Test friendly version for Windows Server 2022"""
        os_info = {
            'type': 'windows',
            'name': 'Windows Server 2022 Standard',
            'build': '20348'
        }
        
        friendly = get_os_version_friendly(os_info)
        assert 'Server 2022' in friendly
    
    def test_windows_10_friendly(self):
        """Test friendly version for Windows 10"""
        os_info = {
            'type': 'windows',
            'name': 'Windows 10 Pro',
            'build': '19044'
        }
        
        friendly = get_os_version_friendly(os_info)
        assert 'Windows 10' in friendly
    
    def test_linux_friendly(self):
        """Test friendly version for Linux"""
        os_info = {
            'type': 'linux',
            'name': 'Ubuntu 22.04 LTS'
        }
        
        friendly = get_os_version_friendly(os_info)
        assert friendly == 'Ubuntu 22.04 LTS'
    
    def test_unknown_build_windows(self):
        """Test friendly version with unknown Windows build"""
        os_info = {
            'type': 'windows',
            'name': 'Windows Server',
            'build': '99999'
        }
        
        friendly = get_os_version_friendly(os_info)
        assert 'Build 99999' in friendly


# ============================================================================
# Edge Cases and Error Handling
# ============================================================================

class TestEdgeCases:
    """Test edge cases and error conditions"""
    
    def test_empty_credentials(self):
        """Test detection with empty credentials"""
        with pytest.raises(OSDetectionError):
            detect_server_os('test.local', username='', credential='')
    
    def test_none_hostname(self):
        """Test detection with None hostname"""
        with pytest.raises((OSDetectionError, TypeError)):
            detect_server_os(None, username='user', credential='pass')
    
    @patch('detection._detect_via_ssh')
    def test_timeout_parameter(self, mock_ssh_detect):
        """Test that timeout parameter is passed through"""
        mock_ssh_detect.return_value = {
            'type': 'linux',
            'name': 'Ubuntu',
            'protocol': 'ssh'
        }
        
        detect_server_os('test.local', username='user', credential='pass', timeout=30)
        
        # Verify timeout was passed to SSH detection as keyword argument
        call_kwargs = mock_ssh_detect.call_args[1]
        assert call_kwargs['timeout'] == 30
    
    def test_parse_malformed_os_release(self):
        """Test parsing malformed os-release file"""
        malformed = "NAME=Ubuntu\nINVALID LINE WITHOUT EQUALS\nVERSION=22.04"
        result = _parse_os_release(malformed)
        
        # Should parse valid lines and skip invalid ones
        assert result.get('NAME') == 'Ubuntu'
        assert result.get('VERSION') == '22.04'
    
    @patch('detection.Client')
    def test_winrm_invalid_json_response(self, mock_client):
        """Test WinRM detection with invalid JSON response"""
        mock_client_instance = MagicMock()
        mock_client_instance.execute_ps.return_value = (
            'NOT JSON DATA',
            MagicMock(error=[]),
            False
        )
        mock_client.return_value = mock_client_instance
        
        with pytest.raises(Exception):
            _detect_via_winrm('test.local', 5985, 'admin', 'pass', False, 10)


# ============================================================================
# Integration Tests
# ============================================================================

class TestIntegration:
    """Integration tests combining multiple components"""
    
    @patch('detection._detect_via_winrm')
    @patch('detection._detect_via_ssh')
    def test_full_detection_workflow_linux(self, mock_ssh, mock_winrm):
        """Test complete detection workflow for Linux server"""
        mock_ssh.return_value = {
            'type': 'linux',
            'name': 'Ubuntu 22.04 LTS',
            'version': '22.04',
            'architecture': 'x86_64',
            'kernel': '5.15.0-58-generic',
            'protocol': 'ssh',
            'port': 22,
            'connection_type': 'ssh',
            'ssl': False,
            'distro_id': 'ubuntu'
        }
        
        result = detect_server_os(
            hostname='ubuntu-server.local',
            username='ubuntu',
            credential='password123'
        )
        
        assert result['type'] == 'linux'
        assert result['name'] == 'Ubuntu 22.04 LTS'
        assert result['protocol'] == 'ssh'
        assert result['port'] == 22
        
        # WinRM should not have been attempted
        mock_winrm.assert_not_called()
    
    @patch('detection._detect_via_winrm')
    @patch('detection._detect_via_ssh')
    def test_full_detection_workflow_windows(self, mock_ssh, mock_winrm):
        """Test complete detection workflow for Windows server"""
        # SSH fails (Windows doesn't have SSH by default)
        mock_ssh.side_effect = Exception("Connection refused")
        
        # WinRM succeeds
        mock_winrm.return_value = {
            'type': 'windows',
            'name': 'Microsoft Windows Server 2019 Datacenter',
            'version': '10.0.17763',
            'architecture': 'x64',
            'build': '17763',
            'protocol': 'winrm',
            'port': 5985,
            'connection_type': 'winrm',
            'ssl': False,
            'auth_used': 'ntlm',
            'edition': 'Windows Server Datacenter',
            'domain': None
        }
        
        result = detect_server_os(
            hostname='windows-server.local',
            username='Administrator',
            credential='Password123!'
        )
        
        assert result['type'] == 'windows'
        assert 'Windows Server 2019' in result['name']
        assert result['protocol'] == 'winrm'
        assert result['auth_used'] == 'ntlm'


if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
