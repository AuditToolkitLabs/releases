#!/usr/bin/env python3
"""Tests for discovery result retention and capacity pruning."""

import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from datetime import datetime, timedelta

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.discovery import DiscoveryManager


class TestDiscoveryRetentionPolicy(unittest.TestCase):
    """Validate discovery retention and max-record safeguards."""

    def test_discovery_results_are_capped_by_max_records(self):
        with TemporaryDirectory() as temp_dir:
            storage_path = Path(temp_dir) / 'discovery_results.json'
            manager = DiscoveryManager(storage_path=str(storage_path))

            with patch('security_settings.get_security_setting', side_effect=lambda k, d: 3 if k == 'result_retention_max_records' else 365):
                for idx in range(5):
                    manager.save_result({
                        'server_id': f'srv-{idx}',
                        'hostname': f'host-{idx}',
                        'timestamp': datetime.utcnow().isoformat(),
                        'success': True
                    })

            results = manager.get_all_results(limit=10)
            self.assertEqual(len(results), 3)

    def test_discovery_results_are_pruned_by_retention_days(self):
        with TemporaryDirectory() as temp_dir:
            storage_path = Path(temp_dir) / 'discovery_results.json'
            manager = DiscoveryManager(storage_path=str(storage_path))

            old_timestamp = (datetime.utcnow() - timedelta(days=45)).isoformat()
            new_timestamp = datetime.utcnow().isoformat()

            with patch('security_settings.get_security_setting', side_effect=lambda k, d: 30 if k == 'result_retention' else 1000):
                manager.save_result({
                    'server_id': 'old',
                    'hostname': 'old-host',
                    'timestamp': old_timestamp,
                    'success': True
                })
                manager.save_result({
                    'server_id': 'new',
                    'hostname': 'new-host',
                    'timestamp': new_timestamp,
                    'success': True
                })

            results = manager.get_all_results(limit=10)
            hostnames = [r.hostname for r in results]
            self.assertIn('new-host', hostnames)
            self.assertNotIn('old-host', hostnames)


if __name__ == '__main__':
    unittest.main()
