import ast
from pathlib import Path

import pytest


def _load_normalizer(function_name: str):
    source_path = Path(__file__).resolve().parents[1] / "api" / "discovery_routes.py"
    source_code = source_path.read_text(encoding="utf-8")
    module_ast = ast.parse(source_code, filename=str(source_path))

    target_func = None
    for node in module_ast.body:
        if isinstance(node, ast.FunctionDef) and node.name == function_name:
            target_func = node
            break

    if target_func is None:
        raise AssertionError(f"Function {function_name} not found")

    isolated_module = ast.Module(body=[target_func], type_ignores=[])
    ast.fix_missing_locations(isolated_module)

    namespace = {}
    exec(compile(isolated_module, str(source_path), "exec"), namespace)  # nosec B102
    return namespace[function_name]


@pytest.fixture(scope="module")
def normalize_test_connection():
    return _load_normalizer("_normalize_winrm_test_connection_response")


@pytest.fixture(scope="module")
def normalize_execute():
    return _load_normalizer("_normalize_winrm_execute_response")


@pytest.mark.parametrize(
    "raw, expected",
    [
        ({"success": True, "message": "connected"}, (True, "connected")),
        ({"success": False, "error": "denied"}, (False, "denied")),
        ((True, "ok"), (True, "ok")),
        ((False,), (False, "")),
        ("bad", (False, "Invalid WinRM test_connection response")),
    ],
)
def test_normalize_winrm_test_connection_response(normalize_test_connection, raw, expected):
    assert normalize_test_connection(raw) == expected  # nosec B101


@pytest.mark.parametrize(
    "raw, expected",
    [
        ({"success": True, "stdout": "hello"}, (True, "hello")),
        ({"success": True, "output": "alt"}, (True, "alt")),
        ({"success": False, "error": "boom"}, (False, "boom")),
        ((True, "ran"), (True, "ran")),
        ((False,), (False, "")),
        (123, (False, "Invalid WinRM execute_command response")),
    ],
)
def test_normalize_winrm_execute_response(normalize_execute, raw, expected):
    assert normalize_execute(raw) == expected  # nosec B101
