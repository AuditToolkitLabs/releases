#!/usr/bin/env python3
"""
EncryptedField tests.

Validates database-agnostic encryption behavior used for PostgreSQL/SQLite.
"""

import os
import sys
import tempfile
import unittest
from typing import cast
from pathlib import Path

from cryptography.fernet import Fernet
from sqlalchemy.engine.default import DefaultDialect

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.encrypted_field import EncryptedField


class TestEncryptedField(unittest.TestCase):
    def setUp(self):
        self._original_env = dict(os.environ)
        for key in [
            'DB_FIELD_ENCRYPTION_KEY',
            'ENCRYPTION_KEY',
            'DB_FIELD_ENCRYPTION_ALLOW_KEYSTORE_FALLBACK',
            'KEYSTORE_MASTER_KEY_PATH',
            'DB_ENCRYPTION_STRICT',
            'FLASK_ENV',
            'ENVIRONMENT',
        ]:
            os.environ.pop(key, None)
        self.dialect = DefaultDialect()
        EncryptedField.clear_cache()

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._original_env)
        EncryptedField.clear_cache()

    def test_round_trip_string_encrypted(self):
        os.environ['DB_FIELD_ENCRYPTION_KEY'] = Fernet.generate_key().decode()
        field = EncryptedField()

        stored = field.process_bind_param('secret-value', self.dialect)
        self.assertIsInstance(stored, str)
        stored_str = cast(str, stored)
        self.assertTrue(stored_str.startswith(EncryptedField.ENCRYPTED_PREFIX))

        recovered = field.process_result_value(stored_str, self.dialect)
        self.assertEqual(recovered, 'secret-value')

    def test_round_trip_json_payload(self):
        os.environ['DB_FIELD_ENCRYPTION_KEY'] = Fernet.generate_key().decode()
        field = EncryptedField()

        payload = {'status': 'ok', 'count': 3}
        stored = field.process_bind_param(payload, self.dialect)
        recovered = field.process_result_value(stored, self.dialect)

        self.assertEqual(recovered, payload)

    def test_plaintext_legacy_read_supported(self):
        os.environ['DB_FIELD_ENCRYPTION_KEY'] = Fernet.generate_key().decode()
        field = EncryptedField()

        recovered = field.process_result_value('legacy-plain-text', self.dialect)
        self.assertEqual(recovered, 'legacy-plain-text')

    def test_strict_mode_requires_key(self):
        os.environ['DB_ENCRYPTION_STRICT'] = 'true'
        field = EncryptedField()

        with self.assertRaises(ValueError):
            field.process_bind_param('must-fail-without-key', self.dialect)

    def test_keystore_fallback_disabled_in_production_by_default(self):
        with tempfile.NamedTemporaryFile(delete=False) as key_file:
            key_file.write(Fernet.generate_key())
            key_path = key_file.name

        self.addCleanup(lambda: Path(key_path).unlink(missing_ok=True))

        os.environ['FLASK_ENV'] = 'production'
        os.environ['KEYSTORE_MASTER_KEY_PATH'] = key_path

        field = EncryptedField()
        with self.assertRaises(ValueError):
            field.process_bind_param('must-not-use-keystore-fallback', self.dialect)

    def test_keystore_fallback_can_be_enabled_explicitly(self):
        with tempfile.NamedTemporaryFile(delete=False) as key_file:
            key_file.write(Fernet.generate_key())
            key_path = key_file.name

        self.addCleanup(lambda: Path(key_path).unlink(missing_ok=True))

        os.environ['FLASK_ENV'] = 'production'
        os.environ['DB_FIELD_ENCRYPTION_ALLOW_KEYSTORE_FALLBACK'] = 'true'
        os.environ['KEYSTORE_MASTER_KEY_PATH'] = key_path

        field = EncryptedField()
        stored = field.process_bind_param('fallback-enabled', self.dialect)
        self.assertIsInstance(stored, str)
        stored_str = cast(str, stored)

        self.assertTrue(stored_str.startswith(EncryptedField.ENCRYPTED_PREFIX))

    def test_db_field_key_takes_precedence_over_keystore_fallback(self):
        db_key = Fernet.generate_key()
        keystore_key = Fernet.generate_key()

        with tempfile.NamedTemporaryFile(delete=False) as key_file:
            key_file.write(keystore_key)
            key_path = key_file.name

        self.addCleanup(lambda: Path(key_path).unlink(missing_ok=True))

        os.environ['DB_FIELD_ENCRYPTION_KEY'] = db_key.decode()
        os.environ['DB_FIELD_ENCRYPTION_ALLOW_KEYSTORE_FALLBACK'] = 'true'
        os.environ['KEYSTORE_MASTER_KEY_PATH'] = key_path

        field = EncryptedField()
        stored = field.process_bind_param('db-key-priority', self.dialect)
        self.assertIsInstance(stored, str)
        stored_str = cast(str, stored)

        token = stored_str[len(EncryptedField.ENCRYPTED_PREFIX):].encode()
        decrypted = Fernet(db_key).decrypt(token).decode()
        self.assertEqual(decrypted, 'db-key-priority')


if __name__ == '__main__':
    unittest.main()
