#!/usr/bin/env python3
"""Regression tests for phase-2 encrypted column coverage."""

import sys
import unittest
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.compliance import ComplianceAssessment, ComplianceControl, ComplianceFrameworkConfig
from models.dead_letter import DeadLetterTask, TaskFailureLog
from models.encrypted_field import EncryptedField


class TestEncryptionColumnCoveragePhase2(unittest.TestCase):
    def test_compliance_sensitive_fields_use_encrypted_field(self):
        self.assertIsInstance(ComplianceAssessment.__table__.c.notes.type, EncryptedField)
        self.assertIsInstance(ComplianceControl.__table__.c.control_description.type, EncryptedField)
        self.assertIsInstance(ComplianceControl.__table__.c.evidence.type, EncryptedField)
        self.assertIsInstance(ComplianceControl.__table__.c.audit_checks.type, EncryptedField)
        self.assertIsInstance(ComplianceFrameworkConfig.__table__.c.control_mappings.type, EncryptedField)

    def test_dead_letter_sensitive_fields_use_encrypted_field(self):
        self.assertIsInstance(DeadLetterTask.__table__.c.last_error.type, EncryptedField)
        self.assertIsInstance(DeadLetterTask.__table__.c.last_traceback.type, EncryptedField)
        self.assertIsInstance(DeadLetterTask.__table__.c.resolution_notes.type, EncryptedField)
        self.assertIsInstance(TaskFailureLog.__table__.c.error_message.type, EncryptedField)
        self.assertIsInstance(TaskFailureLog.__table__.c.traceback.type, EncryptedField)


if __name__ == '__main__':
    unittest.main()
