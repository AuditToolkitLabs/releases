#!/usr/bin/env python3
"""Regression tests for phase-3 encrypted column coverage."""

import sys
import unittest
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.agent_command import AgentCommand
from models.audit_log import AuditLog
from models.encrypted_field import EncryptedField
from models.maintenance_window import ScheduleExecutionLog
from models.terminal import TerminalSessionRecording


class TestEncryptionColumnCoveragePhase3(unittest.TestCase):
    def test_agent_command_sensitive_fields_use_encrypted_field(self):
        self.assertIsInstance(AgentCommand.__table__.c.command_data.type, EncryptedField)
        self.assertIsInstance(AgentCommand.__table__.c.result_data.type, EncryptedField)
        self.assertIsInstance(AgentCommand.__table__.c.error_message.type, EncryptedField)

    def test_audit_log_error_message_uses_encrypted_field(self):
        self.assertIsInstance(AuditLog.__table__.c.error_message.type, EncryptedField)

    def test_schedule_execution_log_error_message_uses_encrypted_field(self):
        self.assertIsInstance(ScheduleExecutionLog.__table__.c.error_message.type, EncryptedField)

    def test_terminal_session_sensitive_fields_use_encrypted_field(self):
        self.assertIsInstance(TerminalSessionRecording.__table__.c.recording_data.type, EncryptedField)
        self.assertIsInstance(TerminalSessionRecording.__table__.c.commands_json.type, EncryptedField)
        self.assertIsInstance(TerminalSessionRecording.__table__.c.error_message.type, EncryptedField)
        self.assertIsInstance(TerminalSessionRecording.__table__.c.review_notes.type, EncryptedField)


if __name__ == '__main__':
    unittest.main()
