#!/usr/bin/env python3
"""
Encryption Column Coverage Tests - Phase 4
Verifies auth-audit, remediation, operational error fields use EncryptedField

Phase 4 targets:
- User model: AuthAuditLog.{user_agent, details}
- Differential model: RemediationItem.{notes, remediation_steps, resolution_notes}
                      RemediationHistory.{old_value, new_value, comment}
- Database model: Hypervisor.last_connection_error
                  FleetAgent.{last_heartbeat_error, last_export_error, last_import_error}
- Scheduled Report model: ScheduledReport.last_error

Author: Security Audit Toolkit Team - At-Rest Encryption Phase 4
Date: February 14, 2026
"""

import pytest
from models.encrypted_field import EncryptedField
from models.user import AuthAuditLog
from models.differential import RemediationItem, RemediationHistory
from models.database import Hypervisor, FleetAgent
from models.scheduled_report import ScheduledReport


class TestAuthAuditEncryption:
    """Verify auth-audit log fields are encrypted"""

    def test_auth_audit_user_agent_encrypted(self):
        """AuthAuditLog.user_agent must use EncryptedField"""
        assert isinstance(AuthAuditLog.__table__.c.user_agent.type, EncryptedField), "AuthAuditLog.user_agent must be encrypted for privacy compliance"  # nosec B101

    def test_auth_audit_details_encrypted(self):
        """AuthAuditLog.details must use EncryptedField"""
        assert isinstance(AuthAuditLog.__table__.c.details.type, EncryptedField), "AuthAuditLog.details must be encrypted to protect sensitive auth event metadata"  # nosec B101


class TestRemediationEncryption:
    """Verify remediation narrative fields are encrypted"""

    def test_remediation_item_notes_encrypted(self):
        """RemediationItem.notes must use EncryptedField"""
        assert isinstance(RemediationItem.__table__.c.notes.type, EncryptedField), "RemediationItem.notes must be encrypted to protect remediation documentation"  # nosec B101

    def test_remediation_item_steps_encrypted(self):
        """RemediationItem.remediation_steps must use EncryptedField"""
        assert isinstance(RemediationItem.__table__.c.remediation_steps.type, EncryptedField), "RemediationItem.remediation_steps must be encrypted to protect remediation procedures"  # nosec B101

    def test_remediation_item_resolution_notes_encrypted(self):
        """RemediationItem.resolution_notes must use EncryptedField"""
        assert isinstance(RemediationItem.__table__.c.resolution_notes.type, EncryptedField), "RemediationItem.resolution_notes must be encrypted to protect resolution documentation"  # nosec B101

    def test_remediation_history_old_value_encrypted(self):
        """RemediationHistory.old_value must use EncryptedField"""
        assert isinstance(RemediationHistory.__table__.c.old_value.type, EncryptedField), "RemediationHistory.old_value must be encrypted to protect audit trail data"  # nosec B101

    def test_remediation_history_new_value_encrypted(self):
        """RemediationHistory.new_value must use EncryptedField"""
        assert isinstance(RemediationHistory.__table__.c.new_value.type, EncryptedField), "RemediationHistory.new_value must be encrypted to protect audit trail data"  # nosec B101

    def test_remediation_history_comment_encrypted(self):
        """RemediationHistory.comment must use EncryptedField"""
        assert isinstance(RemediationHistory.__table__.c.comment.type, EncryptedField), "RemediationHistory.comment must be encrypted to protect change commentary"  # nosec B101


class TestOperationalErrorEncryption:
    """Verify operational error message fields are encrypted"""

    def test_hypervisor_connection_error_encrypted(self):
        """Hypervisor.last_connection_error must use EncryptedField"""
        assert isinstance(Hypervisor.__table__.c.last_connection_error.type, EncryptedField), "Hypervisor.last_connection_error must be encrypted to protect diagnostic data"  # nosec B101

    def test_fleet_agent_heartbeat_error_encrypted(self):
        """FleetAgent.last_heartbeat_error must use EncryptedField"""
        assert isinstance(FleetAgent.__table__.c.last_heartbeat_error.type, EncryptedField), "FleetAgent.last_heartbeat_error must be encrypted to protect diagnostic data"  # nosec B101

    def test_fleet_agent_export_error_encrypted(self):
        """FleetAgent.last_export_error must use EncryptedField"""
        assert isinstance(FleetAgent.__table__.c.last_export_error.type, EncryptedField), "FleetAgent.last_export_error must be encrypted to protect diagnostic data"  # nosec B101

    def test_fleet_agent_import_error_encrypted(self):
        """FleetAgent.last_import_error must use EncryptedField"""
        assert isinstance(FleetAgent.__table__.c.last_import_error.type, EncryptedField), "FleetAgent.last_import_error must be encrypted to protect diagnostic data"  # nosec B101

    def test_scheduled_report_last_error_encrypted(self):
        """ScheduledReport.last_error must use EncryptedField"""
        assert isinstance(ScheduledReport.__table__.c.last_error.type, EncryptedField), "ScheduledReport.last_error must be encrypted to protect diagnostic data"  # nosec B101


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
