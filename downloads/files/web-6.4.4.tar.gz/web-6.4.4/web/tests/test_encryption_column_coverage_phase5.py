#!/usr/bin/env python3
"""
Encryption Column Coverage Tests - Phase 5
Verifies session tracking and differential comparison payloads use EncryptedField

Phase 5 targets:
- User model: UserSession.user_agent (active session browser identification)
- Differential model: DifferentialComparison.changes (audit diff JSON payload)

Author: Security Audit Toolkit Team - At-Rest Encryption Phase 5
Date: February 20, 2026
"""

import pytest
from models.encrypted_field import EncryptedField
from models.user import UserSession
from models.differential import DifferentialComparison


class TestSessionPrivacyEncryption:
    """Verify active session tracking fields are encrypted for privacy"""

    def test_user_session_user_agent_encrypted(self):
        """UserSession.user_agent must use EncryptedField"""
        assert isinstance(UserSession.__table__.c.user_agent.type, EncryptedField), "UserSession.user_agent must be encrypted for user privacy compliance"  # nosec B101


class TestDifferentialPayloadEncryption:
    """Verify differential comparison payloads are encrypted"""

    def test_differential_comparison_changes_encrypted(self):
        """DifferentialComparison.changes must use EncryptedField"""
        assert isinstance(DifferentialComparison.__table__.c.changes.type, EncryptedField), "DifferentialComparison.changes must be encrypted to protect audit diff payloads"  # nosec B101


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
