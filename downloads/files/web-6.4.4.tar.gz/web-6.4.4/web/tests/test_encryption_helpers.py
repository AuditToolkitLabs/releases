#!/usr/bin/env python3
"""Tests for module-level encryption helper functions."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from encryption import decrypt_data, encrypt_data


class TestEncryptionHelpers(unittest.TestCase):
    def test_encrypt_decrypt_round_trip(self):
        plaintext = 'terminal-secret-value'
        encrypted = encrypt_data(plaintext)

        self.assertIsInstance(encrypted, str)
        self.assertNotEqual(encrypted, plaintext)

        decrypted = decrypt_data(encrypted)
        self.assertEqual(decrypted, plaintext)

    def test_helpers_handle_none(self):
        self.assertIsNone(encrypt_data(None))
        self.assertIsNone(decrypt_data(None))


if __name__ == '__main__':
    unittest.main()
