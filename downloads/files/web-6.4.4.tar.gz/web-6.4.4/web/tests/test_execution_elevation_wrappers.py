#!/usr/bin/env python3
import base64
import logging
import sys
import tempfile
import types
import unittest
from pathlib import Path


sys.path.insert(0, str(Path(__file__).parent.parent))

from tasks import audit_tasks


class _FakeSSHManager:
    last_command = None
    command_history = []
    queued_results = []

    def __init__(self, *args, **kwargs):
        pass

    def execute_command(self, server, command, timeout=30):
        _FakeSSHManager.last_command = command
        _FakeSSHManager.command_history.append(command)
        if _FakeSSHManager.queued_results:
            result = _FakeSSHManager.queued_results.pop(0)
            return result
        return {
            'stdout': '[PASS] ok\n',
            'stderr': '',
            'return_code': 0,
        }


class _FakeWinRMManager:
    last_payload = None
    payload_history = []
    queued_results = []
    queued_connection_results = []

    def execute_command(self, server, command, powershell=True, timeout=60):
        _FakeWinRMManager.last_payload = {
            'server': server,
            'command': command,
            'powershell': powershell,
            'timeout': timeout,
        }
        _FakeWinRMManager.payload_history.append(_FakeWinRMManager.last_payload)
        if _FakeWinRMManager.queued_results:
            result = _FakeWinRMManager.queued_results.pop(0)
            return result
        return {
            'success': True,
            'stdout': '[PASS] ok\n',
            'stderr': '',
            'return_code': 0,
        }

    def test_connection(self, **kwargs):
        _ = kwargs
        if _FakeWinRMManager.queued_connection_results:
            return _FakeWinRMManager.queued_connection_results.pop(0)
        return {'success': True, 'message': 'Connected'}


class TestExecutionElevationWrappers(unittest.TestCase):
    def setUp(self):
        self._orig_modules = dict(sys.modules)
        self.logger = logging.getLogger('test.execution.elevation')
        _FakeSSHManager.queued_results = []
        _FakeSSHManager.command_history = []
        _FakeWinRMManager.queued_results = []
        _FakeWinRMManager.payload_history = []
        _FakeWinRMManager.queued_connection_results = []

        sys.modules['ssh_manager'] = types.SimpleNamespace(SSHManager=_FakeSSHManager)
        sys.modules['encryption'] = types.SimpleNamespace(
            ssh_host_key_manager=object(),
            password_manager=object(),
        )
        sys.modules['config'] = types.SimpleNamespace(SSH_DIR=str(Path(tempfile.gettempdir()) / 'ssh-test'))
        sys.modules['winrm_manager'] = types.SimpleNamespace(
            winrm_manager=_FakeWinRMManager(),
            WINRM_AVAILABLE=True,
        )

    def tearDown(self):
        sys.modules.clear()
        sys.modules.update(self._orig_modules)

    @staticmethod
    def _tmp_script(contents='Write-Output "ok"\n'):
        f = tempfile.NamedTemporaryFile('w', suffix='.sh', delete=False, encoding='utf-8')
        f.write(contents)
        f.flush()
        f.close()
        return f.name

    def test_ssh_linux_stream_sudo_uses_elevated_pipeline(self):
        script_path = self._tmp_script('#!/usr/bin/env bash\necho ok\n')
        server = {'name': 'linux1', 'execution_mode': 'stream', 'elevation_method': 'sudo'}

        output, exit_code, status, _ = audit_tasks._execute_via_ssh_linux(
            server, 'audits/platform/baseline/updates.sh', script_path, 30, self.logger
        )

        self.assertEqual(exit_code, 0)
        self.assertEqual(status, 'success')
        self.assertIn('[PASS]', output)
        self.assertIn('base64 -d | sudo bash', _FakeSSHManager.last_command)

    def test_ssh_linux_deployed_audit_wrapper_uses_wrapper_command(self):
        script_path = self._tmp_script('#!/usr/bin/env bash\necho ok\n')
        server = {'name': 'linux2', 'execution_mode': 'deployed', 'elevation_method': 'audit_wrapper'}

        _, exit_code, _, _ = audit_tasks._execute_via_ssh_linux(
            server, 'audits/platform/baseline/updates.sh', script_path, 30, self.logger
        )

        self.assertEqual(exit_code, 0)
        self.assertIn('deployment/linux/least-privilege/audit-wrapper.sh', _FakeSSHManager.last_command)
        self.assertIn('platform/baseline/updates.sh', _FakeSSHManager.last_command)

    def test_ssh_windows_deployed_jea_uses_jer_wrapper(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winssh1',
            'execution_mode': 'deployed',
            'elevation_method': 'jea',
            'jea_endpoint': 'SecurityAudit',
        }

        _, exit_code, _, _ = audit_tasks._execute_via_ssh_windows(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger
        )

        self.assertEqual(exit_code, 0)
        cmd = _FakeSSHManager.last_command
        self.assertIn('run-audit-jer.ps1', cmd)
        self.assertIn('-Mode jea', cmd)
        self.assertIn('-JeaEndpoint "SecurityAudit"', cmd)

    def test_winrm_deployed_jea_uses_jer_wrapper(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winrm1',
            'execution_mode': 'deployed',
            'elevation_method': 'jea',
            'jea_endpoint': 'SecurityAudit',
        }

        _, exit_code, _, _ = audit_tasks._execute_via_winrm(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger,
            enable_readiness_gate=False
        )

        self.assertEqual(exit_code, 0)
        script = _FakeWinRMManager.last_payload['command']
        self.assertIn('run-audit-jer.ps1', script)
        self.assertIn('-Mode jea', script)

    def test_winrm_stream_runas_wraps_script_and_delegates(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winrm2',
            'execution_mode': 'stream',
            'elevation_method': 'runas',
            'jea_endpoint': 'SecurityAudit',
        }

        _, exit_code, _, _ = audit_tasks._execute_via_winrm(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger,
            enable_readiness_gate=False
        )

        self.assertEqual(exit_code, 0)
        wrapped_script = _FakeWinRMManager.last_payload['command']
        self.assertIn('run-audit-jer.ps1', wrapped_script)
        self.assertIn('-Mode runas', wrapped_script)

    def test_ssh_windows_stream_jea_encodes_wrapper_payload(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winssh2',
            'execution_mode': 'stream',
            'elevation_method': 'jea',
            'jea_endpoint': 'SecurityAudit',
        }

        _, exit_code, _, _ = audit_tasks._execute_via_ssh_windows(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger
        )

        self.assertEqual(exit_code, 0)
        cmd = _FakeSSHManager.last_command
        self.assertIn('-EncodedCommand', cmd)

        encoded = cmd.split('-EncodedCommand', 1)[1].strip()
        decoded = base64.b64decode(encoded).decode('utf-16-le')
        self.assertIn('run-audit-jer.ps1', decoded)
        self.assertIn('-Mode jea', decoded)

    def test_ssh_linux_stream_sudo_failure_falls_back_non_elevated(self):
        script_path = self._tmp_script('#!/usr/bin/env bash\necho ok\n')
        server = {'name': 'linux3', 'execution_mode': 'stream', 'elevation_method': 'sudo'}

        _FakeSSHManager.queued_results = [
            {
                'stdout': '',
                'stderr': 'sudo: a password is required\n',
                'return_code': 1,
            },
            {
                'stdout': '[PASS] ok\n',
                'stderr': '',
                'return_code': 0,
            },
        ]

        output, exit_code, status, _ = audit_tasks._execute_via_ssh_linux(
            server, 'audits/platform/baseline/updates.sh', script_path, 30, self.logger
        )

        self.assertEqual(exit_code, 0)
        self.assertEqual(status, 'success')
        self.assertEqual(len(_FakeSSHManager.command_history), 2)
        self.assertIn('sudo bash', _FakeSSHManager.command_history[0])
        self.assertTrue(_FakeSSHManager.command_history[1].endswith('| bash'))
        self.assertIn('non-elevated output', output)

    def test_ssh_windows_stream_jea_missing_wrapper_falls_back_non_elevated(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winssh3',
            'execution_mode': 'stream',
            'elevation_method': 'jea',
            'jea_endpoint': 'SecurityAudit',
        }

        _FakeSSHManager.queued_results = [
            {
                'stdout': '',
                'stderr': 'The term \"run-audit-jer.ps1\" is not recognized as the name of a cmdlet.\n',
                'return_code': 1,
            },
            {
                'stdout': '[PASS] ok\n',
                'stderr': '',
                'return_code': 0,
            },
        ]

        output, exit_code, status, _ = audit_tasks._execute_via_ssh_windows(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger
        )

        self.assertEqual(exit_code, 0)
        self.assertEqual(status, 'success')
        self.assertEqual(len(_FakeSSHManager.command_history), 2)
        first_encoded = _FakeSSHManager.command_history[0].split('-EncodedCommand', 1)[1].strip()
        first_decoded = base64.b64decode(first_encoded).decode('utf-16-le')
        self.assertIn('run-audit-jer.ps1', first_decoded)
        self.assertIn('-EncodedCommand', _FakeSSHManager.command_history[1])
        self.assertIn('non-elevated output', output)

    def test_winrm_deployed_jea_missing_wrapper_falls_back_non_elevated(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winrm3',
            'execution_mode': 'deployed',
            'elevation_method': 'jea',
            'jea_endpoint': 'SecurityAudit',
        }

        _FakeWinRMManager.queued_results = [
            {
                'success': False,
                'stdout': '',
                'stderr': 'The term \'run-audit-jer.ps1\' is not recognized as the name of a cmdlet.',
                'return_code': 1,
            },
            {
                'success': True,
                'stdout': '[PASS] ok\n',
                'stderr': '',
                'return_code': 0,
            }
        ]

        output, exit_code, status, _ = audit_tasks._execute_via_winrm(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger,
            enable_readiness_gate=False
        )

        self.assertEqual(exit_code, 0)
        self.assertEqual(status, 'success')
        self.assertEqual(len(_FakeWinRMManager.payload_history), 2)
        self.assertIn('run-audit-jer.ps1', _FakeWinRMManager.payload_history[0]['command'])
        self.assertIn('audits\\windows\\common\\test.ps1', _FakeWinRMManager.payload_history[1]['command'])
        self.assertIn('run-audit-jer.ps1', output)
        self.assertIn('non-elevated output', output)

    def test_winrm_stream_jea_invalid_endpoint_falls_back_non_elevated(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winrm4',
            'execution_mode': 'stream',
            'elevation_method': 'jea',
            'jea_endpoint': 'BadEndpoint',
        }

        _FakeWinRMManager.queued_results = [
            {
                'success': False,
                'stdout': '',
                'stderr': "JEA endpoint 'BadEndpoint' not found.",
                'return_code': 1,
            },
            {
                'success': True,
                'stdout': '[PASS] ok\n',
                'stderr': '',
                'return_code': 0,
            }
        ]

        output, exit_code, status, _ = audit_tasks._execute_via_winrm(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger,
            enable_readiness_gate=False
        )

        self.assertEqual(exit_code, 0)
        self.assertEqual(status, 'success')
        self.assertEqual(len(_FakeWinRMManager.payload_history), 2)
        self.assertIn('run-audit-jer.ps1', _FakeWinRMManager.payload_history[0]['command'])
        self.assertEqual(_FakeWinRMManager.payload_history[1]['command'], 'Write-Output "ok"\n')
        self.assertIn("BadEndpoint", output)
        self.assertIn('non-elevated output', output)

    def test_winrm_readiness_gate_blocks_on_connection_failure(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winrm-ready-conn-fail',
            'host': '192.168.100.20',
            'port': 5985,
            'user': 'audit_user',
            'password': 'secret',  # nosec
            'execution_mode': 'deployed',
            'elevation_method': 'jea',
            'jea_endpoint': 'SecurityAudit',
        }

        _FakeWinRMManager.queued_connection_results = [
            {'success': False, 'error': '401 Unauthorized'}
        ]

        output, exit_code, status, summary = audit_tasks._execute_via_winrm(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger,
            enable_readiness_gate=True, require_jea_endpoint=True
        )

        self.assertEqual(exit_code, 1)
        self.assertEqual(status, 'failure')
        self.assertIn('WinRM readiness gate blocked legacy execution', output)
        self.assertIn('Preflight connection failed', output)
        self.assertIn('winrm_readiness_failed', summary)
        self.assertEqual(len(_FakeWinRMManager.payload_history), 0)

    def test_winrm_readiness_gate_blocks_on_host_readiness_failure(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winrm-ready-host-fail',
            'host': '192.168.100.20',
            'port': 5985,
            'user': 'audit_user',
            'password': 'secret',  # nosec
            'execution_mode': 'deployed',
            'elevation_method': 'jea',
            'jea_endpoint': 'SecurityAudit',
        }

        _FakeWinRMManager.queued_results = [
            {
                'success': False,
                'stdout': '{"ok":false,"service":"Stopped"}',
                'stderr': '',
                'return_code': 3,
            }
        ]

        output, exit_code, status, summary = audit_tasks._execute_via_winrm(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger,
            enable_readiness_gate=True, require_jea_endpoint=True
        )

        self.assertEqual(exit_code, 1)
        self.assertEqual(status, 'failure')
        self.assertIn('WinRM readiness gate blocked legacy execution', output)
        self.assertIn('Preflight readiness failed', output)
        self.assertIn('winrm_readiness_failed', summary)
        self.assertEqual(len(_FakeWinRMManager.payload_history), 1)
        self.assertIn('Get-Service WinRM', _FakeWinRMManager.payload_history[0]['command'])

    def test_winrm_readiness_gate_passes_and_executes_audit(self):
        script_path = self._tmp_script('Write-Output "ok"\n')
        server = {
            'name': 'winrm-ready-pass',
            'host': '192.168.100.20',
            'port': 5985,
            'user': 'audit_user',
            'password': 'secret',  # nosec
            'execution_mode': 'deployed',
            'elevation_method': 'jea',
            'jea_endpoint': 'SecurityAudit',
        }

        _FakeWinRMManager.queued_results = [
            {
                'success': True,
                'stdout': '{"ok":true,"service":"Running"}',
                'stderr': '',
                'return_code': 0,
            },
            {
                'success': True,
                'stdout': '[PASS] ok\n',
                'stderr': '',
                'return_code': 0,
            }
        ]

        output, exit_code, status, _ = audit_tasks._execute_via_winrm(
            server, 'audits/windows/common/test.ps1', script_path, 30, self.logger,
            enable_readiness_gate=True, require_jea_endpoint=True
        )

        self.assertEqual(exit_code, 0)
        self.assertEqual(status, 'success')
        self.assertIn('[PASS] ok', output)
        self.assertEqual(len(_FakeWinRMManager.payload_history), 2)
        self.assertIn('Get-Service WinRM', _FakeWinRMManager.payload_history[0]['command'])
        self.assertIn('run-audit-jer.ps1', _FakeWinRMManager.payload_history[1]['command'])


if __name__ == '__main__':
    unittest.main()
