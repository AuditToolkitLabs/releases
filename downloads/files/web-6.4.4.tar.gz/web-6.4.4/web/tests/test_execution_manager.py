"""
Unit tests for execution_manager.py - Cross-platform execution abstraction

Tests cover:
- ExecutionResult class
- SSHExecutor (Linux execution)
- WinRMExecutor (Windows execution)
- ExecutionManager factory pattern
- Protocol selection logic
- Error handling and edge cases
"""

import pytest
from unittest.mock import Mock, MagicMock, patch, PropertyMock
import time
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from execution_manager import (
    ExecutionResult,
    ExecutorBase,
    SSHExecutor,
    WinRMExecutor,
    ExecutionManager
)


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def mock_linux_server():
    """Mock server object configured for Linux/SSH"""
    server = Mock()
    server.id = 1
    server.hostname = 'linux-test.local'
    server.username = 'ubuntu'
    server.password = 'test_password'
    server.ssh_key = None
    server.os_type = 'linux'
    server.connection_type = 'ssh'
    server.connection_port = 22
    server.domain = None
    return server


@pytest.fixture
def mock_windows_server():
    """Mock server object configured for Windows/WinRM"""
    server = Mock()
    server.id = 2
    server.hostname = 'windows-test.local'
    server.username = 'Administrator'
    server.password = 'Test_Password123!'
    server.ssh_key = None
    server.os_type = 'windows'
    server.connection_type = 'winrm'
    server.connection_port = 5985
    server.domain = None
    return server


@pytest.fixture
def mock_domain_server():
    """Mock Windows server in Active Directory domain"""
    server = Mock()
    server.id = 3
    server.hostname = 'dc01.example.com'
    server.username = 'admin'
    server.password = 'Domain_Pass123!'
    server.ssh_key = None
    server.os_type = 'windows'
    server.connection_type = 'winrm'
    server.connection_port = 5985
    server.domain = 'EXAMPLE'
    return server


# ============================================================================
# ExecutionResult Tests
# ============================================================================

class TestExecutionResult:
    """Test ExecutionResult class"""
    
    def test_initialization(self):
        """Test ExecutionResult initialization"""
        result = ExecutionResult(
            exit_code=0,
            stdout='Test output',
            stderr='',
            duration_ms=1500,
            protocol='ssh'
        )
        
        assert result.exit_code == 0
        assert result.stdout == 'Test output'
        assert result.stderr == ''
        assert result.duration_ms == 1500
        assert result.protocol == 'ssh'
        assert result.success is True
    
    def test_success_on_exit_code_zero(self):
        """Test that exit code 0 marks result as success"""
        result = ExecutionResult(0, 'output', '', 1000, 'ssh')
        assert result.success is True
    
    def test_failure_on_nonzero_exit_code(self):
        """Test that non-zero exit code marks result as failure"""
        result = ExecutionResult(1, 'output', 'warning', 1000, 'ssh')
        assert result.success is False
        
        result = ExecutionResult(2, 'output', 'error', 1000, 'winrm')
        assert result.success is False
    
    def test_to_dict_conversion(self):
        """Test ExecutionResult.to_dict() serialization"""
        result = ExecutionResult(0, 'stdout', 'stderr', 2000, 'winrm')
        result_dict = result.to_dict()
        
        assert isinstance(result_dict, dict)
        assert result_dict['exit_code'] == 0
        assert result_dict['stdout'] == 'stdout'
        assert result_dict['stderr'] == 'stderr'
        assert result_dict['duration_ms'] == 2000
        assert result_dict['protocol'] == 'winrm'
        assert result_dict['success'] is True
    
    def test_repr_output(self):
        """Test ExecutionResult string representation"""
        result = ExecutionResult(0, 'out', 'err', 1234, 'ssh')
        repr_str = repr(result)
        
        assert 'ExecutionResult' in repr_str
        assert 'SUCCESS' in repr_str
        assert '1234' in repr_str
        assert 'ssh' in repr_str


# ============================================================================
# SSHExecutor Tests
# ============================================================================

class TestSSHExecutor:
    """Test SSHExecutor for Linux connections"""
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_executor_initialization(self, mock_ssh_client, mock_linux_server):
        """Test SSHExecutor initialization"""
        executor = SSHExecutor(mock_linux_server)
        
        assert executor.server == mock_linux_server
        assert executor.ssh is None
        assert executor.connected is False
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_connect_with_password(self, mock_ssh_client, mock_linux_server):
        """Test SSH connection with password authentication"""
        executor = SSHExecutor(mock_linux_server)
        mock_ssh_instance = MagicMock()
        mock_ssh_client.return_value = mock_ssh_instance
        
        executor.connect()
        
        mock_ssh_instance.set_missing_host_key_policy.assert_called_once()
        mock_ssh_instance.connect.assert_called_once()
        assert executor.connected is True
        
        # Verify password auth was used
        call_kwargs = mock_ssh_instance.connect.call_args[1]
        assert call_kwargs['username'] == 'ubuntu'
        assert call_kwargs['password'] == 'test_password'
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_connect_with_key(self, mock_ssh_client, mock_linux_server):
        """Test SSH connection with SSH key authentication"""
        mock_linux_server.ssh_key = '/path/to/key.pem'
        mock_linux_server.password = None
        
        executor = SSHExecutor(mock_linux_server)
        mock_ssh_instance = MagicMock()
        mock_ssh_client.return_value = mock_ssh_instance
        
        executor.connect()
        
        # Verify key auth was used
        call_kwargs = mock_ssh_instance.connect.call_args[1]
        assert call_kwargs['key_filename'] == '/path/to/key.pem'
        assert 'password' not in call_kwargs
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_execute_script_success(self, mock_ssh_client, mock_linux_server):
        """Test successful script execution via SSH"""
        executor = SSHExecutor(mock_linux_server)
        mock_ssh_instance = MagicMock()
        mock_ssh_client.return_value = mock_ssh_instance
        
        # Mock exec_command response
        mock_stdout = MagicMock()
        mock_stdout.read.return_value = b'[PASS] Test passed\n'
        mock_stdout.channel.recv_exit_status.return_value = 0
        
        mock_stderr = MagicMock()
        mock_stderr.read.return_value = b''
        
        mock_ssh_instance.exec_command.return_value = (MagicMock(), mock_stdout, mock_stderr)
        
        executor.connect()
        result = executor.execute_script('test_script.sh')
        
        assert isinstance(result, ExecutionResult)
        assert result.exit_code == 0
        assert '[PASS]' in result.stdout
        assert result.success is True
        assert result.protocol == 'ssh'
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_execute_script_with_args(self, mock_ssh_client, mock_linux_server):
        """Test script execution with arguments"""
        executor = SSHExecutor(mock_linux_server)
        mock_ssh_instance = MagicMock()
        mock_ssh_client.return_value = mock_ssh_instance
        
        mock_stdout = MagicMock()
        mock_stdout.read.return_value = b'output'
        mock_stdout.channel.recv_exit_status.return_value = 0
        mock_stderr = MagicMock()
        mock_stderr.read.return_value = b''
        
        mock_ssh_instance.exec_command.return_value = (MagicMock(), mock_stdout, mock_stderr)
        
        executor.connect()
        result = executor.execute_script('script.sh', ['--verbose', '--check'])
        
        # Verify command included arguments
        call_args = mock_ssh_instance.exec_command.call_args[0][0]
        assert '--verbose' in call_args
        assert '--check' in call_args
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_execute_without_connect_raises_error(self, mock_ssh_client, mock_linux_server):
        """Test that execute_script raises error if not connected"""
        executor = SSHExecutor(mock_linux_server)
        
        with pytest.raises(RuntimeError, match="Not connected"):
            executor.execute_script('test.sh')
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_disconnect(self, mock_ssh_client, mock_linux_server):
        """Test SSH disconnect"""
        executor = SSHExecutor(mock_linux_server)
        mock_ssh_instance = MagicMock()
        mock_ssh_client.return_value = mock_ssh_instance
        
        executor.connect()
        assert executor.connected is True
        
        executor.disconnect()
        
        mock_ssh_instance.close.assert_called_once()
        assert executor.connected is False
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_test_connection(self, mock_ssh_client, mock_linux_server):
        """Test connection health check"""
        executor = SSHExecutor(mock_linux_server)
        mock_ssh_instance = MagicMock()
        mock_ssh_client.return_value = mock_ssh_instance
        
        # Mock transport
        mock_transport = MagicMock()
        mock_transport.is_active.return_value = True
        mock_ssh_instance.get_transport.return_value = mock_transport
        
        executor.connect()
        
        assert executor.test_connection() is True


# ============================================================================
# WinRMExecutor Tests
# ============================================================================

class TestWinRMExecutor:
    """Test WinRMExecutor for Windows connections"""
    
    @patch('execution_manager.WSMan')
    @patch('execution_manager.RunspacePool')
    @patch('execution_manager.PowerShell')
    def test_winrm_executor_initialization(self, mock_ps, mock_pool, mock_wsman, mock_windows_server):
        """Test WinRMExecutor initialization"""
        executor = WinRMExecutor(mock_windows_server)
        
        assert executor.server == mock_windows_server
        assert executor.wsman is None
        assert executor.connected is False
    
    @patch('execution_manager.WSMan')
    @patch('execution_manager.RunspacePool')
    @patch('execution_manager.PowerShell')
    def test_winrm_connect_success(self, mock_ps, mock_pool, mock_wsman, mock_windows_server):
        """Test successful WinRM connection"""
        mock_wsman_instance = MagicMock()
        mock_wsman.return_value = mock_wsman_instance
        
        # Mock successful PowerShell execution for connection test
        mock_ps_instance = MagicMock()
        mock_ps_instance.had_errors = False
        mock_ps.return_value = mock_ps_instance
        
        executor = WinRMExecutor(mock_windows_server)
        executor.connect()
        
        assert executor.connected is True
        mock_wsman.assert_called_once()
    
    @patch('execution_manager.WSMan')
    @patch('execution_manager.RunspacePool')
    @patch('execution_manager.PowerShell')
    def test_winrm_connect_with_domain(self, mock_ps, mock_pool, mock_wsman, mock_domain_server):
        """Test WinRM connection with domain account"""
        mock_wsman_instance = MagicMock()
        mock_wsman.return_value = mock_wsman_instance
        
        mock_ps_instance = MagicMock()
        mock_ps_instance.had_errors = False
        mock_ps.return_value = mock_ps_instance
        
        executor = WinRMExecutor(mock_domain_server)
        executor.connect()
        
        # Verify domain prefix was added to username
        call_kwargs = mock_wsman.call_args[1]
        assert 'EXAMPLE\\admin' in call_kwargs['username'] or call_kwargs['username'] == 'EXAMPLE\\admin'
    
    @patch('execution_manager.WSMan')
    @patch('execution_manager.RunspacePool')
    @patch('execution_manager.PowerShell')
    @patch('builtins.open', create=True)
    def test_winrm_execute_script_success(self, mock_open, mock_ps, mock_pool, mock_wsman, mock_windows_server):
        """Test successful PowerShell script execution via WinRM"""
        # Mock script file reading
        mock_open.return_value.__enter__.return_value.read.return_value = 'Write-Host "Test"'
        
        mock_wsman_instance = MagicMock()
        mock_wsman.return_value = mock_wsman_instance
        
        # Mock successful connection test
        mock_ps_connect_test = MagicMock()
        mock_ps_connect_test.had_errors = False
        
        # Mock script execution
        mock_ps_execute = MagicMock()
        mock_ps_execute.had_errors = False
        mock_ps_execute.invoke.return_value = ['[PASS] Test passed']
        mock_ps_execute.streams.error = []
        
        mock_ps.side_effect = [mock_ps_connect_test, mock_ps_execute]
        
        executor = WinRMExecutor(mock_windows_server)
        executor.connect()
        result = executor.execute_script('test_script.ps1')
        
        assert isinstance(result, ExecutionResult)
        assert result.protocol == 'winrm'
        assert result.exit_code == 0
    
    @patch('execution_manager.WSMan')
    def test_winrm_execute_without_connect_raises_error(self, mock_wsman, mock_windows_server):
        """Test that execute_script raises error if not connected"""
        executor = WinRMExecutor(mock_windows_server)
        
        with pytest.raises(RuntimeError, match="Not connected"):
            executor.execute_script('test.ps1')
    
    @patch('execution_manager.WSMan')
    @patch('execution_manager.RunspacePool')
    @patch('execution_manager.PowerShell')
    def test_winrm_disconnect(self, mock_ps, mock_pool, mock_wsman, mock_windows_server):
        """Test WinRM disconnect"""
        mock_wsman_instance = MagicMock()
        mock_wsman.return_value = mock_wsman_instance
        
        mock_ps_instance = MagicMock()
        mock_ps_instance.had_errors = False
        mock_ps.return_value = mock_ps_instance
        
        executor = WinRMExecutor(mock_windows_server)
        executor.connect()
        executor.disconnect()
        
        assert executor.connected is False
        assert executor.wsman is None


# ============================================================================
# ExecutionManager Tests
# ============================================================================

class TestExecutionManager:
    """Test ExecutionManager factory pattern"""
    
    def test_get_executor_for_linux(self, mock_linux_server):
        """Test that Linux server returns SSHExecutor"""
        executor = ExecutionManager.get_executor(mock_linux_server)
        
        assert isinstance(executor, SSHExecutor)
        assert executor.server == mock_linux_server
    
    def test_get_executor_for_windows(self, mock_windows_server):
        """Test that Windows server returns WinRMExecutor"""
        executor = ExecutionManager.get_executor(mock_windows_server)
        
        assert isinstance(executor, WinRMExecutor)
        assert executor.server == mock_windows_server
    
    def test_get_executor_for_unix(self, mock_linux_server):
        """Test that 'unix' OS type returns SSHExecutor"""
        mock_linux_server.os_type = 'unix'
        executor = ExecutionManager.get_executor(mock_linux_server)
        
        assert isinstance(executor, SSHExecutor)
    
    def test_get_executor_for_bsd(self, mock_linux_server):
        """Test that 'bsd' OS type returns SSHExecutor"""
        mock_linux_server.os_type = 'bsd'
        executor = ExecutionManager.get_executor(mock_linux_server)
        
        assert isinstance(executor, SSHExecutor)
    
    def test_get_executor_unsupported_os_raises_error(self, mock_linux_server):
        """Test that unsupported OS type raises ValueError"""
        mock_linux_server.os_type = 'invalid_os'
        
        with pytest.raises(ValueError, match="Unsupported OS type"):
            ExecutionManager.get_executor(mock_linux_server)
    
    def test_get_executor_case_insensitive(self, mock_windows_server):
        """Test that OS type comparison is case-insensitive"""
        mock_windows_server.os_type = 'WINDOWS'
        executor = ExecutionManager.get_executor(mock_windows_server)
        
        assert isinstance(executor, WinRMExecutor)
    
    @patch('execution_manager.SSHExecutor')
    def test_execute_audit_connects_and_disconnects(self, mock_ssh_executor, mock_linux_server):
        """Test that execute_audit properly connects and disconnects"""
        # Create mock executor instance
        mock_executor_instance = MagicMock()
        mock_executor_instance.execute_script.return_value = ExecutionResult(
            0, 'output', '', 1000, 'ssh'
        )
        mock_ssh_executor.return_value = mock_executor_instance
        
        result = ExecutionManager.execute_audit(
            server=mock_linux_server,
            audit_path='test.sh'
        )
        
        # Verify connect, execute, disconnect sequence
        mock_executor_instance.connect.assert_called_once()
        mock_executor_instance.execute_script.assert_called_once_with('test.sh', None)
        mock_executor_instance.disconnect.assert_called_once()
        
        assert isinstance(result, ExecutionResult)
    
    @patch('execution_manager.SSHExecutor')
    def test_execute_audit_disconnects_on_error(self, mock_ssh_executor, mock_linux_server):
        """Test that disconnect is called even if execution fails"""
        mock_executor_instance = MagicMock()
        mock_executor_instance.execute_script.side_effect = Exception("Execution failed")
        mock_ssh_executor.return_value = mock_executor_instance
        
        with pytest.raises(Exception, match="Execution failed"):
            ExecutionManager.execute_audit(mock_linux_server, 'test.sh')
        
        # Verify disconnect was still called
        mock_executor_instance.disconnect.assert_called_once()
    
    @patch('execution_manager.SSHExecutor')
    def test_test_server_connection_success(self, mock_ssh_executor, mock_linux_server):
        """Test successful connection test"""
        mock_executor_instance = MagicMock()
        mock_executor_instance.test_connection.return_value = True
        mock_ssh_executor.return_value = mock_executor_instance
        
        result = ExecutionManager.test_server_connection(mock_linux_server)
        
        assert result['success'] is True
        assert result['protocol'] == 'ssh'
        assert 'duration_ms' in result
        assert result['error'] is None
    
    @patch('execution_manager.SSHExecutor')
    def test_test_server_connection_failure(self, mock_ssh_executor, mock_linux_server):
        """Test failed connection test"""
        mock_executor_instance = MagicMock()
        mock_executor_instance.connect.side_effect = Exception("Connection refused")
        mock_ssh_executor.return_value = mock_executor_instance
        
        result = ExecutionManager.test_server_connection(mock_linux_server)
        
        assert result['success'] is False
        assert result['protocol'] == 'ssh'
        assert 'duration_ms' in result
        assert 'Connection refused' in result['error']


# ============================================================================
# Integration Tests (Context Manager)
# ============================================================================

class TestContextManager:
    """Test context manager functionality"""
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_executor_context_manager(self, mock_ssh_client, mock_linux_server):
        """Test SSHExecutor as context manager"""
        mock_ssh_instance = MagicMock()
        mock_ssh_client.return_value = mock_ssh_instance
        
        executor = SSHExecutor(mock_linux_server)
        
        with executor as exec_context:
            assert exec_context.connected is True
            assert exec_context == executor
        
        # Verify disconnect was called on exit
        mock_ssh_instance.close.assert_called_once()
        assert executor.connected is False


# ============================================================================
# Edge Cases and Error Handling
# ============================================================================

class TestEdgeCases:
    """Test edge cases and error handling"""
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_connection_timeout(self, mock_ssh_client, mock_linux_server):
        """Test SSH connection timeout handling"""
        mock_ssh_instance = MagicMock()
        mock_ssh_instance.connect.side_effect = TimeoutError("Connection timeout")
        mock_ssh_client.return_value = mock_ssh_instance
        
        executor = SSHExecutor(mock_linux_server)
        
        with pytest.raises(TimeoutError):
            executor.connect()
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_authentication_failure(self, mock_ssh_client, mock_linux_server):
        """Test SSH authentication failure"""
        import paramiko
        
        mock_ssh_instance = MagicMock()
        mock_ssh_instance.connect.side_effect = paramiko.AuthenticationException("Auth failed")
        mock_ssh_client.return_value = mock_ssh_instance
        
        executor = SSHExecutor(mock_linux_server)
        
        with pytest.raises(paramiko.AuthenticationException):
            executor.connect()
    
    @patch('execution_manager.paramiko.SSHClient')
    def test_ssh_execute_with_empty_output(self, mock_ssh_client, mock_linux_server):
        """Test script execution with empty output"""
        executor = SSHExecutor(mock_linux_server)
        mock_ssh_instance = MagicMock()
        mock_ssh_client.return_value = mock_ssh_instance
        
        mock_stdout = MagicMock()
        mock_stdout.read.return_value = b''
        mock_stdout.channel.recv_exit_status.return_value = 0
        mock_stderr = MagicMock()
        mock_stderr.read.return_value = b''
        
        mock_ssh_instance.exec_command.return_value = (MagicMock(), mock_stdout, mock_stderr)
        
        executor.connect()
        result = executor.execute_script('empty_script.sh')
        
        assert result.stdout == ''
        assert result.stderr == ''
        assert result.exit_code == 0
    
    def test_execution_result_with_unicode(self):
        """Test ExecutionResult handles Unicode characters"""
        result = ExecutionResult(
            0,
            'Output with unicode: 你好 мир 🎉',
            '',
            1000,
            'ssh'
        )
        
        assert '你好' in result.stdout
        assert 'мир' in result.stdout
        assert '🎉' in result.stdout
    
    def test_executor_without_password_or_key_raises_error(self, mock_linux_server):
        """Test that executor requires credentials"""
        mock_linux_server.password = None
        mock_linux_server.ssh_key = None
        
        executor = SSHExecutor(mock_linux_server)
        
        with pytest.raises(ValueError, match="ssh_key or password"):
            executor.connect()


if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
