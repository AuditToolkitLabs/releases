#!/usr/bin/env python3
"""Regression tests for feature-gated Direct API and CVE reporting routes."""

import io
import os
import sys
import tarfile
import unittest
import zipfile
from unittest.mock import patch

from flask import Flask, jsonify

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api import asset_discovery_routes, agent_fleet_routes


class TestAssetDiscoveryFeatureGating(unittest.TestCase):
    """Validate feature-tier gating on asset discovery proxy/report routes."""

    def setUp(self):
        self.app = Flask(__name__)

    def _as_response(self, value):
        return self.app.make_response(value)

    def test_proxy_api_blocks_direct_api_scans_when_unavailable(self):
        denied_payload = {'error': 'Feature not available', 'code': 'FEATURE_UNAVAILABLE'}

        with self.app.test_request_context('/api/scans?direct_api_only=true'):
            with patch.object(asset_discovery_routes, 'FLASK_LOGIN_AVAILABLE', False), \
                 patch.object(asset_discovery_routes, 'FEATURE_LICENSING_AVAILABLE', True), \
                 patch.object(
                     asset_discovery_routes,
                     '_feature_unavailable_response',
                     return_value=(jsonify(denied_payload), 403),
                 ) as mock_gate:
                response = self._as_response(asset_discovery_routes.proxy_api('scans'))

        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.get_json().get('code'), 'FEATURE_UNAVAILABLE')
        mock_gate.assert_called_once_with(asset_discovery_routes.Feature.DIRECT_API_SCANS)

    def test_proxy_api_blocks_advanced_cve_routes_when_unavailable(self):
        denied_payload = {'error': 'Feature not available', 'code': 'FEATURE_UNAVAILABLE'}

        with self.app.test_request_context('/api/vulnerabilities?page=1'):
            with patch.object(asset_discovery_routes, 'FLASK_LOGIN_AVAILABLE', False), \
                 patch.object(asset_discovery_routes, 'FEATURE_LICENSING_AVAILABLE', True), \
                 patch.object(
                     asset_discovery_routes,
                     '_feature_unavailable_response',
                     return_value=(jsonify(denied_payload), 403),
                 ) as mock_gate:
                response = self._as_response(asset_discovery_routes.proxy_api('vulnerabilities'))

        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.get_json().get('code'), 'FEATURE_UNAVAILABLE')
        mock_gate.assert_called_once_with(asset_discovery_routes.Feature.ADVANCED_CVE_REPORTING)

    def test_software_report_latest_blocks_when_advanced_cve_unavailable(self):
        denied_payload = {'error': 'Feature not available', 'code': 'FEATURE_UNAVAILABLE'}

        with self.app.test_request_context('/software-report/latest'):
            with patch.object(asset_discovery_routes, 'FLASK_LOGIN_AVAILABLE', False), \
                 patch.object(asset_discovery_routes, 'FEATURE_LICENSING_AVAILABLE', True), \
                 patch.object(
                     asset_discovery_routes,
                     '_feature_unavailable_response',
                     return_value=(jsonify(denied_payload), 403),
                 ) as mock_gate:
                response = self._as_response(asset_discovery_routes.asset_discovery_latest_software_report())

        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.get_json().get('code'), 'FEATURE_UNAVAILABLE')
        mock_gate.assert_called_once_with(asset_discovery_routes.Feature.ADVANCED_CVE_REPORTING)


class TestManagedDirectApiDownloadFeatureGating(unittest.TestCase):
    """Validate feature-tier gating on direct API helper script downloads."""

    def setUp(self):
        self.app = Flask(__name__)

    @staticmethod
    def _unwrap(func):
        while hasattr(func, '__wrapped__'):
            func = func.__wrapped__
        return func

    def test_download_direct_api_script_blocked_when_unavailable(self):
        denied_payload = {'error': 'Feature not available', 'code': 'FEATURE_UNAVAILABLE'}
        raw_fn = self._unwrap(agent_fleet_routes.download_standalone_script)

        with self.app.test_request_context('/api/agent/download/standalone/direct-api-linux-host-setup'):
            with patch.object(agent_fleet_routes, 'FEATURE_LICENSING_AVAILABLE', True), \
                 patch.object(
                     agent_fleet_routes,
                     '_feature_unavailable_response',
                     return_value=(jsonify(denied_payload), 403),
                 ) as mock_gate:
                response = self.app.make_response(raw_fn('direct-api-linux-host-setup'))

        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.get_json().get('code'), 'FEATURE_UNAVAILABLE')
        mock_gate.assert_called_once_with(agent_fleet_routes.Feature.DIRECT_API_SCANS)

    def test_download_non_direct_script_not_feature_gated(self):
        raw_fn = self._unwrap(agent_fleet_routes.download_standalone_script)

        with self.app.test_request_context('/api/agent/download/standalone/jea-setup'):
            with patch.object(agent_fleet_routes, 'FEATURE_LICENSING_AVAILABLE', True), \
                 patch.object(agent_fleet_routes, '_feature_unavailable_response') as mock_gate, \
                 patch.object(agent_fleet_routes.os.path, 'exists', return_value=False):
                response = self.app.make_response(raw_fn('jea-setup'))

        self.assertEqual(response.status_code, 404)
        mock_gate.assert_not_called()

    def test_download_winrm_jea_wrapper_bundle_contains_required_files(self):
        raw_fn = self._unwrap(agent_fleet_routes.download_standalone_script)

        with self.app.test_request_context('/api/agent/download/standalone/winrm-jea-wrapper-bundle'):
            with patch.object(agent_fleet_routes, 'FEATURE_LICENSING_AVAILABLE', True), \
                 patch.object(agent_fleet_routes, '_feature_unavailable_response') as mock_gate:
                response = self.app.make_response(raw_fn('winrm-jea-wrapper-bundle'))

        self.assertEqual(response.status_code, 200)
        response.direct_passthrough = False
        archive = zipfile.ZipFile(io.BytesIO(response.get_data()))
        names = set(archive.namelist())

        self.assertTrue({
            'run-audit-jer.ps1',
            'Invoke-SecurityAuditJEA.ps1',
            'jea/setup-jea.ps1',
            'jea/AuditAgent.pssc',
            'jea/AuditAgent.Full.psrc',
            'jea/AuditAgent.ReadOnly.psrc',
        }.issubset(names))
        mock_gate.assert_not_called()

    def test_download_ssh_sudo_wrapper_bundle_contains_required_files(self):
        raw_fn = self._unwrap(agent_fleet_routes.download_standalone_script)

        with self.app.test_request_context('/api/agent/download/standalone/ssh-sudo-wrapper-bundle'):
            with patch.object(agent_fleet_routes, 'FEATURE_LICENSING_AVAILABLE', True), \
                 patch.object(agent_fleet_routes, '_feature_unavailable_response') as mock_gate:
                response = self.app.make_response(raw_fn('ssh-sudo-wrapper-bundle'))

        self.assertEqual(response.status_code, 200)
        response.direct_passthrough = False
        archive = tarfile.open(fileobj=io.BytesIO(response.get_data()), mode='r:gz')
        names = set(archive.getnames())

        self.assertTrue({
            'run-audit-wrapper.sh',
            'setup-sudoers.sh',
            'install-user.sh',
            'install-linux.sh',
        }.issubset(names))
        mock_gate.assert_not_called()


if __name__ == '__main__':
    unittest.main()
