#!/usr/bin/env python3
"""Tests for GitHub Sponsors webhook to repository_dispatch bridge."""

import hashlib
import hmac
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from flask import Flask

# Add web/ to import path
sys.path.insert(0, str(Path(__file__).parent.parent))

from api.integrations import github_actions


class TestGitHubSponsorsWebhookBridge(unittest.TestCase):
    """Validate sponsorship webhook forwarding behavior."""

    def setUp(self):
        self.app = Flask(__name__)
        self.app.register_blueprint(github_actions.github_actions_bp)
        self.client = self.app.test_client()

        self.secret = "sponsors-webhook-secret"
        self.app.config["GITHUB_SPONSORS_WEBHOOK_SECRET"] = self.secret
        self.app.config["GITHUB_DISPATCH_REPO_OWNER"] = "AuditToolkitLabs"
        self.app.config["GITHUB_DISPATCH_REPO_NAME"] = "Audit-Tool-"

    def _signed_post(self, payload: dict):
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        digest = hmac.new(self.secret.encode(), body, hashlib.sha256).hexdigest()
        signature = f"sha256={digest}"

        return self.client.post(
            "/api/integrations/github/webhook",
            data=body,
            headers={
                "Content-Type": "application/json",
                "X-GitHub-Event": "sponsorship",
                "X-Hub-Signature-256": signature,
                "X-GitHub-Delivery": "test-delivery-id",
            },
        )

    @patch("api.integrations.github_actions._dispatch_repository_event")
    def test_sponsorship_created_forwards_repository_dispatch(self, mock_dispatch):
        mock_dispatch.return_value = True

        response = self._signed_post(
            {
                "action": "created",
                "sponsorship": {
                    "id": "123",
                    "tier": {
                        "name": "Professional",
                    },
                },
                "sender": {
                    "login": "sponsor-user",
                },
            }
        )

        self.assertEqual(response.status_code, 202)
        body = response.get_json()
        self.assertTrue(body.get("forwarded"))
        self.assertEqual(body.get("dispatch_event"), "sponsorship_created")
        self.assertEqual(body.get("tier_slug"), "professional")

        mock_dispatch.assert_called_once()
        kwargs = mock_dispatch.call_args.kwargs
        self.assertEqual(kwargs.get("owner"), "AuditToolkitLabs")
        self.assertEqual(kwargs.get("repo"), "Audit-Tool-")
        self.assertEqual(kwargs.get("event_type"), "sponsorship_created")

        client_payload = kwargs.get("client_payload") or {}
        self.assertEqual(client_payload.get("action"), "created")
        self.assertIn("event", client_payload)

    @patch("api.integrations.github_actions._dispatch_repository_event")
    def test_sponsorship_ignored_when_action_not_allowed(self, mock_dispatch):
        response = self._signed_post(
            {
                "action": "cancelled",
                "sponsorship": {
                    "id": "123",
                    "tier": {
                        "name": "Professional",
                    },
                },
            }
        )

        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        self.assertFalse(body.get("forwarded"))
        self.assertEqual(body.get("reason"), "action_not_allowed")
        mock_dispatch.assert_not_called()

    def test_sponsorship_rejects_invalid_signature(self):
        payload = {
            "action": "created",
            "sponsorship": {
                "id": "123",
                "tier": {
                    "name": "Starter",
                },
            },
        }
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")

        response = self.client.post(
            "/api/integrations/github/webhook",
            data=body,
            headers={
                "Content-Type": "application/json",
                "X-GitHub-Event": "sponsorship",
                "X-Hub-Signature-256": "sha256=invalid",
            },
        )

        self.assertEqual(response.status_code, 401)


if __name__ == "__main__":
    unittest.main()
