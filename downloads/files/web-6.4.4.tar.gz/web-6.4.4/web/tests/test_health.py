#!/usr/bin/env python3
"""
Health Check Tests

Tests for:
- Health check endpoint (/health)
- Readiness probe endpoint (/ready)
- Prometheus metrics endpoint (/metrics)
- Individual dependency checks
- System metrics collection

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import sys
import unittest
from unittest.mock import Mock, patch, MagicMock
import json
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import health module
import health


class TestHealthChecks(unittest.TestCase):
    """Test health check functions"""

    def test_get_uptime(self):
        """Test uptime calculation"""
        uptime = health.get_uptime()
        self.assertIsInstance(uptime, float)
        self.assertGreaterEqual(uptime, 0)

    @patch('redis.from_url')
    def test_check_redis_healthy(self, mock_redis):
        """Test Redis health check when healthy"""
        mock_client = MagicMock()
        mock_client.ping.return_value = True
        mock_client.info.return_value = {
            'redis_version': '7.0.0',
            'uptime_in_seconds': 3600,
            'connected_clients': 5,
            'used_memory': 1024 * 1024 * 10  # 10 MB
        }
        mock_redis.return_value = mock_client

        result = health.check_redis('redis://localhost:6379/0')

        self.assertEqual(result['status'], 'healthy')
        self.assertTrue(result['available'])
        self.assertIn('latency_ms', result)
        self.assertEqual(result['version'], '7.0.0')
        self.assertEqual(result['uptime_seconds'], 3600)
        self.assertEqual(result['connected_clients'], 5)
        self.assertEqual(result['used_memory_mb'], 10.0)

    def test_check_redis_unavailable(self):
        """Test Redis check when connection unavailable"""
        # Test that the function handles unavailable Redis gracefully
        # by providing a URL that will fail to connect
        result = health.check_redis('redis://invalid-host-that-does-not-exist:6379/0')

        # Should return unhealthy status, not crash
        self.assertIn('status', result)
        self.assertIn(result['status'], ['unhealthy', 'unavailable'])
        self.assertFalse(result.get('available', True))

    @patch('redis.from_url')
    def test_check_redis_unhealthy(self, mock_redis):
        """Test Redis check when connection fails"""
        mock_redis.side_effect = Exception("Connection refused")

        result = health.check_redis('redis://localhost:6379/0')

        self.assertEqual(result['status'], 'unhealthy')
        self.assertFalse(result['available'])
        self.assertIn('error', result)

    @patch('sqlalchemy.create_engine')
    def test_check_database_healthy(self, mock_create_engine):
        """Test database health check when healthy"""
        mock_engine = MagicMock()
        mock_conn = MagicMock()
        mock_result = MagicMock()

        mock_engine.connect.return_value.__enter__.return_value = mock_conn
        mock_conn.execute.return_value = mock_result
        mock_result.fetchone.return_value = (1,)
        mock_create_engine.return_value = mock_engine

        result = health.check_database('postgresql://localhost/test')

        self.assertEqual(result['status'], 'healthy')
        self.assertTrue(result['available'])
        self.assertIn('latency_ms', result)
        self.assertEqual(result['type'], 'postgresql')

    @patch('sqlalchemy.create_engine')
    def test_check_database_sqlite(self, mock_create_engine):
        """Test database check with SQLite"""
        mock_engine = MagicMock()
        mock_conn = MagicMock()
        mock_result = MagicMock()

        mock_engine.connect.return_value.__enter__.return_value = mock_conn
        mock_conn.execute.return_value = mock_result
        mock_result.fetchone.return_value = (1,)
        mock_create_engine.return_value = mock_engine

        result = health.check_database('sqlite:///test.db')

        self.assertEqual(result['status'], 'healthy')
        self.assertTrue(result['available'])
        self.assertEqual(result['type'], 'sqlite')

    @patch('sqlalchemy.create_engine')
    def test_check_database_unhealthy(self, mock_create_engine):
        """Test database check when connection fails"""
        mock_create_engine.side_effect = Exception("Connection failed")

        result = health.check_database('postgresql://localhost/test')

        self.assertEqual(result['status'], 'unhealthy')
        self.assertFalse(result['available'])
        self.assertIn('error', result)

    @patch('celery_app.celery_app')
    def test_check_celery_healthy(self, mock_celery):
        """Test Celery health check when workers available"""
        mock_inspect = MagicMock()
        mock_inspect.active.return_value = {
            'celery@worker1': [],
            'celery@worker2': []
        }
        mock_inspect.stats.return_value = {
            'celery@worker1': {'total': {'audit_tasks.execute_audit_task': 100}},
            'celery@worker2': {'total': {'audit_tasks.execute_audit_task': 150}}
        }
        mock_celery.control.inspect.return_value = mock_inspect

        result = health.check_celery()

        self.assertEqual(result['status'], 'healthy')
        self.assertTrue(result['available'])
        self.assertEqual(result['workers'], 2)
        self.assertEqual(result['total_tasks_processed'], 250)

    @patch('celery_app.celery_app')
    def test_check_celery_no_workers(self, mock_celery):
        """Test Celery check when no workers responding"""
        mock_inspect = MagicMock()
        mock_inspect.active.return_value = None
        mock_celery.control.inspect.return_value = mock_inspect

        result = health.check_celery()

        self.assertEqual(result['status'], 'unhealthy')
        self.assertFalse(result['available'])
        self.assertEqual(result['workers'], 0)

    @patch('health.psutil.disk_usage')
    def test_check_disk_space_healthy(self, mock_disk):
        """Test disk space check when healthy"""
        mock_disk.return_value = Mock(
            total=100 * 1024**3,  # 100 GB
            used=50 * 1024**3,    # 50 GB
            free=50 * 1024**3,    # 50 GB
            percent=50.0
        )

        result = health.check_disk_space()

        self.assertEqual(result['status'], 'healthy')
        self.assertEqual(result['percent_free'], 50.0)

    @patch('health.psutil.disk_usage')
    def test_check_disk_space_warning(self, mock_disk):
        """Test disk space check with warning threshold"""
        mock_disk.return_value = Mock(
            total=100 * 1024**3,
            used=92 * 1024**3,
            free=8 * 1024**3,
            percent=92.0
        )

        result = health.check_disk_space()

        self.assertEqual(result['status'], 'warning')
        self.assertLess(result['percent_free'], 10)

    @patch('health.psutil.disk_usage')
    def test_check_disk_space_critical(self, mock_disk):
        """Test disk space check with critical threshold"""
        mock_disk.return_value = Mock(
            total=100 * 1024**3,
            used=98 * 1024**3,
            free=2 * 1024**3,
            percent=98.0
        )

        result = health.check_disk_space()

        self.assertEqual(result['status'], 'critical')
        self.assertLess(result['percent_free'], 5)

    @patch('health.psutil.virtual_memory')
    def test_check_memory_healthy(self, mock_memory):
        """Test memory check when healthy"""
        mock_memory.return_value = Mock(
            total=16 * 1024**3,      # 16 GB
            available=8 * 1024**3,   # 8 GB
            percent=50.0
        )

        result = health.check_memory()

        self.assertEqual(result['status'], 'healthy')
        self.assertEqual(result['percent_used'], 50.0)

    @patch('health.psutil.virtual_memory')
    def test_check_memory_warning(self, mock_memory):
        """Test memory check with warning threshold"""
        mock_memory.return_value = Mock(
            total=16 * 1024**3,
            available=2 * 1024**3,
            percent=87.5
        )

        result = health.check_memory()

        self.assertEqual(result['status'], 'warning')
        self.assertGreater(result['percent_used'], 85)

    @patch('health.psutil.cpu_percent')
    @patch('health.psutil.cpu_count')
    def test_check_cpu_healthy(self, mock_cpu_count, mock_cpu_percent):
        """Test CPU check when healthy"""
        mock_cpu_percent.return_value = 30.0
        mock_cpu_count.return_value = 8

        result = health.check_cpu()

        self.assertEqual(result['status'], 'healthy')
        self.assertEqual(result['percent'], 30.0)
        self.assertEqual(result['count'], 8)

    @patch('health.check_disk_space')
    @patch('health.check_memory')
    @patch('health.check_cpu')
    @patch('health.check_redis')
    @patch('health.check_database')
    @patch('health.check_celery')
    def test_comprehensive_health_check_all_healthy(
        self, mock_celery, mock_db, mock_redis,
        mock_cpu, mock_memory, mock_disk
    ):
        """Test comprehensive health check when all systems healthy"""
        mock_disk.return_value = {'status': 'healthy', 'percent_free': 50.0}
        mock_memory.return_value = {'status': 'healthy', 'percent_used': 50.0}
        mock_cpu.return_value = {'status': 'healthy', 'percent': 30.0}
        mock_redis.return_value = {'status': 'healthy', 'available': True}
        mock_db.return_value = {'status': 'healthy', 'available': True}
        mock_celery.return_value = {'status': 'healthy', 'available': True}

        health_data, status_code = health.comprehensive_health_check()

        self.assertEqual(health_data['status'], 'healthy')
        self.assertEqual(status_code, 200)
        self.assertIn('disk', health_data['checks'])
        self.assertIn('memory', health_data['checks'])
        self.assertIn('cpu', health_data['checks'])
        self.assertIn('redis', health_data['checks'])
        self.assertIn('database', health_data['checks'])
        self.assertIn('celery', health_data['checks'])

    @patch('health.check_disk_space')
    @patch('health.check_memory')
    @patch('health.check_cpu')
    @patch('health.check_redis')
    @patch('health.check_database')
    @patch('health.check_celery')
    def test_comprehensive_health_check_degraded(
        self, mock_celery, mock_db, mock_redis,
        mock_cpu, mock_memory, mock_disk
    ):
        """Test comprehensive health check with warnings"""
        mock_disk.return_value = {'status': 'warning', 'percent_free': 8.0}
        mock_memory.return_value = {'status': 'healthy', 'percent_used': 50.0}
        mock_cpu.return_value = {'status': 'healthy', 'percent': 30.0}
        mock_redis.return_value = {'status': 'healthy', 'available': True}
        mock_db.return_value = {'status': 'healthy', 'available': True}
        mock_celery.return_value = {'status': 'healthy', 'available': True}

        health_data, status_code = health.comprehensive_health_check()

        self.assertEqual(health_data['status'], 'degraded')
        self.assertEqual(status_code, 200)  # Still operational
        self.assertIn('warning_checks', health_data)
        self.assertIn('disk', health_data['warning_checks'])

    @patch('health.check_disk_space')
    @patch('health.check_memory')
    @patch('health.check_cpu')
    @patch('health.check_redis')
    @patch('health.check_database')
    @patch('health.check_celery')
    def test_comprehensive_health_check_unhealthy(
        self, mock_celery, mock_db, mock_redis,
        mock_cpu, mock_memory, mock_disk
    ):
        """Test comprehensive health check when unhealthy"""
        mock_disk.return_value = {'status': 'critical', 'percent_free': 2.0}
        mock_memory.return_value = {'status': 'healthy', 'percent_used': 50.0}
        mock_cpu.return_value = {'status': 'healthy', 'percent': 30.0}
        mock_redis.return_value = {'status': 'unhealthy', 'available': False}
        mock_db.return_value = {'status': 'healthy', 'available': True}
        mock_celery.return_value = {'status': 'healthy', 'available': True}

        health_data, status_code = health.comprehensive_health_check()

        self.assertIn(health_data['status'], ['critical', 'unhealthy'])
        self.assertEqual(status_code, 503)  # Service Unavailable

    @patch('health.check_database')
    @patch('health.check_redis')
    @patch('health.check_celery')
    def test_readiness_check_ready(self, mock_celery, mock_redis, mock_db):
        """Test readiness probe when ready"""
        mock_db.return_value = {'status': 'healthy', 'available': True}
        mock_redis.return_value = {'status': 'healthy', 'available': True}
        mock_celery.return_value = {'status': 'healthy', 'available': True}

        readiness_data, status_code = health.readiness_check()

        self.assertTrue(readiness_data['ready'])
        self.assertEqual(status_code, 200)

    @patch('health.check_database')
    @patch('health.check_redis')
    @patch('health.check_celery')
    def test_readiness_check_not_ready(self, mock_celery, mock_redis, mock_db):
        """Test readiness probe when database unhealthy"""
        mock_db.return_value = {'status': 'unhealthy', 'available': False}
        mock_redis.return_value = {'status': 'healthy', 'available': True}
        mock_celery.return_value = {'status': 'healthy', 'available': True}

        readiness_data, status_code = health.readiness_check()

        self.assertFalse(readiness_data['ready'])
        self.assertEqual(status_code, 503)
        self.assertIn('failures', readiness_data)
        self.assertIn('database', readiness_data['failures'])

    @patch('health.get_uptime')
    @patch('health.check_disk_space')
    @patch('health.check_memory')
    @patch('health.check_cpu')
    @patch('health.check_redis')
    @patch('health.check_database')
    @patch('health.check_celery')
    def test_generate_prometheus_metrics(
        self, mock_celery, mock_db, mock_redis,
        mock_cpu, mock_memory, mock_disk, mock_uptime
    ):
        """Test Prometheus metrics generation"""
        mock_uptime.return_value = 3600.0
        mock_disk.return_value = {
            'status': 'healthy',
            'free_gb': 50.0,
            'percent_used': 50.0
        }
        mock_memory.return_value = {
            'status': 'healthy',
            'percent_used': 50.0
        }
        mock_cpu.return_value = {
            'status': 'healthy',
            'percent': 30.0
        }
        mock_redis.return_value = {
            'status': 'healthy',
            'available': True,
            'latency_ms': 5.2
        }
        mock_db.return_value = {
            'status': 'healthy',
            'available': True,
            'latency_ms': 10.5
        }
        mock_celery.return_value = {
            'status': 'healthy',
            'available': True,
            'workers': 4
        }

        metrics = health.generate_prometheus_metrics()

        # Verify basic structure
        self.assertIn('audit_toolkit_info', metrics)
        self.assertIn('audit_toolkit_uptime_seconds', metrics)
        self.assertIn('audit_toolkit_disk_free_bytes', metrics)
        self.assertIn('audit_toolkit_disk_usage_percent', metrics)
        self.assertIn('audit_toolkit_memory_usage_percent', metrics)
        self.assertIn('audit_toolkit_cpu_usage_percent', metrics)
        self.assertIn('audit_toolkit_redis_health', metrics)
        self.assertIn('audit_toolkit_database_health', metrics)
        self.assertIn('audit_toolkit_celery_health', metrics)
        self.assertIn('audit_toolkit_celery_workers', metrics)

        # Verify values
        self.assertIn('3600', metrics)  # uptime
        self.assertIn('50.0', metrics)  # memory usage
        self.assertIn('30.0', metrics)  # CPU usage
        self.assertIn('audit_toolkit_redis_health 1', metrics)  # Redis healthy
        self.assertIn('audit_toolkit_database_health 1', metrics)  # DB healthy
        self.assertIn('audit_toolkit_celery_workers 4', metrics)  # 4 workers


if __name__ == '__main__':
    unittest.main()
