#!/usr/bin/env python3
"""Validate settings-driven rate-limit wiring on agent ingest endpoints."""

import ast
import unittest
from pathlib import Path


class TestIngestRateLimitWiring(unittest.TestCase):
    """Ensure ingest endpoints use dynamic upload limit helpers, not hardcoded strings."""

    ROOT = Path(__file__).resolve().parents[1]

    def _parse_module(self, relative_path: str) -> ast.Module:
        module_path = self.ROOT / relative_path
        source = module_path.read_text(encoding='utf-8')
        return ast.parse(source)

    def _get_function_node(self, tree: ast.Module, function_name: str) -> ast.FunctionDef:
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name == function_name:
                return node
        self.fail(f"Function {function_name} not found")

    def _assert_decorator_with_callable(self, function_node: ast.FunctionDef, decorator_name: str, callable_name: str):
        for deco in function_node.decorator_list:
            if isinstance(deco, ast.Call) and isinstance(deco.func, ast.Name) and deco.func.id == decorator_name:
                self.assertEqual(len(deco.args), 1, f"{decorator_name} must have exactly one argument")
                arg = deco.args[0]
                self.assertIsInstance(arg, ast.Name, f"{decorator_name} argument must be callable name")
                self.assertEqual(arg.id, callable_name)
                return
        self.fail(f"Decorator @{decorator_name}({callable_name}) not found on {function_node.name}")

    def test_standalone_ingest_uses_settings_limit(self):
        tree = self._parse_module('api/agent_routes.py')
        fn = self._get_function_node(tree, 'upload_results')
        self._assert_decorator_with_callable(fn, 'conditional_limit', 'get_standalone_upload_limit')

    def test_managed_ingest_uses_settings_limit(self):
        tree = self._parse_module('api/agent_fleet_routes.py')
        fn = self._get_function_node(tree, 'ingest_audit_results')
        self._assert_decorator_with_callable(fn, 'conditional_limit', 'get_managed_upload_limit')

    def test_hypervisor_ingest_uses_settings_limit(self):
        tree = self._parse_module('api/hypervisor_agent_routes.py')
        fn = self._get_function_node(tree, 'submit_results')
        self._assert_decorator_with_callable(fn, 'conditional_limit', 'get_hypervisor_upload_limit')

    def test_asset_discovery_receive_endpoints_use_settings_limit(self):
        tree = self._parse_module('api/asset_discovery_routes.py')
        for fn_name in (
            'receive_asset_sync',
            'receive_vulnerability_sync',
            'receive_scan_complete_notification',
        ):
            fn = self._get_function_node(tree, fn_name)
            self._assert_decorator_with_callable(fn, 'conditional_limit', 'get_asset_discovery_upload_limit')


if __name__ == '__main__':
    unittest.main()
