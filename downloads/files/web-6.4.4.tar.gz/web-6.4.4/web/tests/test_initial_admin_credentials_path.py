"""Regression tests for initial admin credentials file path resolution."""

import builtins
import io
import os
import sys
import unittest
from unittest.mock import patch, mock_open

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.user import (
    get_initial_admin_credentials_file_candidates,
    get_initial_admin_credentials_file_path,
)


class TestInitialAdminCredentialsFilePath(unittest.TestCase):
    @patch("models.user.get_initial_admin_credentials_file_candidates")
    @patch("models.user.os.path.exists")
    def test_returns_none_when_no_candidate_exists(self, mock_exists, mock_candidates):
        mock_candidates.return_value = ["/missing/one", "/missing/two"]
        mock_exists.return_value = False

        self.assertIsNone(get_initial_admin_credentials_file_path())

    @patch("models.user.get_initial_admin_credentials_file_candidates")
    @patch("models.user.os.path.exists")
    def test_returns_first_existing_candidate(self, mock_exists, mock_candidates):
        mock_candidates.return_value = ["/missing/one", "/exists/two", "/exists/three"]
        mock_exists.side_effect = lambda path: path == "/exists/two"

        real_open = builtins.open

        def fake_open(path, *args, **kwargs):
            if path == "/exists/two":
                return io.StringIO("")
            return real_open(path, *args, **kwargs)

        with patch("builtins.open", side_effect=fake_open):
            self.assertEqual(get_initial_admin_credentials_file_path(), "/exists/two")

    def test_candidates_include_stable_linux_and_windows_recovery_paths(self):
        with patch.dict(os.environ, {"PROGRAMDATA": r"C:\ProgramData"}, clear=False):
            candidates = get_initial_admin_credentials_file_candidates()

        self.assertIn("/etc/audit-toolkit/initial-admin-credentials.txt", candidates)
        self.assertIn(
            r"C:\ProgramData\SecurityAuditToolkit\runtime\initial-admin-credentials.txt",
            candidates,
        )


if __name__ == "__main__":
    unittest.main()
