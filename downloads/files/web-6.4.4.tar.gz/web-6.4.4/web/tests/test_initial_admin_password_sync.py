"""Regression tests for initial-admin bootstrap and upgrade-safe auth startup behavior."""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch

from flask import Flask

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from models.user import create_initial_admin
from reset_admin_password import remove_initial_admin_artifacts, repair_user_auth_state


class TestInitialAdminStartupBehavior(unittest.TestCase):
    def setUp(self):
        self.original_env_initial = os.environ.get("INITIAL_ADMIN_PASSWORD")
        self.original_env_admin = os.environ.get("ADMIN_PASSWORD")
        os.environ["INITIAL_ADMIN_PASSWORD"] = "ChangeMe123!"  # nosec B105 - deterministic test credential fixture
        os.environ.pop("ADMIN_PASSWORD", None)

    def tearDown(self):
        if self.original_env_initial is None:
            os.environ.pop("INITIAL_ADMIN_PASSWORD", None)
        else:
            os.environ["INITIAL_ADMIN_PASSWORD"] = self.original_env_initial

        if self.original_env_admin is None:
            os.environ.pop("ADMIN_PASSWORD", None)
        else:
            os.environ["ADMIN_PASSWORD"] = self.original_env_admin

    def _build_startup_db_with_builtin_admin(self, builtin_admin):
        startup_db = MagicMock()

        query_builtin = MagicMock()
        query_filter = MagicMock()
        query_filter.order_by.return_value.first.return_value = builtin_admin
        query_builtin.filter.return_value = query_filter

        def query_side_effect(model):
            model_name = getattr(model, "__name__", "")
            if model_name == "User":
                return query_builtin
            return MagicMock()

        startup_db.query.side_effect = query_side_effect
        return startup_db

    @patch("models.user.create_initial_admin")
    @patch("models.user.get_initial_admin_credentials_file_path")
    def test_existing_install_does_not_reset_password_when_change_required(self, mock_get_creds_path, mock_create_initial_admin):
        from auth_login import init_auth

        mock_create_initial_admin.return_value = (None, None)
        mock_get_creds_path.return_value = None

        builtin_admin = MagicMock()
        builtin_admin.must_change_password = True
        builtin_admin.is_active = True
        builtin_admin.is_locked = True
        builtin_admin.failed_login_attempts = 4
        builtin_admin.lockout_until = object()
        builtin_admin.check_password.return_value = False

        startup_db = self._build_startup_db_with_builtin_admin(builtin_admin)
        app = Flask(__name__)
        app.secret_key = "test-secret"  # nosec B105 - test-only Flask secret

        init_auth(app, lambda: startup_db)

        builtin_admin.set_password.assert_not_called()
        self.assertTrue(builtin_admin.must_change_password)
        self.assertTrue(builtin_admin.is_locked)
        self.assertEqual(builtin_admin.failed_login_attempts, 4)
        self.assertIsNotNone(builtin_admin.lockout_until)

        startup_db.commit.assert_not_called()

    @patch("models.user.create_initial_admin")
    @patch("models.user.get_initial_admin_credentials_file_path")
    def test_does_not_reset_password_after_first_change_completed(self, mock_get_creds_path, mock_create_initial_admin):
        from auth_login import init_auth

        mock_create_initial_admin.return_value = (None, None)
        mock_get_creds_path.return_value = None

        builtin_admin = MagicMock()
        builtin_admin.must_change_password = False
        builtin_admin.is_active = True
        builtin_admin.is_locked = True
        builtin_admin.failed_login_attempts = 5
        lockout_marker = object()
        builtin_admin.lockout_until = lockout_marker
        builtin_admin.check_password.return_value = False

        startup_db = self._build_startup_db_with_builtin_admin(builtin_admin)
        app = Flask(__name__)
        app.secret_key = "test-secret"  # nosec B105 - test-only Flask secret

        init_auth(app, lambda: startup_db)

        builtin_admin.set_password.assert_not_called()
        self.assertFalse(builtin_admin.must_change_password)
        self.assertTrue(builtin_admin.is_locked)
        self.assertEqual(builtin_admin.failed_login_attempts, 5)
        self.assertIs(builtin_admin.lockout_until, lockout_marker)
        startup_db.commit.assert_not_called()


class TestCreateInitialAdminInstallerDefaults(unittest.TestCase):
    def setUp(self):
        self.original_env = {
            "FLASK_ENV": os.environ.get("FLASK_ENV"),
            "ENVIRONMENT": os.environ.get("ENVIRONMENT"),
            "INITIAL_ADMIN_PASSWORD": os.environ.get("INITIAL_ADMIN_PASSWORD"),
            "ADMIN_PASSWORD": os.environ.get("ADMIN_PASSWORD"),
            "AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD": os.environ.get("AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD"),
        }
        for key in self.original_env:
            os.environ.pop(key, None)

    def tearDown(self):
        for key, value in self.original_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

    @staticmethod
    def _build_empty_db():
        db_session = MagicMock()
        db_session.query.return_value.count.return_value = 0
        return db_session

    @patch("models.user.persist_initial_admin_credentials", return_value="/tmp/initial-admin-credentials.txt")
    @patch("models.user.AuthAuditLog")
    def test_production_installs_default_to_known_password(self, _mock_log, _mock_persist):
        os.environ["FLASK_ENV"] = "production"
        db_session = self._build_empty_db()

        admin, password = create_initial_admin(db_session)

        self.assertEqual(password, "ChangeMe123!")
        self.assertTrue(admin.check_password("ChangeMe123!"))
        self.assertTrue(admin.must_change_password)

    @patch("models.user.persist_initial_admin_credentials", return_value="/tmp/initial-admin-credentials.txt")
    @patch("models.user.AuthAuditLog")
    @patch("models.user.generate_secure_password", return_value="Rand0m!Pass123")
    def test_randomization_can_be_explicitly_opted_in(self, _mock_generate, _mock_log, _mock_persist):
        os.environ["FLASK_ENV"] = "production"
        os.environ["AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD"] = "1"
        db_session = self._build_empty_db()

        admin, password = create_initial_admin(db_session)

        self.assertEqual(password, "Rand0m!Pass123")
        self.assertTrue(admin.check_password("Rand0m!Pass123"))
        self.assertNotEqual(password, "ChangeMe123!")


class TestBuiltInAdminRecovery(unittest.TestCase):
    def test_repair_user_auth_state_resets_builtin_admin_login_flow(self):
        user = MagicMock()
        user.username = "admin"
        user.must_change_password = False
        user.is_active = False
        user.auth_provider = "ldap"
        user.is_locked = True
        user.failed_login_attempts = 7
        user.lockout_until = object()
        user.is_builtin_admin = False
        user.disclaimer_accepted_at = object()
        user.disclaimer_version = "6.0.0"

        repair_user_auth_state(
            user,
            unlock_only=False,
            password="ChangeMe123!",
            must_change=True,
            repair_builtin_admin=True,
            clear_disclaimer=True,
        )

        user.set_password.assert_called_once_with("ChangeMe123!")
        self.assertTrue(user.is_active)
        self.assertEqual(user.auth_provider, "local")
        self.assertFalse(user.is_locked)
        self.assertEqual(user.failed_login_attempts, 0)
        self.assertIsNone(user.lockout_until)
        self.assertTrue(user.must_change_password)
        self.assertTrue(user.is_builtin_admin)
        self.assertIsNone(user.disclaimer_accepted_at)
        self.assertIsNone(user.disclaimer_version)

    def test_remove_initial_admin_artifacts_removes_known_paths_under_root(self):
        from pathlib import Path
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as temp_dir:
            root_dir = Path(temp_dir)
            data_dir = root_dir / "data"
            data_dir.mkdir()
            app_creds = data_dir / "initial-admin-credentials.txt"
            root_creds = root_dir / ".initial-admin-credentials"
            first_boot = root_dir / ".first-boot-complete"

            for target in (app_creds, root_creds, first_boot):
                target.write_text("stale")

            removed = remove_initial_admin_artifacts(root_dir)

            self.assertIn(str(app_creds), removed)
            self.assertIn(str(root_creds), removed)
            self.assertIn(str(first_boot), removed)
            self.assertFalse(app_creds.exists())
            self.assertFalse(root_creds.exists())
            self.assertFalse(first_boot.exists())


if __name__ == "__main__":
    unittest.main()
