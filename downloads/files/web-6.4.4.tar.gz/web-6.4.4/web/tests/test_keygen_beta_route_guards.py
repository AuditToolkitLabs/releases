#!/usr/bin/env python3
"""Regression tests for Keygen beta create-route guardrails."""

import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from flask import Flask

# Add web/ to import path
sys.path.insert(0, str(Path(__file__).parent.parent))

from api import license_routes


def _unwrap(func):
    while hasattr(func, "__wrapped__"):
        func = func.__wrapped__
    return func


class TestKeygenCreateRouteBetaGuards(unittest.TestCase):
    """Validate beta-tier defaults and request guardrails."""

    def setUp(self):
        self.app = Flask(__name__)
        self.raw_create = _unwrap(license_routes.create_keygen_license)

    def _invoke(self, payload):
        with self.app.test_request_context(
            "/api/license/keygen/create",
            method="POST",
            json=payload,
        ):
            return self.app.make_response(self.raw_create())

    @patch("services_pkg.services.keygen_integration.get_keygen_client")
    def test_beta_defaults_expiry_to_30_days(self, mock_get_keygen_client):
        mock_keygen = Mock()
        mock_keygen.create_license.return_value = (
            True,
            {
                "key": "BETA-TEST-KEY",
                "id": "lic_123",
                "tier": "beta",
                "expires_at": "2026-04-01T00:00:00Z",
                "machines_limit": 25,
            },
        )
        mock_get_keygen_client.return_value = mock_keygen

        response = self._invoke(
            {
                "tier": "beta",
                "email": "beta-customer@example.com",
            }
        )

        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.get_json().get("tier"), "beta")

        kwargs = mock_keygen.create_license.call_args.kwargs
        self.assertEqual(kwargs.get("tier"), "beta")
        self.assertEqual(kwargs.get("email"), "beta-customer@example.com")
        self.assertEqual(kwargs.get("expires_in_days"), 30)
        self.assertEqual(kwargs.get("machines_limit"), 25)
        self.assertEqual(kwargs.get("metadata"), {})

    @patch("services_pkg.services.keygen_integration.get_keygen_client")
    def test_beta_rejects_expiry_over_90_days(self, mock_get_keygen_client):
        response = self._invoke(
            {
                "tier": "beta",
                "email": "beta-customer@example.com",
                "expires_in_days": 120,
            }
        )

        self.assertEqual(response.status_code, 400)
        self.assertIn("maximum of 90 days", response.get_json().get("error", ""))
        mock_get_keygen_client.assert_not_called()

    @patch("services_pkg.services.keygen_integration.get_keygen_client")
    def test_rejects_non_object_metadata(self, mock_get_keygen_client):
        response = self._invoke(
            {
                "tier": "beta",
                "email": "beta-customer@example.com",
                "metadata": "not-an-object",
            }
        )

        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.get_json().get("error"), "metadata must be an object")
        mock_get_keygen_client.assert_not_called()


if __name__ == "__main__":
    unittest.main()
