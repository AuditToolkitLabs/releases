#!/usr/bin/env python3
"""Route-level regression tests for Keygen create across all supported tiers."""

import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from flask import Flask

# Add web/ to import path
sys.path.insert(0, str(Path(__file__).parent.parent))

from api import license_routes


def _unwrap(func):
    while hasattr(func, "__wrapped__"):
        func = func.__wrapped__
    return func


class TestKeygenCreateAllTiers(unittest.TestCase):
    """Validate create endpoint behavior across all tier levels."""

    def setUp(self):
        self.app = Flask(__name__)
        self.raw_create = _unwrap(license_routes.create_keygen_license)

    def _invoke(self, payload):
        with self.app.test_request_context(
            "/api/license/keygen/create",
            method="POST",
            json=payload,
        ):
            return self.app.make_response(self.raw_create())

    @patch("services_pkg.services.keygen_integration.get_keygen_client")
    def test_create_accepts_all_supported_tiers(self, mock_get_keygen_client):
        mock_keygen = Mock()

        def _fake_create_license(**kwargs):
            return (
                True,
                {
                    "key": f"{kwargs['tier'].upper()}-KEY-1234",
                    "id": f"lic-{kwargs['tier']}",
                    "tier": kwargs["tier"],
                    "expires_at": "2026-12-31T00:00:00Z",
                    "machines_limit": kwargs["machines_limit"],
                },
            )

        mock_keygen.create_license.side_effect = _fake_create_license
        mock_get_keygen_client.return_value = mock_keygen

        tiers = ["free", "beta", "starter", "professional", "business", "enterprise"]

        for index, tier in enumerate(tiers):
            with self.subTest(tier=tier):
                response = self._invoke(
                    {
                        "tier": tier,
                        "email": "customer@example.com",
                    }
                )

                self.assertEqual(response.status_code, 201)
                body = response.get_json()
                self.assertTrue(body.get("success"))
                self.assertEqual(body.get("tier"), tier)

                call_kwargs = mock_keygen.create_license.call_args_list[index].kwargs
                self.assertEqual(call_kwargs.get("tier"), tier)
                self.assertEqual(call_kwargs.get("email"), "customer@example.com")
                self.assertEqual(call_kwargs.get("machines_limit"), 25)
                self.assertEqual(call_kwargs.get("metadata"), {})

                expected_expiry_days = 30 if tier == "beta" else 365
                self.assertEqual(call_kwargs.get("expires_in_days"), expected_expiry_days)

    @patch("services_pkg.services.keygen_integration.get_keygen_client")
    def test_create_rejects_unknown_tier(self, mock_get_keygen_client):
        response = self._invoke(
            {
                "tier": "ultimate",
                "email": "customer@example.com",
            }
        )

        self.assertEqual(response.status_code, 400)
        self.assertIn("Invalid tier", response.get_json().get("error", ""))
        mock_get_keygen_client.assert_not_called()


if __name__ == "__main__":
    unittest.main()
