#!/usr/bin/env python3
"""Regression tests for Keygen integration fallback behaviors."""

import os
import sys
import unittest
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch

# Add web/ to import path
sys.path.insert(0, str(Path(__file__).parent.parent))

from services_pkg.services.keygen_integration import KeygenIntegration


class _FakeResponse:
    def __init__(self, status_code, payload=None, text=""):
        self.status_code = status_code
        self._payload = payload or {}
        self.text = text

    def json(self):
        return self._payload


class TestKeygenIntegrationFallbacks(unittest.TestCase):
    """Validate retry and parser compatibility paths."""

    @patch.dict(os.environ, {"KEYGEN_POLICY_BETA": "policy-beta-id"}, clear=False)
    def test_create_license_retries_without_max_machines_on_422(self):
        integration = KeygenIntegration("api-key", "account-id", "product-id")

        posted_payloads = []
        responses = [
            _FakeResponse(
                422,
                {
                    "errors": [
                        {
                            "code": "MAX_MACHINES_INVALID",
                            "detail": "must be equal to 1 for non-floating policy",
                        }
                    ]
                },
                text='{"errors":[{"code":"MAX_MACHINES_INVALID"}]}',
            ),
            _FakeResponse(
                201,
                {
                    "data": {
                        "id": "lic_beta_1",
                        "attributes": {
                            "key": "BETA-XXXX-YYYY",
                            "status": "ACTIVE",
                            "expiry": "2026-04-01T00:00:00Z",
                            "machinesCount": 0,
                            "metadata": {
                                "tier": "beta",
                                "machines_limit": 25,
                            },
                        },
                    }
                },
            ),
        ]

        def fake_post(_url, json=None, timeout=None):
            posted_payloads.append(deepcopy(json))
            return responses.pop(0)

        integration.session.post = fake_post

        success, result = integration.create_license(
            tier="beta",
            email="beta-customer@example.com",
            expires_in_days=30,
            machines_limit=25,
            metadata={"order_id": "ORD-1001"},
        )

        self.assertTrue(success)
        self.assertEqual(result.get("tier"), "beta")
        self.assertEqual(len(posted_payloads), 2)

        first_attrs = posted_payloads[0]["data"]["attributes"]
        second_attrs = posted_payloads[1]["data"]["attributes"]

        self.assertEqual(first_attrs.get("maxMachines"), 25)
        self.assertNotIn("maxMachines", second_attrs)

    def test_parse_license_response_accepts_camel_case_metadata(self):
        integration = KeygenIntegration("api-key", "account-id", "product-id")

        parsed = integration._parse_license_response(
            {
                "data": {
                    "id": "lic_starter_1",
                    "attributes": {
                        "key": "START-XXXX-YYYY",
                        "status": "ACTIVE",
                        "expiry": "2026-04-15T00:00:00Z",
                        "machinesCount": 3,
                        "metadata": {
                            "licenseTier": "starter",
                            "machinesLimit": 50,
                            "releaseChannel": "beta",
                        },
                    },
                }
            }
        )

        self.assertEqual(parsed.get("tier"), "starter")
        self.assertEqual(parsed.get("machines_limit"), 50)
        self.assertEqual(parsed.get("expires_at"), "2026-04-15T00:00:00Z")


if __name__ == "__main__":
    unittest.main()
