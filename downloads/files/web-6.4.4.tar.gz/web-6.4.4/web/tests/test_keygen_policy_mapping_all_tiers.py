#!/usr/bin/env python3
"""KeygenIntegration policy mapping tests across all supported tiers."""

import os
import sys
import unittest
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch

# Add web/ to import path
sys.path.insert(0, str(Path(__file__).parent.parent))

from services_pkg.services.keygen_integration import KeygenIntegration


class _FakeResponse:
    def __init__(self, status_code, payload=None, text=""):
        self.status_code = status_code
        self._payload = payload or {}
        self.text = text

    def json(self):
        return self._payload


class TestKeygenPolicyMappingAllTiers(unittest.TestCase):
    """Validate tier-to-policy mapping and metadata across all tiers."""

    @patch.dict(
        os.environ,
        {
            "KEYGEN_POLICY_FREE": "policy-free",
            "KEYGEN_POLICY_BETA": "policy-beta",
            "KEYGEN_POLICY_STARTER": "policy-starter",
            "KEYGEN_POLICY_PROFESSIONAL": "policy-professional",
            "KEYGEN_POLICY_BUSINESS": "policy-business",
            "KEYGEN_POLICY_ENTERPRISE": "policy-enterprise",
        },
        clear=False,
    )
    def test_create_license_uses_correct_policy_for_each_tier(self):
        integration = KeygenIntegration("api-key", "account-id", "product-id")
        sent_payloads = []

        def _fake_post(_url, json=None, timeout=None):
            sent_payloads.append(deepcopy(json))

            attributes = json["data"]["attributes"]
            metadata = attributes.get("metadata", {})

            return _FakeResponse(
                201,
                {
                    "data": {
                        "id": f"lic-{metadata.get('tier', 'unknown')}",
                        "attributes": {
                            "key": "KEY-XXXX-YYYY",
                            "status": "ACTIVE",
                            "expiry": "2026-12-31T00:00:00Z",
                            "machinesCount": 0,
                            "metadata": metadata,
                        },
                    }
                },
            )

        integration.session.post = _fake_post

        expected_policies = {
            "free": "policy-free",
            "beta": "policy-beta",
            "starter": "policy-starter",
            "professional": "policy-professional",
            "business": "policy-business",
            "enterprise": "policy-enterprise",
        }

        for tier, policy_id in expected_policies.items():
            with self.subTest(tier=tier):
                success, result = integration.create_license(
                    tier=tier,
                    email="customer@example.com",
                    expires_in_days=45,
                    machines_limit=25,
                    metadata={"order_id": f"ORD-{tier}"},
                )

                self.assertTrue(success)
                self.assertEqual(result.get("tier"), tier)

                payload = sent_payloads[-1]
                self.assertEqual(
                    payload["data"]["relationships"]["policy"]["data"]["id"],
                    policy_id,
                )

                metadata = payload["data"]["attributes"]["metadata"]
                self.assertEqual(metadata.get("tier"), tier)
                self.assertEqual(metadata.get("email"), "customer@example.com")
                self.assertEqual(metadata.get("order_id"), f"ORD-{tier}")

                if tier == "beta":
                    self.assertEqual(metadata.get("release_channel"), "beta")
                    self.assertEqual(metadata.get("beta_program"), "customer_evaluation")


if __name__ == "__main__":
    unittest.main()
