#!/usr/bin/env python3
"""Regression tests for host-bound Keygen validation route behavior."""

import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from flask import Flask

# Add web/ to import path
sys.path.insert(0, str(Path(__file__).parent.parent))

from api import license_routes


class TestKeygenValidateHostBinding(unittest.TestCase):
    """Ensure Keygen validation uses local fingerprint and persists host binding."""

    def setUp(self):
        self.app = Flask(__name__)
        self.app.register_blueprint(license_routes.license_bp)
        self.client = self.app.test_client()

    @patch("services_pkg.services.keygen_integration.get_keygen_client")
    @patch("api.license_routes.get_license_service")
    def test_validate_ignores_client_machine_id(self, mock_get_license_service, mock_get_keygen_client):
        mock_service = Mock()
        mock_service._get_machine_fingerprint.return_value = "local-install-fingerprint"
        mock_service.activate_keygen_license.return_value = {"success": True}
        mock_get_license_service.return_value = mock_service

        mock_keygen = Mock()
        mock_keygen.validate_key.return_value = (
            True,
            {
                "key": "KEYGEN-VALID-123",
                "id": "lic_123",
                "tier": "professional",
                "expires_at": "2027-03-11T00:00:00Z",
                "machines_count": 1,
                "machines_limit": 150,
                "metadata": {"email": "customer@example.com"},
            },
        )
        mock_get_keygen_client.return_value = mock_keygen

        response = self.client.post(
            "/api/license/keygen/validate",
            json={"key": "KEYGEN-VALID-123", "machine_id": "caller-spoofed-id"},
        )

        self.assertEqual(response.status_code, 200)
        mock_keygen.validate_key.assert_called_once_with("KEYGEN-VALID-123", "local-install-fingerprint")

        mock_service.activate_keygen_license.assert_called_once()
        activate_kwargs = mock_service.activate_keygen_license.call_args.kwargs
        self.assertEqual(activate_kwargs["license_key"], "KEYGEN-VALID-123")
        self.assertEqual(activate_kwargs["tier"], "professional")

        body = response.get_json()
        self.assertTrue(body.get("host_bound"))
        self.assertEqual(body.get("machine_id"), "local-install-fingerprint")

    @patch("services_pkg.services.keygen_integration.get_keygen_client")
    @patch("api.license_routes.get_license_service")
    def test_validate_fails_when_local_persist_fails(self, mock_get_license_service, mock_get_keygen_client):
        mock_service = Mock()
        mock_service._get_machine_fingerprint.return_value = "local-install-fingerprint"
        mock_service.activate_keygen_license.return_value = {
            "success": False,
            "message": "Cannot activate an expired Keygen license",
        }
        mock_get_license_service.return_value = mock_service

        mock_keygen = Mock()
        mock_keygen.validate_key.return_value = (
            True,
            {
                "key": "KEYGEN-VALID-123",
                "id": "lic_123",
                "tier": "professional",
                "expires_at": "2025-01-01T00:00:00Z",
                "machines_count": 1,
                "machines_limit": 150,
                "metadata": {},
            },
        )
        mock_get_keygen_client.return_value = mock_keygen

        response = self.client.post(
            "/api/license/keygen/validate",
            json={"key": "KEYGEN-VALID-123"},
        )

        self.assertEqual(response.status_code, 400)
        body = response.get_json()
        self.assertFalse(body.get("success"))
        self.assertIn("expired", body.get("error", ""))


if __name__ == "__main__":
    unittest.main()
