#!/usr/bin/env python3
"""Route-level tests for /api/license/generate across supported tiers."""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from flask import Flask

# Add web/ to import path
sys.path.insert(0, str(Path(__file__).parent.parent))

from api import license_routes


def _unwrap(func):
    while hasattr(func, "__wrapped__"):
        func = func.__wrapped__
    return func


class TestLicenseGenerateRouteAllTiers(unittest.TestCase):
    """Validate /api/license/generate for all supported paid tiers."""

    def setUp(self):
        self.app = Flask(__name__)
        self.raw_generate = _unwrap(license_routes.generate_license_key)

    def _invoke(self, payload):
        with self.app.test_request_context(
            "/api/license/generate",
            method="POST",
            json=payload,
        ):
            return self.app.make_response(self.raw_generate())

    @patch("auth_core.get_current_user", return_value={"role": "superadmin"})
    @patch("services_pkg.services.license_service.LicenseService.generate_license_key")
    def test_generate_accepts_all_supported_tiers(self, mock_generate, _mock_user):
        mock_generate.side_effect = [
            "STRT-AAAA-BBBB-CCCC",
            "PROF-AAAA-BBBB-CCCC",
            "BUSN-AAAA-BBBB-CCCC",
            "ENTR-AAAA-BBBB-CCCC",
        ]

        tiers = ["starter", "professional", "business", "enterprise"]

        for tier in tiers:
            with self.subTest(tier=tier):
                response = self._invoke({"tier": tier})
                self.assertEqual(response.status_code, 200)
                body = response.get_json()
                self.assertTrue(body.get("success"))
                self.assertEqual(body.get("tier"), tier)
                self.assertIsInstance(body.get("key"), str)

        self.assertEqual(mock_generate.call_count, 4)

    @patch("auth_core.get_current_user", return_value={"role": "superadmin"})
    @patch("services_pkg.services.license_service.LicenseService.generate_license_key")
    def test_generate_rejects_unknown_tier(self, mock_generate, _mock_user):
        response = self._invoke({"tier": "ultimate"})

        self.assertEqual(response.status_code, 400)
        self.assertIn("Invalid tier", response.get_json().get("message", ""))
        mock_generate.assert_not_called()


if __name__ == "__main__":
    unittest.main()
