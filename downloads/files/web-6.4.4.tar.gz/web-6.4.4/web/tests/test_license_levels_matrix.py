#!/usr/bin/env python3
"""Comprehensive licensing tier matrix tests."""

import math
import sys
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

# Add web/ to import path
sys.path.insert(0, str(Path(__file__).parent.parent))

from services_pkg.services.license_service import (
    ENTERPRISE_FEATURE_PACK_MARKER,
    DELEGATED_AGENT_LIMITS,
    LicenseInfo,
    LicenseService,
    LicenseTier,
    STANDALONE_KEY_LIMITS,
    TRIAL_CONFIG,
    get_delegated_agent_limit_for_tier,
    get_standalone_key_limit_for_tier,
)
from services_pkg.services.feature_licensing import (
    Feature,
    FEATURE_CONFIG,
    FeatureLicenseService,
    LicenseTier as FeatureLicenseTier,
)


class TestLicenseLevelsMatrix(unittest.TestCase):
    """Validate core licensing behavior across all tiers."""

    def test_live_delegated_and_standalone_limits_are_separate(self):
        expected_delegated_limits = {
            LicenseTier.FREE.value: 0,
            LicenseTier.COMMUNITY.value: 0,
            LicenseTier.TRIAL.value: TRIAL_CONFIG["machine_limit"],
            LicenseTier.STARTER.value: 50,
            LicenseTier.PROFESSIONAL.value: 150,
            LicenseTier.BUSINESS.value: 500,
            LicenseTier.ENTERPRISE.value: 10000,
        }
        expected_standalone_limits = {
            LicenseTier.FREE.value: 0,
            LicenseTier.COMMUNITY.value: 0,
            LicenseTier.TRIAL.value: 3,
            LicenseTier.STARTER.value: 10,
            LicenseTier.PROFESSIONAL.value: 50,
            LicenseTier.BUSINESS.value: 100,
            LicenseTier.ENTERPRISE.value: 250,
        }

        self.assertEqual(DELEGATED_AGENT_LIMITS, expected_delegated_limits)
        self.assertEqual(STANDALONE_KEY_LIMITS, expected_standalone_limits)

        for tier, expected_limit in expected_delegated_limits.items():
            with self.subTest(pool="delegated", tier=tier):
                self.assertEqual(get_delegated_agent_limit_for_tier(tier), expected_limit)

        for tier, expected_limit in expected_standalone_limits.items():
            with self.subTest(pool="standalone", tier=tier):
                self.assertEqual(get_standalone_key_limit_for_tier(tier), expected_limit)

        self.assertEqual(get_delegated_agent_limit_for_tier("unknown-tier"), 0)
        self.assertEqual(get_standalone_key_limit_for_tier("unknown-tier"), 0)

    def test_machine_limits_across_all_tiers(self):
        expected_limits = {
            LicenseTier.FREE: 25,
            LicenseTier.TRIAL: TRIAL_CONFIG["machine_limit"],
            LicenseTier.STARTER: 50,
            LicenseTier.PROFESSIONAL: 150,
            LicenseTier.BUSINESS: 500,
            LicenseTier.ENTERPRISE: float("inf"),
        }

        for tier, expected_limit in expected_limits.items():
            with self.subTest(tier=tier.value):
                info = LicenseInfo(tier=tier)
                if math.isinf(expected_limit):
                    self.assertTrue(math.isinf(info.machine_limit))
                else:
                    self.assertEqual(info.machine_limit, expected_limit)

    def test_feature_progression_across_paid_tiers(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            service = LicenseService(data_dir=temp_dir)

            starter_features = set(service._get_tier_features(LicenseTier.STARTER))
            professional_features = set(service._get_tier_features(LicenseTier.PROFESSIONAL))
            business_features = set(service._get_tier_features(LicenseTier.BUSINESS))
            enterprise_features = set(service._get_tier_features(LicenseTier.ENTERPRISE))

        self.assertSetEqual(starter_features, {"unlimited_audits", "basic_reports"})
        self.assertTrue(starter_features.issubset(professional_features))
        self.assertTrue(professional_features.issubset(business_features))
        self.assertTrue(business_features.issubset(enterprise_features))

        self.assertIn("scheduling", professional_features)
        self.assertIn("parallel_execution", business_features)
        self.assertIn("dedicated_support", enterprise_features)

    def test_generate_and_validate_keys_for_all_sellable_tiers(self):
        tier_prefixes = {
            LicenseTier.STARTER: "STRT",
            LicenseTier.PROFESSIONAL: "PROF",
            LicenseTier.BUSINESS: "BUSN",
            LicenseTier.ENTERPRISE: "ENTR",
        }

        original_secret = LicenseService.LICENSE_SECRET
        LicenseService.LICENSE_SECRET = "unit-test-license-secret"

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                service = LicenseService(data_dir=temp_dir)

                for tier, prefix in tier_prefixes.items():
                    with self.subTest(tier=tier.value):
                        key = LicenseService.generate_license_key(tier)
                        self.assertTrue(key.startswith(f"{prefix}-"), key)

                        validation = service._validate_key_offline(key)
                        self.assertTrue(validation.get("valid"))
                        self.assertEqual(validation.get("tier"), tier)
        finally:
            LicenseService.LICENSE_SECRET = original_secret

    def test_paid_license_is_host_bound_and_non_transferable(self):
        original_secret = LicenseService.LICENSE_SECRET
        LicenseService.LICENSE_SECRET = "unit-test-license-secret"

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                with patch.object(LicenseService, "_get_machine_fingerprint", return_value="host-a-fingerprint"):
                    service = LicenseService(data_dir=temp_dir)
                    key = LicenseService.generate_license_key(LicenseTier.PROFESSIONAL)
                    activation = service.activate_license(key)
                    self.assertTrue(activation.get("success"))
                    self.assertEqual(activation["license"].get("tier"), "professional")

                with patch.object(LicenseService, "_get_machine_fingerprint", return_value="host-a-fingerprint"):
                    same_host_service = LicenseService(data_dir=temp_dir)
                    self.assertEqual(same_host_service.license_info.tier, LicenseTier.PROFESSIONAL)

                with patch.object(LicenseService, "_get_machine_fingerprint", return_value="host-b-fingerprint"):
                    transferred_service = LicenseService(data_dir=temp_dir)
                    self.assertEqual(
                        transferred_service.license_info.tier,
                        LicenseTier.FREE,
                        "License should downgrade on fingerprint mismatch",
                    )
        finally:
            LicenseService.LICENSE_SECRET = original_secret

    def test_addon_key_requires_professional_or_higher_base_license(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            service = LicenseService(data_dir=temp_dir)
            now = datetime.utcnow()

            service._license_info = LicenseInfo(
                tier=LicenseTier.STARTER,
                key="starter-base",
                issued=now,
                expires=now + timedelta(days=365),
                features=service._get_tier_features(LicenseTier.STARTER),
                machine_id="starter-host",
            )

            denied = service.activate_keygen_license(
                license_key="addon-key",
                tier="addon",
                expires_at=None,
                metadata={"addons": ["enterprise_feature_pack"]},
            )

            self.assertFalse(denied["success"])
            self.assertIn("Professional or higher base license", denied["message"])

            service._license_info = LicenseInfo(
                tier=LicenseTier.PROFESSIONAL,
                key="professional-base",
                issued=now,
                expires=now + timedelta(days=365),
                features=service._get_tier_features(LicenseTier.PROFESSIONAL),
                machine_id="professional-host",
            )

            allowed = service.activate_keygen_license(
                license_key="addon-key",
                tier="addon",
                expires_at=None,
                metadata={"addons": ["enterprise_feature_pack"]},
            )

            self.assertTrue(allowed["success"])
            self.assertIn("Enterprise Integrations Pack", allowed["message"])
            self.assertIn(ENTERPRISE_FEATURE_PACK_MARKER, allowed["license"]["features"])

    def test_addon_unlocked_features_still_require_professional_base_tier(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            service = FeatureLicenseService(data_dir=Path(temp_dir))

            with patch.object(service, "get_current_license_tier", return_value=FeatureLicenseTier.STARTER), \
                 patch.object(service, "_has_enterprise_feature_pack_addon", return_value=True):
                starter_status = service.is_feature_available(Feature.HYPERVISOR_AUDIT_ADVANCED)

            self.assertFalse(starter_status["available"])
            self.assertEqual(starter_status["upgrade_tier"], "professional+advanced_operations_pack")

            with patch.object(service, "get_current_license_tier", return_value=FeatureLicenseTier.PROFESSIONAL), \
                 patch.object(service, "_has_enterprise_feature_pack_addon", return_value=True):
                professional_status = service.is_feature_available(Feature.HYPERVISOR_AUDIT_ADVANCED)

            self.assertTrue(professional_status["available"])
            self.assertEqual(professional_status["activation_type"], "addon")

    def test_external_ingest_features_require_business_plus_addon(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            service = FeatureLicenseService(data_dir=Path(temp_dir))

            with patch.object(service, "get_current_license_tier", return_value=FeatureLicenseTier.BUSINESS), \
                 patch.object(service, "_has_enterprise_feature_pack_addon", return_value=False):
                source_without_addon = service.is_feature_available(Feature.EXTERNAL_SOURCE_INGEST)
                asset_without_addon = service.is_feature_available(Feature.EXTERNAL_ASSET_PUSH)

            self.assertFalse(source_without_addon["available"])
            self.assertEqual(source_without_addon["upgrade_tier"], "business+advanced_operations_pack")

            self.assertFalse(asset_without_addon["available"])
            self.assertEqual(asset_without_addon["upgrade_tier"], "business+advanced_operations_pack")

            with patch.object(service, "get_current_license_tier", return_value=FeatureLicenseTier.BUSINESS), \
                 patch.object(service, "_has_enterprise_feature_pack_addon", return_value=True):
                source_with_addon = service.is_feature_available(Feature.EXTERNAL_SOURCE_INGEST)
                asset_with_addon = service.is_feature_available(Feature.EXTERNAL_ASSET_PUSH)

            self.assertTrue(source_with_addon["available"])
            self.assertEqual(source_with_addon["activation_type"], "addon")

            self.assertTrue(asset_with_addon["available"])
            self.assertEqual(asset_with_addon["activation_type"], "addon")

    def test_no_feature_uses_enterprise_min_tier_gates(self):
        enterprise_gated = [
            feature.value
            for feature, config in FEATURE_CONFIG.items()
            if config.get("min_tier") == FeatureLicenseTier.ENTERPRISE
        ]
        self.assertEqual(
            enterprise_gated,
            [],
            msg=f"Enterprise min-tier gates remain configured: {enterprise_gated}",
        )

    def test_addon_gated_features_require_professional_or_higher(self):
        invalid = [
            feature.value
            for feature, config in FEATURE_CONFIG.items()
            if config.get("requires_enterprise_feature_pack_addon")
            and config.get("min_tier") not in {FeatureLicenseTier.PROFESSIONAL, FeatureLicenseTier.BUSINESS}
        ]
        self.assertEqual(
            invalid,
            [],
            msg=f"Addon-gated features must be Professional+ base tier: {invalid}",
        )


if __name__ == "__main__":
    unittest.main()
