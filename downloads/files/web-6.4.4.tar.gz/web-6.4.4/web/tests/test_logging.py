#!/usr/bin/env python3
"""
Logging System Test

Tests the new structured logging system:
- JSON formatting
- Log rotation
- Correlation IDs
- Multiple log levels
- Contextual logging

Usage:
    python3 test_logging.py

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import sys
from pathlib import Path

# Add web directory to path for importing logging_config
sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from logging_config import (
    setup_logging, get_logger, CorrelationContext,
    generate_correlation_id
)
import logging


def test_basic_logging():
    """Test basic logging functionality"""
    print("\n" + "="*70)
    print("Test 1: Basic Logging")
    print("="*70)

    logger = logging.getLogger('test.basic')

    logger.debug("This is a DEBUG message")
    logger.info("This is an INFO message")
    logger.warning("This is a WARNING message")
    logger.error("This is an ERROR message")
    logger.critical("This is a CRITICAL message")

    print("✓ Basic logging test complete")


def test_structured_logging():
    """Test structured logging with extra fields"""
    print("\n" + "="*70)
    print("Test 2: Structured Logging")
    print("="*70)

    logger = logging.getLogger('test.structured')

    # Log with extra context
    logger.info(
        "Audit execution started",
        extra={
            'server_id': 42,
            'server_name': 'web-01',
            'audit_path': 'platform/baseline/updates.sh',
            'execution_id': 'exec-12345'
        }
    )

    logger.info(
        "SSH connection established",
        extra={
            'hostname': 'web-01.example.com',
            'port': 22,
            'username': 'admin',
            'connection_time_ms': 150
        }
    )

    print("✓ Structured logging test complete")


def test_correlation_ids():
    """Test correlation ID tracking"""
    print("\n" + "="*70)
    print("Test 3: Correlation IDs")
    print("="*70)

    logger = logging.getLogger('test.correlation')

    # Without correlation ID
    logger.info("Message without correlation ID")

    # With correlation ID using context manager
    with CorrelationContext('task-123-456'):
        logger.info("Starting task processing")
        logger.info("Processing step 1")
        logger.info("Processing step 2")
        logger.info("Task complete")

    # Back to no correlation ID
    logger.info("Message after correlation context")

    # Nested correlation contexts
    with CorrelationContext('parent-task'):
        logger.info("Parent task started")

        with CorrelationContext('child-task-1'):
            logger.info("Child task 1 started")
            logger.info("Child task 1 complete")

        with CorrelationContext('child-task-2'):
            logger.info("Child task 2 started")
            logger.info("Child task 2 complete")

        logger.info("Parent task complete")

    print("✓ Correlation ID test complete")


def test_contextual_logger():
    """Test contextual logger with extra context"""
    print("\n" + "="*70)
    print("Test 4: Contextual Logger")
    print("="*70)

    # Create logger with component context
    logger = get_logger('test.context', component='ssh_manager', version='2.0')

    logger.info("Connection pool initialized", extra={'pool_size': 50})
    logger.info("SSH connection established", extra={'server': 'web-01', 'latency_ms': 120})
    logger.warning("Connection retry required", extra={'attempt': 2, 'max_attempts': 3})

    print("✓ Contextual logger test complete")


def test_exception_logging():
    """Test exception logging"""
    print("\n" + "="*70)
    print("Test 5: Exception Logging")
    print("="*70)

    logger = logging.getLogger('test.exceptions')

    try:
        # Simulate an error
        result = 10 / 0
    except ZeroDivisionError:
        logger.error("Division by zero occurred", exc_info=True)

    try:
        # Simulate another error
        data = {'key': 'value'}
        value = data['missing_key']
    except KeyError:
        logger.exception("Key not found in dictionary")

    print("✓ Exception logging test complete")


def test_logger_adapter():
    """Test logger adapter with persistent context"""
    print("\n" + "="*70)
    print("Test 6: Logger Adapter")
    print("="*70)

    # Create logger with persistent context
    base_logger = logging.getLogger('test.adapter')
    logger = logging.LoggerAdapter(base_logger, {
        'request_id': 'req-abc-123',
        'user_id': 42,
        'ip_address': '192.168.1.100'
    })

    logger.info("User logged in")
    logger.info("API request received", extra={'endpoint': '/api/servers'})
    logger.warning("Rate limit approaching", extra={'requests_today': 180, 'limit': 200})
    logger.info("User logged out")

    print("✓ Logger adapter test complete")


def test_log_files():
    """Verify log files were created"""
    print("\n" + "="*70)
    print("Test 7: Log File Verification")
    print("="*70)

    log_dir = Path(__file__).parent.parent / 'logs'

    expected_files = [
        'audit-toolkit.log',
        'audit-toolkit-error.log',
        'audit-toolkit-access.log'
    ]

    for filename in expected_files:
        filepath = log_dir / filename
        if filepath.exists():
            size = filepath.stat().st_size
            print(f"✓ {filename}: {size} bytes")
        else:
            print(f"✗ {filename}: NOT FOUND")

    print(f"\nLog directory: {log_dir}")
    print("✓ Log file verification complete")


def main():
    """Run all logging tests"""
    print("""
    ╔════════════════════════════════════════════════════════════════╗
    ║          Structured Logging System Test Suite                 ║
    ║    Security Audit Toolkit - Comprehensive Logging v2.0        ║
    ╚════════════════════════════════════════════════════════════════╝
    """)

    # Setup logging for tests
    # Use text format for easier console reading
    setup_logging(
        app_name='audit-toolkit',
        log_dir=Path(__file__).parent.parent / 'logs',
        log_level='DEBUG',
        enable_json=False,  # Text format for readable test output
        enable_rotation=True
    )

    # Run tests
    test_basic_logging()
    test_structured_logging()
    test_correlation_ids()
    test_contextual_logger()
    test_exception_logging()
    test_logger_adapter()
    test_log_files()

    print("\n" + "="*70)
    print("All tests complete!")
    print("="*70)
    print("\nCheck logs in: logs/")
    print("  - audit-toolkit.log (all logs)")
    print("  - audit-toolkit-error.log (errors only)")
    print("  - audit-toolkit-access.log (access logs)")
    print("\nTo enable JSON logging, set LOG_FORMAT=json")
    print("To change log level, set LOG_LEVEL=DEBUG|INFO|WARNING|ERROR|CRITICAL")
    print("="*70 + "\n")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nTest interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nTest failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
