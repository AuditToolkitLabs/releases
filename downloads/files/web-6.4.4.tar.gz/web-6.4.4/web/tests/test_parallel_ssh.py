#!/usr/bin/env python3
"""
Parallel SSH Connection Test

Tests the async SSH manager with concurrent connections:
- Connection pooling
- Parallel execution
- Error handling
- Performance benchmarks

Usage:
    python3 test_parallel_ssh.py [num_servers]

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import asyncio
import sys
import time
from pathlib import Path

import pytest

# Add web directory to path for importing ssh_async
sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from ssh_async import AsyncSSHManager


@pytest.mark.skip(reason="Async test - run directly via 'python test_parallel_ssh.py'")
async def test_parallel_execution(num_servers=10):
    """
    Test parallel SSH execution

    Args:
        num_servers: Number of mock servers to test with
    """
    print(f"Testing Parallel SSH Execution with {num_servers} servers")
    print("=" * 70)

    # Create mock server configurations
    # In real usage, these would come from database
    servers = []
    for i in range(1, num_servers + 1):
        servers.append({
            'id': i,
            'name': f'server{i}',
            'hostname': 'localhost',  # Change to real servers for production test
            'port': 22,
            'username': 'testuser',
            'password': None,  # nosec B105
            'key_path': str(Path.home() / '.ssh' / 'id_rsa')
        })

    # Test command (safe, read-only)
    command = "uname -a && uptime && echo 'SSH test successful'"

    print("\nTest Configuration:")
    print(f"  Servers: {num_servers}")
    print(f"  Command: {command}")
    print("  Max Concurrent: 50")
    print("  Timeout: 30s")
    print()

    # Start timer
    start_time = time.time()

    # Create manager
    manager = AsyncSSHManager(max_concurrent=50)

    try:
        print("Starting parallel execution...")

        # Execute in parallel
        results = await manager.execute_on_servers(
            servers,
            command,
            timeout=30
        )

        # Calculate metrics
        duration = time.time() - start_time

        print(f"\n{'-' * 70}")
        print("Execution Complete")
        print(f"{'-' * 70}\n")

        # Print summary
        summary = manager.get_summary()

        print("Summary Statistics:")
        print(f"  Total Servers: {summary['total']}")
        print(f"  Successful: {summary['successful']} ({summary['success_rate']:.1f}%)")
        print(f"  Failed: {summary['failed']}")
        print(f"  Total Duration: {duration:.2f}s")
        print(f"  Average Duration: {summary['average_duration']:.2f}s")
        print(f"  Speedup: {summary['total_duration'] / duration:.1f}x")
        print()

        # Print individual results
        print("Individual Results:")
        print(f"{'-' * 70}")

        for result in results[:10]:  # Show first 10
            status = "✓ SUCCESS" if result.success else "✗ FAILED"
            print(f"  {result.server_name:15} - {status:12} - {result.duration_seconds:.2f}s")

            if not result.success:
                print(f"    Error: {result.error}")

        if len(results) > 10:
            print(f"  ... and {len(results) - 10} more servers")

        print()

        # Performance evaluation
        print("Performance Evaluation:")
        if summary['success_rate'] >= 95:
            print("  ✓ Success rate: EXCELLENT (≥95%)")
        elif summary['success_rate'] >= 80:
            print("  ⚠ Success rate: GOOD (≥80%)")
        else:
            print("  ✗ Success rate: POOR (<80%)")

        if duration < num_servers * 0.5:
            print(f"  ✓ Execution time: EXCELLENT (<{num_servers * 0.5:.1f}s)")
        elif duration < num_servers:
            print(f"  ⚠ Execution time: GOOD (<{num_servers}s)")
        else:
            print(f"  ✗ Execution time: POOR (≥{num_servers}s)")

        print()

        # Recommendations
        if summary['success_rate'] < 100:
            print("Recommendations:")
            print("  - Check SSH connectivity to failed servers")
            print("  - Verify SSH keys/passwords are correct")
            print("  - Increase timeout for slow connections")
            print("  - Check firewall rules")

        return results, summary

    finally:
        # Cleanup
        await manager.cleanup()


def test_sequential_comparison(num_servers=10):
    """
    Compare parallel vs sequential execution

    This demonstrates the performance improvement of parallel execution
    """
    print(f"\nSequential vs Parallel Comparison ({num_servers} servers)")
    print("=" * 70)

    # Simulate sequential execution time
    # Assume 2 seconds per server (typical SSH command runtime)
    sequential_time = num_servers * 2.0

    # Parallel execution time (measured from actual run)
    # With 50 concurrent connections, should be ~2-4 seconds total
    parallel_time = max(2.0, num_servers / 25)  # Rough estimate

    speedup = sequential_time / parallel_time
    time_saved = sequential_time - parallel_time

    print(f"Sequential Execution: {sequential_time:.1f}s")
    print(f"Parallel Execution:   {parallel_time:.1f}s")
    print(f"Speedup:              {speedup:.1f}x")
    print(f"Time Saved:           {time_saved:.1f}s")
    print()

    # Scale predictions
    print("Projected Performance at Scale:")
    for scale in [50, 100, 200]:
        seq = scale * 2.0
        par = max(2.0, scale / 25)
        print(f"  {scale:3} servers: {seq:.0f}s → {par:.0f}s ({seq/par:.1f}x faster)")


@pytest.mark.skip(reason="Async test - run directly via 'python test_parallel_ssh.py'")
async def test_error_handling():
    """Test error handling with invalid connections"""
    print("\nTesting Error Handling")
    print("=" * 70)

    # Create servers with invalid configurations
    servers = [
        {
            'id': 1,
            'name': 'valid-server',
            'hostname': 'localhost',
            'port': 22,
            'username': 'testuser',
            'key_path': str(Path.home() / '.ssh' / 'id_rsa')
        },
        {
            'id': 2,
            'name': 'invalid-host',
            'hostname': '192.0.2.1',  # TEST-NET (unreachable)
            'port': 22,
            'username': 'testuser',
            'key_path': str(Path.home() / '.ssh' / 'id_rsa')
        },
        {
            'id': 3,
            'name': 'invalid-port',
            'hostname': 'localhost',
            'port': 9999,  # Non-SSH port
            'username': 'testuser',
            'key_path': str(Path.home() / '.ssh' / 'id_rsa')
        }
    ]

    manager = AsyncSSHManager(max_concurrent=3)

    try:
        results = await manager.execute_on_servers(
            servers,
            "echo 'test'",
            timeout=10
        )

        print("Error Handling Results:")
        for result in results:
            status = "✓" if result.success else "✗"
            print(f"  {status} {result.server_name:20} - {result.error or 'Success'}")

        summary = manager.get_summary()
        print(f"\nPartial Success Rate: {summary['success_rate']:.1f}%")
        print("✓ Error handling working correctly")

    finally:
        await manager.cleanup()


async def main():
    """Main test runner"""
    print("""
    ╔════════════════════════════════════════════════════════════════╗
    ║          Parallel SSH Connection Test Suite                   ║
    ║    Security Audit Toolkit - AsyncSSH Manager Testing          ║
    ╚════════════════════════════════════════════════════════════════╝
    """)

    # Get number of servers from command line
    num_servers = int(sys.argv[1]) if len(sys.argv) > 1 else 10

    # Test 1: Basic parallel execution
    results, summary = await test_parallel_execution(num_servers)

    # Test 2: Sequential comparison
    test_sequential_comparison(num_servers)

    # Test 3: Error handling
    await test_error_handling()

    print("\n" + "=" * 70)
    print("All tests complete!")
    print("=" * 70)


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\nTest interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nTest failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
