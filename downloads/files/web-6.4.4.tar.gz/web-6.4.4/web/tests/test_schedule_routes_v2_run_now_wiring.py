#!/usr/bin/env python3
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from flask import Flask


sys.path.insert(0, str(Path(__file__).parent.parent))

from api.schedule_routes_v2 import schedule_v2_bp
import api.schedule_routes_v2 as routes
from auth_core import get_api_key_manager


class _FakeQuery:
    def __init__(self, schedule):
        self._schedule = schedule

    def filter(self, *args, **kwargs):
        return self

    def first(self):
        return self._schedule


class _FakeSession:
    def __init__(self, schedule):
        self._schedule = schedule

    def query(self, model):
        return _FakeQuery(self._schedule)

    def close(self):
        return None


class _CaptureExecuteAudit:
    calls = []

    @classmethod
    def delay(cls, **kwargs):
        cls.calls.append(kwargs)
        return types.SimpleNamespace(id='task-schedule-run-now-123')


class TestScheduleRoutesV2RunNowWiring(unittest.TestCase):
    def setUp(self):
        self.app = Flask(__name__)
        self.app.register_blueprint(schedule_v2_bp)
        self.client = self.app.test_client()
        self.api_key = get_api_key_manager().api_key
        _CaptureExecuteAudit.calls = []

    def _headers(self):
        return {
            'X-API-Key': self.api_key,
            'Content-Type': 'application/json',
        }

    def _fake_task_modules(self):
        fake_audit_tasks = types.ModuleType('tasks.audit_tasks')
        fake_audit_tasks.execute_audit = _CaptureExecuteAudit
        fake_tasks = types.ModuleType('tasks')
        fake_tasks.audit_tasks = fake_audit_tasks
        return {
            'tasks': fake_tasks,
            'tasks.audit_tasks': fake_audit_tasks,
        }

    def test_run_now_forwards_schedule_metadata_and_requester(self):
        schedule = types.SimpleNamespace(
            id=42,
            name='Nightly Managed Audit',
            server_id=7,
            server=types.SimpleNamespace(id=7, name='prod-server'),
            audit=types.SimpleNamespace(file_path='audits/platform/baseline/updates.sh'),
        )

        with patch.object(routes, 'SessionLocal', return_value=_FakeSession(schedule)), \
             patch.dict(sys.modules, self._fake_task_modules(), clear=False):
            response = self.client.post('/api/v2/schedules/42/run-now', headers=self._headers())

        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        self.assertTrue(body['success'])
        self.assertEqual(len(_CaptureExecuteAudit.calls), 1)

        dispatched = _CaptureExecuteAudit.calls[0]
        self.assertEqual(dispatched['server_id'], 7)
        self.assertEqual(dispatched['audit_path'], 'audits/platform/baseline/updates.sh')
        self.assertEqual(dispatched['options']['trigger'], 'manual')
        self.assertEqual(dispatched['options']['schedule_id'], 42)
        self.assertEqual(dispatched['options']['schedule_name'], 'Nightly Managed Audit')
        self.assertIn('requested_by', dispatched['options'])
        self.assertNotEqual(dispatched['options']['requested_by'], 'manual-trigger')

    def test_run_now_rejects_schedule_with_missing_relationships(self):
        schedule = types.SimpleNamespace(
            id=43,
            name='Broken Schedule',
            server_id=9,
            server=None,
            audit=None,
        )

        with patch.object(routes, 'SessionLocal', return_value=_FakeSession(schedule)), \
             patch.dict(sys.modules, self._fake_task_modules(), clear=False):
            response = self.client.post('/api/v2/schedules/43/run-now', headers=self._headers())

        self.assertEqual(response.status_code, 400)
        body = response.get_json()
        self.assertFalse(body['success'])
        self.assertIn('missing server or audit', body['error'])
        self.assertEqual(len(_CaptureExecuteAudit.calls), 0)


if __name__ == '__main__':
    unittest.main()
