#!/usr/bin/env python3
"""Wiring tests for scheduled analytics cleanup and PostgreSQL maintenance tasks."""

import ast
import unittest
from pathlib import Path


class TestScheduledMaintenanceWiring(unittest.TestCase):
    ROOT = Path(__file__).resolve().parents[1]

    def _parse(self, relative_path: str) -> ast.Module:
        source = (self.ROOT / relative_path).read_text(encoding='utf-8')
        return ast.parse(source)

    def _find_function(self, tree: ast.Module, name: str) -> ast.FunctionDef:
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name == name:
                return node
        self.fail(f'Function {name} not found')

    def _contains_string(self, node: ast.AST, value: str) -> bool:
        for child in ast.walk(node):
            if isinstance(child, ast.Constant) and isinstance(child.value, str) and child.value == value:
                return True
        return False

    def _contains_string_fragment(self, node: ast.AST, value_fragment: str) -> bool:
        for child in ast.walk(node):
            if isinstance(child, ast.Constant) and isinstance(child.value, str) and value_fragment in child.value:
                return True
        return False

    def test_scheduled_tasks_include_new_maintenance_functions(self):
        tree = self._parse('tasks/scheduled_tasks.py')
        self._find_function(tree, 'cleanup_analytics_history')
        self._find_function(tree, 'run_postgresql_maintenance')

    def test_postgresql_maintenance_task_uses_vacuum_analyze(self):
        tree = self._parse('tasks/scheduled_tasks.py')
        fn = self._find_function(tree, 'run_postgresql_maintenance')
        self.assertTrue(
            self._contains_string_fragment(fn, 'VACUUM (ANALYZE)'),
            'run_postgresql_maintenance must run VACUUM (ANALYZE) on PostgreSQL tables',
        )

    def test_celery_beat_schedule_includes_new_tasks(self):
        tree = self._parse('celery_app.py')
        self.assertTrue(
            self._contains_string(tree, 'tasks.scheduled_tasks.cleanup_analytics_history'),
            'Celery beat schedule must include cleanup_analytics_history task',
        )
        self.assertTrue(
            self._contains_string(tree, 'tasks.scheduled_tasks.run_postgresql_maintenance'),
            'Celery beat schedule must include run_postgresql_maintenance task',
        )


if __name__ == '__main__':
    unittest.main()
