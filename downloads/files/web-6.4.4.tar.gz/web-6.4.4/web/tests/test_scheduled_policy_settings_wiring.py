#!/usr/bin/env python3
"""Wiring tests for policy-driven scheduling controls in security settings and scheduled tasks."""

import ast
import unittest
from pathlib import Path


class TestScheduledPolicySettingsWiring(unittest.TestCase):
    ROOT = Path(__file__).resolve().parents[1]

    def _parse(self, relative_path: str) -> ast.Module:
        source = (self.ROOT / relative_path).read_text(encoding='utf-8')
        return ast.parse(source)

    def _contains_constant(self, node: ast.AST, value: str) -> bool:
        for child in ast.walk(node):
            if isinstance(child, ast.Constant) and child.value == value:
                return True
        return False

    def test_defaults_include_schedule_controls(self):
        for relative_path in ('security_settings.py', 'api/admin_routes.py'):
            tree = self._parse(relative_path)
            for key in (
                'cleanup_old_executions_enabled',
                'cleanup_old_executions_interval_minutes',
                'cleanup_analytics_history_enabled',
                'cleanup_analytics_history_interval_minutes',
                'postgres_maintenance_interval_minutes',
            ):
                self.assertTrue(
                    self._contains_constant(tree, key),
                    f"{relative_path} must include default key: {key}",
                )

    def test_scheduled_tasks_use_policy_schedule_state_helper(self):
        tree = self._parse('tasks/scheduled_tasks.py')
        required_fragments = (
            'cleanup_old_executions_interval_minutes',
            'cleanup_analytics_history_interval_minutes',
            'postgres_maintenance_interval_minutes',
            'cleanup_old_executions_enabled',
            'cleanup_analytics_history_enabled',
            'postgres_maintenance_enabled',
        )

        for fragment in required_fragments:
            self.assertTrue(
                self._contains_constant(tree, fragment),
                f"scheduled_tasks.py must reference schedule policy key: {fragment}",
            )


if __name__ == '__main__':
    unittest.main()
