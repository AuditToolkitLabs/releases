#!/usr/bin/env python3
"""Tests for startup security guard checks."""

import os
import sys
import unittest
from pathlib import Path

from sqlalchemy import create_engine, text

sys.path.insert(0, str(Path(__file__).parent.parent))

from security_startup_checks import enforce_server_password_storage_format


class TestStartupSecurityChecks(unittest.TestCase):
    def setUp(self):
        self._original_env = dict(os.environ)
        self.engine = create_engine('sqlite:///:memory:')
        with self.engine.begin() as conn:
            conn.execute(text('CREATE TABLE servers (id INTEGER PRIMARY KEY, password TEXT)'))

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._original_env)
        self.engine.dispose()

    def test_encryption_guard_passes_when_all_passwords_encrypted(self):
        os.environ['DB_ENCRYPTION_STRICT'] = 'true'
        with self.engine.begin() as conn:
            conn.execute(text("INSERT INTO servers (id, password) VALUES (1, 'enc:v1:gAAAAencrypted')"))
            conn.execute(text("INSERT INTO servers (id, password) VALUES (2, NULL)"))

        enforce_server_password_storage_format(self.engine)

    def test_encryption_guard_fails_when_plaintext_password_present(self):
        os.environ['DB_ENCRYPTION_STRICT'] = 'true'
        with self.engine.begin() as conn:
            conn.execute(text("INSERT INTO servers (id, password) VALUES (10, 'plain-text-password')"))

        with self.assertRaises(RuntimeError) as ctx:
            enforce_server_password_storage_format(self.engine)

        message = str(ctx.exception)
        self.assertIn('servers.password', message)
        self.assertIn('invalid rows', message)

    def test_encryption_guard_accepts_legacy_fernet_terminal_values(self):
        os.environ['DB_ENCRYPTION_STRICT'] = 'true'

        with self.engine.begin() as conn:
            conn.execute(text('CREATE TABLE terminal_connection_profiles (id INTEGER PRIMARY KEY, password_encrypted TEXT)'))
            conn.execute(text("INSERT INTO terminal_connection_profiles (id, password_encrypted) VALUES (1, 'gAAAAlegacytoken')"))

        enforce_server_password_storage_format(self.engine)

    def test_encryption_guard_fails_for_terminal_plaintext(self):
        os.environ['DB_ENCRYPTION_STRICT'] = 'true'

        with self.engine.begin() as conn:
            conn.execute(text('CREATE TABLE terminal_connection_profiles (id INTEGER PRIMARY KEY, password_encrypted TEXT)'))
            conn.execute(text("INSERT INTO terminal_connection_profiles (id, password_encrypted) VALUES (2, 'plain-terminal-password')"))

        with self.assertRaises(RuntimeError) as ctx:
            enforce_server_password_storage_format(self.engine)

        self.assertIn('terminal_connection_profiles.password_encrypted', str(ctx.exception))


if __name__ == '__main__':
    unittest.main()
