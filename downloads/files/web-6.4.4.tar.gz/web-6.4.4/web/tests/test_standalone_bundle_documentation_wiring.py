#!/usr/bin/env python3
"""Documentation wiring checks for standalone helper bundle downloads."""

import unittest
from pathlib import Path


class TestStandaloneBundleDocumentationWiring(unittest.TestCase):
    ROOT = Path(__file__).resolve().parents[2]

    def test_openapi_documents_standalone_download_endpoint_and_bundle_types(self):
        source = (self.ROOT / 'web' / 'static' / 'openapi.yaml').read_text(encoding='utf-8')

        self.assertIn('/api/agent/download/standalone/{script_type}:', source)
        self.assertIn('- winrm-jea-wrapper-bundle', source)
        self.assertIn('- ssh-sudo-wrapper-bundle', source)
        self.assertIn('- jea-session-config', source)
        self.assertIn('- jea-role-full', source)
        self.assertIn('- jea-role-readonly', source)

    def test_operator_docs_reference_new_bundle_download_types(self):
        deploy_panel_doc = (self.ROOT / 'docs' / '16-deploy-panel-guide.md').read_text(encoding='utf-8')
        agent_deploy_doc = (self.ROOT / 'docs' / '17-agent-deployment-guide.md').read_text(encoding='utf-8')

        self.assertIn('winrm-jea-wrapper-bundle', deploy_panel_doc)
        self.assertIn('ssh-sudo-wrapper-bundle', deploy_panel_doc)
        self.assertIn('/api/agent/download/standalone/<script_type>', deploy_panel_doc)

        self.assertIn('/api/agent/download/standalone/winrm-jea-wrapper-bundle', agent_deploy_doc)
        self.assertIn('/api/agent/download/standalone/ssh-sudo-wrapper-bundle', agent_deploy_doc)
        self.assertIn('/api/agent/download/standalone/run-audit-jer', agent_deploy_doc)
        self.assertIn('/api/agent/download/standalone/run-audit-wrapper', agent_deploy_doc)


if __name__ == '__main__':
    unittest.main()