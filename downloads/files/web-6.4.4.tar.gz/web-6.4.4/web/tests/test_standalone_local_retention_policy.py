#!/usr/bin/env python3
"""Tests for standalone standalone-agent local result retention controls."""

import ast
import os
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory


class TestStandaloneLocalRetentionPolicy(unittest.TestCase):
    """Validate local result retention pruning in standalone web runtime."""

    @classmethod
    def setUpClass(cls):
        repo_root = Path(__file__).resolve().parents[2]
        app_path = repo_root / 'agents' / 'html-standalone' / 'web' / 'app.py'
        source = app_path.read_text(encoding='utf-8')
        tree = ast.parse(source)

        target_functions = {'_resolve_max_local_result_files', 'enforce_local_result_retention'}
        selected_nodes = [
            node for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name in target_functions
        ]

        module = ast.Module(body=selected_nodes, type_ignores=[])
        ast.fix_missing_locations(module)

        class _NoopLogger:
            @staticmethod
            def info(*_args, **_kwargs):
                return None

            @staticmethod
            def warning(*_args, **_kwargs):
                return None

        cls.namespace = {
            'os': os,
            'Path': Path,
            'logger': _NoopLogger(),
            'ENV_AGENT_MAX_LOCAL_RESULT_FILES': 1000,
            'RESULTS_DIR': '',
        }
        exec(compile(module, filename=str(app_path), mode='exec'), cls.namespace)  # nosec B102 - controlled test harness executes selected AST nodes only

    def test_prunes_oldest_results_to_max_local_result_files(self):
        with TemporaryDirectory() as temp_dir:
            results_dir = Path(temp_dir)

            for idx in range(5):
                result_file = results_dir / f"result_{idx}.json"
                result_file.write_text('{"ok": true}', encoding='utf-8')

            self.namespace['RESULTS_DIR'] = str(results_dir)
            removed = self.namespace['enforce_local_result_retention'](
                {'keep_local_results': True, 'max_local_result_files': 3}
            )

            self.assertEqual(removed, 2)
            remaining = sorted(path.name for path in results_dir.glob('*.json'))
            self.assertEqual(remaining, ['result_2.json', 'result_3.json', 'result_4.json'])

    def test_zero_limit_means_unlimited_and_no_prune(self):
        with TemporaryDirectory() as temp_dir:
            results_dir = Path(temp_dir)

            for idx in range(4):
                (results_dir / f"result_{idx}.json").write_text('{"ok": true}', encoding='utf-8')

            self.namespace['RESULTS_DIR'] = str(results_dir)
            removed = self.namespace['enforce_local_result_retention'](
                {'keep_local_results': True, 'max_local_result_files': 0}
            )

            self.assertEqual(removed, 0)
            self.assertEqual(len(list(results_dir.glob('*.json'))), 4)


if __name__ == '__main__':
    unittest.main()
