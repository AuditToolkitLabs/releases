#!/usr/bin/env python3
"""Regression tests for managed-mode license endpoint behavior."""

import os
import sys
import unittest
from pathlib import Path


class TestStandaloneManagedLicenseEndpoints(unittest.TestCase):
    """Ensure local license activation/deactivation stays blocked in managed mode."""

    @classmethod
    def setUpClass(cls):
        repo_root = Path(__file__).resolve().parents[2]
        agent_root = repo_root / 'agents' / 'html-standalone'

        if str(agent_root) not in sys.path:
            sys.path.insert(0, str(agent_root))

        # Managed mode is default, but set explicitly for deterministic behavior.
        os.environ['HTML_STANDALONE_ALLOW_MANUAL_EXECUTION'] = 'false'

        from web.app import app  # pylint: disable=import-error,import-outside-toplevel

        cls.app = app
        cls.app.config['TESTING'] = True
        cls.app.config['WTF_CSRF_ENABLED'] = False

    def setUp(self):
        self.client = self.app.test_client()
        with self.client.session_transaction() as session:
            session['authenticated'] = True
            session['password_change_required'] = False
            session['must_change_password'] = False

    def test_activate_license_api_is_blocked_in_managed_mode(self):
        response = self.client.post('/api/license/activate', json={})
        self.assertEqual(response.status_code, 403)

        payload = response.get_json()
        self.assertIsInstance(payload, dict)
        self.assertFalse(payload.get('success', True))
        self.assertIn('License activation is disabled in managed setup-only mode', payload.get('error', ''))

    def test_deactivate_license_api_is_blocked_in_managed_mode(self):
        response = self.client.post('/api/license/deactivate', json={})
        self.assertEqual(response.status_code, 403)

        payload = response.get_json()
        self.assertIsInstance(payload, dict)
        self.assertFalse(payload.get('success', True))
        self.assertIn('License deactivation is disabled in managed setup-only mode', payload.get('error', ''))


if __name__ == '__main__':
    unittest.main()
