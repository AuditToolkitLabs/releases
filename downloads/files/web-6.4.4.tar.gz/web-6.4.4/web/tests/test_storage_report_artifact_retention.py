#!/usr/bin/env python3
"""Tests for report/artifact lifecycle retention enforcement in storage manager."""

import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from storage.manager import StorageManager
from storage.backends.base import StorageMetadata


class _FakeBackend:
    def __init__(self):
        self.files = {}
        self.deleted = []
        self.compression_enabled = False
        self.encryption_key = None

    def put(self, path, data, content_type=None, metadata=None):
        if hasattr(data, 'read'):
            payload = data.read()
        else:
            payload = data
        if isinstance(payload, str):
            payload = payload.encode('utf-8')

        record = StorageMetadata(
            path=path,
            size=len(payload),
            content_type=content_type,
            last_modified=datetime.utcnow(),
            custom_metadata=metadata or {},
        )
        self.files[path] = record
        return record

    def list_files(self, prefix='', recursive=True):
        return [meta for path, meta in self.files.items() if path.startswith(prefix)]

    def delete(self, path):
        existed = path in self.files
        self.files.pop(path, None)
        if existed:
            self.deleted.append(path)
        return existed


class TestStorageReportArtifactRetention(unittest.TestCase):
    def setUp(self):
        self.manager = StorageManager()
        self.original_backend = self.manager._backend
        self.fake_backend = _FakeBackend()
        self.manager._backend = self.fake_backend

    def tearDown(self):
        self.manager._backend = self.original_backend

    def test_put_report_enforces_age_and_count_retention(self):
        now = datetime.utcnow()
        self.fake_backend.files = {
            'reports/2026/01/old-report.pdf': StorageMetadata(
                path='reports/2026/01/old-report.pdf',
                size=100,
                content_type='application/pdf',
                last_modified=now - timedelta(days=45),
            ),
            'reports/2026/02/mid-report.pdf': StorageMetadata(
                path='reports/2026/02/mid-report.pdf',
                size=100,
                content_type='application/pdf',
                last_modified=now - timedelta(days=10),
            ),
            'reports/2026/02/newer-report.pdf': StorageMetadata(
                path='reports/2026/02/newer-report.pdf',
                size=100,
                content_type='application/pdf',
                last_modified=now - timedelta(days=1),
            ),
        }

        def _policy(key, default=None):
            if key == 'report_artifact_retention_days':
                return 30
            if key == 'report_artifact_max_files':
                return 2
            return default

        with patch('security_settings.get_security_setting', side_effect=_policy):
            self.manager.put_report('generated.pdf', b'pdf-bytes')

        remaining = sorted(path for path in self.fake_backend.files if path.startswith('reports/'))
        self.assertEqual(len(remaining), 2)
        self.assertIn('reports/2026/02/newer-report.pdf', remaining)
        self.assertTrue(any(path.endswith('generated.pdf') for path in remaining))
        self.assertIn('reports/2026/01/old-report.pdf', self.fake_backend.deleted)
        self.assertIn('reports/2026/02/mid-report.pdf', self.fake_backend.deleted)

    def test_put_artifact_enforces_max_files(self):
        now = datetime.utcnow()
        self.fake_backend.files = {
            'artifacts/a-old.json': StorageMetadata(
                path='artifacts/a-old.json',
                size=50,
                content_type='application/json',
                last_modified=now - timedelta(days=2),
            ),
            'artifacts/b-mid.json': StorageMetadata(
                path='artifacts/b-mid.json',
                size=50,
                content_type='application/json',
                last_modified=now - timedelta(days=1),
            ),
        }

        def _policy(key, default=None):
            if key == 'report_artifact_retention_days':
                return 365
            if key == 'report_artifact_max_files':
                return 2
            return default

        with patch('security_settings.get_security_setting', side_effect=_policy):
            self.manager.put_artifact('c-new.json', b'{}')

        remaining = sorted(path for path in self.fake_backend.files if path.startswith('artifacts/'))
        self.assertEqual(len(remaining), 2)
        self.assertIn('artifacts/c-new.json', remaining)
        self.assertIn('artifacts/b-mid.json', remaining)
        self.assertIn('artifacts/a-old.json', self.fake_backend.deleted)


if __name__ == '__main__':
    unittest.main()
