#!/usr/bin/env python3
"""
Input Validation Module

Provides secure input validation functions for:
- Filenames and paths
- Hostnames and IP addresses
- Usernames
- Port numbers
- File paths with directory traversal protection
"""

import re
from pathlib import Path
from functools import lru_cache

# Pre-compiled regex patterns (10-100x faster than compiling on each call)
FILENAME_PATTERN = re.compile(r'^[a-zA-Z0-9._-]+$')
HOSTNAME_PATTERN = re.compile(r'^[a-zA-Z0-9.-]+$')
USERNAME_PATTERN = re.compile(r'^[a-zA-Z0-9_-]+$')

def validate_filename(filename):
    """
    Validate filename to prevent directory traversal and command injection

    Args:
        filename: String to validate

    Returns:
        True if valid, False otherwise

    Security: Prevents path traversal attacks (../, etc.)
    """
    if not filename or not isinstance(filename, str):
        return False
    return bool(FILENAME_PATTERN.match(filename)) and '..' not in filename

def validate_host(host):
    """
    Validate hostname or IP address

    Args:
        host: Hostname or IP address to validate

    Returns:
        True if valid, False otherwise
    """
    return bool(host and HOSTNAME_PATTERN.match(host))

def validate_username(username):
    """
    Validate username for SSH connections

    Args:
        username: Username to validate

    Returns:
        True if valid, False otherwise
    """
    return bool(username and USERNAME_PATTERN.match(username))

def validate_port(port):
    """
    Validate port number (1-65535)

    Args:
        port: Port number (int or string)

    Returns:
        True if valid, False otherwise
    """
    try:
        port_int = int(port)
        return 1 <= port_int <= 65535
    except (ValueError, TypeError):
        return False

def validate_path(path, base_dir):
    """
    Validate path is within base directory (prevents directory traversal)

    Args:
        path: Path to validate
        base_dir: Base directory path must be within

    Returns:
        Resolved path if valid, None otherwise

    Security: Prevents directory traversal attacks
    """
    try:
        base_path = Path(base_dir).resolve()
        target_path = (base_path / path).resolve()

        # Check if target_path is within base_path
        try:
            target_path.relative_to(base_path)
            return target_path
        except ValueError:
            # Path is outside base_dir
            return None
    except (OSError, ValueError):
        return None

# MEDIUM-05 fix: Time-based cache instead of forever-cache
_timestamp_cache = {'value': None, 'expires': 0}

def get_cached_timestamp():
    """
    Get current timestamp (cached for 1 second to reduce datetime calls)

    Returns:
        Current UTC timestamp string

    Note: This is a performance optimization for high-frequency timestamp generation
    MEDIUM-05 fix: Now properly expires after 1 second
    """
    import time
    from datetime import datetime

    now = time.time()
    if now > _timestamp_cache['expires']:
        _timestamp_cache['value'] = datetime.utcnow().isoformat()
        _timestamp_cache['expires'] = now + 1  # Cache for 1 second
    return _timestamp_cache['value']

def validate_audit_path(audit_path, audits_base_dir):
    """
    Validate audit script path is within audits directory

    Args:
        audit_path: Path to audit script
        audits_base_dir: Base audits directory

    Returns:
        Validated path or None if invalid
    """
    return validate_path(audit_path, audits_base_dir)

def validate_log_path(log_path, logs_base_dir):
    """
    Validate log file path is within logs directory

    Args:
        log_path: Path to log file
        logs_base_dir: Base logs directory

    Returns:
        Validated path or None if invalid
    """
    return validate_path(log_path, logs_base_dir)

def validate_plan_name(plan_name):
    """
    Validate plan filename

    Args:
        plan_name: Plan filename to validate

    Returns:
        True if valid, False otherwise
    """
    if not plan_name or not isinstance(plan_name, str):
        return False

    # Plan names must end with .txt or .plan
    if not (plan_name.endswith('.txt') or plan_name.endswith('.plan')):
        return False

    # Remove extension and validate base name
    base_name = plan_name.rsplit('.', 1)[0]
    return validate_filename(base_name)

def sanitize_server_name(name):
    """
    Sanitize server name for safe storage/display

    Args:
        name: Server name to sanitize

    Returns:
        Sanitized name or None if invalid
    """
    if not name or not isinstance(name, str):
        return None

    # Remove potentially dangerous characters
    sanitized = re.sub(r'[^\w\s.-]', '', name)
    sanitized = sanitized.strip()

    return sanitized if sanitized else None

__all__ = [
    'validate_filename',
    'validate_host',
    'validate_username',
    'validate_port',
    'validate_path',
    'get_cached_timestamp',
    'validate_audit_path',
    'validate_log_path',
    'validate_plan_name',
    'sanitize_server_name',
    'FILENAME_PATTERN',
    'HOSTNAME_PATTERN',
    'USERNAME_PATTERN',
]
