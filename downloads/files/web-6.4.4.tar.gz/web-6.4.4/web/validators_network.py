#!/usr/bin/env python3
"""
SSRF Protection Module

Provides URL validation and IP address filtering to prevent
Server-Side Request Forgery (SSRF) attacks.

Security Features:
- Blocks RFC 1918 private IP ranges
- Blocks loopback addresses (127.0.0.0/8, ::1)
- Blocks link-local addresses
- Blocks cloud metadata endpoints (169.254.169.254)
- DNS rebinding protection via pre-resolution
- Protocol allowlist (http, https only by default)

Author: Security Audit Toolkit Team
Date: February 10, 2026
"""

import ipaddress
import socket
import logging
from urllib.parse import urlparse
from typing import Optional, List, Tuple

logger = logging.getLogger(__name__)


# =============================================================================
# Blocked IP Ranges (RFC 1918 + Special)
# =============================================================================

BLOCKED_NETWORKS = [
    # RFC 1918 Private Ranges
    ipaddress.ip_network('10.0.0.0/8'),
    ipaddress.ip_network('172.16.0.0/12'),
    ipaddress.ip_network('192.168.0.0/16'),

    # Loopback
    ipaddress.ip_network('127.0.0.0/8'),
    ipaddress.ip_network('::1/128'),

    # Link-local
    ipaddress.ip_network('169.254.0.0/16'),
    ipaddress.ip_network('fe80::/10'),

    # Cloud Metadata Endpoints
    ipaddress.ip_network('169.254.169.254/32'),  # AWS, GCP, Azure
    ipaddress.ip_network('fd00:ec2::254/128'),   # AWS IPv6 metadata

    # Other Reserved
    ipaddress.ip_network('0.0.0.0/8'),           # "This" network
    ipaddress.ip_network('100.64.0.0/10'),       # Carrier-grade NAT
    ipaddress.ip_network('192.0.0.0/24'),        # IETF Protocol Assignments
    ipaddress.ip_network('198.18.0.0/15'),       # Network Interconnect Testing
    ipaddress.ip_network('224.0.0.0/4'),         # Multicast
    ipaddress.ip_network('240.0.0.0/4'),         # Reserved
    ipaddress.ip_network('255.255.255.255/32'),  # Broadcast

    # IPv6 Special
    ipaddress.ip_network('::/128'),              # Unspecified
    ipaddress.ip_network('fc00::/7'),            # Unique local
    ipaddress.ip_network('ff00::/8'),            # Multicast
]

# Hostnames/patterns that should always be blocked
BLOCKED_HOSTNAMES = [
    'localhost',
    'localhost.localdomain',
    '*.local',
    '*.internal',
    '*.localhost',
    'kubernetes.default.svc',
    '*.cluster.local',
    'instance-data',
    'metadata',
    'metadata.google.internal',
]

# Allowed protocols
ALLOWED_PROTOCOLS = ['http', 'https']


# =============================================================================
# Core Validation Functions
# =============================================================================

def is_ip_blocked(ip_str: str) -> Tuple[bool, Optional[str]]:
    """
    Check if an IP address falls within blocked ranges.

    Args:
        ip_str: IP address as string

    Returns:
        Tuple of (is_blocked, reason)
    """
    try:
        ip = ipaddress.ip_address(ip_str)

        for network in BLOCKED_NETWORKS:
            if ip in network:
                return True, f"IP {ip_str} is in blocked range {network}"

        return False, None

    except ValueError as e:
        return True, f"Invalid IP address: {e}"


def is_hostname_blocked(hostname: str) -> Tuple[bool, Optional[str]]:
    """
    Check if a hostname matches blocked patterns.

    Args:
        hostname: Hostname to check

    Returns:
        Tuple of (is_blocked, reason)
    """
    hostname_lower = hostname.lower()

    for pattern in BLOCKED_HOSTNAMES:
        if pattern.startswith('*.'):
            # Wildcard pattern
            suffix = pattern[1:]  # e.g., ".local"
            if hostname_lower.endswith(suffix) or hostname_lower == pattern[2:]:
                return True, f"Hostname matches blocked pattern: {pattern}"
        else:
            if hostname_lower == pattern:
                return True, f"Hostname is explicitly blocked: {pattern}"

    return False, None


def resolve_hostname(hostname: str, timeout: float = 2.0) -> List[str]:
    """
    Resolve hostname to IP addresses.

    Args:
        hostname: Hostname to resolve
        timeout: DNS resolution timeout in seconds

    Returns:
        List of IP addresses
    """
    socket.setdefaulttimeout(timeout)

    try:
        # Get all addresses (IPv4 and IPv6)
        results = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        ips = list(set(result[4][0] for result in results))
        return ips
    except socket.gaierror as e:
        logger.warning(f"DNS resolution failed for {hostname}: {e}")
        return []
    except socket.timeout:
        logger.warning(f"DNS resolution timeout for {hostname}")
        return []


def validate_url(url: str,
                 allowed_protocols: Optional[List[str]] = None,
                 allow_private_ips: bool = False,
                 dns_resolve: bool = True) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Validate a URL for SSRF safety.

    This function performs multiple layers of validation:
    1. Protocol check (allowlist)
    2. Hostname pattern check
    3. DNS resolution (optional)
    4. IP address range check

    Args:
        url: The URL to validate
        allowed_protocols: List of allowed protocols (default: http, https)
        allow_private_ips: If True, allows RFC 1918 addresses (use with caution!)
        dns_resolve: If True, resolves hostnames to check underlying IPs

    Returns:
        Tuple of (is_valid, error_message, resolved_ip)
        - is_valid: True if URL is safe to access
        - error_message: Description of why URL was blocked (if blocked)
        - resolved_ip: The resolved IP address (if dns_resolve=True)
    """
    if allowed_protocols is None:
        allowed_protocols = ALLOWED_PROTOCOLS

    # Parse URL
    try:
        parsed = urlparse(url)
    except Exception as e:
        return False, f"Invalid URL format: {e}", None

    # Check protocol
    if not parsed.scheme:
        return False, "URL must include protocol (e.g., https://)", None

    if parsed.scheme.lower() not in allowed_protocols:
        return False, f"Protocol '{parsed.scheme}' is not allowed. Use: {', '.join(allowed_protocols)}", None

    # Check for hostname
    if not parsed.hostname:
        return False, "URL must include a hostname", None

    hostname = parsed.hostname.lower()

    # Check hostname against blocked patterns
    is_blocked, reason = is_hostname_blocked(hostname)
    if is_blocked:
        logger.warning(f"SSRF: Blocked hostname access attempt: {hostname}")
        return False, reason, None

    # Check if hostname is an IP address
    try:
        ip = ipaddress.ip_address(hostname)

        if not allow_private_ips:
            is_blocked, reason = is_ip_blocked(str(ip))
            if is_blocked:
                logger.warning(f"SSRF: Blocked IP access attempt: {ip}")
                return False, reason, None

        return True, None, str(ip)

    except ValueError:
        # hostname is not an IP address, continue with DNS resolution
        pass

    # DNS resolution (protect against DNS rebinding)
    if dns_resolve:
        ips = resolve_hostname(hostname)

        if not ips:
            return False, f"Could not resolve hostname: {hostname}", None

        # Check all resolved IPs
        for ip_str in ips:
            if not allow_private_ips:
                is_blocked, reason = is_ip_blocked(ip_str)
                if is_blocked:
                    logger.warning(f"SSRF: DNS resolved to blocked IP: {hostname} -> {ip_str}")
                    return False, f"Hostname resolves to blocked IP: {reason}", None

        # Return first resolved IP
        return True, None, ips[0]

    return True, None, None


def validate_network_cidr(cidr: str,
                          allow_private: bool = True,
                          max_prefix_length: int = 16) -> Tuple[bool, Optional[str]]:
    """
    Validate a CIDR network notation for scanning safety.

    Args:
        cidr: Network in CIDR notation (e.g., "192.168.1.0/24")
        allow_private: Allow private IP ranges (typical for internal scans)
        max_prefix_length: Maximum allowed network size (smaller = larger network)

    Returns:
        Tuple of (is_valid, error_message)
    """
    try:
        network = ipaddress.ip_network(cidr, strict=False)
    except ValueError as e:
        return False, f"Invalid CIDR notation: {e}"

    # Check network size (prevent scanning entire internet)
    if network.prefixlen < max_prefix_length:
        max_hosts = 2 ** (32 - network.prefixlen) if network.version == 4 else 2 ** (128 - network.prefixlen)
        return False, f"Network too large (/{network.prefixlen}). Maximum /{max_prefix_length} allowed. This would scan {max_hosts:,} hosts."

    # Block special ranges even for internal scans
    special_blocked = [
        ipaddress.ip_network('169.254.169.254/32'),  # Cloud metadata
        ipaddress.ip_network('127.0.0.0/8'),         # Loopback
        ipaddress.ip_network('0.0.0.0/8'),           # "This" network
    ]

    for blocked in special_blocked:
        if network.overlaps(blocked):
            return False, f"Network overlaps with blocked range: {blocked}"

    if not allow_private:
        # Check if it's a private network
        if network.is_private:
            return False, f"Private networks not allowed: {cidr}"

    return True, None


def validate_ip_for_scan(ip_str: str,
                         allow_private: bool = True) -> Tuple[bool, Optional[str]]:
    """
    Validate an IP address for scanning.

    Args:
        ip_str: IP address to validate
        allow_private: Allow private IP ranges

    Returns:
        Tuple of (is_valid, error_message)
    """
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError as e:
        return False, f"Invalid IP address: {e}"

    # Always block special addresses
    special_blocked = [
        ipaddress.ip_network('169.254.169.254/32'),
        ipaddress.ip_network('127.0.0.0/8'),
        ipaddress.ip_network('0.0.0.0/8'),
    ]

    for blocked in special_blocked:
        if ip in blocked:
            return False, f"IP is in blocked range: {blocked}"

    if not allow_private:
        if ip.is_private:
            return False, f"Private IP addresses not allowed: {ip_str}"

    return True, None


# =============================================================================
# Flask Integration
# =============================================================================

def create_ssrf_safe_session():
    """
    Create a requests Session with SSRF protections.

    Note: This requires the 'requests' package.

    Returns:
        requests.Session with custom adapter
    """
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.ssl_ import create_urllib3_context

    class SSRFSafeAdapter(HTTPAdapter):
        def send(self, request, *args, **kwargs):
            # Parse URL and validate before sending
            parsed = urlparse(request.url)
            hostname = parsed.hostname

            if hostname:
                # Check hostname
                is_blocked, reason = is_hostname_blocked(hostname)
                if is_blocked:
                    raise ValueError(f"SSRF Protection: {reason}")

                # Resolve and check IP
                try:
                    ip = ipaddress.ip_address(hostname)
                    is_blocked, reason = is_ip_blocked(str(ip))
                    if is_blocked:
                        raise ValueError(f"SSRF Protection: {reason}")
                except ValueError:
                    # Not an IP, resolve it
                    ips = resolve_hostname(hostname)
                    for ip_str in ips:
                        is_blocked, reason = is_ip_blocked(ip_str)
                        if is_blocked:
                            raise ValueError(f"SSRF Protection: {hostname} resolves to blocked IP: {reason}")

            return super().send(request, *args, **kwargs)

    session = requests.Session()
    adapter = SSRFSafeAdapter()
    session.mount('http://', adapter)
    session.mount('https://', adapter)

    return session


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'is_ip_blocked',
    'is_hostname_blocked',
    'resolve_hostname',
    'validate_url',
    'validate_network_cidr',
    'validate_ip_for_scan',
    'create_ssrf_safe_session',
    'BLOCKED_NETWORKS',
    'BLOCKED_HOSTNAMES',
    'ALLOWED_PROTOCOLS',
]
