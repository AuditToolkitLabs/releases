"""Toolkit version resolution helpers for web runtime modules."""

from __future__ import annotations

import os
from pathlib import Path


def get_toolkit_version(default: str = "0.0.0") -> str:
    """Resolve toolkit version from env or VERSION files."""
    env_version = os.environ.get("APP_VERSION", "").strip()
    if env_version:
        return env_version

    version_paths = [
        Path(__file__).resolve().parent.parent / "VERSION",
        Path(__file__).resolve().parent / "VERSION",
        Path("/opt/audit-toolkit/VERSION"),
        Path("/app/VERSION"),
    ]

    for path in version_paths:
        try:
            if path.exists():
                version = path.read_text(encoding="utf-8").strip()
                if version:
                    return version
        except OSError:
            continue

    return default
