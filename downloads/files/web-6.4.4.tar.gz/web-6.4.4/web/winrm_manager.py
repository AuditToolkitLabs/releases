#!/usr/bin/env python3
"""
WinRM Manager - Windows Remote Management

Provides secure WinRM connectivity for Windows server auditing:
- Connection testing with authentication
- Command execution via PowerShell
- Certificate-based authentication support
- Encrypted credential handling

Requirements:
- pywinrm>=0.4.0
- Target Windows hosts must have WinRM enabled
"""

import logging
import os
from typing import Optional, Dict, Any

try:
    from encryption import password_manager as default_password_manager
except Exception:
    default_password_manager = None

logger = logging.getLogger(__name__)

# Try to import winrm
try:
    import winrm
    from winrm.protocol import Protocol
    WINRM_AVAILABLE = True
except ImportError:
    WINRM_AVAILABLE = False
    logger.warning("pywinrm not installed. Windows server connections will be limited to port checks.")


class WinRMManager:
    """
    Manages WinRM connections to Windows servers

    Supports:
    - Basic authentication (username/password)
    - NTLM authentication (DOMAIN\\user)
    - Certificate authentication (for HTTPS)

    All credentials are expected to be decrypted before passing to this class.
    """

    def __init__(self, password_manager=None):
        """
        Initialize WinRM Manager

        Args:
            password_manager: Optional password manager for decryption
        """
        self.password_manager = password_manager or default_password_manager

        if not WINRM_AVAILABLE:
            logger.warning("WinRM functionality limited - pywinrm not installed")

    def test_connection(
        self,
        hostname: str,
        port: int = 5985,
        username: str = None,
        password: str = None,
        use_ssl: bool = False,
        transport: str = 'ntlm',
        timeout: int = 30
    ) -> Dict[str, Any]:
        """
        Test WinRM connection to Windows server

        Args:
            hostname: Target hostname or IP
            port: WinRM port (5985 HTTP, 5986 HTTPS)
            username: Windows username (can include DOMAIN\\)
            password: Password (decrypted)
            use_ssl: Use HTTPS (port 5986)
            transport: Authentication transport (ntlm, basic, certificate)
            timeout: Connection timeout in seconds

        Returns:
            Dict with success, message, and details
        """
        if not WINRM_AVAILABLE:
            # Fallback to port check
            return self._test_port_only(hostname, port, timeout)

        # Decrypt password if needed
        if password and self.password_manager:
            try:
                password = self.password_manager.decrypt_password(password)
            except Exception as e:
                logger.warning(f"Password decryption failed, using as-is: {e}")

        # Determine protocol
        protocol = 'https' if use_ssl or port == 5986 else 'http'
        effective_port = port if port else (5986 if use_ssl else 5985)

        # Build endpoint URL
        endpoint = f"{protocol}://{hostname}:{effective_port}/wsman"

        try:
            # Create WinRM session
            # A06-01 OWASP fix: Validate SSL certificates by default
            # Set WINRM_IGNORE_SSL=true to disable (not recommended for production)
            ignore_ssl = os.environ.get('WINRM_IGNORE_SSL', 'false').lower() == 'true'
            cert_validation = 'ignore' if ignore_ssl else 'validate'
            if use_ssl and not ignore_ssl:
                logger.debug(f"WinRM SSL certificate validation enabled for {hostname}")

            read_timeout = max(timeout + 5, timeout + 1)
            session = winrm.Session(
                target=endpoint,
                auth=(username, password),
                transport=transport,
                server_cert_validation=cert_validation,
                read_timeout_sec=read_timeout,
                operation_timeout_sec=timeout
            )

            # Test with a simple PowerShell command
            result = session.run_ps('$env:COMPUTERNAME')

            if result.status_code == 0:
                computer_name = result.std_out.decode('utf-8').strip()
                return {
                    'success': True,
                    'message': f'Connected successfully to {computer_name}',
                    'details': f'WinRM {transport.upper()} authentication successful.\nRemote computer: {computer_name}'
                }
            else:
                error_msg = result.std_err.decode('utf-8').strip() if result.std_err else 'Unknown error'
                return {
                    'success': False,
                    'error': f'PowerShell command failed: {error_msg}',
                    'details': f'WinRM connected but command execution failed.\nExit code: {result.status_code}'
                }

        except winrm.exceptions.InvalidCredentialsError:
            return {
                'success': False,
                'error': 'Authentication failed - invalid username or password',
                'details': 'Check credentials and ensure the account has remote access rights.\n'
                          'For domain accounts, use DOMAIN\\username format.'
            }
        except winrm.exceptions.WinRMTransportError as e:
            if 'connection refused' in str(e).lower():
                return {
                    'success': False,
                    'error': f'Connection refused on port {effective_port}',
                    'details': 'WinRM may not be enabled. Run on target:\n'
                              'Enable-PSRemoting -Force\n'
                              'Set-Item WSMan:\\localhost\\Service\\AllowUnencrypted -Value $true'
                }
            return {
                'success': False,
                'error': f'WinRM transport error: {str(e)}',
                'details': f'Could not establish WinRM connection to {hostname}:{effective_port}'
            }
        except Exception as e:
            logger.error(f"WinRM connection error to {hostname}: {e}")
            return {
                'success': False,
                'error': f'Connection error: {str(e)}',
                'details': f'Failed to connect to {endpoint}'
            }

    def _test_port_only(
        self,
        hostname: str,
        port: int,
        timeout: int = 10
    ) -> Dict[str, Any]:
        """
        Fallback: Test port connectivity only (when pywinrm not available)
        """
        import socket

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((hostname, int(port)))
            sock.close()

            if result == 0:
                return {
                    'success': True,
                    'message': f'WinRM port {port} is open on {hostname}',
                    'details': 'Port connectivity verified.\n'
                              'Note: Full authentication test requires pywinrm library.\n'
                              'Install with: pip install pywinrm'
                }
            else:
                return {
                    'success': False,
                    'error': f'Cannot reach port {port} on {hostname}',
                    'details': 'Ensure WinRM is enabled:\n'
                              'Enable-PSRemoting -Force\n\n'
                              'And firewall allows the port:\n'
                              f'New-NetFirewallRule -Name "WinRM-{port}" -DisplayName "WinRM Port {port}" '
                              f'-Enabled True -Profile Any -Action Allow -Protocol TCP -LocalPort {port}'
                }
        except socket.gaierror as e:
            return {
                'success': False,
                'error': f'DNS resolution failed: {hostname}',
                'details': 'Could not resolve hostname. Verify the server name or use IP address.'
            }
        except socket.error as e:
            return {
                'success': False,
                'error': f'Network error: {str(e)}',
                'details': f'Check network connectivity to {hostname}'
            }

    def execute_command(
        self,
        server: Dict[str, Any],
        command: str = None,
        powershell: bool = True,
        timeout: int = 60,
        *args
    ) -> Dict[str, Any]:
        """
        Execute command on Windows server via WinRM

        Args:
            server: Server configuration dict
            command: Command or PowerShell script to execute
            powershell: Use PowerShell (True) or CMD (False)
            timeout: Command timeout in seconds

        Returns:
            Dict with success, stdout, stderr, return_code
        """
        if not WINRM_AVAILABLE:
            return {
                'success': False,
                'error': 'pywinrm not installed',
                'details': 'Install with: pip install pywinrm'
            }

        hostname = None
        port = None
        username = None
        password = None

        if isinstance(server, dict):
            hostname = server.get('host') or server.get('hostname')
            port = server.get('port', 5985)
            username = server.get('user') or server.get('username')
            password = server.get('password')
        else:
            # Legacy positional signature: (hostname, port, username, password, command)
            if isinstance(command, int) and isinstance(powershell, str) and args:
                hostname = server
                port = command
                username = powershell
                password = timeout if isinstance(timeout, str) else None
                command = args[0]
                powershell = True
                timeout = 60  # Reset timeout to default after extracting from legacy args
            else:
                return {
                    'success': False,
                    'error': 'Invalid WinRM execute_command signature',
                    'details': 'Pass a server dict or use (hostname, port, username, password, command)'
                }

        # Decrypt password if needed
        if password and self.password_manager:
            try:
                password = self.password_manager.decrypt_password(password)
            except Exception as e:
                logger.warning(f"Password decryption failed, using as-is: {e}")

        use_ssl = port == 5986
        protocol = 'https' if use_ssl else 'http'
        endpoint = f"{protocol}://{hostname}:{port}/wsman"

        # A06-01 OWASP fix: Validate SSL certificates by default
        ignore_ssl = os.environ.get('WINRM_IGNORE_SSL', 'false').lower() == 'true'
        cert_validation = 'ignore' if ignore_ssl else 'validate'

        try:
            read_timeout = max(timeout + 5, timeout + 1)
            session = winrm.Session(
                target=endpoint,
                auth=(username, password),
                transport='ntlm',
                server_cert_validation=cert_validation,
                read_timeout_sec=read_timeout,
                operation_timeout_sec=timeout
            )

            if powershell:
                result = session.run_ps(command)
            else:
                result = session.run_cmd(command)

            return {
                'success': result.status_code == 0,
                'stdout': result.std_out.decode('utf-8') if result.std_out else '',
                'stderr': result.std_err.decode('utf-8') if result.std_err else '',
                'return_code': result.status_code
            }

        except Exception as e:
            logger.error(f"WinRM command execution error: {e}")
            return {
                'success': False,
                'error': str(e),
                'stdout': '',
                'stderr': str(e),
                'return_code': -1
            }


# Singleton instance
winrm_manager = WinRMManager()

__all__ = [
    'WinRMManager',
    'winrm_manager',
    'WINRM_AVAILABLE'
]
