# Fleet Agent Guide

## Overview

The **Fleet Agent** system provides two-way API communication between the core Security Audit Toolkit server and remote endpoints. Unlike traditional SSH/WinRM execution methods, the fleet agent allows:

- **Pull-based execution**: Agent polls server for commands
- **Remote configuration**: Server pushes configuration updates to agents
- **Automatic sync**: Audit scripts are synchronized automatically
- **Database integration**: Results are ingested directly into the audit_executions table
- **Firewall-friendly**: Only outbound HTTPS from agent to server required

### Role Definition

The fleet agent is the strategic replacement path for SSH and WinRM when an agent can be installed on the target host.

Current implementation status:
- Today, the primary control plane is outbound heartbeat and polling.
- Target-state is broader: the main tool and asset discovery should use the fleet agent as the authenticated HTTPS query/execution path on the host.

See [docs/AGENT-ROLE-SEPARATION-DECISION.md](docs/AGENT-ROLE-SEPARATION-DECISION.md) for the authoritative role split and implementation direction.

### Scope and Related Modes

This guide is specifically for **Fleet Agent (polling + command queue)**.

- If you need autonomous local execution with scheduled uploads, see **Standalone Agent** in [docs/17-agent-deployment-guide.md](docs/17-agent-deployment-guide.md).
- If you need direct pull-based inventory from Asset Discovery to host endpoint (`/api/system-info`), see [docs/DIRECT-API-USAGE-SETUP.md](docs/DIRECT-API-USAGE-SETUP.md).
- For the target-host managed HTTPS API scaffold, see [docs/MANAGED-AGENT-HTTPS-API-SCAFFOLD.md](docs/MANAGED-AGENT-HTTPS-API-SCAFFOLD.md).

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        Core Audit Server                                 │
│  ┌─────────────────────────────────────────────────────────────────────┐ │
│  │                   Fleet Agent API                                 │ │
│  │  /api/agent/managed/config/{id}     - Configuration sync            │ │
│  │  /api/agent/managed/sync/manifest   - Audit file manifest           │ │
│  │  /api/agent/managed/sync/download   - Download specific files       │ │
│  │  /api/agent/managed/sync/full-package - Full audit package          │ │
│  │  /api/agent/managed/results/ingest  - Submit results to DB          │ │
│  │  /api/agent/managed/poll            - Poll for commands             │ │
│  │  /api/agent/managed/execute         - Queue audit execution         │ │
│  └─────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
                              ▲
                              │ HTTPS (outbound from agent)
                              │
       ┌──────────────────────┴──────────────────────┐
       │                      │                      │
       ▼                      ▼                      ▼
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│   Windows   │      │    Linux    │      │    Linux    │
│   Server    │      │   Server    │      │   Server    │
│ (PS Agent)  │      │ (Bash Agent)│      │   (Alpine)  │
└─────────────┘      └─────────────┘      └─────────────┘
```

## Installation

### Windows Agent

```powershell
# Download and extract the Fleet package
Invoke-WebRequest -Uri "https://your-server/api/agent/download/windows?format=package" -OutFile "C:\AuditTool\fleet-agent-windows.zip"
Expand-Archive -Path "C:\AuditTool\fleet-agent-windows.zip" -DestinationPath "C:\AuditTool\fleet-agent" -Force
Set-Location "C:\AuditTool\fleet-agent"

# Configure and install as service
.\install-windows.ps1 -Mode Service `
    -ServerUrl "https://your-server:5000" `
    -AgentId "win-server-01" `
    -ApiKey "your-secure-api-key"

# User-mode installs can use -Mode User when local admin is not available.
```

### Linux Agent

```bash
# Download and extract the Fleet package
mkdir -p /opt/audit-tool
curl -fsSL "https://your-server/api/agent/download/linux?format=package" -o /opt/audit-tool/fleet-agent-linux.tar.gz
tar -xzf /opt/audit-tool/fleet-agent-linux.tar.gz -C /opt/audit-tool
cd /opt/audit-tool

# System install
sudo ./install-linux.sh "https://your-server:5000" "your-secure-api-key" "linux-server-01"

# Unprivileged hosts can use ./install-user.sh --server-url ... instead.

# Or install as systemd service
cat > /etc/systemd/system/audit-agent.service << 'EOF'
[Unit]
Description=Security Audit Fleet Agent
After=network.target

[Service]
Type=simple
ExecStart=/opt/audit-tool/fleet-agent.sh --daemon
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable audit-agent
systemctl start audit-agent
```

## Configuration

### Agent Configuration File

The agent reads configuration from `/etc/audit-agent/config.json` (Linux) or `$AgentDir\config.json` (Windows):

```json
{
    "server_url": "https://audit-server.example.com:5000",
    "agent_id": "unique-agent-identifier",
    "api_key": "secure-api-key-from-server",
    "poll_interval": 60,
    "sync_interval": 3600,
    "auto_update": true,
    "tls_verify": true,
    "log_level": "INFO"
}
```

### Server-Side Configuration

The server can push configuration updates via `/api/agent/managed/config/{agent_id}`:

```bash
# Get current agent config
curl -H "X-API-Key: $API_KEY" \
    https://server:5000/api/agent/managed/config/linux-server-01

# Update agent config remotely
curl -X PUT -H "X-API-Key: $API_KEY" \
    -H "Content-Type: application/json" \
    -d '{"poll_interval": 30, "auto_update": true}' \
    https://server:5000/api/agent/managed/config/linux-server-01
```

### Elevation Behavior (Linux + Windows)

Managed agent execution now uses per-audit metadata to decide elevation automatically:

- `@elevation: none` → run non-elevated
- `@elevation: partial` or `@elevation: root/admin` → attempt non-interactive elevated execution
- if elevation is unavailable, agent runs non-elevated and records a warning in output (no password prompts)

Linux agent policy can be controlled with:

- `AUDIT_ELEVATION_MODE=auto` (default): elevate only when audit metadata requests it
- `AUDIT_ELEVATION_MODE=on`: always attempt elevation where possible
- `AUDIT_ELEVATION_MODE=off`: never elevate

Legacy compatibility is preserved with `AUDIT_USE_SUDO=true` (maps to always-on elevation behavior).

## API Endpoints

### GET /api/agent/managed/config/{agent_id}

Retrieve current configuration for an agent.

**Response:**
```json
{
    "status": "success",
    "agent_id": "linux-server-01",
    "config": {
        "poll_interval": 60,
        "sync_interval": 3600,
        "auto_update": true
    },
    "config_version": "abc123hash"
}
```

### PUT /api/agent/managed/config/{agent_id}

Update agent configuration (pushed on next poll).

**Request:**
```json
{
    "poll_interval": 30,
    "enabled_audits": ["baseline", "hardening", "cve"]
}
```

### GET /api/agent/managed/sync/manifest

Get list of available audit files with checksums.

**Query Parameters:**
- `os_type`: `linux` or `windows`
- `categories`: Comma-separated list of categories (optional)

**Response:**
```json
{
    "status": "success",
    "manifest_version": "2024-02-17T12:00:00Z",
    "files": [
        {
            "path": "audits/linux/baseline/updates.sh",
            "checksum": "sha256:abc123...",
            "size": 4096,
            "modified": "2024-02-16T10:30:00Z"
        }
    ],
    "total_files": 45,
    "total_size": 245760
}
```

### POST /api/agent/managed/sync/download

Download specific audit files.

**Request:**
```json
{
    "files": [
        "audits/linux/baseline/updates.sh",
        "audits/linux/hardening/ssh.sh"
    ]
}
```

### GET /api/agent/managed/sync/full-package

Download complete audit package as tar.gz or zip.

**Query Parameters:**
- `os_type`: `linux` or `windows`
- `format`: `tar.gz` (default) or `zip`

### POST /api/agent/managed/results/ingest

Submit audit results for database ingestion.

**Request:**
```json
{
    "agent_id": "linux-server-01",
    "server_id": 42,
    "audit_id": 15,
    "execution_id": "exec-uuid-123",
    "started_at": "2024-02-17T10:00:00Z",
    "completed_at": "2024-02-17T10:05:00Z",
    "exit_code": 0,
    "status": "completed",
    "output": "Full audit output here...",
    "results": {
        "total_checks": 25,
        "passed": 20,
        "warnings": 3,
        "failures": 2,
        "checks": [
            {"name": "SSH Hardening", "status": "PASS", "message": "All checks passed"}
        ]
    },
    "system_info": {
        "hostname": "web-server-01",
        "os": "Ubuntu 22.04",
        "kernel": "6.4.1-94-generic"
    }
}
```

**Response:**
```json
{
    "status": "success",
    "message": "Results ingested successfully",
    "execution_id": 1234,
    "database_id": 5678
}
```

### POST /api/agent/managed/poll

Unified polling endpoint for agents.

**Request:**
```json
{
    "agent_id": "linux-server-01",
    "current_config_version": "abc123",
    "current_manifest_version": "2024-02-16T12:00:00Z",
    "status": {
        "running_audits": [],
        "last_heartbeat": "2024-02-17T10:00:00Z"
    }
}
```

**Response:**
```json
{
    "status": "success",
    "actions": {
        "config_update": {
            "required": true,
            "config": {"poll_interval": 30}
        },
        "sync_update": {
            "required": true,
            "files_changed": 3
        },
        "execute": [
            {
                "execution_id": "exec-123",
                "audit_id": 15,
                "audit_script": "baseline/updates.sh"
            }
        ]
    }
}
```

### POST /api/agent/managed/execute

Queue an audit execution on an agent.

**Request:**
```json
{
    "agent_id": "linux-server-01",
    "audit_id": 15,
    "script_path": "audits/linux/baseline/updates.sh",
    "parameters": {
        "verbose": true
    },
    "priority": "normal"
}
```

## Agent Workflow

### Startup Sequence

1. Load local configuration
2. Verify connectivity to server
3. Register/update agent status
4. Sync configuration from server
5. Download/update audit scripts
6. Enter polling loop

### Polling Loop

```
┌──────────────────────────────────────────────────────────┐
│                    Agent Poll Cycle                       │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  1. POST /poll with current state                        │
│     ↓                                                    │
│  2. Check response for config_update                     │
│     → If yes: Update local config                        │
│     ↓                                                    │
│  3. Check response for sync_update                       │
│     → If yes: Download changed audit files               │
│     ↓                                                    │
│  4. Check response for execute commands                  │
│     → If yes: Run each audit, POST results when done     │
│     ↓                                                    │
│  5. Sleep for poll_interval seconds                      │
│     ↓                                                    │
│  └──→ Return to step 1                                   │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

### Execution Flow

```
Server                           Agent
   │                                │
   │  POST /execute (queue audit)   │
   │───────────────────────────────>│
   │                                │
   │  (Agent polls, gets execute)   │
   │<───────────────────────────────│
   │                                │
   │                                │──┐ Run audit script
   │                                │<─┘ locally
   │                                │
   │  POST /results/ingest          │
   │<───────────────────────────────│
   │                                │
   │  (Server stores in database)   │
   │──┐                             │
   │<─┘                             │
   │                                │
   │  Response: success             │
   │───────────────────────────────>│
```

## Database Integration

Results submitted via `/results/ingest` are stored in the `audit_executions` table:

| Column | Source |
|--------|--------|
| server_id | From request (mapped from agent_id if needed) |
| audit_id | From request |
| started_at | From request |
| completed_at | From request |
| exit_code | From request |
| status | From request |
| output | Raw output text |
| json_result | Structured results JSON |
| execution_method | Set to `"fleet_agent"` |

This allows fleet agent results to appear in:
- Dashboard summaries
- Compliance reports
- Historical trends
- Server detail views
- Scheduled report exports

## Security Considerations

### Authentication

All API endpoints require authentication via:
- `X-API-Key` header with valid API key
- Rate limiting (10 requests/minute per agent)

### TLS/SSL

- Always use HTTPS in production
- Agent supports certificate verification (`tls_verify: true`)
- For self-signed certs, add CA to agent trust store or set `tls_verify: false` (not recommended)

### Agent Permissions

- Agent runs with minimal privileges
- Audit scripts are executed with agent's user context
- Some audits may require elevated privileges (configure sudo/runas)

### Firewall Rules

Only **outbound** HTTPS (443/tcp or custom port) from agent to server required:

```
Agent (internal network) ────HTTPS────> Server (DMZ/datacenter)
```

No inbound ports needed on agent hosts.

## Comparison with Other Methods

| Feature | SSH/WinRM (Full Toolkit) | Standalone Agent (push) | Fleet Agent (polling) | Direct Agent API |
|---------|---------------------------|--------------------------|--------------------------|------------------|
| Connection direction | Inbound from server | Outbound from endpoint | Outbound from endpoint | Inbound to endpoint API |
| Primary purpose | Remote command execution | Autonomous local runs + upload | Central queued execution + sync | On-demand discovery/inventory |
| Firewall-friendly (no inbound endpoint mgmt ports) | ❌ | ✅ | ✅ | ❌ (requires endpoint API exposure) |
| Central queued execution | ✅ | ❌ | ✅ | ❌ |
| Script sync/management | Server-driven | Local package lifecycle | Automatic via managed API | Not applicable |
| Result/data path | Direct execution result collection | Endpoint pushes results | Endpoint ingests to managed APIs | Server pulls `/api/system-info` |
| Dashboard integration | ✅ | ⚠️ Depends on upload pipeline | ✅ | ✅ (discovery path) |

## Troubleshooting

### Agent won't connect

1. Verify server URL is accessible: `curl -I https://server:5000/api/health`
2. Check TLS certificate: `openssl s_client -connect server:5000`
3. Verify API key is valid
4. Check agent logs: `/var/log/audit-agent.log`

### Sync failures

1. Check disk space for audit files
2. Verify checksum mismatches aren't due to local modifications
3. Force full resync: `fleet-agent.sh --force-sync`

### Results not appearing

1. Verify `/results/ingest` returns success
2. Check server-side logs for database errors
3. Confirm server_id maps correctly to registered server

## Files

- `web/api/agent_fleet_routes.py` - Server-side API endpoints
- `standalone-agent/fleet-agent.ps1` - Windows PowerShell agent
- `standalone-agent/fleet-agent.sh` - Linux Bash agent
- `/etc/audit-agent/config.json` - Linux agent configuration
- `$AgentDir\config.json` - Windows agent configuration

Note: the `standalone-agent/` directory name is historical in this repository; the scripts above implement the **managed polling agent** described in this guide.

