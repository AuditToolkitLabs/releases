# Agent Selection & Quick-Start Guide

## Quick Decision Tree

```
Do you have persistent SSH/WinRM access to endpoint?
│
├─ Is this target a hypervisor host (ESXi/Proxmox/KVM/XCP-ng/Nutanix)?
│  │
│  ├─ YES → Use HYPERVISOR AGENT (platform-specific daemon)
│  │
│  └─ NO → Continue below
│
├─ YES → Do you want interactive, operator-driven audits?
│         │
│         ├─ YES → Use STANDALONE AGENT (formerly Lightweight Agent)
│         │
│         └─ NO  → Use FLEET AGENT (formerly Managed Agent)
│
└─ NO  → Use FLEET AGENT (one-time push, then autonomous)
         or API-ONLY mode (pre-configure, agent pulls config)
```

---

## JRE Consolidated Agent: Quick Start (Recommended)

Use this path for new deployments (managed or standalone mode).

### 1. Download
```bash
# Deploy Panel:
# Deploy -> JRE Consolidated Agent -> Select mode (Managed/Standalone) -> Download
```

### 2. Install and Start in Background
```bash
# Windows
INSTALL.bat
pwsh -ExecutionPolicy Bypass -File .\START-AGENT.ps1

# Linux
bash install.sh
bash start-agent.sh
```

### 3. Enable Reboot Persistence
```bash
# Windows (elevated terminal)
pwsh -ExecutionPolicy Bypass -File .\ENABLE-AUTOSTART.ps1

# Linux (systemd)
sudo bash enable-autostart.sh
```

### 4. Verify and Access
- Ready check: `agent/logs/agent.out.log` contains `Status: bootstrap initialized`
- Access console: `http://<host-or-ip>:5000`
- TLS/reverse proxy: `https://<host-or-ip>`

### 5. Stop / Disable (as needed)
```bash
# Windows
pwsh -ExecutionPolicy Bypass -File .\STOP-AGENT.ps1
pwsh -ExecutionPolicy Bypass -File .\DISABLE-AUTOSTART.ps1

# Linux
bash stop-agent.sh
sudo bash disable-autostart.sh
```

See full details: [Agent Deployment Guide](17-agent-deployment-guide.md), [JRE Operations and IP Protection](JRE-OPERATIONS-IP-PROTECTION.md)

---

## Hypervisor Agent: Quick Start

Use this path for hypervisor hosts that should run audits locally and report over outbound HTTPS.

### 1. Download Platform Package
```bash
# Linux hypervisors (Proxmox, KVM, XCP-ng, Nutanix AHV)
wget https://<core-server>/api/hypervisor-agent/download/linux?format=package -O audit-hypervisor-agent-linux.tar.gz

# VMware ESXi
wget https://<core-server>/api/hypervisor-agent/download/esxi?format=package -O audit-hypervisor-agent-esxi.tar.gz
```

### 2. Install
```bash
# Linux
tar -xzf audit-hypervisor-agent-linux.tar.gz
cd audit-hypervisor-agent
sudo ./install-linux.sh

# ESXi (BusyBox sh)
tar -xzf audit-hypervisor-agent-esxi.tar.gz
cd audit-hypervisor-agent
sh ./install-esxi.sh
```

### 3. Register
```bash
./audit-hypervisor-agent register --token <REGISTRATION_TOKEN>
```

### 4. Verify
```bash
./audit-hypervisor-agent status
```

---

## Standalone Agent: Quick Start

### 1. Deploy
```bash
# From Core Server Deploy Panel:
Deploy → Standalone Agent → Select servers → Deploy

# OR Manually:
bash agent.sh --mode standalone --server https://audit.example.com --key abc123
```

### 2. Access Web UI
```
Browser: http://target-hostname:8088/setup
```

### 3. Configure
- Enter Core Server URL
- Enter API Key
- Choose: Auto-export results? (yes/no)
- Choose: Setup scheduled audits? (yes/no)

### 4. Use
- Dashboard shows system info
- Select audits to run
- View results in UI
- Results auto-exported to server (if enabled)

### Configuration File
```bash
# Location: ~/.audit-agent/config.json or /app/config/agent-config.json
{
  "core_server_url": "https://audit.example.com",
  "api_key": "your-secret-key",
  "auto_export": true
}
```

### Verify Connection
```bash
# From standalone agent:
curl -v -H "X-API-Key: your-key" \
  https://audit.example.com/api/health

# Expected response: 200 OK with {"status": "healthy"}
```

---

## Fleet Agent: Quick Start

### 1. Deploy
```bash
# From Core Server Deploy Panel:
Deploy → Fleet Agent → Select servers → Deploy

# Agent automatically:
# - Installs as systemd service (Linux) or Windows Service
# - Configures for autonomous operation
# - Sets up scheduled execution (default: 2 AM daily)
# - Ready to run without user interaction
```

### 2. Verify Service
```bash
# Linux
sudo systemctl status audit-agent

# Windows
Get-Service audit-agent
```

### 3. Check First Run
Wait for scheduled time (default 2 AM) or trigger manually:
```bash
# Linux
sudo /opt/audit-agent/agent.sh --run-now

# Windows
& "C:\Program Files\AuditAgent\agent.ps1" -RunNow
```

### 4. Monitor Results
```bash
# Check server logs for result receipt
tail -f /var/log/audit-agent/results.log

# View discovered hosts in Asset Discovery UI
# Look for "Pending Hosts" section
```

### Configuration File
```bash
# Location: /etc/audit-agent/config.json (Linux)
#           C:\Program Files\AuditAgent\config.json (Windows)
{
  "agent_id": "prod-web-01",
  "server_url": "https://audit.example.com",
  "api_key": "secret-key",
  "audit_schedule": "0 2 * * *",
  "network_discovery": {"enabled": true, "subnet": "192.168.1.0/24"}
}
```

### Verify Operation
```bash
# Check logs for successful execution
journalctl -u audit-agent -f  # Linux
Get-EventLog -LogName Application -Source AuditAgent  # Windows

# Manual heartbeat test
curl -X POST https://audit.example.com/api/agent/heartbeat \
  -H "X-API-Key: secret-key" \
  -H "X-Agent-ID: prod-web-01" \
  -H "Content-Type: application/json" \
  -d '{"agent_id":"prod-web-01","status":"healthy"}'
```

---

## Feature Comparison Matrix

| Feature | Standalone Agent | Fleet Agent |
|---------|-------------|-----------|
| **Requires SSH/WinRM** | Optional (manual deployment path) | One-time only |
| **Web Interface** | ✅ Yes (8088) | ❌ No |
| **Operator Control** | ✅ Full | ❌ None |
| **Autonomous Operation** | ❌ No | ✅ Yes |
| **Network Discovery** | ❌ No | ✅ Yes (subnet scan) |
| **Push Results** | ❌ Pull only | ✅ Yes (HTTPS) |
| **Inbound Access** | SSH/WinRM | None after setup |
| **Cron/Task Scheduler** | ✅ Yes | ✅ Yes |
| **Manual Audit Run** | ✅ Via web UI | ✅ CLI trigger |
| **Air-Gapped Safe** | ❌ No | ✅ Yes |
| **Best for Security** | General auditing | Compliance/PCI/HIPAA |

---

## API Connectivity Flow

### Standalone Agent
```
Agent Web UI (port 8088)
    ↓
User submits audit from browser
    ↓
Agent runs audit locally
    ↓
Results ready
    ↓
If auto_export enabled:
    POST /api/agent/results
    Headers: X-API-Key: {key}
    Body: {audit results as JSON}
    ↓
Core Server receives and stores
```

### Fleet Agent
```
Service starts at scheduled time (e.g., 2 AM)
    ↓
Runs configured audits locally
    ↓
Optionally scans network (discovered hosts)
    ↓
Results collected
    ↓
POST /api/agent/results
Headers: X-API-Key: {key}, X-Agent-ID: {id}
Body: {audit results + discovered hosts}
    ↓
Core Server stores + adds hosts to Asset Discovery
    ↓
Send heartbeat every 5 minutes for next-day schedule
```

---

## Setup Scenarios

### Scenario 1: Single Server, Operator-Managed Audits
**Recommendation:** Standalone Agent

```
Requirements:
- Operator needs to decide which audits to run
- Interactive results review preferred
- Don't need network discovery
- Server has SSH/WinRM access

Steps:
1. Deploy standalone agent via SSH
2. Access http://server:8088 from workstation
3. Operator selects audits and runs them
4. Results visible in web UI
5. Optional: Auto-export to core server
```

### Scenario 2: Large Fleet, Compliance Scheduled Audits
**Recommendation:** Fleet Agent

```
Requirements:
- 50+ servers to audit
- Audits must run on schedule (PCI-DSS requirement)
- Can't have persistent SSH/WinRM (security requirement)
- Need to discover new systems on networks

Steps:
1. Deploy fleet agent to all servers (SSH one-time)
2. Disable SSH/WinRM on all servers after deployment
3. Configure network discovery subnet
4. Agents run daily at 2 AM automatically
5. Results push to server, discovered hosts appear in Asset Discovery
6. No more SSH access needed
```

### Scenario 3: Hybrid - Standalone and Fleet Agents
**Recommendation:** Both

```
Standalone for:
- Development servers (operators need to run ad-hoc audits)
- Testing environments (interactive access preferred)

Fleet for:
- Production servers (scheduled compliance audits)
- DMZ servers (no persistent remote access allowed)
- Air-gapped networks (outbound HTTPS only)

Implementation:
- Deploy based on server classification
- Core server manages both types
- Results aggregated in single dashboard
- Network discovery from standalone agents
```

---

## Common Troubleshooting

### "Can't access agent web UI"
```bash
# If using standalone agent at http://hostname:8088

# 1. Verify port 8088 is listening
netstat -tuln | grep 8088
ss -tuln | grep 8088

# 2. Check firewall
sudo ufw allow 8088/tcp
sudo firewall-cmd --add-port=8088/tcp --permanent

# 3. Verify agent is running
ps aux | grep agent
docker ps | grep audit-agent

# 4. Check agent logs
tail -f /opt/audit-agent/logs/app.log
tail -f /app/logs/agent.log  # Docker
```

### "Agent Results Not Showing on Server"
```bash
# If using standalone agent with auto-export:

# 1. Verify API key in config
cat ~/.audit-agent/config.json | grep api_key

# 2. Test connectivity
curl -v -H "X-API-Key: $(cat config.json | jq -r .api_key)" \
  https://core-server.example.com/api/health

# 3. Check export logs
tail -f /opt/audit-agent/logs/export.log

# 4. Verify firewall outbound HTTPS
sudo ufw allow out to any port 443
```

### "Standalone Agent Not Running"
```bash
# 1. Check service status
sudo systemctl status audit-agent
journalctl -u audit-agent -f

# 2. Verify config file exists
ls -la /etc/audit-agent/config.json

# 3. Check permissions
sudo cat /etc/audit-agent/config.json

# 4. Restart service
sudo systemctl restart audit-agent

# 5. Check for scheduled task
crontab -l | grep audit
cat /etc/cron.d/audit-agent
```

### "Network Discovery Not Working"
```bash
# 1. Verify subnet configuration
cat /etc/audit-agent/config.json | jq .network_discovery

# 2. Test scan manually
/opt/audit-agent/tools/arp-scan.sh 192.168.1.0/24

# 3. Check firewall allows outbound ARP/ICMP
sudo ufw allow out from any to 192.168.1.0/24
```

---

## Migration Path

### From Manual SSH Audits → Standalone Agent
```
Current: SSH to server, run audits manually

Step 1: Deploy standalone agent
  bash agent.sh --server your-url --key your-key

Step 2: Access web UI
  http://target:8088

Step 3: No more SSH needed (optionally disable it)

Benefit: Operators can audit from web browser, no SSH keys needed
```

### From Standalone Agent → Fleet Agent
```
Current: Have standalone agents on 20 servers

Scenario: Want automated scheduled audits without web UI

Option A: Keep standalone, add scheduled tasks
  - Schedule runs via Task Scheduler / cron

Option B: Switch to fleet agent
  - Deploy fleet agent to target hosts
  - Keep standalone alongside temporarily
  - Verify fleet agent results
  - Remove standalone where no longer required

Recommended: Run both during transition period
```

---

## Best Practices

### Standalone Agent
1. **Use separate API Keys per agent** for easier revocation
2. **Monitor /app/logs** for connection errors
3. **Set auto_export = true** for automated result collection
4. **Don't expose port 8088 to internet** (use firewall rules, VPN)
5. **Rotate API keys quarterly**

### Fleet Agent
1. **Enable network_discovery** to find new systems
2. **Review discovered hosts** in Asset Discovery before approving
3. **Monitor heartbeat frequency** - default every 300 seconds
4. **Disable SSH/WinRM after verification** not before
5. **Use separate agent_ids** for each server (auto-generated recommended)

### Both Agents
1. **Use HTTPS only** - never plain HTTP for sensitive data
2. **Store config securely** - 0600 permissions on Linux, restricted ACL on Windows
3. **Audit log results** to SIEM if available
4. **Test connectivity** before deploying to production
5. **Document your setup** - which servers have which agent type

---

## Advanced: Headless Standalone Agent

Use standalone agent without web UI (pure API mode):

```bash
# Environment variables for headless operation
export AUDIT_SERVER_URL="https://audit.example.com"
export AUDIT_API_KEY="secret-key"
export AUDIT_AGENT_ID="auto"
export AUDIT_AUTO_EXPORT="true"
export AUDIT_NO_WEB_UI="true"

# Run agent
python app.py

# Or via Docker
docker run -e AUDIT_SERVER_URL=... -e AUDIT_API_KEY=... audit-agent
```

---

## Next Steps

1. **Choose your agent type** using the decision tree above
2. **Read AGENT-INTEGRATION-GUIDE.md** for detailed setup
3. **Read AGENT-API-REFERENCE.md** for API details
4. **Deploy to test environment first**
5. **Verify connectivity** using provided test commands
6. **Monitor first run** for any issues
7. **Scale to production**
